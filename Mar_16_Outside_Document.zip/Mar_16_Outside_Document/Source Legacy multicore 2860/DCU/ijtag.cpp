﻿#include "ijtag.h"



IJtag::IJtag(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2,
    std::unique_ptr<IDcuOperand> opr3, std::unique_ptr<IDcuOperand> opr4, std::unique_ptr<IDcuOperand> opr5): 
    m_comment(""), m_bInLoop(false), m_MemberInLoop(0), m_LoopCount(0), m_JtagConstraint(nullptr) {

    if (opr1) {
        m_vOpr.push_back(std::move(opr1));
        if (opr2) {
            m_vOpr.push_back(std::move(opr2));
            if (opr3) {
                m_vOpr.push_back(std::move(opr3));
                if (opr4) {
                    m_vOpr.push_back(std::move(opr4));
                    if (opr5) {
                        m_vOpr.push_back(std::move(opr5));
                    }
                }
            }
        }
    }
}


CMersenneTwister*   IJtag::m_pRandom = nullptr;

/**
* @brief operand access interface.
* @param n Operand index
* @return Operand reference
*/
IDcuOperand* IJtag::opr(UI32 n) {
    if (m_vOpr.size() > n) {
        return m_vOpr[n].get();
    } else {
        return nullptr;
    }
}

/**
* @brief Determines the value of the operand.
* @return own reference
*/
IJtag* IJtag::SelectValue() {
    UI32 num = this->GetOprNum();
    for (UI32 i = 0; i < num; i++) {
        this->opr(i)->SelectValue();
    }
    return this;
}

/**
* @brief Setting tool support random
* @param random object manage random tool
*/
void IJtag::SetRandomToolPointer(CMersenneTwister* random) {
    if (m_pRandom == nullptr) {
        m_pRandom = random;
    }
}

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string IJtag::GetJtagCommand() {
    std::stringstream ss;

    ss << this->GetJtagName() << '(' << std::setfill(' ') << std::setw(5);
    UI32 i = 0;

    for (;i < m_vOpr.size() - 1; i++) {
        ss << this->opr(i)->GetCode() << ", ";
    }

    ss << this->opr(i)->GetCode();
    ss << std::setfill(' ') << std::setw(6) << ");";

    return ss.str();
}

/**
* @brief append comment into last current comment
*/
void IJtag::AppendComment(const std::string& comment) {
    m_comment += comment;
}

/**
* @brief Get comment of JTAG
* @return string comment of JTAG
*/
std::string IJtag::GetComment() const {
    return m_comment;
}

/**
* @brief erase comment of JTAG
*/
void IJtag::DeleteComment() {
    m_comment = "";
}

/**
* @brief Set data for operand COprStrData support output Jtag
* @bparam data of COprStrData
*/
void IJtag::SetOutOprData(std::string data) {
    for (UI32 i = 0; i < m_vOpr.size(); i++) {
        if (m_vOpr[i]->GetAttribute() == IDcuOperand::OPR_ATTR_SDATA) {
            COprStrData* opr_data = static_cast<COprStrData*>(m_vOpr[i].get());
            opr_data->SetData(data);
        }
    }
}