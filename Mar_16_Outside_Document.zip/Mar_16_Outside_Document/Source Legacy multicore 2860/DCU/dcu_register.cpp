#include        "dcu_register.h"



//========================= CDcuRegisterSet =============================//

std::vector<std::pair<std::string, std::vector<UI32>>>
                    CDcuRegisterSet::m_vReg = {std::pair<std::string, std::vector<UI32>>( "maver",  {1, 0, 0xA0} ),
                                            std::pair<std::string, std::vector<UI32>>( "mastat", {1, 0, 0xA1} ),
                                            std::pair<std::string, std::vector<UI32>>( "mactrl", {1, 0, 0xA2} ),
                                            std::pair<std::string, std::vector<UI32>>( "marwa",  {1, 0, 0xA3} ),
                                            std::pair<std::string, std::vector<UI32>>( "mawd",   {1, 0, 0xA4} ),
                                            std::pair<std::string, std::vector<UI32>>( "mard",   {1, 0, 0xA5} ),
                                            std::pair<std::string, std::vector<UI32>>( "maerr",  {1, 0, 0xA6} ),
                                            std::pair<std::string, std::vector<UI32>>( "maca",   {1, 0, 0xA7} ),
                                            std::pair<std::string, std::vector<UI32>>( "maua",   {1, 0, 0xA8} ),
                                            std::pair<std::string, std::vector<UI32>>( "maad",   {1, 0, 0xA9} ),
                                            std::pair<std::string, std::vector<UI32>>( "matoc",  {1, 0, 0xAA} ),
                                            std::pair<std::string, std::vector<UI32>>( "matos",  {1, 0, 0xAB} ),
                                            std::pair<std::string, std::vector<UI32>>( "mawd1",  {1, 0, 0xAC} ),
                                            std::pair<std::string, std::vector<UI32>>( "mard1",  {1, 0, 0xAD} ),
                                            std::pair<std::string, std::vector<UI32>>( "maside", {1, 0, 0xAE} ),
                                            std::pair<std::string, std::vector<UI32>>( "maenbl", {1, 0, 0xAF} ), 
                                            std::pair<std::string, std::vector<UI32>>("dbgmbout",{1, 0, 0x1B} ),
                                            std::pair<std::string, std::vector<UI32>>("dbgmbin", {1, 0, 0x1C} )
                                            };


/**
* @brief Initialize list of register
*/
void CDcuRegisterSet::InitRegisterList() {

    std::unique_ptr<CDcuRegister> reg;

    for (UI32 i = 0; i < m_vReg.size(); i++) {
        reg = std::make_unique<CDcuRegister>(m_vReg[i].first, m_vReg[i].second[0], m_vReg[i].second[1], m_vReg[i].second[2]);
            m_RegWeight.Set(reg->GetId(), 10);
            m_mRegSet.insert(std::make_pair(reg->GetId(), std::move(reg)));
    }
}

/**
* @brief Get register name base on map, bank and ir
* @param map: MAP of register
* @param bank: BANK of register
* @param ir: IR code of register
*/
std::string CDcuRegisterSet::GetRegName(UI32 map, UI32 bank, UI32 ir) {
    UI32 id = ((map << 11) + (bank << 8) + ir);
    return this->GetRegName(id);
}

/**
* @brief Get register name base on ID
* @param id: ID of register
*/
std::string CDcuRegisterSet::GetRegName(UI32 id) {

    std::map<UI32, std::unique_ptr<CDcuRegister>>::iterator itr = m_mRegSet.find(id);

    if (itr != m_mRegSet.end()) {
        return (itr->second->GetName());
    } else {
        return std::string("");
    }
}

/**
* @brief random register
* @return the value after random
*/
UI32 CDcuRegisterSet::SelectValue() {
    return m_RegWeight.GetObj();
}
