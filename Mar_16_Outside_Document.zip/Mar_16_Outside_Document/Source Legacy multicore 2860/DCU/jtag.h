﻿#ifndef JTAG_H
#define JTAG_H

#include        "ijtag.h"
#include        "dcu_memory.h"



/*===============================================
@brief: Clock(TCK) Output Control
@ID: 0
@name: set_tck
===============================================*/
class JtagSetTck: public IJtag {

public:
    JtagSetTck(): m_tck_stp(false) {}

    JtagSetTck(bool tck_stp_value): m_tck_stp(tck_stp_value) {}

    ~JtagSetTck() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() const;

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
    bool                        m_tck_stp;      //! 1(true): High level of TCK; 0(false): Oscillation

};


/*===============================================
@brief: Clock(TCK) Period Control
@ID: 1
@name: set_tck_cycle
===============================================*/
class JtagSetTckCycle: public IJtag {

public:
    JtagSetTckCycle(): m_cycle(0) {}

    JtagSetTckCycle(UI32 cycle_value): m_cycle(cycle_value) {}

    ~JtagSetTckCycle() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() const;

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
    UI32                        m_cycle;        //! TCK period(32 - bit)

};


/*===============================================
@brief: Clock(TCK) Delay Control
@ID: 2
@name: set_tck_delay
===============================================*/
class JtagSetTckDelay: public IJtag {

public:
    JtagSetTckDelay(): m_delay(0) {}

    JtagSetTckDelay(UI32 delay_value): m_delay(delay_value) {}

    ~JtagSetTckDelay() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() const;

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
    UI32                        m_delay;        //! TCK delay(32-bit)

};


/*===============================================
@brief: Reset(TRSTZ) Pulse Output
@ID: 3
@name: startup
===============================================*/
class JtagStartup: public IJtag {

public:
    JtagStartup() {}

    ~JtagStartup() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() const;

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
};


/*===============================================
@brief: IDLE State Recovery
@ID: 4
@name: idle
===============================================*/
class JtagIdle: public IJtag {

public:
    JtagIdle() {}

    ~JtagIdle() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() const;

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
};


/*===============================================
@brief: 32-bit Data Write
@ID: 5
@name: wr
===============================================*/
class JtagWr: public IJtag {

public:
    JtagWr():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprData>(32)
            ){}

    JtagWr(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3)) {}

    ~JtagWr() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Write
@ID: 6
@name: wr1
===============================================*/
class JtagWr1: public IJtag {

public:
    JtagWr1():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprBit>(),
            std::make_unique<COprData>(1)
            ) {}

    JtagWr1(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3, std::unique_ptr<IDcuOperand> opr4):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3), std::move(opr4)) {}

    ~JtagWr1() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Write with Authentication
@ID: 7
@name: wr1_key
===============================================*/
class JtagWr1Key: public IJtag {

public:
    JtagWr1Key():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprBit>(),
            std::make_unique<COprData>(1),
            std::make_unique<COprKey>()
            ) {}

    JtagWr1Key(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3,
                std::unique_ptr<IDcuOperand> opr4, std::unique_ptr<IDcuOperand> opr5):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3), std::move(opr4), std::move(opr5)) {}

    ~JtagWr1Key() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 32-bit Data Write and Check
@ID: 8
@name: wrc
===============================================*/
class JtagWrc: public IJtag {

public:
    JtagWrc():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprData>(32),
            std::make_unique<COprData>(32)
            ) {}

    JtagWrc(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3, std::unique_ptr<IDcuOperand> opr4):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3), std::move(opr4)) {}

    ~JtagWrc() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 32-bit Data Check
@ID: 9
@name: cmp
===============================================*/
class JtagCmp: public IJtag {

public:
    JtagCmp():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprData>(32)
            ) {}

    JtagCmp(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3)) {}

    ~JtagCmp() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Check
@ID: 10
@name: cmp1
===============================================*/
class JtagCmp1: public IJtag {

public:
    JtagCmp1():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprBit>(),
            std::make_unique<COprData>(1)
            ) {}

    JtagCmp1(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3, std::unique_ptr<IDcuOperand> opr4):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3), std::move(opr4)) {}

    ~JtagCmp1() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 32-bit Data Check with Polling
@ID: 11
@name: poll
===============================================*/
class JtagPoll: public IJtag {

public:
    JtagPoll():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprData>(32)
            ) {}

    JtagPoll(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3)) {}

    ~JtagPoll() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Check with Polling
@ID: 12
@name: bpoll
===============================================*/
class JtagBpoll: public IJtag {

public:
    JtagBpoll():
        IJtag(
            std::make_unique<COprRdy>(),
            std::make_unique<COprReg>(),
            std::make_unique<COprBit>(),
            std::make_unique<COprData>(1)
            ) {}

    JtagBpoll(std::unique_ptr<IDcuOperand> opr1, std::unique_ptr<IDcuOperand> opr2, std::unique_ptr<IDcuOperand> opr3, std::unique_ptr<IDcuOperand> opr4):
        IJtag(std::move(opr1), std::move(opr2), std::move(opr3), std::move(opr4)) {}

    ~JtagBpoll() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: Class to manage group JTAG commands to do certain purpose
===============================================*/
class ComplexJtag: public IJtag {

public:
    ComplexJtag(): m_id(JTAG_ID_NUM), m_name("") {}

    ComplexJtag(JTAG_ID id, std::string name):
        m_id(id),
        m_name(name),
        m_vJtagList() {}

    ~ComplexJtag() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() const { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() const { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() const;

    /**
    * @brief Split Jtag command list
    * @param list of Jtag after spliting
    */
    std::vector<std::unique_ptr<IJtag>> ExpandJtagCommand() { return std::move(m_vJtagList); }

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    virtual bool RegulateJtagCommand() = 0;

protected:
    JTAG_ID                             m_id;               //! ID of JTAG
    std::string                         m_name;             //! name of JTAG
    std::vector<std::unique_ptr<IJtag>> m_vJtagList;        //! manage list of JTAG support certain purpose

};

/*===============================================
@brief: Class to manage specific JTAG commands of MAU module
===============================================*/
class CAccessMemory: public ComplexJtag {

public:
    CAccessMemory(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> mem, UI32 size, const UI32& attribute):
        m_mem(mem),
        m_size(size),
        m_attribute(attribute) {}

    CAccessMemory(UI32 size, const UI32& attribute):
        m_mem(0, CDcuMemory::MAU_BUS_END),
        m_size(size),
        m_attribute(attribute) {}

    ~CAccessMemory() {}

    /**
    * @brief Setting memory pointer
    * @param memory object manage memory of user
    */
    static void SetMemoryPointer(CDcuMemory* memory);

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    virtual bool RegulateJtagCommand() = 0;

protected:
    std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE>   m_mem;              //! address and resource of target memory
    UI32                                            m_size;             //! size of memory area access in MAU (unit: byte)
    const UI32                                      m_attribute;        //! attribute of this JTAG: 0: Read or 1: Write
    static CDcuMemory*                                 m_pMemory;          //! manage memory

};


/*===============================================
@brief: Class to manage access memory by Type A
===============================================*/
class CAccessMemoryTypeA: public CAccessMemory {

public:
    CAccessMemoryTypeA(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> mem, UI32 size, const UI32& attribute, UI32 cnt = 1):
        CAccessMemory(mem, size, attribute), m_cnt(cnt) {}

    CAccessMemoryTypeA(UI32 size, const UI32& attribute, UI32 cnt = 1):
        CAccessMemory(size, attribute), m_cnt(cnt) {}

    ~CAccessMemoryTypeA() {}

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    bool RegulateJtagCommand();

private:
    UI32                m_cnt;      //! Access Count

};


/*===============================================
@brief: Class to manage access memory by Type B
===============================================*/
class CAccessMemoryTypeB: public CAccessMemory {

public:
    CAccessMemoryTypeB(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> mem, UI32 size, const UI32& attribute):
        CAccessMemory(mem, size, attribute) {
    }

    CAccessMemoryTypeB(UI32 size, const UI32& attribute):
        CAccessMemory(size, attribute) {
    }

    ~CAccessMemoryTypeB() {}

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    bool RegulateJtagCommand();

};


/*===================== MACRO for Operand ==========================*/
#define     RDY(val)                  (std::make_unique<COprRdy>(val))
#define     REG(map, bank, ir)        (std::make_unique<COprReg>(map, bank, ir))
#define     DATA(val, size)           (std::make_unique<COprData>(val, size))
#define     SDATA()                   (std::make_unique<COprStrData>())
#define     BIT(val)                  (std::make_unique<COprBit>(val))
#define     KEY(val)                  (std::make_unique<COprKey>(val))

/*===================== MACRO for JTAG ==========================*/
#define     WR(rdy, map, bank, ir, dr)                        (std::make_unique<JtagWr>(RDY(rdy), REG(map, bank, ir), DATA(dr, 32)))
#define     WRsd(rdy, map, bank, ir)                          (std::make_unique<JtagWr>(RDY(rdy), REG(map, bank, ir), SDATA()))
#define     WR1(rdy, map, bank, ir, bit, dr)                  (std::make_unique<JtagWr1>(RDY(rdy), REG(map, bank, ir), BIT(bit), DATA(dr, 1)))
#define     WR1_KEY(rdy, map, bank, ir, bit, dr, key)         (std::make_unique<JtagWr1Key>(RDY(rdy), REG(map, bank, ir), BIT(bit), DATA(dr, 1), KEY(key)))
#define     WRC(rdy, map, bank, ir, dr, c_dr)                 (std::make_unique<JtagWrc>(RDY(rdy), REG(map, bank, ir), DATA(dr, 32), DATA(c_dr, 32)))
#define     CMP(rdy, map, bank, ir, c_dr)                     (std::make_unique<JtagCmp>(RDY(rdy), REG(map, bank, ir), DATA(c_dr, 32)))
#define     CMP1(rdy, map, bank, ir, bit, c_dr)               (std::make_unique<JtagCmp1>(RDY(rdy), REG(map, bank, ir), BIT(bit), DATA(c_dr, 1)))
#define     POLL(rdy, map, bank, ir, c_dr)                    (std::make_unique<JtagPoll>(RDY(rdy), REG(map, bank, ir), DATA(c_dr, 32)))
#define     BPOLL(rdy, map, bank, ir, bit, c_dr)              (std::make_unique<JtagBpoll>(RDY(rdy), REG(map, bank, ir), BIT(bit), DATA(c_dr, 1)))

#endif // !JTAG_H


