#ifndef CDCU_VALCONSTRAINT_H_
#define CDCU_VALCONSTRAINT_H_

#include        "rtg_common.h"
#include        "rnd_gen.h"


/*===============================================
@brief: Class define constraint for DCU module
===============================================*/
class CDcuValConstraint {
public:
    CDcuValConstraint(): m_min(0), m_max(0) {}

    CDcuValConstraint(UI32 min, UI32 max): m_min(min), m_max(max) {}

    ~CDcuValConstraint() {}

    /**
    * @brief Setting tool support random
    * @param random object manage random tool
    */
    static void SetRandomToolPointer(CMersenneTwister* random);

    /**
    * @brief random value between range
    * @return random value
    */
    UI32 SelectValue();

private:
    UI32                            m_min;           //! Maximum value of constraint
    UI32                            m_max;          //! Maximum value of constraint
    static CMersenneTwister*        m_pRandom;      //! manage random class
};

#endif /* CDcuValConstraint_H_*/
