﻿#include "dcu_block.h"


CDcuBlock::CDcuBlock(): m_name(""), m_vJtag() {

}

CDcuBlock::CDcuBlock(std::string name): m_name(name), m_vJtag() {

}

CDcuBlock::~CDcuBlock() {

}

/**
 * @ brief Append new Jtag into vector Jtag of DcuBlock
 */
void CDcuBlock::AddJtag(std::unique_ptr<IJtag>& pJtag) {
	 m_vJtag.push_back(std::move (pJtag));
}

/**
  * @ brief Insert new Jtag at position
  */
bool CDcuBlock::InsertJtag(std::unique_ptr<IJtag> pJtag, UI32 pos) {
	if(pos > m_vJtag.size())
        MSG_ERROR(0, "InsertJtag is not success position = %d\n", pos);

	std::vector<std::unique_ptr<IJtag>>::iterator itr = m_vJtag.begin();
	advance(itr, pos);
	m_vJtag.insert(itr, std::move(pJtag));

	return false;
}

/**
* @ brief Get total number of Jtag in block
*/
UI32 CDcuBlock::GetJtagNum() const {
	return m_vJtag.size();
}

/**
 * @ brief Get the name of DcuBlock
 */
std::string CDcuBlock::GetBlockName() const {
	return m_name;
}

/**
  * @brief  set block name
  */
void CDcuBlock::SetBlockName(std::string name) {
	m_name = name;
}
/**
 * @ brief Get position of Jtag
 */
UI32 CDcuBlock::GetIndex(std::unique_ptr<IJtag> pJtag) {
	UI32 max = GetJtagNum();
	for (UI32 idx = 0; idx < max; idx++) {
		if (at(idx) == pJtag.get()) {
            return idx;
		}
	}
	std::runtime_error excep("Not found Jtag\n");
	throw excep;
	return 1;
}

/**
 * @ brief Get position of Jtag
 */
UI32 CDcuBlock::GetIndex(IJtag* pJtag) {
	UI32 max = GetJtagNum();
	for (UI32 idx = 0; idx < max; idx++) {
        if (at(idx) == pJtag) {
            return idx;
		}
	}
	std::runtime_error excep("Not found Jtag\n");
	throw excep;
	return 1;
}

/**
 * @ brief Get Jtag at position
 */
IJtag* CDcuBlock::at(UI32 pos) {
	if (pos > m_vJtag.size()) 
        throw std::out_of_range("vector::out of range");

    IJtag* result = m_vJtag[pos].get();

	return result;
}

/**
 * @ brief Replace old Jtag by new Jtag
 */
void CDcuBlock::ReplaceJtag(std::unique_ptr<IJtag> before, std::unique_ptr<IJtag> after) {
	//auto itr = std::find (m_vJtag.begin(), m_vJtag.end(), before.get());
	//if (itr == m_vJtag.end()) {
	//	std::cout<<"Can not replace JTAG: "<<after->GetJtagName()<<std::endl;
	//}
	//IJtag* old = (*itr).get();
	//itr = m_vJtag.erase(itr);
	//m_vJtag.insert(itr, after.get());
}

/**
 * @ brief Delete Jtag out of DcuBlock
 */
bool CDcuBlock::RemoveJtag(std::unique_ptr<IJtag> pJtag) {
	/*auto itr = std::find (m_vJtag.begin(), m_vJtag.end(), pJtag);
	if (itr == m_vJtag.end()) {
		return false;
	}
	delete *itr;
	m_vJtag.erase(itr);*/
	return true;
}

/**
 * @ brief Delete Jtag out of DcuBlock
 */
bool CDcuBlock::EraseJtag(std::unique_ptr<IJtag> pJtag) {
	return false;
}

/**
 * @ brief Show the content of DcuBlock
 */
void CDcuBlock::Dump() {
	std::cout << '[' << m_name << ']' << std::endl;
	for (UI32 pos = 0; pos < m_vJtag.size(); pos++) {
		std::cout<<"pos: "<< pos<<std::endl;
		std::cout << m_vJtag[pos]->GetJtagCommand() << "\t" << m_vJtag[pos]->GetComment() << std::endl;
	}
}

/**
 * @brief  Generate code in type A and type B to read memory for final comparision
 */	
void CDcuBlock::LoadDataOut(CDcuMemory::T_RECORDMEM mMemInfor) {
	return ;
}

/**
 * @brief  Expand sub Jtag inside sequence 
 */
void CDcuBlock::ExpandJtagBlock() {
    std::vector<std::unique_ptr<IJtag>> jtag_list(std::move(m_vJtag));
    std::vector<std::unique_ptr<IJtag>> temp;
    m_vJtag.clear();
	
    for (UI32 i = 0; i < jtag_list.size(); i++) {
        std::vector<std::unique_ptr<IJtag>> temp = jtag_list[i]->ExpandJtagCommand();
		
		if (temp.size() == 0)	m_vJtag.push_back(std::move(jtag_list[i]));

        for (UI32 j = 0; j < temp.size(); j++) m_vJtag.push_back(std::move(temp[j]));
    }
}

/**
 * @brief  print final code into output file
 */
void CDcuBlock::Print(std::ostream& ofs) {
    IJtag* pJtag = nullptr;
    const std::string data_variable = "_D_";
    const std::string data_member = data_variable + "[i]";

    auto PrintData = [&](const std::vector<UI32>& data, const std::string& variable) {
        ofs << "\n";
        for (UI32 i = 0; i < data.size(); i++) {
            ofs << variable << std::dec << "[" << i << "] = " << std::hex << "32'h" << data[i] << ";\t";
            if ((i % 10) == 0) ofs << "\n";
        }
        ofs << "\n\n";
    };


	for (UI32 pos = 0; pos < m_vJtag.size(); pos++) {
        pJtag = m_vJtag[pos].get();
		std::vector<UI32> data = pJtag->GetData();

        if (data.size() != 0)
            PrintData(data, data_variable);

        if (pJtag->InLoop() == false) {
            //Print Jtag information
            if (pJtag->GetComment().size())
                ofs << pJtag->GetComment() << "\n";
            ofs << pJtag->GetJtagCommand() << "\n";
        } else {
            UI32 loopCount = pJtag->GetLoopCount();
            UI32 loopMember = pJtag->GetNumOfMemberInLoop();

            ofs << "for (i = 0; i <" << std::dec << loopCount << "; i = i + 1) \n" << "begin \n";

            for (UI32 j = 0; j < loopMember; j++) {
                pJtag = m_vJtag[pos + j].get();
                pJtag->SetOutOprData(data_member);

                if (pJtag->GetComment().size())
                    ofs << std::setw(pJtag->GetComment().size() + 4) << pJtag->GetComment() << "\n";
                ofs << std::setw(pJtag->GetJtagCommand().size() + 4) << pJtag->GetJtagCommand() << "\n";
            }

            ofs << "end \n";
            pos = pos  + (loopMember - 1);
        }
	}
}




