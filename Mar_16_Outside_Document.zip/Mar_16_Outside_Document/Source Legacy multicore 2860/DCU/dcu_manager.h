﻿#ifndef CDCU_MANAGER_H
#define CDCU_MANAGER_H

#include        "dcu_memory.h"
#include        "jtag_set.h"
#include        "dcu_config.h"
#include        "mau_block.h" 
#include        "rtg_common.h"
#include        "rtg_types.h"

class CDcuManager {

public:
    /**
    * @brief Construct this object
    */
    CDcuManager();

    /**
    * @brief  Destroy this object
    */
    ~CDcuManager();

    /**
    * @brief   DCU main
    */
    bool DCUMain(int argc, char** argv);

    /**
    * @brief  Start up DCU by reading input and allocating data to suitable section
    * @param  None
    * @return Return TRUE if DCU is started up successfully, otherwise return FALSE
    */
    bool InitDCU(int argc, char** argv);

    /**
    * @brief   Generate random Jtag for DCU
    */
    bool GenerateDCUBlock(std::vector <std::unique_ptr<CDcuBlock>>* vdcuBlock);

    /**
    * @brief   Output the code, write it into output file
    */
    bool OutputResult(std::vector <std::unique_ptr<CDcuBlock>>* vdcuBlock);

    /**
    * @brief  Init MAU memory
    * @param  None
    * @return Return TRUE if init successfully, otherwise return FALSE
    */
    bool ParseDcuInfor(const std::string& section);

	 /**
    * @brief  Generate Num block Jtag
    * @param  None
    * @return
    */
	std::unique_ptr<CDcuBlock> GenerateJtagBlock(UI32 N);

    /**
    * @brief  Generate print user code setting
    * @param  None
    * @return true: success
			  false: fail
    */
    bool PrintUserCode(std::ofstream& ofs, std::string key);

    /**
    * @brief  Export variable and data that necessary to support execute DCU
    */
    void PrintSelfDefinitionData(std::ofstream& ofs);
	
	/**
	 * @brief   Generate handshake code at begin of random block for DCU and CPU
	 * @param  CDcuBlock
	 * @return None
	 * 
	 */
    virtual void GenerateHandshakeSequence(std::unique_ptr<CDcuBlock>& dcu);

	/**
	 * @brief   Generate handshake code at begin of random block for DCU-MAU and CPU
	 * @param  CMauBlock
	 * @return None
	 * 
	 */
    virtual void GenerateFinalHandshakeSequence(std::unique_ptr<CMauBlock>& mau);

    /**
    * @brief  Get Self Check Memory Range
    * @return  Self Check Memory Range
    */
    std::map<MEMADDR, UI32>  GetSelfCheckMemRange();

    /**
    * @brief  Convert string (both decimal and hexa) to integer
    * @param  s: Input string
    * @return Integer number
    */
    static unsigned int AtoI(LPCTSTR s) throw (std::invalid_argument) {
        std::stringstream	ss;
        std::string			str(s);
        UI32				val;
        int					len = str.length();

        if (len < 1) {
            throw std::invalid_argument(s);
        }
        transform(str.begin(), str.end(), str.begin(), tolower);
        if (str.compare(0, 2, "0x") == 0) {
            for (int p = 2; p < len; p++) {
                if ((str.at(p) < '0' || str.at(p) > '9') && (str.at(p) < 'a' || str.at(p) > 'f')) {
                    throw std::invalid_argument(s);
                }
            }
            ss << std::hex << str.substr(2, str.length() - 2);
        }
        else {
            for (int p = 0; p < len; p++) {
                if (str.at(p) < '0' || str.at(p) > '9') {
                    throw std::invalid_argument(s);
                }
            }
            ss << std::dec << str;
        }
        ss >> val;
        return (unsigned int)val;
    }

    /**
    * @brief  get the prefix for dcu label
    * @param  None
    * @return string prefix
    */
    std::string GetTContext() {
        std::string strContext;
        std::stringstream ss;
        ss << "frog_P" << std::dec << std::right << std::setw(2) << std::setfill('0') << m_config->GetPeId();
        ss << '_';

        ss >> strContext;
        return strContext;
    }

    /**
    * @brief  get the peid
    * @param  None
    * @return peid
    */
    UI32 GetPeId() const {
        return m_config->GetPeId();
    }

public:
    std::unique_ptr<CDcuMemory>    m_memory;
    CJtagSet					m_accessMem;
    std::unique_ptr<CDcuConfig> m_config;
	std::vector<std::pair <UI32, UI32>>	m_mHandShakeRecord;
};

#endif // !CDCU_MANAGER_H

