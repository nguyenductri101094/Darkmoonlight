﻿#include "jtag_set.h"


std::map<std::string, IJtag::JTAG_ID> CJtagSet::m_mJtagSet =
{
            { "MAU_rd_b_type_a", IJtag::JTAG_ID_MAU_RD_B_TYPE_A },
            { "MAU_wr_b_type_a", IJtag::JTAG_ID_MAU_WR_B_TYPE_A },
            { "MAU_rd_h_type_a", IJtag::JTAG_ID_MAU_RD_H_TYPE_A },
            { "MAU_wr_h_type_a", IJtag::JTAG_ID_MAU_WR_H_TYPE_A },
            { "MAU_rd_w_type_a", IJtag::JTAG_ID_MAU_RD_W_TYPE_A },
            { "MAU_wr_w_type_a", IJtag::JTAG_ID_MAU_WR_W_TYPE_A },
            { "MAU_rd_dw_type_a", IJtag::JTAG_ID_MAU_RD_DW_TYPE_A },
            { "MAU_wr_dw_type_a", IJtag::JTAG_ID_MAU_WR_DW_TYPE_A },

            { "MAU_rd_b_type_b", IJtag::JTAG_ID_MAU_RD_B_TYPE_B },
            { "MAU_wr_b_type_b", IJtag::JTAG_ID_MAU_WR_B_TYPE_B },
            { "MAU_rd_h_type_b", IJtag::JTAG_ID_MAU_RD_H_TYPE_B },
            { "MAU_wr_h_type_b", IJtag::JTAG_ID_MAU_WR_H_TYPE_B },
            { "MAU_rd_w_type_b", IJtag::JTAG_ID_MAU_RD_W_TYPE_B },
            { "MAU_wr_w_type_b", IJtag::JTAG_ID_MAU_WR_W_TYPE_B },
            { "MAU_rd_dw_type_b", IJtag::JTAG_ID_MAU_RD_DW_TYPE_B },
            { "MAU_wr_dw_type_b", IJtag::JTAG_ID_MAU_WR_DW_TYPE_B }
    };

/**
* @brief Set access memory type and corresponding information
*/
bool CJtagSet::SetJtagInfor(std::string access_type, UI32 weight_value, UI32 cnt_min, UI32 cnt_max) {

    std::map<std::string, IJtag::JTAG_ID>::iterator itr = m_mJtagSet.find(access_type);

    if (itr != m_mJtagSet.end()) {
        m_JtagWeight.Set(itr->second, weight_value);
        if (cnt_max != 0 && cnt_max >= cnt_min) {
            m_mJtagCntRange.insert(std::make_pair(itr->second, std::make_pair(cnt_min, cnt_max)));
        }

        return true;
    } else {
        return false;
    }
}


/**
* @brief Random access memory type and create JTAG command base on that
*/
std::unique_ptr<IJtag> CJtagSet::CreateJtagCommand() {
    IJtag::JTAG_ID id = m_JtagWeight.GetObj();
    return this->CreateJtagCommand(id);
}


/**
* @brief create JTAG command based on access memory type
*/
std::unique_ptr<IJtag> CJtagSet::CreateJtagCommand(IJtag::JTAG_ID access_id) {

    std::unique_ptr<IJtag> pJtag = nullptr;
    const char read = 0;
    const char write = 1;

    switch (access_id) {
        case IJtag::JTAG_ID_MAU_RD_B_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(1, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_B_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(1, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_H_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(2, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_H_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(2, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_W_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(4, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_W_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(4, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_DW_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(8, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_DW_TYPE_A:
            pJtag = std::make_unique<CAccessMemoryTypeA>(8, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_B_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(1, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_B_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(1, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_H_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(2, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_H_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(2, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_W_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(4, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_W_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(4, write);
            break;
        case IJtag::JTAG_ID_MAU_RD_DW_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(8, read);
            break;
        case IJtag::JTAG_ID_MAU_WR_DW_TYPE_B:
            pJtag = std::make_unique<CAccessMemoryTypeB>(8, write);
            break;
        default:
            _ASSERT(0);
            break;
    }

    std::map<IJtag::JTAG_ID, std::pair<UI32, UI32>>::iterator itr = m_mJtagCntRange.find(access_id);

    if (itr != m_mJtagCntRange.end()) {
        std::unique_ptr<CDcuValConstraint> constraint = std::make_unique<CDcuValConstraint>(itr->second.first, itr->second.second);
        pJtag->SetConstraint(constraint);
    }

    return pJtag;
}

