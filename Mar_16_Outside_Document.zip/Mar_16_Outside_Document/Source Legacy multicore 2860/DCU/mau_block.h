﻿#ifndef CMAU_BLOCK_H
#define CMAU_BLOCK_H

#include        "dcu_block.h"
#include        "jtag.h"

class CMauBlock: public CDcuBlock {

public:

	/**
     * @ brief contructor for CMauUBlock object
     * @ param
     * @ return
     */
    CMauBlock();

	/**
     * @ brief contructor for CMauUBlock object
     * @ param name: The name of MauBlock, default is null
     * @ return
     */
    CMauBlock(std::string name);

	/**
     * @ brief Delete MAUBlock object
     * @ param 
     * @ return
     */
    ~CMauBlock();

	/**
	 * @brief  Generate code in type A and type B to read memory for final comparision
	 * @param  
	 * @return CDcuBlock content JTAG read memory
	 * 
	 */	
    virtual void LoadDataOut(CDcuMemory::T_RECORDMEM mMemInfor);

private:
    bool								m_MBIN;    //! Content value of DBG_MBIN register for handshake between MAU and CPU 
    bool								m_MBOUT;   //! Content value of DBG_MBOUT register for handshake between MAU and CPU
    std::vector<std::pair <UI32, UI32>>	m_mHandShakeRecord;
};

#endif // !CMAU_BLOCK_H


