﻿#ifndef CDCU_CONFIG_H
#define CDCU_CONFIG_H

#include        "rtg_common.h"
#include        "rtg_types.h"
#include		<getopt.h>

class CDcuConfig {

public:

    /**
    * @brief Construct this object
    */
    CDcuConfig();

    /**
    * @brief  Destroy this object
    */
    ~CDcuConfig();

	 /**
    * @brief  Get the random number
    * @param  None
    * @return Return number
    */
    UI32 GetSeedNum() const;

    /**
    * @brief  Get number of Jtag in a block
    * @param  None
    * @return Return number of Jtag in a block
    */
    UI32 GetJtagNum() const;

    /**
    * @brief  Get number of Jtag Block
    * @param  None
    * @return Return number of Jtag block
    */
    UI32 GetBlockJtagNum() const;

	/**
    * @brief  Get number of CPU random Block
    * @param  None
    * @return Return number of JCPU random Block
    */
    UI32 GetCPUBlockNum() const;

	/**
     * @ brief Get the name of DCU seeting file
     * @ param 
     * @ return the name
     */
	std::string GetProfileName() const;

    /**
    * @ brief Get the name of DCU user code file
    * @ param
    * @ return the name
    */
    std::string GetUsercodeName() const;

    /**
    * @brief  rename of FROG output file
    * @param  None
    */
    void RenameOutputFile();

	/**
    * @brief  Get name of FROG output file 
    * @param  None
    * @return Return the name that user setting
    */
	std::string GetOutputFileName() const;

	/**
    * @brief  Parse input file DCU configuration
    * @param  filepath Path of input file DCU configuration
    * @return Return TRUE if data is processed successfully, otherwise return FALSE
    */
    bool ParseDcuOption(int argc, char** argv);

    /**
    * @brief  Parse input file DCU configuration
    * @param  filepath Path of input file DCU configuration
    * @return Return TRUE if data is processed successfully, otherwise return FALSE
    */
    bool ParseDcuConfig(const std::string& filepath);

    /**
    * @brief  Parse input file DCU user code
    * @param  filepath Path of input file DCU user code
    * @return Return TRUE if data is processed successfully, otherwise return FALSE
    */
    bool ParseDcuUsercode(const std::string& filepath);

    /**
    * @brief  Method to access usercode data
    * @param  key Name of usercode section that need to get
    * @return Return vector string contain data of that section
    */
    CsvRow& GetDcuUsercode(const std::string& key);

    /**
    * @brief  Method to access data in each section
    * @param  section Name of section that need to get
    * @return Return vector contain data of that section
    */
    SectionData& GetSectionData(const std::string& section);

    /**
    * @brief  Seprate string by specific character
    * @param  str Target string
    * @param  key Specific character
    * @return Return vector string which is seprated
    */
    CsvRow	Split(std::string& src, const std::string& key);

    /**
    * @brief  Remove redundant character ("space") out of string
    * @param  str Target string
    * @return Return string without "space" character
    */
    static std::string Trim(const std::string& str);

    /**
    * @brief  Check if string is section key (contain "::")
    * @param  str Target string
    * @return Return TRUE if string is section key, otherwise return FALSE
    */
    bool	IsSectionKey(const std::string& str);

    /**
    * @brief  Print out all data for debugging
    * @param  None
    * @return Return all data of configuration
    */
    void DumpConfigData();

    /**
    * @brief  Get peid from configuration
    * @param  None
    * @return PeId
    */
    UI32 GetPeId() const;


public:
    UI32            m_nSeed;

private:
	
	UI32            m_nCPUBlockNum;
    UI32            m_nJtagNum;    //<! @brief Number of Jtag in a block
    UI32            m_nBlockJtagNum;   //<! @brief Number of block Jtag
    UI32            m_nPeId;
	std::string     m_strOutputCmd;
	std::string		m_strDCUProfile;
	std::string		m_strDCUUsercode;
	static const std::string	optstr;
	static const struct option	opts[];

protected:
    SectionMap    m_mConfigData;  //<! @brief Map that contain data of all sections
    SectionMapUsecode    m_mDcuUsercodeData;  //<! @brief Map that contain data of all sections
};

#endif // !CDCU_CONFIG_H


