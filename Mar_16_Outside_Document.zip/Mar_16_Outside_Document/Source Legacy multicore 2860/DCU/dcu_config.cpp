﻿#include    "dcu_config.h"
#include    "dcu_manager.h"


CDcuConfig::CDcuConfig():
    m_nSeed(0),
    m_nCPUBlockNum(0),
    m_nJtagNum(0),
    m_nBlockJtagNum(0),
    m_nPeId(0),
    m_strOutputCmd("out_%seed%.cmd"),
    m_strDCUProfile(),
    m_strDCUUsercode()
    {}


CDcuConfig::~CDcuConfig() {

}

const std::string CDcuConfig::optstr("");

const struct option CDcuConfig::opts[] = {

	{"block_num",       required_argument, NULL, 0x10},
	{"output_asm_file", required_argument, NULL, 0x11},
	{"Jtag_blockNum",   required_argument, NULL, 0x12},
	{"Jnum_in_block", 	required_argument, NULL, 0x13},
	{"dcu_profile",		required_argument, NULL, 0x14},
	{"dcu_usercode",	required_argument, NULL, 0x15},
	{"seed"		   ,	required_argument, NULL, 0x16},
    {"peid"		   ,	required_argument, NULL, 0x17},
	{NULL, 0, NULL, 0}
};

/**
* @brief  Get number of Jtag in a block
*/
UI32 CDcuConfig::GetSeedNum() const {
    return m_nSeed;
}

/**
* @brief  Get number of Jtag in a block
*/
UI32 CDcuConfig::GetJtagNum() const {
    return m_nJtagNum;
}

/**
* @brief  Get number of Jtag Block
*/
UI32 CDcuConfig::GetBlockJtagNum() const {
    return m_nBlockJtagNum;
}

/**
* @brief  Get number of Jtag Block
*/
UI32 CDcuConfig::GetCPUBlockNum() const {
    return m_nCPUBlockNum;
}

/**
* @brief  Get the name of setting file
*/
std::string CDcuConfig::GetProfileName() const {
    return m_strDCUProfile;
}

/**
* @brief  Get the name of setting file
*/
std::string CDcuConfig::GetUsercodeName() const {
    return m_strDCUUsercode;
}

/**
* @brief  rename name of ouptput file
*/
void CDcuConfig::RenameOutputFile() {
	std::string strRename;
	std::string placeholder = "%seed%";
    std::string::size_type idx;

    if ((idx = m_strOutputCmd.find(placeholder, 0)) != std::string::npos) {
        std::stringstream ss;
        ss << m_strOutputCmd.substr(0, idx) << std::hex << std::setw(8) << std::setfill('0') << m_nSeed << ".cmd";
        ss >> m_strOutputCmd;
    } else {
        std::string::size_type pos(m_strOutputCmd.rfind('.'));
        if (pos != std::string::npos) {
            m_strOutputCmd = m_strOutputCmd.substr(0, pos) + ".cmd";
        } else {
            m_strOutputCmd += ".cmd";
        }
    }
}


/**
* @brief  Get name of ouptput file
*/
std::string CDcuConfig::GetOutputFileName() const {
    return m_strOutputCmd;
}


/**
* @brief  Parse input file DCU configuration
*/
bool CDcuConfig::ParseDcuOption(int argc, char** argv) {
	int			opt;
	extern int	opterr;
    extern int	optind;

    optind = 1; /* Set index to start processed */
	opterr = 0; /* Don't show message in getopt.*/

	/* Retrieve parameters */
    while ((opt = getopt_long(argc, argv, optstr.c_str(), opts, NULL)) != -1) {
        switch ( opt ) {
			
		case 0x10: /*block_num*/
			m_nCPUBlockNum = std::atoi(optarg);
			try {
				
				if ((m_nCPUBlockNum = CDcuManager::AtoI(optarg)) == 0) {
					MSG_ERROR(0, "Invalid param : --block_num is 0.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --block_num needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --block_num \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			
			break;

		case 0x11:	/* output_asm_file */
			if (strncmp(optarg, "--", 2) == 0) {
				MSG_ERROR(0, "Invalid param : --output_asm_file needs parameter.\n", optarg);
				return false;
			}
			m_strOutputCmd = optarg;
			break;

		case 0x12: /*Jtag_blockNum*/
			try {
				if ((m_nBlockJtagNum = CDcuManager::AtoI(optarg)) == 0) {
					MSG_ERROR(0, "Invalid param : --block_num is 0.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2) == 0) {
					MSG_ERROR(0, "Invalid param : --block_num needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --block_num \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;

		case 0x13:	/* Jnum_in_block */
			try {
				if ((m_nJtagNum = CDcuManager::AtoI(optarg)) == 0) {
					MSG_ERROR(0, "Invalid param : --Jnum_in_block is 0.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				
				if (strncmp(optarg, "--", 2) == 0) {
					MSG_ERROR(0, "Invalid param : --Jnum_in_block needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --Jnum_in_block \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;

		case 0x14:	/* m_strDCUProfile */
			if (strncmp(optarg, "--", 2) == 0) {
				MSG_ERROR(0, "Invalid param : --dcu_profile needs parameter.\n", optarg);
				return false;
			}
			m_strDCUProfile = optarg;
			break;

		case 0x15:	/* m_strDCUUsercode */
			if (strncmp(optarg, "--", 2) == 0) {
				MSG_ERROR(0, "Invalid param : --dcu_usercode needs parameter.\n", optarg);
				return false;
			}
			m_strDCUUsercode = optarg;
			break;

		case 0x16:	/* seed */
			try {
				m_nSeed = CDcuManager::AtoI(optarg);
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --seed needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --seed \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;

        case 0x17:
            try {
                m_nPeId = CDcuManager::AtoI(optarg);
                if (m_nPeId > 63) {
                    MSG_ERROR(0, "Invalid param : --peid needs 0-63. (%d)\n", optarg);
                    return false;
                }
            } catch (std::invalid_argument) {
                MSG_ERROR(0, "Invalid param : --peid \"%s\" is not number.\n", optarg);
                return false;
            }
            break;

		default:
            break;
		}
	}
	
	return true;
}
/**
* @brief  Parse input file DCU configuration
*/
bool CDcuConfig::ParseDcuConfig(const std::string& filepath) {
    std::ifstream	ifs(filepath);
    const std::string 	separator(",");
    SectionData			secdata;
    if (ifs.fail()) {
        if (filepath.length() == 0) {
            return true;
        }
        else {
            MSG_ERROR(0, "profile [%s] not found.\n", filepath.c_str());
        }
        return false;
    }

    // Csv splitter
    while (ifs.eof() != true) {
        std::string  line;
        getline(ifs, line);
        CsvRow&& row = Split(line, std::string("//"));
        if (row.empty()) {
            continue;
        }
        line = row[0];
        row.clear();
        if ((row = Split(line, std::string(","))).size() > 0) {
            secdata.push_back(row);
        }
    }

    // Section distribute
    SectionData::iterator itr;
    SectionData part = { { "NOTHING" } };
    SectionName name = "NOTHING";
	
    for (itr = secdata.begin(); itr != secdata.end(); ++itr) {
       // std::cout << "itr: " << (*itr)[0] << "\tSize: " << (*itr).size() << std::endl;
        if (IsSectionKey((*itr)[0]) == true) {
            if ((*itr).size() == 1) {
                if (m_mConfigData.insert(Section(name, part)).second != true) {
                    SectionData vpre = m_mConfigData[name];
                    vpre.insert(vpre.end(), part.begin(), part.end());
                    m_mConfigData.erase(name);
                    m_mConfigData.insert(Section(name, vpre));
                }
                name = (*itr)[0];
                part.clear();
            }
            else {
                //Do nothing
            }
        }
        else {
            part.push_back(*itr);
        }
    }

    if (part.empty() == false) {
        if ((m_mConfigData.insert(Section(name, part)).second) != true) {
            SectionData vpre = m_mConfigData[name];
            vpre.insert(vpre.end(), part.begin(), part.end());
            m_mConfigData.erase(name);
            m_mConfigData.insert(Section(name, vpre));
        }
    }

    m_mConfigData.erase("NOTHING");

    return true;
}

/**
* @brief  Parse input file DCU user code
*/
bool CDcuConfig::ParseDcuUsercode(const std::string& filepath) {
    // Current design need user code for start up
    if (m_strDCUUsercode.length() == 0) {
        return false;
    }

    std::ifstream ifs(m_strDCUUsercode, std::ios_base::in);
    if (!ifs) {
        std::cerr << "Fail to retrieve DCU user-code [" << m_strDCUUsercode << "]" << "\n";
        return false;
    }

    CsvRow			secdataUsercode;
    while (ifs.eof() != true) {
        std::string  line;
        getline(ifs, line);
        secdataUsercode.push_back(line);
    }

    // Section distribute
    CsvRow::iterator itr;
    CsvRow part = { "NOTHING" };
    SectionName name = "NOTHING";

    for (itr = secdataUsercode.begin(); itr != secdataUsercode.end(); ++itr) {
        // std::cout << "itr: " << (*itr)[0] << "\tSize: " << (*itr).size() << std::endl;
        if (IsSectionKey(*itr) == true) {
            if (m_mDcuUsercodeData.insert(SectionUsecode(name, part)).second != true) {
                CsvRow vpre = m_mDcuUsercodeData[name];
                vpre.insert(vpre.end(), part.begin(), part.end());
                m_mDcuUsercodeData.erase(name);
                m_mDcuUsercodeData.insert(SectionUsecode(name, vpre));
            }
            name = *itr;
            part.clear();
        } else {
            part.push_back(*itr);
        }
    }

    if (part.empty() == false) {
        if ((m_mDcuUsercodeData.insert(SectionUsecode(name, part)).second) != true) {
            CsvRow vpre = m_mDcuUsercodeData[name];
            vpre.insert(vpre.end(), part.begin(), part.end());
            m_mDcuUsercodeData.erase(name);
            m_mDcuUsercodeData.insert(SectionUsecode(name, vpre));
        }
    }

    m_mDcuUsercodeData.erase("NOTHING");
    return true;
}

CsvRow& CDcuConfig::GetDcuUsercode(const std::string& key)
{
    static CsvRow dummyCsvRow;
    SectionMapUsecode::iterator itr = m_mDcuUsercodeData.lower_bound(key);
    if (itr != m_mDcuUsercodeData.end()) return itr->second;
    return dummyCsvRow;
}

/**
* @brief  Method to access data in each section
*/
SectionData& CDcuConfig::GetSectionData(const std::string& section) {
    static SectionData dummy;
    SectionMap::iterator itr = m_mConfigData.lower_bound(section);
    if (itr != m_mConfigData.end()) return itr->second;
    return dummy;
}

/**
* @brief  Seprate string by specific character
*/
CsvRow CDcuConfig::Split(std::string& src, const std::string& key) {
    CsvRow v;
    std::string::size_type index = 0;
    while (index < src.length()) {
        std::string::size_type oldindex = index;
        index = src.find(key, index);
        if (index != std::string::npos) {
            std::string item = src.substr(oldindex, index - oldindex);
            v.push_back(Trim(item));
        }
        else {
            std::string item = src.substr(oldindex);
            v.push_back(Trim(item));
            break;
        }
        index += key.length();
    }
    return v;
}

/**
* @brief  Remove redundant character ("space") out of string
*/
std::string CDcuConfig::Trim(const std::string & str) {

    std::string::const_iterator head = str.begin();
    std::string::const_iterator tail = str.end();
    if (str.length() < 1) {
        return std::string("");
    }

    while (isspace(*head)) {
        head++;
    }
    if (head != tail) {
        do {
            tail--;
        } while (isspace(*tail));
        tail++;
    }
    return std::string(head, tail);
}

/**
* @brief  Check if string is section key (contain "::")
*/
bool CDcuConfig::IsSectionKey(const std::string& str) {
    return str.compare(0, 2, "::", 2) == 0;
}

/**
* @brief  Print out all data for debugging
*/
void CDcuConfig::DumpConfigData() {
    SectionMap::iterator s;
    for (s = m_mConfigData.begin(); s != m_mConfigData.end(); ++s) {
        if (s->first.length() == 0) {
            std::cout << "[no name]" << std::endl;
        }
        else {
            std::cout << "[" << s->first << "]" << std::endl;
        }
        SectionData::iterator d;
        for (d = s->second.begin(); d != s->second.end(); ++d) {
            CsvRow::iterator c = d->begin();
            if (c != d->end()) {
                std::cout << *c;
                c++;
            }
            for (; c != d->end(); ++c) {
                std::cout << ", " << *c;
            }
            std::cout << std::endl;
        }
    }
}

/**
* @brief  Get peid from configuration
* @param  None
* @return PeId
*/
UI32 CDcuConfig::GetPeId() const {
    return m_nPeId;
}

