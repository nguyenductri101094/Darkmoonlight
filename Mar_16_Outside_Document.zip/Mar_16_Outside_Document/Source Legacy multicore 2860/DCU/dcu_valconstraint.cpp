#include           "dcu_valconstraint.h"


//========================= CDcuValConstraint =============================//

CMersenneTwister*   CDcuValConstraint::m_pRandom = nullptr;
/**
* @brief Setting tool support random
* @param random object manage random tool
*/
void CDcuValConstraint::SetRandomToolPointer(CMersenneTwister* random) {
    if (m_pRandom == nullptr) {
        m_pRandom = random;
    }
}

UI32 CDcuValConstraint::SelectValue() {
    return m_pRandom->GetRange(m_min, m_max);
}