﻿#include "dcu_manager.h"

CDcuManager::CDcuManager() : 
    m_memory(new CDcuMemory), 
    m_accessMem(), 
    m_config(new CDcuConfig)
{}

CDcuManager::~CDcuManager() {

}

/**
* @brief   DCU main
*/
bool CDcuManager::DCUMain(int argc, char** argv) {

    std::vector <std::unique_ptr<CDcuBlock>> vdcuBlock;

    if (InitDCU(argc, argv) == false) {
        MSG_ERROR(0, "InitDCU is FAIL\n");
        return false;
    }

    if (GenerateDCUBlock(&vdcuBlock) == false) {
        MSG_ERROR(0, "GenerateDCUMain is FAIL\n");
        return false;
    }

    if (OutputResult(&vdcuBlock) == false) {
        MSG_ERROR(0, "OutputJtagCommand is FAIL\n");
        return false;
    }

    return true;
}

/**
* @brief  Start up DCU by reading input and allocating data to suitable section
*/
bool CDcuManager::InitDCU(int argc, char** argv) {

    if (m_config->ParseDcuOption(argc, argv) != true) {
        MSG_ERROR(0, "\nParsing option is not success\n");
        return false;
    }

    if (m_config->ParseDcuConfig(m_config->GetProfileName()) != true) {
        MSG_ERROR(0, "\nParsing profile is not success\n");
        return false;
    }

    if (m_config->ParseDcuUsercode(m_config->GetUsercodeName()) != true) {
        MSG_ERROR(0, "\nParsing usercode is not success\n");
        return false;
    }

    if (ParseDcuInfor("::MEMORY_CONFIGURATION") == false) {
        MSG_ERROR(0, "\nInit Memory MAU not success\n");
        return false;
    }

    if (ParseDcuInfor("::MAU_REQUEST") == false) {
        MSG_ERROR(0, "\nInit JtagSet MAU not success\n");
        return false;
    }

    UI32 seed = m_config->GetSeedNum();
    g_rnd.Seed(&seed);
    m_config->RenameOutputFile();

    IJtag::SetRandomToolPointer(&g_rnd);
    CDcuValConstraint::SetRandomToolPointer(&g_rnd);
    CAccessMemory::SetMemoryPointer(this->m_memory.get());

    return true;
}

/**
* @brief   Generate random Jtag for DCU
*/
bool CDcuManager::GenerateDCUBlock(std::vector <std::unique_ptr<CDcuBlock>>* vdcuBlock) {

    UI32 BlockNum = this->m_config->GetBlockJtagNum();
    for (UI32 N = 0; N < BlockNum; N++) {
        std::unique_ptr<CDcuBlock> dcuBlock = this->GenerateJtagBlock(N);
        dcuBlock->ExpandJtagBlock();
        vdcuBlock->push_back(std::move(dcuBlock));
    }
    // JTAG read memory for comparison
    std::unique_ptr<CMauBlock> mauBlock = std::make_unique<CMauBlock>();
    mauBlock->SetBlockName("Self_check_code");
    this->GenerateFinalHandshakeSequence(mauBlock);
    CDcuMemory::T_RECORDMEM mMemInfor = this->m_memory->GetExecutedMem();
    mauBlock->LoadDataOut(mMemInfor);
    vdcuBlock->push_back(std::move(mauBlock));

    return true;
}

/**
* @brief   Output the code, write it into output file
*/
bool CDcuManager::OutputResult(std::vector <std::unique_ptr<CDcuBlock>>* vdcuBlock) {

    std::string filename = m_config->GetOutputFileName();

    std::ofstream	ofs(filename.c_str(), (std::ios::out | std::ios::trunc));
    if (!ofs) {
        return false;
    }
    const std::string StartUp = "::START_UP_CODE";
    const std::string EndCode = "::END_CODE";
    //! Initialize variable that store data
    PrintSelfDefinitionData(ofs);
    //! 1. Print user code setting for startup program
    this->PrintUserCode(ofs, StartUp);
    //! 2. Print MAU random block
    for (UI32 i = 0; i < vdcuBlock->size(); i++) {
        ofs << "\n\n//====================== " << (*vdcuBlock)[i]->GetBlockName() << " ============================\n\n";
        (*vdcuBlock)[i]->Print(ofs);
    }

    //! 1. Print user code setting for end of program
    this->PrintUserCode(ofs, EndCode);

    ofs.close();
    return true;

}

/**
* @brief  Init MAU memory
*/
bool CDcuManager::ParseDcuInfor(const std::string& section) {
    SectionData data = m_config->GetSectionData(section);
    std::map<std::string, UI32> section_key = { {"::MAU_REQUEST", 0}, {"::MEMORY_CONFIGURATION", 1} };

    switch (section_key[section]) {
        case 0:     // ::MAU_REQUEST
        {
            UI32 weight = 0, min = 0, max = 0;
            std::string access_type;
            for (UI32 row = 0; row < data.size(); row++) {
                //Convert input string to suitable data
                access_type = data[row][0];
                weight = AtoI(data[row][1].c_str());
                if (data[row].size() == 4) {
                    min = AtoI(data[row][2].c_str());
                    max = AtoI(data[row][3].c_str());
                } else {
                    min = 0; max = 0;
                }

                if (m_accessMem.SetJtagInfor(access_type, weight, min, max) == false) {
                    MSG_ERROR(0, "\nData  JtagSet MAU not true\n");
                    return false;
                }
            }
        }
            break;
        case 1:    // ::MEMORY_CONFIGURATION
        {
            MEMADDR StartAddress = 0, EndAddress = 0, weight = 0;
            std::string attribute, resource;
            for (UI32 row = 0; row < data.size(); row++) {
                //Convert input string to suitable data
                StartAddress = AtoI(data[row][0].c_str());
                EndAddress = AtoI(data[row][1].c_str());
                attribute = data[row][2];
                resource = data[row][3];
                weight = AtoI(data[row][4].c_str());

                if (m_memory->SetMem(StartAddress, EndAddress, attribute, resource, weight) == false) {
                    MSG_ERROR(0, "\nFail to set memory: StartAddress = %x, EndAddress = %x, attribute = %s, resource = %s, weight = %d\n", StartAddress, EndAddress, attribute.c_str(), resource.c_str(), weight);
                    return false;
                }
            }
        }
            break;

        default:
            break;
    }

    return true;
}

/**
* @brief  Generate 1 block Jtag
*/
std::unique_ptr<CDcuBlock> CDcuManager::GenerateJtagBlock(UI32 N) {

	std::string label;
	std::stringstream ss;
	ss << "DCU_codeblock_" << std::dec << std::setw(2) << std::setfill('0') << N;
	ss >> label;
	std::unique_ptr<CDcuBlock> dcuBlock = std::make_unique<CDcuBlock>();
	dcuBlock->SetBlockName(label);
	UI32 JtagNum = m_config->GetJtagNum();
	UI32 CPUBlockNum = m_config->GetCPUBlockNum() - 1;
	if (CPUBlockNum >= N){
		GenerateHandshakeSequence(dcuBlock);	
	}
	for (UI32 i = 0; i < JtagNum; i++)	{
        std::unique_ptr<IJtag>  JtagTemp = m_accessMem.CreateJtagCommand();

        // Simulate Jtag
       if(JtagTemp->RegulateJtagCommand() == false ) continue;
		
		// Generate Jtag
        dcuBlock->AddJtag(JtagTemp);
	}
	return dcuBlock;
}

/**
* @brief  Generate all block Jtag, Jtag command in each block, handshake
*/
bool CDcuManager::PrintUserCode(std::ofstream& ofs, std::string key) {
	// Print user code to output file
    ofs << "\n//! User code area !//\n";
    CsvRow data = m_config->GetDcuUsercode(key);
    CsvRow::iterator itr;
    for (itr = data.begin(); itr != data.end(); ++itr) {
        ofs << (*itr) << "\n";
    }
    ofs << "\n//! End user code area !//\n";
    return true;
}

/**
* @brief  Export variable and data that necessary to support execute DCU
*/
void CDcuManager::PrintSelfDefinitionData(std::ofstream& ofs) {
    ofs << "\nreg	[31:0]	_D_	[0:16383] ;		// Transfer Data (Word) \n";
}

/**
 * @brief  Generate handshake code at begin of random block for DCU and CPU
 * 
 */
void CDcuManager::GenerateHandshakeSequence(std::unique_ptr<CDcuBlock>& dcuBlock) {
	
	// Must init MBIN = 0, MBOUT = 0
	// DCU write m_MBIN = 1 and wait m_MBOUT = 1
	// Handshake when starting random code
	// Handshake for each block
    UI32 DBG_MAP_PE = GetPeId() + 1;
    UI32 mbInVal = 0, mbOutVal = 0;
    std::unique_ptr<IJtag>      pWrMBIN;
    std::unique_ptr<IJtag>      pPollMBOUT;
    // Handshake for each block
    if (m_mHandShakeRecord.size() == 0) {
        mbInVal = 1;
        mbOutVal = 1;
    } else {
        mbInVal = !m_mHandShakeRecord.back().first;
        mbOutVal = !m_mHandShakeRecord.back().second;
    }

    pWrMBIN = WR(1, DBG_MAP_PE, 0/*bank0*/, 0x1C/*dbgmbin*/, mbInVal);
    pPollMBOUT = POLL(1, DBG_MAP_PE, 0/*bank0*/, 0x1B/*dbgmbout*/, mbOutVal);
    pWrMBIN->AppendComment("// Handshake_code_before_start_next_block");
    pPollMBOUT->AppendComment("// Handshake_code_before_start_next_block");
    m_mHandShakeRecord.push_back(std::make_pair(mbInVal, mbOutVal));
    dcuBlock->AddJtag(pPollMBOUT);
    dcuBlock->AddJtag(pWrMBIN);
}

/**
 * @brief  Generate handshake code at begin of selfcheck block for DCU-MAU and CPU
 * 
 */
void CDcuManager::GenerateFinalHandshakeSequence(std::unique_ptr<CMauBlock>& mauBlock) {
	
    UI32 DBG_MAP_PE = GetPeId() + 1;
    UI32 mbInVal = 0xFACEDADD, mbOutVal = 0xFACEDADD;
    std::unique_ptr<IJtag>      pWrMBIN = WR(1, DBG_MAP_PE, 0/*bank0*/, 0x1C/*dbgmbin*/, mbInVal);
    std::unique_ptr<IJtag>      pPollMBOUT = POLL(1, DBG_MAP_PE, 0/*bank0*/, 0x1B/*dbgmbout*/, mbOutVal);
    pWrMBIN->AppendComment("// Handshake_code_before_start_self_check_code");
    pPollMBOUT->AppendComment("// Handshake_code_before_start_self_check_code");
    m_mHandShakeRecord.push_back(std::make_pair(mbInVal, mbOutVal));
    mauBlock->AddJtag(pPollMBOUT);
    mauBlock->AddJtag(pWrMBIN);
}

/**
* @brief  Get Self Check Memory Range
* @return  Self Check Memory Range
*/
std::map<MEMADDR, UI32>  CDcuManager::GetSelfCheckMemRange() {
    CDcuMemory::T_RECORDMEM::iterator itr;
    CDcuMemory::T_RECORDMEM MemInfor = this->m_memory->GetExecutedMem();
    std::map<MEMADDR, UI32> memRange;

    for (itr = MemInfor.begin(); itr != MemInfor.end(); itr++) {
        UI32 addr = itr->first;
        UI32 size = std::get<0>(itr->second);
        UI32 cnt = std::get<1>(itr->second);

        for (UI32 i = 0; i < cnt; i++) {
            memRange.insert(std::make_pair(addr, size));
            addr += size;
        }
    }

    return memRange;
}

