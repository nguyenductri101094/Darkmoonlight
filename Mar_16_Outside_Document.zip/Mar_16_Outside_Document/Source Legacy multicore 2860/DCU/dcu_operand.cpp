#include    "dcu_operand.h"

//========================= IDcuOperand =============================//


CMersenneTwister*   IDcuOperand::m_pRandom = nullptr;
/**
* @brief Setting tool support random
* @param random object manage random tool
*/
void IDcuOperand::SetRandomToolPointer(CMersenneTwister* random) {
    if (m_pRandom == nullptr) {
        m_pRandom = random;
    }
}

//========================= COprRdy =============================//

/**
* @brief random value for operand
* @return the pointer of operand
*/
IDcuOperand* COprRdy::SelectValue() {
    if (m_bIsRandom) {
        if (m_constraint) {
            m_rdy = m_constraint->SelectValue();
        } else {
            m_rdy = m_pRandom->GetRange(0U, 1U);
        }
    }

    return this;
}

/**
* @brief Convert operands to assembler code.
* @return Operand string
*/
std::string COprRdy::GetCode() const {
    return std::to_string(m_rdy);
}


//========================= COprReg =============================//

//CRegisterSet*        COprReg::m_RegSet = nullptr;
//
///**
//* @brief Setting set of register support random
//* @param object of CRegisterSet
//*/
//void COprReg::SetRegSet(CRegisterSet* reg_set) {
//    if (m_RegSet == nullptr) {
//        m_RegSet = reg_set;
//    }
//}

/**
* @brief get id of register
* @return id of register
*/
UI32 COprReg::GetValue() const {
    return ((m_map << 11) + (m_bank << 8) + m_ir);
}

/**
* @brief cast the operand to UI32
* @return ID of Register
*/
COprReg::operator UI32() {
    return ((m_map << 11) + (m_bank << 8) + m_ir);
}

/**
* @brief random value for operand
* @return the pointer of operand
*/
IDcuOperand* COprReg::SelectValue() {
    if (m_bIsRandom) {
        UI32 reg = m_RegSet->SelectValue();
        m_map  = (reg >> 11) & 0x7;
        m_bank = (reg >> 8) & 0x7;
        m_ir   = reg & 0xFF;
    }

    return this;
}

/**
* @brief Convert operands to assembler code.
* @return Operand string
*/
std::string COprReg::GetCode() const {
    std::stringstream ss;
    std::string reg_name = m_RegSet->GetRegName(this->GetValue());

    ss << "map"  << m_map  << ", ";
    ss << "bank" << m_bank << ", ";
    if (reg_name != "") {
        ss << reg_name;
    } else {
        ss << std::hex << "8'h" << m_ir;
    }

    return ss.str();
}

/**
* @brief regulate operand to valid value
* @return true if regulate successful
*/
bool COprReg::RegulateOperand() {
    return true;
}

//========================= COprData =============================//

/**
* @brief random value for operand
* @return the pointer of operand
*/
IDcuOperand* COprData::SelectValue() {
    if (m_bIsRandom) {
        if (m_constraint) {
            m_data = m_constraint->SelectValue();
        } else {
            m_data = m_pRandom->Get();
        }
    }

    return this;
}

/**
* @brief Convert operands to assembler code.
* @return Operand string
*/
std::string COprData::GetCode() const {

    if (m_data_size == 1) {
        return std::to_string(m_data);
    } else {
        std::stringstream ss;
        ss << std::dec << m_data_size << "'h" << std::hex << m_data;
        return ss.str();
    }
}


//========================= COprStrData =============================//

/**
* @brief Convert operands to assembler code.
* @return Operand string
*/
std::string COprStrData::GetCode() const {
    return m_data;
}


//========================= COprBit =============================//

/**
* @brief random value for operand
* @return the pointer of operand
*/
IDcuOperand* COprBit::SelectValue() {
    if (m_bIsRandom) {
        if (m_constraint) {
            m_bit = m_constraint->SelectValue();
        } else {
            m_bit = m_pRandom->GetRange(0U, 31U);
        }
    }

    return this;
}

/**
* @brief Convert operands to assembler code.
* @return Operand string
*/
std::string COprBit::GetCode() const {
    std::stringstream ss;
    ss << "5'h" << std::hex << m_bit;

    return ss.str();
}


//========================= COprKey =============================//

/**
* @brief random value for operand
* @return the pointer of operand
*/
IDcuOperand* COprKey::SelectValue() {
    if (m_bIsRandom) {
        if (m_constraint) {
            m_key = m_constraint->SelectValue();
        } else {
            m_key = m_pRandom->GetRange(0U, 0xFU);
        }
    }

    return this;
}

/**
* @brief Convert operands to assembler code.
* @return Operand string
*/
std::string COprKey::GetCode() const {
    return std::to_string(m_key);
}
