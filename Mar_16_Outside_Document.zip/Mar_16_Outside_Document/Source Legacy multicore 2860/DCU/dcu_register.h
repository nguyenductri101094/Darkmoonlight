#ifndef DCU_REGISTER_H_
#define DCU_REGISTER_H_


#include    "rnd_gen.h"

/*===============================================
@brief: Class define register in DCU module
===============================================*/
class CDcuRegister {

public:

    CDcuRegister() {}

    CDcuRegister(std::string name, UI32 map, UI32 bank, UI32 ir):
        m_name(name),
        m_map(map),
        m_bank(bank),
        m_ir(ir) {}

    ~CDcuRegister() {}

    /**
    * @brief  Get name of register
    * @return name of register
    */
    std::string GetName() const { return m_name; }

    /**
    * @brief  Get ID of register
    * @return ID of register
    */
    UI32 GetId() const { return ((m_map << 11) + (m_bank << 8) + m_ir); }

    /**
    * @brief  Get MAP of register
    * @return MAP of register
    */
    UI32 GetMap() const { return m_map; }

    /**
    * @brief  Get BANK of register
    * @return BANK of register
    */
    UI32 GetBank() const { return m_bank; }

    /**
    * @brief  Get IR of register
    * @return IR of register
    */
    UI32 GetIR() const { return m_ir; }


private:
    std::string     m_name;         //! name of register
    UI32            m_map;          //! Map number(0-7) of IR register defined by DUT spec
    UI32            m_bank;         //! Bank number(0-7) of IR register defined by DUT spec
    UI32            m_ir;           //! Number(8-bit) of IR register define by DUT spec
};


/*===============================================
@brief: Class store aLL register in DCU module
===============================================*/
class CDcuRegisterSet {

public:
    CDcuRegisterSet(): m_RegWeight(&g_rnd) {
        this->InitRegisterList();
    }

    ~CDcuRegisterSet() {}

    /**
    * @brief Initialize list of register
    */
    void InitRegisterList();

    /**
    * @brief Get register name base on map, bank and ir
    * @param map: MAP of register
    * @param bank: BANK of register
    * @param ir: IR code of register
    */
    std::string GetRegName(UI32 map, UI32 bank, UI32 ir);

    /**
    * @brief Get register name base on ID
    * @param id: ID of register
    */
    std::string GetRegName(UI32 id);

    /**
    * @brief random register
    * @return the value after random
    */
    UI32 SelectValue();

private:
    static std::vector<std::pair<std::string, std::vector<UI32>>>      m_vReg;          //! list store all register in DCU module
    std::map<UI32, std::unique_ptr<CDcuRegister>>                         m_mRegSet;       //! lisT manage all register in DCU module
    CWeightedRandom<UI32>                                              m_RegWeight;     //! support random Reg base on ID

};


#endif /* REGISTER_H_*/
