﻿#ifndef CDCU_MEMORY_H
#define CDCU_MEMORY_H

#include    "rnd_gen.h"


class CDcuMemory {

public:
    typedef enum {
        MAU_BUS_AXI = 0,
        MAU_BUS_GVCI = 0,
        MAU_BUS_KVCI = 0,
        MAU_BUS_eLB = 1,
        MAU_BUS_NT = 3,
        MAU_BUS_END = 4
    } MAU_BUS_RESOURCE;

    typedef     std::map<MEMADDR, std::tuple<UI32, UI32, MAU_BUS_RESOURCE>>  T_RECORDMEM; // (Addr, <size, count, bus>)

public:
    /**
    * @brief Construct this object
    */
    CDcuMemory();

    /**
    * @brief  Destroy this object
    */
    ~CDcuMemory();

    /**
    * @brief  Push all memory range
    * @param  startAddr Start mem address
    * @param  endAddr End mem address
    * @param  attribute Read/Write/Read&Write
    * @param  resource Memory bus
    * @param  ratio Ratio of accessing into this memory area
    * @return Return TRUE if memory is set successfully, otherwise return FALSE
    */
    bool SetMem(MEMADDR startAddr, MEMADDR endAddr, std::string attribute, std::string resource, UI32 weight);

    /**
    * @brief  Method to get a range of memory
    * @param  size Memory size needed
    * @param  attribute Memory's attribute needed: 0 == Read; 1 == Write
    * @return Return the suitable memory area (Start address of memory and bus of the memory)
    */
    std::pair<MEMADDR, MAU_BUS_RESOURCE> SelectAddressRange(const UI32& attribute, UI32 size, UI32 counter);

    /**
    * @brief  Record memory to list of executed memory
    * @param  startAddr Start address of memory need to record
    * @param  size Size of each address
    * @param  counter Number of loop
    * @param  bus Bus of the memmory which is recorded
    * @return Record the executed memory
    */
    void RecordExecutedMem(MEMADDR startAddress, UI32 size, UI32 counter, MAU_BUS_RESOURCE bus);

    /**
    * @brief  Inform user the resource of input memory range
    * @param  mr Range of memory that is needed to check
    * @return Return resource of a memory range
    */
    MAU_BUS_RESOURCE GetResource(MEMADDR mr);

    /**
    * @brief  Convert resource from string to bitset
    * @param  resource: input "string" resource
    * @param  bus: output "enum" resource (= bus)
    * @return Return TRUE if resource is converted successfully, otherwise return FALSE
    */
    bool ResourceToBitset(const std::string& resource, MAU_BUS_RESOURCE* bus);

    /**
    * @brief  Inform user all memory which were executed
    * @param  None
    * @return Map of Start address and size of executed memory
    */
    T_RECORDMEM GetExecutedMem();

    /**
    * @brief  Show all content of Memory for debugging
    * @param  None
    * @return Return the memory ranges, resources of Readable Mem and Writable Mem
    */
    void DumpMemory();

private:
    
    CWeightedRandom <MEMRANGE>       m_wrReadableMem;
    CWeightedRandom <MEMRANGE>       m_wrWritableMem;
    std::map<MEMRANGE, MAU_BUS_RESOURCE>         m_mResource;
    T_RECORDMEM       m_ExecutedMem; // Contain all memory were executed: (StartAddress, <size, counter, bus>)
};


#endif // CDcuMemory_H

