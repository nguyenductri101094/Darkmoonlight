#ifndef DCU_OPERAND_H_
#define DCU_OPERAND_H_


#include    "dcu_register.h"
#include    "rnd_gen.h"
#include    "dcu_valconstraint.h"


/*===============================================
@brief: Abstract class of all operand of JTAG
===============================================*/
class IDcuOperand {

public:

    typedef enum {
        OPR_ATTR_RDY,
        OPR_ATTR_REG,
        OPR_ATTR_BIT,
        OPR_ATTR_DATA,
        OPR_ATTR_SDATA,
        OPR_ATTR_KEY,
        OPR_ATTR_NUM
    } OPR_ATTR; 

    IDcuOperand(): m_attr(OPR_ATTR_NUM), m_bIsRandom(true), m_constraint(nullptr) {}

    IDcuOperand(OPR_ATTR attr): m_attr(attr), m_bIsRandom(true), m_constraint(nullptr) {}

    IDcuOperand(OPR_ATTR attr, bool isRandom): m_attr(attr), m_bIsRandom(isRandom), m_constraint(nullptr) {}

    ~IDcuOperand() {}

    /**
    * @brief Setting tool support random
    * @param random object manage random tool
    */
    static void SetRandomToolPointer(CMersenneTwister* random);

    /**
    * @brief get value of current operand
    * @return value of current operand
    */
    virtual UI32 GetValue() { return 0; }

    /**
    * @brief get attribute of operand
    */
    virtual OPR_ATTR GetAttribute() { return m_attr; }

    /**
    * @brief Setting constraint for operand
    * @param constraint of operand
    */
    virtual void SetConstraint(std::unique_ptr<CDcuValConstraint> &constraint) { m_constraint = std::move(constraint);}

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    virtual IDcuOperand* SelectValue() = 0;

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    virtual std::string GetCode() const = 0;

    /**
    * @brief regulate operand to valid value
    * @return true if regulate successful
    */
    virtual bool RegulateOperand() { return true; }

protected:
    OPR_ATTR                                m_attr;         //! attribute of operand
    bool                                    m_bIsRandom;    //! determine whether random value or not: True it mean random
    static CMersenneTwister*                m_pRandom;      //! manage random class
    std::unique_ptr<CDcuValConstraint>      m_constraint;    //! constraint of each operand

};


/*===============================================
@brief: Class define operand register
===============================================*/
class COprRdy: public IDcuOperand {

public:
    COprRdy(): IDcuOperand(OPR_ATTR_RDY), m_rdy(0) {}

    COprRdy(bool value): IDcuOperand(OPR_ATTR_RDY, false), m_rdy(value) {}

    ~COprRdy() {}

    /**
    * @brief value of bit RDY
    * @return RDY value
    */
    UI32 GetValue() const { return m_rdy; }

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    IDcuOperand* SelectValue();

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    std::string GetCode() const;

private:
    bool        m_rdy;       //! 1: Do after falling edges of RDYZ 0: Do immediately

};


/*===============================================
@brief: Class define operand register
===============================================*/
class COprReg: public IDcuOperand {

public:
    COprReg(): IDcuOperand(OPR_ATTR_REG), m_map(0), m_bank(0), m_ir(0) {
        m_RegSet = std::make_unique<CDcuRegisterSet>();
    }

    COprReg(UI32 map, UI32 bank, UI32 ir): 
            IDcuOperand(OPR_ATTR_REG, false), 
            m_map(map), 
            m_bank(bank), 
            m_ir(ir) {
        m_RegSet = std::make_unique<CDcuRegisterSet>();
    }

    ~COprReg() {}

    /**
    * @brief Setting set of register support random
    * @param object of CDcuRegisterSet
    */
    //static void SetRegSet(CDcuRegisterSet* reg_set);

    /**
    * @brief get id of register
    * @return id of register
    */
    UI32 GetValue() const;

    /**
    * @brief cast the operand to UI32
    * @return ID of Register
    */
    operator UI32();

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    IDcuOperand* SelectValue();

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    std::string GetCode() const;

    /**
    * @brief  Get MAP of register
    * @return MAP of register
    */
    UI32 GetMap() const { return m_map; }

    /**
    * @brief  Get BANK of register
    * @return BANK of register
    */
    UI32 GetBank() const { return m_bank; }

    /**
    * @brief  Get IR of register
    * @return IR of register
    */
    UI32 GetIR() const { return m_ir; }

    /**
    * @brief regulate operand to valid value
    * @return true if regulate successful
    */
    bool RegulateOperand();

private:
    UI32                                 m_map;            //! Map number(0-7) of IR register defined by DUT spec
    UI32                                 m_bank;           //! Bank number(0-7) of IR register defined by DUT spec
    UI32                                 m_ir;             //! Number(8-bit) of IR register define by DUT spec
    std::unique_ptr<CDcuRegisterSet>        m_RegSet;         //! Set of register to support random    

};


/*===============================================
@brief: Class define operand data
===============================================*/
class COprData: public IDcuOperand {

public:
    COprData(UI32 size): IDcuOperand(OPR_ATTR_DATA), m_data(0), m_data_size(size) {}

    COprData(UI32 value, UI32 size): IDcuOperand(OPR_ATTR_DATA, false), m_data(value), m_data_size(size) {}

    ~COprData() {}

    /**
    * @brief get write data vaule
    * @return write data vaule
    */
    UI32 GetValue() const { return m_data; }

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    IDcuOperand* SelectValue();

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    std::string GetCode() const;

private:
    UI32        m_data;         //! value is wrote to destination 
    UI32        m_data_size;    //! size of data. unit: bit
};


/*===============================================
@brief: Class define operand string data
===============================================*/
class COprStrData: public IDcuOperand {

public:
    COprStrData(): IDcuOperand(OPR_ATTR_SDATA), m_data("") {}

    COprStrData(std::string value): IDcuOperand(OPR_ATTR_SDATA, false), m_data(value) {}

    ~COprStrData() {}

    /**
    * @brief set data for operand
    * @param data of operand
    */
    void SetData(std::string data) { m_data = data; }

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    virtual IDcuOperand* SelectValue() { return this; }

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    std::string GetCode() const;

private:
    std::string        m_data;         //! value is wrote to destination 
};


/*===============================================
@brief: Class define operand Ascending digit position
===============================================*/
class COprBit: public IDcuOperand {

public:
    COprBit(): IDcuOperand(OPR_ATTR_BIT), m_bit(0) {}

    COprBit(UI32 pos): IDcuOperand(OPR_ATTR_BIT, false), m_bit(pos) {}

    ~COprBit() {}

    /**
    * @brief value of bit RDY
    * @return RDY value
    */
    UI32 GetValue() const { return m_bit; }

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    IDcuOperand* SelectValue();

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    std::string GetCode() const;


private:
    UI32        m_bit;       //! bit position
};


/*===============================================
@brief: Class define operand Authentication code
===============================================*/
class COprKey: public IDcuOperand {

public:
    COprKey(): IDcuOperand(OPR_ATTR_KEY), m_key(0) {}

    COprKey(bool value): IDcuOperand(OPR_ATTR_KEY, false), m_key(value) {}

    ~COprKey() {}

    /**
    * @brief value of bit RDY
    * @return RDY value
    */
    UI32 GetValue() const { return m_key; }

    /**
    * @brief random value for operand
    * @return the pointer of operand
    */
    IDcuOperand* SelectValue();

    /**
    * @brief Convert operands to assembler code.
    * @return Operand string
    */
    std::string GetCode() const;

private:
    UI32        m_key;       //! Authentication code
};

#endif /* OPERAND_H_*/