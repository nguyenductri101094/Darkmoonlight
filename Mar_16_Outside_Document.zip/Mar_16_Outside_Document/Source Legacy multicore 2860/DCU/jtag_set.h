﻿#ifndef CJTAG_SET_H
#define CJTAG_SET_H

#include        "rnd_gen.h"
#include        "jtag.h"

class CJtagSet {

public:
    CJtagSet(): m_JtagWeight(&g_rnd) {}

    ~CJtagSet() {}

    /**
    * @brief Set access memory type and corresponding weight
    * @param access_type: type of access memory
    * @param weight_value: corresponding weight
    * @param cnt_min: minimum cnt
    * @param cnt_max: maximum cnt
    * @return true if setting is successful
    */
    bool SetJtagInfor(std::string access_type, UI32 weight_value, UI32 cnt_min, UI32 cnt_max);

    /**
    * @brief Random access memory type and create JTAG command base on that
    * @return JTAG command
    */
    std::unique_ptr<IJtag> CreateJtagCommand();

    /**
    * @brief create JTAG command based on access memory type
    * @param access_id: ID of access memory type
    * @return JTAG command
    */
    std::unique_ptr<IJtag> CreateJtagCommand(IJtag::JTAG_ID access_id);

private:
    CWeightedRandom<IJtag::JTAG_ID>                 m_JtagWeight;       //! support random Jtag base on ID
    static std::map<std::string, IJtag::JTAG_ID>    m_mJtagSet;         //! name and ID of Jtag
    std::map<IJtag::JTAG_ID, std::pair<UI32, UI32>> m_mJtagCntRange;    //! Range to random value of cnt for MAU type A

};

#endif // CACCESS_MEMORY_SET_H


