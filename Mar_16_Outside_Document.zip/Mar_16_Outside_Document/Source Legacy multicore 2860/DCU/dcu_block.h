﻿#ifndef CDCU_BLOCK_H
#define CDCU_BLOCK_H

#include    "ijtag.h"
#include    "rtg_common.h"
#include    "rtg_types.h"
#include    "dcu_memory.h"

class CDcuBlock {

public:

	/**
     * @ brief contructor of CDcuBlock object
     * @ param 
     * @ return
     */
    CDcuBlock();
	/**
     * @ brief contructor of CDcuBlock object
     * @ param name: The name of DcuBlock, default is null 
     * @ return
     */
    CDcuBlock(std::string name);

	/**
     * @ brief Delete CDcuBlock object
     * @ param 
     * @ return
     */
    ~CDcuBlock();

	/**
     * @ brief Append new Jtag into vector Jtag of DcuBlock
     * @ param pJtag point to new Jtag
     * @ return 
     */
    void AddJtag(std::unique_ptr<IJtag>& pJtag);

	/**
     * @ brief Insert new Jtag at position
     * @ param pJtag point to new Jtag
	 * @ param pos is the position of new Jtag
     * @ return True:  Insert success
	            False: Insert fail
     */
    bool InsertJtag(std::unique_ptr<IJtag> pJtag, UI32 pos);

	/**
     * @ brief Get total number of Jtag in block
     * @ param 
     * @ return Jtag num
     */
    UI32 GetJtagNum() const;

	/**
     * @ brief Get the name of DcuBlock
     * @ param 
     * @ return the name
     */
    std::string GetBlockName() const;

	/**
	 * @brief  set block name
	 * @param  Name
	 * @return None
	 * 
	 */
    void SetBlockName(std::string name);

	/**
     * @ brief Get position of Jtag
     * @ param pJtag point to Jtag that need to get position
     * @ return position
     */
    UI32 GetIndex(std::unique_ptr<IJtag> pJtag);

	/**
     * @ brief Get position of Jtag
     * @ param pJtag point to Jtag that need to get position
     * @ return position
     */
    UI32 GetIndex(IJtag* pJtag);

	/**
     * @ brief Get Jtag at position
     * @ param pos is the position of Jtag
     * @ return std::unique_ptr Jtag 
     */
	IJtag* at(UI32 pos);

	/**
     * @ brief Replace old Jtag by new Jtag
     * @ param before is old Jtag
	 * @ param after is new Jtag
     * @ return
     */
    void ReplaceJtag(std::unique_ptr<IJtag> before, std::unique_ptr<IJtag> after);

	/**
     * @ brief Delete Jtag out of DcuBlock
     * @ param pJtag point to Jtag need to remove
     * @ return True:  Remove success
	            False: Remove fail
     */
    bool RemoveJtag(std::unique_ptr<IJtag> pJtag);

	/**
     * @ brief Delete Jtag out of DcuBlock
     * @ param pJtag point to Jtag need to remove
     * @ return True:  Remove success
	            False: Remove fail
     */
    bool EraseJtag(std::unique_ptr<IJtag> pJtag);

	/**
     * @ brief Show the content of DcuBlock
     * @ param 
     * @ return
     */
    void Dump();

	/**
	 * @brief  Generate code in type A and type B to read memory for final comparision
	 * @param  
	 * @return CDcuBlock content JTAG read memory
	 * 
	 */	
    virtual void LoadDataOut(CDcuMemory::T_RECORDMEM mMemInfor);

	/**
	 * @brief  Expand sub Jtag inside sequence
	 * @param  
	 * @return CDcuBlock content random code
	 * 
	 */
    virtual void ExpandJtagBlock();

	/**
	 * @brief  print final code into output file
	 * @param  
	 * @return CDcuBlock content handshake code
	 * 
	 */
	virtual void Print(std::ostream& ofs);

protected:
    std::string m_name;                             //! Content the name of DcuBlock
    std::vector<std::unique_ptr<IJtag>> m_vJtag;    //! Content the Jtag in DcuBlock

};

#endif // !CDCU_BLOCK_H



