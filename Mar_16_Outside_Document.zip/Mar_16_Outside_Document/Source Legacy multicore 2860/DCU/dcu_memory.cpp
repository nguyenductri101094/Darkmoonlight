﻿#include "dcu_memory.h"

CDcuMemory::CDcuMemory() : m_wrReadableMem(&g_rnd), m_wrWritableMem(&g_rnd), m_mResource(), m_ExecutedMem() {

}

CDcuMemory::~CDcuMemory() {

}

/**
* @brief  Push all memory range
*/
bool CDcuMemory::SetMem(MEMADDR startAddr, MEMADDR endAddr, std::string attribute, std::string resource, UI32 weight) {
    MAU_BUS_RESOURCE bus = MAU_BUS_END;
    if (ResourceToBitset(resource, &bus) == false) return false;

    if (attribute == "R" || attribute == "R/W") {
        m_wrReadableMem.Set(MEMRANGE(startAddr, endAddr), weight);
    }
    if (attribute == "W" || attribute == "R/W") {
        m_wrWritableMem.Set(MEMRANGE(startAddr, endAddr), weight);
    }

    if (m_mResource.insert(std::make_pair(MEMRANGE(startAddr, endAddr), bus)).second == false) return false;

    return true;
}
/**
* @brief  Method to get a range of memory
*/
std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> CDcuMemory::SelectAddressRange(const UI32& attribute, UI32 size, UI32 counter) {
    MEMADDR startAddress = 0;
    MAU_BUS_RESOURCE bus = MAU_BUS_END;
    MEMRANGE selectedRange;
    CWeightedRandom <MEMRANGE>  copyOfMem(&g_rnd);

    if (attribute == 0) { // 0 == Read attribute
        copyOfMem = m_wrReadableMem;
    } else if (attribute == 1) { // 1 == Write attribute
        copyOfMem = m_wrWritableMem;
    }

    std::set<MEMRANGE> s = copyOfMem.KeySet();
    std::set<MEMRANGE>::iterator itr;

    //Browse the memory and select suitable memory ranges
    for (itr = s.begin(); itr != s.end(); ++itr) {
        MEMRANGE memReflectToResource = MEMRANGE(itr->first, itr->second);
        bus = m_mResource.at(memReflectToResource);
        bool IsAXIResource = false;
        if (bus == MAU_BUS_AXI) IsAXIResource = true;

        if (((itr->second - itr->first) < (size * counter - 1))
            || ((size == 8) && (IsAXIResource == false))
            || ((size == 16) && (IsAXIResource == true))) {
            copyOfMem.Delete(*itr);
        }
    }
    copyOfMem.ReCalc();

    //Select the memory randomly
    if (copyOfMem.Count()){
        selectedRange = copyOfMem.GetObj();
        startAddress = g_rnd.GetRange(selectedRange.first, (selectedRange.second - size * counter + 1));
    } else {
        MSG_WARN(0, "Can not find suitable memory for:\nAttribute: %d (0 = Read; 1 = Write) - Size: %d - Counter: %d\n", attribute, size, counter);
        return std::pair<MEMADDR, MAU_BUS_RESOURCE>(startAddress, MAU_BUS_END);
    }

    if (m_mResource.find(selectedRange) != m_mResource.end()) {
        bus = m_mResource.at(selectedRange);
    }

    //Align MemAddress before return      
    switch (size) {
    case 1:
        break;
    case 2:
        startAddress &= 0xFFFFFFFE;
        break;
    case 4:
    case 16: // Type B: 32 bytes * 4
        startAddress &= 0xFFFFFFFC;
        break;
    case 8:
        startAddress &= 0xFFFFFFF8;
        break;
    default:
        break;
    }

    //Store MemRange to map for verification
    RecordExecutedMem(startAddress, size, counter, bus);
    return std::pair<MEMADDR, MAU_BUS_RESOURCE>(startAddress, bus);
}

/**
* @brief  Record memory to list of executed memory
*/
void CDcuMemory::RecordExecutedMem(MEMADDR startAddress, UI32 size, UI32 counter, MAU_BUS_RESOURCE bus) {

    auto CorrectCounter = [=](MEMADDR startAddr, MEMADDR endAddr, UI32 sizeMem, MAU_BUS_RESOURCE bus) -> void {
        if (startAddr == endAddr) {
            m_ExecutedMem[startAddr] = std::make_tuple(1, 1, bus);
            return;
        }
        MEMADDR aligned_startaddr = 0;
        switch (sizeMem) {
            case 1:
                break;
            case 2:
                aligned_startaddr = (startAddr + 1) & 0xFFFFFFFE;
                break;
            case 4:
            case 16: // Type B: 32 bytes * 4
                aligned_startaddr = (startAddr + 3) & 0xFFFFFFFC;
                break;
            case 8:
                aligned_startaddr = (startAddr + 7) & 0xFFFFFFF8;
                break;
            default:
                break;
        }

        if (aligned_startaddr > startAddr) {
            if (aligned_startaddr < endAddr) {
                MEMADDR extraMem = aligned_startaddr - startAddr;
                m_ExecutedMem[startAddr] = std::make_tuple(1, (UI32)extraMem, bus);
                if (extraMem > 7) {
                    MSG_ERROR(0, "Extra memory is not in range 1");
                    std::runtime_error excep("MAU memory issue\n ");
                    throw excep;
                }
                startAddr = aligned_startaddr;
            } else {
                MEMADDR extraMem = endAddr - startAddr + 1;
                m_ExecutedMem[startAddr] = std::make_tuple(1, (UI32)extraMem, bus);
                return;
            }
        } 

        UI32 newCount = (endAddr - startAddr + 1) / sizeMem;
        MEMADDR newMemExtra = (endAddr - startAddr + 1) % sizeMem;
        if (newCount > 0) {
            m_ExecutedMem[startAddr] = std::make_tuple(sizeMem, newCount, bus);
        }
        switch (newMemExtra) {
        case 0:
            return;
        case 1 ... 7:
            m_ExecutedMem[startAddr + newCount * sizeMem] = std::make_tuple(1, (UI32)newMemExtra, bus);
            break;
        default:
            MSG_ERROR(0, "Extra memory is not in range 2");
            std::runtime_error excep("MAU memory issue\n ");
            throw excep;
            break;        
        }
        return;
    };

    MEMADDR endAddress = startAddress + size * counter - 1;
    T_RECORDMEM::iterator itrMem;
    MEMADDR ExecutedStart = 0, ExecutedEnd = 0;
    // Type B: 32 bits * 4 
    if (size == 16) {
        size = 4;
        counter = 4;
    }

    // Check if new memory range is already in list of executed memory yet
    for (itrMem = m_ExecutedMem.begin(); itrMem != m_ExecutedMem.end(); ++itrMem) {
        ExecutedStart = itrMem->first;
        std::tuple<UI32, UI32, MAU_BUS_RESOURCE> valueMap = itrMem->second;
        UI32 sizeTuple = std::get<0>(valueMap);
        UI32 cntTuple = std::get<1>(valueMap);
        ExecutedEnd = itrMem->first + sizeTuple * cntTuple - 1;
        // New memory is already recorded
        if (startAddress >= ExecutedStart && endAddress <= ExecutedEnd) {
            return;
        }
        // A part of new memory is apart of executed memory
        else if (!(startAddress > ExecutedEnd || endAddress < ExecutedStart)) {
            break;
        }
    }

    // If new memory range is overlapped the old ones 
    if (itrMem != m_ExecutedMem.end()) {
        while (itrMem != m_ExecutedMem.end()) {
            ExecutedStart = itrMem->first;
            std::tuple<UI32, UI32, MAU_BUS_RESOURCE> valueMap = itrMem->second;
            UI32 sizeTuple = std::get<0>(valueMap);
            UI32 cntTuple = std::get<1>(valueMap);
            ExecutedEnd = itrMem->first + sizeTuple * cntTuple - 1;

            if (startAddress > ExecutedStart && startAddress <= ExecutedEnd) {
                startAddress = ExecutedEnd + 1;
                ++itrMem;
            } else if (startAddress <= ExecutedStart && endAddress >= ExecutedEnd) {
                itrMem = m_ExecutedMem.erase(itrMem);
            } else if (endAddress >= ExecutedStart && endAddress <= ExecutedEnd) {
                endAddress = ExecutedStart - 1;
                ++itrMem;
            } else {
                break;
            }
        }
        if ((startAddress - 1) == endAddress) {  // Special case
            return;
        } else if ((startAddress - 1) > endAddress) {
            MSG_ERROR(0, "Wrong address: startAddr = %x, endAddr = %x, sizeMem = %d", startAddress, endAddress, size);
            std::runtime_error excep("MAU memory issue\n ");
            throw excep;
        }
        CorrectCounter(startAddress, endAddress, size, bus);
    } else {
        m_ExecutedMem[startAddress] = std::make_tuple(size, counter, bus);
    }

    /*T_RECORDMEM::iterator itrMem2;
    T_RECORDMEM trymem = m_ExecutedMem;
    UI32 count = 0;
    for (itrMem2 = trymem.begin(); itrMem2 != trymem.end(); ++itrMem2) {
        std::tuple<UI32, UI32, MAU_BUS_RESOURCE> valueMap = itrMem2->second;
        UI32 sizeTuple = std::get<0>(valueMap);
        UI32 cntTuple = std::get<1>(valueMap);
        count++;
        std::cout << count << ". MemExecuted Try: 0x" << std::hex << std::setw(8) << std::setfill('0') << itrMem2->first << "\tSize: " << sizeTuple << "\tCount: " << cntTuple << std::endl;
    }*/

    return;
}

/**
* @brief  Inform user the resource of input memory range
*/
CDcuMemory::MAU_BUS_RESOURCE CDcuMemory::GetResource(MEMADDR mr) {
    std::map<MEMRANGE, MAU_BUS_RESOURCE>::iterator itr = m_mResource.begin();
    while (itr != m_mResource.end()) {
        if (itr->first.first <= mr && itr->first.second >= mr) {
            return itr->second;
        }
        itr++;
    }

    return MAU_BUS_END;
}

/**
* @brief  Convert string Resource to bitset
*/
bool CDcuMemory::ResourceToBitset(const std::string& resource, MAU_BUS_RESOURCE* bus) {

    std::map<std::string, MAU_BUS_RESOURCE> resoure = { {"AXI", MAU_BUS_AXI}, {"GVCI", MAU_BUS_GVCI}, {"KVCI", MAU_BUS_KVCI},
                                                        {"eLB",MAU_BUS_eLB}, {"NT",MAU_BUS_NT} };

    std::map<std::string, MAU_BUS_RESOURCE>::iterator itr = resoure.find(resource);
    if (itr != resoure.end()) {
        (*bus) = itr->second;
        return true;
    } else {
        return false;
    }
}

/**
* @brief  Inform user all memory which were executed
*/
CDcuMemory::T_RECORDMEM CDcuMemory::GetExecutedMem() {
    return m_ExecutedMem;
}

/**
* @brief  Show all content of Memory for debugging
*/
void CDcuMemory::DumpMemory() {
    //Print Readable Mem
    std::set<MEMRANGE> KeyRead = m_wrReadableMem.KeySet();
    std::set<MEMRANGE>::iterator itr;
    std::cout << "[Read Memory]" << std::endl;
    for (itr = KeyRead.begin(); itr != KeyRead.end(); ++itr) {
        std::cout << "0x" << std::hex << std::setw(8) << std::setfill('0') << itr->first;
        std::cout << "\t,0x" << std::hex << std::setw(8) << std::setfill('0') << itr->second;
        std::cout << "\t," << std::dec << m_wrReadableMem.GetWeight(*itr) << std::endl;
    }
    //Print Writable Mem
    std::set<MEMRANGE> KeyWrite = m_wrWritableMem.KeySet();
    std::cout << "[Write Memory]" << std::endl;
    for (itr = KeyWrite.begin(); itr != KeyWrite.end(); ++itr) {
        std::cout << "0x" << std::hex << std::setw(8) << std::setfill('0') << itr->first;
        std::cout << "\t,0x" << std::hex << std::setw(8) << std::setfill('0') << itr->second;
        std::cout << "\t," << std::dec << m_wrWritableMem.GetWeight(*itr) << std::endl;
    }
    //Print Resource
    std::cout << "[Resource]" << std::endl;
    std::map<MEMRANGE, MAU_BUS_RESOURCE>::iterator s;
    for (s = m_mResource.begin(); s != m_mResource.end(); ++s) {
        std::cout << "Resource: 0x" << std::hex << std::setw(8) << std::setfill('0') << s->first.first;
        std::cout << "\t,0x" << std::hex << std::setw(8) << std::setfill('0') << s->first.second;
        std::cout << "\t," << std::dec << s->second << std::endl;
    }
}

