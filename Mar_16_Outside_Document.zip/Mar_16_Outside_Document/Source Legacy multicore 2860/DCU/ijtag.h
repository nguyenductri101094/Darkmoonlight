﻿#ifndef IJTAG_H
#define IJTAG_H


#include    "dcu_operand.h"


/*===============================================
@brief: Abstract class of JTAG commands
===============================================*/
class IJtag {

public:

    typedef enum {
        JTAG_ID_SET_TCK,
        JTAG_ID_SET_TCK_CYCLE,
        JTAG_ID_SET_TCK_DELAY,
        JTAG_ID_STARTUP,
        JTAG_ID_IDLE,
        JTAG_ID_WR,
        JTAG_ID_WR1,
        JTAG_ID_WR1_KEY,
        JTAG_ID_WRC,
        JTAG_ID_CMP,
        JTAG_ID_CMP1,
        JTAG_ID_POLL,
        JTAG_ID_BPOLL,
        JTAG_ID_MAU_RD_B_TYPE_A,
        JTAG_ID_MAU_WR_B_TYPE_A,
        JTAG_ID_MAU_RD_H_TYPE_A,
        JTAG_ID_MAU_WR_H_TYPE_A,
        JTAG_ID_MAU_RD_W_TYPE_A,
        JTAG_ID_MAU_WR_W_TYPE_A,
        JTAG_ID_MAU_RD_DW_TYPE_A,
        JTAG_ID_MAU_WR_DW_TYPE_A,
        JTAG_ID_MAU_RD_B_TYPE_B,
        JTAG_ID_MAU_WR_B_TYPE_B,
        JTAG_ID_MAU_RD_H_TYPE_B,
        JTAG_ID_MAU_WR_H_TYPE_B,
        JTAG_ID_MAU_RD_W_TYPE_B,
        JTAG_ID_MAU_WR_W_TYPE_B,
        JTAG_ID_MAU_RD_DW_TYPE_B,
        JTAG_ID_MAU_WR_DW_TYPE_B,
        JTAG_ID_NUM
    } JTAG_ID;

    IJtag(std::unique_ptr<IDcuOperand> opr1 = nullptr, std::unique_ptr<IDcuOperand> opr2 = nullptr,
        std::unique_ptr<IDcuOperand> opr3 = nullptr, std::unique_ptr<IDcuOperand> opr4 = nullptr, std::unique_ptr<IDcuOperand> opr5 = nullptr);

    virtual ~IJtag() {}

    /**
    * @brief Setting tool support random
    * @param random object manage random tool
    */
    static void SetRandomToolPointer(CMersenneTwister* random);

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    virtual JTAG_ID GetJtagId() const = 0;

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    virtual std::string GetJtagName() const = 0;

    /** 
    * @brief Get number of operands.
    * @return number of operands
    */
    UI32 GetOprNum() const { return m_vOpr.size();}

    /**
    * @brief operand access interface.
    * @param n Operand index
    * @return Operand reference
    */
    IDcuOperand* opr(UI32 n);

    /**
    * @brief append comment into last current comment
    */
    void AppendComment(const std::string& comment);

    /**
    * @brief Get comment of JTAG
    * @return string comment of JTAG
    */
    std::string GetComment() const;

    /**
    * @brief erase comment of JTAG
    */
    void DeleteComment();

    /**
    * @brief Set Jtag need for adjust operand。
    */
    void SetInsNeed(IJtag *pJtag) { m_vNeedJtag.push_back(pJtag); }

    /**
    * @brief Get Jtag need for adjust operand。
    * @return Vector list of need Jtag.
    */
    std::vector<IJtag*> GetJtagNeed() const { return m_vNeedJtag; }

    /**
    * @brief erase all Jtag need
    */
    void ClearJtagNeed() { m_vNeedJtag.clear(); }

    /**
    * @brief Set current Jtag to Loop
    */
    void SetInLoop(bool value) { m_bInLoop = value; }
  
    /**
    * @brief Set data written to memory
    */
   void SetData(std::vector<UI32> data) { m_data = data; }

   /**
   * @brief Set total of members in loop
   */
   void SetNumOfMemberInLoop(UI32 value) { m_MemberInLoop = value; }

   /**
   * @brief Set loop count
   */
   void SetLoopCount(UI32 value) { m_LoopCount = value; }

    /**
    * @brief Check JTag in loop or not
    * @return current status
    */
    bool InLoop() const { return m_bInLoop; }

    /**
    * @brief Get data written to memory
    * @return data list
    */
    std::vector<UI32> GetData() const { return m_data; }

    /**
    * @brief Get total of members in loop
    * @return total of members in loop
    */
    UI32 GetNumOfMemberInLoop() const { return m_MemberInLoop; }

    /**
    * @brief Get loop count
    * @return value of loop count
    */
    UI32 GetLoopCount() const { return m_LoopCount; }

    /**
    * @brief Set data for operand COprStrData support output Jtag
    * @bparam data of COprStrData
    */
    void SetOutOprData(std::string data);

    /**
    * @brief Determines the value of the operand.
    * @return own reference
    */
    virtual IJtag* SelectValue();

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    virtual std::string GetJtagCommand();

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    virtual bool RegulateJtagCommand() { return true; }

    /**
    * @brief Split Jtag command list
    * @param list of Jtag after spliting
    */
    virtual std::vector<std::unique_ptr<IJtag>> ExpandJtagCommand() { return  std::vector<std::unique_ptr<IJtag>>(); }

    /**
    * @brief Get constraint for Jtag
    * @return constraint of Jtag
    */
    virtual CDcuValConstraint* GetConstraint() {return m_JtagConstraint.get(); }

    /**
    * @brief Setting constraint for Jtag
    * @param constraint of Jtag
    */
    virtual void SetConstraint(std::unique_ptr<CDcuValConstraint> &constraint) { m_JtagConstraint = std::move(constraint); }

protected:
    std::vector<std::unique_ptr<IDcuOperand>>   m_vOpr;          //! Operand array of this instruction
    std::vector<IJtag*>	                        m_vNeedJtag;     //! The list of need JTAG for operand adjustment.
    std::string                                 m_comment;       //! describe some attention about JTAG
    static CMersenneTwister*                    m_pRandom;       //! manage random class
    bool                                        m_bInLoop;       //! check whether current Jtag in loop or not
    std::vector<UI32>                           m_data;          //! data to initialize for some variable
    UI32                                        m_MemberInLoop;  //! A number of member in loop
    UI32                                        m_LoopCount;     //! loop count
    std::unique_ptr<CDcuValConstraint>          m_JtagConstraint;  //! constraint of each jtag

};

#endif // IJTAG_H
