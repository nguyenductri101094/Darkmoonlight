﻿#include        "jtag.h"


/*===============================================
@brief: Clock(TCK) Output Control
@ID: 0
@name: set_tck
===============================================*/
const IJtag::JTAG_ID     JtagSetTck::m_id(JTAG_ID_SET_TCK);
const std::string        JtagSetTck::m_name("set_tck");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagSetTck::GetJtagCommand() const {
    std::stringstream ss;

    ss << m_name <<  '(' << std::setfill(' ') << std::setw(5) 
       << m_tck_stp 
       << std::setfill(' ') << std::setw(6) << ");";

    return ss.str();
}


/*===============================================
@brief: Clock(TCK) Period Control
@ID: 1
@name: set_tck_cycle
===============================================*/
const IJtag::JTAG_ID     JtagSetTckCycle::m_id(JTAG_ID_SET_TCK_CYCLE);
const std::string        JtagSetTckCycle::m_name("set_tck_cycle");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagSetTckCycle::GetJtagCommand() const {
    std::stringstream ss;

    ss << m_name << '(' << std::setfill(' ') << std::setw(8)
       << std::hex << "32'h" << m_cycle
       << std::setfill(' ') << std::setw(6) << ");";

    return ss.str();
}


/*===============================================
@brief: Clock(TCK) Delay Control
@ID: 2
@name: set_tck_delay
===============================================*/
const IJtag::JTAG_ID     JtagSetTckDelay::m_id(JTAG_ID_SET_TCK_DELAY);
const std::string        JtagSetTckDelay::m_name("set_tck_delay");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagSetTckDelay::GetJtagCommand() const {
    std::stringstream ss;

    ss << m_name << '(' << std::setfill(' ') << std::setw(8)
       << std::hex << "32'h" << m_delay
       << std::setfill(' ') << std::setw(6) << ");";

    return ss.str();
}


/*===============================================
@brief: Reset(TRSTZ) Pulse Output
@ID: 3
@name: startup
===============================================*/
const IJtag::JTAG_ID     JtagStartup::m_id(JTAG_ID_STARTUP);
const std::string        JtagStartup::m_name("startup");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagStartup::GetJtagCommand() const {
    std::stringstream ss;

    ss << m_name << " ;";

    return ss.str();
}


/*===============================================
@brief: IDLE State Recovery
@ID: 4
@name: idle
===============================================*/
const IJtag::JTAG_ID     JtagIdle::m_id(JTAG_ID_IDLE);
const std::string        JtagIdle::m_name("idle");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagIdle::GetJtagCommand() const {
    std::stringstream ss;

    ss << m_name << " ;";

    return ss.str();
}


/*===============================================
@brief: 32-bit Data Write
@ID: 5
@name: wr
===============================================*/
const IJtag::JTAG_ID     JtagWr::m_id(JTAG_ID_WR);
const std::string        JtagWr::m_name("wr");


/*===============================================
@brief: 1-bit Data Write
@ID: 6
@name: wr1
===============================================*/
const IJtag::JTAG_ID     JtagWr1::m_id(JTAG_ID_WR1);
const std::string        JtagWr1::m_name("wr1");


/*===============================================
@brief: 1-bit Data Write with Authentication
@ID: 7
@name: wr1_key
===============================================*/
const IJtag::JTAG_ID     JtagWr1Key::m_id(JTAG_ID_WR1_KEY);
const std::string        JtagWr1Key::m_name("wr1_key");


/*===============================================
@brief: 32-bit Data Write and Check
@ID: 8
@name: wrc
===============================================*/
const IJtag::JTAG_ID     JtagWrc::m_id(JTAG_ID_WRC);
const std::string        JtagWrc::m_name("wrc");


/*===============================================
@brief: 32-bit Data Check
@ID: 9
@name: cmp
===============================================*/
const IJtag::JTAG_ID     JtagCmp::m_id(JTAG_ID_CMP);
const std::string        JtagCmp::m_name("cmp");

/*===============================================
@brief: 1-bit Data Check
@ID: 10
@name: cmp1
===============================================*/
const IJtag::JTAG_ID     JtagCmp1::m_id(JTAG_ID_CMP1);
const std::string        JtagCmp1::m_name("cmp1");


/*===============================================
@brief: 32-bit Data Check with Polling
@ID: 11
@name: poll
===============================================*/
const IJtag::JTAG_ID     JtagPoll::m_id(JTAG_ID_POLL);
const std::string        JtagPoll::m_name("poll");


/*===============================================
@brief: 1-bit Data Check with Polling
@ID: 12
@name: bpoll
===============================================*/
const IJtag::JTAG_ID     JtagBpoll::m_id(JTAG_ID_BPOLL);
const std::string        JtagBpoll::m_name("bpoll");


//======================== ComplexJtag =================================//

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string ComplexJtag::GetJtagCommand() const {
    std::stringstream ss;

    for (UI32 jtag = 0; jtag < m_vJtagList.size(); jtag++) {
        ss << m_vJtagList[jtag]->GetJtagCommand() << std::endl;
    }

    return ss.str();
}


//========================= CAccessMemory =============================//
CDcuMemory*    CAccessMemory::m_pMemory = nullptr;

/**
* @brief Setting memory
* @param memory object manage memory of user
*/
void CAccessMemory::SetMemoryPointer(CDcuMemory* memory) {
    if (m_pMemory == nullptr) {
        m_pMemory = memory;
    }
}


//========================= CAccessMemoryTypeA =============================//

/**
* @brief Add attribute and correct JTAG command
* @return true if correct successfully
*/
bool CAccessMemoryTypeA::RegulateJtagCommand() {
    const UI32 write = 1;
    const UI32 default_value = 0xFFFFFFFF;
    const UI32 maxAccessCount = 0x3FFF;
    UI32 try_times = 10, cnt = m_cnt;
    UI32 align = ~(m_size - 1);
    std::stringstream ss;

    if (m_mem.second == CDcuMemory::MAU_BUS_END) { 
        cnt = maxAccessCount;
        // Random target memory in case of it does not specify
        while (m_mem.second == CDcuMemory::MAU_BUS_END && try_times != 0) {
            if (m_JtagConstraint != nullptr) {
                cnt = m_JtagConstraint->SelectValue();
            } else {
                cnt = m_pRandom->GetRange(1U, cnt);
            }

            m_mem = m_pMemory->SelectAddressRange(m_attribute, m_size, cnt);
            try_times--;
        }
    }

    if (try_times == 0) return false;

    /*=======Setting start address for MA_RWA register======*/
    UI32 start_address = m_mem.first & align;
    std::unique_ptr<JtagWr> MA_RWA = WR(1, 1, 0, 0xA3, start_address);
    std::string attributeMem = (m_attribute != 0) ? "Write" : "Read";
    ss << "//------------------ " << attributeMem <<" Circle TypeA - "<< std::dec << m_size << " byte ----------------------";
    MA_RWA->AppendComment(ss.str());
    // Prepare value in order to write to memory
    if (m_attribute == write) {
        std::vector<UI32> data;
        for (UI32 i = 0; i < cnt; i++) {
            data.push_back(m_pRandom->Get());
        }
        MA_RWA->SetData(data);
    }

    m_vJtagList.push_back(std::move(MA_RWA));

    /*=======Setting control for MA_CTRL register======*/
    UI32 ma_ctrl = 0;
    
    ma_ctrl |= (1 << 31);                   // Setting Access Control
    ma_ctrl |= (m_attribute << 30);         // Setting Read / Write 
    UI32 size = log2(m_size);
    ma_ctrl |= (size << 28);              // Setting Data Size
    ma_ctrl |= (m_mem.second << 24);        // Setting Map Select
    ma_ctrl |= ((cnt - 1) << 2);          // Setting Access Count

    std::unique_ptr<JtagWr> MA_CTRL = WR(1, 1, 0, 0xA2, ma_ctrl);
    m_vJtagList.push_back(std::move(MA_CTRL));

    /*============== Self check current address ======*/
    /*This is the first Jtag in Loop*/
    std::unique_ptr<JtagWrc> MA_CA = WRC(1, 1, 0, 0xA7, default_value, default_value);
    MA_CA->SetInLoop(true);
    MA_CA->SetLoopCount(cnt);
    JtagWrc* ma_ca = MA_CA.get();
    UI32 member_in_loop = 1;

    m_vJtagList.push_back(std::move(MA_CA));

    /*=======Setting data write for MA_WD register======*/
    if (m_attribute == write) {
        std::unique_ptr<JtagWr> MA_WD = WRsd(1, 1, 0, 0xA4);
        MA_WD->SetInLoop(true);
        member_in_loop++;
        m_vJtagList.push_back(std::move(MA_WD));

        /*=======Setting 32 bit upper data write for MA_WD1 in case of access memory 64 bit======*/
        if (m_size == 8) {
            std::unique_ptr<JtagWr> MA_WD1 = WRsd(1, 1, 0, 0xAC);
            MA_WD1->SetInLoop(true);
            member_in_loop++;
            m_vJtagList.push_back(std::move(MA_WD1));
        }
    } else {
        /*============== Read value of memory ======*/
        std::unique_ptr<JtagWrc> MA_RD = WRC(1, 1, 0, 0xA5, default_value, default_value);
        MA_RD->SetInLoop(true);
        member_in_loop++;
        m_vJtagList.push_back(std::move(MA_RD));

        /*======= Read value of memory in case of access memory 64 bit ======*/
        if (m_size == 8) {
            std::unique_ptr<JtagWrc> MA_RD1 = WRC(1, 1, 0, 0xAD, default_value, default_value);
            MA_RD1->SetInLoop(true);
            member_in_loop++;
            m_vJtagList.push_back(std::move(MA_RD1));
        }
    }

    /*============== Self check Register status ======*/
    std::unique_ptr<JtagWrc> MA_STAT = WRC(1, 1, 0, 0xA1, default_value, default_value);
    MA_STAT->SetInLoop(true);
    member_in_loop++;
    m_vJtagList.push_back(std::move(MA_STAT));
    // First Jtag in loop will store A number of Jtag in Loop
    ma_ca->SetNumOfMemberInLoop(member_in_loop);

    return true;
}



//========================= CAccessMemoryTypeB =============================//

/**
* @brief Add attribute and correct JTAG command
* @return true if correct successfully
*/
bool CAccessMemoryTypeB::RegulateJtagCommand() {
    const UI32 write = 1;
    const UI32 default_value = 0xFFFFFFFF;
    UI32 align = ~(m_size - 1);
    std::stringstream ss;
    UI32 cnt = 1;
    std::vector<UI32> readData = this->GetData();
    bool InLoop = (readData.size() > 0) ? true : false;

    // Random target memory in case of it does not specify
    if (m_mem.second == CDcuMemory::MAU_BUS_END) {
        // Support Block transfer
        if (m_size == 4) cnt = m_pRandom->GetRange(0, 1) ? 1 : 4;
        m_mem = m_pMemory->SelectAddressRange(m_attribute, m_size * cnt, 1);
        if (m_mem.second == CDcuMemory::MAU_BUS_END) return false;
    }

    // Random High-ranking address
    UI32 uas = m_pRandom->GetRange(0, 3);

    /*=======Setting upper address for MA_UA register======*/
    UI32 upper_address = m_mem.first >> 24;
    UI32 ma_ua = upper_address << (uas * 8);

    std::unique_ptr<JtagWr> MA_UA = WR(1, 1, 0, 0xA8, ma_ua);
    std::string attributeMem = (m_attribute != 0) ? "Write" : "Read";
    ss << "//------------------ " << attributeMem << " Circle TypeB - Start Address " << std::hex << m_mem.first << " - " << std::dec << m_size * cnt << " byte ----------------------";
    MA_UA->AppendComment(ss.str());
    JtagWr* pMA_UA = MA_UA.get();

    m_vJtagList.push_back(std::move(MA_UA));

    /*=======Setting control for MA_AD ======*/
    UI32 ma_ad = 0;

    ma_ad |= (m_attribute << 31);           // Setting Read / Write 
    UI32 size = log2(m_size);
    if (cnt == 4) size = 3;
    ma_ad |= (size << 29);                  // Setting Data Size
    ma_ad |= (m_mem.second << 27);          // Setting Map Select
    ma_ad |= ((uas + 1) << 24);             // Setting Upper Address Select

    if (readData.size() > 0) {
        // Support self-check memory
        std::vector<UI32> Data;
        UI32 lower_address = 0, temp_ma_ad = 0;

        for (UI32 i = 0; i < readData.size(); i++) {
            lower_address = (readData[i] & 0x00FFFFFF) & align;
            temp_ma_ad = ma_ad | lower_address;
            Data.push_back(temp_ma_ad);
        }

        std::unique_ptr<JtagWr> MA_AD = WRsd(1, 1, 0, 0xA9);
        MA_AD->SetInLoop(InLoop);
        MA_AD->SetLoopCount(Data.size());
        MA_AD->SetNumOfMemberInLoop(1);

        m_vJtagList.push_back(std::move(MA_AD));

        pMA_UA->SetData(Data);

    } else {
        UI32 lower_address = (m_mem.first & 0x00FFFFFF) & align;
        ma_ad |= lower_address;                 // Setting lower Address Select

        std::unique_ptr<JtagWr> MA_AD = WR(1, 1, 0, 0xA9, ma_ad);
        m_vJtagList.push_back(std::move(MA_AD));

        /*=======Setting data write for MA_AD register======*/
        if (m_attribute == write) {
            std::unique_ptr<JtagWr> MA_AD = WR(1, 1, 0, 0xA9, m_pRandom->Get());
            m_vJtagList.push_back(std::move(MA_AD));

            /*=======Setting 32 bit upper data write for MA_WD1 in case of access memory 64 bit======*/
            if (m_size == 8) {
                MA_AD = WR(1, 1, 0, 0xA9, m_pRandom->Get());
                m_vJtagList.push_back(std::move(MA_AD));

            } else if (cnt == 4) {
                MA_AD = WR(1, 1, 0, 0xA9, m_pRandom->Get());
                m_vJtagList.push_back(std::move(MA_AD));

                MA_AD = WR(1, 1, 0, 0xA9, m_pRandom->Get());
                m_vJtagList.push_back(std::move(MA_AD));

                MA_AD = WR(1, 1, 0, 0xA9, m_pRandom->Get());
                m_vJtagList.push_back(std::move(MA_AD));
            }

        } else {
            /*============== Read value of memory ======*/
            std::unique_ptr<JtagWrc> MA_RD = WRC(1, 1, 0, 0xA5, default_value, default_value);
            m_vJtagList.push_back(std::move(MA_RD));

            /*======= Read value of memory in case of access memory 64 bit ======*/
            if (m_size == 8) {
                std::unique_ptr<JtagWrc> MA_RD1 = WRC(1, 1, 0, 0xAD, default_value, default_value);
                m_vJtagList.push_back(std::move(MA_RD1));
            }
        }

        /*============== Self check Register start address ======*/
        std::unique_ptr<JtagWrc> MA_CA = WRC(1, 1, 0, 0xA7, default_value, default_value);
        m_vJtagList.push_back(std::move(MA_CA));
    }
    return true;

}
