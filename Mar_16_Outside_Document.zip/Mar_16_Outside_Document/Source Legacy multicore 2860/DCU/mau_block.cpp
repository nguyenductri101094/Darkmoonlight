﻿#include "mau_block.h"


CMauBlock::CMauBlock(): m_MBIN(0), m_MBOUT(0) {

}

CMauBlock::CMauBlock(std::string name): CDcuBlock(name), m_MBIN(0), m_MBOUT(0) {

}

CMauBlock::~CMauBlock() {

}

/**
 * @brief   Generate code in type A and type B to read memory for final comparision
 */
void CMauBlock::LoadDataOut(CDcuMemory::T_RECORDMEM mMemInfor) {	
    CDcuMemory::T_RECORDMEM::iterator itr;

	for (itr = mMemInfor.begin(); itr != mMemInfor.end(); itr++) {
		std::unique_ptr<IJtag> pJtag = nullptr;
		UI32 addr = itr->first;
		UI32 size = std::get<0>(itr->second);
		const UI32 cnt = std::get<1>(itr->second); //Always bigger than 1
		CDcuMemory::MAU_BUS_RESOURCE res =  std::get<2>(itr->second);
        if (cnt < 1 || cnt > 0x4000) {
            MSG_ERROR(0, "Wrong address: startAddr = %x, size = %d, count = %d", itr->first, size, cnt);
            std::runtime_error excep("MAU memory issue\n ");
            throw excep;
        }
        // Random generate access type A and type B
        if ((g_rnd.Get() & 1) != 0) {
            // Access Type A        
            pJtag = std::make_unique<CAccessMemoryTypeA>(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> (addr, res), size, 0/*read*/, cnt);
            pJtag->RegulateJtagCommand();
            this->AddJtag(pJtag);
        } else {// Access Type B
           if (cnt == 1) {
                pJtag = std::make_unique<CAccessMemoryTypeB>(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> (addr, res), size, 0/*read*/);
                pJtag->RegulateJtagCommand();
                this->AddJtag(pJtag);
                continue;
            }
            UI32 startAddr = addr;
            UI32 upperAddr = startAddr >> 24;
            std::vector<UI32> vAddr;
            
            for (UI32 i = 0; i < cnt; i++) {
                UI32 curAddr = startAddr + (size*i);            
                if ((curAddr >> 24) == upperAddr) {
                    vAddr.push_back(curAddr);
                } else {
                    pJtag = std::make_unique<CAccessMemoryTypeB>(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> (startAddr, res), size, 0/*read*/);
                    pJtag->SetData(vAddr);
                    pJtag->RegulateJtagCommand();
                    this->AddJtag(pJtag);
                    // Update start address and upper address
                    startAddr = curAddr;
                    upperAddr = startAddr >> 24;
                    vAddr.clear();
                }
            }
            if (vAddr.size()) {
                pJtag = std::make_unique<CAccessMemoryTypeB>(std::pair<MEMADDR, CDcuMemory::MAU_BUS_RESOURCE> (startAddr, res), size, 0/*read*/);
                pJtag->SetData(vAddr);
                pJtag->RegulateJtagCommand();
                this->AddJtag(pJtag);
            }        
        }
    }

    //Finish generate selfcheck code
    this->ExpandJtagBlock();
}

