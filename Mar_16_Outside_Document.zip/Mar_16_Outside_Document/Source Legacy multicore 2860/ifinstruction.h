#ifndef IFINSTRUCTION_H_
#define IFINSTRUCTION_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"
#include	"ifoperand.h"
#include	"ldd_info.h"
#include	"ifassembler.h"
#include	"regulation.h"
#include	"cpu_e3v5/sim/frog_if.h"
#include	"inst_id_list.h"

#if (1)     // E3V5_ASSIGN => arc headerへ移動する
#define		IF_INS_PRV0		IPRIV_CU0
#define		IF_INS_PRV1		IPRIV_CU1
#define		IF_INS_PRV2		IPRIV_CU2
#define		IF_INS_PRV3		IPRIV_SV
#define		IF_INS_PRV4		IPRIV_HV
#define		IF_INS_PRV5		IPRIV_DB

#define		IF_INS_CAT0		ICAT_FPU_S
#define		IF_INS_CAT1		ICAT_FPU_D
#define		IF_INS_CAT2		ICAT_SIMD
#define		IF_INS_CAT3		ICAT_CACHE
#define		IF_INS_CAT4		ICAT_MPU
#define		IF_INS_CAT5		ICAT_MMU
#define		IF_INS_CAT6		ICAT_DEBUG
#define		IF_INS_CAT7		ICAT_SPECIAL
#define		IF_INS_CAT8		ICAT_NATIVEDATA
#define		IF_INS_CAT9		ICAT_NATIVECODE

#define		IF_INS_BHV0		LOAD_MEMORY
#define		IF_INS_BHV1		STORE_MEMORY
#define		IF_INS_BHV2		LOAD_SR
#define		IF_INS_BHV3		STORE_SR
#define		IF_INS_BHV4		LOAD_GR
#define		IF_INS_BHV5		STORE_GR
#define		IF_INS_BHV6		LOAD_VR
#define		IF_INS_BHV7		STORE_VR
#define		IF_INS_BHV8		LOAD_PC
#define		IF_INS_BHV9		STORE_PC
#define		IF_INS_BHV10	JMP
#define		IF_INS_BHV11	TRAP_EXCEPTION
#define		IF_INS_BHV12	INS_1WAY
#define		IF_INS_BHV13	INS_2WAY
#define		IF_INS_BHV14	INS_4WAY

#define     MSK_BHV_INS_1WAY (1 << INS_1WAY)
#define     MSK_BHV_INS_2WAY (1 << INS_2WAY)
#define     MSK_BHV_INS_4WAY (1 << INS_4WAY)

#endif // E3V5 Assign


/**
 * @brief  命令を抽象化するインターフェースクラスです。
 *         全ての命令はこのインターフェースを実装する必要があります。
 *         特定の命令だけに必要な処理は仮想関数として派生クラスで実装してください。
 */
class IInstruction {
	
public:

	/**
	 * @brief  命令の実行権限を示す列挙子。各権限が示す内容は依存部で定義する。
	 *         std::bitset<IInstruction::END_PRIVILEDGE>アクセス用。
	 */
	typedef enum {
		IF_INS_PRV0,		//!< @brief 命令権限0
		IF_INS_PRV1,		//!< @brief 命令権限1 
		IF_INS_PRV2,		//!< @brief 命令権限2
		IF_INS_PRV3,		//!< @brief 命令権限3
		IF_INS_PRV4,		//!< @brief 命令権限4
		IF_INS_PRV5,		//!< @brief 命令権限5 
		END_PRIVILEDGE,		//!< @brief 権限定義数 
	} INS_PRIVILEDGE;

	
	/**
	 * @brief  命令の機能/種別を示す列挙子。機能/種別が示す内容は依存部で定義する。
	 *         std::bitset<IInstruction::END_CATEGORY>アクセス用。
	 */
	typedef enum {
		IF_INS_CAT0,		//!< @brief 命令種別0	+1
		IF_INS_CAT1,		//!< @brief 命令種別1	+2
		IF_INS_CAT2,		//!< @brief 命令種別2	+4
		IF_INS_CAT3,		//!< @brief 命令種別3	+8
		IF_INS_CAT4,		//!< @brief 命令種別4	+16
		IF_INS_CAT5,		//!< @brief 命令種別5	+32
		IF_INS_CAT6,		//!< @brief 命令種別6	+64
		IF_INS_CAT7,		//!< @brief 命令種別7	+128
		IF_INS_CAT8,		//!< @brief 命令種別8	+256
		IF_INS_CAT9,		//!< @brief 命令種別9	+512
		END_CATEGORY,		//!< @brief 種別定義数
	} INS_CATEGORY;
	
	
	/**
	 * @brief  命令の振る舞いを示す列挙子。動作が示す内容は依存部で定義する。
	 *        std::bitset<IInstruction::END_BEHAVIOR>アクセス用。
	 */
	typedef enum {
		IF_INS_BHV0,		//!< @brief 命令動作0
		IF_INS_BHV1,		//!< @brief 命令動作1
		IF_INS_BHV2,		//!< @brief 命令動作2
		IF_INS_BHV3,		//!< @brief 命令動作3
		IF_INS_BHV4,		//!< @brief 命令動作4
		IF_INS_BHV5,		//!< @brief 命令動作5
		IF_INS_BHV6,		//!< @brief 命令動作6
		IF_INS_BHV7,		//!< @brief 命令動作7
		IF_INS_BHV8,		//!< @brief 命令動作8
		IF_INS_BHV9,		//!< @brief 命令動作9
		IF_INS_BHV10,		//!< @brief 命令動作10
		IF_INS_BHV11,		//!< @brief 命令動作11
		IF_INS_BHV12,		//!< @brief 命令動作12
		IF_INS_BHV13,		//!< @brief 命令動作13
		IF_INS_BHV14,		//!< @brief 命令動作14
		END_BEHAVIOR,		//!< @brief 動作定義数
	} INS_BEHAVIOR;

	typedef enum {
		IF_SEQ_NONE,
		IF_SEQ_NORM,
		IF_SEQ_C2B1,
		IF_SEQ_FWD,
		IF_SEQ_GAP,
        IF_SEQ_RECOVERY,
        IF_SEQ_DCU,
		IF_SEQ_ARRAY,
		IF_SEQ_NUM,
	} INS_SEQUENCE;

    typedef enum {
        IF_PEND_NONE,
        IF_PEND_EI,
        IF_PEND_FE,
        END_PEND_INT
    } INS_PENDING_INTERRUPT;
	
    typedef enum {
        INS_FLG_Z	= (1 << 0),
        INS_FLG_S	= (1 << 1),
        INS_FLG_OV	= (1 << 2),
        INS_FLG_CY	= (1 << 3),
        INS_FLG_SAT	= (1 << 4),
    } INS_UPDATE_FLAG;
	
	/**
	 * @brief  このオブジェクトを生成します。
	 *         オペランドの型は命令によって制約がありますが、
	 *         このコンストラクタではオペランド型制約のチェックを行いません。
	 * 
	 * @param  op1	オペランド1 (default NULL)
	 * @param  op2	オペランド2 (default NULL)
	 * @param  op3	オペランド3 (default NULL)
	 * @param  op4	オペランド4 (default NULL)
	 */
	IInstruction(IOperand* op1 = NULL, IOperand* op2 = NULL, IOperand* op3 = NULL, IOperand* op4 = NULL)
		:	m_vop(), m_vdr(), m_note(""), m_oldcode(""), m_code(0ULL), m_len(0), m_nRepeat(1), m_regTarg(nullptr), m_coupleIns(nullptr), 
		m_bValid(false), m_bsSequence(0), m_bInLoop(false), m_bComplex(false), m_bChain(false), m_bForcedAdjust(false), m_bRegulate(false), m_Exception(0, 0),
		m_pswb(0), m_pswa(0), m_bOutput(true), m_bBreakInsertIns(false), m_bBreakTargetIns(false), m_bBreakCheckDone(false), m_bBreakNotSS(false), m_bRandomIns(false),
        m_bLDL_STC_CusIns(false), m_bSTCSuccess(false), m_pForwardIns(nullptr), m_pC2B1_Ins(nullptr), m_pRiePartner(nullptr), m_sPendingInt(0)
	{
		if (op1) {
			m_vop.push_back(op1);
			if (op2) {
				m_vop.push_back(op2);
				if (op3) {
					m_vop.push_back(op3);
					if (op4) {
						m_vop.push_back(op4);
					}
				}
			}
		}
	}

	
	/**
	 * @brief  このオブジェクトを破棄します
	 *         オブジェクトが所有するインスタンスは
	 *         登録されたIOperand、リンクディレクティブオブジェクトです。
	 * 
	 */	
	virtual ~IInstruction() {
		std::for_each(m_vop.begin(), m_vop.end(), [](IOperand*   p){ delete p;});
		std::for_each(m_vdr.begin(), m_vdr.end(), [](IDirective* p){ delete p;});
		//std::for_each(m_vNeedIns.begin(), m_vNeedIns.end(), [](IInstruction *p) { delete p;}); //[FROG]TODO: Delete remaining needed ins.
	}

	/**
	 * @brief   命令idを取得します。
	 * @return  命令id
	 */	
	virtual UI32 GetId() = 0;

	/**
	 * @brief   命令idを取得します。
	 * @return  命令id
	 */	
	virtual void SetId(UI32 newId) {};

	/**
	 * @brief  ニモニック文字列を取得します。
	 * @return ニモニック文字列
	 */	
	virtual const std::string& GetMne() = 0;


	/**
	 * @brief  オペランド数を取得します。
	 * @return オペランド数
	 */	
	virtual UI32 GetOpNum() const {
		return m_vop.size();
	}

    virtual UI32 UpdateFlag() {return 0;}
	/**
	 * @brief  この命令の権限値を取得します。
	 * @return 権限値
	 */	
	virtual UI32 GetPriviledge() = 0;


	/**
	 * @brief  この命令の権限属性を取得します。
	 * @param  p 権限列挙子
	 * @return 真の場合、指定値に適合
	 */	
	virtual bool Priviledge(INS_PRIVILEDGE p) {
		std::bitset<END_PRIVILEDGE> bs;
		bs = GetPriviledge();
		return (bs[p] != 0);
	}
	
	
	/**
	 * @brief  この命令の種別値を取得します。
	 * @return 種別値
	 */	
	virtual UI32 GetCategory() = 0;


	/**
	 * @brief  この命令のカテゴリ属性を取得します。
	 * @param  c カテゴリ列挙子
	 * @return 真の場合、指定値に適合
	 */	
	virtual bool Category(INS_CATEGORY c) {
		std::bitset<END_CATEGORY> bs;
		bs = GetCategory();
		return (bs[c] != 0);
	}
	
	
	/**
	 * @brief  この命令の動作値を取得します。
	 * @return 動作値
	 */	
	virtual UI32 GetBehavior() = 0;


	/**
	 * @brief  この命令の振舞い属性を取得します。
	 * @param  b 振舞い列挙子
	 * @return 真の場合、指定値に適合
	 */	
	virtual bool Behavior(INS_BEHAVIOR b) {
		std::bitset<END_BEHAVIOR> bs;
		bs = GetBehavior();
		return (bs[b] != 0);
	}

	
	/**
	 * @brief  オペランドの値を決定します。
	 * @return 自身の参照
	 */
	virtual IInstruction* Fix() {
		UI32 num = GetOpNum();
		for (UI32 i = 0; i < num; i++) {
			opr(i)->Fix();
		}
		return this;
	}

	/**
	 * @brief  Get register index that store mismatch value between CForest and RTL
	 * @return A vector include register index mismatch 
	 */
	virtual UI64 GetOprIdxMistmatch() {
		return 0;
	}
	/**
	 * @brief  オペランドを並べるだけのシミュレーション用アセンブラコードを生成する
	 *         このコード生成方式に適合しない場合は、派生クラスでの実装となります。
	 *         内部シミュレーション時のオペコード生成用であるため可視性・可読性は無視します。
	 *         またラベル指示されているオペランドは、アドレス解決されている必要があります。
	 * 
	 * @return アセンブラコード文字列
	 * @see    GetOutCode
	 */
	virtual std::string GetCode() {
		std::stringstream ss;
		UI32 num = GetOpNum();
		ss << std::setw(2) << std::left << std::setfill(' ') << GetMne();
		if (num > 0) {
			ss << ' ' << opr(0)->GetCode();
			if (num > 1) {
				ss << ',' << opr(1)->GetCode();
				if (num > 2) {
					ss << ',' << opr(2)->GetCode();
					if (num > 3) {
						ss << ',' << opr(3)->GetCode();
					}
				}
			}
		}
		return ss.str();
	};


	/**
	 * @brief  オペランドを並べるだけの出力用のアセンブラコードを生成します。
	 *         このコード生成方式に適合しない場合は、派生クラスでの実装となります。
	 *         ここで生成するアセンブラコードは出力ファイル用です。
	 *         命令ニモニックを16スペースでアラインし、オペランドを並べます。
	 *         オペランドがラベル指示されている場合、ラベル名を出力します。。
	 * 
	 * @return アセンブラコード文字列
	 * @see    GetCode
	 */
	virtual std::string GetOutCode() {
		std::stringstream ss;
		UI32 num = GetOpNum();
		ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
		
		if (num > 0) {
			ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : (opr(0)->GetLabel()) );
			if (num > 1) {
				ss << ',' << ((opr(1)->GetLabel() == NULL) ? opr(1)->GetCode() : (opr(1)->GetLabel()));
				if (num > 2) {
					ss << ',' << ((opr(2)->GetLabel() == NULL) ? opr(2)->GetCode() : (opr(2)->GetLabel()));
					if (num > 3) {
						ss << ',' << ((opr(3)->GetLabel() == NULL) ? opr(3)->GetCode() : (opr(3)->GetLabel()));
					}
				}
			}
		}
		return ss.str();
	};


	/**
	 * @brief  特定の汎用レジスタを使用する命令に設定する。
	 *         どのオペランドに対して設定されるかはランダムで決まる。
	 * @param  reg  レジスタインデックス
	 * @return アセンブラコード出力文字列
	 */
	virtual bool SetGrAnyOpr(UI32 reg) {
		if (m_vop.empty()) {
			return false;
		}
		std::vector<IOperand*> shfl = m_vop;
		std::random_shuffle(shfl.begin(), shfl.end(), g_rnd);
		BS_OPRATTR bs;
		bs[IOperand::OPR_ATTR_GR] = 1;
		
		for (std::vector<IOperand*>::iterator itr = shfl.begin(); itr != shfl.end(); itr++) {
			if ((*itr)->MatchAttr(bs) && (*itr)->Replace(reg)) {
				//m_len = 0; // 再度アセンブルが必要
				return true;
			}
		}		
		return false;
	}


	/**
	 * @brief  指定オペランドNに指定の汎用レジスタregを使用する命令に書き換える。
	 *         失敗時も再アセンブルされる。
	 * @param  N    オペランド番号(0〜）
	 * @param  reg  レジスタインデックス
	 * @return 書き換え成功時は真を返す。
	 *         ペアレジスタなどに奇数インデックス、
	 *         r0が選択出来ないオペランドを0に書き換える場合などは失敗し偽を返す。
	 */
	virtual bool SetGrOprN(UI32 N, UI32 reg) {
		std::vector<IOperand*>::iterator itr = m_vop.begin();
		std::advance(itr, N);
		if (itr == m_vop.end()) {
			return false;
		}
		return (*itr)->IsGR() && (*itr)->Replace(reg);
	}


	/**
	 * @brief    この命令のオペランドに値制約があるかを取得する。
	 * @return   真の場合、オペランドに値制約がある
	 */
	virtual bool HasConstraint() {
		std::vector<IOperand*>::iterator itr;
		for (itr = m_vop.begin(); itr != m_vop.end(); itr++) {
			if ((*itr)->GetConstraint()) {
				return true;
			}
		}
		return false;
	}
	
	
	/**
	 * @brief    コメント文字列を追加設定する。
	 * @param  s コメント文字列
	 * @return   コメント文字列
	 */
	virtual std::string& AppendComment(LPCTSTR s) {
		m_note += s;
		return m_note;
	}


	/**
	 * @brief  コメント文字列を取得する。
	 * @return コメント文字列
	 */
	virtual std::string& GetComment() {
		return m_note;
	}

	/**
	 * @brief  delete comment of instruction
	 * @return empty
	 */
	virtual std::string& DelComment(){
		m_note = "";
		return m_note;
	}

	/**
	 * @brief    コメント文字列を追加設定する(シングルライン記述)。
	 * @param  s コメント文字列
	 * @return   命令自身のアドレス
	 */
	virtual IInstruction* Note(LPCTSTR s) {
		m_note += s;
		return this;
	}	
	
	/**
	 * @brief    オペランドアクセスインターフェース。
	 * @param  n オペランドインデックス
	 * @return   オペランド参照
	 */
	virtual IOperand* opr(UI32 n) {
		if (m_vop.size() > n) {
			//m_len = 0;			// 命令書き換えられる可能性がある為、再アセンブルさせる。
			return m_vop[n];
		}else{
			return nullptr;
		}
	}

	/**
	 * @brief  find register has constraint and register was updated value in simualte part
	 * @return   operand index
	 */
    virtual UI32 GetConstraintBit();

	/**
	 * @brief  ソースレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */			
    virtual REGFLG GetGrSrc();

	/**
	 * @brief  デスティネーションレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */
    virtual REGFLG GetGrDst();

	/**
	 * @brief  ソースレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */			
    virtual REGFLG GetWrSrc();

	/**
	 * @brief  デスティネーションレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */
    virtual REGFLG GetWrDst();
	/**
	 * @brief    この命令をアセンブルします。
	 * @param  n オペコード格納領域
	 * @return   命令長（失敗時は０を返す）
	 */
    virtual UI32 Assemble(UI64* n);

	
	/**
	 * @brief    ラベルの設定。
	 * @param  str オペランドインデックス
	 * @return   命令オブジェクト
	 */
	virtual IInstruction* SetLabel(std::string str) {
		m_vdr.push_back(new CLabel(str.data(), 0));
		return this;
	}
	
	
	/**
	 * @brief    ディレクティブの設定。
	 * @param  b ディレクティブ
	 */
	virtual void SetDirective(IDirective* b) {
		m_vdr.push_back(b);
	}

	/**
	 * @brief Retrieve number of directive
	 * @return Number of directive
	 */
	virtual UI32 GetDirectiveNum() {
		return m_vdr.size();
	}

	/**
	 * @brief    ディレクティブの取得
	 * @param  i ディレクティブ
	 * @return   ディレクティブ参照
	 */
	virtual IDirective* GetDirective(UI32 i) {
		return (m_vdr.size() > i) ? m_vdr[i] : nullptr;
	}

	virtual void RemoveDirective(IDirective *pDir) {
		std::vector<IDirective*>::iterator itr = std::find_if(m_vdr.begin(), m_vdr.end(), [&] (IDirective* p) {return (p == pDir);});
		if(itr != m_vdr.end())
			m_vdr.erase(itr);
	}

	virtual void ClearDirective() {
		m_vdr.clear();
	}

    bool HasAsyncLabel();

    bool HasDeassertAsyncLabel();

    bool HasAssertLabel();

    void ClearAsync();

    /**
    * @brief  Set attribute pending interrupt
    * @return Set attribute pending interrupt
    */
    void SetAttrPending(INS_PENDING_INTERRUPT bsPendInt = END_PEND_INT, bool val = true) {
        m_sPendingInt.set(bsPendInt, val);
    }

    /**
    * @brief  Get attribute pending interrupt
    * @param  Type of pending interrupt
    * @return TRUE: Interrupt type that user input is pending, otherwise is FALSE
    */
    bool HasAttrPending(INS_PENDING_INTERRUPT bsPendInt) {
        return m_sPendingInt.test(bsPendInt);
    }

    /**
    * @brief  Clear attribute pending interrupt
    * @return Clear attribute pending interrupt
    */
    void ClearAttrPending() {
        m_sPendingInt.reset();
    }

	virtual void SetException(UI32 cause_code, UI32 addr) {
		m_Exception = std::make_pair(cause_code, addr);
	}

	virtual std::pair<UI32, UI32> GetException() {return m_Exception;}

	/**
	 * @brief    ディレクティブの取得
	 * @param  i ディレクティブ
	 * @return   ディレクティブ参照
	 */
	virtual std::string GetLabel() {
		for (size_t s = 0; s < m_vdr.size(); s++) {
			std::string label = m_vdr[s]->GetLabel();
			if(label.size() != 0) {
				return label;
			}
		}
		return std::string("");
	}


	/**
	 * @brief    命令長を取得する。
	 * @return   命令長
	 */
    virtual UI32 GetLen();


	/**
	 * @brief    この命令のオペコードを取得する。
	 * @return   オペコード
	 */
    virtual UI64 Fetch();


	/**
	 * @brief    この命令の各オペランドについて補正情報を取得する。
	 * @param    pReg 検証情報（In/Outパラメータクラス参照）
	 */	
    virtual void Regulate(IRegulation* pReg);

	/**
	 * @brief  この命令の妥当性（補正制御に合格したこと）を示す
	 * @return この命令の妥当性を取得する。真の場合、補正処理をスキップ可能。
	 */
	virtual bool GetValid() {
		return m_bValid;
	}


	/**
	 * @brief この命令の妥当性（補正制御に合格したこと）を設定する。
	 *        命令の妥当性はコードブロックのUpdateでクリアされる。
	 * @param f 命令の妥当性を設定する。
	 */
	virtual IInstruction* SetValid(bool f) {
		m_bValid = f;
        return this;
	}


	/**
	 * @brief	ディレクティブ情報を指定された命令インスタンスへ移動する
	 * @param	命令インスタンス
	 */
    void DirMoveTo(IInstruction* pIns);

    void AsyncMoveTo(IInstruction *pIns);

    void OnlyDirMoveTo(IInstruction* pIns);

	/**
	 * @brief	シーケンス情報を設定する。
	 * @param	シーケンスフラグ
	 */
	virtual void SetSequence(INS_SEQUENCE seq = IF_SEQ_NORM, bool val = true) {
		m_bsSequence.set(seq, val);
	}

	virtual void SetSequence(std::bitset<IF_SEQ_NUM> bsSequence) {
		m_bsSequence = bsSequence;
	}

	/**
	 * @brief	シーケンス情報を取得する。
	 * @return	シーケンスフラグ
	 */
	bool InSequence(void) const {
		if(m_bsSequence.none())
			return false;
		return true;
	}

	bool InSequence(INS_SEQUENCE seq) {
		return m_bsSequence.test(seq);
	}

	/**
	 * @brief	Get sequence attribute。
	 * @return	Set of sequence type
	 */
	std::bitset<IF_SEQ_NUM> GetSequence() {
		return m_bsSequence;
	}

	/**
	 * @brief	ループ内命令フラグを取得する。
	 * @param	ループ内命令フラグ
	 */
	bool IsComplex(void) const {
		return m_bComplex;
	}

	/**
	 * @brief	ループ内命令フラグを設定する。
	 * @param	ループ内命令フラグ
	 */
	void SetInLoop(bool flag = true) {
		m_bInLoop = flag;
	}


	/**
	 * @brief	ループ内命令フラグを取得する。
	 * @param	ループ内命令フラグ
	 */
	bool InLoop(void) const {
		return m_bInLoop;
	}


	/**
	 * @brief	シーケンス情報を取得する。
	 * @return	シーケンスフラグ
	 */
	void SetRegulationTarget(IInstruction* pIns) {
		m_regTarg = pIns;
	}


	/**
	 * @brief	シーケンス情報を取得する。
	 * @return	シーケンスフラグ
	 */
	IInstruction* GetRegulationTarget(void) {
		return m_regTarg;
	}
	
	void SetSequentialIns(IInstruction *pIns){
		m_vSeqIns.push_back(pIns);
	}
	std::vector<IInstruction*> & GetSequentialIns(){
		return m_vSeqIns;
	}

	/**
	 * @brief	Set Instruction need for adjust operand。
	 * @return	void.
	 */
	void SetInsNeed(IInstruction *pIns){
		m_vNeedIns.push_back(pIns);
	}
	/**
	 * @brief	Get Instruction need for adjust operand。
	 * @return	Vector list of need Instruction.
	 */
	std::vector<IInstruction*> & GetInsNeed(){
		return m_vNeedIns;
	}

	/**
	 *
	 */
	void ClearInsNeed() {
		m_vNeedIns.clear();
	}

    /**
	 * @brief   Solve the contradictory constraints
	 * @return  true if instruction can solve, otherwise return false
	 */
    virtual bool SolveConstraint(){return false;};

	/**
	 * @brief     ストリーム出力の演算子オーバーロード(フレンド関数)
	 * @param  s　出力するストリームオブジェクト
	 * @param  o  出力対象となるインスタンス
	 * @return    出力したストリームオブジェクト
	 */
	friend	std::ostream& operator<< (std::ostream& s, IInstruction& o) {
		if(!o.m_bOutput){
			return s;
		}

		// Directive
		std::for_each (o.m_vdr.begin(), o.m_vdr.end(), [&s](IDirective* pd) {pd->Print(s);});
		
		// Instruction
		static const int	align_opr = 48;
		s << std::setfill(' ');
		s << std::left;
		s << "\t";
		s << std::setw(align_opr) << o.GetOutCode();
		s << "-- " << o.GetComment() << std::endl;
		
		return s;
	}

	void SetChain() {
		m_bChain = true;
	}

	bool GetChain() {
		return m_bChain;
	}

	/*
	 * @brief set Ins is random instruction
	 */
	void SetRandomIns(bool flag){
		m_bRandomIns = flag;
	}


	/*
	 * @brief get current ins is random or not 
	 */
	bool IsRandomIns(){
		return m_bRandomIns;
	}

	/*
	 * @brief set Ins is ldl_stc custom instruction
	 */
	void SetLDL_STC_CusIns(bool flag){
		m_bLDL_STC_CusIns = flag;
	}


	/*
	 * @brief get current ins is ldl_stc custom or not 
	 */
	bool IsLDL_STC_CusIns(){
		return m_bLDL_STC_CusIns;
	}

		/*
	 * @brief set STC Ins false or success
	 */
	void SetSTCSuccess(bool flag){
		m_bSTCSuccess = flag;
	}


	/*
	 * @brief get current STC Ins is  false or success 
	 */
	bool IsSTCSuccess(){
		return m_bSTCSuccess;
	}

	/*
	* @brief set couple instruction.
	*/
	void SetCoupleIns(IInstruction* pIns) {
		m_coupleIns = pIns;
	}
	
	/*
	 * @brief get couple instruction. 
	*/
	IInstruction* GetCoupleIns() {
		return m_coupleIns;
	}
	/*
	 * @brief Set Forwarding data instruction
	 */
	void SetForwardIns(IInstruction* pIns){
		m_pForwardIns = pIns;
	}

	/*
	 * @brief Get Forwarding data instruction
	 */
	IInstruction* GetForwardIns() {
		return m_pForwardIns;
	}

	/*
	* @brief Set C2B1 instruction
	*/
	void SetC2B1Ins(IInstruction* pIns){
		m_pC2B1_Ins = pIns;
	}

	/*
	* @brief Get C2B1 instruction
	*/
	IInstruction* GetC2B1Ins() {
		return m_pC2B1_Ins;
	}

	/*
	 * @brief get other RIE couple instruction (one .word and one .hword instruction)
	 */
	IInstruction* GetRiePartner() {
		return m_pRiePartner;
	}

	/*
	 * @brief set other RIE couple instruction (one .word and one .hword instruction)
	 */
	void SetRiePartner( IInstruction* pIns) {
		m_pRiePartner = pIns;
	}

	/**
	* @brief RType制御(SIMDのアドレッシングについての除外項目)
	* Base = {Step/Index}となる命令は正常に補正できないため、使用する汎用レジスタを差し替える
	*/
	virtual bool RTypeVerify(){
		return false;
	}

	void SetForcedAdjust(bool bForce = true) {
		m_bForcedAdjust = bForce;
	}

	bool IsForcedAdjust(bool bForce = true) {
		return m_bForcedAdjust;
	}

	/**
	 * @brief	Set/Get re-executing times.
	 * @param	Number of re-executing times.
	 */
	void SetRepeat(UI32 r) {m_nRepeat = r;}
	UI32 GetRepeat() {return m_nRepeat;}

	/**
	* @brief To get set and set regualte attribute of instruction
	*
	*/
	void SetRegulate(bool bRegualte) { m_bRegulate = bRegualte; }
	bool IsRegulate() {return m_bRegulate;}

	virtual void SetTaken(bool taken) {}
	virtual void SetTaken(bool taken, IInstruction* notIns) {}
	virtual void SetReverse(IInstruction* notIns) {}
	virtual IInstruction* GetReverse() {return nullptr;}
	virtual void DelReverse() {}
	virtual bool HasBranchConstraint() {return false;}
	virtual bool GetConstraint() {return false;}
	virtual void SetConstraint(bool constraint) {}
	virtual bool TakeCondition(UI32 psw) {return false;}
	virtual void SetJumpTargetLabel(std::string label) {}
	virtual std::string GetJumpTarget() {return "";}

    /**
     * @brief Remove mismatch register in instruction
     * @param MismatchRegSet list of register mismatch
     * @param MismatchEntrySet list of entry mismatch
     */
    void RemoveRegInList(UI32 MismatchRegSet, UI32 MismatchEntrySet);
    
	/**
	 * @brief MPXアーキテクチャ構成情報のMPXINFOレジスタRSIZEビットの問い合わせ関数
	 * @return Fullの場合:true
	 */
    bool IsMPX4Full(void);

protected:
	std::vector<IOperand*>		m_vop;		//!< @brief この命令が持つオペランド配列
	std::vector<IDirective*>	m_vdr;		//!< @brief この命令に付加される疑似命令
	std::vector<IInstruction*>	m_vSeqIns;	//!< @brief	The list of sequential instruction
	std::vector<IInstruction*>	m_vNeedIns;	//!< @brief The list of need Instruction for operand adjustment.
	std::string					m_note;		//!< @brief コメント文字列
	std::string					m_oldcode;
	UI64						m_code;		//!< @brief 命令コード
	UI8							m_len;		//!< @brief 命令長
	UI32						m_nRepeat;	//!< @brief Re-executing time (for adjustment)
	IInstruction*				m_regTarg;	//!< @brief 補正ターゲット命令(補正命令は対象命令を保持、NULL以外)
	IInstruction*				m_coupleIns; //!<@brief Couple instruction with this instruction.
	bool						m_bValid;	//!< @brief 補正済み
	std::bitset<IF_SEQ_NUM>		m_bsSequence;	//!< @brief シーケンス命令（一連の手順の一部）であるか(この命令を跨ぐような命令順を移動させない)
	bool						m_bInLoop;	//!< @brief ループ内命令
	bool						m_bComplex;	//!< @brief 複合内命令
	bool                        m_bChain;   //!< @brief コードブロック間接続用命令
	bool						m_bForcedAdjust;
	bool						m_bRegulate; //!< @brief Is this instruction need to regulate.
	std::pair<UI32, UI32>		m_Exception; //!< @brief Cause code and handler address of interrupt/exception.
public:
	UI32						m_pswb;
	UI32						m_pswa;
	bool						m_bOutput;
    bool                        m_bBreakInsertIns; //!< @brief ブレーク例外発生命令挿入完了フラグ
    bool                        m_bBreakTargetIns; //!< @brief ブレーク例外発生対象命令フラグ
    bool                        m_bBreakCheckDone;     //!< @brief ブレーク選出チェック済フラグ
    bool                        m_bBreakNotSS;     //!< @brief ブレークSS抑止フラグ
	bool						m_bRandomIns;	   //!< @brief Random instruction.
	bool						m_bLDL_STC_CusIns; //!< @brief Is ldl_stc custom instruction.
	bool						m_bSTCSuccess;	   //!< @brief Decide ldl_stc success or fail.    
	IInstruction*               m_pForwardIns;      //!< @brief store 2nd in Forwarding Data instruction
	IInstruction*               m_pC2B1_Ins;       //!< @brief store 2nd in C2B1 instruction
	IInstruction*				m_pRiePartner;
    std::bitset<END_PEND_INT>   m_sPendingInt;     //!< @brief Inform there is interrupt pending or not
};

/*
 * 複数の命令を1つの命令として扱う。 
 * 
 * 
 * 
 */
class ComplexInstruction : public IInstruction
{
public:
	/**
	 * @brief  このオブジェクトを生成します。
	 */
	ComplexInstruction(UI32 id, std::string mne) : m_id(id), m_mne(mne), m_ins() {
		m_bComplex = true;
	}
	
	/**
	 * @brief	このオブジェクトを破棄します。
	 *			ただし要素は破棄しない。 
	 */
	virtual ~ComplexInstruction(){ 
		std::for_each(m_ins.begin(), m_ins.end(), [&] (IInstruction* p) { delete p;} );
	}
	
	/**
	 * @brief  このオブジェクトを生成します。
	 */
	IInstruction* operator [](int n) {
		return m_ins[n];
	}

	/**
	 * @brief  Wrapper interface of std::vector::push_back
	 * @param  elm  A part of instruction.
	 */	
	void push_back(IInstruction* elm) {
		m_ins.push_back(elm);
	}

	/**
	 * @brief  Wrapper interface of std::vector::pop_back
	 */	
	void pop_back() {
		m_ins.pop_back();
	}
	
	/**
	 * @brief  Wrapper interface of std::vector::back
	 * @param  elm  A part of instruction.
	 */	
	IInstruction* back() {
		return m_ins.back();
	}

	/**
	 * @brief  Wrapper interface of std::vector::size
	 * @return Number of instruction in container.
	 */		
	size_t size() {
		return m_ins.size();
	} 

	/**
	 * @brief  Wrapper interface of std::vector::clear
	 * @return Number of instruction in container.
	 */		
	void clear() {
		return m_ins.clear();
	} 

	/**
	 * @brief    含まれる命令長の合算値を返します。。
	 * @return   命令長（失敗時は０を返す）
	 */
	virtual UI32 GetLen() override {
		UI32 len = 0;
		for (UI32 i = 0; i < size(); i++) {
			UI32 tlen = m_ins[i]->GetLen();
			if (tlen == 0) {
				len = 0;
				break;
			}else{
				len += tlen;
			}
		}
		return len;
	}

	/**
	 * @brief    この命令をアセンブルします。
	 * @param  n オペコード格納領域
	 * @return   命令長（失敗時は０を返す）
	 */
	virtual UI32 Assemble(UI64* n) override {
		UI32 len = 0;
		UI64 code;
		for (UI32 i = 0; i < size(); i++) {
			UI32 tlen = m_ins[i]->Assemble(&code);
			if (tlen == 0) {
				len = 0;
				break;
			}else{
				len += tlen;
			}
		}
		return len;
	}

	/**
	 * @brief  Unique id.
	 * @return Unique id.
	 */		
	virtual UI32 GetId() override {
		return m_id;
	}

	/**
	 * @brief	シーケンス情報を設定する。
	 * @param	シーケンスフラグ
	 */
	void SetSequence(INS_SEQUENCE seq = IF_SEQ_NORM, bool val = true) {
		std::for_each (m_ins.begin(), m_ins.end(), [=](IInstruction* p) { p->SetSequence(seq, val);});
	}

	void SetSequence(std::bitset<IF_SEQ_NUM> bsSequence) {
		std::for_each (m_ins.begin(), m_ins.end(), [=](IInstruction* p) { p->SetSequence(bsSequence);});
	}

	/**
	 * @brief    コメント文字列を追加設定する。
	 * @param  s コメント文字列
	 * @return   コメント文字列
	 */
	virtual std::string& AppendComment(LPCTSTR s) {
		std::for_each (m_ins.begin(), m_ins.end(), [=](IInstruction* p) { p->AppendComment(s);});
		return m_note;
	}

	/**
	 * @brief     ストリーム出力の演算子オーバーロード(フレンド関数)
	 * @param  s　出力するストリームオブジェクト
	 * @param  o  出力対象となるインスタンス
	 * @return    出力したストリームオブジェクト
	 */
	friend	std::ostream& operator<< (std::ostream& s, ComplexInstruction& o) {
		std::for_each (o.m_ins.begin(), o.m_ins.end(), [&s](IInstruction* p) { s << (*p); });
		return s;
	}

	/**
	 * @brief  Implement flag operation(pur).
	 * @return always zero.
	 */		
	virtual UI32 GetCategory()	override {return 0;}
	virtual UI32 GetBehavior()	override {return 0;}
	virtual UI32 GetPriviledge()override {return 0;}
	virtual const std::string& GetMne() {return m_mne;}
	
protected:
	UI32						m_id;	//!< @brief 命令IDとなるユニーク値
	std::string					m_mne;	//!< @brief 複合命令名
	std::vector<IInstruction*>	m_ins;	//!< @brief 命令配列
};

class UserInstruction : public IInstruction {
public: 
	UserInstruction(std::string code): IInstruction(), m_asmCode(code) {
		m_bOutput = false;
	}
	
	UserInstruction(): IInstruction(), m_asmCode("") {
		m_bOutput = false;
	}

	UserInstruction(IOperand* op1 = NULL, IOperand* op2 = NULL, IOperand* op3 = NULL, IOperand* op4 = NULL)
	: IInstruction(op1, op2, op3, op4), m_asmCode("") {
		m_bOutput = false;
	}

	virtual std::string GetCode(){ return m_asmCode; }

	virtual UI32 GetId(){ return 0; }

	virtual const std::string& GetMne() { return m_asmCode;}

	virtual UI32 GetPriviledge() { return 0;}

	virtual UI32 GetCategory() { return 0; }

	virtual UI32 GetBehavior() { return 0; }

	virtual ~UserInstruction() {}
protected:
	std::string					m_asmCode;
};


typedef std::bitset<IInstruction::END_PRIVILEDGE>	BS_IPRV;
typedef std::bitset<IInstruction::END_CATEGORY>		BS_ICAT;
typedef std::bitset<IInstruction::END_BEHAVIOR>		BS_IBHV;

#endif /* IFINSTRUCTION_H_ */
