#include "ifinsset.h"
#include "insid_set.h"

IInstructionSet* IInstructionSet::New() {

		return new CInstructionSet();

}

