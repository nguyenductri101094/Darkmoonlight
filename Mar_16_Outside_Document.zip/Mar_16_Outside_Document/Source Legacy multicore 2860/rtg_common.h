#ifndef RTG_COMMON_H_ 
#define RTG_COMMON_H_

/* Standard header files */
#include		<cstdio>
#include		<cstdlib>
#include		<cstring>
#include		<ctime>
#include		<cassert>
#include		<cstdarg>
#include        <cctype>
#include		<memory>
#include		<iostream>
#include		<iomanip>
#include		<fstream>
#include		<sstream>
#include		<iterator>
#include		<utility>
#include		<bitset>
#include		<typeinfo>
#include		<algorithm>
#include		<bitset>
#include		<vector>
#include		<queue>
#include		<map>
#include		<set>
#include		<tuple>
#include		<stdexcept>

/* System header files */
#include		<unistd.h>
#include		<fcntl.h>
#if (0)
#include		<cxxabi.h>  // for de-mangling
#include		<mcheck.h>	// for mtrace
#endif

#include		"rtg_macro.h"
#include		"rtg_types.h"
#include		"msg_log.h"

extern const char* const RTG_TARGET;
extern const char* const RTG_APP_REV;
extern const char* const RTG_HASHCODE;
extern const char* const RTG_CPU_ISA;

#endif // RTG_COMMON_H_
