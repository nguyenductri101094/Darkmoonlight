#ifndef IFBLK_MANAGER_H_
#define IFBLK_MANAGER_H_

#include	<iostream>
#include	"ifinsset.h"
#include	"ifsysreg.h"
#include	"codeblock.h"
#include	"ifinsset.h"
#include    "cpu_e3v5/mxu_parser.h"

typedef		std::map<std::string,CWeightList*>	LIST_INSSET;


/**
 * @brief コードブロックの生成条件をもつパラメータクラス。
 */
struct TBlockConfig {
public:
	TBlockConfig() : 
		N(0), InsNum(0), pInsSet(NULL), m_pSrSet(NULL),
		m_bSys(false), m_bNC(true), m_bGM(false), m_bBase(false), m_VCID(0), m_HTID(0), m_GMID(0), m_ucfile()
	{}
	~TBlockConfig(){}
	
	// アーキテクチャに合わせて必要なフィールドを追加してよい
	UI32				N;			//<! @brief ブロックインデックス番号
	UI32				InsNum;		//<! @brief ブロック内の命令数
	
	// 破棄予定-> ここから
	std::map<std::string,CWeightList*>* pInsSet;	//<! @brief 命令セットのリスト 
	ISysRegSet*			m_pSrSet;		//<! @brief SR制御
	// 破棄予定-> ここまで
	
	//------------------------------
	bool				m_bSys;		//<! @brief 生成するブロックが実行されるスレッド番号
	bool				m_bNC;		//<! @brief 生成するブロックがNativeContextのコードであるとき真
    bool                m_bGM;      //<! @brief True if the generated block is a guest mode code
	bool				m_bBase;	//<! @brief 生成するブロックがベースコンテキストであるとき真
	UI32				m_VCID;		//<! @brief 生成するブロックが実行されるVM番号
	UI32				m_HTID;		//<! @brief 生成するブロックが実行されるスレッド番号
	UI32				m_GMID;		//<! GM number of the block to be generated]
    UI32				m_PEID;		//<! PEID number of the block to be generated
	std::string			m_ucfile;
};


/**
 * @brief コードブロックの生成と処理を抽象化するインターフェースクラスです。
 */
class IBlockManager
{
public:

	//! ベクタアドレス列挙子(Architecture)
	enum ADDR_INTVECTOR {
		ADR_VECTOR_RESET	= 0x00,		//!< @brief Resetベクタアドレス
		ADR_VECTOR_SYSERR	= 0x10,		//!< @brief SysErrorベクタアドレス
		ADR_VECTOR_HVTRAP	= 0x20,		//!< @brief HV Trapベクタアドレス
		ADR_VECTOR_FETRAP	= 0x30,		//!< @brief FE Trapベクタアドレス
		ADR_VECTOR_TRAP0	= 0x40,		//!< @brief Trap0ベクタアドレス
		ADR_VECTOR_TRAP1	= 0x50,		//!< @brief Trap1ベクタアドレス
		ADR_VECTOR_RIE		= 0x60,		//!< @brief 予約命令例外ベクタアドレス
		ADR_VECTOR_FPPFPI	= 0x70,		//!< @brief 浮動小数点命令例外ベクタアドレス
		ADR_VECTOR_UCPOP	= 0x80,		//!< @brief コプロ使用権例外ベクタアドレス
		ADR_VECTOR_MPUMMU	= 0x90,		//!< @brief メモリアクセス例外ベクタアドレス
		ADR_VECTOR_PIE		= 0xA0,		//!< @brief 特権命令例外ベクタアドレス
		ADR_VECTOR_DEBUG	= 0xB0,		//!< @brief デバッグ例外ベクタアドレス
		ADR_VECTOR_MAE		= 0xC0,		//!< @brief ミスアラインアクセス例外ベクタアドレス
		ADR_VECTOR_BGINT  	= 0xD0,		//!< @brief BGFEINT, BGEIINT vector address
		ADR_VECTOR_FENMI	= 0xE0,		//!< @brief FENMI例外ベクタアドレス
		ADR_VECTOR_FEINT	= 0xF0,		//!< @brief FEレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT000	= 0x100,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT001	= 0x110,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT002	= 0x120,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT003	= 0x130,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT004	= 0x140,
		ADR_VECTOR_EIINT005	= 0x150,
		ADR_VECTOR_EIINT006	= 0x160,
		ADR_VECTOR_EIINT007	= 0x170,
		ADR_VECTOR_EIINT008	= 0x180,
		ADR_VECTOR_EIINT009	= 0x190,
		ADR_VECTOR_EIINT010	= 0x1a0,
		ADR_VECTOR_EIINT011	= 0x1b0,
		ADR_VECTOR_EIINT012	= 0x1c0,
		ADR_VECTOR_EIINT013	= 0x1d0,
		ADR_VECTOR_EIINT014	= 0x1e0,
		ADR_VECTOR_EIINT015	= 0x1f0,
		ADR_VECTOR_NUM		= 0x200,
	};

	/**
	 * @brief  このオブジェクトを構築します。
	 */	
	IBlockManager(){}
	
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual	~IBlockManager() {}


	/**
	 * @brief  ベクタブロックコードを生成します。
	 * @return ベクタブロックコード
	 */
	virtual std::vector<CVectorBlock*>* GenerateIntVector(TBlockConfig*) = 0;
		
	/**
	 * @brief  ハンドラコードを生成します。
	 * @return ブロックコード
	 */
	virtual std::vector<CHandlerBlock*>* GenerateHandler(TBlockConfig*) = 0;

	/**
	 * @brief  ハンドラコードを生成します。
	 * @return ブロックコード
	 */
	virtual CHandlerBlock*	GenEITBLHandler(TBlockConfig* pCfg) = 0;

	/**
	 * @brief  ハンドラコードを生成します。
	 * @return ブロックコード
	 */
	virtual std::vector<CHandlerBlock*>* GenerateFixHandlerBlock(TBlockConfig*) = 0;

	/**
	 * @brief  プリロードコードを生成します。
	 * @return プリロードコード
	 */
	virtual std::vector<CPreloadBlock*>* GeneratePreload(TBlockConfig*) = 0;
	
	/**
	 * @brief  プリロードコードを生成します。
	 * @return プリロードコード
	 */
	virtual std::vector<CPreloadBlock*>* GenerateSRsInit(TBlockConfig*) = 0;
		
	/**
	 * @brief  メモリ初期化コードを生成します。
	 * @param recode メモリ初期化情報
	 */
	virtual CPreloadBlock* AppendMemPresetBlock(std::vector<T_MEMWRRECORD > * recode, UI32 peid) = 0;

	/**
	 * @brief This function append code block initializing sharing memory
	 * @param recode    Accessed memory record
	 * @return Code block
	 */
	virtual CPreloadBlock * AppendShareMemPreset(std::vector<T_MEMWRRECORD > * recode, UI32 peid) = 0;
		
	/**
	 * @brief		       Generate debug break set up block
	 *                     This is block that config for breakpoint exception
	 * @param returnReg    General register for return to caller block
	 * @param pCfg         TBlockConfig
	 * @return             CPreloadBlock
	 */
	virtual CPreloadBlock*	GenerateDebugBreakSetUpBlock(TBlockConfig* pCfg, UI32 returnReg) = 0;

	/**
	 * @brief  プリフェッチコードを生成します。
	 * @param  pf_addr プリフェッチ開始アドレス
	 * @param  pf_size プリフェッチサイズ
	 */
	virtual void AppendPrefetchCode (std::string & context, CSyncBlock* pPF) = 0;
	virtual void AppendPrefetchData (UI32 pf_addr ,UI32 pf_size, CSyncBlock* pPF) = 0;
	
	virtual void FetchLineZeroing_AddOpcodeDirectly (std::vector<INode*>& rCb) = 0;


	/**
	 * @brief  プロローグコードを生成します。
	 * @return プロローグコード
	 */
	virtual std::vector<CPrologueBlock*>* GeneratePrologue(TBlockConfig*) = 0;
	

	/**
	 * @brief  同期ブロックコードを生成します。
	 * @return 同期ブロックコード
	 */
	virtual std::vector<CSyncBlock*>* GenerateSync(TBlockConfig*) = 0;
	
	/**
	 * @brief  create break setup block for break function
	 * @return preload block
	 */
	virtual std::vector<CPreloadBlock*>* GenerateSetupBlock(TBlockConfig* pCfg) = 0;
	/**
	 * @brief  ランダムタブロックコードを生成します。
	 * @param  pCfg 構成情報 
	 * @return ブロックコード
	 */
	virtual CCodeBlock* GenerateRandomBlock(TBlockConfig* pCfg)  = 0;

	/**
	 * @brief  同期ブロックコードを生成します。
	 * @return 同期ブロックコード
	 */
	virtual std::vector<CTeSyncBlock*>* GenerateTeSync(TBlockConfig*) = 0;
	

	/**
	 * @brief  汎用レジスタを交差させるランダムタブロックコードを生成します。
	 * @param  N    ブロック番号
	 * @param  num  命令数
	 * @param  WeightSet 発生させる命令重みセット 
	 * @return ブロックコード
	 */
	//virtual CCodeBlock* GenerateGrInteraceBlock(UI32 N, UI32 num, std::map< std::string , CWeightList* > *  WeightSet= NULL) = 0;

	/**
	 * @brief  ファンクションコードを生成します。
	 * @return ファンクションコード
	 */
	virtual std::vector<CFunctionBlock*>* GenerateFunction(TBlockConfig*) = 0;
	
	/**
	 * @brief  エピローグコードを生成します。
	 * @return エピローグコード
	 */
	virtual std::vector<CEpilogueBlock*>* GenerateEpilogue(TBlockConfig*) = 0;

	/**
	 * @brief  期待値生成コードを生成します。
	 * @return ブロックコード
	 */
	virtual void GenVerifier(CCodeBlock* pEB, TBlockConfig* pCfg){};
		
	/**
	 * @brief  終了コードを生成します。
	 * @return ブロックコード
	 */
	virtual std::vector<CTerminateBlock*>* GenerateTerminateBlock(TBlockConfig*) = 0;
	
	/**
	 * @brief generate random user code block
	 * @return new user code 
	 */
	virtual CUserBlock* GenerateUserBlock(LPCTSTR context_key, TBlockConfig* pCfg, std::string labelStr) = 0;
	
	/**
	 * @brief  ランダムタブロックコードを生成します。
	 * @param  num  命令数
	 * @param  pset 発生させる命令セット 
	 * @return ブロックコード
	 */
	//virtual CCodeBlock* GenerateBlock(UI32 num, IInstructionSet* pset) = 0;
	
	/**
	 * @brief  コードブロックに例外をプリセットします(強制例外の設定)。
	 *         例外の発生要因はアーキテクチャに依存する。
	 * @param  pCb  例外を設定するコードブロック
	 * @param  pEx	発生させる例外とその確率 
	 */
	virtual void PresetException(CCodeBlock* pCb, IException* pEx) = 0;
	
	virtual std::vector<CUserBlock*>* InsertUserCode(LPCTSTR context_key , LPCTSTR user_key , TBlockConfig* pCfg, CCodeBlock* pCB) {return nullptr;}

	
	/**
	 * @brief  ブロック間を繋ぐ命令を追加します。
	 * @param  src 前処理ブロック。このブロックに後処理へつながる命令が追加される。
	 * @param  dst 後処理ブロック
	 * @return 後処理の参照
	 */
	virtual CCodeBlock* ChainBlock(CCodeBlock* src, CCodeBlock* dst) = 0;
	virtual CCodeBlock* MixBlock(CCodeBlock* src, CCodeBlock* dst) = 0;

	virtual std::vector<CFunctionBlock*>* GenerateMPUpdate(TBlockConfig* pCfg) = 0;
	/**
	 * @brief 命令セットの重み情報へのポインタを取得。
	 */
	virtual IInstructionSet * GetWeightSet() = 0;

	virtual bool CU1isON(void) = 0;

	/**
	 * @brief	Move regulation at the beginning of handler to random code block
	 */
	virtual void FrontRegulationHandler() = 0;

	/**
	 * @brief	Return the register that has constraint at the beginning of handler
	 * @param	Handler name
	 * @return	A vector of registers index
	 */
	virtual std::vector<UI32> GetConstraintReg(UI32 handler) = 0;

	virtual UI32 GetHandlerWorkReg() = 0;

	virtual UI32 GetHandlerReg() = 0;

    /**
    * @brief Get variable which save MPU information
    */
    virtual CMmList* GetMPUInfor() = 0;

    /**
    * @brief	Add Dead Code
    * @param	pCB	pointer to code block, pIns  pointer to instruction
    */
    virtual void AddDeadCode(CCodeBlock *pCB) = 0;

    virtual UI32 GetMismatchReg() = 0;

    virtual UI32 GetMismatchEntry() = 0;

	virtual bool EnabelHVTRAPFor (UI32 changeto) = 0;

    /*
    * @Brief get list of handshake record
    * @param none
    */
    virtual std::vector<std::pair <UI32, UI32>> GetHandShakeRecord() = 0;

    /*
    * @Brief Setting list of handshake record
    * @param list of handshake record
    */
    virtual void SetHandShakeRecord(std::vector<std::pair <UI32, UI32>> handshake_list) = 0;

    /*
    * @Brief Setting self check memory range
    * @param list of self check memory range
    */
    virtual void SetSelfCheckMemRange(std::map<MEMADDR, UI32> memRange) = 0;

    /*
    * @Brief generate self check code that MAU accessed
    * @param pCB pointer to current code block
    */
    virtual void GenerateDCUSelfCheckCode(CCodeBlock *pCB, UI32 peid) = 0;

    /*
    * @Brief Generate handshake code between DCU and CPU
    * @param pCB pointer to current code block
    */
    virtual void GenerateDCUHandShakeCode(CCodeBlock *pCB, UI32 MBIN, UI32 MBOUT, UI32 peid) = 0;

    virtual std::string GetPEContext(UI32 peid) = 0;

public:

	/**
	 * @brief  このオブジェクトを生成します。
	 * @return ブロックマネージャオブジェクト
	 */
	static IBlockManager* New(LIST_INSSET*  ws);
};

struct TWorkMemory {
	TWorkMemory(): m_maxgpid(0) {
		SetCommonArea (0xfea00000);
		SetWorkArea (0xfea00400, 0xfea01400, 1, 1);
	}

	void SetCommonArea(UI32 ba) {
		BASE_COMMON			= ba;
	}
	void SetWorkArea(UI32 ba, UI32 ea, UI32 vmnum, UI32 htnum) {
		BASE_PE				= ba;
		BASE_WORK_END		= ea;
		m_vmnum				= vmnum;
		m_htnum				= htnum;
		//ReCalc();
	}
	void SetMachine(UI32 vmnum, UI32 htnum, UI32 maxGPID) {
		m_vmnum				= vmnum;
		m_htnum				= htnum;
		m_maxgpid           = maxGPID;
		ReCalc();
	}


	void ReCalc() {
		OFS_STACK_EI		= (OFS_SAVE_FE + SIZ_SAVE_FE);
		OFS_STACK_EI_ENTRY	= (OFS_STACK_EI + SIZ_STACK_EI);
		OFS_RANDAM_PTR		= (OFS_STACK_EI_ENTRY + SIZ_STACK_EI_ENTRY);
		OFS_ITLB_INFO		= (OFS_RANDAM_PTR + SIZ_RANDAM_PTR);

		BASE_PE_HT			= (BASE_PE + SIZE_PE_COMMON);
		SIZE_PE_HT			= (SIZE_HT * (m_htnum + 1));

		BASE_PE_VM			= (BASE_PE_HT  + SIZE_PE_HT);
		SIZE_PE_VM			= (SIZE_VM * (m_vmnum + 1));

		SIZE_PE				= (SIZE_PE_COMMON + SIZE_PE_HT + SIZE_PE_VM);

		DBTRAP_PC_INDEX	                = (BASE_PE + SIZE_PE + 1024 + 48) & (~0xf); // [FROG]TODO: Reserve for exception handler

		EXP_RET_PC_INDEX	            = DBTRAP_PC_INDEX + (m_maxgpid +1) *2048; // Align 16 bits 
		EXP_RET_PC_PRESET	            = EXP_RET_PC_INDEX + 4;

		BREAK_INFO_PRESET	            = EXP_RET_PC_PRESET + 16380; // ALign 16bit

		BACKUP_RESTORE_GM_RESOURCE      = BREAK_INFO_PRESET + 16;// Align 16 bits
		
		GM_TERMINATE_FLAG               = BACKUP_RESTORE_GM_RESOURCE + (m_maxgpid +1) * 660; //PC 4 + GRs 31*4 + SRs 36*4 + MPU 32*4*3 registers + MPCFG 1*4

		EXP_INT_TO_HOST_BACKUP_PC       = GM_TERMINATE_FLAG + (m_maxgpid +1) * 4; //Address 4 byte for each GM

        STORE_MPU_INFO                 = (EXP_INT_TO_HOST_BACKUP_PC + (m_maxgpid +1) * 4 + 15) & (~0xf); // Each PE has different address for PC backup. Need to align 16

        BASE_WR_INIT                    = STORE_MPU_INFO + (g_hwInfo->m_mpnum * 3 * 4) * (m_maxgpid + 1); //  Each entry has 3 regester (MPLA, MPUA, MPAT) and we need 4 byte for each one. CURRENTLY, MPU has two bank and 8 VM

        BASE_WR_PRESET                  = (BASE_WR_INIT + 512 + 15) & (~0xf);	// Wire register init range: 32*16 = 512 bytes. Need to align 16
	}

//HT
	UI32		m_vmnum;
	UI32		m_htnum;
	UI32		m_maxgpid;
	const	UI32	OFS_SAVE_FE		= 0;
	const	UI32	SIZ_SAVE_FE		= 0x080;
	UI32		OFS_STACK_EI;
	const	UI32	SIZ_STACK_EI		= 508;
	UI32		OFS_STACK_EI_ENTRY;
	const	UI32	SIZ_STACK_EI_ENTRY	= 4;
	UI32		OFS_RANDAM_PTR;
	const	UI32	SIZ_RANDAM_PTR		= 8;
	UI32		OFS_ITLB_INFO;
	const	UI32	SIZ_ITLB_INFO		= 4;
	const	UI32	SIZE_HT			= 1024; //= 8192;
//VM
	const	UI32	OFS_SAVE_DB		= 0;
	const	UI32	SIZ_SAVE_DB		= 0x080;
	const	UI32	SIZE_VM			= 1024; // = 4096;
//PE
	const	UI32	OFS_DTLB_INFO		= 0;
	const	UI32	SIZ_DTLB_INFO		= 64;
//----------------------------------------------------------------
	const UI32	SIZE_COMMON		= 1024;
	const UI32	SIZE_PE_COMMON		= 0;
	const UI32	SIZ_SYNCHRO_HT      = 16;

    const UI32		OFS_SYNCHRO_HT_COMPLETE  = 0;
    const UI32		SIZ_SYNCHRO_HT_COMPLETE  = 256;

    const UI32		OFS_SYNCHRO_HT_STANDBY  = OFS_SYNCHRO_HT_COMPLETE + SIZ_SYNCHRO_HT_COMPLETE ;
    const UI32		SIZ_SYNCHRO_HT_STANDBY  = 256;

    const UI32		OFS_SYNCHRO_PE_COMPLETE  = OFS_SYNCHRO_HT_STANDBY + SIZ_SYNCHRO_HT_STANDBY;
    const UI32		SIZ_SYNCHRO_PE_COMPLETE  = 16;

    const UI32		OFS_SYNCHRO_PE_STANDBY  = OFS_SYNCHRO_PE_COMPLETE + SIZ_SYNCHRO_PE_COMPLETE ;
    const UI32		SIZ_SYNCHRO_PE_STANDBY  = 16;

    const UI32		OFS_SYNCHRO_STANDBY  = OFS_SYNCHRO_PE_STANDBY + SIZ_SYNCHRO_PE_STANDBY ;
    const UI32		SIZ_SYNCHRO_STANDBY  = 1;

    const UI32		OFS_SYNCHRO_SKIP_PE_COMPLETE  = OFS_SYNCHRO_STANDBY + SIZ_SYNCHRO_STANDBY ;
    const UI32		SIZ_SYNCHRO_SKIP_PE_COMPLETE  = 1;

	UI32		BASE_COMMON;
	UI32 		BASE_PE; 	// PEが使用するアドレス先頭
	UI32		BASE_PE_HT;	// HTが使用する先頭サイズ
	UI32		SIZE_PE_HT; 	// HTが使用する全体サイズ
	UI32		BASE_PE_VM;	// VMが使用する先頭サイズ
	UI32		SIZE_PE_VM;	// VMが使用する全体サイズ 
	UI32		SIZE_PE;		// PEが使用する全体サイズ
	UI32		BASE_WR_INIT;	// Memory which is used to store init value of wire registers
	UI32		BASE_WR_PRESET;	// Wide register preset 
	UI32		BASE_WORK_END;
	UI32		DBTRAP_PC_INDEX;
	UI32		EXP_RET_PC_INDEX;
	UI32		EXP_RET_PC_PRESET;
	UI32		BREAK_INFO_PRESET;
	UI32		BACKUP_RESTORE_GM_RESOURCE;
	UI32		GM_TERMINATE_FLAG;
	UI32		EXP_INT_TO_HOST_BACKUP_PC;
    UI32		STORE_MPU_INFO;    // memory area to store MPU information that support initialize and reset exception

	void Dump() {
		std::cout << "--WORK INFO------------------------" << std::endl;
		std::cout << "BASE_COMMON : " << std::hex << BASE_COMMON << std::endl;
		std::cout << "BASE_PE     : " << std::hex << BASE_PE << std::endl;
		std::cout << "BASE_PE_HT  : " << std::hex << BASE_PE_HT << std::endl;
		std::cout << "SIZE_PE_HT  : " << std::hex << SIZE_PE_HT << std::endl; 
		std::cout << "BASE_PE_VM  : " << std::hex << BASE_PE_VM << std::endl;
		std::cout << "SIZE_PE_VM  : " << std::hex << SIZE_PE_VM << std::endl; 
		std::cout << "SIZE_PE     : " << std::hex << SIZE_PE << std::endl; 
        std::cout << "End of PE1  : " << std::hex << (BASE_PE + SIZE_PE - 1) << std::endl;

        std::cout << "DBTRAP_PC_INDEX  : " << std::hex << DBTRAP_PC_INDEX << std::endl;
        std::cout << "EXP_RET_PC_INDEX  : " << std::hex << EXP_RET_PC_INDEX << std::endl;
        std::cout << "EXP_RET_PC_PRESET     : " << std::hex << EXP_RET_PC_PRESET << std::endl;

        std::cout << "BREAK_INFO_PRESET  : " << std::hex << BREAK_INFO_PRESET << std::endl;
        std::cout << "BACKUP_RESTORE_GM_RESOURCE  : " << std::hex << BACKUP_RESTORE_GM_RESOURCE << std::endl;
        std::cout << "GM_TERMINATE_FLAG     : " << std::hex << GM_TERMINATE_FLAG << std::endl;
        std::cout << "EXP_INT_TO_HOST_BACKUP_PC  : " << std::hex << EXP_INT_TO_HOST_BACKUP_PC << std::endl;

        std::cout << "STORE_MPU_INFO  : " << std::hex << STORE_MPU_INFO << std::endl;
        std::cout << "BASE_WR_INIT     : " << std::hex << BASE_WR_INIT << std::endl;
		std::cout << "BASE_WR_PRESET: " << std::hex << BASE_WR_PRESET << std::endl;
		std::cout << "BASE_WORK_END: " << std::hex << BASE_WORK_END << std::endl;
		std::cout << "----------------------------------------" << std::endl;
	}
};

extern std::unique_ptr<CAddressWeight>	 g_LoadableAddr;
extern std::unique_ptr<CAddressWeight>	 g_StorableAddr;
extern std::unique_ptr<CAddressWeight>	 g_RmwAddr;
extern std::unique_ptr<TWorkMemory>      g_wm;
extern std::unique_ptr<ISimulatorHwInfo> g_hwInfo;

#endif /*IFBLK_MANAGER_H_*/
