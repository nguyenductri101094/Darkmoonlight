﻿#include    "ifinstruction.h"
#include    "rtg_app.h"

/**
* @brief  find register has constraint and register was updated value in simualte part
* @return operand index
*/
UI32 IInstruction::GetConstraintBit() {
    UI32 UseOpr = 0;
    std::for_each(m_vop.begin(), m_vop.end(), [&UseOpr](IOperand* p) {
        UseOpr |= p->GetConstraintBit();
    });
    return UseOpr;
}

/**
* @brief Get source register index in 32 bit flag format
* @return 32 bit flag
*/
REGFLG IInstruction::GetGrSrc() {
    REGFLG rf = 0;
    std::for_each(m_vop.begin(), m_vop.end(), [&rf](IOperand* p) {
        rf |= p->GetGrSrc();
    });
    return rf;
}

/**
* @brief  Get the destination register index in 32 bit flag format
* @return 32 bit flag
*/
REGFLG IInstruction::GetGrDst() {
    REGFLG rf = 0;
    std::for_each(m_vop.begin(), m_vop.end(), [&rf](IOperand* p) {
        rf |= p->GetGrDst();
    });
    return rf;
}

/**
* @brief  Get source register index in 32 bit flag format
* @return 32 bit flag
*/
REGFLG IInstruction::GetWrSrc() {
    REGFLG rf = 0;
    std::for_each(m_vop.begin(), m_vop.end(), [&rf](IOperand* p) {
        rf |= p->GetWrSrc();
    });
    return rf;
}

/**
* @brief  Get the destination register index in 32 bit flag format
* @return 32 bit flag
*/
REGFLG IInstruction::GetWrDst() {
    REGFLG rf = 0;
    std::for_each(m_vop.begin(), m_vop.end(), [&rf](IOperand* p) {
        rf |= p->GetWrDst();
    });
    return rf;
}

/**
* @brief This command is assembled.
* @param n opcode storage area
* @return instruction length(returns 0 on failure)
*/
UI32 IInstruction::Assemble(UI64* n) {
    // TODO:カプセル化する
    //extern IAssembler* g_asm;
    UI32 len = g_asm->Asm(GetCode().c_str(), n);
    if (len == 0) {
        MSG_ERROR(0, "Fail to assemble \"%s\"\n", GetCode().c_str());
    }
    return len;
}

/**
* @brief Current instruction has async label or not (assert and deassert)
*/
bool IInstruction::HasAsyncLabel() {
    for (size_t s = 0; s < m_vdr.size(); s++) {
        if (m_vdr[s]->GetAsyncLabel() != NULL) {
            return true;
        }
    }
    return false;
}

/**
* @brief Current instruction has deassert async label or not
*/
bool IInstruction::HasDeassertAsyncLabel() {
    for (size_t s = 0; s < m_vdr.size(); s++) {
        CAsyncLabel *pAsyncLabel = static_cast<CAsyncLabel*>(m_vdr[s]->GetAsyncLabel());
        if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert == false) {
            return true;
        }
    }
    return false;
}

/**
* @brief Current instruction has assert async label or not
*/
bool IInstruction::HasAssertLabel() {
    for (size_t s = 0; s < m_vdr.size(); s++) {
        CAsyncLabel *pAsyncLabel = static_cast<CAsyncLabel*>(m_vdr[s]->GetAsyncLabel());
        if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert == true) {
            return true;
        }
    }
    return false;
}

/**
* @brief clear all async of current instruction
*/
void IInstruction::ClearAsync() {
    std::vector<IDirective*>::iterator itr = m_vdr.begin();
    while (itr < m_vdr.end()) {
        if ((*itr)->GetAsyncLabel() != NULL) {
            delete (*itr);
            itr = m_vdr.erase(itr);
        } else
            itr++;
    }
}

/**
* @brief Get instruction length.
* @return instruction length
*/
UI32 IInstruction::GetLen() {
    if (m_len == 0) {
        if (m_oldcode == "") m_oldcode = this->GetCode();
        m_len = Assemble(&m_code);
    } else if (m_oldcode != this->GetCode()) {
        m_oldcode = this->GetCode();
        m_len = Assemble(&m_code);
    }
    return m_len;
}


/**
* @brief Get the op code of this instruction.
* @return opcode
*/
UI64 IInstruction::Fetch() {
    if (m_len == 0) {
        if (m_oldcode == "") m_oldcode = this->GetCode();
        m_len = Assemble(&m_code);
    } else if (m_oldcode != this->GetCode()) {
        m_oldcode = this->GetCode();
        m_len = Assemble(&m_code);
    }
    return m_code;
}


/**
* @brief Acquires correction information for each operand of this instruction.
* @param pReg verification information(see In / Out parameter class)
*/
void IInstruction::Regulate(IRegulation* pReg) {
    // 各オペランドについて制約をチェック
    for (UI32 i = 0; i < GetOpNum(); i++) {
        IOperand* popr = opr(i);
        _ASSERT(popr);
        popr->Regulate(pReg);
    }
}

/**
* @brief Move the directive information to the specified instruction instance
* @param instruction instance
*/
void IInstruction::DirMoveTo(IInstruction* pIns) {
    std::vector<IDirective*>::iterator itr = m_vdr.begin();
    CAsyncLabel *pAsyncLabel;
    while (itr < m_vdr.end()) {
        pAsyncLabel = static_cast<CAsyncLabel*>((*itr)->GetAsyncLabel());
        if (pAsyncLabel == NULL || pAsyncLabel->m_bAssert == false) {
            pIns->SetDirective(*itr);
            itr = m_vdr.erase(itr);
        } else
            itr++;
    }

    pIns->SetInLoop(this->InLoop());
}

/**
* @brief Move async label from current instruction to pIns instruction
*/
void IInstruction::AsyncMoveTo(IInstruction *pIns) {
    std::vector<IDirective*>::iterator itr = m_vdr.begin();
    while (itr < m_vdr.end()) {
        if ((*itr)->GetAsyncLabel() != NULL) {
            pIns->SetDirective(*itr);
            itr = m_vdr.erase(itr);
        } else
            itr++;
    }
}

void IInstruction::OnlyDirMoveTo(IInstruction* pIns) {
    std::vector<IDirective*>::iterator itr = m_vdr.begin();
    CAsyncLabel *pAsyncLabel;
    while (itr < m_vdr.end()) {
        pAsyncLabel = static_cast<CAsyncLabel*>((*itr)->GetAsyncLabel());
        if (pAsyncLabel == NULL) {
            pIns->SetDirective(*itr);
            itr = m_vdr.erase(itr);
        } else
            itr++;
    }

    pIns->SetInLoop(this->InLoop());
}

/**
* @brief Remove mismatch register in instruction
* @param MismatchRegSet list of register mismatch
*/
void IInstruction::RemoveRegInList(UI32 MismatchRegSet, UI32 MismatchEntrySet) {
    UI32 nValidRegList = ~MismatchRegSet & 0xfffffffe; // Exclude r0
    UI32 nInValidRegList = MismatchRegSet;
    bool bResult = true;

    if (MismatchRegSet == 0)
        return;

    // Calculate msk for list12 operand
    UI32 msk_list12 = CToolFnc::ConvertRegListToList12(MismatchRegSet);
    msk_list12 = ~msk_list12;

    // Replace general registers
    if (this->GetGrSrc() & MismatchRegSet) {
       
        IOperand *pOpr;
        if (this->GetId() == INS_ID_PUSHSP) {
            std::vector<std::vector<UI32>> vReglist;
            std::vector<UI32> vReg;
            for (UI32 i = 1; i < 32; i++) {
                if ((nValidRegList >> i) & 1) {
                    vReg.push_back(i);

                } else if (vReg.size() > 0) {
                    vReglist.push_back(vReg);
                    vReg.clear();
                }
            }
            if(vReg.size() > 0) vReglist.push_back(vReg);

            UI32 pos = g_rnd.GetRange(0U, (UI32)vReglist.size() - 1);
            vReg = vReglist[pos];
            UI32 rh = g_rnd.GetRange(0U, (UI32)vReg.size() - 1);
            UI32 rt = g_rnd.GetRange(rh, (UI32)vReg.size() - 1);
            bResult &= this->opr(0)->Replace(vReg[rh]);
            bResult &= this->opr(1)->Replace(vReg[rt]);
        } else {
            for (UI32 op = 0; op < this->GetOpNum(); op++) {
                pOpr = this->opr(op);
                if (this->GetMne() == "prepare" && this->opr(0) == pOpr) {
                    // 1st operand of prepare is List12
                    UI32 list12 = (UI32)*pOpr;
                    // Remove all violated bits
                    list12 &= msk_list12;
                    if (pOpr->Replace(list12) == false) {
                        bResult &= false;
                    }
                }

                if (pOpr->Attr(IOperand::OPR_ATTR_GR) == false || pOpr->Attr(IOperand::OPR_ATTR_SRC) == false)
                    continue;

                if ((pOpr->GetGrSrc() & MismatchRegSet) == 0) {
                    continue;
                }
               
                bResult &= pOpr->ReplaceIdxFromList(nValidRegList);
            }
        }
    }

    // Destination of LD instruction can be mismatch. In case this instruction belong to loop sequence, let replace it
    if (/*this->InLoop() && */this->Behavior(IInstruction::LOAD_MEMORY) && (this->GetGrDst() & ~MismatchRegSet)) {
        IOperand *pOpr;
        if (this->GetId() == INS_ID_POPSP) {
            std::vector<UI32> vReg;
            for (UI32 i = 1; i < 32; i++) {
                if (((MismatchRegSet >> i) & 1)) {
                    vReg.push_back(i);
                }
            }

            UI32 rt = g_rnd.GetRange(0U, (UI32)vReg.size() - 1);
            bResult &= this->opr(0)->Replace(vReg[0]);
            bResult &= this->opr(1)->Replace(vReg[rt]);
        }
        for (UI32 op = 0; op < this->GetOpNum(); op++) {
            pOpr = this->opr(op);
            if (this->GetMne() == "dispose" && this->opr(1) == pOpr) {
                // 2nd operand of dipose is List12
                UI32 list12 = (UI32)*pOpr;
                // Remove all violated bits
                list12 &= ~msk_list12;
                if (pOpr->Replace(list12) == false) {
                    bResult &= false;
                }
            }
            /* Checked: RW operand of CAXI and STC.X should be matched register. Don't replace by this condition */
            if (pOpr->Attr(IOperand::OPR_ATTR_GR) && pOpr->Attr(IOperand::OPR_ATTR_SRC) == false && (pOpr->GetGrDst() & ~MismatchRegSet)) {
                bResult &= pOpr->ReplaceIdxFromList(nInValidRegList);
            }
        }
    }

    // Limitation. Does not generate disposej imm, list12, [reg]. reg belong to list12
    if (this->GetId() == INS_ID_DISPOSE_R3) {
        IOperand *pOpr = this->opr(1);
        // 2nd operand of dipose is List12
        UI32 list12 = (UI32)*pOpr;
        list12 &= ~(1 << this->opr(2)->Idx());
        if (pOpr->Replace(list12) == false)
            this->opr(2)->Replace(g_rnd.GetRange(4, 19));

        this->AppendComment("Remove disposej reg in list12 ");
    }

    // Replace wide-register of FP-SIMD instruction
    if ((this->Category(IInstruction::ICAT_FPU_S) && this->Category(IInstruction::ICAT_SIMD))) {
        IOperand *pOpr;
        for (UI32 op = 0; op < this->GetOpNum(); op++) {
            pOpr = this->opr(op);
            if (this->Behavior(IInstruction::LOAD_MEMORY) && pOpr->Attr(IOperand::OPR_ATTR_WR) && pOpr->Attr(IOperand::OPR_ATTR_DST)) {
                if (((1 << pOpr->Idx()) & MismatchRegSet) == 0) {
                    bResult &= pOpr->ReplaceIdxFromList(nInValidRegList);
                }
                if (pOpr->Attr(IOperand::OPR_ATTR_SRC)) {
                    continue;
                }
            }

            if (pOpr->Attr(IOperand::OPR_ATTR_WR) && pOpr->Attr(IOperand::OPR_ATTR_SRC)) {
                if (pOpr->GetWrSrc() & MismatchRegSet) {
                    bResult &= pOpr->ReplaceIdxFromList(nValidRegList);
                }
            }
        }
    }
    // Replace same GRs/WRs in sourc and dest of STORE instruction
    if (this->Behavior(IInstruction::STORE_MEMORY) && this->GetId() != INS_ID_PUSHSP) {
        IOperand *pOpr;
        UI32 regValBit = 0;
        for (UI32 op = 0; op < this->GetOpNum(); op++) {
            pOpr = this->opr(op);
            UI32 oldIdx = ((pOpr->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << pOpr->Idx());
            if (pOpr->GetConstraint() == nullptr && oldIdx != 1) // bit 0
                regValBit |= oldIdx;
            // Checked same register: st.b r14,0x1180[r14]
            while (regValBit & this->GetConstraintBit()) {
                pOpr->ReplaceIdxFromList(nValidRegList);
                regValBit &= ~(oldIdx); // Clear old idx
                regValBit |= ((pOpr->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << pOpr->Idx()); // Set new idx
            }
        }
    }
    // 
    if (this->GetId() == INS_ID_STM_MP) {
        IOperand *pStartEntryOpr = this->opr(0);
        IOperand *pEndEntryOpr = this->opr(1);
        UI32 mpu_num = g_hwInfo->m_mpnum - 1;
        if (pEndEntryOpr->Idx() >= pStartEntryOpr->Idx()) {
            std::vector<UI32> vReg;
            UI32 newStartEntry = 0, newEndEntry = 0;
            for (UI32 i = 0; i <= mpu_num; i++) {
                if (((MismatchEntrySet >> i) & 1)) {
                    vReg.push_back(i);
                }
            }
            UI32 startMismatchEntry = vReg.front();
            UI32 endMismatchEntry = vReg.back();
            if (startMismatchEntry == 0 || endMismatchEntry == mpu_num) {
                if (endMismatchEntry < mpu_num) {
                    newStartEntry = g_rnd.GetRange((UI32)(endMismatchEntry + 1), (UI32)mpu_num);
                    newEndEntry = g_rnd.GetRange((UI32)newStartEntry, (UI32)mpu_num);
                } else if (startMismatchEntry > 0) {
                    newEndEntry = g_rnd.GetRange((UI32)0, (UI32)(startMismatchEntry - 1));
                    newStartEntry = g_rnd.GetRange((UI32)0, (UI32)newEndEntry);
                } else {
                    std::runtime_error excep("Fail calculate entry of LDM.MP/STM.MP\n ");
                    throw excep;
                }
            } else {
                if (g_rnd.GetRange(0, 1)) {
                    newEndEntry = g_rnd.GetRange((UI32)0, (UI32)(startMismatchEntry - 1));
                    newStartEntry = g_rnd.GetRange((UI32)0, (UI32)newEndEntry);
                } else {
                    newStartEntry = g_rnd.GetRange((UI32)(endMismatchEntry + 1), (UI32)mpu_num);
                    newEndEntry = g_rnd.GetRange((UI32)newStartEntry, (UI32)mpu_num);
                }
            }
            if (newStartEntry > newEndEntry) {
                MSG_ERROR(0, "Calculate entry of LDM.MP/STM.MP is wrong \"%s\"   \"%s\"  newStartEntry = %d ; newEndEntry = %d \n", this->GetCode().c_str(), this->GetComment().c_str(), newStartEntry, newEndEntry);
                std::runtime_error excep("Calculate entry of LDM.MP/STM.MP is wrong\n ");
                throw excep;
            }
            pStartEntryOpr->Replace(newStartEntry);
            pEndEntryOpr->Replace(newEndEntry);
        }
    } else if (this->GetId() == INS_ID_LDM_MP) {
        IOperand *pStartEntryOpr = this->opr(1);
        IOperand *pEndEntryOpr = this->opr(2);
        bResult &= pStartEntryOpr->ReplaceIdxFromList(MismatchEntrySet);
        bResult &= pEndEntryOpr->ReplaceIdxFromList(MismatchEntrySet);
    }

    if (bResult == false) {
        MSG_ERROR(0, "Can not replace resource of \"%s\"   \"%s\" \n", this->GetCode().c_str(), this->GetComment().c_str());
        std::runtime_error excep("Can not replace resource\n ");
        throw excep;
    }
}

/**
* @ brief MPXINFO register MPX architecture configuration information RSIZE bit inquiry function
* @return For Full : true
*/
bool IInstruction::IsMPX4Full(void) {

    FrogRegData mpx_info = (FrogRegData)0;
    UI32	is_NM, success;
    UI32 tcid = 0; // TODO: Support multi-thread

    gcs_is_simulator_native(&is_NM);
    if (is_NM == 0x01) {
        success = gcs_get_nc_register("FXINFO", &mpx_info);
    } else {
        success = gcs_get_tc_register("FXINFO", &mpx_info, tcid);
    }
    if (GCSIF_SUCCESS != success) {
        //TODO: Output error message
        return (false);
    }

    return ((UI32)mpx_info != 1);

}