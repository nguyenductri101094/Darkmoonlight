#ifndef WEIGHT_PARSER_H_
#define WEIGHT_PARSER_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"

/**
 * @brief	重み設定ファイルの要素オブジェクト
 */
class CWeightItem {
public:
CWeightItem( UI32 line_no
			,UI32 vals
			,std::string key_name
			,std::string val_1
			,std::string val_2
			,std::string val_3
			,std::string val_4
			,std::string val_5
			,std::string val_6
			,std::string val_7
			,std::string val_8
			,std::string val_9 )
	: m_line_no(line_no)
	, m_vals(vals)
	, m_key_name(key_name)
	, m_val_1(val_1)
	, m_val_2(val_2)
	, m_val_3(val_3)
	, m_val_4(val_4)
	, m_val_5(val_5)
	, m_val_6(val_6)
	, m_val_7(val_7)
	, m_val_8(val_8)
	, m_val_9(val_9) {}
	~CWeightItem(){}
public:
	UI32 m_line_no ;
	UI32 m_vals ;
	std::string m_key_name ;	//!< 第１トークン
	std::string m_val_1 ;		//!< 第２トークン
	std::string m_val_2 ;		//!< 第３トークン
	std::string m_val_3 ;		//!< 第４トークン
	std::string m_val_4 ;		//!< 第５トークン
	std::string m_val_5 ;		//!< 第６トークン
	std::string m_val_6 ;		//!< 第７トークン
	std::string m_val_7 ;		//!< 第８トークン
	std::string m_val_8 ;		//!< 第９トークン
	std::string m_val_9 ;		//!< 第１０トークン
};


/**
 * @brief	重み設定ファイルのセクションオブジェクト
 */
class CWeightList {
public:
	CWeightList(): m_WeightList() {}
	~CWeightList() {
		std::vector<CWeightItem*>::iterator itr;
		for (itr = m_WeightList.begin(); itr != m_WeightList.end(); itr++) {
			delete *itr;
		}
	}

	/**
	 * @brief	セクションオブジェクトに要素オブジェクトを追加する
	 */
	void Set( UI32 line_no
			, UI32 vals
			, std::string key_name 
			, std::string val_1
			, std::string val_2 = ""
			, std::string val_3 = ""
			, std::string val_4 = ""
			, std::string val_5 = ""
			, std::string val_6 = ""
			, std::string val_7 = ""
			, std::string val_8 = ""
			, std::string val_9 = "" )
	{
		m_WeightList.push_back(new CWeightItem( line_no ,vals ,key_name , val_1 , val_2 , val_3 , val_4 , val_5 , val_6 , val_7 , val_8 , val_9 )) ;
	}

	std::vector<CWeightItem*> m_WeightList ;
};

#endif /*WEIGHT_PARSER_H_*/
