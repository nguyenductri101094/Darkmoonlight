#ifndef		RTG_MACROS_H_
#define		RTG_MACROS_H_

#define		_ASSERT(_cond_)				assert(_cond_)
#define		FROG_ASSERT(_cond_)			assert(_cond_)

#define		APP_RETURN_OK				(0U)
#define		APP_INVALID_PARAM			(~1U)
#define		APP_INTERNAL_ERROR			(~2U)

#define		BASE_WEIGHT					60

// Macro for strings-build-in-source
#ifndef XSTR
#define	XSTR(str)						DSTR(str)
#ifndef	DSTR
#define DSTR(str)						#str
#endif
#endif


// Console control codes
#define		COUT_REVERSE				("\x1b[7m")
#define 	COUT_RED        			("\x1b[1;31m")
#define 	COUT_GREEN      			("\x1b[1;32m")
#define 	COUT_YELLOW     			("\x1b[1;33m")
#define 	COUT_BLUE       			("\x1b[1;34m")
#define		COUT_MAGENTA				("\x1b[1;35m")
#define 	COUT_BRIGHT     			("\x1b[1m")
#define 	COUT_UNDERLINE  			("\x1b[4m")
#define 	COUT_RESET      			("\x1b[0m")

#define     HOST_ENTRY                 (8)
#define     CONVENTION_ENTRY           (9)
// DEBUG
#ifdef		NDEBUG
#define		RELMODE						1
#else
#define		DBGMODE						1
#endif

#endif	// RTG_MACROS_H_
