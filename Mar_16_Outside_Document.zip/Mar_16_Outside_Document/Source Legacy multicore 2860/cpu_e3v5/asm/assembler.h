#ifndef ASSEMBLER_H_
#define ASSEMBLER_H_

#include	"rtg_common.h"
#include	"ifassembler.h"
//extern "C"{
#include	"libccg-v850.h"
//}

/**
 * @brief 命令アセンブル機能を提供するクラスです。
 *        IAssemblerを実装します。
 */
class CAssembler : public IAssembler
{
public:

	/**
	 * @brief このオブジェクトを構築します。
	 */
	CAssembler();

	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~CAssembler();

	/**
	 * @brief インスタンスを初期化します。
	 * @param param エンディアンを指定。
	 */
	virtual void Init(IASM_ENDIAN param);

	/**
	 * @brief 渡された命令文をアセンブルし、オペコード領域に格納します。
	 *        アセンブルが成功した場合、命令長を返します。
	 * @param str     命令文
	 * @param opecode オペコード領域
	 * @return 命令長(失敗時は０を返す)
	 */
	virtual UI32 Asm(LPCTSTR str, UI64* opecode);
	virtual UI32 Disasm(LPSTR str, UI64 opecode);
protected:
};

#endif /*IFASSEMBLER_H_*/

