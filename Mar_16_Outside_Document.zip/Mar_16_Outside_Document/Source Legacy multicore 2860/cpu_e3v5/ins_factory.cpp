// ---------------------------------------------------------------------------
// This file was automatically generated
//     by "./mk_factory.pl"
//     on  Thu Nov 22 13:55:51 2012
// ---------------------------------------------------------------------------

#include		"adr_selector.h"
#include        "insid_set.h"

#define GET_IRAM_HEAD()		(0x00000000)
#define GET_IRAM_TAIL()		(0xFEEFFFFF)
#define GET_STORE_HEAD()	(0x00000000)
#define GET_STORE_TAIL()	(0xFEEFFFFF)
#define GET_LOAD_HEAD()		(0x00000000)
#define GET_LOAD_TAIL()		(0xFEEFFFFF)
#define GET_RMW_HEAD()		(0x00000000)
#define GET_RMW_TAIL()		(0xFEEFFFFF)

IInstruction* CInstructionSet::CreateIns(INS_ID insid) {

	IInstruction* pIns = NULL;
	IInstruction* pNot = NULL;

	switch (insid) {
	case 1:
		pIns = new CIns_1_add();
		break;

	case 2:
		pIns = new CIns_2_add();
		break;

	case 3:
		pIns = new CIns_3_addi();
		break;

	case 4:
		pIns = new CIns_4_adf();
		break;

	case 5:
		pIns = new CIns_5_and();
		break;

	case 6:
		pIns = new CIns_6_andi();
		break;

	// Bcond ブランチ命令
	// ------------------------------------------------------------------------------------------
	//       反対命令を用意しておく(Taken/NotTakenどちらかを使うことで好きな方に制御させることが出来る)
	//       br(必ずジャンプ)は反対命令をNOPとする。
	//       bsaは反対命令が存在しない。
	case 7:
		pIns = new CIns_7_bc();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));

		pNot = new CIns_17_bnc();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 8:
		pIns = new CIns_8_be();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));

		pNot = new CIns_18_bne();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 9:
		pIns = new CIns_9_bf();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));

		pNot = new CIns_26_bt();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 10:
		pIns = new CIns_10_bge();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_15_blt();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 11:
		pIns = new CIns_11_bgt();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_13_ble();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 12:
		pIns = new CIns_12_bh();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_19_bnh();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 13:
		pIns = new CIns_13_ble();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_11_bgt();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 14:
		pIns = new CIns_14_bl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_20_bnl();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 15:
		pIns = new CIns_15_blt();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_10_bge();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 16:
		pIns = new CIns_16_bn();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_23_bp();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;
		
	case 17:
		pIns = new CIns_17_bnc();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_7_bc();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 18:
		pIns = new CIns_18_bne();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_8_be();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 19:
		pIns = new CIns_19_bnh();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_12_bh();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 20:
		pIns = new CIns_20_bnl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_14_bl();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 21:
		pIns = new CIns_21_bnv();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_27_bv();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 22:
		pIns = new CIns_22_bnz();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_28_bz();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 23:
		pIns = new CIns_23_bp();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_16_bn();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 24:
		pIns = new CIns_24_br();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));

		// NOPを反対命令とする
		pNot = new CIns_115_nop();
		pIns->SetReverse( pNot );
		break;

	case 25:
		pIns = new CIns_25_bsa();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_85_jr();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 26:
		pIns = new CIns_26_bt();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_9_bf();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 27:
		pIns = new CIns_27_bv();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_21_bnv();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 28:
		pIns = new CIns_28_bz();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_22_bnz();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;
		
	// 32bit cond
	case 29:
		pIns = new CIns_29_bc();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_39_bnc();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 30:
		pIns = new CIns_30_be();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_40_bne();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 31:
		pIns = new CIns_31_bf();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_47_bt();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 32:
		pIns = new CIns_32_bge();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_37_blt();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 33:
		pIns = new CIns_33_bgt();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_35_ble();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 34:
		pIns = new CIns_34_bh();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_41_bnh();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 35:
		pIns = new CIns_35_ble();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_33_bgt();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 36:
		pIns = new CIns_36_bl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_42_bnl();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 37:
		pIns = new CIns_37_blt();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_32_bge();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 38:
		pIns = new CIns_38_bn();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_45_bp();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 39:
		pIns = new CIns_39_bnc();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_29_bc();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 40:
		pIns = new CIns_40_bne();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_30_be();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 41:
		pIns = new CIns_41_bnh();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_34_bh();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 42:
		pIns = new CIns_42_bnl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_36_bl();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 43:
		pIns = new CIns_43_bnv();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_48_bv();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 44:
		pIns = new CIns_44_bnz();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_49_bz();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 45:
		pIns = new CIns_45_bp();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_38_bn();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 46:
		pIns = new CIns_46_bsa();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));

		pNot = new CIns_85_jr();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 47:
		pIns = new CIns_47_bt();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_31_bf();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 48:
		pIns = new CIns_48_bv();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_43_bnv();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 49:
		pIns = new CIns_49_bz();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		
		pNot = new CIns_44_bnz();
		pNot->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));		
		pIns->SetReverse( pNot );
		break;

	case 50:
		pIns = new CIns_50_bins();
		break;

	case 51:
		pIns = new CIns_51_bsh();
		break;

	case 52:
		pIns = new CIns_52_bsw();
		break;

	case 53:
		pIns = new CIns_53_callt();
		break;

	case 54:
		pIns = new CIns_54_caxi();
		pIns->opr(0)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x03, 4 ));
		break;

	case 55:
		pIns = new CIns_55_cll();
		break;

	case 56:
		pIns = new CIns_56_clr1();
		pIns->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 57:
		pIns = new CIns_57_clr1();
		pIns->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 58:
		pIns = new CIns_58_cmov();
		break;

	case 59:
		pIns = new CIns_59_cmov();
		break;

	case 60:
		pIns = new CIns_60_cmp();
		break;

	case 61:
		pIns = new CIns_61_cmp();
		break;

	case 62:
		pIns = new CIns_62_ctret();

		pNot = new CIns_115_nop();
		pIns->SetReverse( pNot );
		break;

	case 63:
		pIns = new CIns_63_di();
		break;

	case 64: 
		pIns = new CIns_64_dispose();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 4));
		break;

	case 65:
		pIns = new CIns_65_dispose();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 4));
		
		pNot = new CIns_115_nop();
		pIns->SetReverse( pNot );
	
		break;

	case 66:
		pIns = new CIns_66_div();
		break;

	case 67:
		pIns = new CIns_67_divh();
		break;

	case 68:
		pIns = new CIns_68_divh();
		break;

	case 69:
		pIns = new CIns_69_divhu();
		break;

	case 70:
		pIns = new CIns_70_divq();
		break;

	case 71:
		pIns = new CIns_71_divqu();
		break;

	case 72:
		pIns = new CIns_72_divu();
		break;

	case 73:
		pIns = new CIns_73_ei();
		break;

	case 74:
		pIns = new CIns_74_eiret();
		pNot = new CIns_115_nop();
		pIns->SetReverse( pNot );
		break;

	case 75:
		pIns = new CIns_75_feret();
		pNot = new CIns_115_nop();
		pIns->SetReverse( pNot );
		break;

	case 76:
		pIns = new CIns_76_fetrap();
		break;

	case 77:
		pIns = new CIns_77_halt();
		break;

	case 78:
		pIns = new CIns_78_hsh();
		break;

	case 79:
		pIns = new CIns_79_hsw();
		break;

	case 80:
		pIns = new CIns_80_jarl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));

		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 81:
		pIns = new CIns_81_jarl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 82:
		pIns = new CIns_82_jarl();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 83:
		pIns = new CIns_83_jmp();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 84:
		pIns = new CIns_84_jmp();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 85:
		pIns = new CIns_85_jr();
		pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 86:
		pIns = new CIns_86_jr();
		//pIns->opr(0)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		pNot = new CIns_115_nop();				
		pIns->SetReverse( pNot );
		break;

	case 87:
		pIns = new CIns_87_ld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 88:
		pIns = new CIns_88_ld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 89:
		pIns = new CIns_89_ld_bu();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 90:
		pIns = new CIns_90_ld_bu();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 91:
		pIns = new CIns_91_ld_dw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break;

	case 92:
		pIns = new CIns_92_ld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 93:
		pIns = new CIns_93_ld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 94:
		pIns = new CIns_94_ld_hu();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 95:
		pIns = new CIns_95_ld_hu();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 96:
		pIns = new CIns_96_ld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 97:
		pIns = new CIns_97_ld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 98:
		pIns = new CIns_98_ldl_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 99:
		pIns = new CIns_99_ldsr();
		break;

	case 100:
		pIns = new CIns_100_loop();
		pIns->opr(1)->SetConstraint(new ILoadConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL(), 0x01, 2, (1<<IValConstraint::FETCH) ));
		break;

	case 101:
		pIns = new CIns_101_mac();
		break;

	case 102:
		pIns = new CIns_102_macu();
		break;

	case 103:
		pIns = new CIns_103_mov();
		break;

	case 104:
		pIns = new CIns_104_mov();
		break;

	case 105:
		pIns = new CIns_105_mov();
		break;

	case 106:
		pIns = new CIns_106_movea();
		break;

	case 107:
		pIns = new CIns_107_movhi();
		break;

	case 108:
		pIns = new CIns_108_mul();
		break;

	case 109:
		pIns = new CIns_109_mul();
		break;

	case 110:
		pIns = new CIns_110_mulh();
		break;

	case 111:
		pIns = new CIns_111_mulh();
		break;

	case 112:
		pIns = new CIns_112_mulhi();
		break;

	case 113:
		pIns = new CIns_113_mulu();
		break;

	case 114:
		pIns = new CIns_114_mulu();
		break;

	case 115:
		pIns = new CIns_115_nop();
		break;

	case 116:
		pIns = new CIns_116_not();
		break;

	case 117:
		pIns = new CIns_117_not1();
		pIns->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 118:
		pIns = new CIns_118_not1();
		pIns->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 119:
		pIns = new CIns_119_or();
		break;

	case 120:
		pIns = new CIns_120_ori();
		break;

	case 121:
		pIns = new CIns_121_popsp();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 4));
		break;

	case 122:
		pIns = new CIns_122_prepare();
		pIns->opr(0)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 4));
		break;

	case 123:
		pIns = new CIns_123_prepare();
		pIns->opr(0)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 4));
		break;

	case 124:
		pIns = new CIns_124_prepare();
		pIns->opr(0)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 4));
		break;

	case 125:
		pIns = new CIns_125_prepare();
		pIns->opr(0)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 4));
		break;

	case 126:
		pIns = new CIns_126_pushsp();
		pIns->opr(0)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 4));
		break;

	case 127:
		pIns = new CIns_127_rie();
		break;

	case 128:
		pIns = new CIns_128_rie();
		break;

	case 129:
		pIns = new CIns_129_rotl();
		break;

	case 130:
		pIns = new CIns_130_rotl();
		break;

	case 131:
		pIns = new CIns_131_sar();
		break;

	case 132:
		pIns = new CIns_132_sar();
		break;

	case 133:
		pIns = new CIns_133_sar();
		break;

	case 134:
		pIns = new CIns_134_sasf();
		break;

	case 135:
		pIns = new CIns_135_satadd();
		break;

	case 136:
		pIns = new CIns_136_satadd();
		break;

	case 137:
		pIns = new CIns_137_satadd();
		break;

	case 138:
		pIns = new CIns_138_satsub();
		break;

	case 139:
		pIns = new CIns_139_satsub();
		break;

	case 140:
		pIns = new CIns_140_satsubi();
		break;

	case 141:
		pIns = new CIns_141_satsubr();
		break;

	case 142:
		pIns = new CIns_142_sbf();
		break;

	case 143:
		pIns = new CIns_143_sch0l();
		break;

	case 144:
		pIns = new CIns_144_sch0r();
		break;

	case 145:
		pIns = new CIns_145_sch1l();
		break;

	case 146:
		pIns = new CIns_146_sch1r();
		break;

	case 147:
		pIns = new CIns_147_set1();
		pIns->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 148:
		pIns = new CIns_148_set1();
		pIns->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 149:
		pIns = new CIns_149_setf();
		break;

	case 150:
		pIns = new CIns_150_shl();
		break;

	case 151:
		pIns = new CIns_151_shl();
		break;

	case 152:
		pIns = new CIns_152_shl();
		break;

	case 153:
		pIns = new CIns_153_shr();
		break;

	case 154:
		pIns = new CIns_154_shr();
		break;

	case 155:
		pIns = new CIns_155_shr();
		break;

	case 156:
		pIns = new CIns_156_sld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 157:
		pIns = new CIns_157_sld_bu();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 158:
		pIns = new CIns_158_sld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 159:
		pIns = new CIns_159_sld_hu();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 160:
		pIns = new CIns_160_sld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 161:
		pIns = new CIns_161_snooze();
		break;

	case 162:
		pIns = new CIns_162_sst_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 163:
		pIns = new CIns_163_sst_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 164:
		pIns = new CIns_164_sst_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 165:
		pIns = new CIns_165_st_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 166:
		pIns = new CIns_166_st_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 167:
		pIns = new CIns_167_st_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 168:
		pIns = new CIns_168_st_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 169:
		pIns = new CIns_169_st_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 170:
		pIns = new CIns_170_st_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 171:
		pIns = new CIns_171_st_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 172:
		pIns = new CIns_172_stc_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 173:
		pIns = new CIns_173_stsr();
		break;

	case 174:
		pIns = new CIns_174_sub();
		break;

	case 175:
		pIns = new CIns_175_subr();
		break;

	case 176:
		pIns = new CIns_176_switch();
		break;

	case 177:
		pIns = new CIns_177_sxb();
		break;

	case 178:
		pIns = new CIns_178_sxh();
		break;

	case 179:
		pIns = new CIns_179_synce();
		break;

	case 180:
		pIns = new CIns_180_synci();
		break;

	case 181:
		pIns = new CIns_181_syncm();
		break;

	case 182:
		pIns = new CIns_182_syncp();
		break;

	case 183:
		pIns = new CIns_183_syscall();
		break;

	case 184:
		pIns = new CIns_184_trap();
		break;

	case 185:
		pIns = new CIns_185_tst();
		break;

	case 186:
		pIns = new CIns_186_tst1();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1 ));
		break;

	case 187:
		pIns = new CIns_187_tst1();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1 ));
		break;

	case 188:
		pIns = new CIns_188_xor();
		break;

	case 189:
		pIns = new CIns_189_xori();
		break;

	case 190:
		pIns = new CIns_190_zxb();
		break;

	case 191:
		pIns = new CIns_191_zxh();
		break;

	case 192:
		pIns = new CIns_192_hvcall();
		break;

	case 193:
		{
		pIns = new CIns_193_hvtrap();
		UI32 causeCode = (UI32) *(pIns->opr(0));;
		while ((causeCode == 0x1e && g_mgr->EnabelHVTRAPFor(INS_CID_CHANGE_MODE))
			|| ((causeCode <= 0x7) && g_mgr->EnabelHVTRAPFor(INS_CID_CHANGE_VMACHINE))) {

			pIns->opr(0)->ReFix();
		    causeCode = (UI32) *(pIns->opr(0));
		}
		break;
		}
	case 194:
		pIns = new CIns_194_ldvc_sr();
		break;

	case 195:
		pIns = new CIns_195_stvc_sr();
		break;

	case 196:
		pIns = new CIns_196_dst();
		break;

	case 197:
		pIns = new CIns_197_est();
		break;

	case 198:
		pIns = new CIns_198_ldtc_gr();
		break;

	case 199:
		pIns = new CIns_199_ldtc_vr();
		break;

	case 200:
		pIns = new CIns_200_ldtc_pc();
		break;

	case 201:
		pIns = new CIns_201_ldtc_sr();
		break;

	case 202:
		pIns = new CIns_202_sttc_gr();
		break;

	case 203:
		pIns = new CIns_203_sttc_vr();
		break;

	case 204:
		pIns = new CIns_204_sttc_pc();
		break;

	case 205:
		pIns = new CIns_205_sttc_sr();
		break;

	case 206:
		pIns = new CIns_206_cache();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1 ));
		break;

	case 207:
		pIns = new CIns_207_pref();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		break;

	case 208:
		pIns = new CIns_208_tlbai();
		break;

	case 209:
		pIns = new CIns_209_tlbr();
		break;

	case 210:
		pIns = new CIns_210_tlbs();
		break;

	case 211:
		pIns = new CIns_211_tlbvi();
		break;

	case 212:
		pIns = new CIns_212_tlbw();
		break;

	case 213:
		pIns = new CIns_213_dbcp();
		break;

	case 214:
		pIns = new CIns_214_dbhvtrap();
		break;

	case 215:
		pIns = new CIns_215_dbpush();
		break;

	case 216:
		pIns = new CIns_216_dbret();
		break;

	case 217:
		pIns = new CIns_217_dbtag();
		break;

	case 218:
		pIns = new CIns_218_dbtrap();
		break;

	case 219:
		pIns = new CIns_219_rmtrap();
		break;

	case 220:
		pIns = new CIns_220_absf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 221:
		pIns = new CIns_221_absf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 222:
		pIns = new CIns_222_addf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 223:
		pIns = new CIns_223_addf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 224:
		pIns = new CIns_224_ceilf_dl();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 225:
		pIns = new CIns_225_ceilf_dul();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 226:
		pIns = new CIns_226_ceilf_duw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 227:
		pIns = new CIns_227_ceilf_dw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 228:
		pIns = new CIns_228_ceilf_sl();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 229:
		pIns = new CIns_229_ceilf_sul();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 230:
		pIns = new CIns_230_ceilf_suw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 231:
		pIns = new CIns_231_ceilf_sw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 232:
		pIns = new CIns_232_cmovf_d();
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 233:
		pIns = new CIns_233_cmovf_s();
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 234:
		pIns = new CIns_234_cmpf_d();
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 235:
		pIns = new CIns_235_cmpf_s();
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 236:
		pIns = new CIns_236_cvtf_dl();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 237:
		pIns = new CIns_237_cvtf_ds();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 238:
		pIns = new CIns_238_cvtf_dul();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 239:
		pIns = new CIns_239_cvtf_duw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 240:
		pIns = new CIns_240_cvtf_dw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 241:
		pIns = new CIns_241_cvtf_hs();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 242:
		pIns = new CIns_242_cvtf_ld();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 243:
		pIns = new CIns_243_cvtf_ls();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 244:
		pIns = new CIns_244_cvtf_sd();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 245:
		pIns = new CIns_245_cvtf_sl();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 246:
		pIns = new CIns_246_cvtf_sh();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 247:
		pIns = new CIns_247_cvtf_sul();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 248:
		pIns = new CIns_248_cvtf_suw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 249:
		pIns = new CIns_249_cvtf_sw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 250:
		pIns = new CIns_250_cvtf_uld();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 251:
		pIns = new CIns_251_cvtf_uls();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 252:
		pIns = new CIns_252_cvtf_uwd();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 253:
		pIns = new CIns_253_cvtf_uws();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 254:
		pIns = new CIns_254_cvtf_wd();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 255:
		pIns = new CIns_255_cvtf_ws();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 256:
		pIns = new CIns_256_divf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 257:
		pIns = new CIns_257_divf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 258:
		pIns = new CIns_258_floorf_dl();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 259:
		pIns = new CIns_259_floorf_dul();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 260:
		pIns = new CIns_260_floorf_duw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 261:
		pIns = new CIns_261_floorf_dw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 262:
		pIns = new CIns_262_floorf_sl();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 263:
		pIns = new CIns_263_floorf_sul();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 264:
		pIns = new CIns_264_floorf_suw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 265:
		pIns = new CIns_265_floorf_sw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 266:
		pIns = new CIns_266_fmaf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 267:
		pIns = new CIns_267_fmsf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 268:
		pIns = new CIns_268_fnmaf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 269:
		pIns = new CIns_269_fnmsf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 270:
		pIns = new CIns_270_maddf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 271:
		pIns = new CIns_271_maxf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 272:
		pIns = new CIns_272_maxf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 273:
		pIns = new CIns_273_minf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 274:
		pIns = new CIns_274_minf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 275:
		pIns = new CIns_275_msubf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 276:
		pIns = new CIns_276_mulf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 277:
		pIns = new CIns_277_mulf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 278:
		pIns = new CIns_278_negf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 279:
		pIns = new CIns_279_negf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 280:
		pIns = new CIns_280_nmaddf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 281:
		pIns = new CIns_281_nmsubf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(2)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 282:
		pIns = new CIns_282_recipf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 283:
		pIns = new CIns_283_recipf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 284:
		pIns = new CIns_284_roundf_dl();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 285:
		pIns = new CIns_285_roundf_dul();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 286:
		pIns = new CIns_286_roundf_duw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 287:
		pIns = new CIns_287_roundf_dw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 288:
		pIns = new CIns_288_roundf_sl();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 289:
		pIns = new CIns_289_roundf_sul();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 290:
		pIns = new CIns_290_roundf_suw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 291:
		pIns = new CIns_291_roundf_sw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 292:
		pIns = new CIns_292_rsqrtf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 293:
		pIns = new CIns_293_rsqrtf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 294:
		pIns = new CIns_294_sqrtf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 295:
		pIns = new CIns_295_sqrtf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 296:
		pIns = new CIns_296_subf_d();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 297:
		pIns = new CIns_297_subf_s();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 298:
		pIns = new CIns_298_trfsr();
		break;

	case 299:
		pIns = new CIns_299_trncf_dl();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 300:
		pIns = new CIns_300_trncf_dul();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 301:
		pIns = new CIns_301_trncf_duw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 302:
		pIns = new CIns_302_trncf_dw();
		pIns->opr(0)->SetConstraint(new IFpuDoubleConstraint());
		break;

	case 303:
		pIns = new CIns_303_trncf_sl();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 304:
		pIns = new CIns_304_trncf_sul();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 305:
		pIns = new CIns_305_trncf_suw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 306:
		pIns = new CIns_306_trncf_sw();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint());
		break;

	case 307:
		pIns = new CIns_307_cnvq15q30();
		break;

	case 308:
		pIns = new CIns_308_cnvq30q15();
		break;

	case 309:
		pIns = new CIns_309_cnvq31q62();
		break;

	case 310:
		pIns = new CIns_310_cnvq62q31();
		break;

	case 311:
		pIns = new CIns_311_dup_h();
		break;

	case 312:
		pIns = new CIns_312_dup_w();
		break;

	case 313:
		pIns = new CIns_313_expq31();
		break;

	case 314:
		pIns = new CIns_314_modadd();
		pIns->opr(0)->SetConstraint(new IValConstraint(0,0xFFFFFFFF,0,0)); // Dummy Constraint
		break;

	case 315:
		pIns = new CIns_315_mov_dw();
		break;

	case 316:
		pIns = new CIns_316_mov_dw();
		break;

	case 317:
		pIns = new CIns_317_mov_h();
		break;

	case 318:
		pIns = new CIns_318_mov_w();
		break;

	case 319:
		pIns = new CIns_319_mov_w();
		break;

	case 320:
		pIns = new CIns_320_mov_w();
		break;

	case 321:
		pIns = new CIns_321_pki16i32();
		break;

	case 322:
		pIns = new CIns_322_pki16ui8();
		break;

	case 323:
		pIns = new CIns_323_pki32i16();
		break;

	case 324:
		pIns = new CIns_324_pki64i32();
		break;

	case 325:
		pIns = new CIns_325_pkq15q31();
		break;

	case 326:
		pIns = new CIns_326_pkq30q31();
		break;

	case 327:
		pIns = new CIns_327_pkq31q15();
		break;

	case 328:
		pIns = new CIns_328_pkui8i16();
		break;

	case 329:
		pIns = new CIns_329_vabs_h();
		break;

	case 330:
		pIns = new CIns_330_vabs_w();
		break;

	case 331:
		pIns = new CIns_331_vadd_dw();
		break;

	case 332:
		pIns = new CIns_332_vadd_h();
		break;

	case 333:
		pIns = new CIns_333_vadd_w();
		break;

	case 334:
		pIns = new CIns_334_vadds_h();
		break;

	case 335:
		pIns = new CIns_335_vadds_w();
		break;

	case 336:
		pIns = new CIns_336_vaddsat_h();
		break;

	case 337:
		pIns = new CIns_337_vaddsat_w();
		break;

	case 338:
		pIns = new CIns_338_vand();
		break;

	case 339:
		pIns = new CIns_339_vbiq_h();
		break;

	case 340:
		pIns = new CIns_340_vbswap_dw();
		break;

	case 341:
		pIns = new CIns_341_vbswap_h();
		break;

	case 342:
		pIns = new CIns_342_vbswap_w();
		break;

	case 343:
		pIns = new CIns_343_vcalc_h();
		break;

	case 344:
		pIns = new CIns_344_vcalc_w();
		break;

	case 345:
		pIns = new CIns_345_vcmov();
		break;

	case 346:
		pIns = new CIns_346_vcmpeq_h();
		break;

	case 347:
		pIns = new CIns_347_vcmpeq_w();
		break;

	case 348:
		pIns = new CIns_348_vcmple_h();
		break;

	case 349:
		pIns = new CIns_349_vcmple_w();
		break;

	case 350:
		pIns = new CIns_350_vcmplt_h();
		break;

	case 351:
		pIns = new CIns_351_vcmplt_w();
		break;

	case 352:
		pIns = new CIns_352_vcmpne_h();
		break;

	case 353:
		pIns = new CIns_353_vcmpne_w();
		break;

	case 354:
		pIns = new CIns_354_vconcat_b();
		break;

	case 355:
		pIns = new CIns_355_vitlv_h();
		break;

	case 356:
		pIns = new CIns_356_vitlv_w();
		break;

	case 357:
		pIns = new CIns_357_vitlvhw_h();
		break;

	case 358:
		pIns = new CIns_358_vitlvwh_h();
		break;

	case 359:
		pIns = new CIns_359_vld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 360:
		pIns = new CIns_360_vld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 361:
		pIns = new CIns_361_vld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 362:
		pIns = new CIns_362_vld_b();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
		break;

	case 363:
		pIns = new CIns_363_vld_dw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break;

	case 364:
		pIns = new CIns_364_vld_dw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break;

	case 365:
		pIns = new CIns_365_vld_dw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break;

	case 366:
		pIns = new CIns_366_vld_dw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break;

	case 367:
		pIns = new CIns_367_vld_dw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break;

	case 368:
		pIns = new CIns_368_vld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 369:
		pIns = new CIns_369_vld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 370:
		pIns = new CIns_370_vld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 371:
		pIns = new CIns_371_vld_h();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break;

	case 372:
		pIns = new CIns_372_vld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 373:
		pIns = new CIns_373_vld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 374:
		pIns = new CIns_374_vld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 375:
		pIns = new CIns_375_vld_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break;

	case 376:
		pIns = new CIns_376_vmadrn_h();
		break;

	case 377:
		pIns = new CIns_377_vmadrn_w();
		break;

	case 378:
		pIns = new CIns_378_vmadsat_h();
		break;

	case 379:
		pIns = new CIns_379_vmadsat_w();
		break;

	case 380:
		pIns = new CIns_380_vmaxge_h();
		break;

	case 381:
		pIns = new CIns_381_vmaxge_w();
		break;

	case 382:
		pIns = new CIns_382_vmaxgt_h();
		break;

	case 383:
		pIns = new CIns_383_vmaxgt_w();
		break;

	case 384:
		pIns = new CIns_384_vminle_h();
		break;

	case 385:
		pIns = new CIns_385_vminle_w();
		break;

	case 386:
		pIns = new CIns_386_vminlt_h();
		break;

	case 387:
		pIns = new CIns_387_vminlt_w();
		break;

	case 388:
		pIns = new CIns_388_vmsum_h();
		break;

	case 389:
		pIns = new CIns_389_vmsum_w();
		break;

	case 390:
		pIns = new CIns_390_vmsumad_h();
		break;

	case 391:
		pIns = new CIns_391_vmsumad_w();
		break;

	case 392:
		pIns = new CIns_392_vmsumadim_h();
		break;

	case 393:
		pIns = new CIns_393_vmsumadim_w();
		break;

	case 394:
		pIns = new CIns_394_vmsumadre_h();
		break;

	case 395:
		pIns = new CIns_395_vmsumadre_w();
		break;

	case 396:
		pIns = new CIns_396_vmsumadrn_h();
		break;

	case 397:
		pIns = new CIns_397_vmsumadrn_w();
		break;

	case 398:
		pIns = new CIns_398_vmul_h();
		break;

	case 399:
		pIns = new CIns_399_vmul_w();
		break;

	case 400:
		pIns = new CIns_400_vmulcx_h();
		break;

	case 401:
		pIns = new CIns_401_vmulcx_w();
		break;

	case 402:
		pIns = new CIns_402_vmult_h();
		break;

	case 403:
		pIns = new CIns_403_vmult_w();
		break;

	case 404:
		pIns = new CIns_404_vneg_h();
		break;

	case 405:
		pIns = new CIns_405_vneg_w();
		break;

	case 406:
		pIns = new CIns_406_vnot();
		break;

	case 407:
		pIns = new CIns_407_vor();
		break;

	case 408:
		pIns = new CIns_408_vsar_dw();
		break;

	case 409:
		pIns = new CIns_409_vsar_dw();
		break;

	case 410:
		pIns = new CIns_410_vsar_h();
		break;

	case 411:
		pIns = new CIns_411_vsar_h();
		break;

	case 412:
		pIns = new CIns_412_vsar_w();
		break;

	case 413:
		pIns = new CIns_413_vsar_w();
		break;

	case 414:
		pIns = new CIns_414_vshl_dw();
		break;

	case 415:
		pIns = new CIns_415_vshl_dw();
		break;

	case 416:
		pIns = new CIns_416_vshl_h();
		break;

	case 417:
		pIns = new CIns_417_vshl_h();
		break;

	case 418:
		pIns = new CIns_418_vshl_w();
		break;

	case 419:
		pIns = new CIns_419_vshl_w();
		break;

	case 420:
		pIns = new CIns_420_vshr_dw();
		break;

	case 421:
		pIns = new CIns_421_vshr_dw();
		break;

	case 422:
		pIns = new CIns_422_vshr_h();
		break;

	case 423:
		pIns = new CIns_423_vshr_h();
		break;

	case 424:
		pIns = new CIns_424_vshr_w();
		break;

	case 425:
		pIns = new CIns_425_vshr_w();
		break;

	case 426:
		pIns = new CIns_426_vshufl_b();
		break;

	case 427:
		pIns = new CIns_427_vst_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 428:
		pIns = new CIns_428_vst_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 429:
		pIns = new CIns_429_vst_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 430:
		pIns = new CIns_430_vst_b();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
		break;

	case 431:
		pIns = new CIns_431_vst_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 432:
		pIns = new CIns_432_vst_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 433:
		pIns = new CIns_433_vst_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 434:
		pIns = new CIns_434_vst_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 435:
		pIns = new CIns_435_vst_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 436:
		pIns = new CIns_436_vst_dw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
		break;

	case 437:
		pIns = new CIns_437_vst_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 438:
		pIns = new CIns_438_vst_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 439:
		pIns = new CIns_439_vst_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 440:
		pIns = new CIns_440_vst_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 441:
		pIns = new CIns_441_vst_h();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
		break;

	case 442:
		pIns = new CIns_442_vst_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 443:
		pIns = new CIns_443_vst_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 444:
		pIns = new CIns_444_vst_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 445:
		pIns = new CIns_445_vst_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 446:
		pIns = new CIns_446_vst_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
		break;

	case 447:
		pIns = new CIns_447_vsub_dw();
		break;

	case 448:
		pIns = new CIns_448_vsub_h();
		break;

	case 449:
		pIns = new CIns_449_vsub_w();
		break;

	case 450:
		pIns = new CIns_450_vsubs_h();
		break;

	case 451:
		pIns = new CIns_451_vsubs_w();
		break;

	case 452:
		pIns = new CIns_452_vsubsat_h();
		break;

	case 453:
		pIns = new CIns_453_vsubsat_w();
		break;

	case 454:
		pIns = new CIns_454_vxor();
		break;

	case 455:
		pIns = new CIns_455__word();
		break;

	case 456:
		pIns = new CIns_456__short();
		break;

	case 457:
		pIns = new CIns_457_cmovf_w4();
		break ;

	case 458:
		pIns = new CIns_458_movv_w2();
		break ;

	case 459:
		pIns = new CIns_459_movv_w4();
		break ;

	case 460:
		pIns = new CIns_460_movvg_w();
		break ;

	case 461:
		pIns = new CIns_461_movvi();
		break ;

	case 462:
		pIns = new CIns_462_flpv_s2();
		break ;

	case 463:
		pIns = new CIns_463_flpv_s4();
		break ;

	case 464:
		pIns = new CIns_464_shflv_w2();
		break ;

	case 465:
		pIns = new CIns_465_shflv_w4();
		break ;

	case 466:
		pIns = new CIns_466_ldv_dw();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 467:
		pIns = new CIns_467_ldv_dw();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 468:
		pIns = new CIns_468_ldv_dw();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 469:
		pIns = new CIns_469_ldv_dw();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 470:
		pIns = new CIns_470_ldv_qw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 471:
		pIns = new CIns_471_ldv_qw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 472:
		pIns = new CIns_472_ldv_qw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 473:
		pIns = new CIns_473_ldv_qw();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 474:
		pIns = new CIns_474_ldv_w();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 475:
		pIns = new CIns_475_ldv_w();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 476:
		pIns = new CIns_476_ldv_w();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 477:
		pIns = new CIns_477_ldv_w();
		pIns->opr(1)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break ;

	case 478:
		pIns = new CIns_478_ldvgtr2_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break ;

	case 479:
		pIns = new CIns_479_ldvgtr4_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 16));
		break ;

	case 480:
		pIns = new CIns_480_ldvpgtr2_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 16));
		break ;

	case 481:
		pIns = new CIns_481_ldvpgtr4_w();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 32));
		break ;

	case 482:
		pIns = new CIns_482_ldvz_h1();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break ;

	case 483:
		pIns = new CIns_483_ldvz_h2();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 484:
		pIns = new CIns_484_ldvz_h4();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 485:
		pIns = new CIns_485_ldvz_h1();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break ;

	case 486:
		pIns = new CIns_486_ldvz_h2();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 487:
		pIns = new CIns_487_ldvz_h4();
		pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 488:
		pIns = new CIns_488_stv_dw();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 489:
		pIns = new CIns_489_stv_dw();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 490:
		pIns = new CIns_490_stv_dw();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 491:
		pIns = new CIns_491_stv_dw();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 492:
		pIns = new CIns_492_stv_qw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 493:
		pIns = new CIns_493_stv_qw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 494:
		pIns = new CIns_494_stv_qw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 495:
		pIns = new CIns_495_stv_qw();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x0f, 16));
		break ;

	case 496:
		pIns = new CIns_496_stv_w();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 497:
		pIns = new CIns_497_stv_w();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 498:
		pIns = new CIns_498_stv_w();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 499:
		pIns = new CIns_499_stv_w();
		pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 500:
		pIns = new CIns_500_stvpsct2_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 16));
		break ;

	case 501:
		pIns = new CIns_501_stvpsct4_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 32));
		break ;

	case 502:
		pIns = new CIns_502_stvsct2_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
		break ;

	case 503:
		pIns = new CIns_503_stvsct4_w();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 16));
		break ;

	case 504:
		pIns = new CIns_504_stvz_h1();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break ;

	case 505:
		pIns = new CIns_505_stvz_h2();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 506:
		pIns = new CIns_506_stvz_h4();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 507:
		pIns = new CIns_507_stvz_h1();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
		break ;

	case 508:
		pIns = new CIns_508_stvz_h2();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
		break ;

	case 509:
		pIns = new CIns_509_stvz_h4();
		pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x07, 8));
		break ;

	case 510:
		pIns = new CIns_510_cmov_w1();
		break ;

	case 511:
		pIns = new CIns_511_cmov_w2();
		break ;

	case 512:
		pIns = new CIns_512_cmov_w4();
		break ;

	case 513:
		pIns = new CIns_513_trfsrv_w2();
		break ;

	case 514:
		pIns = new CIns_514_trfsrv_w4();
		break ;

        case 515:
		pIns = new CIns_515_absf_s1();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
		break;
        case 516:
		pIns = new CIns_516_absf_s2();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
		break;
        case 517:
		pIns = new CIns_517_absf_s4();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
		break;
	case 518:
		pIns = new CIns_518_addf_s1();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
		break;
	case 519:
		pIns = new CIns_519_addf_s2();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
		break;
	case 520:
		pIns = new CIns_520_addf_s4();
		pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
		pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
		break;
        case 521:
                pIns = new CIns_521_divf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 522:
                pIns = new CIns_522_divf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 523:
                pIns = new CIns_523_divf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 524:
                pIns = new CIns_524_maxf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 525:
                pIns = new CIns_525_maxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 526:
                pIns = new CIns_526_maxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 527:
                pIns = new CIns_527_minf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 528:
                pIns = new CIns_528_minf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 529:
                pIns = new CIns_529_minf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 530:
                pIns = new CIns_530_mulf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 531:
                pIns = new CIns_531_mulf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 532:
                pIns = new CIns_532_mulf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 533:
                pIns = new CIns_533_negf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 534:
                pIns = new CIns_534_negf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 535:
                pIns = new CIns_535_negf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 536:
                pIns = new CIns_536_recipf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 537:
                pIns = new CIns_537_recipf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 538:
                pIns = new CIns_538_recipf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 539:
                pIns = new CIns_539_rsqrtf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 540:
                pIns = new CIns_540_rsqrtf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 541:
                pIns = new CIns_541_rsqrtf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 542:
                pIns = new CIns_542_sqrtf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 543:
                pIns = new CIns_543_sqrtf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 544:
                pIns = new CIns_544_sqrtf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 545:
                pIns = new CIns_545_subf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 546:
                pIns = new CIns_546_subf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 547:
                pIns = new CIns_547_subf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 548:
                pIns = new CIns_548_fmaf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 549:
                pIns = new CIns_549_fmaf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 550:
                pIns = new CIns_550_fmaf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 551:
                pIns = new CIns_551_fmsf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 552:
                pIns = new CIns_552_fmsf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 553:
                pIns = new CIns_553_fmsf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 554:
                pIns = new CIns_554_fnmaf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 555:
                pIns = new CIns_555_fnmaf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 556:
                pIns = new CIns_556_fnmaf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 557:
                pIns = new CIns_557_fnmsf_s1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 558:
                pIns = new CIns_558_fnmsf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 559:
                pIns = new CIns_559_fnmsf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 560:
                pIns = new CIns_560_addsubf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 561:
                pIns = new CIns_561_addsubf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 562:
                pIns = new CIns_562_addsubnf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 563:
                pIns = new CIns_563_addsubnf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 564:
                pIns = new CIns_564_subaddf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 565:
                pIns = new CIns_565_subaddf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 566:
                pIns = new CIns_566_subaddnf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 567:
                pIns = new CIns_567_subaddnf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 568:
                pIns = new CIns_568_addxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 569:
                pIns = new CIns_569_addxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 570:
                pIns = new CIns_570_mulxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 571:
                pIns = new CIns_571_mulxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 572:
                pIns = new CIns_572_subxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 573:
                pIns = new CIns_573_subxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 574:
                pIns = new CIns_574_addsubnxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 575:
                pIns = new CIns_575_addsubnxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 576:
                pIns = new CIns_576_addsubxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 577:
                pIns = new CIns_577_addsubxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 578:
                pIns = new CIns_578_subaddnxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 579:
                pIns = new CIns_579_subaddnxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 580:
                pIns = new CIns_580_subaddxf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 581:
                pIns = new CIns_581_subaddxf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 582:
                pIns = new CIns_582_addrf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 583:
                pIns = new CIns_583_addrf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 584:
                pIns = new CIns_584_maxrf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 585:
                pIns = new CIns_585_maxrf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 586:
                pIns = new CIns_586_minrf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 587:
                pIns = new CIns_587_minrf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 588:
                pIns = new CIns_588_mulrf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 589:
                pIns = new CIns_589_mulrf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 590:
                pIns = new CIns_590_subrf_s2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 591:
                pIns = new CIns_591_subrf_s4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 592:
                pIns = new CIns_592_ceilf_suw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 593:
                pIns = new CIns_593_ceilf_suw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 594:
                pIns = new CIns_594_ceilf_suw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 595:
                pIns = new CIns_595_ceilf_sw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 596:
                pIns = new CIns_596_ceilf_sw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 597:
                pIns = new CIns_597_ceilf_sw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 598:
                pIns = new CIns_598_cvtf_hs1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 599:
                pIns = new CIns_599_cvtf_hs2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 600:
                pIns = new CIns_600_cvtf_hs4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 601:
                pIns = new CIns_601_cvtf_sh1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 602:
                pIns = new CIns_602_cvtf_sh2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 603:
                pIns = new CIns_603_cvtf_sh4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 604:
                pIns = new CIns_604_cvtf_suw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 605:
                pIns = new CIns_605_cvtf_suw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 606:
                pIns = new CIns_606_cvtf_suw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 607:
                pIns = new CIns_607_cvtf_sw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 608:
                pIns = new CIns_608_cvtf_sw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 609:
                pIns = new CIns_609_cvtf_sw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 610:
                pIns = new CIns_610_cvtf_uws1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 611:
                pIns = new CIns_611_cvtf_uws2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 612:
                pIns = new CIns_612_cvtf_uws4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 613:
                pIns = new CIns_613_cvtf_ws1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 614:
                pIns = new CIns_614_cvtf_ws2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 615:
                pIns = new CIns_615_cvtf_ws4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 616:
                pIns = new CIns_616_floorf_suw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 617:
                pIns = new CIns_617_floorf_suw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 618:
                pIns = new CIns_618_floorf_suw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 619:
                pIns = new CIns_619_floorf_sw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 620:
                pIns = new CIns_620_floorf_sw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 621:
                pIns = new CIns_621_floorf_sw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 622:
                pIns = new CIns_622_roundf_suw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 623:
                pIns = new CIns_623_roundf_suw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 624:
                pIns = new CIns_624_roundf_suw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 625:
                pIns = new CIns_625_roundf_sw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 626:
                pIns = new CIns_626_roundf_sw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 627:
                pIns = new CIns_627_roundf_sw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 628:
                pIns = new CIns_628_trncf_suw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 629:
                pIns = new CIns_629_trncf_suw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 630:
                pIns = new CIns_630_trncf_suw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 631:
                pIns = new CIns_631_trncf_sw1();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 632:
                pIns = new CIns_632_trncf_sw2();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 633:
                pIns = new CIns_633_trncf_sw4();
                pIns->opr(0)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
        case 634:
                pIns = new CIns_634_cmpf_s1();
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x1));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x1));
                break;
        case 635:
                pIns = new CIns_635_cmpf_s2();
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0x3));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0x3));
                break;
        case 636:
                pIns = new CIns_636_cmpf_s4();
                pIns->opr(1)->SetConstraint(new IFpuSingleConstraint(0xf));
                pIns->opr(2)->SetConstraint(new IFpuSingleConstraint(0xf));
                break;
		
		//------------- G4MH Instruction---------//
		
		/*ld.b instruction */
		case 637: 
				pIns = new CIns_637_ld_b_inc();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
				break;
		case 638: 
				pIns = new CIns_638_ld_b_dec();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
				break;
		
		/*ld.bu instruction */
		case 639: 
				pIns = new CIns_639_ld_bu_inc();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
				break;
	
		case 640: 
				pIns = new CIns_640_ld_bu_dec();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
				break;		
		
		/*ld.h instruction */
		case 641: 
				pIns = new CIns_641_ld_h_inc();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
				break;	
		case 642: 
				pIns = new CIns_642_ld_h_dec();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
				break;	
		
		/*ld.hu instruction */
		case 643: 
				pIns = new CIns_643_ld_hu_inc();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
				break;	

		case 644: 
				pIns = new CIns_644_ld_hu_dec();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
				break;
		
		/*ld.w instruction */
		case 645: 
				pIns = new CIns_645_ld_w_inc();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
				break;
		case 646: 
				pIns = new CIns_646_ld_w_dec();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
				break;

		/*ld.dw instruction */
		case 647: 
				pIns = new CIns_647_ld_dw_inc();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
				break;
		case 648: 
				pIns = new CIns_648_ld_dw_dec();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
				break;
		
		/*st.b instruction */
		case 649: 
				pIns = new CIns_649_st_b_inc();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
				break;
		case 650: 
				pIns = new CIns_650_st_b_dec();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
				break;
		
		/*st.h instruction */
		case 651: 
				pIns = new CIns_651_st_h_inc();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
				break;
		case 652: 
				pIns = new CIns_652_st_h_dec();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
				break;
		
		/*st.w instruction */
		case 653: 
				pIns = new CIns_653_st_w_inc();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
				break;
		case 654: 
				pIns = new CIns_654_st_w_dec();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
				break;
	
		/*st.dw instruction */
		case 655: 
				pIns = new CIns_655_st_dw_inc();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
				break;
		case 656: 
				pIns = new CIns_656_st_dw_dec();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
				break;

		/*clip.b instruction */
		case 657: 
				pIns = new CIns_657_clip_b();
				break;
		/*clip.bu instruction */
		case 658: 
				pIns = new CIns_658_clip_bu();
				break;
		/*clip.h instruction */
		case 659:
				pIns = new CIns_659_clip_h();
				break;
		/*clip.hu instruction */
		case 660: 
				pIns = new CIns_660_clip_hu();
				break;
		case 661:
				pIns = new CIns_661_ldl_bu();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
				break;
		case 662:
				pIns = new CIns_662_ldl_hu();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
				break;
		case 663:
				pIns = new CIns_663_ldl_dw();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 8));
				break;
		case 664:
				pIns = new CIns_664_stc_b();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
				break;
		case 665:
				pIns = new CIns_665_stc_h();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
				break;
		case 666:
				pIns = new CIns_666_stc_dw();
				pIns->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 8));
				break;
		case 667:
				pIns = new CIns_667_resbank();
				break;
		case 668:
				pIns = new CIns_668_stm_gsr();
				pIns->opr(0)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x3, 144));
				break;
		case 669:
				pIns = new CIns_669_stm_mp();
				pIns->opr(2)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x3, 384));
				break;
		case 670:
				pIns = new CIns_670_ldm_gsr();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x3, 144));
				break;
		case 671:
				pIns = new CIns_671_ldm_mp();
				pIns->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x3, 384));
				break;
			//--------------End G4MH Instruction------------------------------//			


		default :
			//拡張命令はFP命令追加分ずらす
			pIns = CreateInsEx(insid);
			break;
	};

	return pIns;
};

/**
 * CreateLdStInsEx
 * 
 * 拡張命令としてのメモリアクセス命令
 * 複合命令の要素となる。
 * 
 * @param	insid	命令ID
 * @param	mr		アクセス対象範囲(mr.first - mr.second)
 * @param	basereg	ベースレジスタのインデックス
 * @param	dsreg	dst/srcレジスタのインデックス
 * 
 */
IInstruction* CInstructionSet::CreateLdStInsEx(INS_ID insid, MEMRANGE mr, UI32 basereg, UI32 srcreg, UI32 dsreg) {
	
	IInstruction* pIns = NULL;
	const UI32 bitWidth = 6; // -32 〜 31
	
	switch(insid)
	{
     	case 87:
	     	pIns = new CIns_87_ld_b(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~0U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1/*=Size, mask-align=0*/)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
		 	break;
 	
     	case 88:
	     	pIns = new CIns_88_ld_b(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~0U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
	
     	case 89:
		 	pIns = new CIns_89_ld_bu(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~0U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
		 	
     	case 90:
		 	pIns = new CIns_90_ld_bu(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~0U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
			
     	case 91:
		 	pIns = new CIns_91_ld_dw(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 8)),
		 		new COprPR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
			
     	case 92:
		 	pIns = new CIns_92_ld_h(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
			
     	case 93:
		 	pIns = new CIns_93_ld_h(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
			
     	case 94:
		 	pIns = new CIns_94_ld_hu(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
			
     	case 95:
		 	pIns = new CIns_95_ld_hu(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
		 	
     	case 96:
		 	pIns = new CIns_96_ld_w(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;
			
     	case 97:
		 	pIns = new CIns_97_ld_w(
		 		new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4)),
		 		new COprGR(dsreg, dsreg, GR_W, NULL)
		 	);
			break;

		// LOAD (SHORT FORMAT)
		case 156:
			pIns = new CIns_156_sld_b(
				new COprDispEP(bitWidth, ~0U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
	
		case 157:
			pIns = new CIns_157_sld_bu(
				new COprDispEP(4, ~0U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
	
		case 158:
			pIns = new CIns_158_sld_h(
				new COprDispEP(bitWidth, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
	
		case 159:
			pIns = new CIns_159_sld_hu(
				new COprDispEP(5, ~1U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
	
		case 160:
			pIns = new CIns_160_sld_w(
				new COprDispEP(bitWidth, ~3U, DR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;

		// STORE (SHORT FORMAT)
		case 162:
			pIns = new CIns_162_sst_b (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprDispEP(bitWidth, ~0U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1))
			);
			break;
	
		case 163:
			pIns = new CIns_163_sst_h (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprDispEP(bitWidth, ~1U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2))
			);
			break;
	
		case 164:
			pIns = new CIns_164_sst_w (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprDispEP(bitWidth, ~3U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4))
			);
			break;
		// STORE
		case 165:
			pIns = new CIns_165_st_b (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~0U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1))
			);
			break;
	
		case 166:
			pIns = new CIns_166_st_b (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~0U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1))
			);
			break;
	
		case 167:
			pIns = new CIns_167_st_dw (
				new COprPR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 8))
			);
			break;
	
		case 168:
			pIns = new CIns_168_st_h (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2))
			);
			break;
	
		case 169:
			pIns = new CIns_169_st_h (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2))
			);
			break;
	
		case 170:
			pIns = new CIns_170_st_w (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4))
			);
			break;
	
		case 171:
			pIns = new CIns_171_st_w (
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprSDispReg(bitWidth, basereg, basereg, ~1U, DR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4))
			);
			break;
//---------------Modified 4th August 2016---------------------------
		case 467:
			pIns = (new CIns_467_ldv_dw())->Fix();
			pIns->opr(1)->Replace(basereg);
			pIns->opr(1)->SetConstraint(new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x7, 8));
			break ;

		case 471:
			pIns = (new CIns_471_ldv_qw())->Fix();
			pIns->opr(0)->Replace(basereg);
			pIns->opr(0)->SetConstraint(new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0xf, 16));
			break;

		case 475:
			pIns = (new CIns_475_ldv_w())->Fix();
			pIns->opr(1)->Replace(basereg);
			pIns->opr(1)->SetConstraint(new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4));
			break ;
		case 487:
			pIns = (new CIns_487_ldvz_h4())->Fix();
			pIns->opr(0)->Replace(basereg);
			pIns->opr(0)->SetConstraint(new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x7, 8));
			break;

            // STORE
		case 488:
			pIns = (new CIns_488_stv_dw())->Fix();
			pIns->opr(2)->Replace(basereg);
			pIns->opr(2)->SetConstraint(new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x7, 8));
			break ;

		case 489:
			pIns = (new CIns_489_stv_dw())->Fix();
			pIns->opr(2)->Replace(basereg);
			pIns->opr(2)->SetConstraint(new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x7, 8));
			break ;
		
		case 493:
			pIns = (new CIns_493_stv_qw())->Fix();
			pIns->opr(1)->Replace(basereg);
			pIns->opr(1)->SetConstraint(new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0xf, 16));
			break ;

		case 497:
			pIns = (new CIns_497_stv_w())->Fix();
			pIns->opr(2)->Replace(basereg);
			pIns->opr(2)->SetConstraint(new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4));
			break ;

		case 509:
			pIns = (new CIns_509_stvz_h4())->Fix();
			pIns->opr(1)->Replace(basereg);
			pIns->opr(1)->SetConstraint(new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x7, 8));
			break ;

		case 637: 
			pIns = new CIns_637_ld_b_inc(
				new COprGRmx(basereg, basereg, '+', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
		case 638: 
			pIns = new CIns_638_ld_b_dec(
				new COprGRmx(basereg, basereg, '-', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
		
		/*ld.bu instruction */
		case 639: 
			pIns = new CIns_639_ld_bu_inc(
				new COprGRmx(basereg, basereg, '+', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
	
		case 640: 
			pIns = new CIns_640_ld_bu_dec(
				new COprGRmx(basereg, basereg, '-', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x0, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;		
		
		/*ld.h instruction */
		case 641: 
			pIns = new CIns_641_ld_h_inc(
				new COprGRmx(basereg, basereg, '+', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;	
		case 642: 
			pIns = new CIns_642_ld_h_dec(
				new COprGRmx(basereg, basereg, '-', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;	
		
		/*ld.hu instruction */
		case 643: 
			pIns = new CIns_643_ld_hu_inc(
				new COprGRmx(basereg, basereg, '+', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;	

		case 644: 
			pIns = new CIns_644_ld_hu_dec(
				new COprGRmx(basereg, basereg, '-', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x1, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)	
			);
			break;
		
		/*ld.w instruction */
		case 645: 
			pIns = new CIns_645_ld_w_inc(
				new COprGRmx(basereg, basereg, '+', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
		case 646: 
			pIns = new CIns_646_ld_w_dec(
				new COprGRmx(basereg, basereg, '-', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;

		/*ld.dw instruction */
		case 647: 
			pIns = new CIns_647_ld_dw_inc(
				new COprGRmx(basereg, basereg, '+', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 8)),
				new COprPR(dsreg, dsreg, 2065, NULL)
			);
			break;
		case 648: 
			pIns = new CIns_648_ld_dw_dec(
				new COprGRmx(basereg, basereg, '-', 1, 305, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 8)),
				new COprPR(dsreg, dsreg, 2065, NULL)
			);
			break;
		
		/*st.b instruction */
		case 649: 
			pIns = new CIns_649_st_b_inc(
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprGRmx(basereg, basereg, '+', 1, 305, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second,0x00,1)) 		
			);
			break;
		case 650: 
			pIns = new CIns_650_st_b_dec(
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprGRmx(basereg, basereg, '-', 1, 305, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second,0x00, 1))
			);
			break;
		
		/*st.h instruction */
		case 651: 
			pIns = new CIns_651_st_h_inc(
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprGRmx(basereg, basereg, '+', 1, 305, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second,0x01, 2))			
			);
			break;
		case 652: 
			pIns = new CIns_652_st_h_dec(
				new COprGR(srcreg,srcreg, GR_R, NULL),
				new COprGRmx(basereg, basereg, '-', 1, 305, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x01, 2))
			);
			break;
		
		/*st.w instruction */
		case 653: 
			pIns = new CIns_653_st_w_inc(
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprGRmx(basereg, basereg, '+', 1, 305, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x03, 4))	
			);
			break;
		case 654: 
			pIns = new CIns_654_st_w_dec(
				new COprGR(srcreg, srcreg, GR_R, NULL),
				new COprGRmx(basereg, basereg, '-', 1, 305, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x03, 4))			
			);
			break;
		/*ldl+stc instructuion*/
		case 661:
			pIns = new CIns_661_ldl_bu(
				new COprGRm(basereg, basereg, 3, GR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x00, 1)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
		case 662:
			pIns = new CIns_662_ldl_hu(
				new COprGRm(basereg, basereg, 3, GR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x01, 2)),
				new COprGR(dsreg, dsreg, GR_W, NULL)
			);
			break;
		case 663:
			pIns = new CIns_663_ldl_dw(
				new COprGRm(basereg, basereg, 3, GR_LR, new CLoadAddressSelector((UI32)mr.first, (UI32)mr.second, 0x07, 8)),
				new COprPR(dsreg, dsreg, GR_W, NULL)
			);
			break;
		case 664:
			pIns = new CIns_664_stc_b(
				new COprGR(srcreg, srcreg, GR_RW, NULL),
				new COprGRm(basereg, basereg, 3, GR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x00, 1))
			);
			break;
		case 665:
			pIns = new CIns_665_stc_h(
				new COprGR(srcreg, srcreg, GR_RW, NULL),
				new COprGRm(basereg, basereg, 3, GR_SR, new CStoreAddressSelector((UI32)mr.first, (UI32)mr.second, 0x01, 2))
			);
			break;
		default:
			FROG_ASSERT(0);
			break;
	}
		
	return pIns;
}

/**
 * CreateLdStInsEx
 * 
 * 拡張命令としてのメモリアクセス命令
 * 複合命令の要素となる。
 * 
 * @param	insid	命令ID
 * @param	mr		アクセス対象範囲(mr.first - mr.second)
 * @param	basereg	ベースレジスタのインデックス
 * @param	dsreg	dst/srcレジスタのインデックス
 * 
 */
IInstruction* CInstructionSet::CreateCAXIInsEx(INS_ID insid, MEMRANGE mr, UI32 basereg, UI32 dsreg1, UI32 dsreg2) {
	
	IInstruction* pIns = NULL;
	//const UI32 bitWidth = 6; // -32 〜 31
	
	switch(insid)
	{
		case 54:
			pIns = new CIns_54_caxi (
				//new COprGRm(basereg, basereg, ~0U, GR_R, NULL),
			    new COprGRm(basereg, basereg, 3, 417, new CRmwAddressSelector((UI32)mr.first, (UI32)mr.second, 0x3, 4)),
				new COprGR(dsreg1, dsreg1, GR_R, NULL),
		 		new COprGR(dsreg2, dsreg2, GR_RW, NULL)
		 	);
		 	break;
			
		default:
			FROG_ASSERT(0);
			break;
	}
		
	return pIns;
}


IInstruction* CInstructionSet::CreateInsEx(INS_ID insid) {
	
	IInstruction* pIns = NULL;
	std::vector<UI32> vOprSrc;
	std::vector<UI32> vOprDst;
	IInstruction*		pIns1;
	IInstruction*		pIns2;
	enum				LDL_DataType {BYTE = 0x01, HWORD = 0x02, WORD = 0x03};
	UI32				Ins1Id = INS_ID_MOVI5;
	UI32				Ins2Id = INS_ID_ADD_I5;
	UI32				BCondId = INS_ID_BR_SD9;
	UI32				mskPos = 0;			//Store position of RIE opcode in mask array, append to comment for debugging if need
	extern std::unique_ptr<CBitWeight> g_FlagAddr;

	std::vector<UI32> STORE_C2B1;
	std::vector<UI32> SHORT_STORE;
	std::vector<UI32> SHIFT;
	std::vector<UI32> ALU;
	std::vector<UI32> MUL;
	std::vector<UI32> C2B1;
	std::vector<UI32> DIV;
	std::vector<UI32> LOAD_STORE;
	std::vector<UI32> SPECIAL;
	std::vector<UI32> LOAD;
	std::vector<UI32> FPU;

	/* GR_IdxSelector */
	std::vector<UI32> gr_src;
    std::vector<UI32> gr_dst;
    UI32 nMismatchedReg = m_nMismatchRegSet;
    UI32 nMatchedReg = ~m_nMismatchRegSet;
	for (UI32 i = 1; i < 32; i++) {
        if(m_nMismatchRegSet != 0) {
            if(((1 << i) & m_nMismatchRegSet) == 0)
		        gr_src.push_back(i);
            else
                gr_dst.push_back(i);
        } else {
            gr_src.push_back(i);
            gr_dst.push_back(i);
        }

	}
	std::random_shuffle(gr_src.begin(), gr_src.end(), g_rnd);
    std::random_shuffle(gr_dst.begin(), gr_dst.end(), g_rnd);

	//------------------------------------------------------------
	// lambda : Macro_pref_I
	//------------------------------------------------------------
	//          regA is Address, regC is loop counter 
	//------------------------------------------------------------
	auto Macro_pref_I = [&] (UI32 regA, UI32 regC) {
		ComplexInstruction* pCmp = new ComplexInstruction(insid, "pref_I");
		
		IInstruction* pTmp = new CIns_103_mov( new COprGRpi(regA, regA, GR_R, NULL) , GRd(regA)); // Opr(0) is SPECIAL GR.
		pTmp->opr(0)->SetConstraint(new INumConstraint(GET_IRAM_HEAD(), GET_IRAM_TAIL()) );
		
		pCmp->push_back( pTmp );
		pCmp->push_back( MOV5(10, regC) );	// RedMine #62133#note-7
		pCmp->back()->SetSequence();
		
		pCmp->push_back( new CIns_207_pref(new COprPrefOp(0U, 40, NULL), new COprGRm(regA, regA, ~0U, GR_R, NULL)));
		pCmp->back()->SetInLoop();
		pCmp->back()->SetSequence();
		
		pCmp->push_back( ADDI(48, regA, regA) );	// RedMine #62133#note-7
		pCmp->back()->SetInLoop();
		pCmp->back()->SetSequence();
		
        pCmp->push_back(LOOPP(regC, "DUMMY"));
		pCmp->back()->SetInLoop();
		pCmp->back()->SetSequence();
		return (IInstruction*)pCmp;
	};

  	//------------------------------------------------------------
	// lambda : dispIncDec 
	// -----------------------------------------------------------
	//          Re-write displacement to 
	//          by incrimetal(disptype=0) or decrimental(disptype=1) value  
	//------------------------------------------------------------  
    auto dispIncDec = [&] (ComplexInstruction* p, UI32 disptype) {
    	if (p == nullptr || p->size() < 1) {
    		return;
    	}
    	auto behav = IValConstraint::STORE_MEMORY;
    	UI32 ac	= 0;
    	if ((*p)[0]->Behavior(IInstruction::LOAD_MEMORY)) {
    		behav = IValConstraint::LOAD_MEMORY;
    	}else
    	if ((*p)[0]->Behavior(IInstruction::STORE_MEMORY)) {
    		behav = IValConstraint::STORE_MEMORY;
    	}else {
    		FROG_ASSERT(0);
    		return;
    	};

		IOperand*	pOpr;
    	for (UI32 k = 0; k < (*p)[0]->GetOpNum(); k++) {
			pOpr = (*p)[0]->opr(k);
			if (pOpr->GetConstraint() != NULL && pOpr->GetConstraint()->GetType(behav)) {
				ac = k;
				break;
			}
		}

    	SI32 ldsz	= (*p)[0]->opr(ac)->GetConstraint()->m_nSzm;
  		SI32 disp	= (UI32)*((*p)[0]->opr(ac));
  		ldsz *= disptype ? (-1) : 1;
    	for (UI32 i = 1; i < p->size(); i++) {
   	 		disp += ldsz;
	 		(*p)[i]->opr(ac)->Imm(disp);
    	}
    };
    
  	//------------------------------------------------------------
	// lambda : SetArrayAlign 
	// -----------------------------------------------------------
	//          Set instruction of head to maximum align in array. 
	//------------------------------------------------------------  
    auto SetArrayAlign = [&] (ComplexInstruction* p) {
    	if (p == nullptr || p->size() < 1) {
    		return;
    	}
    	auto behav = IValConstraint::STORE_MEMORY;
    	UI32 ac	= 0;
    	if ((*p)[0]->Behavior(IInstruction::LOAD_MEMORY)) {
    		behav = IValConstraint::LOAD_MEMORY;
    	}else
    	if ((*p)[0]->Behavior(IInstruction::STORE_MEMORY)) {
    		behav = IValConstraint::STORE_MEMORY;
    	}else {
    		FROG_ASSERT(0);
    		return;
    	};

        auto GetAlign = [](IInstruction *pIns) ->std::pair<UI32, UI32> {
            IOperand *pOpr = NULL;
            UI32 msk = 0;
            UI32 acsize = 0;
            IValConstraint::CONSTRAINT_TYPE behav = IValConstraint::STORE_MEMORY;
            if (pIns->Behavior(IInstruction::LOAD_MEMORY)) {
    		    behav = IValConstraint::LOAD_MEMORY;
    	    }else
    	    if (pIns->Behavior(IInstruction::STORE_MEMORY)) {
    		    behav = IValConstraint::STORE_MEMORY;
    	    }else {
                MSG_WARN(0, "Unsupported instruction, %s.\n", pIns->GetCode().c_str());
    		    FROG_ASSERT(0);
    		    return std::pair<UI32, UI32>(msk, acsize);
    	    };

    	    for (UI32 k = 0; k < pIns->GetOpNum(); k++) {
			    pOpr = pIns->opr(k);
                IValConstraint *pConst = pOpr->GetConstraint();
			    if (pConst != NULL && pConst->GetType(behav)) {
                    msk = pConst->m_nMsk;
                    acsize = pConst->m_nSzm;
				    break;
			    }
		    }
            if(pOpr == NULL) {
                MSG_WARN(0, "Unsupported instruction, %s.\n", pIns->GetCode().c_str());
            }
            return std::pair<UI32, UI32>(msk, acsize);
        };

        // Get max alignment
        UI32 max_msk = 0;
        UI32 ac_size = 0;
        for(UI32 n = 0; n < p->size(); n++) {
            UI32 msk = GetAlign((*p)[n]).first;
            if (ac_size == 0)
                ac_size = GetAlign((*p)[n]).second;
            if (msk > max_msk) {
                max_msk = msk;
                ac_size = GetAlign((*p)[n]).second;
            }
        }

		IOperand*	pOpr;
    	for (UI32 k = 0; k < (*p)[0]->GetOpNum(); k++) {
			pOpr = (*p)[0]->opr(k);
			if (pOpr->GetConstraint() != NULL && pOpr->GetConstraint()->GetType(behav)) {
				ac = k;
				break;
			}
		}
		(*p)[0]->opr(ac)->GetConstraint()->m_nMsk = max_msk;
        (*p)[0]->opr(ac)->GetConstraint()->m_nSzm = ac_size;
    };
    
    //------------------------------------------------------------
    // lambda : Macro_LdArray
    // -----------------------------------------------------------
    //          Memory access in a row
    //    disptype : 0:Incriment, 1:decriment, 2:random
    //    iSet     : instruction set by weighted
    //    mr       : range of base reg value
    //    num      : num of instruction
    //    name     : comment 
    //------------------------------------------------------------    
    auto Macro_LdArray = [&] (UI32 disptype, CWeightedRandom<INS_ID>& iSet, MEMRANGE mr, UI32 num, const char* name) {
    	std::string str(name);
  		if (disptype == 0) str = str + "(INC)"; 
  		if (disptype == 1) str = str + "(DEC)"; 
  		if (disptype == 2) str = str + "(RND)";    	
    	
        ComplexInstruction* pCmp = new ComplexInstruction(insid, name);
        IInstruction*       pIns;
        
        UI32 srcreg;                // store register
     	UI32 destreg;				// load   register
     	UI32 basereg;				// base address register
        UI32 idx = 0;               // idx in gr list

     	basereg = gr_src.back();	// select base reg
  		
		UI32 id = iSet.GetObj();
		bool pairReg = false;
		if (id == INS_ID_ST_DW) //st.dw-167
			pairReg = true;
     	for (UI32 t = 0; t < num; t++) {
	     	std::random_shuffle(gr_dst.begin(), gr_dst.end(), g_rnd);
            idx = 0;
            do {
	     	    destreg = gr_dst[idx];
                idx++;
            } while (destreg == basereg);

            std::random_shuffle(gr_src.begin(), gr_src.end(), g_rnd);
            idx = 0;
            do {
	     	    srcreg = gr_src[idx];
                idx++;
            } while (srcreg == basereg || (pairReg == true && ((srcreg % 2 != 0) || srcreg == (basereg - 1) || basereg == (srcreg - 1))));
            
    	 	pIns = this->CreateLdStInsEx(id, mr, basereg, srcreg, destreg)->Fix();
            pIns->SetSequence(IInstruction::IF_SEQ_ARRAY);
    	 	pIns->AppendComment(str.c_str());
    	 	pCmp->push_back(pIns);
     	}
     	if (disptype != 2) {
			dispIncDec(pCmp, disptype);
     	}else{
     		// ビット幅が変化する連続パタンは最初をアラインしておく
     		// これをしない場合、アライン補正が入ることがある（実害は無い）。
     		SetArrayAlign(pCmp);
     	}
        return (IInstruction*)pCmp;
    };
	
	// Lamda function to random instruction id
	auto RandomId = [](std::vector<UI32> vInsId){
		UI32 pos = g_rnd.GetRange(0U, (UI32)vInsId.size()-1);
		return vInsId.at(pos);
	};

	// Lamda function to random FPU/FXU/Int RIE instruction
	auto RandomRieOp = [&](INS_ID insid){
		UI32 retImm;// mskPos;
		if (insid == INS_CID_RIE_FXU32){

			 /* Array of mask pairs to create RIE opcode. Each pair contain an AND mask (first value) and OR mask (second value)
			 The generated value will be AND with first value and OR with second value
			 To get more information about the opcode, please refer to document: G4MH_ISA_Arch_2015.10.11*/
			static std::pair<UI32,UI32> ImmMskArrFxu[25] = {  std::make_pair(0xF83EF81F,0x048007E0), std::make_pair(0xF806F81F,0x04C807E0), std::make_pair(0xF806F81F,0x04D007E0)
												  , std::make_pair(0xF806F81F,0x04D807E0), std::make_pair(0xF806F81F,0x04E807E0), std::make_pair(0xF806F81F,0x04F007E0)
												  , std::make_pair(0xF806F81F,0x04F807E0), std::make_pair(0xF802F81F,0x052C07E0), std::make_pair(0xF83EF81F,0x054007E0)
												  , std::make_pair(0xF800F801,0x05A007EE), std::make_pair(0xF800F800,0x05A007F5), std::make_pair(0xF800F800,0x05A007F6)
												  , std::make_pair(0xF800F800,0x05A007F7), std::make_pair(0xF800F801,0x05A007FC), std::make_pair(0xF800F800,0x45A007FF)
												  , std::make_pair(0xF800F800,0x85A007FF), std::make_pair(0xF800F800,0xC5A007FF), std::make_pair(0xF800F81F,0x05A207E0)
												  , std::make_pair(0xF802F81F,0x05B007E0), std::make_pair(0xF800F81F,0x05BE07E0), std::make_pair(0xF802F81F,0x05C007E0)
												  , std::make_pair(0xF800F81F,0x05CA07E0), std::make_pair(0xF800F81F,0x05CC07E0), std::make_pair(0xF800F81F,0x05CE07E0)
												  , std::make_pair(0xF81EF81F,0x05E007E0)};
			mskPos = g_rnd.GetRange(0, 24);
			if (mskPos == 7 || mskPos == 8) mskPos=9;	//RIE for case 7 and case 8 changed to UCPOP2 in new spec
			retImm = g_rnd.GetRange(0x00000000U, 0xFFFFFFFFU);
			retImm &= ImmMskArrFxu[mskPos].first;
			retImm |= ImmMskArrFxu[mskPos].second;
		}
		else if (insid == INS_CID_RIE_FPU32){
				/* Array of mask pairs to create RIE opcode. Each pair contain an AND mask (first value) and OR mask (second value)
				The generated value will be AND with first value and OR with second value
				To get more information about the opcode, please refer to document: G4MH_ISA_Arch_2015.10.11 (For FPU RIE)*/
			static std::pair<UI32,UI32> ImmMskArrFpu[123] = { std::make_pair( 0x000EF800,0x040007E0), std::make_pair( 0x000EF81F,0x040007E0), std::make_pair( 0xF00EF01E,0x0C1007E0)
												, std::make_pair( 0xF80EF01E,0x041007E1), std::make_pair( 0xF80EF01F,0x04100FE0), std::make_pair( 0x780EF81F,0x842007E0)
												, std::make_pair( 0x780EF01E,0x843007E0), std::make_pair( 0xF80EF01E,0x043007E1), std::make_pair( 0xF80EF01F,0x04300FE0)
												, std::make_pair( 0xF800F803,0x044007E4), std::make_pair( 0xF800F807,0x044007E8), std::make_pair( 0xF800F803,0x044007F4)
												, std::make_pair( 0xF800F807,0x044007F8), std::make_pair( 0xF800F000,0x04420FE1), std::make_pair( 0xF800F80F,0x044207E0)
												, std::make_pair( 0xF800F000,0x04420FF1), std::make_pair( 0xF800F80F,0x044207F0), std::make_pair( 0xF000F800,0x0C4407E0)
												, std::make_pair( 0xF000F800,0x0C4407E1), std::make_pair( 0xF000F800,0x0C4407E2), std::make_pair( 0xF000F800,0x0C4407E3)
												, std::make_pair( 0xF000F800,0x0C4407E4), std::make_pair( 0xF800F803,0x044407E4), std::make_pair( 0xF800F807,0x044407E8)
												, std::make_pair( 0xF000F800,0x0C4407F0), std::make_pair( 0xF000F800,0x0C4407F1), std::make_pair( 0xF000F800,0x0C4407F2)
												, std::make_pair( 0xF000F800,0x0C4407F3), std::make_pair( 0xF000F800,0x0C4407F4), std::make_pair( 0xF800F803,0x044407F4)
												, std::make_pair( 0xF800F807,0x044407F8), std::make_pair( 0xF800F81F,0x044607E0), std::make_pair( 0xF800F81F,0x044807E0)
												, std::make_pair( 0xF800F81F,0x044A07E0), std::make_pair( 0xF800F81F,0x044C07E0), std::make_pair( 0xF800F800,0x044E07E3)
												, std::make_pair( 0xF800F81F,0x044E07E0), std::make_pair( 0xF800F000,0x04500FE0), std::make_pair( 0xF800F000,0x04500FE1)
												, std::make_pair( 0xF800F000,0x04500FE2), std::make_pair( 0xF800F000,0x04500FE3), std::make_pair( 0xF800F000,0x04500FE4)
												, std::make_pair( 0xF800F803,0x045007E4), std::make_pair( 0xF800F807,0x045007E8), std::make_pair( 0xF800F000,0x04500FF0)
												, std::make_pair( 0xF800F000,0x04500FF1), std::make_pair( 0xF800F000,0x04500FF2), std::make_pair( 0xF800F000,0x04500FF3)
												, std::make_pair( 0xF800F000,0x04500FF4), std::make_pair( 0xF800F803,0x045007F4), std::make_pair( 0xF800F807,0x045007F8)
												, std::make_pair( 0xF000F800,0x0C5207E0), std::make_pair( 0xF000F000,0x04520FE1), std::make_pair( 0xF000F800,0x0C5207E1)
												, std::make_pair( 0xF000F800,0x0C5207E2), std::make_pair( 0xF800F000,0x04520FE3), std::make_pair( 0xF800F80F,0x045207E0)
												, std::make_pair( 0xF000F800,0x0C5207F0), std::make_pair( 0xF000F000,0x04520FF1), std::make_pair( 0xF000F800,0x0C5207F1)
												, std::make_pair( 0xF800F80F,0x045207F0), std::make_pair( 0xF000F000,0x04540FE0), std::make_pair( 0xF000F800,0x0C5407E0)
												, std::make_pair( 0xF000F000,0x04540FE1), std::make_pair( 0xF000F800,0x0C5407E1), std::make_pair( 0xF000F000,0x04540FE2)
												, std::make_pair( 0xF000F800,0x0C5407E2), std::make_pair( 0xF000F000,0x04540FE3), std::make_pair( 0xF000F800,0x0C5407E3)
												, std::make_pair( 0xF000F000,0x04540FE4), std::make_pair( 0xF000F800,0x0C5407E4), std::make_pair( 0xF800F803,0x045407E4)
												, std::make_pair( 0xF800F807,0x045407E8), std::make_pair( 0xF000F000,0x04540FF0), std::make_pair( 0xF000F800,0x0C5407F0)
												, std::make_pair( 0xF000F000,0x04540FF1), std::make_pair( 0xF000F800,0x0C5407F1), std::make_pair( 0xF000F000,0x04540FF2)
												, std::make_pair( 0xF000F800,0x0C5407F2), std::make_pair( 0xF000F000,0x04540FF3), std::make_pair( 0xF000F800,0x0C5407F3)
												, std::make_pair( 0xF000F000,0x04540FF4), std::make_pair( 0xF000F800,0x0C5407F4), std::make_pair( 0xF800F803,0x045407F4)
												, std::make_pair( 0xF800F807,0x045407F8), std::make_pair( 0xF800F81F,0x045607E0), std::make_pair( 0xF000F000,0x04580FE0)
												, std::make_pair( 0xF000F800,0x0C5807E0), std::make_pair( 0xF000F000,0x04580FE1), std::make_pair( 0xF000F800,0x0C5807E1)
												, std::make_pair( 0xF800F81F,0x045807E0), std::make_pair( 0xF800F81F,0x045A07E0), std::make_pair( 0xF800F81F,0x045C07E0)
												, std::make_pair( 0xF000F000,0x045E07E0), std::make_pair( 0xF000F800,0x0C5E07E0), std::make_pair( 0xF000F000,0x045E07E1)
												, std::make_pair( 0xF000F800,0x0C5E07E1), std::make_pair( 0xF000F000,0x045E07E2), std::make_pair( 0xF000F800,0x0C5E07E2)
												, std::make_pair( 0xF800F800,0x045E07E3), std::make_pair( 0xF800F81F,0x045E07E0), std::make_pair( 0xF800F81F,0x046607E0)
												, std::make_pair( 0xF800F81F,0x046C07E0), std::make_pair( 0xF000F01E,0x0C7007E0), std::make_pair( 0xF800F01E,0x047007E1)
												, std::make_pair( 0xF800F01F,0x04700FE0), std::make_pair( 0xF000F01E,0x0C7207E0), std::make_pair( 0xF800F01E,0x047207E1)
												, std::make_pair( 0xF800F01F,0x04720FE0), std::make_pair( 0xF000F01E,0x0C7407E0), std::make_pair( 0xF800F01E,0x047407E1)
												, std::make_pair( 0xF800F01F,0x04740FE0), std::make_pair( 0xF800F81F,0x047607E0), std::make_pair( 0xF000F01E,0x0C7807E0)
												, std::make_pair( 0xF800F01E,0x047807E1), std::make_pair( 0xF800F01F,0x04780FE0), std::make_pair( 0xF000F01E,0x0C7A07E0)
												, std::make_pair( 0xF800F01E,0x047A07E1), std::make_pair( 0xF800F01F,0x047A0FE0), std::make_pair( 0xF800F81F,0x047C07E0)
												, std::make_pair( 0xF000F01E,0x0C7E07E0), std::make_pair( 0xF800F01E,0x047E07E1), std::make_pair( 0xF800F01F,0x047E0FE0) };

			/* Some field of some opcode must be higher than 0, this mask is used to check 
			To get more information about the opcode, please refer to document: G4MH_ISA_Arch_2015.10.11 (For FPU RIE)
			The opcode must which some filed must be !=00 or != 00000 .. etc*/
			static std::pair<UI32,UI32>  lowerBounMsk[18] = {  std::make_pair(0x000E0000,0x040E07E0), std::make_pair(0x000EF800,0x040EFFE0), std::make_pair(0xF800F800,0xFC40FFE4)
												, std::make_pair(0xF800F800,0xFC40FFF4), std::make_pair(0xF800F803,0xFC42FFE3), std::make_pair(0xF800F801,0xFC42FFF1)
												, std::make_pair(0xF800F800,0xFC44FFE4), std::make_pair(0xF800F800,0xFC44FFF4), std::make_pair(0xF800F801,0xFC48FFE1)
												, std::make_pair(0xF800F803,0xFC4EFFE3), std::make_pair(0xF800F800,0xFC50FFE4), std::make_pair(0xF800F800,0xFC50FFF4)
												, std::make_pair(0xF800F803,0xFC52FFE3), std::make_pair(0xF800F801,0xFC52FFF1), std::make_pair(0xF800F800,0xFC54FFE4)
												, std::make_pair(0xF800F800,0xFC54FFF4), std::make_pair(0xF800F801,0xFC58FFE1), std::make_pair(0xF800F803,0xFC5EFFE3) };

			//RIE opcode :Refer from G4MH_ISA_Arch_2015.10.11, Instruction code (FPU) sheet, row 29
			mskPos = g_rnd.GetRange(0, 122);

			//Case 93,95,97 was updated to Opcode of instruction in updated ISA specification
			if (mskPos == 93 || mskPos == 95 || mskPos == 97) mskPos = 3;

			retImm = g_rnd.GetRange(0x00000000U, 0xFFFFFFFFU);
			retImm &= ImmMskArrFpu[mskPos].first;
			retImm |= ImmMskArrFpu[mskPos].second;
			for (UI32 i = 0; i < 18; i++){
				if ( ( retImm | lowerBounMsk[i].first ) == lowerBounMsk[i].second ) {
					retImm  = 0x244027EF; // If meet constrain case, replace by a default value
					break;
				}
			}
		}
		else if  (insid == INS_CID_RIE_FXU64){

			/* Array of mask pairs to create RIE opcode. Each pair contain an AND mask (first value) and OR mask (second value)
			The generated value will be AND with first value and OR with second value
			To get more information about the opcode, please refer to document: G4MH_ISA_Arch_2015.10.11 (For FPU RIE)*/
			static std::pair<UI32,UI32> ImmMskArrFxu64[14] = { std::make_pair(0xFFFE001F, 0x000102E0), std::make_pair(0xFFE0001F, 0x00170780), std::make_pair(0xFFE0001F, 0x001707A0)
															, std::make_pair(0xFFE0001F, 0x00190780), std::make_pair(0xFFE0001F, 0x001907A0), std::make_pair(0xF820001F, 0x02DD07A0)
															, std::make_pair(0xF9E0001F, 0x041D07A0), std::make_pair(0xF860001F, 0x063D07A0), std::make_pair(0xF860001F, 0x065D07A0)
															, std::make_pair(0xF860001F, 0x067D07A0), std::make_pair(0xF820001F, 0x06DD07A0)
															, std::make_pair(0xF8E0001F, 0x071D07A0), std::make_pair(0xFFE0001F, 0x001F0780), std::make_pair(0xFFE0001F, 0x001F07A0) };

			//RIE opcode : Refer from G4MH_ISA_Arch_2015.10.11, Instruction code (TOP) sheet
			mskPos = g_rnd.GetRange(0, 13);
			retImm = g_rnd.GetRange(0x00000000U, 0xFFFFFFFFU);
			retImm &= ImmMskArrFxu64[mskPos].first;
			retImm |= ImmMskArrFxu64[mskPos].second;
		}
		else if (insid == INS_CID_RIE_INT64){

			/* Array of mask pairs to create RIE opcode. Each pair contain an AND mask (first value) and OR mask (second value)
			The generated value will be AND with first value and OR with second value
			To get more information about the opcode, please refer to document: G4MH_ISA_Arch_2015.10.11 (InSheet 1)*/
			static std::pair<UI32,UI32> ImmMskArrInt64[7] = { std::make_pair(0xFFFE001F,0x000102E0), std::make_pair(0xFFE0001F,0x00170780), std::make_pair(0xFFE0001F,0x001707A0)
															 , std::make_pair(0xFFE0001F,0x00190780), std::make_pair(0xFFE0001F,0x001907A0), std::make_pair(0xFFE0001F,0x001F0780)
															 , std::make_pair(0xFFE0001F,0x001F07A0)};

			//RIE opcode : Refer from G4MH_ISA_Arch_2015.10.11, Sheet1
			mskPos = g_rnd.GetRange(0, 6);
			retImm = g_rnd.GetRange(0x00000000U, 0xFFFFFFFFU);
			retImm &= ImmMskArrInt64[mskPos].first;
			retImm |= ImmMskArrInt64[mskPos].second;		
		}
		return retImm ;
	};

	// Lamda function to create 2 instructions of C2B1
	auto CreateContinuousIns = [&](UI32 instid1, UI32 instid2){
		pIns1 = nullptr;
		pIns2 = nullptr;
		pIns1 = this->CreateIns(instid1)->Fix();
		pIns2 = this->CreateIns(instid2)->Fix();
	};

	// Lamda function to adjust operand follow C2B1 constraint
	auto C2B1Constraint = [](IInstruction* pIns1, UI32 OprIns1, IInstruction* pIns2, UI32 OprIns2){
		UI32 regIns1 = pIns1->opr(OprIns1)->Idx();
		UI32 regIns2 = pIns2->opr(OprIns2)->Idx();
		if(pIns1->GetId() == INS_ID_MOVEA)
			pIns1->opr(1)->Replace(0);
		if (regIns1 != regIns2)
			pIns1->opr(OprIns1)->Replace(regIns2);
	};

	// Lamda function to set in sequence for C2B1 instrution
	auto SetC2B1Attribute = [] (IInstruction* pIns1, IInstruction* pIns2){
		pIns1->SetSequence(IInstruction::IF_SEQ_C2B1);
		pIns2->SetSequence(IInstruction::IF_SEQ_C2B1);
		pIns1->AppendComment(" -- first C2B1 instruction");
		pIns2->AppendComment(" -- second C2B1 instruction");
	};

	// Lamda function to adjust operand of second instruction of C2B1 instruction
	auto AdjustOprand = [](IInstruction *pIns, UI32 OprCons, UI32 OprChange){

		if(pIns->opr(OprCons)->Idx() == 0){
			UI32 newOpr = g_rnd.GetRange(1, 31);
			pIns->opr(OprCons)->Replace(newOpr);
		}
		while (pIns->opr(OprCons)->Idx() == pIns->opr(OprChange)->Idx()){
			UI32 newOpr = g_rnd.GetRange(1, 31);
			pIns->opr(OprChange)->Replace(newOpr);
		}
	};
	// Lamda function push 2 instructions into 1 complex instrruction and correct instruction id. 
	auto CreateComplexIns = [](IInstruction *pIns1, IInstruction *pIns2, UI32 insid, const char* name)->IInstruction* {
		ComplexInstruction* pCmp = new ComplexInstruction(insid, name);
		if(pIns1 != NULL)
			pCmp->push_back(pIns1);
		if(pIns2 != NULL)
			pCmp->push_back(pIns2);

		return (IInstruction*)pCmp;
	};

    //------------------------------------------------------------
    // lambda : Macro_LdArray
    // -----------------------------------------------------------
    //          Memory access in a row
    //    disptype : 0:Incriment, 1:decriment, 2:random
    //    iSet     : instruction set by weighted
    //    mr       : range of base reg value
    //    num      : num of instruction
    //    name     : comment 
    //------------------------------------------------------------    
    auto Macro_CaxiArray = [&] (UI32 disptype, CWeightedRandom<INS_ID>& iSet, MEMRANGE mr, UI32 num, const char* name) {
    	
    	std::string str(name);
  		if (disptype == 0) str = str + "(INC)"; 
  		if (disptype == 1) str = str + "(DEC)"; 
  		if (disptype == 2) str = str + "(RND)";    	
    	
        ComplexInstruction* pCmp = new ComplexInstruction(insid, name);
        IInstruction*       pIns;
        
     	UI32 destreg1;				// load/store   register
     	UI32 destreg2;				// load/store   register
     	UI32 basereg;				// base address register
        UI32 idx = 0;
     	basereg = gr_src[idx];	// select base reg
  		
		UI32 id = iSet.GetObj();
     	for (int t = 0; t < (int)num; t++) {
            idx = 0;
	     	std::random_shuffle(gr_src.begin(), gr_src.end(), g_rnd);
            do {
	     	    destreg1 = gr_src[idx];
                idx++;
            } while (destreg1 == basereg);

			std::random_shuffle(gr_src.begin(), gr_src.end(), g_rnd);
            idx = 0;
            do {
                destreg2 = gr_src[idx];
                idx++;
            } while (destreg2 == basereg);

			if(destreg1==destreg2){
				t--;
				continue ;
			}
	     	if (disptype == 2) {
	     		id = iSet.GetObj();
	     	}

    	 	pIns = this->CreateCAXIInsEx(id, mr, basereg, destreg1, destreg2)->Fix();
    	 	pIns->SetSequence(IInstruction::IF_SEQ_ARRAY);
    	 	pIns->AppendComment(str.c_str());
    	 	pCmp->push_back(pIns);
     	}
     	if (disptype != 2) {
			dispIncDec(pCmp, disptype);
     	}else{
     		// ビット幅が変化する連続パタンは最初をアラインしておく
     		// これをしない場合、アライン補正が入ることがある（実害は無い）。
     		SetArrayAlign(pCmp);
     	}
        return (IInstruction*)pCmp;
    };
	//------------------------------------------------------------
    // lambda : Macro_LDL_STC
    // -----------------------------------------------------------
    //          Generate ldl and stc instructions incouple .
    //    stcResult : 0: fail, 1:success, 2: TBD
    //    insid     : Instruction ID.
    //    name		: Instruction nam. 
    //------------------------------------------------------------ 
	auto Macro_LDL_STC = [&] (LDL_DataType tpye ,bool Result , UI32 insid, const char* name) {
    	
    	std::string str(name);
  	   	
        ComplexInstruction* pCmp = new ComplexInstruction(insid, str);
        IInstruction*       pIns1=NULL;
		IInstruction*       pIns2=NULL;
		switch (tpye) {
			//!<Byte
			case BYTE:
				//!< Push ldl Ins
				pIns1 = new CIns_661_ldl_bu();
				pIns1->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x00, 1));
				pIns1->AppendComment("ldl_stc_bu_");
				pIns1->SetRandomIns(true);
				pIns1->SetLDL_STC_CusIns(true);
				//!< Push stc Ins
				pIns2 = new CIns_664_stc_b();
                pIns2->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x00, 1));
				pIns2->SetRandomIns(true);
				pIns2->AppendComment("ldl_stc_b_");
			break;
			//!<HWORD
			case HWORD:
				//!< Push ldl Ins
				pIns1 = new CIns_662_ldl_hu();
				pIns1->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x01, 2));
				pIns1->AppendComment("ldl_stc_hu_");
				pIns1->SetRandomIns(true);
				pIns1->SetLDL_STC_CusIns(true);
				//!< Push stc Ins
				pIns2 = new CIns_665_stc_h();
                pIns2->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x01, 2));
				pIns2->SetRandomIns(true);
				pIns2->AppendComment("ldl_stc_h_");
			break;
			//!<WORD
			case WORD :
				//!< Push ldl Ins
				pIns1 = new CIns_98_ldl_w();
				pIns1->opr(0)->SetConstraint(new CLoadAddressSelector(GET_LOAD_HEAD(), GET_LOAD_TAIL(), 0x03, 4));
				pIns1->AppendComment("ldl_stc_w_");
				pIns1->SetRandomIns(true);
				pIns1->SetLDL_STC_CusIns(true);
				//!< Push stc Ins
				pIns2 = new CIns_172_stc_w();
                pIns2->opr(1)->SetConstraint(new CStoreAddressSelector(GET_STORE_HEAD(), GET_STORE_TAIL(), 0x03, 4));
				pIns2->SetRandomIns(true);
				pIns2->AppendComment("ldl_stc_w_");
				break;
			break;
		}
		
		if (Result) { //!< Success
			pIns1->AppendComment("success");
            pIns1->SetSTCSuccess(true);
			pIns2->AppendComment("success");
			pIns1->SetCoupleIns(pIns2);
			pCmp->push_back(pIns1);
		} else {	//!< Fail
			pIns1->AppendComment("false");
            pIns1->SetSTCSuccess(false);
			pIns2->AppendComment("false");
			pIns1->SetCoupleIns(pIns2);
			pCmp->push_back(pIns1);
		}
		
    	
        return (IInstruction*)pCmp;
    };

	//-----------------------------------------------------------

	MEMBITS mb;
	if (g_FlagAddr->Count() > 0) {
		mb = g_FlagAddr->SelectValue();
	}
	
	switch (insid) {
	case INS_CID_CLR1_B:
		pIns1 = new CIns_56_clr1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint((UI32)mb.first,  (UI32)mb.first,  0, 1) );
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first == 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C56_clr1");
		break;
	case INS_CID_CLR1:
		pIns1 = new CIns_57_clr1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			
			//補正できないパターン
			if ((pIns1->opr(0)->Idx() == 0) && (mb.second != 0)) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first != 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
			while (pIns1->opr(0)->Idx() == pIns1->opr(1)->Idx()) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C57_clr1");
		break;

	case INS_CID_NOT1_B:
		pIns1 = new CIns_117_not1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first == 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C117_not1");
		break;

	case INS_CID_NOT1:
		pIns1 = new CIns_118_not1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			//補正できないパターン
			if ((pIns1->opr(0)->Idx() == 0) && (mb.second != 0)) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first != 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
			while (pIns1->opr(0)->Idx() == pIns1->opr(1)->Idx()) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C118_not1");
		break;

	case INS_CID_SET1_B:
		pIns1 = new CIns_147_set1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first == 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C147_set1");
		break;

	case INS_CID_SET1:
		pIns1 = new CIns_148_set1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			//補正できないパターン
			if ((pIns1->opr(0)->Idx() == 0) && (mb.second != 0)) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first != 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
			while (pIns1->opr(0)->Idx() == pIns1->opr(1)->Idx()) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C148_set1");
		break;

	case INS_CID_TST1_B:
		pIns1 = new CIns_186_tst1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		}else{
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first == 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C186_tst1");
		break;

	case INS_CID_TST1:
		pIns1 = new CIns_187_tst1();
		if (g_FlagAddr->Count() == 0) {
			pIns1->opr(1)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x00, 1 ));
		} else {
			pIns1->opr(0)->SetConstraint(new INumConstraint(mb.second, mb.second) );
			pIns1->opr(1)->SetConstraint(new IValConstraint(mb.first,  mb.first,  0, 1) );
			//補正できないパターン
			if ((pIns1->opr(0)->Idx() == 0) && (mb.second != 0)) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
			if ((pIns1->opr(1)->Idx() == 0) && (mb.first != 0)) {
				pIns1->opr(1)->Replace(g_rnd.GetRange(1,31));
			}
			while (pIns1->opr(0)->Idx() == pIns1->opr(1)->Idx()) {
				pIns1->opr(0)->Replace(g_rnd.GetRange(1,31));
			}
		}
		pIns = CreateComplexIns(pIns1, NULL, insid, "CIns_C187_tst1");
		break;

	case INS_CID_PREF_I:
		pIns = Macro_pref_I(gr_src.at(0), gr_src.at(1));
		break;
	
	// ---------------------------------------------------
	// 
	case INS_CID_LD_ARRAY:
	{
		UI32 temp = nMismatchedReg & (nMismatchedReg >> 1) & 0x55555555; // Get idx which's even and (idx + 1) also in set
        for (UI32 i = 0; i < 32; i++) {
            if(((temp >> i) & 1) == 0) {
                gr_dst.erase(std::remove(gr_dst.begin(), gr_dst.end(), i), gr_dst.end());
            }
        }
		if (m_ldIns == true && m_ldIns.Count() && gr_dst.size()) {
			pIns = Macro_LdArray(g_rnd.Get() % 3, m_ldIns, g_LoadableAddr->SelectRange(), g_rnd.GetRange(m_ldArrayNum.first, m_ldArrayNum.second), "Ins_C010_ld_array");
		} else {
		    ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C010_ld_array");
		    pIns = (IInstruction*)pCmp;
        }
		break;
	}

	case INS_CID_ST_ARRAY:
	{
		UI32 temp = nMatchedReg & (nMatchedReg >> 1) & 0x55555555; // Get idx which's even and (idx + 1) also in set
        for (UI32 i = 0; i < 32; i++) {
            if(((temp >> i) & 1) == 0) {
                gr_src.erase(std::remove(gr_src.begin(), gr_src.end(), i), gr_src.end());
            }
        }
		if (m_stIns == true && m_stIns.Count() && gr_src.size()) {
			pIns = Macro_LdArray(g_rnd.Get() % 3, m_stIns, g_StorableAddr->SelectRange(), g_rnd.GetRange(m_stArrayNum.first, m_stArrayNum.second), "Ins_C011_st_array");
		} else {
		    ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C011_st_array");
		    pIns = (IInstruction*)pCmp;
        }
		break;
	}

	case INS_CID_LS_ARRAY:
	{
        UI32 temp = nMatchedReg & (nMatchedReg >> 1) & 0x55555555; // Get idx which's even and (idx + 1) also in set
        gr_src.erase ( std::remove_if(gr_src.begin(), gr_src.end(), [=](UI32 u)->bool {return ((u & temp) == 0);}), gr_src.end() );
        temp = nMismatchedReg & (nMismatchedReg >> 1) & 0x55555555; // Get idx which's even and (idx + 1) also in set
        gr_dst.erase ( std::remove_if(gr_dst.begin(), gr_dst.end(), [=](UI32 u)->bool {return ((u & temp) == 0);}), gr_dst.end() );
		if (m_lsIns == true && m_lsIns.Count() && gr_src.size() && gr_dst.size()) {
			pIns = Macro_LdArray(2, m_lsIns, g_RmwAddr->SelectRange(), g_rnd.GetRange(m_lsArrayNum.first, m_lsArrayNum.second), "Ins_C012_ls_array");
            break;
		} else {
		    ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C012_ls_array");
		    pIns = (IInstruction*)pCmp;
        }
		break;
	}

	case INS_CID_SLD_ARRAY:
        gr_dst.erase ( std::remove_if(gr_dst.begin(), gr_dst.end(), [](UI32 u)->bool {return (u == 30);}), gr_dst.end() );
		if (m_sldIns == true && m_sldIns.Count() && gr_dst.size()) {
			pIns = Macro_LdArray(g_rnd.Get() % 3, m_sldIns, g_LoadableAddr->SelectRange(), g_rnd.GetRange(m_sldArrayNum.first, m_sldArrayNum.second), "Ins_C013_sld_array");
		}
		else {
			ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C013_sld_array");
			pIns = (IInstruction*)pCmp;
		}
		break;

	case INS_CID_SST_ARRAY:
        gr_src.erase ( std::remove_if(gr_src.begin(), gr_src.end(), [](UI32 u)->bool {return (u == 30);}), gr_src.end() );
		if (m_sstIns == true && m_sstIns.Count() && gr_src.size()) {
			pIns = Macro_LdArray(g_rnd.Get() % 3, m_sstIns, g_StorableAddr->SelectRange(), g_rnd.GetRange(m_sstArrayNum.first, m_sstArrayNum.second), "Ins_C014_sst_array");
		}
		else {
			ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C014_sst_array");
			pIns = (IInstruction*)pCmp;
		}
		break;

	case INS_CID_SLS_ARRAY:
        gr_src.erase ( std::remove_if(gr_src.begin(), gr_src.end(), [](UI32 u)->bool {return (u == 30);}), gr_src.end() );
        gr_dst.erase ( std::remove_if(gr_dst.begin(), gr_dst.end(), [](UI32 u)->bool {return (u == 30);}), gr_dst.end() );
		if (m_slsIns == true && m_slsIns.Count() && gr_src.size() && gr_dst.size()) {
			pIns = Macro_LdArray(2, m_slsIns, g_RmwAddr->SelectRange(), g_rnd.GetRange(m_slsArrayNum.first, m_slsArrayNum.second), "Ins_C015_sls_array");
		}
		else {
			ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C015_sls_array");
			pIns = (IInstruction*)pCmp;
		}
		break;

	case INS_CID_CAXI_ARRAY:
        gr_src.erase ( std::remove_if(gr_src.begin(), gr_src.end(), [](UI32 u)->bool {return (u == 30);}), gr_src.end() );
        gr_dst.erase ( std::remove_if(gr_dst.begin(), gr_dst.end(), [](UI32 u)->bool {return (u == 30);}), gr_dst.end() );
		if (m_caxiIns == true && m_caxiIns.Count() && gr_src.size() && gr_dst.size() > 1) {
			pIns = Macro_CaxiArray(2, m_caxiIns, g_RmwAddr->SelectRange(), g_rnd.GetRange(m_caxiArrayNum.first, m_caxiArrayNum.second), "Ins_C016_caxi_array");
		}
		else {
			ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C016_caxi_array");
			pIns = (IInstruction*)pCmp;
		}
		break;
		
	case INS_CID_MPU_UPDATE: // MPU Update
		// This instruction will be updated after generated.
		pIns = (IInstruction*) new ComplexInstruction(insid, "Ins_C017_mpu_update");
		break;

	case INS_CID_MOV_ALU:
		ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_SUB, INS_ID_SUBR, INS_ID_AND, INS_ID_OR, INS_ID_XOR, INS_ID_SHL_I5, INS_ID_SHR_I5, INS_ID_SAR_I5};

		while((Ins1Id == INS_ID_MOVI5) && (Ins2Id == INS_ID_ADD_I5)){
			Ins1Id = g_rnd.GetRange(INS_ID_MOV, INS_ID_MOVI5);
			Ins2Id = RandomId(ALU);
		}
		CreateContinuousIns(Ins1Id, Ins2Id);
		AdjustOprand(pIns2, 1, 0);
		C2B1Constraint(pIns1, 1, pIns2, 1);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C018_mov_alu");
		break;

	case INS_CID_MOVR_SHIFT:
		SHIFT = {INS_ID_SHL_I5, INS_ID_SHR_I5};
		CreateContinuousIns(INS_ID_MOV, RandomId(SHIFT));
		C2B1Constraint(pIns2, 1, pIns1, 1);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C019_movr_shift");

		break;

	case INS_CID_MOV_SST:
		SHORT_STORE = {INS_ID_SST_B, INS_ID_SST_H, INS_ID_SST_W};
		CreateContinuousIns(g_rnd.GetRange(INS_ID_MOV, INS_ID_MOVI5), RandomId(SHORT_STORE));
		while(pIns2->opr(0)->Idx() == 0){
			pIns2->opr(0)->Replace(g_rnd.GetRange(1, 31));
		}
		while(pIns1->opr(0)->Idx() == 30){
			pIns1->opr(0)->Replace(g_rnd.GetRange(0, 31));
		}
		AdjustOprand(pIns2, 1, 0);
		C2B1Constraint(pIns1, 1, pIns2, 0);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C020_mov_sst");

		break;

	case INS_CID_MOV5_ST:
		STORE_C2B1 = {INS_ID_ST_B_SD16, INS_ID_ST_H_SD16, INS_ID_ST_W_SD16};
		CreateContinuousIns(INS_ID_MOVI5, RandomId(STORE_C2B1));
		AdjustOprand(pIns2, 0, 1);
		C2B1Constraint(pIns1, 1, pIns2, 0);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C021_mov5_st");

		break;

	case INS_CID_MOVEA_SST:
		SHORT_STORE = {INS_ID_SST_B, INS_ID_SST_H, INS_ID_SST_W};
		CreateContinuousIns(INS_ID_MOVEA, RandomId(SHORT_STORE));
		while(pIns2->opr(0)->Idx() == 0){
			pIns2->opr(0)->Replace(g_rnd.GetRange(1, 31));
		}
		AdjustOprand(pIns2, 1, 0);
		C2B1Constraint(pIns1, 2, pIns2, 0);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C022_movea_sst");

		break;

	case INS_CID_MOVEA_ST:
		STORE_C2B1 = {INS_ID_ST_B_SD16, INS_ID_ST_H_SD16, INS_ID_ST_W_SD16};
		CreateContinuousIns(INS_ID_MOVEA, RandomId(STORE_C2B1));
		AdjustOprand(pIns2, 0, 1);
		C2B1Constraint(pIns1, 2, pIns2, 0);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C023_movea_st");

		break;

	case INS_CID_CMP_BCC:

		while(BCondId == INS_ID_BR_SD9){
			BCondId = g_rnd.GetRange(INS_ID_BC_SD9, INS_ID_BZ_SD17);
		}
		CreateContinuousIns(g_rnd.GetRange(INS_ID_CMP, INS_ID_CMP_SI5) , BCondId);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C024_cmp_bcc");

		break;

	case INS_CID_ALU_BCC:
		ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_SUB, INS_ID_SUBR, INS_ID_TST, INS_ID_AND, INS_ID_OR, INS_ID_XOR, INS_ID_SHL_I5, INS_ID_SHR_I5, INS_ID_SAR_I5};

		while(BCondId == INS_ID_BR_SD9){
			BCondId = g_rnd.GetRange(INS_ID_BC_SD9, INS_ID_BZ_SD17);
		}
		CreateContinuousIns(RandomId(ALU), BCondId);
		pIns1->SetC2B1Ins(pIns2);
		SetC2B1Attribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C025_alu_bcc");

		break;

	case INS_CID_LDLBU_STCB_S: // LDL and STC in couple successfully.
		pIns = Macro_LDL_STC(BYTE,true,insid, "Ins_C025_ldlbu_stc_b_s");
		break;
	
	case INS_CID_LDLBU_STCB_F: // LDL and STC in couple Fail.
		pIns = Macro_LDL_STC(BYTE,false,insid, "Ins_C026_ldlbu_stc_b_f");
		break;

	case INS_CID_LDLHU_STCH_S: // LDL and STC in couple successfully.
		pIns = Macro_LDL_STC(HWORD,true,insid, "Ins_C027_ldlhu_stc_h_s");
		break;
	
	case INS_CID_LDLHU_STCH_F: // LDL and STC in couple Fail.
		pIns = Macro_LDL_STC(HWORD,false,insid, "Ins_C028_ldlh_stc_h_f");
		break;

	case INS_CID_LDLW_STCW_S: // LDL and STC in couple successfully.
		pIns = Macro_LDL_STC(WORD,true,insid, "Ins_C029_ldlw_stc_w_s");
		break;
	
	case INS_CID_LDLW_STCW_F: // LDL and STC in couple Fail.
		pIns = Macro_LDL_STC(WORD,false,insid, "Ins_C030_ldlw_stc_w_f");
		break;

	case INS_CID_ALU_ALU:
	case INS_CID_ALU_JMP:
	case INS_CID_ALU_LDST:
	case INS_CID_ALU_DIV:
	case INS_CID_ALU_MUL:
	case INS_CID_ALU_SPECIAL:
	case INS_CID_ALU_FPU:
	case INS_CID_ALU_C2B1:
	case INS_CID_LD_ALU:
	case INS_CID_LD_JMP:
	case INS_CID_LD_LDST:
	case INS_CID_LD_DIV:
	case INS_CID_LD_MUL:
	case INS_CID_LD_SPECIAL:
	case INS_CID_LD_FPU:
	case INS_CID_LD_C2B1:
	case INS_CID_FPU_FPU:
	case INS_CID_C2B1_C2B1:
	case INS_CID_CMPFS_TRFSR:
		pIns = CreateForwardingIns(insid);
		break;

	case INS_CID_CHANGE_PRIV:		
		pIns = (IInstruction*) new ComplexInstruction (insid, "Ins_change_privilege");
		break;
        
    case INS_CID_CHANGE_MODE:
        pIns = (IInstruction*) new ComplexInstruction(insid, "Ins_change_mode");
        break;

    case INS_CID_CHANGE_VMACHINE:
        pIns = (IInstruction*) new ComplexInstruction(insid, "Ins_change_virtual_machine");
        break;

	case INS_CID_RIE_FPU32:
		pIns1 = _WORD(RandomRieOp(INS_CID_RIE_FPU32));
		pIns1->AppendComment(" RIE for FPU 32 bit code area mask, array position: ");
		pIns1->AppendComment(std::to_string(mskPos).c_str());
		pIns = CreateComplexIns(pIns1, NULL, insid, "Ins_C052_rie_fpu32");
		break;

	case INS_CID_RIE_FXU32:
		pIns1 = _WORD(RandomRieOp(INS_CID_RIE_FXU32));
		pIns1->AppendComment(" RIE for FXU 32 bit code area mask, array position: ");
		pIns1->AppendComment(std::to_string(mskPos).c_str());
		pIns = CreateComplexIns(pIns1, NULL, insid, "Ins_C053_rie_fxu32");
		break;

	case INS_CID_RIE_FXU64:
		pIns1 = _WORD(RandomRieOp(INS_CID_RIE_FXU64));				// RIE opcode for FXU64bit RIE
		pIns1->AppendComment(" RIE for FXU 64 bit code area mask, array position: ");
 		pIns1->AppendComment(std::to_string(mskPos).c_str());
 		pIns1->SetSequence();
 		pIns2 = this->CreateIns(456)->Fix();	// random haftword instruction for allocate bit [47:32]
		pIns2->AppendComment(" 2nd instruction in RIE couple ");
		pIns2->SetSequence();
		pIns1->SetRiePartner( pIns2);
		pIns2->SetRiePartner(pIns1);
		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C054_rie_fxu64");
		break;

	case INS_CID_RIE_INT64:
		pIns1 = _WORD(RandomRieOp(INS_CID_RIE_INT64));				// RIE opcode for INT64bit RIE
		pIns1->AppendComment(" RIE for INT code 64 bit area mask, array position: ");
 		pIns1->AppendComment(std::to_string(mskPos).c_str());
 		pIns1->SetSequence();
 		pIns2 = this->CreateIns(456)->Fix();	// random haftword instruction for allocate bit [47:32]
		pIns2->AppendComment(" 2nd instruction in RIE couple ");
		pIns2->SetSequence();
		pIns1->SetRiePartner( pIns2);
		pIns2->SetRiePartner(pIns1);
 		pIns = CreateComplexIns(pIns1, pIns2, insid, "Ins_C055_rie_int64");
 		break;

	case INS_CID_MPU_CHECK: // MPU checking function
		{
			ComplexInstruction* pCmp = new ComplexInstruction(insid, "Ins_C056_mpu_checking");
			UI32 spid_reg = g_rnd.GetRange(1, 31);
			UI32 addr_reg = g_rnd.GetRange(0, 31);
			UI32 size_reg = g_rnd.GetRange(0, 31);
			UI32 result_reg = g_rnd.GetRange(1, 31);
			UI32 mcc_reg = g_rnd.GetRange(0, 31);
			
			pCmp->push_back(STSR(g_rnd.GetRange(24, 31), spid_reg, 5));
			pCmp->back()->SetSequence();

			pCmp->push_back( DI() );
			pCmp->back()->SetSequence();
			
			pCmp->push_back(LDSR(size_reg, 9, 5));
			pCmp->back()->SetSequence();

			pCmp->push_back(LDSR(addr_reg, 8, 5));
			pCmp->back()->SetSequence();

			pCmp->push_back(LDSR(spid_reg, 12, 5));
			pCmp->back()->SetSequence();

			pCmp->push_back(LDSR(mcc_reg, 10, 5));
			pCmp->back()->SetSequence();

			pCmp->push_back(STSR(11, result_reg, 5));
			pCmp->back()->SetSequence();

			pCmp->push_back( EI() );
			pCmp->back()->SetSequence();
			pIns = (IInstruction*) pCmp;
		}
		break;

	default :	// User Code
		pIns = (IInstruction*) new ComplexInstruction (insid, "User_Instruction");
		break;
	}
	return pIns;
}

IInstruction *CInstructionSet::CreateForwardingIns(INS_ID ins_id) {

     UI32 mismatchReg = g_mgr->GetMismatchReg();
	//Define instruction set 
	static std::vector<UI32> ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_ADDI_SI16, INS_ID_CMP, INS_ID_CMP_SI5, INS_ID_MOV, INS_ID_MOVI5, INS_ID_MOVI32, INS_ID_MOVEA, INS_ID_MOVHI,
		INS_ID_SUB, INS_ID_SUBR, INS_ID_ADF, INS_ID_SBF, INS_ID_SATADD, INS_ID_SATADD_I5, INS_ID_SATADD_R3, INS_ID_SATSUB, INS_ID_SATSUB_R3, INS_ID_SATSUBI, INS_ID_SATSUBR,
		INS_ID_AND, INS_ID_ANDI_I16, INS_ID_NOT, INS_ID_OR, INS_ID_ORI, INS_ID_TST, INS_ID_XOR, INS_ID_XORI, INS_ID_BINS, INS_ID_BSH, INS_ID_BSW, INS_ID_CMOV,
		INS_ID_CMOV_SI5, INS_ID_HSH, INS_ID_HSW, INS_ID_ROTL, INS_ID_ROTL_I5, INS_ID_SAR, INS_ID_SAR_I5, INS_ID_SAR_R3, INS_ID_SASF, INS_ID_SETF, INS_ID_SHL, INS_ID_SHL_I5,
		INS_ID_SHL_R3, INS_ID_SHR, INS_ID_SHR_I5, INS_ID_SHR_R3, INS_ID_SXB, INS_ID_SXH, INS_ID_ZXB, INS_ID_ZXH, INS_ID_SCH0L, INS_ID_SCH0R, INS_ID_SCH1L, INS_ID_SCH1R};
	static std::vector<UI32> DIV = {INS_ID_DIV, INS_ID_DIVH_2, INS_ID_DIVH_3, INS_ID_DIVHU, INS_ID_DIVQ, INS_ID_DIVQU, INS_ID_DIVU};
	static std::vector<UI32> MUL = {INS_ID_MUL, INS_ID_MULI9, INS_ID_MULH, INS_ID_MULHI5, INS_ID_MULHI, INS_ID_MULU, INS_ID_MULUI9, INS_ID_MAC, INS_ID_MACU };
	static std::vector<UI32> SPECIAL = {INS_ID_LOOP, INS_ID_CAXI, INS_ID_SWITCH };
	static std::vector<UI32> JUMP = {INS_ID_JARL, INS_ID_JMP, INS_ID_JMPD32};

    static std::vector<UI32> FPU = {INS_ID_ABSF_S, INS_ID_ADDF_S, INS_ID_CEILF_SL, INS_ID_CEILF_SUL, INS_ID_CEILF_SUW, INS_ID_CEILF_SW, INS_ID_CMOVF_S, INS_ID_CMPF_S, INS_ID_CVTF_LS, INS_ID_CVTF_SL,
		INS_ID_CVTF_SUL, INS_ID_CVTF_SUW, INS_ID_CVTF_SW, INS_ID_CVTF_ULS, INS_ID_CVTF_UWS, INS_ID_CVTF_WS, INS_ID_DIVF_S, INS_ID_FLOORF_SL, INS_ID_FLOORF_SUL, INS_ID_FLOORF_SUW,
		INS_ID_FLOORF_SW, INS_ID_MAXF_S, INS_ID_MINF_S, INS_ID_MULF_S, INS_ID_NEGF_S, INS_ID_RECIPF_S, INS_ID_ROUNDF_SL, INS_ID_ROUNDF_SUL, INS_ID_ROUNDF_SUW, INS_ID_ROUNDF_SW,
		/*INS_ID_RSQRTF_S, INS_ID_SQRTF_S, Not supported due to mismach*/INS_ID_SUBF_S, INS_ID_TRFSR, INS_ID_TRNCF_SL, INS_ID_TRNCF_SUL, INS_ID_TRNCF_SUW, INS_ID_TRNCF_SW,
        INS_ID_CVTF_HS, INS_ID_CVTF_SH, INS_ID_FMAF_S, INS_ID_FMSF_S, INS_ID_FNMAF_S, INS_ID_FNMSF_S };
	static std::vector<UI32> LOAD_STORE = {INS_ID_LD_BSD16, INS_ID_LD_BSD23, INS_ID_LD_BUD16, INS_ID_LD_BUD23, INS_ID_LD_DW, INS_ID_LD_HSD16, INS_ID_LD_HSD23, INS_ID_LD_HUD16,
		INS_ID_LD_HUD23, INS_ID_LD_WSD16, INS_ID_LD_WSD23, INS_ID_LDL_W, INS_ID_SLD_B, INS_ID_SLD_BU, INS_ID_SLD_H , INS_ID_SLD_HU, INS_ID_SLD_W, INS_ID_SST_B, INS_ID_SST_H,
		INS_ID_SST_W, INS_ID_ST_B_SD16, INS_ID_ST_B_SD23, INS_ID_ST_DW, INS_ID_ST_H_SD16, INS_ID_ST_H_SD23, INS_ID_ST_W_SD16, INS_ID_ST_W_SD23, INS_ID_STC_W, INS_ID_CLR1_SD16,
		INS_ID_CLR1, INS_ID_NOT, INS_ID_NOT1SD16, INS_ID_NOT1, INS_ID_SET1_SD16, INS_ID_SET1, INS_ID_TST1_SD16, INS_ID_TST1,
		/*G4MH Ins*/INS_ID_LD_B_INC, INS_ID_LD_B_DEC, INS_ID_LD_BU_INC, INS_ID_LD_BU_DEC, INS_ID_LD_H_INC, INS_ID_LD_H_DEC, INS_ID_LD_HU_INC, INS_ID_LD_HU_DEC, INS_ID_LD_W_INC,
		INS_ID_LD_W_DEC, INS_ID_ST_B_INC, INS_ID_ST_B_DEC, INS_ID_ST_H_INC, INS_ID_ST_H_DEC, INS_ID_ST_W_INC, INS_ID_ST_W_DEC, INS_ID_LDL_BU, INS_ID_LDL_HU,
		INS_ID_STC_B, INS_ID_STC_H, /*FXU*/ INS_ID_LDV_DW, INS_ID_LDV_QW, INS_ID_LDV_W, INS_ID_LDVZ_H4, INS_ID_STV_DW, INS_ID_STV_QW, INS_ID_STV_W, INS_ID_STVZ_H4};

	static std::vector<UI32> C2B1 = {INS_CID_MOV_ALU, INS_CID_CMP_BCC, INS_CID_ALU_BCC};

	static std::vector<UI32> LOAD = {INS_ID_LD_BSD16, INS_ID_LD_BSD23, INS_ID_LD_BUD16, INS_ID_LD_BUD23, INS_ID_LD_DW, INS_ID_LDL_W, INS_ID_LD_HSD16, INS_ID_LD_HSD23, INS_ID_LD_HUD16,
		INS_ID_LD_HUD23, INS_ID_LD_WSD16, INS_ID_LD_WSD23, INS_ID_SLD_B, INS_ID_SLD_BU, INS_ID_SLD_H , INS_ID_SLD_HU, INS_ID_SLD_W, INS_ID_LD_B_INC, INS_ID_LD_B_DEC, INS_ID_LD_BU_INC,
		INS_ID_LD_BU_DEC, INS_ID_LD_H_INC, INS_ID_LD_H_DEC, INS_ID_LD_HU_INC, INS_ID_LD_HU_DEC, INS_ID_LD_W_INC, INS_ID_LD_W_DEC, INS_ID_LDL_BU, INS_ID_LDL_HU};
	static std::vector <UI32> LOAD_WORD = {INS_ID_LDL_W, INS_ID_LD_WSD16, INS_ID_LD_WSD23, INS_ID_SLD_W, INS_ID_LD_DW, INS_ID_LD_W_INC, INS_ID_LD_W_DEC};
	static std::vector<UI32> LOAD_POST_UPDATE = {INS_ID_LD_B_INC, INS_ID_LD_B_DEC, INS_ID_LD_BU_INC, INS_ID_LD_BU_DEC, INS_ID_LD_H_INC, INS_ID_LD_H_DEC, INS_ID_LD_HU_INC, INS_ID_LD_HU_DEC, INS_ID_LD_W_INC,
		INS_ID_LD_W_DEC, INS_ID_LDL_BU, INS_ID_LDL_HU};

	// Lamda function push 2 instructions into 1 complex instrruction and correct instruction id. 
	auto CreateComplexIns = [](IInstruction *pIns1, IInstruction *pIns2, UI32 insid, const char* name)->IInstruction* {
		ComplexInstruction* pCmp = new ComplexInstruction(insid, name);
		if(pIns1 != NULL)
			pCmp->push_back(pIns1);
		if(pIns2 != NULL)
			pCmp->push_back(pIns2);

		return (IInstruction*)pCmp;
	};

	// Lamda function to random instruction id
	auto RandomId = [](std::vector<UI32> vInsId){
		UI32 pos = g_rnd.GetRange(0U, vInsId.size()-1);
		return vInsId.at(pos);
	};

	// Lamda function to set forwarding attributes
	auto SetFWDAttribute = [] (IInstruction* pIns1, IInstruction* pIns2){
		if(pIns1 != NULL) {
			pIns1->SetSequence(IInstruction::IF_SEQ_FWD, true);
			pIns1->AppendComment(" -- First Forwarding Data instruction");
		}
		if(pIns2 != NULL) {
			pIns2->SetSequence(IInstruction::IF_SEQ_FWD, true);
			pIns2->AppendComment(" -- Second Forwarding Data instruction");
		}
	};


	// Lamda function to get GR register of pIns
	auto GetGrOpr = [](IInstruction* pIns, IOperand::OPR_ATTR opr_attr){
		std::vector<IOperand*> vOprGr;
		if(pIns->IsComplex()){
			ComplexInstruction* pCi = static_cast<ComplexInstruction*>(pIns);
			// Checked: There is no case that src of 1st instruction was used as dst of succeeding instruction.
			for(UI32 i = 0; i < pCi->size(); i++) {
				IInstruction *p = (*pCi)[i];
				for(UI32 oprIdx = 0; oprIdx < p->GetOpNum(); oprIdx++) {
					if(p->opr(oprIdx)->Attr(IOperand::OPR_ATTR_GR) && p->opr(oprIdx)->Attr(opr_attr)){
                        vOprGr.push_back(p->opr(oprIdx));
					}
				}
			}
		} else {
			for(UI32 oprIdx = 0; oprIdx < pIns->GetOpNum(); oprIdx++) {
				if(pIns->opr(oprIdx)->Attr(IOperand::OPR_ATTR_GR) && pIns->opr(oprIdx)->Attr(opr_attr)){
                    vOprGr.push_back(pIns->opr(oprIdx));
				}
			}
		}
		return vOprGr;
	};
	
	// Make dependent operand
	auto MakeDependentOperand = [=] (IInstruction* pIns1, IInstruction* pIns2) {
		UI32					nIns1Reg;
		UI32					nIns2Reg;
		bool					depend_opr = false;
		std::vector<IOperand*>	vOprSrc;
		std::vector<IOperand*>	vOprDst;
       
        //Remove mismatch register in forwarding
        pIns1->RemoveRegInList(mismatchReg, 0);
        pIns2->RemoveRegInList(mismatchReg, 0);
		vOprDst = GetGrOpr(pIns1, IOperand::OPR_ATTR_DST);
		vOprSrc = GetGrOpr(pIns2, IOperand::OPR_ATTR_SRC);
        if (vOprDst.size() == 0 || vOprSrc.size() == 0) {
            return false;
        }
		// Check dependent operand
		for (UI32 dst = 0; dst < vOprDst.size(); dst++) {
			nIns1Reg = vOprDst[dst]->Idx();
			for (UI32 src = 0; src < vOprSrc.size(); src++) {
				nIns2Reg = vOprSrc[src]->Idx();
				if(nIns1Reg == nIns2Reg){
					depend_opr = true;
					break;
				}
			}
			if(depend_opr == true)
				break;
		}

		// Replace dependent operand
		if(depend_opr == false){
			std::random_shuffle(vOprSrc.begin(), vOprSrc.end(), g_rnd);
			std::random_shuffle(vOprDst.begin(), vOprDst.end(), g_rnd);
			UI32 posS = 0;
			std::vector<UI32> vRegList;
			for(UI32 i = 1; i < 32; i++)
				if (((mismatchReg >> i) & 1) == 0) vRegList.push_back(i);
			std::random_shuffle(vRegList.begin(), vRegList.end(), g_rnd);

			while(( vOprSrc[posS]->Attr(IOperand::OPR_ATTR_PAIR) && ( (1 << (vOprDst[0]->Idx() + 1)) & mismatchReg) != 0) || 
                vOprSrc[posS]->Replace(vOprDst[0]->Idx()) == false) {
				// Random another Source Operand
				posS++;
				// Tried with all src operands (maximum operand of 1 ins)
				if(posS == vOprSrc.size()){
					posS = 0;
                    // Remove register that register pair is mismatched
                    // Use Erase–remove idiom
                    if (vOprSrc[posS]->Attr(IOperand::OPR_ATTR_PAIR)) {
                        vRegList.erase(std::remove_if(vRegList.begin(), vRegList.end(), [=](UI32 element) {return ((1 << (element + 1)) & mismatchReg); }), vRegList.end());
                    }
					// Randomize another register
					while(vRegList.size()) {
						UI32 r = vRegList.back();
						// [FROG]TODO: How about C2B1?
						if(vOprDst[0]->Replace(r)) {
							vRegList.pop_back();
							break;
                        }
						vRegList.pop_back();
					}
					if(vRegList.size() == 0) {
						return false;
					}
					vRegList.pop_back();
				}
			}
		}

		return true;

	};

	// Variable definition
	IInstruction *pIns1 = nullptr;
	IInstruction *pIns2 = nullptr;
	ComplexInstruction* pCIns1 = nullptr;
	ComplexInstruction* pCIns2 = nullptr;
	IInstruction *pIns = nullptr;

	// Check invalid ins_id
	switch(ins_id) {
	case INS_CID_ALU_ALU:
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(ALU))->Fix();
		MakeDependentOperand(pIns1, pIns2);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C032_alu_alu");
		break;

	case INS_CID_ALU_JMP:
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(JUMP))->Fix();
		MakeDependentOperand(pIns1, pIns2);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		if(pIns2->GetId() == INS_ID_JMPD32) {
			pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C033_alu_br");
		} else {
			pIns2->SetInsNeed(pIns1);
            pIns2->SetForcedAdjust();
			pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C033_alu_br");
		}
		break;

	case INS_CID_ALU_LDST:
		//[FROG]TODO: Specify limitation in usermanual
		//[FROG]TODO: Not regulate address register: 
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(LOAD_STORE))->Fix();

		if(MakeDependentOperand(pIns1, pIns2) == false) {
			// Generate a non-forwarding couple
			pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C034_alu_ldst");
			break;
		}

		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		// pIns1 will be inserted when regulating pIns2
		if(pIns1->GetGrDst() & pIns2->GetConstraintBit()) {
			pIns2->SetInsNeed(pIns1);
            pIns2->SetForcedAdjust();

            if (pIns2->Behavior(IInstruction::STORE_MEMORY) && g_cfg->m_vPeId.size() > 1) {// Do not access competitive memory
                for (UI32 op = 0; op < pIns2->GetOpNum(); op++)
                    if (pIns2->opr(op)->GetConstraint() != nullptr)
                        pIns2->opr(op)->GetConstraint()->SetRAMNotCompetitive(true);
            }
			pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C034_alu_ldst");
			break;
		}
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C034_alu_ldst");
		break;

	case INS_CID_ALU_DIV:
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(DIV))->Fix();
		MakeDependentOperand(pIns1, pIns2);

		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C035_alu_div");
		break;

	case INS_CID_ALU_MUL:
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(MUL))->Fix();
		MakeDependentOperand(pIns1, pIns2);

		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C036_alu_mul");
		break;

	case INS_CID_ALU_SPECIAL:
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(SPECIAL))->Fix();
		MakeDependentOperand(pIns1, pIns2);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		// pIns1 will be inserted when regulating pIns2
		if( pIns2->GetId() == INS_ID_LOOP || pIns2->GetId() == INS_ID_SWITCH
			|| pIns1->GetGrDst() & pIns2->GetConstraintBit()) {
			pIns2->SetInsNeed(pIns1);
            pIns2->SetForcedAdjust();
            if (pIns2->GetId() == INS_ID_CAXI && g_cfg->m_vPeId.size() > 1) // Do not access competitive memory
                pIns2->opr(0)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x03, 4, 0, true));
			pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C037_alu_special");
			break;
		}
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C037_alu_special");
		break;

	case INS_CID_ALU_FPU:
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(FPU))->Fix();
		// Remove FPU constraint, its value will be set by pIns1
		for(UI32 i = 0; i < pIns2->GetOpNum();i++){
			if(pIns2->opr(i)->GetConstraint())
				pIns2->opr(i)->RemoveConstraint();
		}
		MakeDependentOperand(pIns1, pIns2);

		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C038_alu_fpu");
		break;

	case INS_CID_ALU_C2B1:
		//[FROG]TODO: Support ST ins of C2B1 in E3V5
		pIns1 = this->CreateIns(RandomId(ALU))->Fix();
		pIns2 = this->CreateIns(RandomId(C2B1))->Fix();
		
		pCIns2 = static_cast<ComplexInstruction*>(pIns2);
		pIns1->SetForwardIns((*pCIns2)[0]);
		MakeDependentOperand(pIns1, pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C039_alu_c2b1");
		break;

	case INS_CID_LD_ALU:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(ALU))->Fix();
		MakeDependentOperand(pIns1, pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C040_ld_alu");
		break;	

	case INS_CID_LD_JMP:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(JUMP))->Fix();
		MakeDependentOperand(pIns1, pIns2);
		pIns1->SetForwardIns(pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		SetFWDAttribute(pIns1, pIns2);

		if(g_mgr->GetMismatchReg() == 0 && pIns2->GetId() == INS_ID_JMPD32) {
			pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C041_ld_br");
		} else {
			// RW area can not be used for jump (I area)
			std::vector<UI32>::iterator itr;
			itr = std::find_if(LOAD_POST_UPDATE.begin(), LOAD_POST_UPDATE.end(), [&pIns1] (UI32 id) {return (pIns1->GetId() == id);});
			// In case of post-update LD instruction, can not forward the address register to loop/switch.
			if(itr != LOAD_POST_UPDATE.end()) {
				while(pIns1->opr(1)->Idx() == 0)
					pIns1->opr(1)->Replace(g_rnd.GetRange(1, 31));	// r0 was not used in jump addressing
				if(pIns1->opr(0)->Idx() == pIns2->opr(0)->Idx()) {
					pIns2->opr(0)->Replace(pIns1->opr(1)->Idx());
				}
			}
			pIns2->SetInsNeed(pIns1);
            pIns2->SetForcedAdjust();
			pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C041_ld_br");
		}
		break;

	case INS_CID_LD_LDST:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(LOAD_STORE))->Fix();
		if(MakeDependentOperand(pIns1, pIns2) == false) {
			// Generate a non-forwarding couple
			pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C042_ld_ldst");
			break;
		}

		pIns1->SetForwardIns(pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		SetFWDAttribute(pIns1, pIns2);
		{ // Make a internal scope
			// pIns1 will be inserted when regulating pIns2
			UI32 nForwardAddress = pIns1->GetGrDst() & pIns2->GetConstraintBit();
			nForwardAddress &= (pIns1->opr(0)->GetGrSrc() & pIns1->opr(1)->GetGrDst()) ? ~0 : ~(pIns1->GetGrSrc());
			if(nForwardAddress) {
				// The constraint is 32bits address. The LD size should be WORD or more.
				std::vector<UI32>::iterator itr;
				itr = std::find_if(LOAD_WORD.begin(), LOAD_WORD.end(), [&pIns1] (UI32 id) {return (pIns1->GetId() == id);});
				if(itr == LOAD_WORD.end()) {
					// Current pIns1 is not suitable, re-generating
					IInstruction *p = this->CreateIns(RandomId(LOAD_WORD))->Fix();
					UI32 r = pIns1->opr(1)->Idx();
					if(p->opr(1)->Replace(r) == false) // LD.DW
						p->opr(1)->Replace(r & ~0x1);

					delete pIns1;
					pIns1 = p;
					SetFWDAttribute(pIns1, NULL);
				}

				pIns2->SetInsNeed(pIns1);
                pIns2->SetForcedAdjust();

                if (pIns2->Behavior(IInstruction::STORE_MEMORY) && g_cfg->m_vPeId.size() > 1) {// Do not access competitive memory
                    for (UI32 op = 0; op < pIns2->GetOpNum(); op++)
                        if (pIns2->opr(op)->GetConstraint() != nullptr)
                            pIns2->opr(op)->GetConstraint()->SetRAMNotCompetitive(true);
                }

				pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C042_ld_ldst");
				break;
			}
		}

		// The adjustment code of Ins2 may be inserted among pIns1 & pIns2.
		if(pIns1->GetConstraintBit() & pIns2->GetConstraintBit()) {
			UI32 disp = g_rnd.GetRange(0, 0);	// [TN]TODO: Set disp in range (max(dh1, dh2), min(dt1, dt2));
			UI32 size = pIns1->opr(0)->GetConstraint()->GetSize();
			pIns1->opr(0)->SetDispRange(disp, disp);
			pIns1->opr(0)->SetDisp(disp);
			pIns1->SetRepeat(2);
			if(pIns2->Behavior(IInstruction::STORE_MEMORY))
				pIns1->opr(0)->SetAttr(IOperand::OPR_ATTR_SMEM, true);
			IOperand *pConstOpr = nullptr;
			for(UI32 i = 0; i < pIns2->GetOpNum(); i++) {
				if(pIns2->opr(i)->GetConstraint() != NULL) {
					pConstOpr = pIns2->opr(i);
					break;
				}
			}
			if(pConstOpr != NULL) { // Checked: The contrary case will never occur with current instruction
				size = std::max(size, pConstOpr->GetConstraint()->GetSize());
				pIns1->opr(0)->GetConstraint()->SetSize(size); // Reserve and initialize for maximum size
				pConstOpr->SetDispRange(disp, disp);
				pConstOpr->SetDisp(disp);
				UI32 size2 = pConstOpr->GetConstraint()->GetSize();
				UI32 mask2 = pConstOpr->GetConstraint()->GetMask();
				pConstOpr->RemoveConstraint();// Access same memory as pIns1.
				pConstOpr->SetConstraint(new IDummyConstraint(mask2, size2)); //Dummy constraint
			}
		}
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C042_ld_ldst");
		break;

	case INS_CID_LD_DIV:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(DIV))->Fix();
		MakeDependentOperand(pIns1, pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C043_ld_div");
		break;

	case INS_CID_LD_MUL:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(MUL))->Fix();
		MakeDependentOperand(pIns1, pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C044_ld_mul");
		break;	

	case INS_CID_LD_SPECIAL:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();;
		pIns2 = this->CreateIns(RandomId(SPECIAL))->Fix();
		MakeDependentOperand(pIns1, pIns2);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);

		// pIns1 will be inserted when regulating pIns2
		if(pIns2->GetId() == INS_ID_LOOP || pIns2->GetId() == INS_ID_SWITCH) {
			// Checked: The valud of LOOP/SWITCH adjustment is less than 5. It is OK to be adjust by BYTE size or more.
			std::vector<UI32>::iterator itr;
			itr = std::find_if(LOAD_POST_UPDATE.begin(), LOAD_POST_UPDATE.end(), [&pIns1] (UI32 id) {return (pIns1->GetId() == id);});
			// In case of post-update LD instruction, can not forward the address register to loop/switch.
			if(itr != LOAD_POST_UPDATE.end()) {
				if(pIns1->opr(0)->Idx() == pIns2->opr(0)->Idx()) {
					pIns2->opr(0)->Replace(pIns1->opr(1)->Idx());
				}
			}
			pIns2->SetInsNeed(pIns1);
            pIns2->SetForcedAdjust();
			pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C045_ld_special");
			break;
		} else if(pIns2->GetId() == INS_ID_CAXI) {
			// The constraint is 32bits address. The LD size should be WORD or more.
			UI32 nForwardAddress = pIns1->GetGrDst() & pIns2->GetConstraintBit();
			nForwardAddress &= (pIns1->opr(0)->GetGrSrc() & pIns1->opr(1)->GetGrDst()) ? ~0 : ~(pIns1->GetGrSrc());
			if(nForwardAddress) {
				std::vector<UI32>::iterator itr;
				itr = std::find_if(LOAD_WORD.begin(), LOAD_WORD.end(), [&pIns1] (UI32 id) {return (pIns1->GetId() == id);});
				if(itr == LOAD_WORD.end()) {
					// Current pIns1 is not suitable, re-generating
					IInstruction *p = this->CreateIns(RandomId(LOAD_WORD))->Fix();
					UI32 r = pIns1->opr(1)->Idx();
					if(p->opr(1)->Replace(r) == false) // LD.DW
						p->opr(1)->Replace(r & ~0x1);

					delete pIns1;
					pIns1 = p;
					SetFWDAttribute(pIns1, NULL);
				}

				pIns2->SetInsNeed(pIns1);
                pIns2->SetForcedAdjust();

                if (g_cfg->m_vPeId.size() > 1) // Do not access competitive memory
                    pIns2->opr(0)->SetConstraint(new CRmwAddressSelector(GET_RMW_HEAD(), GET_RMW_TAIL(), 0x03, 4, 0, true));

				pIns = CreateComplexIns(NULL, pIns2, ins_id, "Ins_C045_ld_special");
				break;
			}
			
			// The adjustment code of Ins2 may be inserted among pIns1 & pIns2.
			if(pIns1->GetConstraintBit() & pIns2->GetConstraintBit()) {
				UI32 size = std::max(pIns1->opr(0)->GetConstraint()->GetSize(), pIns2->opr(0)->GetConstraint()->GetSize());
				pIns1->SetRepeat(2);
				pIns1->opr(0)->SetDispRange(0x0, 0x0);
				pIns1->opr(0)->SetDisp(0x0);
				pIns1->opr(0)->SetAttr(IOperand::OPR_ATTR_SMEM, true);
				pIns1->opr(0)->GetConstraint()->SetSize(size); // Reserve and initialize for maximum size-8bytes
				UI32 size2 = pIns2->opr(0)->GetConstraint()->GetSize();
				UI32 mask2 = pIns2->opr(0)->GetConstraint()->GetMask();
				pIns2->opr(0)->RemoveConstraint();// Access same memory as pIns1.
				pIns2->opr(0)->SetConstraint(new IDummyConstraint(mask2, size2)); //Dummy constraint
			}
		}
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C045_ld_special");
		break;

	case INS_CID_LD_FPU:
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(FPU))->Fix();
		// FPU's operand was adjusted by pIns1
		for(UI32 i = 0; i < pIns2->GetOpNum();i++){
			if(pIns2->opr(i)->GetConstraint())
				pIns2->opr(i)->RemoveConstraint();
		}
		MakeDependentOperand(pIns1, pIns2);
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C046_ld_fpu");
		break;

	case INS_CID_LD_C2B1:
		//[FROG]TODO: Support ST instruction in C2B1 (E3V5)
		pIns1 = this->CreateIns(RandomId(LOAD))->Fix();
		pIns2 = this->CreateIns(RandomId(C2B1))->Fix();
        pIns1->opr(0)->GetConstraint()->SetRAMNotCompetitive(true);
		pCIns2 = static_cast<ComplexInstruction*>(pIns2);
		pIns1->SetForwardIns((*pCIns2)[0]);
		MakeDependentOperand(pIns1, pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C047_ld_c2b1");
		break;

	case INS_CID_FPU_FPU:
		pIns1 = this->CreateIns(RandomId(FPU))->Fix();
		pIns2 = this->CreateIns(RandomId(FPU))->Fix();
		// FPU's operand was adjusted by pIns1
		for(UI32 i = 0; i < pIns2->GetOpNum();i++){
			if(pIns2->opr(i)->GetConstraint())
				pIns2->opr(i)->RemoveConstraint();
		}

		if (MakeDependentOperand(pIns1, pIns2) == false) {
			// Generate a non-forwarding couple
			pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C048_fpu_fpu");
			break;
		}

		pIns1->SetForwardIns(pIns2);
		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C048_fpu_fpu");
		break;

	case INS_CID_C2B1_C2B1:
		pIns1 = this->CreateIns(RandomId(C2B1))->Fix();
		pIns2 = this->CreateIns(RandomId(C2B1))->Fix();

		if (MakeDependentOperand(pIns1, pIns2) == false) {
			// Generate a non-forwarding couple
			pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C049_c2b1_c2b1");
			break;
		}

		//[FROG]TODO: Support ST instruction in E3V5 C2B1 couple
		pCIns1 = static_cast<ComplexInstruction*>(pIns1);
		pCIns2 = static_cast<ComplexInstruction*>(pIns2);
		(*pCIns1)[1]->SetForwardIns((*pCIns2)[0]);

		SetFWDAttribute(pIns1, pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C049_c2b1_c2b1");

		break;

	case INS_CID_CMPFS_TRFSR:
		pIns1 =  this->CreateIns(INS_ID_CMPF_S)->Fix();
		pIns2 =  this->CreateIns(INS_ID_TRFSR)->Fix();
		SetFWDAttribute(pIns1, pIns2);
        pIns1->RemoveRegInList(mismatchReg, 0);
        pIns2->RemoveRegInList(mismatchReg, 0);

		pIns1->SetForwardIns(pIns2);
		pIns = CreateComplexIns(pIns1, pIns2, ins_id, "Ins_C051_cmpfs_trfsr");
		break;

	default:
		pIns = (IInstruction*) new ComplexInstruction (ins_id, "User_Instruction");
		break;
	}

	return pIns;
}
