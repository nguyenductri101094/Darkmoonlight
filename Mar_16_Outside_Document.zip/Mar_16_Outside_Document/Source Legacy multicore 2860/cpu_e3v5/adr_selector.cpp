#include "adr_selector.h"



// --------------------------------------------------------------------------------------
//
//   CAddressSelector
//
// --------------------------------------------------------------------------------------

/**
 * @brief  指定値が制約に適合するかを検証します
 * @param  val 検証値
 * @return 適合する場合真を返す。
 */
bool CAddressSelector::IsValid(UI64 val) {
	
	if (m_pSegList == NULL) {
		return IValConstraint::IsValid(val);
	}
	
	//m_pSegList->Dump();

	bool bSuccess = !(this->GetType(IValConstraint::RAISE_MERROR));
	if (m_pSegList->Valid(val, m_nSzm, bSuccess) != true) {
		/* Exception起こしたくないのに起きる、起こしたいのに起きない */
		return false;
	}
	
	// MAE
	return IValConstraint::IsValid(val);
}


/**
 * @brief  制約に適合する目標を得る
 * @return 適合値を返す。
 */
UI64 CAddressSelector::SelectValue() {
	
	// メモリ許可リスト/論理アドレスリスト
	if (m_pSegList == NULL) {
		// データソースがない
		return IValConstraint::SelectValue();
	}
	
	//m_pSegList->Dump();
	
	// アクセス可能なリストをフィルター
	std::vector<CSegmentStatus*> vset;
	
	bool bExp = (this->GetType(IValConstraint::RAISE_MERROR));
	m_pSegList->FilterSegmentList(vset, !bExp);

	// 候補無しの場合は、例外制御を反転させる	
	if (vset.size() == 0) {
        bExp = !bExp;
		this->SetType(IValConstraint::RAISE_MERROR, bExp);
		m_pSegList->FilterSegmentList(vset, !bExp);
	}
	
	_ASSERT(vset.size());
	if (vset.size() == 0) {
		return IValConstraint::SelectValue();
	}
	
	// Listの中から選択
	CSegmentStatus* pSS = NULL;
	std::random_shuffle(vset.begin(), vset.end(), g_rnd);
	bool bSelected = false;
	UI32 try_time = 3;
	
	while(try_time > 0)	{ // Try to allocate 3 times
		while (vset.size()) {
			pSS = vset.back();
			vset.pop_back();
			if (pSS->m_nSize < m_nSzm) {
				continue;
			}
		
			_ASSERT(pSS);
							

			UI64 nMin = pSS->m_nAddr;
            UI64 nMax = pSS->m_nAddr + pSS->m_nSize - 1;

            nMin = (nMin + m_nMsk) & (~m_nMsk);

            if (nMax < nMin || ((nMax - nMin + 1) < (m_nSzm + m_nUnA))) {
                continue;
            }

			UI64 nAcMin = 0;
			UI64 nAcMax = 0;
			if(this->GetType(IValConstraint::ACCESS_RANGE)) {
				// Adjust the ranged based on accessed size.
                // Support force clear llbit
				nAcMin = (m_nAccessedMin + m_nMsk) & (~m_nMsk);
                nAcMax = m_nAccessedMax;

				//  2 memory areas must nested
				if(nMax < nAcMin || nAcMax < nMin) {
					continue;
				}

				// Select memory range.
                /**

                  |   +++++++++|+++++++++++++|              |
                  nMin       nAcMin        nAcMax         nMax

                  |++++++++++++|+++++++++++++|              |
                  nMin       nAcMin         nMax         nAcMax

                  |            |+++++++++++++|++++++++++++++|
                nAcMin        nMin         nAcMax         nMax

                  |            |+++++++++++++|              |
                nAcMin        nMin         nMax          nAcMax

                */    

                m_nMin = nMin;
                if (nAcMax < nMax && nAcMin > nMin && (nAcMax - nMin) > (m_nSzm + m_nUnA)) {
                    // case 1
                    m_nMax = nAcMax;
                    m_nMin = nAcMax - (m_nSzm + m_nUnA);
                } else {
                    m_nMax = nMax;
                }

                if ((m_nMax - m_nMin) < m_nSzm + m_nUnA) {
                    continue;
                }
				bSelected = true;
				break;
			} else {
                if (m_nUnA != 0) {
                    nAcMin = (nMin & (~m_nMsk)) + m_nUnA;
                    while (nAcMin < nMin) {
                        nAcMin += m_nSzm;
                    }
                    UI32 carry = nAcMin - nMin;
                    if (pSS->m_nSize < (m_nSzm + carry)) {
                        continue;
                    }
                }
				m_nMin = nMin;
				m_nMax = nMax;
				bSelected = true;
				break;
			}
		}
		// Allocated succesfully
		if(bSelected)
			break;

		try_time--;
		this->SetType(IValConstraint::ACCESS_RANGE, false);
        bExp = (try_time == 1) ? !bExp : bExp;
        this->SetType(IValConstraint::RAISE_MERROR, bExp);
        m_pSegList->FilterSegmentList(vset, !bExp);
	}

	vset.clear();// NOT delete! Clear all elements before destructor called.

	return IValConstraint::SelectValue();
}

// --------------------------------------------------------------------------------------
//
//   CLoadAddressSelector
//
// --------------------------------------------------------------------------------------


// --------------------------------------------------------------------------------------
//
//   CStoreAddressSelector
//
// --------------------------------------------------------------------------------------


