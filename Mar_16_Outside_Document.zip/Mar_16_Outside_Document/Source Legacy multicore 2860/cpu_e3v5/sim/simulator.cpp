#include	<cstdio>
#include	<iostream>
#include	<cstring>
#include	"simulator.h"
//#include	"regindex.h"
#include    "inttypes.h"
#include    "adr_selector.h"
#include    "rtg_cfg.h"
#include    "ifsim_ctrl.h"

//! 例外要因ビット
#define MMU_BIT_UR (0x00010000) //!< ユーザ・モードでの読み出し
#define MMU_BIT_UW (0x00020000) //!< ユーザ・モードでの書き込み
#define MMU_BIT_UX (0x00040000) //!< ユーザ・モードでの命令実行
#define MMU_BIT_SR (0x00080000) //!< スーパバイザ・モードでの読み出し
#define MMU_BIT_SW (0x00100000) //!< スーパバイザ・モードでの書き込み
#define MMU_BIT_SX (0x00200000) //!< スーパバイザ・モードでの命令実行
#define MMU_BIT_V  (0x00400000) //!< 一致するページの存在を示す
#define MMU_BIT_NP (0x00800000) //!< 次ページでの例外を示す
#define MMU_BIT_PB (0x01000000) //!< ページ境界例外を示す
#define MMU_BIT_ME (0x02000000) //!< 多重一致例外を示す
#define MMU_BIT_PERMIT (0x003f0000) //!< 権限ビット

static CSimulator *g_simulation ;		//<! @brief	シミュレータを参照する広域変数
extern std::shared_ptr<CGeneratorProfile>		g_prf;
extern std::unique_ptr<ISimulatorControl>		g_sim;

CSimulator::CSimulator() : m_nUndoLogOn( SIM_UNDO_DISABLE ) , m_vLLBit(), m_initialized( false ) {
}

CSimulator::~CSimulator() {
	std::vector<IUndoProfile*>::iterator itr;
	for (itr = m_Undo.begin(); itr != m_Undo.end(); itr++) {
		delete *itr;
	}
    //gcs_disable_simulator_stop(1);
    //gcs_reset_simulator();
}

/****************************************************************/
/*              High-level interface method group                 */
/****************************************************************/

#if defined(_DBG_SIM01_)
#define	_INFO_ON_ 1
#else
#define	_INFO_ON_ 0
#endif

bool CSimulator::Init(std::string& path) {
	g_simulation = this ;

	GCS_CB_INFO_EX cbInfo;
	GCS_HW_INFO_EX hwInfo;

    cbInfo.fpC      = cb_insert_comment;
    cbInfo.fpExM    = cb_update_generator_memory;
    cbInfo.fpExNR   = cb_update_nc_register;
    cbInfo.fpExVR   = cb_update_vc_register;
    cbInfo.fpExTR   = cb_update_tc_register;
    cbInfo.fpL      = cb_update_generator_llbit;
    cbInfo.fpExTLB  = cb_update_generator_tlb;

	m_bNM = true ;
	m_nPC= 0 ;

	bool ret= false ;
	m_nUndoLogOn= SIM_UNDO_API     ; //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	if (gcs_initialize_simulator_ex( _INFO_ON_ , &cbInfo, path,&hwInfo) == GCSIF_SUCCESS) {
		ret= true ;
	}
	m_nUndoLogOn= SIM_UNDO_DISABLE ; //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (hwInfo.vmnum == 1) {
        m_gmnum = 8;
        hwInfo.vmnum = 0;
    } else {
        m_gmnum = 0;
    }
	m_vmnum= hwInfo.vmnum ;
	m_htnum= hwInfo.threadnum ;
	m_mpnum= hwInfo.mpnum ;
	m_tlbnum= hwInfo.tlbnum ;
	m_bpnum= hwInfo.bpnum ;
	m_smallpage= hwInfo.smallpage ;
	m_initialized= true ;

	//ISS内の主にMPU/MMU関連のSreg／TLBエントリーの値をFROG内に取り込む
	InitMxuData();
    CAddressWeight*	aw = g_LoadableAddr.get();
    std::set<MEMRANGE> s = aw->KeySet();

    std::set<MEMRANGE>::iterator itr;
    for (itr = s.begin(); itr != s.end(); itr++) {
        m_mVacancy.insert(std::make_pair(itr->first, itr->second));
    }

	return ret ;
}

std::string CSimulator::GetSimulatorVersion( void ) {
	std::string version;
	gcs_get_simulator_version( version );
	return version;
} 

std::string CSimulator::GetName( void ) {
	return std::string( "CFOREST" ) ;
} 

bool CSimulator::GetSimulatorInfo(ISimulatorHwInfo &info) {
	if (!m_initialized) {
		m_nErrorInfo= ERR_NOT_INITIALIZED ;
		return ( false ) ;
	}
    info.m_gmnum    = m_gmnum;
	info.m_vmnum    = m_vmnum ;
	info.m_htnum    = m_htnum ;
	info.m_mpnum    = m_mpnum ;
	info.m_tlbnum   = m_tlbnum ;
	info.m_bpnum    = m_bpnum ;
	info.m_smallpage= m_smallpage ;

	m_nErrorInfo= ERR_CLEAN ;
	return ( true ) ;
} 

bool CSimulator::Step(SI32 htid ,UI64 address ,ISimulatorStepResp * response=NULL) {
	//!<BR>[処理細目]<BR>

	UI32    is_NM ;
	gcs_is_simulator_native( &is_NM ) ;

	UI32	success ;

    clear_statistics_memory();
	m_nCauseCode= 0 ;
	//!◎シミュレータを１ステップ実行させる。実行中に更新された情報はアンドゥコンテナに蓄積する。
	m_nUndoLogOn= SIM_UNDO_ENABLE  ; //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	m_tagsIns.push_back(m_Undo.size());
	if(is_NM == 0x01)
		m_Undo.push_back(new CPcRegProfile( 0x80000000 ,address )) ;
	else
		m_Undo.push_back(new CPcRegProfile( htid, address )) ;
	success= gcs_step_simulator( htid ) ;
	m_nUndoLogOn= SIM_UNDO_DISABLE ; //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	if (success != GCSIF_SUCCESS) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	
	UI32 machine ;
	gcs_is_simulator_native( &machine ) ;
	m_bNM= (machine) ? true : false ;
	
	FrogRegData value_128= (FrogRegData) 0;
    if (m_bNM == true) {
    	success= gcs_get_nc_register("PC" , &value_128);
    	if (success != GCSIF_SUCCESS) {
    		m_nErrorInfo= success ;
    		return (false) ;
    	}
    } else {
    	success= gcs_get_tc_register("PC" , &value_128 , htid);
    	if (success != GCSIF_SUCCESS) {
    		m_nErrorInfo= success ;
    		return (false) ;
    	}
    }
	m_nPC= (UI32)value_128 ;
    
	//!・引数により実行結果格納場所が与えられていれば次の２つを格納する。
	if (response) {
		//!・１．例外が発生していればEIIC/FEIC/DBICの更新値、発生していなければ０を例外情報として格納する。
		response->exception= (gcs_get_exception() == true) ? m_nCauseCode : 0 ;
    	//!・２．プログラムカウンタの更新値を格納する。
		response->pc= m_nPC ;
	}
	//!▽リターン。<BR><BR>
	return (true) ;
}


bool CSimulator::CreateChkPoint(std::string point_id)
{
	//!<BR>[処理細目]<BR>

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
std::cout	<< "\n>>>>>>>>>>>>>>>>>>>>>>> ChkPoint to \"" << point_id << "\"" << std::endl;
if (point_id.compare(1 ,18 ,"__codeblock_0_84aa ",1 ,18) == 0) {
	std::cout	<< std::endl;
}
#endif
	//!・タグ情報コンテナへ、現在のアンドゥーコンテナの使用位置（プロファイル番号）と指定されたtag名を登録。
	UI32 pos= m_Undo.size() ;
	std::pair<std::map<std::string,UI32>::iterator, bool> result;
	result = m_tags.insert( std::pair<std::string , UI32 >(point_id , pos ) ) ;
	if (!result.second ) {
		m_tags.erase(result.first);
		m_tags.insert( std::pair<std::string , UI32 >(point_id , pos ) ) ;
	}
	//!▽リターン。<BR><BR>
	return (true) ;
}

#define MAX_PROFILE 10000
#define MAX_TAGS    1000

bool CSimulator::Rollback(std::string point_id) {
	//!<BR>[処理細目]<BR>

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
std::cout	<< "\n@@@@@@@@@@@@@@@@@@@@@@@ RollBack to \"" << point_id << "\" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" << std::endl;
#endif
	IUndoProfile	undo ;

	//!◎プログラムカウンタの更新をキャッシュしていることを表すフラグをクリアする
	undo.Init() ;

	//!・指定されたtag名を検索
	std::map<std::string , UI32 >::iterator p ;
	p = m_tags.find(point_id) ;
	if (p == m_tags.end()) {
		//!・▽マッチしなければ異常リターン
		return (false) ;
	}
	//!・プロファイル番号を取得
	UI32 pos= p->second ;

	//!・プロファイル番号までロールバック
	if (m_Undo.size() > pos) {
		for (int i= 0 ;i < MAX_PROFILE ;i++) {
			//!・◎アンドゥーコンテナの末尾につながっている情報をシミュレータに書き戻す。ただしプログラムカウンタの更新は頻繁であるため最後の更新のみ行なうべくキャッシュしておく。
			IUndoProfile* Profile= m_Undo.back();
			Profile->WriteBack() ;
			//!・・情報を削除し使用していたメモリを開放する・
			delete Profile;
			//!・◎アンドゥーコンテナの末尾を削除する。
			m_Undo.pop_back() ;
			//!・・プロファイル番号に達したらやめる。
			if (m_Undo.size() <= pos) {
				break;
			}
		}
	}

	//!◎プログラムカウンタの更新がキャッシュさせれていれば（最後の更新のみ）シミュレータに書き戻す。
	undo.Flash() ;

	//!・posより後を指しているTagを削除する
	p= m_tags.begin() ;
	for (int i= 0 ;i < MAX_TAGS ;i++) {
		if (p == m_tags.end()) {
			break ;
		}
		if (p->second >= pos) {
			m_tags.erase( p ) ;
			p= m_tags.begin() ;
		} else {
			p++ ;
		}
	}
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
std::cout	<< "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n" << std::endl;
#endif
	//!・（ロールバックした結果で）ISS内の主にMPU/MMU関連のSreg／TLBエントリーの値をFROG内に取り込む
	//UpdateMxuData();
	//!▽リターン。<BR><BR>
	return (true) ;
} 

bool CSimulator::Rollback() {
	//!<BR>[処理細目]<BR>

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
std::cout	<< "\n@@@@@@@@@@@@@@@@@@@@@@@ RollBack to \"" << point_id << "\" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" << std::endl;
#endif
	IUndoProfile	undo ;

	//!◎プログラムカウンタの更新をキャッシュしていることを表すフラグをクリアする
	undo.Init() ;

	//!・指定されたtag名を検索
	std::map<std::string , UI32 >::iterator p ;
	UI32 pos = m_tagsIns.back();

	//!・プロファイル番号までロールバック
	if (m_Undo.size() > pos) {
		for (int i= 0 ;i < MAX_PROFILE ;i++) {
			//!・◎アンドゥーコンテナの末尾につながっている情報をシミュレータに書き戻す。ただしプログラムカウンタの更新は頻繁であるため最後の更新のみ行なうべくキャッシュしておく。
			IUndoProfile* Profile= m_Undo.back();
			Profile->WriteBack() ;
			//!・・情報を削除し使用していたメモリを開放する・
			delete Profile;
			//!・◎アンドゥーコンテナの末尾を削除する。
			m_Undo.pop_back() ;
			//!・・プロファイル番号に達したらやめる。
			if (m_Undo.size() <= pos) {
				break;
			}
		}
	}

	//!◎プログラムカウンタの更新がキャッシュさせれていれば（最後の更新のみ）シミュレータに書き戻す。
	undo.Flash() ;

	m_tagsIns.pop_back();
	// [FROG] TODO: Update tags
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
std::cout	<< "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n" << std::endl;
#endif
	//!・（ロールバックした結果で）ISS内の主にMPU/MMU関連のSreg／TLBエントリーの値をFROG内に取り込む
	//UpdateMxuData();
	//!▽リターン。<BR><BR>
	return (true) ;
} 

bool CSimulator::PresetMemory( bool isNC ,UI32 htid , UI64 vaddr, SI32 size , UI64 val, bool flag) {
	//!<BR>[処理細目]<BR>

	//!・書き込む値を文字列表現に変換する。
	if (htid >= m_htnum) {
		m_nErrorInfo= ERR_INVALID_OTHER_PARAM	;
		return (false) ;
	}
	//!・MMUが搭載されていれば論理→物理アドレス変換を行なう。
	UI64 address ;
	if (m_tlbnum == 0) {
		address = vaddr ;
	} else {
		//!・▽TLB不一致違反またはTLB多重一致違反があるアドレスではアドレス変換出来ないため異常リターン。
		UI32 rslt= V850_MMU_TransferAddr( isNC ,htid , vaddr ,size ,MXU_ACC_DONTCARE ,&address ,NULL ,NULL ,NULL ,NULL ,NULL ) ;
		if ((rslt & MMU_BIT_V) == 0) {
			m_nErrorInfo= ERR_MMU_VOID ;
			return (false) ;
		}
		else
		if (rslt & MMU_BIT_ME) {
			m_nErrorInfo= ERR_MMU_ME ;
			return (false) ;
		}
	}

	//!▽アンドゥ・コンテナに指定アドレスとサイズを含むメモリー初期値設定情報があれば正常リターン。（重複は後方を除去）
    std::map<UI32, CPresetMemProfile*>::iterator itr;
    itr = m_mPresetMem.lower_bound(address);
    if(itr != m_mPresetMem.end()) {
        CPresetMemProfile *Profile = itr->second;
		if ((address >= Profile->m_address)&&(address+size <= Profile->m_address+Profile->m_size)) {
			if(!flag){
#if !defined(NDEBUG)
/*DEBUG*/			std::cout	<< "Info : Skip PresetMemory"
/*DEBUG*/					<< " Waddress=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << address 
/*DEBUG*/					<< " size=0x"                  << size
/*DEBUG*/                   << " value=0x"                 << val
/*DEBUG*/					<< " Writen Memory: address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << Profile->m_address 
/*DEBUG*/					<< " size=0x"                  << Profile->m_size
/*DEBUG*/                   << " value=0x"                 << Profile->m_writen
/*DEBUG*/					<< std::endl;
#endif // !NDEBUG
				return (false) ;
			}
		}
    }

	//!・書き込む値を文字列表現に変換する。
	char	buf[42];
	UI8		code ;
	SI32	i= 0;
	UI32	success ;

	for (SI32 offset= 0 ;offset < size ;offset++ ) {
		code= ((UI8 *)&val)[offset] ;
		buf[i] = '0' ; i++ ;
		buf[i] = 'x' ; i++ ;
		if ((code >> 4) < 10) {
			buf[i] = '0' +  (code >> 4) ;
			} else {
				buf[i] = (code >> 4) - 10 + 'a' ;
			} 
		i++ ;
		if ((code & 15) < 10) { buf[i] = '0' +  (code & 15) ; } else { buf[i] = (code & 15) - 10 + 'a' ; } 
		i++ ;
		if (offset < (size-1)) {
			buf[i] = ',' ;
		} else {
			buf[i] = 0 ;
		} 
		i++ ;
	}
	//!・シミュレータ上のメモリに書き込みを行う。この書き込みで発生するコールバックにより書き込み物理アドレスとデータがプリセット情報としてアンドゥーコンテナに記録される。
	m_nUndoLogOn= SIM_UNDO_PRESET  ; //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	success= gcs_write_simulator_memory(address, size, std::string(buf)) ;
	m_nUndoLogOn= SIM_UNDO_DISABLE ; //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	//!▽書き込みエラーが無ければ正常リターン、あれば詳細情報を設定して異常リターン。<BR><BR>
	if (success != GCSIF_SUCCESS) {
		m_nErrorInfo= success ;
		return (false) ;
	}

    if (g_prf->IsLoadMem(address, size)) {

        std::map<MEMADDR, MEMADDR>::iterator mem_itr;
        mem_itr = m_mVacancy.upper_bound(address);
        mem_itr--;
        MEMADDR start = mem_itr->first, end = mem_itr->second;

        m_mVacancy.erase(mem_itr);
        if (address > start) {
            m_mVacancy.insert(std::make_pair(start, address));
        }
        if ((address + size) < end) {
            m_mVacancy.insert(std::make_pair(address + size, end));
        }
    }
   
	return (true) ;
}

bool CSimulator::WriteMemory( UI64 address , SI32 size , UI64 val ) {
	//!<BR>[処理細目]<BR>

	char	buf[42];
	UI8		code ;
	SI32	i= 0;
	UI32	success ;

	//!・書き込む値を文字列表現に変換する。
	for (SI32 offset= 0 ;offset < size ;offset++ ) {
		code= ((UI8 *)&val)[offset] ;
		buf[i] = '0' ; i++ ;
		buf[i] = 'x' ; i++ ;
		if ((code >> 4) < 10) {
			buf[i] = '0' +  (code >> 4) ;
			} else {
				buf[i] = (code >> 4) - 10 + 'a' ;
			} 
		i++ ;
		if ((code & 15) < 10) { buf[i] = '0' +  (code & 15) ; } else { buf[i] = (code & 15) - 10 + 'a' ; } 
		i++ ;
		if (offset < (size-1)) {
			buf[i] = ',' ;
		} else {
			buf[i] = 0 ;
		} 
		i++ ;
	}
	//!・シミュレータ上のメモリに書き込みを行う。
	m_nUndoLogOn= SIM_UNDO_API     ; //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	success= gcs_write_simulator_memory(address, size, std::string(buf)) ;
	m_nUndoLogOn= SIM_UNDO_DISABLE ; //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	//!▽書き込みエラーが無ければ正常リターン、あれば詳細情報を設定して異常リターン。<BR><BR>
	if (success != GCSIF_SUCCESS) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	return (true) ;
} 


bool CSimulator::ReadMemory( UI64 address , SI32 size , UI64 * val ) {
	//!<BR>[処理細目]<BR>

	std::string buf;
	UI8		code ;
	UI32	success ;
	LPSTR	bytes= (LPSTR)val ;

	//!・指定したメモリアドレスから読み出した値（文字列表現）を buf[] に受け取る。
	success= gcs_read_simulator_memory(address, size, buf) ;
	if (success != GCSIF_SUCCESS) {
		m_nErrorInfo= success ;
		return (false) ;
	}

	//!・buf[]に格納されている "(0x??,0x??,0x??,0x??)" 形式の文字列を数値に変換し m_value にセットする。
	if ((size <= 0)||(buf[0] != '(')||(buf[1] != '0')||(buf[2] != 'x')){
		m_nErrorInfo= GCSIF_ERR_ISS_MEMORY ;
		return (false) ;
	}
	*val= 0ULL ;
	for (SI32 offset= 0 ;offset < size ;offset++ ) {
		if ((buf[offset*5+1] != '0')||(buf[offset*5+2] != 'x')||((offset >= size-1)?(buf[offset*5+5] != ')'):(buf[offset*5+5] != ','))){
			m_nErrorInfo= GCSIF_ERR_ISS_MEMORY ;
			return (false) ;
		}
		code= buf[offset*5+4] ; 
		if ((code >= '0')&&(code <= '9')) {
			bytes[offset] += code - '0' ;
		}
		else
		if ((code >= 'a')&&(code <= 'f')) {
			bytes[offset] += code - 'a' + 10 ;
		} else {
			m_nErrorInfo= GCSIF_ERR_ISS_MEMORY ;
			return (false) ;
		}
		code= buf[offset*5+3] ; 
		if ((code >= '0')&&(code <= '9')) {
			bytes[offset] += (code - '0') * 16  ;
		}
		else
		if ((code >= 'a')&&(code <= 'f')) {
			bytes[offset] += (code - 'a' + 10) * 16 ;
		} else {
			m_nErrorInfo= GCSIF_ERR_ISS_MEMORY ;
			return (false) ;
		}
	}
	//!▽リターン。<BR><BR>
	return (true) ;
} 


bool CSimulator::ReadNcReg(UI32 * value , SI32 regID , SI32 selID ) {
	if ((selID < 0)||(selID > 15)||(regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	std::string name;
	if(!gcs_get_sreg_name(selID, regID, name)){
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}
	FrogRegData value_128= (FrogRegData) 0 ;
	SI32 success= gcs_get_nc_register(name , &value_128 ) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 


bool CSimulator::ReadTcReg(UI32 * value , SI32 regID , SI32 selID , SI32 htid ) {
	if ((selID < 0)||(selID > 15)||(regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	std::string name;
	if(!gcs_get_sreg_name(selID, regID, name)){
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}
	FrogRegData value_128= (FrogRegData) 0 ;
	SI32 success= gcs_get_tc_register(name , &value_128 , htid) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 

bool CSimulator::WriteNcReg(UI32  value , SI32 regID , SI32 selID ) {
	if ((selID < 0)||(selID > 15)||(regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	std::string name;
	if(!gcs_get_sreg_name(selID, regID, name)){
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}
	FrogRegData value_128= (FrogRegData) value ;
	SI32 success= gcs_set_nc_register(name , value_128 ) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	return (true) ;
} 


bool CSimulator::WriteTcReg(UI32 value , SI32 regID , SI32 selID , SI32 htid ) {
	if ((selID < 0)||(selID > 15)||(regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}
	std::string name;
	if(!gcs_get_sreg_name(selID, regID, name)){
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}
	FrogRegData value_128= (FrogRegData) value ;
	SI32 success= gcs_set_tc_register(name , value_128 , htid) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	return (true) ;
} 

bool CSimulator::ReadVcReg(UI32 * value , SI32 regID , SI32 selID , SI32 vcid ) {
	if ((regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	std::string name;
	if(!gcs_get_sreg_name(selID, regID, name)){
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	SI32 success ;
	FrogRegData value_128 = (FrogRegData) 0 ;
	success= gcs_get_vc_register(name , &value_128 , vcid) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 


bool CSimulator::ReadGrReg(UI32 * value ,SI32 regID , SI32 tcid ) {
	if ((regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	char str[5];
	sprintf(str, "R%d", regID);
	std::string name(str);

	FrogRegData value_128= (FrogRegData) 0 ;

	UI32	is_NM, success;
	gcs_is_simulator_native( &is_NM ) ;

	if(tcid == 0 && is_NM == 0x01){
		success= gcs_get_nc_register(name , &value_128) ;
	} else {
		success= gcs_get_tc_register(name , &value_128, tcid) ;
	}
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 

bool CSimulator::ReadSysRegister(UI32 * value, std::string registerName , SI32 tcid ) {

	FrogRegData value_128= (FrogRegData) 0 ;

	UI32	is_NM, success;
	gcs_is_simulator_native( &is_NM ) ;

	if(tcid == 0 && is_NM == 0x01){
		success= gcs_get_nc_register(registerName , &value_128) ;
	} else {
		success= gcs_get_tc_register(registerName , &value_128, tcid) ;
	}
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 

//#define MPX4_FULL      0x3
//#define MPX4_HARF_64   0x2
//#define MPX4_HARF_64_  0x1
//#define MPX4_HARF_128  0x0

bool CSimulator::ReadWrReg(__uint128_t * value ,SI32 regID , SI32 tcid ) {

/*
	UI32 mpxinfo ;
	ReadNcReg(&mpxinfo, 9, 8) ;
	mpxinfo &= 0x3 ;
	printf("MPXINFO : 0x%08x\n", mpxinfo) ;
	printf("regID   : %d\n", regID) ;
	if( mpxinfo==MPX4_HARF_128 ) {
		if ((regID < 0)||(regID > 16)) {
			m_nErrorInfo= ERR_INVALID_REGISTER ;
			return (false) ;
		}
	} else if( mpxinfo==MPX4_HARF_64 || mpxinfo==MPX4_FULL  )
*/
	{
		if ((regID < 0)||(regID > 31)) {
			m_nErrorInfo= ERR_INVALID_REGISTER ;
			return (false) ;
		}
	}

	char str[5];
	sprintf(str, "WR%d", regID);
	std::string name(str);

	UI32	is_NM;
	gcs_is_simulator_native( &is_NM ) ;
	if(tcid == 0 && is_NM == 0x01){
		gcs_get_nc_register(name , (FrogRegData* ) value) ;
	} else {
		gcs_get_tc_register(name , (FrogRegData*) value, tcid) ;
	}

	return (true) ;
} 



bool CSimulator::ReadVeReg(UI64 * value ,SI32 regID , SI32 tcid ) {
	if ((regID < 0)||(regID > 31)) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}

	char str[5];
	sprintf(str, "VR%d", regID);
	std::string name(str);

	FrogRegData value_128= (FrogRegData) 0 ;
	SI32 success = GCSIF_SUCCESS;
	UI32 is_NM;
	gcs_is_simulator_native( &is_NM ) ;

	if(tcid == 0 && is_NM == 0x01){
		success = gcs_get_nc_register(name , &value_128) ;
	} else {
		success = gcs_get_tc_register(name , &value_128 , tcid) ;
	}
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= ERR_INVALID_REGISTER ;
		return (false) ;
	}
	*value = (UI64)value_128 ;
	return (true) ;
} 


bool CSimulator::ReadPC(UI32 * value ) {
	std::string name("PC");
	FrogRegData value_128= (FrogRegData) 0 ;
	SI32 success= gcs_get_nc_register(name , &value_128 ) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 


bool CSimulator::ReadPC(UI32 * value , SI32 htid ) {
	std::string name("PC");
	FrogRegData value_128= (FrogRegData) 0 ;
	SI32 success= gcs_get_tc_register(name , &value_128 , htid) ;
	if (GCSIF_SUCCESS != success) {
		m_nErrorInfo= success ;
		return (false) ;
	}
	*value = (UI32)value_128 ;
	return (true) ;
} 


bool CSimulator::GetErrorInfo(UI32 * value ) {
	*value= m_nErrorInfo ;
	return (true) ;
}

bool CSimulator::DumpTcReg( SI32 tcid ) {
	UI32 value[32];
	UI32 regID ;
	FrogRegData value_128= (FrogRegData) 0 ;
	for (regID= 0 ;regID < 32 ;regID++) {
		char str[5];
		sprintf(str, "R%d", regID);
		std::string name(str);

		SI32 success= gcs_get_tc_register(name , &value_128 , tcid) ;
		if (GCSIF_SUCCESS != success) {
			m_nErrorInfo= success ;
			return (false) ;
		}
		value[regID]= (UI32)value_128 ;
	}
	
	MSG_INFO(0 , " ============================ Dump register on TC#%d ==================================\n" ,tcid ) ;
	MSG_INFO(0 , " r0  - r7  : %08x %08x %08x %08x : %08x %08x %08x %08x\n" ,value[0] ,value[1] ,value[2] ,value[3] ,value[4] ,value[5] ,value[6] ,value[7] ) ;
	MSG_INFO(0 , " r8  - r15 : %08x %08x %08x %08x : %08x %08x %08x %08x\n" ,value[8] ,value[9] ,value[10],value[11],value[12],value[13],value[14],value[15]) ;
	MSG_INFO(0 , " r16 - r23 : %08x %08x %08x %08x : %08x %08x %08x %08x\n" ,value[16],value[17],value[18],value[19],value[20],value[21],value[22],value[23]) ;
	MSG_INFO(0 , " r24 - r31 : %08x %08x %08x %08x : %08x %08x %08x %08x\n" ,value[24],value[25],value[26],value[27],value[28],value[29],value[30],value[31]) ;

	return (true) ;
} 

void CSimulator::GetMemoryPresetData( std::vector<T_MEMWRRECORD > *  buff ) {
	//std::vector<IUndoProfile*>::iterator itr ;
	//for (itr= m_Undo.begin() ; itr != m_Undo.end(); itr++) {
	//	IUndoProfile * tmpProfile= *itr;
	//	if (tmpProfile->GetType() == 17) {					// MEMORY ACCESS
	//		CPresetMemProfile * Profile= (CPresetMemProfile *)tmpProfile ;
	//		std::pair<UI32,UI64> r= std::pair<UI32,UI64>(Profile->m_size , Profile->m_writen) ;
	//		buff->push_back(T_MEMWRRECORD(Profile->m_address,r));
	//	}
	//}

    std::map<UI32, CPresetMemProfile*>::iterator itr;
    for (itr = m_mPresetMem.begin(); itr != m_mPresetMem.end(); itr++) {
        CPresetMemProfile* Profile = itr->second;
        std::pair<UI32, UI64> r = std::pair<UI32, UI64>(Profile->m_size, Profile->m_writen);
        buff->push_back(T_MEMWRRECORD(Profile->m_address, r));
    }
}

void CSimulator::GetMemoryWritenData( std::vector<T_MEMWRRECORD > * buff ) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	MSG_INFO(0, "================================= writen memory ======================================\n");
#endif
	std::vector<IUndoProfile*>::iterator itr= m_Undo.end() ;
	for (itr--; itr != m_Undo.begin(); itr--) {
		IUndoProfile * tmpProfile= *itr;
		if (tmpProfile->GetType() == 16) {					// MEMORY ACCESS
			CWrMemProfile * Profile= (CWrMemProfile *)tmpProfile ;
			if (Profile->m_access_bus == SIM_UNDO_ENABLE) {
				UI64	value= 0ULL ;
				ReadMemory( Profile->m_address, Profile->m_size, &value ) ;
				std::pair<UI32,UI64> r= std::pair<UI32,UI64>(Profile->m_size , value) ;
				buff->push_back(T_MEMWRRECORD(Profile->m_address,r));
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
				std::cout	<< "Info : "
							<< "Writen Memory: address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << Profile->m_address 
							<< " size=0x"                  << Profile->m_size
							<< " data=0x"                  << std::setw(16) << std::right << std::setfill('0') << std::hex << value 
							<< std::endl;
#endif
        	}
		}
	}
}

void CSimulator::GetLLBitData( std::vector<T_LLBITRECORD > * buff ) {
    std::vector<T_LLBITRECORD >::iterator itr;
    for(itr = m_vLLBit.begin(); itr < m_vLLBit.end(); itr++) {
		buff->push_back(T_LLBITRECORD(*itr));
	}
}

/**
 * @brief	Send a interrupt request to simulator
 * @ptid	Physical thread ID of current machine
 * @name	Interrupt name
 * @channel	Interrupt channel
 * @priority	Interrupt priority incase of user interrupt (EIINT and EITBL).
 * @causecode	Cause code in case of SYSERR
 */
void CSimulator::RequestInterrupt(UI32 ptid, UI32 intId, std::string name, UI32 channel, UI32 priority, UI32 causecode, UI32 gpid) {
	UI32 isNM;
	gcs_is_simulator_native(&isNM);

	bool isNC = (isNM == 0x1) ? true : false;
	switch (intId) {
	case IException::EXP_SYSERR:
		gcs_req_syserr_pe(causecode, isNC, ptid);
		break;

	case IException::EXP_DBNMI:
		gcs_req_dbnmi_pe(isNC, ptid);
		break;

	case IException::EXP_DBINT:
		gcs_req_dbint_pe(channel, isNC, ptid);
		break;

	case IException::EXP_RMINT:
		gcs_req_rmint_pe(isNC, ptid);
		break;

	case IException::EXP_FENMI:
		gcs_req_fenmi_pe(isNC, ptid);
		break;

	case IException::EXP_FEINT:
		gcs_req_feint_pe(channel, false, gpid, false, isNC, ptid);
		break;

	case IException::EXP_EIINT:
		gcs_req_eiint_pe(channel, priority, false, false, gpid, false, isNC, ptid);
		break;

	case IException::EXP_EITBL:
		gcs_req_eiint_pe(channel, priority, true, false, gpid, false, isNC, ptid);
		break;

	case IException::EXP_GMFEINT:
		gcs_req_feint_pe(channel, true, gpid, false, isNC, ptid);
		break;

	case IException::EXP_GMEIINT:
		gcs_req_eiint_pe(channel, priority, false, true, gpid, false, isNC, ptid);
		break;

	case IException::EXP_GMEITBL:
		gcs_req_eiint_pe(channel, priority, true, true, gpid, false, isNC, ptid);
		break;

	case IException::EXP_BGFEINT:
		gcs_req_feint_pe(channel, true, gpid, true, isNC, ptid);
		break;
	
	case IException::EXP_BGEIINT:
		gcs_req_eiint_pe(channel, priority, false, true, gpid, true, isNC, ptid);

		break;
	default:
		break;
	}
}

void CSimulator::ClearInterrupt(UI32 ptid, UI32 eventId, std::string name) {
	UI32 isNM;
	gcs_is_simulator_native(&isNM);
	bool isNC = (isNM == 0x1) ? true : false;
	
    std::string interrupt_name = "";
    if (name == "gmfeint" || name == "bgfeint" ) {
        interrupt_name = "feint";
    } else if (name == "gmeiint" || name == "gmeitbl" || name == "bgeiint") {
        interrupt_name = "eiint";
    } else {
        interrupt_name = name;
    }


	gcs_clear_req_pe(interrupt_name, isNC, ptid);
}



bool CSimulator::IsNativeMachine (void) {
     return m_bNM;  
}

/**
* @brief Check memory range from addr to addr + size whether it has preset yet
* @return true if memory range do not preset
*/
bool CSimulator::IsInitMemory(UI64 addr, UI32 size) {
    MEMRANGE		mr(0,0);
    UI64 end_addr = addr + size;

    if (g_prf->IsLoadMem(addr, size) == false) return false;

    std::map<UI32, CPresetMemProfile*>::iterator itr;
    itr = m_mPresetMem.lower_bound(addr);

    if (itr != m_mPresetMem.begin() && itr != m_mPresetMem.end()) {
        CPresetMemProfile *cur_profile = itr->second;
        CPresetMemProfile *pre_Profile = (--itr)->second;
        if (end_addr <= cur_profile->m_address && addr >= pre_Profile->m_address + pre_Profile->m_size) {
            return true;
        } else {
            return false;
        }
    } 

    return true;
}

/**
* @brief find memory has size which do not preset memory
* @return start address of the memory area
*/
MEMADDR CSimulator::FindVacantMemory(UI32 size, UI64 align) {
    UI32 index = 0;
    UI32 ups = 0; 
    UI32 mask = ~ups;
	if(align != 0){
		ups = align - 1;
		mask = ~ups;
	}
	
    std::map<MEMADDR, MEMADDR> temp_vacancy = m_mVacancy;

    std::map<MEMADDR, MEMADDR>::iterator itr = temp_vacancy.begin();
    index = g_rnd.GetRange((UI32)0, temp_vacancy.size() - 1);
    std::advance(itr, index);
    // (itr->first + align - 1) & mask : Round up
    while (( ((itr->second - ((itr->first + ups) & mask)) < size) /*||
        g_sim->IsMDPexception( ((itr->first + ups) & mask), size, true, false) != NO_ERROR*/) && (temp_vacancy.size() - 1) != 0) {
        temp_vacancy.erase(itr);
        index = g_rnd.GetRange((UI32)0, temp_vacancy.size() - 1);
        itr = temp_vacancy.begin();
        std::advance(itr, index);
    }

    if ((temp_vacancy.size() - 1) == 0) return 0;

    return ((itr->first + ups) & mask);
}


/****************************************************************/
/*             Undoバッファ用インスタンスメソッド群             */
/****************************************************************/

/**
 * @brief システムレジスタ更新の取消し（ネイティブ・コンテキスト）
 *
 */
SI32 CNcRegProfile::WriteBack( void ){
	//!<BR>[処理細目]<BR>

	//!・保持していたレジスタ番号とバンク番号からレジスタ名（文字列）へ変換する。
	std::string name;
	if(!gcs_get_sreg_name(m_selID, m_regID, name)){
		return (ERR_INVALID_REGISTER) ;
	}

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "NC: " << name << " = " << std::hex << m_value << std::endl;
#endif
	//!・保持していた書き戻し値とレジスタ名で、シミュレータにネイティブ・コンテキストレジスタへの書き込みを求める。
	return gcs_set_nc_register(name, (FrogRegData)m_value) ;
}

/**
 * @brief システムレジスタ更新の取消し（スレッド・コンテキスト）
 *
 */
SI32 CTcRegProfile::WriteBack( void ){
	std::string name;
	if(!gcs_get_sreg_name(m_selID, m_regID, name)){
		return (ERR_INVALID_REGISTER) ;
	}
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "TC#" << std::dec << m_tcid << " : " << name << " = " << std::hex << m_value << std::endl;
#endif
	//!・保持していた書き戻し値とレジスタ名で、シミュレータにスレッド・コンテキストレジスタへの書き込みを求める。
	return gcs_set_tc_register(name, (FrogRegData)m_value, m_tcid) ;
}

/**
 * @brief システムレジスタ更新の取消し（仮想マシン・コンテキスト）
 *
 */
SI32 CVcRegProfile::WriteBack( void ){
	//!<BR>[処理細目]<BR>

	//!・保持していたレジスタ番号とバンク番号からレジスタ名（文字列）へ変換する。
	std::string name;
	if(!gcs_get_sreg_name(m_selID, m_regID, name)){
		return (ERR_INVALID_REGISTER) ;
	}
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "VC#" << std::dec << m_vcid << " : " << name << " = " << std::hex << m_value << std::endl;
#endif
	//!・保持していた書き戻し値とレジスタ名で、シミュレータに汎用レジスタへの書き込みを求める。
	return gcs_set_vc_register(name, (FrogRegData)m_value, m_vcid) ;
}

/**
 * @brief 汎用レジスタ更新の取消し
 *
 */
SI32 CGrRegProfile::WriteBack( void ){
	//!<BR>[処理細目]<BR>

	//!・保持していたレジスタ番号からレジスタ名（文字列）へ変換する。
	char str[5];
	sprintf(str, "R%d", m_regID);
	std::string name(str);
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "TC#" << std::dec << m_tcid << " : " << name << " = " << std::hex << m_value << std::endl;
#endif
	//!・保持していた書き戻し値とレジスタ名で、シミュレータにベクタレジスタへの書き込みを求める。
	UI32 mode;
	gcs_is_simulator_native(&mode);
	if(mode == 0x01)
		return gcs_set_nc_register(name, (FrogRegData)m_value) ;
	else
		return gcs_set_tc_register(name, (FrogRegData)m_value, m_tcid) ;
}

/**
 * @brief ベクタ・レジスタ更新の取消し
 *
 */
SI32 CVeRegProfile::WriteBack( void ){
	//!<BR>[処理細目]<BR>
	//!・保持していたレジスタ番号からレジスタ名（文字列）へ変換する。
	char str[5];
	sprintf(str, "VR%d", m_regID);
	std::string name(str);

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "TC#" << std::dec << m_tcid << " : " << name << " = " << std::hex << m_value << std::endl;
#endif
	UI32 mode;
	gcs_is_simulator_native(&mode);
	if(mode == 0x01)
		return gcs_set_nc_register(name, (FrogRegData) m_value) ;
	else
		return gcs_set_tc_register(name, (FrogRegData) m_value, m_tcid) ;
}

/**
 * @brief ＴＬＢ更新の取消し
 *
 */
SI32 CTLBProfile::WriteBack( void ){
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	printf("TLB[0x%08x]= { L0=0x%08x , L1=0x%08x , H0=0x%08x , H1=0x%08x }\n" ,m_idx ,m_l0 , m_l1 , m_h0 , m_h1 );
#endif
	return gcs_write_simulator_tlb( m_idx ,m_l0 , m_l1 , m_h0 , m_h1 );
}

/**
 * @brief ＬＬｂｉｔ更新の取消し
 *
 */
SI32 CLLbitProfile::WriteBack( void ){
	UI32 ret ;
	if (m_status == FROG_LLBIT_DELETE) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	    printf("Cleate LLbit[ADR:0x%08x, size:%d isNC:%d HTID:%d]\n" ,(UI32)m_address, m_size, m_isNt, m_tcid );
#endif
		ret= gcs_create_memory_link( m_address, m_isNt, m_tcid, m_size);
	} else {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	    printf("Delete LLbit[ADR:0x%08x]\n" ,(UI32)m_address );
#endif
		ret= gcs_remove_memory_link_addr( m_address );
	}
	return (ret) ;
}

/**
 * @brief ＰＣ更新の取消し
 *
 */
SI32 CPcRegProfile::WriteBack( void ){
	SI32 success= GCSIF_SUCCESS ;

	if (m_pc_pending == false) {
		m_pc_tcid = m_tcid ;
		m_pc_value= m_value ;
		m_pc_pending= true ;
	} else {
		if (m_pc_tcid == m_tcid) {
			m_pc_value= m_value ;
		} else {
			success= IUndoProfile::Flash();
			m_pc_tcid = m_tcid ;
			m_pc_value= m_value ;
		}
	}
	return (success) ;
}
bool IUndoProfile::m_pc_pending ;
UI32 IUndoProfile::m_pc_tcid ;
UI32 IUndoProfile::m_pc_value ;


/**
 * @brief メモリ書き込みの取消し
 *
 */
SI32 CWrMemProfile::WriteBack( void ){
	//!<BR>[処理細目]<BR>

	if (m_access_bus == SIM_UNDO_ENABLE) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		std::cout	<< "Mem(EXC): address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << m_address 
					<< " size=0x"        << m_size
					<< " data=0x"        << std::setw(16) << std::right << std::setfill('0') << std::hex << m_value 
					<< std::endl;
#endif
	}
	else {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		std::cout	<< "Mem(API): address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << m_address 
					<< " size=0x"        << m_size
					<< " data=0x"        << std::setw(16) << std::right << std::setfill('0') << std::hex << m_value 
					<< std::endl;
#endif
	}

	//!・m_valueの値（保持していた書き戻し値）を文字列 "0x??,0x??,0x??,0x??" 形式に変換し buf[] に格納
	char	buf[42];
	UI8		code ;
	SI32	i= 0;
	for (UI32 offset= 0 ;offset < m_size ;offset++ ) {
		code= ((UI8 *)&m_value)[offset] ;
		buf[i] = '0' ; i++ ;
		buf[i] = 'x' ; i++ ;
		if ((code >> 4) < 10) {
			buf[i] = '0' +  (code >> 4) ;
		} else {
			buf[i] = (code >> 4) - 10 + 'a' ;
		} 
		i++ ;
		if ((code & 15) < 10) {
			buf[i] = '0' +  (code & 15) ;
		} else {
			buf[i] = (code & 15) - 10 + 'a' ;
		} 
		i++ ;
		if (offset < (m_size-1)) {
			buf[i] = ',' ;
		} else {
			buf[i] =0 ;
		} 
		i++ ;
	}

	//!・保持していた書き戻しアドレスと buf[] で、シミュレータにメモリ書き込みを要求
	return gcs_write_simulator_memory( m_address, m_size, std::string(buf) ) ;
}



/**
 * @brief メモリ初期値書き込みの取消し
 *
 */
SI32 CPresetMemProfile::WriteBack( void ){
	//!<BR>[処理細目]<BR>
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout	<< "Mem(Preset): address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << m_address 
				<< " size=0x"        << m_size
				<< " data=0x"        << std::setw(16) << std::right << std::setfill('0') << std::hex << m_value 
				<< std::endl;
#endif

	//!・m_valueの値（保持していた書き戻し値）を文字列 "0x??,0x??,0x??,0x??" 形式に変換し buf[] に格納
	char	buf[42];
	UI8		code ;
	SI32	i= 0;
	for (UI32 offset= 0 ;offset < m_size ;offset++ ) {
		code= ((UI8 *)&m_value)[offset] ;
		buf[i] = '0' ; i++ ;
		buf[i] = 'x' ; i++ ;
		if ((code >> 4) < 10) {
			buf[i] = '0' +  (code >> 4) ;
		} else {
			buf[i] = (code >> 4) - 10 + 'a' ;
		} 
		i++ ;
		if ((code & 15) < 10) {
			buf[i] = '0' +  (code & 15) ;
		} else {
			buf[i] = (code & 15) - 10 + 'a' ;
		} 
		i++ ;
		if (offset < (m_size-1)) {
			buf[i] = ',' ;
		} else {
			buf[i] =0 ;
		} 
		i++ ;
	}

	//!・保持していた書き戻しアドレスと buf[] で、シミュレータにメモリ書き込みを要求
	return gcs_write_simulator_memory( m_address, m_size, std::string(buf) ) ;
}



/****************************************************************/
/*                     MMU/MPU関連メソッド群                     */
/****************************************************************/

#define M_TLB_PERMISSION (telo0 & 0x0000003f)
#define M_TLB_S			 ((telo0 >>   6) & 0x000f)
#define M_TLB_PFN		 (((telo0 & 0xfffffc00) >> 10) | ((telo1 & 0x00ff) << 22))
#define M_TLB_PCC		 ((telo1 >>  28) & 0x000f)
#define M_TLB_PGSIZE	 (tehi0 & 0x001f)
#define M_TLB_VPN		 ((tehi0 >>  10) & 0x003fffff)
#define M_TLB_ASID		 (tehi1 & 0x03ff)
#define M_TLB_HVC		 ((tehi1 >> 14) & 1)
#define M_TLB_VM		 ((tehi1 >> 15) & 1)
#define M_TLB_VCID		 ((tehi1 >> 16) & 7)
#define M_TLB_G			 ((tehi1 >> 20) & 1)
#define M_TLB_L			 ((tehi1 >> 30) & 1)
#define M_TLB_V			 ((tehi1 >> 31) & 1)

UI32 CSimulator::V850_MMU_SearchTLB( bool isNC ,UI32 htid , UI64 addr ,UI32 AccessFlg ,UI32 *pIndex= NULL )
{
	//!<BR>[処理細目]<BR>

	//!・引数で指定されたスレッド／マシンのレジスタ値（PSW,ASID）を取得。
	UI32	psw  ;
	UI32	hvc  ;
	UI32	vm   ;
	UI32	vcid ;
	UI32	asid ;

	if (isNC) {
		vm= 0 ;
		psw= m_psw[64] ;
		vcid= 0 ;
		asid= m_asid[64] ;
		hvc = ((psw >> 19)&1) ;
	} else {
		vm= 1 ;
		asid= m_asid[htid] ;
		vcid= m_vcid_table[htid] ;
		psw= m_psw[htid] ;
		hvc = ((psw >> 19)&1) ;
	}

	//!・引数で指定されたアドレス ,ASID ,PSW.VM(とvcid) ,PSW.HVC に合致するTLBエントリーを検索。
	UI32	vpn= ((addr >> 10) & 0x003fffff) ;
	UI32	ret= 0 ;
	UI32	match ;
	UI32	index ;
	UI32	pgsize ;
	bool	permition_err = false ;
	match = 0 ;
	for (index= 0 ;index <= m_tlbnum ;index++ ) {
		UI32 tehi0= m_tehi0[index] ;
		UI32 tehi1= m_tehi1[index] ;
		pgsize= M_TLB_PGSIZE ;
		if ((m_smallpage == false) && (pgsize < 2)) {
			pgsize= 2 ;
		}

		if (M_TLB_V == 0) { continue ; }		//エントリー無効？
		if ((M_TLB_VPN >> pgsize) != (vpn >> pgsize)) {
			continue ;							//VPNが一致しない。
		}
		if (M_TLB_G == 0) {						//グローバルページでは無い？
			if (asid != M_TLB_ASID) {			//アドレス空間が異なる？
 				continue ;
			}
		}
		if (M_TLB_HVC != 0) {					//HVCALL用メモリ空間？
			if (hvc == 0) {						//HVCALL期間中では無い？
				continue ;
			}
		}
		if (M_TLB_VM == 0) {					//ネイティブマシン用ページ？
			if (vm != 0) {						//ネイティブモードではない？
				continue ;
			}
		} else {								//仮想CPU用ページ？
			if (vm == 0) {						//仮想CPUモードでは無い。
				continue ;
			}
			if (M_TLB_VCID != vcid) {			//仮想CPU番号が一致しない。
				continue ;
			}
		}
		
		if (pIndex != NULL) { *pIndex= index ; }
		match++ ;

		//・・この間、合致したTLBエントリーの中に引数で要求されているアクセスを満たさないものがあった場合は特権違反として記録しておく。
		UI32 telo0= m_telo0[index] ;
		if ((AccessFlg & ((M_TLB_PERMISSION) << 16)) != AccessFlg) {
			permition_err= true ;
		} else {
		}
	}
	//!・合致したエントリーが複数ある場合は戻り値のTLB多重一致ビットをセット。
	if (match >  1) {
		ret |= MMU_BIT_ME ;
	}
	//!・合致したエントリーがある場合は戻り値のTLB一致ビット（Vビット）をセット。
	if (match != 0) {
		ret |= MMU_BIT_V ;
	}
	if((permition_err == true)||(match == 0)||((ret & MMU_BIT_ME) != 0)) {
		//!・特権違反 または TLB不一致違反 または TLBページ境界違反 または TLB多重一致違反であれば、要求されたアクセス情報を戻り値に反映する。
		ret |= AccessFlg ;
	}
	//!▽リターン。<BR><BR>
	return ( ret ) ;
}


UI32 CSimulator::V850_MMU_TransferAddr( bool isNC ,UI32 htid , UI32 vaddr ,UI64 length ,UI32 AccessFlg ,UI64 *paddr1 ,UI64 *length1 ,UI32 *option1 ,UI64 *paddr2 ,UI64 *length2 ,UI32 *option2 )
{
	//!<BR>[処理細目]<BR>

	UI32	index1 = 0 ;
	UI32	index2 = 0 ;
	UI32	ret ;
	UI32	pgsize ;
	UI32	telo0 ;
	UI32	telo1 ;
	UI32	tehi0 ;

	if (length1 != NULL) { *length1= 0 ; }
	if (length2 != NULL) { *length2= 0 ; }

	AccessFlg &= MMU_BIT_PERMIT ;

	//!・最小ページサイズ設定。
	//!　m_bMMUSmallPage == true -> 1kB、　m_bMMUSmallPage == false -> 4kB
	UI32	min_pgsize= (m_smallpage == true)? 1024 : 4096 ;
	
	//!◎ページの検索処理を呼ぶ。
	ret= V850_MMU_SearchTLB( isNC , htid , vaddr , AccessFlg ,&index1 ) ;

	if (AccessFlg & (MMU_BIT_UR | MMU_BIT_UW | MMU_BIT_SR | MMU_BIT_SW)) {
		//!・<<< データーアクセス処理 >>>

		//!・・最小ページ境界チェック
		if ((vaddr & ~(min_pgsize-1)) != ((vaddr + length - 1) & ~(min_pgsize-1))) {
			ret |= (MMU_BIT_PB | AccessFlg ) ;
		}
		//!・▽TLB多重違反またはTLB不一致違反またはページ境界違反エラーならばリターン。
		if (((ret & (MMU_BIT_ME | MMU_BIT_PB)) != 0)||((ret & MMU_BIT_V) == 0)) {
			return (ret) ;
		}
		
		telo0= m_telo0[index1] ;
		telo1= m_telo1[index1] ;
		tehi0= m_tehi0[index1] ;
		//!・・ページサイズを求める。このとき最小ページサイズ未満は、最小ページサイズと読みかえる
		pgsize= M_TLB_PGSIZE ;
		if ((m_smallpage == false) && (pgsize < 2)) {
			pgsize= 2 ;
		}
		//!・・物理アドレスを計算
		if (paddr1 != NULL) { 
			*paddr1= ((UI64)(M_TLB_PFN >> pgsize) << (10 + pgsize)) + (UI64)(vaddr & ((1ull << (10 + pgsize)) - 1)) ;
		}
		//!・・アクセスサイズを計算
		if (length1 != NULL) { 
			*length1= length ;
		}
		//!・・その他の情報を取り出す
		if (option1 != NULL) { 
			*option1= ((M_TLB_S << 16) | M_TLB_PCC) ;
		}
	}
	else
	if (AccessFlg & (MMU_BIT_UX | MMU_BIT_SX)) {
		//!・<<< 命令フェッチ処理 >>>
		
		if (((ret & MMU_BIT_ME) != 0)||((ret & MMU_BIT_V) == 0))  {			//多重例外または不一致例外を検出した。
			return (ret) ;
		}
		telo0= m_telo0[index1] ;
		telo1= m_telo1[index1] ;
		tehi0= m_tehi0[index1] ;
		//!・・ページサイズを求める。このとき最小ページサイズ未満は、最小ページサイズと読みかえる
		pgsize= M_TLB_PGSIZE ;
		if ((m_smallpage == false) && (pgsize < 2)) {
			pgsize= 2 ;
		}
		if (((M_TLB_VPN >> pgsize) + 1) != ((vaddr + length - 1) >> (10 + pgsize))) {
			//!・・<<< この命令フェッチがTLBエントリが管理しているページサイズ内に収まっている場合の処理 >>>
			
			//!・・・物理アドレスを計算
			if (paddr1  != NULL) { 
				*paddr1= ((UI64)(M_TLB_PFN >> pgsize) << (10 + pgsize)) + (UI64)(vaddr & ((1ull << (10 + pgsize)) - 1)) ;
			}
			//!・・・アクセスサイズを計算
			if (length1 != NULL) { 
				*length1= length ;
			}
			//!・・・その他の情報を取り出す
			if (option1 != NULL) { 
				*option1= ((M_TLB_S << 16) | M_TLB_PCC) ;
			}
		} else {
			//!・・<<< この命令フェッチがTLBエントリが管理しているページサイズをはみ出している場合の処理 >>>
			
			//!・・◎次ページの検索処理を呼ぶ。以降、戻り値は次ページの情報となる
			ret= V850_MMU_SearchTLB( isNC , htid ,(vaddr + length) , AccessFlg ,&index2 ) ;
			ret |= MMU_BIT_NP ;

			
			//!・・・前方の物理アドレスを計算
			if (paddr1  != NULL) { 
				*paddr1= ((UI64)(M_TLB_PFN >> pgsize) << (10 + pgsize)) + (UI64)(vaddr & ((1ull << (10 + pgsize)) - 1)) ;
			}
			//!・・・前方のアクセスサイズを計算
			if (length1 != NULL) { 
				*length1= min_pgsize - ((min_pgsize -1) & vaddr)  ;
			}
			//!・・・前方のその他の情報を取り出す
			if (option1 != NULL) { 
				*option1= ((M_TLB_S << 16) | M_TLB_PCC) ;
			}
			//!・・▽多重例外または不一致例外を検出していた場合はここでリターン。
			if (((ret & MMU_BIT_ME) != 0)||((ret & MMU_BIT_V) == 0))  {	
				return (ret) ;
			}
			
			telo0= m_telo0[index2] ;
			telo1= m_telo1[index2] ;
			tehi0= m_tehi0[index2] ;
			//!・・・次ページサイズを求める。このとき最小ページサイズ未満は、最小ページサイズと読みかえる
			pgsize= M_TLB_PGSIZE ;
			if ((m_smallpage == false) && (pgsize < 2)) {
				pgsize= 2 ;
			}
			//!・・・後方の物理アドレスを計算
			if (paddr2  != NULL) { 
				*paddr2= ((UI64)(M_TLB_PFN >> pgsize) << (10 +pgsize)) ;
			}
			//!・・・後方のアクセスサイズを計算
			if (length2 != NULL) { 
				*length2= length - *length1 ;
			}
			//!・・・後方のその他の情報を取り出す
			if (option2 != NULL) { 
				*option2= ((M_TLB_S << 16) | M_TLB_PCC) ;
			}
		}
	}
	else
	if (AccessFlg == 0) {
		//!・<<< アドレス変換のみを行なう場合の処理 >>>

		if (((ret & MMU_BIT_ME) != 0)||((ret & MMU_BIT_V) == 0)) {
			//　▽TLB多重エラーまたはTLB不一致エラーまたはページ境界エラーを検出した場合はリターン。
			return (ret) ;
		}
		
		telo0= m_telo0[index1] ;
		telo1= m_telo1[index1] ;
		tehi0= m_tehi0[index1] ;
		//!・・ページサイズを求める。このとき最小ページサイズ未満は、最小ページサイズと読みかえる
		pgsize= M_TLB_PGSIZE ;
		if ((m_smallpage == false) && (pgsize < 2)) {
			pgsize= 2 ;
		}
		//!・・物理アドレスを計算
		if (paddr1 != NULL) { 
			*paddr1= ((UI64)(M_TLB_PFN >> pgsize) << (10 + pgsize)) + (UI64)(vaddr & ((1ull << (10 + pgsize)) - 1)) ;
		}
		//!・・アクセスサイズを設定
		if (length1 != NULL) { 
			*length1= length ;
		}
		//!・・その他の情報を設定
		if (option1 != NULL) { 
			*option1= ((M_TLB_S << 16) | M_TLB_PCC) ;
		}
	}
	else ;

	//!▽リターン。<BR><BR>
	return (ret) ;
}

bool CSimulator::MmuTransferAddr( bool isNC , UI32 htid , UI32 vaddr , UI64 length , eMXU_ACCESS_TYPE ac , UI64  *paddr1 , UI64 *length1 , UI64 *paddr2 , UI64 *length2) {
	//!<BR>[処理細目]<BR>

	//!▽指定された htid が搭載数を越えている場合は異常リターン。
	if (htid >= m_htnum) {
		m_nErrorInfo= ERR_INVALID_OTHER_PARAM	;
		return (false) ;
	}

	//!▽MMUを搭載していないのに呼ばれた場合は論理アドレス＝物理アドレス、アクセス可能として正常リターン。
	if (m_tlbnum == 0) {
		if(paddr1  != NULL) { *paddr1 = (UI64)vaddr ; }
		if(length1 != NULL) { *length1= length ; }
		if(paddr2  != NULL) { *paddr2 = 0 ; }
		if(length2 != NULL) { *length2= 0 ; }
		return (true) ;
	}

	//!・指定されたスレッド／マシンのレジスタ値（PSW,ASID,MCFG0）を取得。
	UI32 psw ;
//	UI32 asid ;
	UI32 vcid= 0 ;
	UI32 mcfg0 ;

	if (isNC) {
		psw   = m_psw[64] ;
//		asid  = m_asid[64] ;
		mcfg0 = m_mcfg0[8] ;
	} else {
		psw   = m_psw[htid] ;
//		asid  = m_asid[htid] ;
		vcid  = m_vcid_table[htid] ;
		mcfg0 = m_mcfg0[vcid] ;
	}
	//!▽MCFG0.MMでMMUがOFFされている場合は論理アドレス＝物理アドレス、アクセス可能として正常リターン。
	if ((mcfg0 & 8) == 0) {
		if(paddr1  != NULL) { *paddr1 = (UI64)vaddr ; }
		if(length1 != NULL) { *length1= length ; }
		if(paddr2  != NULL) { *paddr2 = 0 ; }
		if(length2 != NULL) { *length2= 0 ; }
		return (true) ;
	}
	UI32 AccessFlg= (ac == MXU_ACC_READ )    ? (0x09) :
					(ac == MXU_ACC_WRITE)    ? (0x12) :
					(ac == MXU_ACC_FETCH)    ? (0x24) :
					(ac == MXU_ACC_DONTCARE) ? (0x00) :
					(ac == MXU_ACC_RMW  )    ? (0x1b) : (0x3f) ;

	//!・SV/UMチェック。
	AccessFlg &= (psw & 0x40000000) ? 0x07 : 0x38 ; 

	//!◎仮想アドレス-物理アドレス 変換処理・サブ関数をコール。
	UI32 rslt= CSimulator::V850_MMU_TransferAddr( isNC ,htid , vaddr ,length ,AccessFlg ,paddr1 ,length1 ,NULL ,paddr2 ,length2 ,NULL ) ;

	//!▽エラーがなければ正常リターン、あれば詳細情報を設定して異常リターン。<BR><BR>
	if ((rslt & MMU_BIT_V) == 0) {
		m_nErrorInfo= ERR_MMU_VOID ;
		return (false) ;
	}
	else
	if (rslt & MMU_BIT_ME) {
		m_nErrorInfo= ERR_MMU_ME ;
		return (false) ;
	}
	else
	if (rslt & MMU_BIT_PB) {
		m_nErrorInfo= ERR_MMU_PB ;
		return (false) ;
	}
	else
	if (rslt & MMU_BIT_NP) {
		m_nErrorInfo= ERR_MMU_NP ;
		return (false) ;
	}
	else
	if (rslt & MMU_BIT_PERMIT) {
		m_nErrorInfo= ERR_MMU_PV ;
		return (false) ;
	}
	else {
		m_nErrorInfo= ERR_CLEAN ;
		return (true) ;
	}
}


bool CSimulator::GetSegmentList(CSegmentList* &result , UI32 begin_adr , UI32 end_adr , eMXU_ACCESS_TYPE ac , UI32 htid, UI32 ac_size) {
    return GetSegmentList(result , begin_adr , end_adr , ac , htid ,m_bNM, ac_size) ;
}


bool CSimulator::GetSegmentList(CSegmentList* &result , UI32 begin_adr , UI32 end_adr , eMXU_ACCESS_TYPE ac , UI32 htid , bool isNC, UI32 ac_size) {
	//!<BR>[処理細目]<BR>

	//!・引数をチェック（begin_adr ,end_adr ,htid）
	if ((begin_adr > end_adr)||(htid >= m_htnum)) { // <<================ 条件を暫定で変更しました！！ Original : begin_adr >= end_adr
		m_nErrorInfo= ERR_INVALID_OTHER_PARAM	;
		return (false) ;
	}

	//===========================================================
	//!・<<<<ＭＭＵが搭載されている場合の処理>>>>
	//===========================================================
	if (m_tlbnum != 0) {
		//!・・指定されたスレッド／マシンのレジスタ値（PSW,ASID,MCFG0）を取得。
		UI32 psw ;
		UI32 asid ;
		UI32 vcid= 0 ;
		UI32 mcfg0 ;

		if (isNC) {
			result= &(m_Seg[64]) ;
			psw   = m_psw[64] ;
			asid  = m_asid[64] ;
			mcfg0 = m_mcfg0[8] ;
		} else {
			result= &(m_Seg[htid]) ;
			psw   = m_psw[htid] ;
			asid  = m_asid[htid] ;
			vcid= m_vcid_table[htid] ;
			mcfg0 = m_mcfg0[vcid] ;
		}

		//===========================================================
		// 区間リストの更新の要否確認
		//===========================================================
		if (  (result->isDirty()   == false)
		   && (result->m_begin_adr == begin_adr)
		   && (result->m_end_adr   == end_adr)
		   && (result->m_psw       == psw)
		   && (result->m_asid      == asid)
		   )
		{
			if (result->m_ac == ac) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("!!segment list ReUse\n");
#endif
				//!・▽前回と条件が変わっていなければ、リストを再使用する。ここでリターン。
				return (true) ;
			}
			//!・▽アクセス種別のみが異なる場合は、保存してあるTLB情報からValid情報とStatus情報のみ更新する。ここでリターン。
			result->MakeStatus((((psw & 0x40000000) != 0) ? true: false) ,ac ) ;
			result->m_ac= ac ;
#if defined(_DBG_SIM01_)
 result->Dump();
#endif
			return (true) ;
		}
		if ((mcfg0 & 0x00000008) == 0) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("!!mmu off. full map!!\n");
#endif
			//!・▽MCFG0.MM がセットされていなければbegin_adr から end_adr までフルアクセス可能な１つの区間を設定。ここでリターン。
			result->Clear();
			result->Set( begin_adr , ((UI64)end_adr - (UI64)begin_adr + 1) ,/*status*/MXU_RES_V , /*priv*/0x3f ,/*asid*/0 , /*G*/true , /*HVC*/false , /*SmallPage*/1024 , /*paddr*/begin_adr) ;
			result->MakeStatus((((psw & 0x40000000) != 0) ? true: false) ,ac ) ;
			result->m_ac= ac ;
			result->m_begin_adr = begin_adr ;
			result->m_end_adr   = end_adr ;
			result->m_psw       = psw ;
			result->m_dirty     = false ;
			return (true) ;
		}
		
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("!!make segment list\n");
#endif
		//===========================================================
		// 区間リスト作成
		//===========================================================
		//!・・指定されたマシンに属する有効なエントリーのページアドレス＆サイズを基に区間アドレスをピックアップ
		std::set<UI32> segment ;
		std::set<UI32>::iterator itr;
		for (UI32 index = 0; index < m_tlbnum; index++ ){
			UI32 tehi0= m_tehi0[index] ;
			UI32 tehi1= m_tehi1[index] ;
			if (M_TLB_PGSIZE >= 0x14) {
				//ブロックサイズが過大
				MSG_ERROR(0, "TLB block size=%dMB is over\n", (1 << (M_TLB_PGSIZE-10)));
				_ASSERT(0);
			}
			if (M_TLB_V == 0) {						//エントリー無効？
				continue ;
			}
			if (M_TLB_VM == 0) {					//ネイティブマシン用ページ？
				if (!isNC) {						//現在ネイティブモードではない？
					continue ;
				}
			} else {								//仮想CPU用ページ？
				if (isNC) {							//現在仮想CPUモードでは無い。
					continue ;
				}
				if (M_TLB_VCID != vcid) {			//仮想CPU番号が一致しない。
					continue ;
				}
			}
			UI32 mmu_lower= ((M_TLB_VPN >>  M_TLB_PGSIZE) << (M_TLB_PGSIZE));
			UI32 mmu_upper= mmu_lower + (1 << M_TLB_PGSIZE) ;
			segment.insert( mmu_lower ) ;
			segment.insert( mmu_upper ) ;
		}
		//!・・区間アドレスから区間リスト作成
		result->Clear();
		result->m_begin_adr = begin_adr ;
		result->m_end_adr   = end_adr ;
		result->m_psw       = psw ;
		result->m_asid      = asid ;

		UI32 min_pgsize= (m_smallpage) ? 1024 : 4096 ;
		for (itr = segment.begin(); itr != segment.end(); itr++) {
			UI64 addr= (*itr) << 10 ;
			if ((addr <= (UI64)begin_adr)||(addr >= ((UI64)end_adr + 1))) {
				continue ;
			}
			UI64 size= addr - (UI64)begin_adr ;
			UI32 index = 0;
			UI32 rslt= V850_MMU_SearchTLB( isNC , htid , begin_adr , /*full access*/MMU_BIT_PERMIT ,&index ) ;
			if ((rslt & MMU_BIT_V ) == 0)  {			//不一致違反を検出した。
				result->Set( begin_adr , size ,MXU_RES_VOID , /*priv*/0 , /*asid*/0 , /*global*/false , /*hvc*/false , min_pgsize , /*paddr*/0ull ) ;
				begin_adr= addr ;
				continue ;
			}
			UI32 telo0= m_telo0[index] ;
			UI32 telo1= m_telo1[index] ;
			UI32 tehi0= m_tehi0[index] ;
			UI32 tehi1= m_tehi1[index] ;
			UI32 priv= M_TLB_PERMISSION ;
			UI32 asid= M_TLB_ASID ;
			bool global= (M_TLB_G == 1) ;
			bool hvc= (M_TLB_HVC == 1) ;
			UI64 paddr= ((UI64)(M_TLB_PFN >> M_TLB_PGSIZE) << (10 + M_TLB_PGSIZE)) + (UI64)(begin_adr - ((M_TLB_VPN >> M_TLB_PGSIZE) << (10 + M_TLB_PGSIZE))) ;
			if ((rslt & MMU_BIT_ME) != 0)  {
				result->Set( begin_adr , size ,MXU_RES_ME   , priv , asid , global , hvc , min_pgsize , paddr ) ;
			} else {
				result->Set( begin_adr , size ,MXU_RES_PRIV , priv , asid , global , hvc , min_pgsize , paddr ) ;
			}
			begin_adr= addr ;
		}
		if (begin_adr <= end_adr) {
			UI64 size= end_adr - begin_adr + 1 ;
			UI32 index= 0 ;
			//!　　◎区間アドレスにヒットするTLBエントリを検索する
			UI32 rslt= V850_MMU_SearchTLB( isNC , htid , begin_adr , /*full access*/MMU_BIT_PERMIT ,&index ) ;
			if ((rslt & MMU_BIT_V ) == 0)  {			//不一致違反を検出した。
				//!・・・一致し無かった場合はその情報と区間サイズを区間リストに詰める。
				result->Set( begin_adr , size ,MXU_RES_VOID , /*priv*/0 , /*asid*/0 , /*global*/false , /*hvc*/false , min_pgsize , /*paddr*/0ull ) ;
			} else {
				//!・・・一致した場合はエントリーの情報と区間サイズを区間リストに詰める。
				UI32 telo0= m_telo0[index] ;
				UI32 telo1= m_telo1[index] ;
				UI32 tehi0= m_tehi0[index] ;
				UI32 tehi1= m_tehi1[index] ;
				UI32 priv= M_TLB_PERMISSION ;
				UI32 asid= M_TLB_ASID ;
				bool global= (M_TLB_G == 1) ;
				bool hvc= (M_TLB_HVC == 1) ;
				UI64 paddr= ((UI64)(M_TLB_PFN >> M_TLB_PGSIZE) << (10 + M_TLB_PGSIZE)) + (UI64)(begin_adr - ((M_TLB_VPN >> M_TLB_PGSIZE) << (10 + M_TLB_PGSIZE))) ;
				if ((rslt & MMU_BIT_ME) != 0)  {
					//!・・・多重違反区間はその情報と最後に合致したエントリーの情報をセットする
					result->Set( begin_adr , size ,MXU_RES_ME   , priv , asid , global , hvc , min_pgsize , paddr ) ;
				} else {
					result->Set( begin_adr , size ,MXU_RES_PRIV , priv , asid , global , hvc , min_pgsize , paddr ) ;
				}
			}
		}
		result->MakeStatus((((psw & 0x40000000) != 0) ? true: false) ,ac ) ;
		result->m_ac= ac ;
		result->m_dirty= false ;
	}


	//===========================================================
	//!・<<<<ＭＰＵが搭載されている場合の処理>>>>
	//===========================================================
	if (m_mpnum != 0) {
		//!・・指定されたスレッド／マシンのレジスタ値（PSW,ASID,MPM,DIR0）を取得。
		UI32 psw    = 0;
		UI32 mpm    = 0;
        UI32 spid_mpidn = 0;
        UI32 dir0 = m_dir0[8];
        result = &(m_Seg[64]);

		if ((m_pswh >> 31) != 0) {
            // Guest Mode
            psw = m_gmpsw;
            mpm = m_gmmpm;
            spid_mpidn = m_gmspid_mpidn;
		} else {
            // Host Mode and Convention Mode have same register
			psw   = m_psw[64] ;
			mpm   = m_mpm ;
            spid_mpidn = m_spid_mpidn;
		}

		//===========================================================
		// 区間リストの更新の要否確認
		//===========================================================
		if (  (result->isDirty()   == false)
		   && (result->m_begin_adr == begin_adr)
		   && (result->m_end_adr   == end_adr)
		   && (result->m_psw       == psw)
		   && (result->m_dir0      == dir0)
		   )
		{
			if (result->m_ac == ac) {
			
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("!!segment list ReUse\n");
#endif
				//!・▽前回と条件が変わっていなければ、リストを再使用する。ここでリターン。
				return (true) ;
			}
			//!・▽アクセス種別のみが異なる場合は、保存してあるTLB情報からValid情報とStatus情報のみ更新する。ここでリターン。
			result->MakeStatus((((psw & 0x40000000) != 0) ? true: false) ,ac ) ;
			result->m_ac= ac ;
#if defined(_DBG_SIM01_)
 printf("!!modify Valid and Status part.\n");
 result->Dump();
#endif
			return (true) ;
		}

        // G4MH don't care DIR0.DN bit, only Debug mode (DIR0.DM) was checked
        if (((dir0 & 0x00000001) != 0) || ((mpm & 0x00000005) == 0)) {

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("!!mpu off. then full map!!\n");
#endif
			//!・PSW.HVC か DIR0.DN がセットされているあいだは全域フルアクセスとなる。
			result->Clear();
			result->Set( begin_adr , (end_adr - begin_adr + 1) , MXU_RES_V, 0x7f ) ;
			result->MakeStatus((((psw & 0x40000000) != 0) ? true: false) ,ac ) ;
			result->m_ac= ac ;
			result->m_begin_adr = begin_adr ;
			result->m_end_adr   = end_adr ;
			result->m_psw       = psw ;
			result->m_dir0      = dir0 ;
			result->m_dirty     = false ;
			return (true) ;
		}
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("!!make segment list\n");
#endif
		//===========================================================
		// 区間リスト作成
		//===========================================================
		//!・・全保護領域の開始アドレスと終了アドレスを基に区間アドレスをピックアップ
		std::set<UI32> segment ;
		std::set<UI32>::iterator itr;
		for (UI32 mp_idx = 0; mp_idx < m_mpnum; mp_idx++ ){
			UI32 mpu_lower= (m_mpla[m_mpbk][mp_idx] >> 2);
			UI32 mpu_upper= (m_mpua[m_mpbk][mp_idx] >> 2) + 1;
			if (mpu_lower >= mpu_upper) {
				//!・・・開始アドレスと終了アドレスの大小関係が不正な保護領域は区間に関係させない。
				continue ;
			}
			segment.insert( mpu_lower ) ;
			segment.insert( mpu_upper ) ;
		}
		//!・・区間リストを一旦クリアする。
		result->Clear();
		//!・・区間アドレスから区間リスト作成する。
		result->m_begin_adr = begin_adr ;
		result->m_end_adr   = end_adr ;
		result->m_psw       = psw ;
		result->m_dir0      = dir0 ;

		for (itr = segment.begin(); itr != segment.end(); itr++) {
			UI64 addr= *itr * 4 ;
			if (addr <= (UI64)begin_adr) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("addr=0x%08llx -> under of range (0x%08x - 0x%08x)\n" , addr , begin_adr ,end_adr);
#endif
				continue ;
			}
			if (addr > (UI64)end_adr) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("addr=0x%08llx -> over  of range (0x%08x - 0x%08x)\n" , addr , begin_adr ,end_adr);
#endif

				break ;
			}

			UI64 size= addr - (UI64)begin_adr ;
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("begin_adr=0x%08x size=0x%08llx -> [" , begin_adr , size);
#endif
			UI32 rslt= GetAccessPermission(begin_adr, mpm, spid_mpidn) ;
			UI32 priv= (rslt & 0x3f) ;
			UI32 status= (rslt & 0x00000040) ? MXU_RES_PRIV : MXU_RES_VOID ;
			result->Set( begin_adr , size ,status , priv) ;
			begin_adr= addr ;
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("] status=%d priv=0x%02x  -> Set!\n" , status , priv);
#endif
		}
		if (begin_adr <= end_adr) {
			UI64 size= end_adr - begin_adr + 1 ;
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("begin_adr=0x%08x size=0x%08llx -> [" , begin_adr , size);
#endif
			//!・・◎区間アドレスのアクセス権限を検索する。
			UI32 rslt= GetAccessPermission(begin_adr, mpm, spid_mpidn) ;
			UI32 priv= (rslt & 0x3f) ;
			UI32 status= (rslt & 0x00000040) ? MXU_RES_PRIV : MXU_RES_VOID ;
			//!・・・区間のアクセス情報と区間サイズを区間リストに詰める。
			result->Set( begin_adr , size ,status , priv) ;
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
 printf("] status=%d priv=0x%02x \n" , status , priv);
#endif
		}
		result->MakeStatus((((psw & 0x40000000) != 0) ? true: false) ,ac ) ;
        if (ac_size >= 8)
            result->UpdateSegCrossSetting(ac_size);
		result->m_ac= ac ;
		result->m_dirty= false ;
	}
#if defined(_DBG_SIM01_)
 result->Dump();
#endif
	return (true) ;
}

UI32 CSimulator::GetAccessPermission(UI32 addr, UI32 mpm, UI32 spid_mpidn) {

	bool match = false;
	UI32 permission_hm = 0, permission = 0;
    UI32 hbe = (m_mpcfg >> 8) & 0x3f;

    // match: checking whether addr has belong to any MPU channel or not.
    // start, end is start channel and end channel. 
    // svp_mask: variable to check permission depend on GMMPM.SVP

    auto GetPermission = [=](bool* match, UI32 start, UI32 end) -> UI32 {
        UI32 permission = 0;

        for (UI32 mp_idx = start; mp_idx < end; mp_idx++) {
            UI32 mpu_lower = m_mpla[m_mpbk][mp_idx];
            UI32 mpu_upper = m_mpua[m_mpbk][mp_idx] | 0x3;
            if (mpu_lower >= mpu_upper) {
                continue;
            }
            if ((mpu_lower > addr) || (addr > mpu_upper)) {
                //!・・OutOfRange
                continue;
            }

            UI32 mpat = m_mpat[m_mpbk][mp_idx];
            if ((mpat & 0x80) == 0) {
                // channel is disable
                continue;
            }
            *match = true;
               
            if ((mpat & 0x4000) != 0 || ((mpat >> 16) & spid_mpidn) != 0) {	// Check XR permission
                permission |= (mpat & 0x2d);
            }

            if ((mpat & 0x8000) != 0 || ((mpat >> 24) & spid_mpidn) != 0) { // Check W permission
                permission |= (mpat & 0x12);
            }
        }
        return permission;
    };

    if ((m_hvcfg & 0x1) != 0) {
        // Check Guest management in Guest Mode or Host management in Host Mode
        if ((mpm & 0x1) != 0) {
            permission = (m_pswh >> 31) ? GetPermission(&match, 0, hbe) : GetPermission(&match, hbe, m_mpnum);
            if ((mpm & 0x2) == 0) {
                permission |= 0x38;   // MPM.SVP
                match = true;
            }
        } else {
            permission = 0x3f;
            match = true;
        }
        // Check Host management in Guest Mode
        if ((mpm & 0x4) != 0) {
            match = false;
            permission_hm = GetPermission(&match, hbe, m_mpnum);

        } else {
            permission_hm = 0x3f;
        }

        permission &= permission_hm;

    } else {
        // Convention mode
        permission = GetPermission(&match, 0, m_mpnum);
        if ((mpm & 0x2) == 0) {
            permission |= 0x38;   // MPM.SVP
            match = true;
        }
    }

	if (match) {
		permission |= 0x40 ;
	}

	return (permission) ;
}

void CSimulator::InitMxuData( void ) {
	//!<BR>[処理細目]<BR>

	FrogRegData val ;
	std::string name;
    const UI32 MaxMPUbank = 2;

	if (m_mpnum != 0) {
        gcs_get_nc_register("MPBK", &val);
        m_mpbk = (UI32)val;

		for (UI32 mp_index= 0; mp_index < m_mpnum; mp_index++ ){
            for (UI32 bank_index = 0; bank_index < MaxMPUbank; bank_index++) {
                m_mpla[bank_index][mp_index] = 0;
                m_mpua[bank_index][mp_index] = 0;
                m_mpat[bank_index][mp_index] = 0;
            }
		}
		gcs_get_nc_register( "MPM" , &val ) ;
		m_mpm= (UI32)val ;
        gcs_get_nc_register("GMMPM", &val);
        m_gmmpm = (UI32)val;
		//!・・メモリ保護領域ごとの、所属ＶＭ情報を作成する。
		// UpdateMpuRgnData();
	}
	if (m_tlbnum != 0) {
		//===========================================================
		//!・<<<<ＭＭＵが搭載されている場合の処理>>>>
		//===========================================================
		UI32 telo0 ;
		UI32 telo1 ;
		UI32 tehi0 ;
		UI32 tehi1 ;
		// 搭載TLBエントリー数に応じたTLBエントリー設定の読み出し。
		for (UI32 index= 0; index < m_tlbnum; index++ ){
			gcs_read_simulator_tlb (index, &telo0, &telo1, &tehi0, &tehi1);
			m_telo0[index]= telo0 ;	
			m_telo1[index]= telo1 ;	
			m_tehi0[index]= tehi0 ;	
			m_tehi1[index]= tehi1 ;	
		}
	}
	//!・搭載ＶＭ数に応じたVMPRTnレジスタ値の読み出し
	m_vmprt[0] = 0 ;
	m_vmprt[1] = 0 ;
	m_vmprt[2] = 0 ;
	const UI32 MPID_NUM = 8;	//[FROG]TODO: Number of MPID

    m_pswh = 0;
    m_hvcfg = 0;
    m_spid = 0;
    m_gmspid = 0;
    m_gmspid_mpidn = 0;
    m_spid_mpidn = 0;

    for (UI32 i = 0; i < MPID_NUM; i++) {
        m_mpid[i] = 0;
    }

    gcs_get_nc_register("GMPSW", &val);
    m_gmpsw = (UI32)val;
	gcs_get_nc_register( "PSW"  , &val ) ;
	m_psw[64]= (UI32)val ;
	m_mcfg0[8] = 0;

	gcs_get_nc_register( "DIR0" , &val ) ;
	m_dir0[8]= (UI32)val ;
	//!▽リターン<BR><BR>
}

void CSimulator::UpdateMpuRgnData( void ) {
	//!<BR>[処理細目]<BR>

	if (m_mpnum == 0) {
		return ;
	}
	//!・メモリ保護領域ごとにある所属ＶＭ情報のクリア
	for (UI32 mp_idx= 0 ; mp_idx < m_mpnum ;mp_idx++) { m_mpvm[mp_idx]= 0 ; }
	return;


	//!・MPPRTn値からメモリ保護領域のリージョン割り当てを取り出す
	UI8  rgn[9];
	UI32 val ;
	val= m_mpprt[0] ;
	rgn[0] = (uint8_t)(val & 0xff) ;val= val >> 8;
	rgn[1] = (uint8_t)(val & 0xff) ;val= val >> 8;
	rgn[2] = (uint8_t)(val & 0xff) ;val= val >> 8;
	rgn[3] = (uint8_t)(val & 0xff) ;
	val= m_mpprt[1] ;
	rgn[4] = (uint8_t)(val & 0xff) ;val= val >> 8;
	rgn[5] = (uint8_t)(val & 0xff) ;val= val >> 8;
	rgn[6] = (uint8_t)(val & 0xff) ;val= val >> 8;
	rgn[7] = (uint8_t)(val & 0xff) ;
	val= m_mpprt[2] ;
	rgn[8] = (uint8_t)(val & 0xff);

	//!・メモリ保護領域ごとにある所属ＶＭ情報のクリア
	for (UI32 mp_idx= 0 ; mp_idx < m_mpnum ;mp_idx++) { m_mpvm[mp_idx]= 0 ; }
	//!・ＶＭ毎の処理
	for (UI32 vc_idx= 0 ; vc_idx < m_vmnum ;vc_idx++){
		//!・・ＶＭのボトムリージョンとトップリージョンの割り出し（VM数を上限とする）
		UI32 brgn= rgn[vc_idx] ;
		UI32 trgn= rgn[vc_idx+1] ;
		if (brgn > m_mpnum) { brgn= m_mpnum ; }
		if (trgn > m_mpnum) { trgn= m_mpnum ; }
		UI32 flag= (1 << vc_idx) ;
		//!・・ボトムリージョンからトップリージョンまでの所属ＶＭ情報の、ＶＭに対応するビットをセット。
		for (UI32 mp_idx= brgn ; mp_idx < trgn ;mp_idx++) {
			m_mpvm[mp_idx] |= flag ;
		}
	}
	//!▽リターン<BR><BR>
}

void CSimulator::UpdateThreadMapping()
{
	//!<BR>[処理細目]<BR>

	//!・VMPRTn値からベーススレッドＩＤ情報の取り出し
	uint8_t btid[9];
	UI32 val ;
	val= m_vmprt[0] ;
	btid[0] = (uint8_t)(val & 0x7f) ;val= val >> 8;
	btid[1] = (uint8_t)(val & 0x7f) ;val= val >> 8;
	btid[2] = (uint8_t)(val & 0x7f) ;val= val >> 8;
	btid[3] = (uint8_t)(val & 0x7f) ;
	val= m_vmprt[1] ;
	btid[4] = (uint8_t)(val & 0x7f) ;val= val >> 8;
	btid[5] = (uint8_t)(val & 0x7f) ;val= val >> 8;
	btid[6] = (uint8_t)(val & 0x7f) ;val= val >> 8;
	btid[7] = (uint8_t)(val & 0x7f) ;
	val= m_vmprt[2] ;
	btid[8] = (uint8_t)(val & 0x7f);

	//!・スレッドに対応するVM番号の表をクリア
	memset (m_vcid_table, 0xFF, sizeof(m_vcid_table));

	std::bitset<64>	htbs;
	if (btid[0] > m_htnum) {
		btid[0] = m_htnum;
	}

	//!・ＶＭ毎の処理
	for (uint32_t x = 0; x < m_vmnum; x++) {
		if (btid[x+1] > m_htnum) {
			btid[x+1] = m_htnum;
		}
		//!・・スレッドに対応するVM番号の表の中の、対象VMのベーススレッドから次VMのベーススレッドー１までに対象ＶＭ番号をセット。（重複する場合ＶＭ番号が小さいセット方が優先）
		for (uint32_t y = btid[x]; y < btid[x+1]; y++) {
			if (htbs[y]) {
				; // invalid
			} else {
				htbs.set(y);	
				m_vcid_table[y] = x;
			}
		}
	}
	//!▽リターン<BR><BR>
}


/**
 * 直近に実行した命令で行なったメモリデータアクセスの記録を取得する
 *
 * @param  type   [out]  True:リードアクセス  false:ライトアクセス 
 * @param  addr   [out]  アクセスアドレス
 * @param  byte   [out]  データバイト数
 * @return isValid
 */
bool CSimulator::PopMemAccessLog(UI32 &read1_write0 , UI64 &addr , UI32 &byte ) {
    if (m_DataAccessInStep.size() == 0) {
        return false ;
    }

    std::vector<DataAccessItem>::iterator itr = m_DataAccessInStep.begin() ;
    read1_write0 = (*itr).m_Read1_Write0 ;
    addr = (*itr).m_nMemAddress ;
    byte = (*itr).m_nMemByte ;
    m_DataAccessInStep.erase( itr );
    return true ;
}

/**
 * @brief set m_itrDataAccessInStep equal firt element of m_DataAccessInStep
 *	Assign value for m_itrDataAccessInStep before get m_DataAccessInStep element.
 * @param	index of memory in memory log
 * @return	True: if index is valid, otherwise, false
 */
bool CSimulator::SetMemVariable(UI32 idx){
	if(idx >= m_DataAccessInStep.size())
		return false;
	m_itrDataAccessInStep = m_DataAccessInStep.begin();
	std::advance(m_itrDataAccessInStep, idx);
	return true;
}
/**
 * 直近に実行した命令で行なったメモリデータアクセスの記録を取得する
 *
 * @param  type   [out]  True:リードアクセス  false:ライトアクセス 
 * @param  addr   [out]  アクセスアドレス
 * @param  byte   [out]  データバイト数
 * @param  value  [out]  アクセスデータ
 * @return isValid
 */
bool CSimulator::EachMemAccessLog(UI32 &read1_write0 , UI64 &addr , UI32 &byte, UI64 &value ) {
    if (m_DataAccessInStep.size() == 0) {
        return false ;
    }
	if( m_itrDataAccessInStep != m_DataAccessInStep.end() ) {
		read1_write0 = (*m_itrDataAccessInStep).m_Read1_Write0 ;
		addr = (*m_itrDataAccessInStep).m_nMemAddress ;
		byte = (*m_itrDataAccessInStep).m_nMemByte ;
		value = (*m_itrDataAccessInStep).m_nMemData;
		m_itrDataAccessInStep++;
		return true ;
	}
	else return false;
}



/****************************************************************/
/*                 コールバック処理メソッド群                   */
/****************************************************************/

/**************************************/
/*  ネイティブ・コンテキスト・アクセス  */
/**************************************/
void CSimulator::update_nc_register(std::string regname, FrogRegData value, FrogRegData prev_value) {
	UI32 value_32 = static_cast<UI32>(value);
	UI32 prev_value_32 = static_cast<UI32>(prev_value);

	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "Native Context Register: " << regname << " = " << std::hex << (UI32)prev_value << " → " << std::hex << (UI32)value << std::endl;
#endif
	FrogRegPro match_reg;
	gcs_get_register_profile(regname, &match_reg);
	
	if (match_reg.m_type == FROG_PC) {									/* PC */
		m_nPC= value_32 ;
	}
	else
	if (match_reg.m_type == FROG_GR) {									/* r0 - r31 */
	}
	else
	if (match_reg.m_type == FROG_SR) {									/* SReg */
		switch(match_reg.m_sel_id) {
			case 0:	//--------------------------------------------------------- Bank 00
				switch(match_reg.m_reg_id) {	
					case 5:											/* PSW */
						m_psw[64]= value_32;
						break ;
					case 0:											/* EIPC */
					case 2:											/* FEPC */
						break ;

					case 15:										/* PSWH */
						m_pswh = value_32 ;
                        MxuSetDirty();
						break ;

					case 18:											/* EIPSW */
					case 19:											/* FEPSW */
						break ;

					case 1:											/* EIPSW */
					case 3:											/* FEPSW */
						break ;

					case 13:										/* EIIC */
					case 14:										/* FEIC */
						m_nCauseCode= value_32 ;
						break ;
					default:	
						break ;
				}
				break ;
			case 1: //---------------------------------------------------------- Bank 01
				switch(match_reg.m_reg_id) {
					case 0:											/* SPID */
                        {
                            char str[8] ;
                            FrogRegData val;
                            std::string name;
						    m_spid = value_32;
                            m_spid_mpidn = 0;
                            for (UI32 i= 0; i < 8 /*MPID_NUM*/; i++ ){
		                        sprintf(str , "MPID%d" , i ) ;
		                        name = std::string(str);
		                        gcs_get_nc_register( name , &val  ) ;
		                        if (m_spid == (UI32)val) {
                                    m_spid_mpidn |= 1 << i;
		                        }
                            }
                        }
						MxuSetDirty(); 

						break ;
					case 16:										/* HVCFG */
                        m_hvcfg = value_32;
                        MxuSetDirty();
                        break;
					default:	
						break ;
				}
				break ;
			case 2: //---------------------------------------------------------- Bank 02

				// Checking wether resbanks instruction in G4MH.
				switch(match_reg.m_reg_id) {	
					case 17:										/* RBNR */
						break ;
				}

				break ;
			case 3: //---------------------------------------------------------- Bank 03
				switch(match_reg.m_reg_id) {	
					case 18:										/* DBPC */
						break ;
					case 19:										/* DBPSW */
						break ;
					case 15:										/* DBIC */
						m_nCauseCode= value_32 ;
						break ;
					case 20:										/* DIR0 */
						m_dir0[8]= value_32 ;
						break;
					default:	
						break ;
				}
				break ;
			case 4: //---------------------------------------------------------- Bank 04
				break ;
			case 5: //---------------------------------------------------------- Bank 05
			{
				UI32 reg = match_reg.m_reg_id ;
                if (reg == 0) {				 /* MPM */
                    m_mpm = value_32;
                    MxuSetDirty();
                } else if (reg == 2) {       /*MPCFG*/
                    m_mpcfg = value_32;
                    MxuSetDirty();
                }

                else if (reg == 17) {       /*MPBK*/
                    m_mpbk = value_32 & 0x1; 
                    MxuSetDirty();
                }
				else if (20 <= reg && reg <= 22) {/* MPLA, MPUA, MPAT */
					FrogRegData mpidx;
					gcs_get_nc_register( "MPIDX" , &mpidx ) ;
					if(reg == 20) {
						m_mpla[m_mpbk][mpidx]= (UI32)value_32 ;
					} else if (reg == 21) {
						m_mpua[m_mpbk][mpidx]= (UI32)value_32 ;
					} else if (reg == 22) {
						m_mpat[m_mpbk][mpidx]= (UI32)value_32 ;
					}
					MxuSetDirty();
				} else if(24 <= reg && reg <= 31) { /* MPIDn */
                    UI32 n = reg - 24;
                    m_mpid[n] = value_32;
                    m_spid_mpidn &= ~(1 << n);
                    m_gmspid_mpidn &= ~(1 << n);

                    if(m_spid == value_32)
                        m_spid_mpidn |= 1 << n;

                    if (m_gmspid == value_32)
                        m_gmspid_mpidn |= 1 << n;
					MxuSetDirty(); 
				}
			}
				break ;
			case 6: //---------------------------------------------------------- Bank 06
			case 7: //---------------------------------------------------------- Bank 07	
				break ;
			case 9:	//--------------------------------------------------------- Bank 09

				switch(match_reg.m_reg_id) {	
					case 5:											/* GMPSW */
						m_gmpsw = value_32 ;
                        MxuSetDirty();
						break ;
					case 0:											/* GMEIPC */
					case 2:											/* GMFEPC */
						break ;
					case 1:											/* GMEIPSW */
					case 3:											/* GMFEPSW */
						break ;
					case 13:										/* GMEIIC */
					case 14:										/* GMFEIC */
						m_nCauseCode= value_32 ;
						break ;
					case 16:										/* GMSPID */
						{
						char str[8] ;
						FrogRegData val;
						std::string name;
						m_gmspid = value_32;
						m_gmspid_mpidn = 0;
						for (UI32 i= 0; i < 8 /*MPID_NUM*/; i++ ){
							sprintf(str , "MPID%d" , i ) ;
							name = std::string(str);
							gcs_get_nc_register( name , &val  ) ;
							if (m_gmspid == (UI32)val) {
                                m_gmspid_mpidn |= 1 << i;
								}
							}
						}
						MxuSetDirty(); 
						break ;
                    case 25: 
                        m_gmmpm = value_32;                        /*GMMPM*/
                        MxuSetDirty();
                        break;
					default:	
						break ;
				}

				break ;
            case 37: //---------------------------------------------------------- Bank 37
            case 40: //---------------------------------------------------------- Bank 40
                m_mpla[m_mpbk][match_reg.m_reg_id] = (UI32)value_32;
                MxuSetDirty();
                break;
            case 38: //---------------------------------------------------------- Bank 38
            case 41: //---------------------------------------------------------- Bank 41
                m_mpua[m_mpbk][match_reg.m_reg_id] = (UI32)value_32;
                MxuSetDirty();
                break;
            case 39: //---------------------------------------------------------- Bank 39
            case 42: //---------------------------------------------------------- Bank 42
                m_mpat[m_mpbk][match_reg.m_reg_id] = (UI32)value_32;
                MxuSetDirty();
                break;
			default:	
				break ;
		}
	}
	else ;

	if (match_reg.m_type == FROG_GR) {
		if (value == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CGrRegProfile( 0x80000000 ,match_reg.m_reg_id ,prev_value_32 )) ;
	} else
	if (match_reg.m_type == FROG_VR) {
		if (value_32 == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CVeRegProfile( 0x80000000 ,match_reg.m_reg_id ,prev_value_32 )) ;
	} else
	if (match_reg.m_type == FROG_PC) {
		if ((UI32)value == (UI32)prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CPcRegProfile( 0x80000000 ,prev_value_32 )) ;
	} else {
		if (value_32 == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CNcRegProfile(match_reg.m_sel_id ,match_reg.m_reg_id ,prev_value_32 )) ;
	}
}

/**************************************/
/*  仮想マシン・コンテキスト・アクセス  */
/**************************************/
void CSimulator::update_vc_register(std::string regname, FrogRegData value, FrogRegData prev_value, UI32 vcid) {

	UI32 value_32 = static_cast<UI32>(value);
	UI32 prev_value_32 = static_cast<UI32>(prev_value);

	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "VC#" << std::dec << vcid << " Context Register: " << regname << " = " << std::hex << prev_value_32 << " → " << std::hex << value << std::endl;
#endif

	FrogRegPro match_reg;
	gcs_get_register_profile(regname, &match_reg);

	if (match_reg.m_type == FROG_PC) {									/* PC */
		m_nPC= value_32 ;
	}
	else
	if (match_reg.m_type == FROG_GR) {									/* r0 - r31 */
	}
	else
	if (match_reg.m_type < 10) {									/* SReg */
		switch(match_reg.m_sel_id) {
			case 1: //---------------------------------------------------------- Bank 01
				if (match_reg.m_reg_id == 0) {						/* MCFG0*/
					m_mcfg0[vcid]= value_32 ;
				}
				break ;
			case 3: //--------------------------------------------------------- Bank 03
				switch(match_reg.m_reg_id) {	
					case 18:										/* DBPC */
						break ;
					case 19:										/* DBPSW */
						break ;
					case 15:										/* DBIC */
						m_nCauseCode= value_32 ;
						break ;
					case 20:										/* DIR0 */
						m_dir0[vcid]= value_32 ;
						break ;
					default:	
						break ;
				}
				break ;
			case 5: //---------------------------------------------------------- Bank 05
				switch(match_reg.m_reg_id) {	
					case 0:											/* MPM */
						m_mpm= value_32 ;
						break ;
					default:	
						break ;
				}
				break ;
			case 9:	//--------------------------------------------------------- Bank 09

				switch(match_reg.m_reg_id) {	
					case 5:											/* GMPSW */
						m_gmpsw = value ;
						break ;
					case 0:											/* GMEIPC */
					case 2:											/* GMFEPC */
						break ;
					case 1:											/* GMEIPSW */
					case 3:											/* GMFEPSW */
						break ;
					case 13:										/* GMEIIC */
					case 14:										/* GMFEIC */
						m_nCauseCode= value_32 ;
						break ;
					case 16:										/* GMSPID */
						{
						char str[8] ;
						FrogRegData val;
						std::string name;
						m_spid = value_32;
						m_asid[64] = 0;
						for (UI32 i= 0; i < 8 /*MPID_NUM*/; i++ ){
							sprintf(str , "MPID%d" , i ) ;
							name = std::string(str);
							gcs_get_nc_register( name , &val  ) ;
							if (m_spid == (UI32)val) {
								m_asid[64] |= 1 << i;
								}
							}
						}
						MxuSetDirty(); 
						break ;
                    case 25:
                        m_gmmpm = value_32;
                        MxuSetDirty();
                        break;
					default:	
						break ;
				}

				break ;

			default: //---------------------------------------------------------
				break ;
		}
		if (value_32 == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CVcRegProfile(vcid ,match_reg.m_sel_id ,match_reg.m_reg_id ,prev_value_32 )) ;
	}
	else ;

}

/**************************************/
/*   スレッド・コンテキスト・アクセス   */
/**************************************/
void CSimulator::update_tc_register(std::string regname, FrogRegData value, FrogRegData prev_value, UI32 htid) {
	UI32 value_32 = static_cast<UI32>(value);
	UI32 prev_value_32 = static_cast<UI32>(prev_value);

	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	std::cout << "TC#" << std::dec << htid << " Context Register: " << regname << " = " << std::hex << prev_value << " → " << std::hex << value << std::endl;
#endif
	FrogRegPro match_reg;
	gcs_get_register_profile(regname, &match_reg);

	if (match_reg.m_type == FROG_PC) {									/* PC */
		m_nPC= value_32 ;
	}
	else
	if (match_reg.m_type == FROG_GR) {									/* r0 - r31 */
	}
	else
	if (match_reg.m_type == FROG_SR) {									/* SReg */
		switch(match_reg.m_sel_id) {
			case 0: //--------------------------------------------------------- Bank 00
				switch(match_reg.m_reg_id) {	
					case 5:											/* PSW */
						m_psw[htid]= value_32 ;
						break ;
					case 0:											/* EIPC */
					case 2:											/* FEPC */
						break ;

					case 15:										/* PSWH */
						m_pswh = value_32 ;
						break ;

					case 18:											/* EIPSW */
					case 19:											/* FEPSW */
						break ;

					case 1:											/* EIPSW */
					case 3:											/* FEPSW */
						break ;

					case 13:										/* EIIC */
					case 14:										/* FEIC */
						m_nCauseCode= value_32 ;
						break ;
					default:	
						break ;
				}
				break ;
			case 2: //---------------------------------------------------------- Bank 02
				if (match_reg.m_reg_id == 7) {						/* ASID*/
					m_asid[htid]= value_32 ;
					MxuSetDirty( htid ); 
				}
				break ;

			case 9:	//--------------------------------------------------------- Bank 09

				switch(match_reg.m_reg_id) {	
					case 5:											/* GMPSW */
						m_psw[64]= value ;
						break ;
					case 0:											/* GMEIPC */
					case 2:											/* GMFEPC */
						break ;
					case 1:											/* GMEIPSW */
					case 3:											/* GMFEPSW */
						break ;
					case 13:										/* GMEIIC */
					case 14:										/* GMFEIC */
						m_nCauseCode= value_32 ;
						break ;
					case 16:										/* GMSPID */
						{
						char str[8] ;
						FrogRegData val;
						std::string name;
						m_spid = value_32;
						m_asid[64] = 0;
						for (UI32 i= 0; i < 8 /*MPID_NUM*/; i++ ){
							sprintf(str , "MPID%d" , i ) ;
							name = std::string(str);
							gcs_get_nc_register( name , &val  ) ;
							if (m_spid == (UI32)val) {
								m_asid[64] |= 1 << i;
								}
							}
						}
						MxuSetDirty(); 
						break ;
                    case 25:
                        m_gmmpm = value_32;
                        MxuSetDirty();
                        break;
					default:	
						break ;
				}

				break ;

			default: //---------------------------------------------------------
				break ;
		}
	}
	else ;

	if (match_reg.m_type == FROG_GR) {
		if (value_32 == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CGrRegProfile( htid ,match_reg.m_reg_id ,prev_value_32 )) ;
	} else
	if (match_reg.m_type == FROG_VR) {
		if (value_32 == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CVeRegProfile( htid ,match_reg.m_reg_id ,prev_value_32 )) ;
	} else
	if (match_reg.m_type == FROG_PC) {
		if (value_32 == prev_value_32) {
			return ;
		}
		//m_Undo.push_back(new CPcRegProfile( htid ,prev_value_32 )) ;
	} else {
		if (value_32 == prev_value_32) {
			return ;
		}
		m_Undo.push_back(new CTcRegProfile( htid ,match_reg.m_sel_id ,match_reg.m_reg_id ,prev_value_32 ));
	}
}

/****************************/
/* メモリー・アクセス        */
/****************************/
void CSimulator::update_generator_memory(UI64 address, UI32 size, UI64 value, UI64 prev_value, UI32 access_type, UI32 access_bus, UI32 load_action){
	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}
	if (access_type == FROG_ACCESS_TYPE_READ){
		if (m_nUndoLogOn != SIM_UNDO_ENABLE) {
			return ;
		}
#if !defined(NDEBUG)
#if defined(_DBG_SIM_H_)
    if (address > 0x4000000) {
		std::cout	<< COUT_BLUE  << "Read Memory (EXC) :" << COUT_RESET
					<< " address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << address 
					<< " size=0x"     << size
					<< " data=0x"     << std::setw(16) << std::right << std::setfill('0') << std::hex << value 
					<< std::endl;
    }
#endif
#endif
		return ;
	}
	if (m_nUndoLogOn == SIM_UNDO_ENABLE) {
#if !defined(NDEBUG)
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		std::cout	<< COUT_RED << "Write Memory(EXC) :" << COUT_RESET
					<< " address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << address 
					<< " size=0x"    << size
 					<< " data=0x"    << std::setw(16) << std::right << std::setfill('0') << std::hex << prev_value 
					<< " → 0x"       << std::setw(16) << std::right << std::setfill('0') << std::hex << value
					<< std::endl;
#endif
#endif
		m_Undo.push_back(new CWrMemProfile(address ,size ,prev_value , m_nUndoLogOn)) ;
	}
	else
	if (m_nUndoLogOn == SIM_UNDO_PRESET) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		std::cout	<< COUT_GREEN << "Write Memory(Preset) :" << COUT_RESET
					<< " address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << address 
					<< " size=0x"    << size
					<< " data=0x"    << std::setw(16) << std::right << std::setfill('0') << std::hex << prev_value 
					<< " → 0x"       << std::setw(16) << std::right << std::setfill('0') << std::hex << value
					<< std::endl;
#endif
        CPresetMemProfile *pProfile = new CPresetMemProfile(address ,size ,value ,prev_value , m_nUndoLogOn);
		m_Undo.push_back(pProfile) ;
        m_mPresetMem.insert(std::make_pair((UI32)address, pProfile));
	}
	else {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		std::cout	<< COUT_GREEN << "Write Memory(API) :" << COUT_RESET
					<< " address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << address 
					<< " size=0x"    << size
					<< " data=0x"    << std::setw(16) << std::right << std::setfill('0') << std::hex << prev_value 
					<< " → 0x"       << std::setw(16) << std::right << std::setfill('0') << std::hex << value
					<< std::endl;
#endif
		m_Undo.push_back(new CWrMemProfile(address ,size ,prev_value , m_nUndoLogOn)) ;
	}
}


/**
 * @brief １命令分のメモリーアクセス情報を一時保存する。
 */
void CSimulator::update_statistics_memory(UI64 address, UI32 size, UI32 access_type, UI32 access_bus, UI32 load_action, UI64 value ) {
    if (m_nUndoLogOn != SIM_UNDO_ENABLE) {
        return ;
    }
    if (load_action == /*data access*/ FROG_ACCESS_BUS_RW) {
        return ;
    }
    if (FROG_ACCESS_TYPE_READ == access_type) {
		DataAccessItem temp(1 , address , size, value ) ;
        m_DataAccessInStep.push_back( temp );
    } else {    
		DataAccessItem temp(0 , address , size, value ) ;
        m_DataAccessInStep.push_back( temp );
    }   
}


/**
 * @brief １命令分のメモリーアクセス情報を一時保存する。
 */
void CSimulator::clear_statistics_memory(void) {
    m_DataAccessInStep.clear() ;
}

/****************************/
/* リンクビット操作          */
/****************************/
void CSimulator::update_generator_llbit(UI64 address, UI32 size, bool isNt, UI32 htid, const int32_t status) {
	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}

    // Update LLBit status
    if((UI32) status == FROG_LLBIT_CREATE) {
        // Add new LLBit
        T_LLBITRECORD r ;
		r.m_type    = 13; // LLBit profile
		r.m_address	= address;
		r.m_size	= size;
		r.m_isNt	= isNt;
		r.m_tcid	= htid;
		r.m_status	= status;
		m_vLLBit.push_back(T_LLBITRECORD(r));
    } else {    // Delete cases
        std::vector<T_LLBITRECORD>::iterator itr;
        itr = std::find_if(m_vLLBit.begin(), m_vLLBit.end(), [=] (T_LLBITRECORD r) {return (r.m_address == address);});
        // W/A for CFOREST limitation, "size is fixed 0 in case of LLBit deleting"
        // This will overwrite LLBit size
        size = (*itr).m_size;
        if(itr != m_vLLBit.end()) {
            // Delete LLBit information
            m_vLLBit.erase(itr);
        }
    }

#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	UI32 t = status;
	if (t == FROG_LLBIT_CREATE) {
		std::cout << "-- Create LL: ";
	} else {
		std::cout << "-- Delete LL: ";
	}
	
	if (isNt) {
		std::cout << "NT#-- ";
	} else {
		std::cout << "HT#" << std::dec << htid << " " ;
	}
	std::cout << "address=0x" << std::hex << address << ", size=" << std::dec << size << std::endl;
#endif

	m_Undo.push_back(new CLLbitProfile(address, size, isNt , htid , status)) ;
}

/****************************/
/* ＴＬＢ操作               */
/****************************/
void CSimulator::update_generator_tlb(UI32 idx , UI32 l0 , UI32 l1 , UI32 h0 , UI32 h1 , UI32 l0_prev , UI32 l1_prev , UI32 h0_prev , UI32 h1_prev , UI32 at) {
	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}

	if(at == FROG_TLB_WRITE_ENTRY){
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		printf("Update TLB[%2d]: Low0=%08X, Low1=%08X, High0=%08X, High1=%08X→ Low0=%08X, Low1=%08X, High0=%08X, High1=%08X\n", idx,l0_prev,l1_prev,h0_prev,h1_prev,l0,l1,h0,h1);
#endif
		m_Undo.push_back(new CTLBProfile( idx , l0_prev  , l1_prev  , h0_prev  , h1_prev , at)) ;
		m_telo0[idx]= l0 ;
		m_telo1[idx]= l1 ;
		m_tehi0[idx]= h0 ;
		m_tehi1[idx]= h1 ;
	}else
	if(at == FROG_TLB_READ_ENTRY){
	}else{
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
		printf("Invalid access type=%s\n", at);
#endif
	}
}

/****************************/
/* コメント・メッセージ      */
/****************************/
void CSimulator::insert_comment(std::string comment) {
	if (m_nUndoLogOn == SIM_UNDO_DISABLE) {
		return ;
	}
    comment = comment.substr(0, comment.find('\n') + 1);
    std::cout << comment << std::endl;
}

void CSimulator::SetSysMemPreset(UI64 addr, UI32 size, UI64 value)
{
	std::vector <CPresetMemProfile*>::iterator itr;
	itr = std::find_if(m_SysMemPreset.begin(), m_SysMemPreset.end(), [&] (CPresetMemProfile *itr)->bool{ return (itr->m_address==addr);});
	if(itr == m_SysMemPreset.end())
		m_SysMemPreset.push_back(new CPresetMemProfile(addr, size, value, 0, SIM_UNDO_PRESET));
}
void CSimulator::GetSysMemPreset(std::vector<T_MEMWRRECORD > * buff)
{
	std::vector <CPresetMemProfile* >::iterator itr;
	for(itr = m_SysMemPreset.begin(); itr != m_SysMemPreset.end(); itr++)
	{
		if((*itr)->m_access_bus == SIM_UNDO_PRESET)
		{
			std::pair<UI32, UI64> r = std::pair<UI32, UI64> ((*itr)->m_size, (*itr)->m_writen);
			buff->push_back(T_MEMWRRECORD((*itr)->m_address, r));
		}
	}
}


/****************************************************************/
/*                コールバック・エントリー関数群                */
/****************************************************************/

void cb_update_nc_register(const std::string regname, FrogRegData value, FrogRegData prev_value) {
	g_simulation->update_nc_register(regname, value, prev_value) ;
}

void cb_update_vc_register(const std::string regname, FrogRegData value, FrogRegData prev_value, UI32 vcid) {
	g_simulation->update_vc_register(regname, value, prev_value, vcid) ;
}

void cb_update_tc_register(const std::string regname, FrogRegData value, FrogRegData prev_value, UI32 tcid) {
	g_simulation->update_tc_register(regname, value, prev_value, tcid) ;
}

void cb_update_generator_memory(uint64_t address, UI32 size, uint64_t value, uint64_t prev_value, UI32 access_type, UI32 access_bus, UI32 load_action) {
	g_simulation->update_generator_memory(address, size, value, prev_value, access_type, access_bus, load_action) ;
	g_simulation->update_statistics_memory(address, size, access_type, access_bus, load_action, value );
}
void cb_update_generator_llbit(UI32 pe_id, uint64_t address, UI32 size, bool isNt, UI32 ptid, const UI32 status) {
	g_simulation->update_generator_llbit(address, size, isNt, ptid, status) ;
}

void cb_update_generator_tlb(UI32 idx, UI32 l0, UI32 l1, UI32 h0, UI32 h1, UI32 l0_prev, UI32 l1_prev, UI32 h0_prev, UI32 h1_prev, UI32 at) {
	g_simulation->update_generator_tlb(idx, l0, l1, h0, h1, l0_prev, l1_prev, h0_prev, h1_prev, at) ;
}

void cb_insert_comment(const std::string &comment) {
	g_simulation->insert_comment( comment ) ;
}
