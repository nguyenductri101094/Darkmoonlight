#include "sim_ctrl.h"
#include "instruction.h"
#include "ifbreakparam.h"
#include "ifblk_manager.h"
#include "adr_selector.h"
#include "insid_set.h"
#include "mxu_parser.h"

extern std::shared_ptr<CGeneratorConfig>	    g_cfg;
extern std::unique_ptr<ISysRegSet>	            g_srs;
extern std::unique_ptr<IException>              g_exp;
extern std::shared_ptr<CAssemblerSourceFile>    g_asf;
extern std::unique_ptr<IBlockManager>			g_mgr;
extern std::shared_ptr<CGeneratorProfile>		g_prf;
extern std::unique_ptr<TWorkMemory>				g_wm;

#define LOGSW_INS_SIM		(!defined(NDEBUG) && 1)
#define LOGSW_REGULATION	(!defined(NDEBUG) && 0)
#define	EXCEPTION_MIN_PROBABLY	100
#define	NewINS(_CB_, _INS_)		((_CB_)->AddOpeCode(_INS_))

CSimulatorControl::CSimulatorControl() {
}

CSimulatorControl::~CSimulatorControl() {
	if (m_pSim) {
		delete m_pSim;
		m_pSim = NULL;
	}
}


/**
 * @brief	シミュレーターを初期化します。
 */	
bool CSimulatorControl::Init(std::string& iniPath) {
	delete m_pSim;
	m_pSim = ISimulator::New();
	if(m_pSim->Init(iniPath) == false) {
		return false;
	}
	m_nWRMemOffset    = 16;	// Offset for initializing WR at beginning
	m_nWRMemBlockCount = 0;
	m_bNewWRMemBlock = false;

	m_bRollback = false;
	m_pRollbackIns = NULL;

	m_nDeassertIdx = 0;
    m_nPreciMismatchReg = 0;
    m_nPreciMismatchFlag = 0;

    m_MPUlist = g_mgr->GetMPUInfor();

	if(g_cfg->m_cpuStopinTime != 0)
		ResetIntTimer();

	return (m_pSim != NULL);
}

void CSimulatorControl::ResetIntTimer(){

	for (UI32 intId = IException::EXP_SYSERR; intId <= IException::EXP_EIINT; intId++){
		m_mAssertINTatTime.insert(std::make_pair(intId, 0));
	}

	for (UI32 intId = IException::EXP_GMFEINT; intId <= IException::EXP_BGEIINT; intId++){
		if(intId == IException::EXP_GMEITBL || intId == IException::EXP_GMRBINT)
			continue;

		m_mAssertINTatTime.insert(std::make_pair(intId, 0));
	}
}


bool CSimulatorControl::ReadySimulation (ISimulationParam* pSp, IBlockSimParam* pBsp) {
	
	_ASSERT(pBsp);
	_ASSERT(m_pSim);
	
	// Get Next Thread
    pBsp->htid = 0x80000000; // m_pSim->GetNextHT();
    m_pSim->ReadPC(&pBsp->lpc);

	// PC Update(physical)
	UI64 pa1 = 0, pa2 = 0;
	UI64 ps1 = 0, ps2 = 0;
	if (m_pSim->MmuTransferAddr(true, 0, (UI64)pBsp->lpc, 1, MXU_ACC_DONTCARE, &pa1, &ps1, &pa2, &ps2) != true) {
		MSG_ERROR(0, "Internal error at address transfer %s(%d).\n", __FUNCTION__, __LINE__);
		return false;
	}
	pBsp->ppc = (UI32)pa1;
		
	//!< Search target block
	if ((pBsp->pCodeBlock = pSp->pAsmSrcObj->Search(pBsp->ppc)) == NULL) {
		MSG_ERROR(0, "Not found address in code. PC={LA=%08X, PA=%08X}\n", pBsp->lpc, pBsp->ppc);
		return false;
	}
	
	pBsp->result = 0;
	
	return true;
}


bool CSimulatorControl::RegulateBranchCondition(CCodeBlock* pCB, IInstruction* pIns) {
	bool bForce = pIns->IsForcedAdjust();

	auto IsAlwaysJump = [](IInstruction *p) -> bool{
		const std::string& mne = p->GetMne();
		return (mne=="ctret" || mne=="eiret" || mne=="feret" || mne=="br" || mne=="jr" || mne=="jmp" || mne=="jarl" 
			|| ((mne=="dispose") && (p->GetOpNum()==3)) );
	};

	if(pIns->Behavior(IInstruction::JMP)){
		if (pIns->HasBranchConstraint() != true) {
			return false;
		}
		
		UI32 psw = GetPSW();
		bool taken = pIns->GetConstraint();
		if (pIns->TakeCondition(psw) == taken) {
			if(!bForce || IsAlwaysJump(pIns)) {
				pIns->DelReverse(); // 反対条件を消す
				return false; // OK!
			}
			pIns->SetConstraint(false);
			if(taken) {
				IInstruction *revIns = pIns->GetReverse();
				revIns->SetConstraint(false);
				if(revIns != nullptr){
					if(revIns->opr(0))
						revIns->opr(0)->SetLabel(pIns->opr(0)->GetLabel());
					pCB->AddOpeCode(revIns, pCB->GetIndex(pIns) + 1);
					return true;
				}
			} else {
				pIns->opr(0)->Replace(pIns->GetLen());
				pIns->opr(0)->RemoveLabel();
				pIns->DelReverse(); // 反対条件を消す
			}
			return false;
		}

		// 反対命令を持たない
		// NotTaken制約BSAがTakenになる場合
		if ((pIns->GetMne()=="bsa") && (taken==false)) {
			pIns->DelReverse(); // 反対条件を消す
			pIns->opr(0)->Replace(pIns->GetLen());
			pIns->opr(0)->RemoveLabel();
			if(bForce){
				pIns->SetConstraint(false);
			}
			return false; // OK!
		}

		// branchの補正処理（反対命令を入れる）
		IInstruction* revIns = pIns->GetReverse();
		if (revIns == nullptr) {
			MSG_ERROR(0, "Internal error -> branch control regulate[%s] ""%s"" psw=%08x\n", (taken?"Taken":"NotTaken"), pIns->GetMne().c_str(), psw);
			FROG_ASSERT(0);
		}

        revIns->SetTaken(pIns->GetConstraint());

		if (revIns->opr(0)) {
			// brの反対命令はnopにしている。br以外はオペランドあり
			// またbr17命令はISAにない！
			revIns->opr(0)->SetLabel(pIns->opr(0)->GetLabel());
		}

		if(pIns->InSequence(IInstruction::IF_SEQ_C2B1)) {
			if(pIns->GetId() == INS_ID_BSA_SD9){
				IInstruction* pPrevIns = pCB->at(pCB->GetIndex(pIns)-1);
				pPrevIns->DelComment();
                pPrevIns->SetC2B1Ins(nullptr);
                pPrevIns->SetSequence(IInstruction::IF_SEQ_C2B1, false);
			}
			else{
				IInstruction* pPrevIns = pCB->at(pCB->GetIndex(pIns)-1);
				pPrevIns->SetC2B1Ins(revIns);
				revIns->SetSequence(IInstruction::IF_SEQ_C2B1); //[FROG]TODO
				revIns->AppendComment(pIns->GetComment().c_str());
			}
		}
		pIns->DirMoveTo(revIns);
		pIns->AsyncMoveTo(revIns);
		if( pIns->GetLabel().find("_bp_") != std::string::npos ) {
			revIns->SetLabel(pIns->GetLabel());
		}
		revIns->m_bBreakTargetIns = pIns->m_bBreakTargetIns;
		revIns->m_bBreakInsertIns = pIns->m_bBreakInsertIns;
		if(!bForce) {
			PrepareDeletedIns(pCB, pIns);
			pCB->Replace(pIns, revIns);
			delete pIns;
			return true;
		}
		pIns->SetConstraint(false);
		if(revIns != NULL)
			revIns->SetConstraint(false);
		if(taken) {
			pCB->AddOpeCode(revIns, pCB->GetIndex(pIns));
		} else {
			if (revIns->opr(0)) {
				revIns->opr(0)->Replace(pIns->GetLen());
				revIns->opr(0)->RemoveLabel();
			}
			pCB->Replace(pIns, revIns);
			delete pIns;
		}

		return true;
	}
	else return false;
}

/**
*@brief	Handle MIP exception has occur at SYNCI instruction to prevent hazard
*@param	pIns: current handle instruction
*/
void CSimulatorControl::PreventHazardSystemRegister(IInstruction *pIns) {

    UI32 oldValue = 0, newValue = 0, PC = 0;
    UI32 old_SPID_MPIDn = 0;
    UI32 sr = (UI32) *(pIns->opr(1));
    IValConstraint* pConst = pIns->opr(0)->GetConstraint();
    m_pSim->ReadPC(&PC);

    if (pConst != nullptr) {
        newValue = pConst->SelectValue();
    } else {
        m_pSim->ReadGrReg(&newValue, pIns->opr(0)->Idx(), 0);
    }

    // Backup old value of system register
    switch (sr) {
        case (0 * 32 + 5):
            oldValue = m_pSim->GetPSW();
            m_pSim->SetPSW(newValue);
            break;
        case (1 * 32 + 0):  // SPID
        {
            old_SPID_MPIDn = m_pSim->GetSPID_MPIDn();
            m_pSim->ReadNcReg(&oldValue, (sr & 0x1f), (sr >> 5));

            char str[8];
            std::string name;
            UI32 mpidn = 0;
            UI32 spid = newValue & 0x1f;
            UI32 new_SPID_MPIDn = 0;

            for (UI32 i = 0; i < 8 /*MPID_NUM*/; i++) {
                sprintf(str, "MPID%d", i);
                name = std::string(str);
                m_pSim->ReadSysRegister(&mpidn, name, 0);
                if (spid == mpidn) {
                    new_SPID_MPIDn |= 1 << i;
                }
            }
            m_pSim->SetSPID_MPIDn(new_SPID_MPIDn);
        }
        break;
        case (1 * 32 + 16):
            oldValue = m_pSim->GetHVCFG();
            newValue &= 0x1;
            m_pSim->SetHVCFG(newValue);
            break;
        case (5 * 32 + 0):
            oldValue = m_pSim->GetMPM();
            newValue &= 0x7;
            newValue |= (oldValue & 0xFFFFFFFC);
            m_pSim->SetMPM(newValue);
            break;
        case (5 * 32 + 2):
            oldValue = m_pSim->GetMPCFG();
            m_pSim->SetMPCFG(newValue);
            break;
    /*    case (5 * 32 + 17):
            oldValue = m_pSim->GetMPBK();
            newValue &= 0x1;
            m_pSim->SetMPBK(newValue);
            break;*/
        case (5 * 32 + 20):
        {
            UI32 MPIDX = 0;
            m_pSim->ReadSysRegister(&MPIDX, "MPIDX", 0);
            oldValue = m_pSim->GetMPLA(MPIDX);
            newValue &= 0xFFFFFFFC;
            m_pSim->SetMPLA(MPIDX, newValue);
        }
            break;
        case (5 * 32 + 21):
        {
            UI32 MPIDX = 0;
            m_pSim->ReadSysRegister(&MPIDX, "MPIDX", 0);
            oldValue = m_pSim->GetMPUA(MPIDX);
            newValue &= 0xFFFFFFFC;
            m_pSim->SetMPUA(MPIDX, newValue);
        }
            break;
        case (5 * 32 + 22):
        {
            UI32 MPIDX = 0;
            m_pSim->ReadSysRegister(&MPIDX, "MPIDX", 0);
            oldValue = m_pSim->GetMPAT(MPIDX);
            m_pSim->SetMPAT(MPIDX, newValue);
        }
            break;
        case (5 * 32 + 24) ... ((5 * 32 + 31)) :     // MPID0 -> MPID7
        {
            old_SPID_MPIDn = m_pSim->GetSPID_MPIDn();
            m_pSim->ReadNcReg(&oldValue, (sr & 0x1f), (sr >> 5));

            newValue &= 0x1f;
            UI32 n = (sr & 0x1f) - 24;
            UI32 new_SPID_MPIDn = old_SPID_MPIDn & ~(1 << n);

            UI32 SPID = 0;
            if (IsGuestMode()) {
                m_pSim->ReadSysRegister(&SPID, "GMSPID", 0);
            } else {
                m_pSim->ReadSysRegister(&SPID, "SPID", 0);
            }

            if (SPID == newValue)
                new_SPID_MPIDn |= 1 << n;

            m_pSim->SetSPID_MPIDn(new_SPID_MPIDn);
        }
            break;
        default:
            m_pSim->ReadNcReg(&oldValue, (sr & 0x1f), (sr >> 5));
            break;
    }

    // Check MIP exception at SYNCI when got new value
    if (IsMIPexception(PC + 4, 0xA) != NO_ERROR) {
        pIns->opr(0)->SetConstraint(new INumConstraint(oldValue, oldValue));
    }

    // Restore old value for system register
    switch (sr) {
        case (0 * 32 + 5):
            m_pSim->SetPSW(oldValue);
            break;
        case (1 * 32 + 0):
            m_pSim->SetSPID_MPIDn(old_SPID_MPIDn);
            break;
        case (1 * 32 + 16):
            m_pSim->SetHVCFG(oldValue);
            break;
        case (5 * 32 + 0):
            m_pSim->SetMPM(oldValue);
            break;
        case (5 * 32 + 2):
            m_pSim->SetMPCFG(oldValue);
            break;
     /*   case (5 * 32 + 17):
            m_pSim->SetMPBK(oldValue);
            break;*/
        case (5 * 32 + 20):
        {
            UI32 MPIDX = 0;
            m_pSim->ReadSysRegister(&MPIDX, "MPIDX", 0);
            m_pSim->SetMPLA(MPIDX, oldValue);
        }
        break;
        case (5 * 32 + 21):
        {
            UI32 MPIDX = 0;
            m_pSim->ReadSysRegister(&MPIDX, "MPIDX", 0);
            m_pSim->SetMPUA(MPIDX, oldValue);
        }
        break;
        case (5 * 32 + 22):
        {
            UI32 MPIDX = 0;
            m_pSim->ReadSysRegister(&MPIDX, "MPIDX", 0);
            m_pSim->SetMPAT(MPIDX, oldValue);
        }
        break;
        case (5 * 32 + 24) ... ((5 * 32 + 31)) :
            m_pSim->SetSPID_MPIDn(old_SPID_MPIDn);
            break;
        default:
            break;
    }
    // Check MIP exception at SYNCI with current value
    if (IsMIPexception(PC + 4, 0xA) != NO_ERROR) {
        pIns->opr(0)->SetConstraint(new INumConstraint(oldValue, oldValue));
    }
}

bool CSimulatorControl::MaskSysRegLoad (CCodeBlock* pCB, IInstruction *pIns)
{
	auto ReadSpecialSReg = [&] (UI32 &val, UI32 regId, UI32 selId) -> bool{
		UI32 srVal;
		if (selId == 0)
		{
			if(regId == 8){ // FPST(0,8)
				// FPST reflects FPSR (0, 6) register.
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				UI32 valXC = (srVal >> 10) & 0x3F;
				UI32 valXP = (srVal >> 0) & 0x1F;
				val = (valXC << 8) | (valXP << 0);
				//if (FPU_SEL_FPU20) {	// FPU-2.0 // TODO: Support FPU-2.0
				   // UI32 valPR = (srVal >> 16) & 0x1;
				   // val = ( valPR << 15 ) | (valXC << 8) | (valXP << 0) ;
				//} else {											// FPU-3.0
					UI32 valIF = (srVal >> 22) & 0x1;
					val = (valXC << 8) | ( valIF << 5 ) | (valXP << 0) ;
				//}
				return true;
			}else if(regId == 9){   // FPCC(0,9)
				// FPCC reflects FPSR (0, 6) register.
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				val = (srVal >> 24) & 0xFF;
				return true;
			}else if(regId == 10){  // FPCFG(0, 10)
				// FPCFG reflects FPSR (0, 6) register.
				UI32 valRM, valXE;
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				valRM = (srVal >> 18) & 0x3;
				valXE = (srVal >> 5) & 0x1F;
				val = (valRM << 8) | (valXE << 0);
				return true;
			}
		}
		return false;
	};

	auto GenerateRandomVal = [](UI32 mask){
		UI32 nMask = 1;
		UI32 nCount = 0;
		UI32 randomVal = 0;
		UI32 nResult = 0;

		nCount	= 0;
		nMask = 1;
		while(nMask){
			if(mask & nMask)
				nCount++;
			nMask <<= 1;
		}
		// Generate a random number in range of (0; (2^nCount) - 1)
		randomVal = g_rnd.GetRange((UI32) 0, (UI32) ((1 << nCount) - 1 ));

		nCount	= 0;
		nMask	= 1;
		while(nMask){
			if(mask & nMask){
				nResult |= (randomVal & 1) << nCount;
				randomVal >>= 1;
			}
			nCount++;
			nMask <<= 1;
		}
		return nResult;
	};


	auto IsNeededMPUProtect = [=] (UI32 sr) -> bool {
        UI32 mip_demand_gm = g_prf->m_mpdemand[0] >> 16;
        UI32 mpla_gm = 0, mpua_gm = 0;
		UI32 pc;
		UI32 svlock = 0, hvcfg = 0, pswh = 0;

		if((GetPSW() & 0x40000000))
			return false;

        mpla_gm = m_pSim->GetMPLA(mip_demand_gm);
        mpua_gm = m_pSim->GetMPUA(mip_demand_gm);
        m_pSim->ReadNcReg(&svlock, 8, 1);
        m_pSim->ReadNcReg(&hvcfg, 16, 1);
        m_pSim->ReadNcReg(&pswh, 15, 0);

		m_pSim->ReadPC(&pc);
		
		if(mpla_gm <= pc && pc <= mpua_gm) {
			return false;
		}
		// SPID, MPM, MPLA, MPUA, MPAT, MPIDn can not be update when SVLOCK.SVL = 1
		if(svlock != 0 
			&& ((sr >> 5) == 0x5 /* MPU SRs */ || (sr == (1 * 32) +  0)  /* SPID */ ))
			return false;

        if ((hvcfg & 0x1) != 0 && (pswh & 0x80000000) == 0)
            return false;

		return true;
	};

	const std::string &mne = pIns->GetMne();

	//if(pIns->Behavior(IInstruction::LOAD_SR) && pIns->opr(0)->GetConstraint() == NULL)
	if(mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr")
	{
		const UI32 NO_MASK = 0xffffffff;
		IValConstraint *pConst = pIns->opr(0)->GetConstraint();

		UI32 sr = (UI32) *(pIns->opr(1));
		UI32 regId = (sr & 0x1f);
		UI32 selId = (sr >> 5);
		UI32 nMask;

		nMask = g_srs->GetWriteMask(regId, selId);
		if(nMask != NO_MASK){
			UI32 grVal, srVal;

			if( pConst == NULL || !pConst->GetType(IValConstraint::DUMMY))
			return true;

			//m_pSim->ReadGrReg(&grVal, pIns->opr(0)->Idx(), 0/*htid#0*/);
			grVal = GenerateRandomVal(nMask);

			// Special cases FPST(0,8), FPCC(0,9), FPCFG(0, 10)
			if(!ReadSpecialSReg(srVal, regId, selId)){
				UI32 nContext;
				const UI32 NC = 1 << 0; //CSysReg::SR_CONTEXT_NC
				const UI32 VC = 1 << 1; //CSysReg::SR_CONTEXT_VC
				const UI32 TC = 1 << 2; //CSysReg::SR_CONTEXT_TC
				const UI32 CONTEXT_END = 1 << 3; //CSysReg::SR_CONTEXT_END

				if(mne == "ldtc.sr")
					nContext = TC;
				else if (mne == "ldvc.sr")
					nContext = VC;
				else
				if(!g_srs->GetContext(regId, selId, nContext))
					nContext = CONTEXT_END;

				if(nContext == NC || IsNativeMode()) // Native Context
				{
					m_pSim->ReadNcReg(&srVal, regId, selId);
				}
				else if (nContext == VC || (nContext == (NC | VC) && !IsNativeMode())) // Virtual Context
				{
					UI32 htcfg0;
					UI32 htid = 0; // TODO: Not support multi-thread
					UI32 vcid;
					m_pSim->ReadTcReg(&htcfg0, 0,  2, htid);
					vcid = (htcfg0 >> 8) & 7 ;
					m_pSim->ReadVcReg(&srVal, regId, selId, vcid);
				}
				else if (nContext == TC || ((nContext == (NC | TC)) && !IsNativeMode())) // Thread Context
					m_pSim->ReadTcReg(&srVal, regId, selId, 0/*htid#0*/); // TODO: Support multi-thread
				else{
					MSG_INFO (0, "Can not read current system register SR[%d][%d].\n", selId, regId );
					return true;
				}
			}
			grVal = (grVal & nMask) | (srVal & ~nMask);
			pIns->opr(0)->RemoveConstraint(); // Remove dummy constraint
			pIns->opr(0)->SetConstraint(new INumConstraint(grVal, grVal));
		} else {

			// Ajust MPIDX to avoid regions that used for MIP/MDP setting
			if(regId == 16 && selId == 5 /* MPIDX */ && pIns->GetRegulationTarget() == NULL) {
				UI32 regVal, newVal;
				m_pSim->ReadGrReg(&regVal, pIns->opr(0)->Idx(), 0);
				
				newVal = regVal;
				while(g_prf->IsWorkMPURegionByIdx(newVal)) {
					newVal = g_rnd.GetRange((UI32)0, g_hwInfo->m_mpnum - 1);
				}
				if(newVal != regVal){
					pIns->opr(0)->SetConstraint(new INumConstraint(newVal, newVal));
				}
			}
		}
        // Random MPCFG
        if (sr == (5 * 32 + 2)) {  
            UI32 regVal = 0, hbe = 0;

            m_pSim->ReadGrReg(&regVal, pIns->opr(0)->Idx(), 0);
            hbe = (regVal >> 8) & 0x3F;

            if (m_MPUlist->IsValidHBE(hbe) == false) {
                hbe &= 0xFFFFC0FF;   // clear old value
                hbe |= (m_MPUlist->RandomHBE() << 8);
                pIns->opr(0)->SetConstraint(new INumConstraint(hbe, hbe));
            }           
        }

        if (g_srs->IsHazardedSR(sr) && (GetPSW() & 0x40000000) == 0) {
            PreventHazardSystemRegister(pIns);
        }
    }

	IInstruction *pTarget = pIns->GetRegulationTarget();
    if (pTarget != NULL) {
        UI32 nTargetId = pTarget->GetId();
        if ((nTargetId == INS_ID_LDSR || nTargetId == INS_ID_LDTC_SR || nTargetId == INS_ID_LDVC_SR)
            && IsFirstRegulationIns(pCB, pIns)) {
            UI32 sr = (UI32) *(pTarget->opr(1));
            if (((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12))/*MPU SRs*/
                || (sr == (1 * 32) + 0)  /* SPID */
                || (sr == (0 * 32) + 5)  /* PSW */) {
                if (!IsNeededMPUProtect(sr)) {
                    // Delete adjustment code
                    UI32 idx = pCB->GetIndex(pIns);
                    UI32 nDelete = 0;
                    while (pIns != pTarget) {
                        if (pIns->GetRegulationTarget() == pTarget
                            && pIns->GetComment().find("privilege") == std::string::npos
                            && pIns->GetComment().find("Regulation code") == std::string::npos) {
                            pIns->DirMoveTo(pCB->at(idx + 1));
                            pIns->AsyncMoveTo(pCB->at(idx + 1));
                            pCB->Remove(pIns);
                            nDelete++;
                        } else {
                            idx++;
                        }
                        pIns = pCB->at(idx);
                    }
                    if (nDelete) {
                        return false;
                    }
                }
            }
        }
    }
	return true;
}

bool CSimulatorControl::AdjustJumpForwarding(CCodeBlock *pCB, IInstruction *pIns) {
	if(pIns->GetRegulationTarget() == nullptr)
		return false;

	auto GetUI32ActualSize = [] (UI32 num) ->UI32 {
		if((num & 0xffffff80) == 0)
			return 1;	// BYTE size
		if((num & 0xffff8000) == 0)
			return 2;	// HWORD size
		return 4;	// WORD size
	};

	// Regulate forwarding for LOOP by replacing termination ins. (MOVI32) by its FWD partner.
	IInstruction *pTarget = pIns->GetRegulationTarget();
	UI32 targetId = pTarget->GetId();
	// Fowarding couple ALU/LD_SPECIAL and ALU/LU_JUMP
	if(targetId == INS_ID_LOOP || targetId == INS_ID_JARL || targetId == INS_ID_JMP || targetId == INS_ID_JMPD32) {
		if(pTarget->GetInsNeed().size() == 0)
			return false;

		UI32 ex = 0; // Temporary variable
		UI32 targV = (UI32)(*(pIns->opr(0)));
		UI32 reg = pIns->opr(1)->Idx();
		IInstruction *pNeed = pTarget->GetInsNeed().back();
		// Recover solution for the size of LD less than targV
		if(pNeed->Behavior(IInstruction::LOAD_MEMORY)) {
			UI32 size = pNeed->opr(0)->GetConstraint()->m_nSzm;
			UI32 targSize = GetUI32ActualSize(targV);
			IInstruction *pNew = nullptr;
            CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());
			if(size == 1) {	// BYTE size but size(targV) > BYTE 
				if(targSize > 2) {	// BYTE size but size(targV) < HWORD
					pNew = pInsSet->CreateIns(INS_ID_LD_WSD23);
					pNew->opr(0)->SetConstraint(new CLoadAddressSelector(0xFEE00000 /*Not used*/, 0xFEEFFFFF /*Not used*/, 0x03, 4, 0 , true));
				} else if (targSize == 2) {	// size(targV) > HWORD, but size < WORD
					pNew = pInsSet->CreateIns(INS_ID_LD_HSD23);
					pNew->opr(0)->SetConstraint(new CLoadAddressSelector(0xFEE00000 /*Not used*/, 0xFEEFFFFF /*Not used*/, 0x01, 2, 0, true));
				}
			}
			if(size == 2 && targSize > 2) {	// HWORD size but size(targV) > HWORD 
				pNew = pInsSet->CreateIns(INS_ID_LD_WSD23);
					pNew->opr(0)->SetConstraint(new CLoadAddressSelector(0xFEE00000 /*Not used*/, 0xFEEFFFFF /*Not used*/, 0x03, 4, 0, true));
			}

			if(pNew != nullptr) {
				pNew->opr(0)->Replace(pNeed->opr(0)->Idx());
				pNew->opr(1)->Replace(pNeed->opr(1)->Idx());
				pIns->ClearInsNeed();
				delete pNeed;
				pNew->SetSequence(IInstruction::IF_SEQ_FWD);
				pNew->AppendComment(" --Forwarding Data instruction");
				pNew->SetForwardIns(pTarget);
				pTarget->SetInsNeed(pNew);
			}
		}

		// Set constraint for JUMP instruction that was not set beforehand.
		if(targetId == INS_ID_JARL || targetId == INS_ID_JMP || targetId == INS_ID_JMPD32) {
			pTarget->opr(0)->SetConstraint(new INumConstraint(targV, targV));
		}
		std::vector<IInstruction*> vIns = RegulateByForwardingIns(0 /*htid*/, targV, reg, ex, pTarget, pCB);

		UI32 idx = pCB->GetIndex(pIns);
		IInstruction *pNewIns = NULL;
		while(vIns.size()) {
			pNewIns = vIns.back();

            if (g_mgr->GetMismatchReg() != 0 && pNewIns->Behavior(IInstruction::STORE_MEMORY)) {
                pNewIns->SetForcedAdjust(true);
            }

			pCB->AddOpeCode(pNewIns, idx);
			vIns.pop_back();
		}
		if(pNewIns != NULL) {
			// Move direction to last inserted instruction.
			pIns->DirMoveTo(pNewIns);
			pCB->Remove(pIns);
			pCB->Update();
			return true;
		}
	}
	return false;
}

bool CSimulatorControl::CheckHALTReleaseCond(IInstruction *pIns) { 

    // HALT instruction need SV privilege
    if ((GetPSW() & 0x40000000))
        return false;

    // HALT can not be released in Debug mode
    UI32 dir0 = 0;
    m_pSim->ReadNcReg(&dir0, 20, 3);

    if ((dir0 & 0x1))
        return false;

    std::set <std::string> InterruptType = {"bgeiint", "bgeitbl", "bgfeint", "gmeiint", "gmeitbl", "gmfeint"};
    std::set <std::string> InterruptChangeVM = { "bgeiint", "bgeitbl", "bgfeint", "eiint", "eitbl", "fenmi", "feint" };

    UI32 pswh = 0, hvsb = 0;
    m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
    m_pSim->ReadSysRegister(&hvsb, "HVSB", 0);

    // Check and adjust requests at current instruction
    IDirective *pDir = nullptr;
    UI32 n = 0;
    bool INTpending = false, INTtoVMAccepted = false;

    while ((pDir = pIns->GetDirective(n)) != nullptr) {

        CAsyncLabel *pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
        if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
            if (CheckAcceptanceCond(pAsyncLabel->m_nEventId, pAsyncLabel->m_priority) == false) {

				// Support Spec. G4MH2.0 ver. 108 section 2.5.10
				if ((pswh >> 31) == 0 && InterruptType.find(pAsyncLabel->m_name) != InterruptType.end()) {
					//Do nothing
				} else {
					INTpending = true;
				}
			} else if (InterruptChangeVM.find(pAsyncLabel->m_name) != InterruptChangeVM.end()
                || (pAsyncLabel->m_nEventId >= IException::EXP_GMFEINT && pAsyncLabel->m_nEventId <= IException::EXP_GMRBINT && ((hvsb >> 3) & 0x1) == 1)) {
                    INTtoVMAccepted = true;  
            }
		}
        n++;
    }

    // There is pending event.
    for (CIntInfo* itr_info : m_vRequestedIntStack) {
        if (CheckAcceptanceCond(itr_info->nEventId, itr_info->nPriority) == false) {
            // Support Spec. G4MH2.0 ver. 108 section 2.5.10
            if ((pswh >> 31) == 0 && InterruptType.find(itr_info->sName) != InterruptType.end()) {
                // Do nothing
            } else {
                INTpending = true;
            }
        } else if (InterruptChangeVM.find(itr_info->sName) != InterruptChangeVM.end()
             || (itr_info->nEventId >= IException::EXP_GMFEINT && itr_info->nEventId <= IException::EXP_GMRBINT && ((hvsb >> 3) & 0x1) == 1)) {
                INTtoVMAccepted = true;
        }
    }

    if (INTpending == true && INTtoVMAccepted == false) {
        return false;
    }

    return true;
}

bool CSimulatorControl::RegulateValueConstraint(CCodeBlock* pCB, IInstruction* pIns) {
	_ASSERT(pCB);
	_ASSERT(pIns);

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	bool bForce = pIns->IsForcedAdjust();
	r.SetForce(bForce);
	r.SetRepeat(pIns->GetRepeat());

	/*skip regulation if UCPOP pIns*/
	UI32 insid = pIns->GetId();
	if ( insid == INS_ID_LDV_DW_2REG || insid == INS_ID_LDV_QW_2REG || insid == INS_ID_LDV_W_2REG || insid == INS_ID_LDVZ_H4_2REG 
	|| insid == INS_ID_STV_DW_2REG || insid == INS_ID_STV_QW_2REG || insid == INS_ID_STV_W_2REG || insid == INS_ID_STVZ_H4_2REG || (insid >= INS_ID_CNVQ15Q30 && insid <= INS_ID_VXOR) /*Prevent SIMD instruction to be regulated because regulation code is not neccessary and can cause out of codeblock size*/ ) {
		return false;
	}

	if(pIns->GetMne() == "loop") {
		IValConstraint *pConst = pIns->opr(0)->GetConstraint();
		if(pConst != NULL && pConst->GetType(IValConstraint::DUMMY)) {
			IInstruction *pTemp;
			IInstruction *pNewIns;
			//[FROG]TODO: Improve it
			UI32 addr = (g_wm->BASE_PE + g_wm->SIZE_PE + 6*4*(512 >> 4));
			UI32 lp = pCB->GetIndex(pIns);
			UI32 i;
			// If r3 is used as loop counter.
			if(pIns->opr(0)->Idx() == 3) {
				UI32 reg = 0;
				for(UI32 i = lp - 1; i >= 0; i--) {
					IInstruction *pTemp = pCB->at(i)->GetRegulationTarget();
					if (pTemp == NULL) {
						pTemp = (pCB->at(i)->GetC2B1Ins() != nullptr) ? pCB->at(i)->GetC2B1Ins() : pCB->at(i)->GetForwardIns();
					}
					if(pTemp!= NULL && pTemp->GetMne() == "loop"){
						pTemp = pCB->at(i + 1);
						reg = pTemp->opr(1)->Idx();
						break;
					}
				}
				pNewIns = MOVR(reg, 3);
				pNewIns->SetInLoop();
				pCB->AddOpeCode(pNewIns, lp);
			}

			i = lp -1; // [FROG]TODO: If async occurs at loop?
			do {
				pTemp = pCB->at(i);
				if(pTemp->GetException().first != 0)
					break;
				i--;
			} while (pTemp->InLoop());
			if(pTemp->InLoop() || (pTemp->GetRegulationTarget() != NULL && pTemp->GetRegulationTarget()->InLoop())) {
				pNewIns = POPSP(1, 31); // Restore register status
				pNewIns->SetInLoop();
				pCB->AddOpeCode(pNewIns, lp);

				// Move stack address to r3
				pNewIns = MOV32(addr, 3);
				pNewIns->SetInLoop();
				pCB->AddOpeCode(pNewIns, lp);
				pIns->DirMoveTo(pNewIns);
			}

			pIns->opr(0)->RemoveConstraint(); // Remove dummy constraint
			return true;
		}
	}

	// Needed to RE-ASM when removing instruction
	if(AdjustJumpForwarding(pCB, pIns))
		return true;

	// Needed to RE-ASM when removing instruction
	if (!MaskSysRegLoad(pCB, pIns)) 
		return true;

    // Check MIP occur in sequence regulate for FERET/EIRET
    if (pIns->GetRegulationTarget() != nullptr
        && (pIns->GetRegulationTarget()->GetId() == INS_ID_FERET || pIns->GetRegulationTarget()->GetId() == INS_ID_EIRET) 
        && IsFirstRegulationIns(pCB, pIns)) {
        UI32 PC = 0;
        m_pSim->ReadPC(&PC);
        if (IsMIPexception((PC + 0x20), 0xe)) {
            UI32 position = pCB->GetIndex(pIns);
            IInstruction* pInsXXRET = pIns->GetRegulationTarget();
            IInstruction* pInsNext = pIns;

            while (pInsNext != pInsXXRET) {
                pInsNext->SetRegulationTarget(nullptr);
                position++;
                pInsNext = pCB->at(position);
            }

            pCB->Remove(pInsXXRET);
            return true;
        }
    }

	//       (a)  (b)  (c)
	// oprxx r1,  r4,  r1
	// 
	//       「(a)のr1」と「(c)のr1」に値制約がある場合、
	//        制約が矛盾する場合これを解決出来ない。
	//        「(c)のr1」制約は削除する->（a）の制約と同じになる。
	// 

	std::bitset<32> grlist(0);
    if(!pIns->SolveConstraint())
    {
	    for (UI32 x = 0; x < pIns->GetOpNum(); x++) {
		    IOperand* popr = pIns->opr(x);
		    if (popr->IsGR() && (popr->GetConstraint()!=NULL)) {
			    if (grlist[popr->Idx()]) {
				    popr->RemoveConstraint();
			    }else{
				    grlist.set(popr->Idx());
			    }
		    }
	    }
    }

    // WRについても、同一レジスタがオペランドで使用される場合、
    // ２つ目のオペランドに対する制約を削除する。
    // 補正命令が重複して作成されるのを防ぐため。
	std::bitset<32> wrlist(0);
	for( UI32 x = 0; x < pIns->GetOpNum(); x++ ) {
		IOperand* popr = pIns->opr(x);
		if( popr->IsWR() && (popr->GetConstraint() != NULL )) {
			if( wrlist[popr->Idx()] ) {
				popr->RemoveConstraint();
			} else {
				wrlist.set(popr->Idx());
			}
		}
	}


	if(pIns->GetId() == INS_ID_CACHE) {
		IValConstraint *pConst = pIns->opr(1)->GetConstraint();
		IOperand *pCacheOp = pIns->opr(0);
		if(((UI32) *pCacheOp) == 2 /*CFALI*/ && pConst != NULL) {
			pConst->SetType(IValConstraint::FETCH);
		}
	} else if (pIns->GetId() == INS_ID_PREF) {
		IValConstraint *pConst = pIns->opr(1)->GetConstraint();
		IOperand *pPrefOp = pIns->opr(0);
		if(((UI32) *pPrefOp) == 0 /*PREFI*/ && pConst != NULL) {
			pConst->SetType(IValConstraint::FETCH);
		}
	}

	// ignore regulate the instruction if UCPOP exception occur
	UI32 psw = GetPSW();
	if (!((pIns->GetPriviledge() == 2) && ((psw & 0x20000) == 0))) {
		pIns->Regulate(&r);
		pIns->SetForcedAdjust(false);
	}

	if (r.Pass()) {
		// Memory Init before first access! --> to create __preload codeblock.
		if (pIns->Behavior(IInstruction::LOAD_MEMORY) || 
			pIns->Behavior(IInstruction::STORE_MEMORY) ) { // Store時も周辺８バイトで初期化
			std::vector<std::pair<UI32,UI32> >::iterator itr;
			for (itr = r.m_vEa.begin(); itr != r.m_vEa.end(); itr++) {
				const UI64 PSIZE = 4ULL;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;
				const UI64 ALIGN = ~(PFETCHSIZE - 1);
				UI64 start_na	= itr->first;					// NO Align head
				UI64 end_na		= itr->first + itr->second - 1;	// NO Align tail
				UI64 start_a	= start_na & ALIGN;				// Word Align head
				UI64 end_a		= end_na & ALIGN;
                if (pIns->GetId() == INS_ID_STM_GSR || pIns->GetId() == INS_ID_STM_MP) {
                    m_mNotSelfCheckMemoryList.insert(std::make_pair(start_a, end_na));
                }

                if (IsMDPexception(itr->first, itr->second, pIns->Behavior(IInstruction::LOAD_MEMORY), pIns->Behavior(IInstruction::STORE_MEMORY)) != NO_ERROR) {
                    // Set exception information
                    pIns->SetException(0x91, 0x90);
                }

                for (UI64 z = start_a; z <= end_a; z += PFETCHSIZE) {
                    UI64 rv = 0;
                    rv = g_rnd.Get();			// Gereate RANDOM for initial value on memory(32bit upper).
                    rv = (rv << 32) | g_rnd.Get();	// Gereate RANDOM for initial value on memory(64bit).

                    // Access into share memory with multi setting. 
                    if (g_prf->IsCompetitiveMem((MEMADDR)z) == true) {

                        //Check STORE into Competitive memory (PE0-CIWR, PE1 CRW, PE2 CW)
                        if (pIns->Behavior(IInstruction::STORE_MEMORY) && pIns->GetInsNeed().size() == 0) {
                            if (CanStoreMem(pCB, pIns, z) == true) {
                                // RMW- bitop instruction 
                                if (pIns->Behavior(IInstruction::LOAD_MEMORY) == true && pIns->GetId() != INS_ID_CAXI) {
                                    return false;
                                } else {
                                    pIns->SetForcedAdjust(true);
                                }
                            } else {
                                ImprovingStoreCompetitive(pCB, pIns);
                            }
                            return true;
                        } else if (pIns->GetInsNeed().size() == 0 
                            && (pIns->GetId() == INS_ID_LDM_GSR || (pIns->GetId() == INS_ID_LDM_MP && g_prf->m_is_mpu == true))) {
                                PrepareDeletedIns(pCB, pIns);
                                IInstruction * nop = NOP();
                                nop->AppendComment("Give up LOAD from competitive memory");
                                pIns->DirMoveTo(nop);
                                pIns->AsyncMoveTo(nop);
                                nop = pCB->Replace(pIns, nop);
                                delete nop;
                                pCB->Update();
                                return true;
                        }
                        // Does not preset
                        return false;
                    }

                    m_pSim->PresetMemory(true, 0, z, PSIZE, (rv & 0xffffffff));
                    if (PFETCHSIZE == 8)
                        m_pSim->PresetMemory(true, 0, z + PSIZE, PSIZE, (rv >> 32));
#if DBGMODE && 0
                    std::cout << pIns->GetCode() << "       => Preset address = 0x" << std::hex << z
                        << ", size=" << std::dec << PSIZE << ", val=0x" << std::hex << rv << std::endl;
#endif
                }
            }
        }
        return false; /* false = 補正[しない]*/
    }
	
	if (r.NeedIns()) {
		// GR補正
		std::vector< std::pair<UI32,UI32> > & v_gr = r.m_vGr;
		std::vector< std::pair<UI32,UI32> >::iterator itr;

        // ２レジスタを補正する場合、レジスタAの補正命令を生成、
		// レジスタBの補正命令を生成するときにAの値を使用してはならない。
		// Aの補正後AをpushしBの補正時にはpushされているものは使用しない
		UI32 exclude = 0;
		std::vector<IInstruction*> vPrevIns;

		for (itr = v_gr.begin(); itr != v_gr.end(); itr++) {
			if (itr->first == 0) {
				std::cout << "GiveUpRecovery_R0" << std::endl;
				if(itr->second != 0) {
					pIns->SetForcedAdjust(bForce);
					GiveUpRecovery_R0(pIns, &r); // r0を補正しようとした
				}
            } else {
                IInstruction* pNewIns = nullptr;
                UI32 accessMem = 0;
                // Get operand hold memory address
                IOperand* poprMem = nullptr;
                for (UI32 i = 0; i < pIns->GetOpNum(); i++) {
                    IValConstraint* pConst = pIns->opr(i)->GetConstraint();
                    if (pConst != nullptr) {
                        poprMem = pIns->opr(i);
                        if (pConst->GetType(IValConstraint::INUM) && poprMem->Idx() == itr->first) {
                            break;
                        }

                        UI32 disp = poprMem->GetDisp();
                        accessMem = itr->second + disp;
                        // TODO: 
                        if (pIns->GetMne() == "prepare" || pIns->GetMne() == "pushsp" || pIns->GetMne() == "resbank") {
                            accessMem--;
                        }
                        break;
                    }
                }

                if (accessMem != 0 && pIns->Behavior(IInstruction::STORE_MEMORY) == true
                    && g_prf->IsCompetitiveMem((MEMADDR)(accessMem)) == true) {

                    std::vector<IInstruction*> vNeedpIns;
                    if (CanStoreMem(pCB, pIns, accessMem) == true) {
                        if (pIns->GetInsNeed().size() == 0) {
                            PrepareValBeforeStore(pCB, pIns, itr->second, itr->first);
                            vNeedpIns = pIns->GetInsNeed();
                        } else {
                            vNeedpIns = pIns->GetInsNeed();
                        }
                        poprMem->RemoveConstraint();
                    } else {
                        ImprovingStoreCompetitive(pCB, pIns);
                        return true;
                    }
                    for (UI32 i = 0; i < vNeedpIns.size(); i++) {
                        pNewIns = vNeedpIns.at(i);
                        pIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
                        pNewIns->SetRegulationTarget(pIns);
                        pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                    }

                } else {
                    IInstruction* pNewIns = (pIns->InLoop() || bForce || pIns->GetId() == INS_ID_DISPOSE_R3) ?
                        MOV32(itr->second, itr->first) :
                        GenerateRegulatedInstructionGR32(0/*htid*/, itr->second, itr->first, exclude, &vPrevIns, pIns, pCB);

                    // NULL means adjusted by forwarding instruction. Do not need to adjust any more.
                    if (pNewIns != NULL) {
                        if (pNewIns->GetComment().size() == 0) {
                            pNewIns->AppendComment("Regulation code for ");
                            pNewIns->AppendComment(pIns->GetMne().c_str());
                        }
                        //Adjust for dispose instruction
                        if (pIns->GetId() == INS_ID_DISPOSE_R3) {
                            if (itr->first == pIns->opr(2)->Idx()) {
                                delete pNewIns;	// Re-create adjustment code
                                pNewIns = MOV32P(pIns->GetJumpTarget(), itr->first);
                                pIns->SetInsNeed(pNewIns);
                            }
                            pIns->AsyncMoveTo(pNewIns); // cover a case that FEINT changeing V machine occurs at dispose instruction (has register in list 12)
                        }
                        pNewIns->SetRegulationTarget(pIns);
                        if (pIns->GetId() != INS_ID_LOOP)	// Do not move _Loop label to above loop counter intialization
                            pIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
                        pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                    }
                }
            }
			exclude |= (1 << itr->first);
		}

		// WR補正
		std::vector< std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> > > & v_wr = r.m_vWr;
		std::vector< std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> > >::iterator itrwr;
		std::bitset<4> elm_flg;
		__uint128_t val = 0, cur_val = 0;

		IInstruction *pNewIns = nullptr;
		UI32 reg = 0, addrReg = 0;

		// Exclude loop counter register if current instruction belongs to a loop sequence.
		if(pIns->InLoop()) {
			UI32 idx = pCB->GetIndex(pIns);
			IInstruction *p = NULL;
			IInstruction *pLoop = NULL;
			while(idx < pCB->GetInstructionNum()) {
				p = pCB->at(idx);
				if(p->GetMne() == "loop") {
					pLoop = p;
                    exclude |= (1 << p->opr(0)->Idx());
					break;
				}
				idx++;
			}
			if(pLoop != NULL) {
				while(idx > 0) {
					p = pCB->at(idx - 1);
					if(p->InLoop() == false)
						break;
                    exclude |= p->GetConstraintBit();
					idx--;
				}
			}
		}
		
		// Randomize register for adjustment sequence.
		addrReg = 0;
		while(addrReg == 0){
			UI32 tmp = g_rnd.GetRange(4, 29);
			if((exclude & (1 << tmp)) == 0)
				addrReg = tmp;
		}

		// Set value for Wide Register
		for( itrwr = v_wr.begin(); itrwr != v_wr.end(); itrwr++ ){
			reg = itrwr->first;
			elm_flg = itrwr->second.first;
			val = itrwr->second.second;
			UI32 nWRMemPreset = g_wm->BASE_WR_PRESET + m_nWRMemOffset;
			
			//[FROG]TODO: Potential bug: when there are more than 8 WRs needed to be preset in loop, 
			// the memory will no enough. But the rate is rare.
			if((nWRMemPreset + 128 > g_wm->BASE_WORK_END) && (!pIns->InLoop())) {
				std::stringstream ss;
				std::string label;
				// Add a new WR memory preset block.
				m_nWRMemBlockCount++;
				m_bNewWRMemBlock = true;
                ss << GetPEContext();
				ss << "NMNT_wr_preset_memory_" << m_nWRMemBlockCount;
				ss >> label;
				pNewIns = MOV32P(label,11);
				pIns->DirMoveTo(pNewIns);// Directive MOVE for Label of Branch condition
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				pNewIns = JMP32(11);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			
				// Set return code after memory preset
				pNewIns = MOV32(g_rnd.Get(), 11);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
				pNewIns->SetLabel(label + "_ret");
				// Set return code after memory preset
				pNewIns = MOV32(g_rnd.Get(), 10);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				// Re-calculate memory address.
				m_nWRMemOffset = 0;
				nWRMemPreset = g_wm->BASE_WR_PRESET + m_nWRMemOffset;

			}

			// Get WR current value
			m_pSim->ReadWrReg(&cur_val, reg, 0);

			// Preset memory for WR. It will be recored and preset in _wr_preset_memory_
			for( UI32 elmnum = 0; elmnum < (sizeof(__uint128_t)/sizeof(UI32)); elmnum++ ){
				UI32 v = 0;
				if( elm_flg.test(elmnum) ) {
					v = (UI32)(( val >> (elmnum * 32)) & ((__uint128_t)0xffffffffUL ));
				} else {
					v = (UI32)(( cur_val >> (elmnum * 32)) & ((__uint128_t)0xffffffffUL ));
				}
				m_pSim->PresetMemory(true, 0, (nWRMemPreset + elmnum * 4), 4, v, true);
			}

			pNewIns = MOV32(nWRMemPreset, addrReg);
			pNewIns->SetRegulationTarget(pIns);
			pNewIns->AppendComment("Regulation code");
			pIns->DirMoveTo(pNewIns);// Directive MOVE for Label of Branch condition
			pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

			// Load adjustment value to wide register
			pNewIns = LDVQW(0, addrReg, reg);   
			pNewIns->SetRegulationTarget(pIns);
			pNewIns->AppendComment("Regulation code");
            pNewIns->SetInLoop(pIns->InLoop());
			pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns)); 

			m_nWRMemOffset += 16;
		}

		// ブロック情報の更新
		pCB->Update();
	}

	if(r.GiveUpRegulate()) {
		// If removed instruction is 2nd ins. of C2B1
		if(pIns->InSequence(IInstruction::IF_SEQ_C2B1) && pIns->GetC2B1Ins() == nullptr) {
			IInstruction *pPrevIns = pCB->at(pCB->GetIndex(pIns) - 1);
			pPrevIns->DelComment();
			pPrevIns->SetC2B1Ins(nullptr);
		}
		if(pIns->InSequence(IInstruction::IF_SEQ_FWD) && pIns->GetForwardIns() != nullptr) {
			IInstruction *p = pIns->GetForwardIns();
			if(pCB->GetHandlerAddress() != 0 && (p->Behavior(IInstruction::LOAD_MEMORY) || p->Behavior(IInstruction::STORE_MEMORY)))
				pCB->Remove(p);
		}

		IInstruction *p;
		if ((pIns->GetMne() == "dispose") && (pIns->Behavior(IInstruction::JMP))) {
			// Insert move instruction.
			p = MOV32P(pIns->GetJumpTarget(), pIns->opr(2)->Idx());
			p->AppendComment("Give-up regulation");
			pIns->DirMoveTo(p);
			pCB->AddOpeCode(p, pCB->GetIndex(pIns));

			// Insert jump instruction.
			p =  JMP32(pIns->opr(2)->Idx());
			p->AppendComment("Give-up regulation");
			pIns->AsyncMoveTo(p);
			pCB->AddOpeCode(p, pCB->GetIndex(pIns));

			// Remove dispose instruction.
			pCB->Remove(pIns);

		} else {
			p = NOP();
			p->AppendComment("Give-up regulation");
            p->SetInLoop(pIns->InLoop());
			pIns->DirMoveTo(p);
			pIns->AsyncMoveTo(p);
			PrepareDeletedIns(pCB, pIns);
			p = pCB->Replace(pIns, p);
			delete p;
		}
		pCB->Update();
	}
	
	/* r.m_result(そのまま実行可能ならば真) => 論理反転する */
	return true; 	
}

bool CSimulatorControl::IsNativeMode( void ) {
	UI32 psw = 0;
	m_pSim->ReadNcReg(&psw, 5, 0);
	return ((psw & 0x80000000)==0);
}

/**
* @brief Get whether the simulator is in guest operation. .
* @Returns true if guest operation is in progress.
*/
bool CSimulatorControl::IsGuestMode(void) {
    UI32 pswh = 0;
    m_pSim->ReadNcReg(&pswh, 15, 0);
    return ((pswh & 0x80000000) != 0);
}

/**
* @brief Get whether the simulator is in host operation. .
* @Returns true if host operation is in progress.
*/
bool CSimulatorControl::IsHostMode(void) {
    UI32 pswh = 0, hvcfg = 0;
    m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
    m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);

    if ((hvcfg & 0x1) != 0 && (pswh & 0x80000000) == 0) {
        return true;
    } else {
        return false;
    }
}

std::string CSimulatorControl::GetMContext() {
	std::stringstream ss;
	std::string strContext = GetPEContext() + "NM_";
	if(IsGuestMode() == true) {

        UI32 gmid = 0, pswh = 0;
        m_pSim->ReadNcReg(&pswh, 15, 0);
        gmid = (pswh >> 8) & 0x7;
        ss << GetPEContext() << "GM" << std::dec << std::setw(2) << std::setfill('0') << gmid;
		ss << '_';
	}
	ss >> strContext;
	return strContext;
}

std::string CSimulatorControl::GetTContext() {
    std::string strContext(GetPEContext() + "NMNT_");
    
    if (g_prf->IsConventionalMode() == false) {
        std::stringstream ss;
        UI32 gmid = 0, pswh = 0;
        m_pSim->ReadNcReg(&pswh, 15, 0);
        gmid = (pswh >> 8) & 0x7;
        ss << GetPEContext() << "GM" << std::dec << std::setw(2) << std::setfill('0') << gmid;
        ss << '_';

        ss >> strContext;
    }
	return strContext;
}

std::string CSimulatorControl::GetPEContext() {
    std::stringstream ss;
    UI32 PEID = 0;
    m_pSim->ReadSysRegister(&PEID, "PEID", 0);
    PEID &= 0x1F;

    ss << "frog_P" << std::dec << std::right << std::setw(2) << std::setfill('0') << PEID;

    return ss.str();
}

UI32 CSimulatorControl::GetTargetHandlerAddress(IExceptionConfig *pExp) {
	UI32 nHandlerAddress = pExp->m_addr;

	if (pExp->m_name == "EIINT") {
		UI32 pc, ebase, eiic;
		if(IsGuestMode()){
			m_pSim->ReadNcReg(&ebase, 19, 9);
			m_pSim->ReadNcReg(&eiic, 13, 9);
			m_pSim->ReadPC(&pc);
		} else {
            m_pSim->ReadNcReg(&ebase, 3, 1);
            m_pSim->ReadNcReg(&eiic, 13, 0);
            m_pSim->ReadPC(&pc);
		}

		// Direct vector method
		if(pc <= ebase + 0x1f0) {
			nHandlerAddress = pc - ebase;
		} else { // Reference table method
			nHandlerAddress += ((eiic & 0x0f) << 4);
			//[FROG]TODO: EITBL use NM handler
			nHandlerAddress |= 0x1;
		}
	} else if(pExp->m_name == "HVTRAP") {  // HVTRAP use NM handler
		nHandlerAddress |= 0x1;
	}

	nHandlerAddress |= IsNativeMode() ? 1 : 0;

	return nHandlerAddress;
	
}

UI32 CSimulatorControl::GetPSW( void ) {
	UI32 psw = 0, pswh = 0;
	m_pSim->ReadNcReg(&pswh, 15, 0);
	if ((pswh & 0x80000000) != 0) {
		m_pSim->ReadNcReg(&psw, 5, 9);	//GMPSW
	} else {
        m_pSim->ReadNcReg(&psw, 5, 0);  //PSW
    }
	return psw;
}

/**
 * @brief シミュレーションGiveUp時の動作をハンドリングする。 
 * @param pIns シミュレーションも補正も出来ない命令
 */
void CSimulatorControl::GiveUpRecovery_R0(IInstruction* pIns, IRegulation *Reg) {
	
	IOperand* popr = NULL;
	for (UI32 N = 0; N < pIns->GetOpNum(); N++) {
		if (pIns->opr(N)->IsGR() && (pIns->opr(N)->Idx() == 0)) {
			popr = pIns->opr(N);
			break;
		}
	}
	
	if (popr ==NULL) std::cout << __FUNCTION__ << ":" << pIns->GetCode() << std::endl;
	_ASSERT(popr);
	
	/* FPU倍精度：r0でも可能な制約に書き換える */
	BS_ICAT bcat;
	//bcat.set(IInstruction::ICAT_FPU_D);
	//if (pIns->GetCategory() & bcat.to_ulong()) {
	//	//UI32 r = g_rnd.Get() & 3;
	//	UI32 r = g_rnd.Get() & 0; //[FROG]TODO: Fix it
	//	switch (r) {
	//	case 0:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_ZERO));
	//		break;
	//	case 1:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::NEGATIVE_ZERO));
	//		break;
	//	case 2:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_INF));
	//		break;
	//	case 3:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_INF));
	//		break;
	//	default:
	//		break;
	//	}
	//	pIns->AppendComment(" GiveUp-r0 ");
	//}
	
	/* FPU単精度：r0でも可能な制約に書き換える */
	bcat.reset();
	bcat.set(IInstruction::ICAT_FPU_S);
	bcat.set(IInstruction::ICAT_FPU_D);
	if (pIns->GetCategory() & bcat.to_ulong()) {
		popr->RemoveConstraint();
		pIns->AppendComment(" GiveUp-r0 ");
	} else {
		//if a instruction which source register is r0. Infinite loop occur due to can not regulate r0
		Reg->GiveUp();
	}
	
	/* r0からrXへ命令を再構成する */
}


/**
 * @param	htid	Thread id
 * @param	targV	目標値
 * @param	reg		補正対象のレジスタインデックス
 * @param	exclude	使用禁止のレジスタ情報
 */
IInstruction* CSimulatorControl::GenerateRegulatedInstructionGR32(UI32 htid, UI32 targV, UI32 reg, UI32& ex, std::vector<IInstruction*>* vPrevIns, IInstruction* pIns, CCodeBlock* pcb) {
	IInstruction *pNewIns = nullptr;

	// Generate code for forwarding data instruction with dependent operand has constraint
	if(pIns->GetInsNeed().size() != 0){
		std::vector<IInstruction*> vIns = RegulateByForwardingIns(htid, targV, reg, ex, pIns, pcb);
		UI32 idx = pcb->GetIndex(pIns);
		while(vIns.size()) {
			pNewIns = vIns.back();

            if (g_mgr->GetMismatchReg() != 0 && pNewIns->Behavior(IInstruction::STORE_MEMORY)) {
                pNewIns->SetForcedAdjust(true);
            }

			pcb->AddOpeCode(pNewIns, idx);
			vIns.pop_back();
		}
		// Move direction to last inserted instruction.
		pIns->DirMoveTo(pNewIns);
		pcb->Update();
		return NULL;
	} else {
		// TODO: 補正するパターンが必要
		targV == 0 ? (pNewIns = MOVR(0, reg)) : pNewIns = MOV32(targV, reg);
	}
	return pNewIns;
}

std::vector<IInstruction*> CSimulatorControl::RegulateByForwardingIns(UI32 htid, UI32 targV, UI32 reg, UI32& ex, IInstruction* pIns, CCodeBlock* pcb) {
    std::vector<IInstruction*> vNewIns;
	std::vector<IInstruction *> &vNeededIns = pIns->GetInsNeed();
	IInstruction *pNeed = vNeededIns.back();
	IInstruction *pNewIns = NULL;
	UI32 valBuffer = 0;
	SI32 sValBuffer = 0;
	UI32 reuse = 0;
	UI32 nDisp = 0;
	UI32 rTemp = 0;
	auto CheckSignedRange = [] (SI32 val, UI32 bitsize) {
		SI32 min = (-1 * (1 << (bitsize - 1)));
		SI32 max = (1 << (bitsize - 1)) - 1;
		if(val >= min && val <= max)
			return true;
		return false;
	};
	//auto CheckUnSignedRange = [] (SI32 val, UI32 bitsize) {
	//	SI32 min = 0;
	//	SI32 max = (1 << bitsize) - 1;
	//	if(val >= min && val <= max)
	//		return true;
	//	return false;
	//};

	auto GenRandomRegister = [&pIns] (IInstruction *p, UI32 exclude_reg, UI32 mask) {
		std::vector<UI32> reglist;
        UI32 valid_reg = 0;
		// Mask used register of 2nd instruction in sequential jmp
		IInstruction * seqJmp = (pIns->GetSequentialIns().size() > 0 ? pIns->GetSequentialIns().back() : nullptr);
		if (seqJmp != nullptr) exclude_reg |= seqJmp->GetGrSrc();

        exclude_reg |= (p->GetGrSrc() | p->GetGrDst() | g_mgr->GetMismatchReg());        
        if (mask) {
            exclude_reg |= 0xAAAAAAAA;
            exclude_reg |= p->GetGrSrc() >> 1; // Support case Ins1: st.dw r24,0x1[r25] -- Ins 2: ld.dw 0x10[r25],r2 ==> Register r25 of ld.dw is overwrited by pair reg
        }

        valid_reg = ~exclude_reg;
        for (UI32 i = 1; i < 32; i++) {
            if ((valid_reg >> i) & 0x1) {
                reglist.push_back(i);
            }
        }

		std::random_shuffle(reglist.begin(), reglist.end(), g_rnd);
		if(reglist.size())
			return reglist[0];
		else
			return (g_rnd.GetRange(0, 31) & ~mask);	// This case may cause error, but never occur.
	};

	switch (pNeed->GetId())
	{
		case INS_ID_SATADD_I5:
		// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > 0x7FFFFFFF)
				break;

			sValBuffer = g_rnd.GetRange((SI32)-16, (SI32)15);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;
			// This case caused saturated result in SATADDI5
			if((SI32) valBuffer < 0 && sValBuffer < 0 && targV != 0x80000000) {
				break;
			}

			// R0 can not be set non-zero value
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADD_I5:
			sValBuffer = g_rnd.GetRange((SI32)-16, (SI32)15);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;

			// R0 can not be set non-zero value
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOVI5:
			if(!CheckSignedRange(targV, 5))
				break;
			pNeed->opr(0)->Replace(targV);
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOV:
			// R0 can not be set non-zero value
			if(pNeed->opr(0)->Idx() == 0 && targV != 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADDI_SI16:
			sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADD:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = targV - reuse;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SUB:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = reuse - targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SUBR:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = reuse + targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ANDI_I16:
			// This instruction will AND only 16 MLS bits
			if(!CheckSignedRange(targV, 16))
				break;

			if(pNeed->opr(1)->Idx() == 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->Replace(g_rnd.GetRange(0, 0xffff) | targV);
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_AND:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			valBuffer = g_rnd.GetRange((UI32)0, (UI32)0xffffffff) | targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ORI:
			if(pNeed->opr(1)->Idx() == 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));

			// Generate random value for immediate
			valBuffer = g_rnd.GetRange(0, 0xffff);
			valBuffer = valBuffer & targV;  // Keep bits whose value is 1
			pNeed->opr(0)->Replace(valBuffer);

			// Generate random value for operand register
			valBuffer = targV & ~valBuffer; // Get the remains bits that need to be 1
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_OR:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			// Generate random operands
			valBuffer = g_rnd.Get();
			valBuffer = valBuffer & targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(0, 0));

			valBuffer = targV & ~valBuffer;
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_HSH:
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_XOR:
			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = reuse ^ targV;
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_NOT:
			valBuffer = ~targV;
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATADD:
			// The result of SATADD can not exceed maximum positive (0x7fffffff)
			if(std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = (SI32)targV - (SI32)reuse;

			// The above expression caused overflow.
			if ((SI32) reuse < 0 && (SI32) valBuffer < 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = targV - reuse;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32) reuse < 0 && (SI32) valBuffer < 0)
					break;

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATADD_R3:
			// The result of SATADD can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32) 0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = targV - reuse;
			// This case will cause saturated result
			if ((SI32) reuse < 0 && (SI32) valBuffer < 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = targV - reuse;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32) reuse < 0 && (SI32) valBuffer < 0)
					break;

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(1)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUB_R3:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = targV + reuse;
			// The above expression caused overflow.
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = (SI32)reuse - (SI32)targV;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(1)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUB:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = (SI32)reuse + (SI32)targV;
			// This case will cause saturated result
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				// The result of this expression can not overfllow because both reuse and targV are positive.
				valBuffer = (SI32)reuse - (SI32)targV;
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUBI:
			// The result of SATSUBI can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > 0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			sValBuffer = reuse - targV;
			if(sValBuffer >= (SI32)-32768 && sValBuffer <= (SI32)32767) {
				pNeed->opr(0)->Replace(sValBuffer);
			} else {
				sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
				pNeed->opr(0)->Replace(sValBuffer);

				valBuffer = sValBuffer + targV;
				// The above expression caused overflow. It will cause saturated in SATSUB
				if((SI32)valBuffer < 0 && (SI32) sValBuffer > 0 && targV != 0x80000000)
					break;
				
				if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUBR:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(1)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = (SI32)reuse + (SI32)targV;
			// This case will cause saturated result
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
				// The result of this expression can not overfllow because both reuse and targV are positive.
				valBuffer = (SI32)reuse - (SI32)targV;
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOVEA:
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			sValBuffer = targV - reuse;
			// Out of range
			if(std::abs((SI64)sValBuffer) >= 0x7FFF && pNeed->opr(1)->Idx() == 0) {
                pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
                m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
                sValBuffer = targV - reuse;
			}
            if(std::abs((SI64)sValBuffer) >= 0x7FFF) {
                sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
				SI32 sNewVal = (SI32)targV - sValBuffer;
                if(pNeed->opr(1)->Idx() == 0 && sNewVal != 0)
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint((UI32)sNewVal, (UI32)sNewVal));
			}
			pNeed->opr(0)->Replace(sValBuffer);
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF); // LD.B fixed bit#0 of disp to 0
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB23(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
						
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BUD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BUD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB23(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
						
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_DW:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if((rTemp & ~0x1) == (pNeed->opr(0)->Idx() & ~0x1) || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0x1);
			pNewIns = STDW23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 8, 0, true));
			if(reg & 0x1)	// regulated register index is odd (in dest pair register)
				pNewIns->opr(0)->SetConstraint(new INumConstraint((UI64)targV << 32, (UI64)targV << 32));
			else
				pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LDL_W:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HSD23:
            {
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
            }
		case INS_ID_LD_HUD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HUD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_WSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_WSD23:
            {
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
            }
		case INS_ID_SLD_B:
			nDisp = g_rnd.GetRange(0, 0x3F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTB (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_BU:
			nDisp = g_rnd.GetRange(0, 0xF) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTB (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_H:
			nDisp = g_rnd.GetRange(0, 0x7F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTH (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_HU:
			nDisp = g_rnd.GetRange(0, 0x1F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTH (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_W:
			nDisp = g_rnd.GetRange(0, 0x3F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTW (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
		case INS_ID_LD_B_INC:
		case INS_ID_LD_B_DEC:
		case INS_ID_LD_BU_INC:
		case INS_ID_LD_BU_DEC:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_H_INC:
		case INS_ID_LD_H_DEC:
		case INS_ID_LD_HU_INC:
		case INS_ID_LD_HU_DEC:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_W_INC:
		case INS_ID_LD_W_DEC:
		case INS_ID_LDL_BU:
		case INS_ID_LDL_HU:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4, 0, true));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
			
		default:
			break;
	}

	//[FROG]TODO: What do FROG do if instruction was passed already?
	// Can not generate forwarding couple
	if(vNewIns.size() == 0 && pIns->GetId() != INS_ID_JMP && pIns->GetId() != INS_ID_JARL) {
		delete pNeed;
		pNewIns = MOV32(targV, reg);
		if(!pIns->InSequence(IInstruction::IF_SEQ_C2B1))
			pNewIns->SetForwardIns(pIns);
		pNewIns->SetSequence(IInstruction::IF_SEQ_FWD);
		pNewIns->AppendComment("Forwarding Data instruction");
		vNewIns.push_back(pNewIns);
	} else {
        // Move async. event label to new instruction by ratio 50:50
        if(g_rnd.Get() & 0x1) {
            pIns->AsyncMoveTo(pNeed);
        }
    }
	if(pcb->GetHandlerAddress() != 0) {
		std::for_each(vNewIns.begin(), vNewIns.end(), [](IInstruction *p) { p->SetForcedAdjust(true); });
	}
	pIns->ClearInsNeed();

	return vNewIns;
}

bool CSimulatorControl::Step(UI32 htid, UI32 lpc, UI32 ppc, IInstruction* pIns, ISimulatorStepResp * res) {
	_ASSERT(pIns);
	
	UI64 opecode	= pIns->Fetch();
	UI32 inslen		= pIns->GetLen();
	UI64 addrL1		= 0;
	UI64 sizeL1		= 0;
	UI64 addrL2		= 0;
	UI64 sizeL2		= 0;
	
	if (m_pSim->MmuTransferAddr(true, 0, lpc, inslen, MXU_ACC_FETCH, &addrL1, &sizeL1, &addrL2, &sizeL2) != true) {
		return false;
	}
	
	_ASSERT(inslen == (sizeL1 + sizeL2));
	
	if (sizeL2 != 0) {
		/* 実際はバイトアクセスされる */
		UI64	splitOpecode = 0;
		UI8*	splitPos = ((UI8*)&opecode) + sizeL1;
		memcpy((void*)&splitOpecode, (void*)splitPos, sizeL2); 
		memset((void*)splitPos, 0, sizeL2);
		if (m_pSim->WriteMemory(addrL2, sizeL2, splitOpecode)!=true) {
			return false;
		}
	}
	
	if (m_pSim->WriteMemory(addrL1, sizeL1, opecode) != true) {
		return false;
	}

	pIns->m_pswb = GetPSW();
	bool ret  = m_pSim->Step(htid, lpc, res);
	pIns->m_pswa = GetPSW();
	return ret;
}


bool CSimulatorControl::DecodeAddress(UI32 L, UI32* PL, UI32* PP) {
	_ASSERT(PP);
	
	UI64 physical = 0;
	if (m_pSim->MmuTransferAddr(true, 0, L, 1, MXU_ACC_DONTCARE, &physical, NULL, NULL, NULL) != true) {
		return false;
	}
	*PL = L;
	*PP = (UI32)physical;
	return true;
}


bool CSimulatorControl::RecalcAbsoluteAddress(IInstruction* pIns) {
	UI32 opNum = pIns->GetOpNum();
	IOperand* popr = nullptr;
	
	for (UI32 i = 0; i < opNum; i++) {
		popr = pIns->opr(i);
		if (popr->GetLabel() != NULL) {
			if (popr->Attr(IOperand::OPR_ATTR_RLABEL)!=true) {
				MSG_ERROR(0,"YY %s : opr(%d) %s (ALABEL) = 0x%08X\n", pIns->GetCode().data(), i, popr->GetLabel(), (UI32)(*popr));
			}else{
				MSG_INFO (0,"YY %s : opr(%d) %s (ALABEL) = 0x%08X\n", pIns->GetCode().data(), i, popr->GetLabel(), (UI32)(*popr));
			} 			
		}	
	}
	return false;
}

/**
 * @brief ブレークポイントの設定と種別選択処理
 */
UI32 CSimulatorControl::GenerateBreakPointBeforeSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk) {
	UI32 num_of_channels = g_exp->GetNumOfChannels();
	UI32 break_point_weight = g_exp->GetBreakPointWeight(); // ブレークポイント生成比率取得
	IBreakParam bparam;
    UI32 break_type = IBreakParam::BREAK_NONE;
    UI32 range = 0;
    std::stringstream ss;
    std::string bp_label;
	UI32 gpid = 0;
	if(g_cfg->m_mGMs.size() > 1) {
		UI32 pswh = 0;
		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		gpid = (pswh >> 8) & 0x7;
	}
	if(( break_point_weight != 0 ) && ( pIns->GetId() != INS_ID_DBT ) ) {
		range = g_rnd.GetRange(1,100);
		if( break_point_weight >= range ) { // ブレークポイントを生成する
			// ブレークポイントの種別選択
            bparam = IBreakParam();
            break_type = bparam.m_type = g_exp->GetBreakType();
            bparam.m_block_num = std::atoi(pBlk->GetName().c_str() + 15);
            bparam.m_block_label = pBlk->GetLabel();
#if DBGMODE
                std::fprintf(stdout,"==> GetBreakType:%d\n",break_type);
#endif

            // ブレークポイントの生成時点での登録
            switch( break_type ) {
            case IBreakParam::BREAK_PCB :
				if (p->pBreakParam[gpid].size() < num_of_channels){
					ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam[gpid].size();
					ss >> bp_label;
					ss.str(""); ss.clear(std::stringstream::goodbit);
					pIns->SetLabel(bp_label);
					bparam.m_addr_label = bp_label;
					bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
					bparam.m_addr_mask = 0x0;
					bparam.m_data = 0x0;
					bparam.m_data_mask = 0x0;
					p->pBreakParam[gpid].push_back(bparam);
#if DBGMODE
                std::fprintf(stdout,"==> Create BreakParam for BREAK_PCB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;

            case IBreakParam::BREAK_LDB :
                if(pIns->Behavior(IInstruction::LOAD_MEMORY) & (! pIns->Behavior(IInstruction::STORE_MEMORY))&&(p->pBreakParam[gpid].size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam[gpid].size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam[gpid].push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_LDB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_SDB :
                if(pIns->Behavior(IInstruction::STORE_MEMORY) & (! pIns->Behavior(IInstruction::LOAD_MEMORY))&&(p->pBreakParam[gpid].size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam[gpid].size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam[gpid].push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_SDB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_RMWB :
                if((pIns->Behavior(IInstruction::STORE_MEMORY)) && (pIns->Behavior(IInstruction::LOAD_MEMORY))&&(p->pBreakParam[gpid].size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam[gpid].size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam[gpid].push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_RMWB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_LSAB :
                if(((pIns->Behavior(IInstruction::STORE_MEMORY)) || (pIns->Behavior(IInstruction::LOAD_MEMORY)) || (pIns->GetException().first != 0 /*EITBL*/))
					&&(p->pBreakParam[gpid].size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam[gpid].size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam[gpid].push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_LSAB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;

			    case IBreakParam::BREAK_SS :
                if(( ! pIns->InLoop()) && (!pIns->InSequence()) ) {
                    // SS(SingleStep)用情報生成
                    ss << pBlk->GetLabel() << "_db_" << p->pNotBreakParam[gpid].size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); DBTRAP命令にラベルを貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pNotBreakParam[gpid].push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_SS on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;

            case IBreakParam::BREAK_AE :
				{
				UI32 indId = pIns->GetId();
                // Break_AEの場合、対象命令がDISPOSE,PREPARE,POPSP,PUSHSP命令であること
                if(((indId == INS_ID_DISPOSE) || (indId == INS_ID_DISPOSE_R3) || ((indId >= INS_ID_POPSP) && (indId <= INS_ID_PUSHSP)) 
					|| (indId >= INS_ID_STM_GSR && indId <= INS_ID_LDM_MP)) && (!pIns->InSequence())) {
                    ss << pBlk->GetLabel() << "_db_" << p->pNotBreakParam[gpid].size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    pIns->SetLabel(bp_label);
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pNotBreakParam[gpid].push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_AE on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
				}
            case IBreakParam::BREAK_RLB :
                if( p->pBreakParam[gpid].size() > 0 ) {
                    pBlk->m_bRLB = true;
#if DBGMODE
                    std::fprintf(stdout,"==> Set Block.m_bRLB = 1 for BREAK_RLB\n");
#endif
                    break_type = IBreakParam::BREAK_NONE; // RLBの場合、BreakParamには登録しない
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }

                break;
            default:
                break_type = IBreakParam::BREAK_NONE; // ブレークポイントを生成しない
            }
        }
    }
#if DBGMODE
    fprintf(stdout,"==> Generate Break Type: %d break_point_weight:%3d range:%3d Pins:%3d %s\n",break_type,break_point_weight,range,pIns->GetId(),pIns->GetCode().c_str());
#endif
    return break_type;
}

/**
 * @brief ブレークポイント情報の生成処理
 */
void CSimulatorControl::GenerateBreakPointSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk) {
	UI32 access_type = 0;
	UI64 address = 0;
	UI32 size = 0;
	UI64 value = 0;
    std::stringstream ss;
    std::string bp_label;
	IBreakParam bparam;
	UI32 num_of_channels = g_exp->GetNumOfChannels();

    UI32 break_type = 0;
    UI32 block_num = 0;
    std::string block_label;
	UI32 gpid = 0;
	if(g_cfg->m_mGMs.size() > 1) {
		UI32 pswh = 0;
		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		gpid = (pswh >> 8) & 0x7;
	}
    if(p->pBreakParam[gpid].size())
    // ブレークポイントの種別毎に情報を生成する
    switch( p->pBreakParam[gpid].back().m_type ) {
    case IBreakParam::BREAK_PCB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_PCB\n");
#endif
        break;

    case IBreakParam::BREAK_LDB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_LDB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }  
		}
#endif
		m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 0, (UI32)m_pSim->SizeMemAccessLog() - 1));
		m_pSim->EachMemAccessLog( access_type, address, size, value );
        if( p->pBreakParam[gpid].back().m_addr_label == "" ) {
            p->pBreakParam[gpid].back().m_addr = address;
        }
        p->pBreakParam[gpid].back().m_data = value;
        p->pBreakParam[gpid].back().m_data_size = size;
        
        switch( size ) {
        case 1:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        case 8: // Double Word Access
            if( p->pBreakParam[gpid].size() <= num_of_channels ) {
                p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
                bp_label = p->pBreakParam[gpid].back().m_addr_label;
                break_type = p->pBreakParam[gpid].back().m_type;
                block_num = p->pBreakParam[gpid].back().m_block_num;
                block_label = p->pBreakParam[gpid].back().m_block_label;
                bparam = IBreakParam();
                bparam.m_type = break_type;
                bparam.m_block_num = block_num;
                bparam.m_block_label = block_label;
                bparam.m_addr_label = bp_label;
                bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                bparam.m_data = (UI32)(value >> 32); // high value
                bparam.m_data_mask = 0x00000000;
                bparam.m_data_size = 0;
                p->pBreakParam[gpid].push_back(bparam);
            } else {
                p->pBreakParam[gpid].pop_back();
            }
            break;
        default:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        if( size == 8 ) {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_addr,p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_addr_mask,p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_data,p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_data_mask);
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].back().m_addr,p->pBreakParam[gpid].back().m_addr_mask,p->pBreakParam[gpid].back().m_data,p->pBreakParam[gpid].back().m_data_mask);
        } else {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].back().m_addr,p->pBreakParam[gpid].back().m_addr_mask,p->pBreakParam[gpid].back().m_data,p->pBreakParam[gpid].back().m_data_mask);
        }
#endif
        break;
    case IBreakParam::BREAK_SDB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_SDB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }
        }
#endif
		m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 0, (UI32)m_pSim->SizeMemAccessLog() - 1));
		m_pSim->EachMemAccessLog( access_type, address, size, value );
        p->pBreakParam[gpid].back().m_addr = address;
        p->pBreakParam[gpid].back().m_data = value;
        p->pBreakParam[gpid].back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        case 8: // Double Word Access
            if( p->pBreakParam[gpid].size() <= num_of_channels ) {
                p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
                bp_label = p->pBreakParam[gpid].back().m_addr_label;
                break_type = p->pBreakParam[gpid].back().m_type;
                block_num = p->pBreakParam[gpid].back().m_block_num;
                block_label = p->pBreakParam[gpid].back().m_block_label;
                bparam = IBreakParam();
                bparam.m_type = break_type;
                bparam.m_block_num = block_num;
                bparam.m_block_label = block_label;
                bparam.m_addr_label = bp_label;
                bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                bparam.m_data = (UI32)(value >> 32); // high value
                bparam.m_data_mask = 0x00000000;
                bparam.m_data_size = 0;
                p->pBreakParam[gpid].push_back(bparam);
            } else {
                p->pBreakParam[gpid].pop_back();
            }
            break;
        default:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        if( size == 8 ) {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_addr,p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_addr_mask,p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_data,p->pBreakParam[gpid].at(p->pBreakParam[gpid].size()-2).m_data_mask);
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].back().m_addr,p->pBreakParam[gpid].back().m_addr_mask,p->pBreakParam[gpid].back().m_data,p->pBreakParam[gpid].back().m_data_mask);
        } else {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].back().m_addr,p->pBreakParam[gpid].back().m_addr_mask,p->pBreakParam[gpid].back().m_data,p->pBreakParam[gpid].back().m_data_mask);
        }
#endif
        break;
    case IBreakParam::BREAK_RMWB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_RMWB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }  
		} 
#endif
		m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 0, (UI32)m_pSim->SizeMemAccessLog() - 1));
		m_pSim->EachMemAccessLog( access_type, address, size, value );
        p->pBreakParam[gpid].back().m_addr = address;
        p->pBreakParam[gpid].back().m_data = value;
        p->pBreakParam[gpid].back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        default:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].back().m_addr,p->pBreakParam[gpid].back().m_addr_mask,p->pBreakParam[gpid].back().m_data,p->pBreakParam[gpid].back().m_data_mask);
#endif
        break;
    case IBreakParam::BREAK_LSAB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_LSAB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }  
		}
#endif
		if(m_pSim->SizeMemAccessLog() > 1) {
			m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 1, (UI32)m_pSim->SizeMemAccessLog() - 1));
			m_pSim->EachMemAccessLog( access_type, address, size, value );
		} else {
			std::vector<MEMRANGE> vMem;
			if(pIns->GetException().first == 0x1c) { // SYSERR at autosave
				UI32 rbip, intbp, channel, rbcr0;
				rbip = intbp = channel = 0;
                m_pSim->ReadNcReg(&rbip, 18, 2);
                m_pSim->ReadNcReg(&rbcr0, 15, 2);
				if(IsGuestMode()) {
					m_pSim->ReadNcReg(&intbp, 20, 9);    // GMINTBP
				} else {
                    m_pSim->ReadNcReg(&intbp, 4, 1);
				}
				UI32 n = 0;
				IDirective *pDir = nullptr;
				while((pDir = pIns->GetDirective(n)) != nullptr) {
					CAsyncLabel* pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAsyncLabel != NULL && (pAsyncLabel->m_name == "eitbl" || pAsyncLabel->m_name == "gmeitbl")) {
						channel = pAsyncLabel->m_channel;
						break;
					}
					n++;
				}
				UI32 start, end;
				UI32 bank_size = ((rbcr0 >> 16) & 0x1) ? 0x90 : 0x60;
				start = end = intbp + 4 * channel;
				vMem.push_back(MEMRANGE(start, end));
				start = end = rbip;
				vMem.push_back(MEMRANGE(start, end));
				start = end = rbip;
				start = end = rbip - bank_size * 14;
				vMem.push_back(MEMRANGE(start, end));
				start = end = rbip - bank_size * 15;
				vMem.push_back(MEMRANGE(start, end));

				// Randomize order of vMem
				std::random_shuffle(vMem.begin(), vMem.end(), g_rnd);
				address = g_rnd.GetRange(vMem[0].first, vMem[0].second);
				size = 4;
				value = g_rnd.Get();
            } else {
                p->pBreakParam[gpid].pop_back();
                break;
            }
		}
        p->pBreakParam[gpid].back().m_addr = address;
        p->pBreakParam[gpid].back().m_data = value;
        p->pBreakParam[gpid].back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam[gpid].back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        default:
            p->pBreakParam[gpid].back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam[gpid].back().m_addr,p->pBreakParam[gpid].back().m_addr_mask,p->pBreakParam[gpid].back().m_data,p->pBreakParam[gpid].back().m_data_mask);
#endif
        break;

    default:
        // 到達しないはず
        break;
    }
    
}


void CSimulatorControl::GenerateBreakPointSetupBlock(IBlockSimParam* bsp) {
    std::vector<INode*>&    vHB = g_asf->GetPreloadBlock();
    std::string labelStr("");
    std::string labelStr2("");
    std::string labelSS("");
    std::string block_label("");
    std::stringstream ss;
    UI32 ins_cnt = 0;
    UI32 tmpR = g_mgr->GetHandlerWorkReg();
    UI32 tmpC = tmpR + 1; // DBPC - 2
    UI32 tmpD = tmpR + 2;
    UI32 dir1 = tmpR + 3;
    IInstruction* pIns;
    UI32 csl;
    CCodeBlock* pHB = nullptr;
    UI32 bpc;
    UI32 addr_mask;
    UI32 data_mask;
    UI32 rbsel;
	CCodeBlock*		pBlk	= bsp->pCodeBlock;
	UI32 SQ0 = 0;
	UI32 SQ1 = 0;
	UI32 gpid = 0;
	if(g_cfg->m_mGMs.size() > 1) {
		UI32 pswh = 0;
		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		gpid = (pswh & 0x700) >> 8;
	}
	g_exp->GetChannelInSequential(&SQ0, &SQ1);
	static std::string sRetLabel[8] = {"", "", "", "", "", "", "", ""};
	std::string debugBlock ;
	std::stringstream ss1;
	 if (g_cfg->m_mGMs.size()){
		ss1 << "GM0" << gpid << "_debug_breaksetup";
	} else	{
		ss1 <<"debug_breaksetup";
	}
	ss1 >> debugBlock;
    for( std::vector<INode*>::iterator itr = vHB.begin(); itr != vHB.end(); itr++ ) {
        pHB = static_cast<CCodeBlock*>(*itr);
		
        // ブレークハンドラの挿入位置を見つける
        if( pHB->GetName() == debugBlock) {
            if (bsp->pBreakParam[gpid].size()) {           
                block_label = bsp->pBreakParam[gpid].front().m_block_label.c_str();
                if (bsp->pBreakParam[gpid].front().m_addr == 0xff) {
                    bsp->pBreakParam[gpid].clear();
                }
            } else {
                block_label = bsp->pNotBreakParam[gpid].front().m_block_label.c_str();
            }
			pHB->FreeAddress();

            ss << block_label << "_breaknext";
            ss >> labelStr;
            ss.str(""); ss.clear(std::stringstream::goodbit);

			for (UI32 i = 0; i < pHB->GetInstructionNum(); i++) {
				IInstruction* pTmp = pHB->at(i);
				if (pTmp->GetLabel().find("_entry") != std::string::npos) {
					ins_cnt= i;
					break;
				}
			}

			if (ins_cnt == 0) {
				UI32 addr = g_wm->DBTRAP_PC_INDEX + (gpid * 2044);
				std::string sEntrLabel = pHB->GetLabel() + "_entry";
				pIns = MOV32(addr, tmpR);//Get Index'address
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = LDW16(0,tmpR,tmpD);	//Load index to reg1
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = ADD5(4, tmpD);
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = STW16(tmpD,0,tmpR); //update the index value
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = LDW16(0,tmpD,tmpR);	//Using tmpD as index to entry value
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = MOV32P(sEntrLabel, tmpD);	//Using tmpD as index to loadPC
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = ADD(tmpD, tmpR);
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = JMP32(tmpR);	//Jump to the suitable entry
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = JR22P(labelStr);
				pIns->SetLabel(sEntrLabel);
				pHB->AddOpeCode(pIns, ins_cnt++);
				sRetLabel[gpid] = labelStr;
			} else {
				for (UI32 i = ins_cnt; i < pHB->GetInstructionNum(); i++) {
					IInstruction* pTmp = pHB->at(i);
					if (pTmp->GetId() != INS_ID_JRSD22) {
						ins_cnt= i;
						break;
					}
				}
				pIns = JR22P(labelStr);
				pHB->AddOpeCode(pIns, ins_cnt++);
			}

             // チャネルループの初期化とブレークイネーブルを設定する
            pIns = STSR( 21, dir1, 3 );               // Get DIR1
            pHB->AddOpeCode(pIns, ins_cnt++);
            pIns = MOV32( 0xffffff09, tmpR );		  // Clear bit DIR1.SQ0, DIR1.SQ1
            pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = AND( tmpR, dir1 );                 // DIR1.CSL, SQ0, SQ1 clear
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = ORI( 1, dir1, dir1 );              // DIR1.BEN set
			pHB->AddOpeCode(pIns, ins_cnt++);

			if(SQ0 == Code_Ch_DIR1_SQ0){
				pIns = ORI( 0x2, dir1, dir1 );				// DIR1.SQ0 set
				pIns->AppendComment("for Sequential Break Channel 0-1");
				pHB->AddOpeCode(pIns, ins_cnt++);
			}
			if(SQ1 == Code_Ch_DIR1_SQ1){
				pIns = ORI( 0x4, dir1, dir1 ); 
				pIns->AppendComment("for Sequential Break Channel 2-3");
				pHB->AddOpeCode(pIns, ins_cnt++);			// DIR1.SQ1 set
			}

            csl = 0;
			for( std::vector<IBreakParam >::iterator itr = bsp->pNotBreakParam[gpid].begin(); itr != bsp->pNotBreakParam[gpid].end(); itr++ ) {

				if((*itr).m_type == IBreakParam::BREAK_AE) { // DIR0.AEEの設定はコードブロックで１回のみで良い
					pIns = STSR( 20, tmpR, 3 );              // get DIR0(tmpR)
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = MOV32( 0xfffffdff, tmpD );        // set mask(tmpD)
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = AND( tmpD, tmpR );
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = ORI( 0x200, tmpR, tmpR );
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = LDSR( tmpR, 20, 3 );              // set DIR0.AEE=1
					pHB->AddOpeCode( pIns, ins_cnt++ );
				}
			}

            for( std::vector<IBreakParam >::iterator itr = bsp->pBreakParam[gpid].begin(); itr != bsp->pBreakParam[gpid].end(); itr++ ) {
                pIns = ORI( csl, dir1, tmpR);
                pHB->AddOpeCode(pIns, ins_cnt++);
                pIns = LDSR( tmpR, 21, 3);   //set DIR1.CSL
                pHB->AddOpeCode(pIns, ins_cnt++);

                if( pBlk->m_bRLB ){ // 他のチャネル登録がある時、リレー設定（RLB）の設定も必要ならば、
                    rbsel = 0x0;
                    // RBVE
                    rbsel |= g_rnd.GetRange(0,1) << 14;
                    // RBVSEL
                    rbsel |= ( 0x1 << g_rnd.GetRange(0,7) ) << 24;
					 // Enable RBCF in single core
					if((g_cfg->m_vPeId.size() <= 1) && (g_cfg->m_nPeWorkIdx == 0))
						rbsel |= 0x1 << 13;
                    // RBCE
                    rbsel |= g_rnd.GetRange(0,1) << 12;
                    // RBCSEL
                    rbsel |= ( 0x1 << g_rnd.GetRange(0,6) ) << 16;

                    pIns = STSR(  20, tmpR, 3 );                // Get DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32( 0x0000AFFF, tmpC );           // clear RBVSEL,RBCSEL,RBVE,RBCE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = AND( tmpC, tmpR );
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32( rbsel, tmpC );                // set RBVSEL,RBCSEL,RBVE,RBCE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = OR( tmpC, tmpR );
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR, 20, 3 );                 // set DIR0
                    pIns->AppendComment(" for Break_RLB ");
                    pHB->AddOpeCode(pIns, ins_cnt++);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_RLB DIR0:%08x\n",rbsel);
#endif                    
                }
				if(g_rnd.GetRange(1, 100) > 50){
					if(((SQ0 == Code_Ch_DIR1_SQ0) && (csl == 0))||((SQ1 == Code_Ch_DIR1_SQ1) && (csl == 32))){
						pIns = STSR( 22, tmpR, 3 );
						pHB->AddOpeCode(pIns, ins_cnt++);
						pIns = ORI( 0x20, tmpR, tmpR );
						pHB->AddOpeCode(pIns, ins_cnt++);
						pIns = LDSR( tmpR, 22, 3 );					// BPC.EO set
						pHB->AddOpeCode(pIns, ins_cnt++);
						csl += 16;
						continue;
					}
				}
				
				g_exp->SetChannel(&bpc, &addr_mask, &data_mask);

                // ブレーク例外種別毎にチャネルを設定する
                switch( (*itr).m_type ) {
                case IBreakParam::BREAK_PCB :
                    
                    bpc &= 0xFFFFFFFC; // WE=0,RE=0

                    pIns = MOV32( bpc, tmpR );     
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );                 // set BPC for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = MOV32P( (*itr).m_addr_label, tmpR ); // value of PC
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );                 // set BPAV for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = MOV32( addr_mask, tmpR );     
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );                 // set BPAM for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    break;

                case IBreakParam::BREAK_LDB :
                    
                    if( (*itr).m_data_size == 0 ) { // double word
                        bpc = 0x00000000;
                    } else {
#if DBGMODE
                        bpc = 0x10001019;
#else
                        bpc &= 0xfffffffb; // FE=0
#endif
                    }
                    data_mask |= (*itr).m_data_mask;
#if DBGMODE
                    addr_mask = 0xffffffff;
                    data_mask = 0xffffff00;
#endif
                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    if( (*itr).m_addr_label != "" ) {
                        pIns = MOV32P( (*itr).m_addr_label, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                        pIns = ADDI( (*itr).m_addr, tmpR, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                    } else {
                        pIns = MOV32( (*itr).m_addr, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                    }
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_SDB :
                    
                    if( (*itr).m_data_size == 0 ) { // double word
                        bpc = 0x00000000;
                    } else {
#if DBGMODE
                        bpc = 0x1000101a;
#else
                        bpc &= 0xfffffffb; // FE=0
#endif                        
                    }
                    data_mask |= (*itr).m_data_mask;
#if DBGMODE
                    addr_mask = 0xffffffff;
                    data_mask = 0xffffff00;
#endif
                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_RMWB :
                   
                    bpc &= 0xfffffffb; // FE=0
                    data_mask |= (*itr).m_data_mask;

                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_LSAB :
                    bpc &= 0xfffffffb; // FE=0
                    data_mask |= (*itr).m_data_mask;

                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );

#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x\n",bpc,(*itr).m_addr,addr_mask);
#endif
						break;
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;

                }
                csl += 16;
            }
            // Next Block

			pIns = JR22P(sRetLabel[gpid]);
			pHB->AddOpeCode(pIns, ins_cnt++);

            pIns = NOP()->SetLabel(labelStr);
            pHB->AddOpeCode(pIns, ins_cnt++);
            for( std::vector<IBreakParam >::iterator itr = bsp->pNotBreakParam[gpid].begin(); itr != bsp->pNotBreakParam[gpid].end(); itr++ ) {
                labelStr2 = (*itr).m_addr_label + "_setpsw";
                if( (*itr).m_type == IBreakParam::BREAK_SS ) {
                    pIns = STSR( 18, tmpD, 3 );                 // Get DBPC
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32P( (*itr).m_addr_label, tmpR);  // value of SS's dbtrap
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ADDI( 2, tmpR, tmpR );               // dbtrap address + 2
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = CMPR( tmpR, tmpD );                  // Are you SingleStep's dbtrap?
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = BNE17P( labelStr2 );                  // if no then skip
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = STSR(  20, tmpR, 3 );                // Get DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ORI( 0x0010, tmpR, tmpR );           // set SSE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR, 20, 3 );                 // set DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = STSR(  19, tmpR, 3 );                 // Get DBPSW
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ORI( 0x0800, tmpR, tmpR );           // set SS bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR,  19, 3);                  //set DBPSW
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = NOP()->SetLabel(labelStr2);
                    pHB->AddOpeCode(pIns, ins_cnt++);
                }
            }
        }
    }
    bsp->pBreakParam[gpid].clear();
	bsp->pNotBreakParam[gpid].clear();
}

bool CSimulatorControl::CheckAcceptanceCond(UI32 intId, UI32 priority) {

	bool bAccepted = true;
	switch (intId) {

	case IException::EXP_SYSERR:
		break;

	case IException::EXP_DBNMI://No condition
		break;

	case IException::EXP_FENMI:
	case IException::EXP_DBINT:
		{
			UI32 dir0 = 0;
			m_pSim->ReadNcReg(&dir0, 20, 3);
			bAccepted = !(dir0 & 0x1);
			break;
		}

	case IException::EXP_FEINT:
		{
			UI32 psw = 0, dir0 = 0;
			m_pSim->ReadNcReg(&dir0, 20, 3);
			m_pSim->ReadNcReg(&psw, 5, 0);
			bAccepted = !((psw & 0x80) | (dir0 & 0x1));
			break;
		}

	case IException::EXP_GMFEINT:
		{
			UI32 hvcfg = 0, pswh = 0;
			m_pSim->ReadNcReg(&hvcfg, 16, 1);
			m_pSim->ReadNcReg(&pswh, 15, 0);
			if ((hvcfg & 0x1) == 0 || (pswh >> 31) == 0) {
				bAccepted = false;
                break;
			}
			UI32 gmpsw = 0, dir0 = 0;
			m_pSim->ReadNcReg(&dir0, 20, 3);
			m_pSim->ReadNcReg(&gmpsw, 5, 9);
			bAccepted = !((gmpsw & 0x80) | (dir0 & 0x1));
			break;
		}

	case IException::EXP_BGFEINT:
		{
			UI32 psw = 0, gmpsw = 0, dir0 = 0;
			m_pSim->ReadNcReg(&dir0, 20, 3);
			m_pSim->ReadNcReg(&gmpsw, 5, 9);
			m_pSim->ReadNcReg(&psw, 5, 0);
			UI32 hvcfg = 0, pswh = 0;
			m_pSim->ReadNcReg(&hvcfg, 16, 1);	//HVCFG
			m_pSim->ReadNcReg(&pswh, 15, 0);	//PSWH
			if ((hvcfg & 0x1) == 0 || (pswh >> 31) == 0) {
				bAccepted = false;
                break;
			}
			// PSW.ID and PSW.NP = 0, DIR0_DM = 0, GMPSW.NP = 0
			bAccepted = !((psw & 0xa0) | (dir0 & 0x1) | (gmpsw & 0x80));					
			break;
		}
    case IException::EXP_RBINT:
	case IException::EXP_EITBL:
	case IException::EXP_EIINT:
		{
			UI32 psw = 0, plmr = 0, dir0 = 0, ispr = 0, intcfg = 0, intcfg_epl = 0;
			m_pSim->ReadNcReg(&dir0, 20, 3);
			m_pSim->ReadNcReg(&plmr, 14, 2);    //PLMR
			m_pSim->ReadNcReg(&psw, 5, 0);	    //PSW
			m_pSim->ReadNcReg(&intcfg, 13, 2);  //INTCFG
			m_pSim->ReadNcReg(&ispr, 10, 2);    //ISPR
			intcfg_epl = (intcfg & 0x2) >> 0x1;
			// PSW.ID and PSW.NP = 0, PLMR.PLM is masked
			if(((psw & 0xa0) != 0) || ((plmr & 0xFF) <= priority) || ((dir0 & 0x1) != 0)) {
				bAccepted = false;
                break;
			}
			//G4MH20 specs v1.07 section 3.1. New checking when INTCFG.EPL 
			if(intcfg_epl == 0x1)	{// PSW.EIMASK <= priority
				UI32 psw_eimask = (psw >> 20) & 0x0ff;
				if (psw_eimask <= priority) {
					bAccepted = false;
                    break;
				}
			} else {// Checking ISPR
				priority = (priority > 15 ? 15 : priority);
				UI32 ispr_msk = (ispr & 0x0ffff) & (0x0ffff >> (15 - priority));
				if (ispr_msk != 0) {
					bAccepted = false;
                    break;
				}
			}
			break;
		}
    case IException::EXP_GMRBINT:
	case IException::EXP_GMEIINT:
	case IException::EXP_GMEITBL:
		{
			UI32 gmpsw = 0, gmplmr = 0, dir0 = 0;
			m_pSim->ReadNcReg(&dir0, 20, 3);
			m_pSim->ReadNcReg(&gmplmr, 22, 9);	//GMPLMR
			m_pSim->ReadNcReg(&gmpsw, 5, 9);	    //GMPSW
			UI32 hvcfg = 0, pswh = 0;
			m_pSim->ReadNcReg(&hvcfg, 16, 1);	//HVCFG
			m_pSim->ReadNcReg(&pswh, 15, 0);	//PSWH
			if ((hvcfg & 0x1) == 0 || (pswh >> 31) == 0) {
				bAccepted = false;
                break;
			}
			// PSW.ID and PSW.NP = 0, PLMR.PLM is masked
			if(((gmpsw & 0xa0) != 0) || ((gmplmr & 0xFF) <= priority) || ((dir0 & 0x1) != 0)) {
				bAccepted = false; 
                break;
			}
			//G4MH20 specs v1.07 section 3.1. New checking when INTCFG.EPL 
			// PSW.EIMASK <= priority
			UI32 gmpsw_eimask = (gmpsw >> 20) & 0x0ff;
			if (gmpsw_eimask <= priority) {
				bAccepted = false;
                break;
			}
			
			break;
		}
	
	case IException::EXP_BGEIINT:
		{
			UI32 psw = 0, gmplmr = 0, dir0 = 0, gmpsw = 0;
			UI32 hvcfg = 0, pswh = 0;
			m_pSim->ReadNcReg(&hvcfg, 16, 1);	//HVCFG
			m_pSim->ReadNcReg(&pswh, 15, 0);	//PSWH
			if ((hvcfg & 0x1) == 0 || (pswh >> 31) == 0) {
				bAccepted = false;
                break;
			}
			m_pSim->ReadNcReg(&gmplmr, 22, 9);    //GMPLMR
			m_pSim->ReadNcReg(&psw, 5, 0);	    //PSW
			m_pSim->ReadNcReg(&gmpsw, 5, 9);
			// PSW.ID and PSW.NP = 0, DIR0_DM = 0, GMPSW.ID = 0, GMPSW.NP = 0
            if (((psw & 0xa0) != 0) || ((dir0 & 0x1) != 0) || ((gmpsw & 0xa0) != 0)) {
                bAccepted = false;
                break;
            }

			// PSW.EIMASK <= priority
			UI32 gmpsw_eimask = (gmpsw >> 20) & 0x0ff;
			if ((gmplmr & 0xFF) <= priority || gmpsw_eimask <= priority) {
				bAccepted = false;
                break;
			}
            
			break;
		}
	
	default:
		break;
	}
	
	return bAccepted;
}

bool CSimulatorControl::SyncCoProc(CCodeBlock *pCB, IInstruction *pIns) {
	UI32 pos = pCB->GetIndex(pIns);
	IInstruction *p = NULL;
	UI32 reg1 = 0, reg2 = 0, reglist = pIns->GetConstraintBit();
	// Limitation: Write ignore in G3KH when updating DR, DW, DX bits
	static UI32 default_mpm = 0xffffffff;
	UI32 mpm = 0;

	if(IsGuestMode()) {
		m_pSim->ReadNcReg(&mpm, 25, 9);  // GMMPM
	} else {
        m_pSim->ReadNcReg(&mpm, 0, 5);
	}

	// Initialized default_mpm by first MPM value.
	if(default_mpm == 0xffffffff)
		default_mpm = mpm;

	if((mpm & 0x7) == (default_mpm & 0x7))
		return false;

	for(UI32 n = pos; n < pCB->GetInstructionNum(); n++) {
		IInstruction *p = pCB->at(n);
		if(p->InLoop() == false)
			break;
		if(p->GetMne() == "loop") {
			reglist |= p->opr(0)->Idx();
		}
	}

	do {
		reg1 = g_rnd.GetRange(4, 29);
		reg2 = g_rnd.GetRange(4, 29);
	} while(((1 << reg1) & reglist) || ((1 << reg2) & reglist) || (reg1 == reg2));

	// [FROG]TODO: Resolve hazard issue when updating MPM register
	p = MOV32(default_mpm, reg1);
	p->SetSequence();
	pIns->DirMoveTo(p);
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	p = STSR(8, reg2, 1);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	p = LDSR(0, 8, 1);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);
	
	p = LDSR(reg1, 0, 5);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);
	
	p = SYNCI();
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	p = LDSR(reg2, 8, 1);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	return true;
}
/**
 *@brief	Check asynchronous label type of pending interrupt and request interrupt. EIINT, GMEIINT, EITBL, GMEITBL are same type
 *@param	event1: pending interrupt
 *@param	event2: request interrupt
 *@return	bool(true: interrupts have same type, false: different type)
 */
bool CSimulatorControl::CheckSameInterruptType(std::string event1, std::string event2) {
    /* EIINT = GMEIINT = EITBL = GMEITBL */
    /* FEINT = GMFEINT */
    /* DBINT = DBNMI */
    std::set<std::string> InterruptType = {"eiint", "eitbl", "feint", "gmeiint", "gmeitbl", "gmfeint", "bgeiint", "bgfeint"};

    auto CorrectInterruptName = [=](std::string InterruptName) -> std::string {
        if (InterruptType.find(InterruptName) != InterruptType.end()) {
            if (InterruptName.find("fe") != std::string::npos) {
                return std::string("feint");
            } else {
                return std::string("eiint");
            }

        }
        return InterruptName;
    };

    event1 = CorrectInterruptName(event1);
    event2 = CorrectInterruptName(event2);

    if (event1 == event2) {
        return true;
    }

    return false;
}

/**
 *@brief	Check asynchronous label type of pending interrupt and request interrupt. EIINT, GMEIINT, EITBL, GMEITBL are same type
 *@param	event1: pending interrupt
 *@param	event2: request interrupt
 *@return	bool(true: interrupts have same type, false: different type)
 */
bool CSimulatorControl::CheckSameInterruptType(UI32 intId1, UI32 intId2) {
    /* EIINT = GMEIINT = EITBL = GMEITBL */
    /* FEINT = GMFEINT */
    /* DBINT = DBNMI */
    std::set<UI32> InterruptId = {IException::EXP_EIINT, IException::EXP_EITBL, IException::EXP_GMEIINT, IException::EXP_GMEITBL,
		IException::EXP_BGEIINT, IException::EXP_FEINT, IException::EXP_GMFEINT, IException::EXP_BGFEINT};
	
    auto CorrectInterruptName = [=](UI32 intId) -> UI32 {
		UI32 intResult = intId;
        switch (intId1) {
		case IException::EXP_EITBL:
		case IException::EXP_GMEIINT:
		case IException::EXP_GMEITBL:
		case IException::EXP_BGEIINT:
			intResult = IException::EXP_EIINT;
			break;

		case IException::EXP_FEINT:
		case IException::EXP_GMFEINT:
		case IException::EXP_BGFEINT:
			intResult = IException::EXP_FEINT;
			break;
		}
        return intResult;
    };

    intId1 = CorrectInterruptName(intId1);
    intId2 = CorrectInterruptName(intId2);
    return (intId1 == intId2);
}

/**
 * @brief	Check asynchronous label, then send interrupt request to simulator
 * @pIns	Current simulated instruction
 */
void CSimulatorControl::CheckInterruptRequest(CCodeBlock *pCB, IInstruction *pIns) {
	IDirective	*pDir = NULL;
	CAsyncLabel *pAsyncLabel = NULL;
	UI32		n = 0;

    m_vRequestedIns.push_back(pIns);

	while((pDir = pIns->GetDirective(n)) != nullptr) {
		pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		if(pAsyncLabel == NULL) {
			n++;
			continue;
		}

		if(pAsyncLabel->m_bAssert) {
			const std::string &name = pAsyncLabel->m_name;
			std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
			while(itr < m_vRequestedIntStack.end()) {
				if(CheckSameInterruptType((*itr)->sName,name))
					break;
				itr++;
			}
			
			if(itr == m_vRequestedIntStack.end()) {
				UI32 period = g_rnd.GetRange(1, EXCEPTION_MIN_PROBABLY);
				// Support case MDP at EIINT reference table.
				// To make sure EIINT request at 1st instruction handler was clear before finishing executing MP_Handler.
				if(pCB->GetLabel().find("mp_handler") != std::string::npos) {
					IInstruction *pFirst = pCB->at(0);
					if(pFirst->GetRegulationTarget() != NULL)
						pFirst = pFirst->GetRegulationTarget();

					/* EIINT or GMEIINT or EITBL or GMEITBL */
					if(((name.find("eiint") != std::string::npos) || (name.find("eitbl") != std::string::npos)) && pFirst == pIns) {
						UI32 mei = 0;
                        m_pSim->ReadNcReg(&mei, 8, 2);
	
						if((mei & 0x3e) == 0x2a) { // MDP at reference table access
							pIns->RemoveDirective(pAsyncLabel);
							continue;
						} else 
							period = 0;
					}
				}
				
				m_vRequestedIntStack.push_back(new CIntInfo(pIns, name, period, pAsyncLabel->m_index, pAsyncLabel->m_priority, pAsyncLabel->m_causecode, pAsyncLabel->m_channel, pAsyncLabel->m_gpid));
				m_vRequestedIntStack.back()->nEventId = pAsyncLabel->m_nEventId;
				m_pSim->RequestInterrupt(0, pAsyncLabel->m_nEventId, name, pAsyncLabel->m_channel, pAsyncLabel->m_priority, pAsyncLabel->m_causecode, pAsyncLabel->m_gpid);
				// Update status of interrupt. It is used for keeping assert label or need to remove (#92188)
				if(g_cfg->m_cpuStopinTime != 0)
					SetAssertINTatTime(pAsyncLabel->m_nEventId, g_cfg->m_cpuStopinTime);
			} else {
				MSG_WARN(0, "Pending interrupt (%s) was requested again\n", name.c_str());
				MSG_WARN(0, "New interrupt, name = %s, channel = %d, priority = %d\n", pAsyncLabel->m_name.c_str(), pAsyncLabel->m_channel, pAsyncLabel->m_priority);
				MSG_WARN(0, "Pending interrupt, name = %s, channel = %d, priority = %d\n", (*itr)->sName.c_str(), (*itr)->nChannel, (*itr)->nPriority);
                std::runtime_error excep("Interrupt is requested again\n ");
                throw excep;
			}
		} else {
            if (pCB->GetHandlerAddress() == IBlockManager::ADR_VECTOR_BGINT)
                m_vRequestedIns.pop_back();

			m_pSim->ClearInterrupt(0, pAsyncLabel->m_nEventId, pAsyncLabel->m_name);
			std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
			while(itr != m_vRequestedIntStack.end()) {
				CIntInfo* p = *itr;
				if(pAsyncLabel->m_name == p->sName) {
					itr = m_vRequestedIntStack.erase(itr);
					delete p;
					break;
				} else
					itr++;
			}
		}
		n++;
	}
}

/**
 * @brief	Adjust codeblock when exception occurs
 * @param	pCB pointer to a code block structure
 * @param	pIns pointer to current executing instruction
 * @return	Specify whether code block was adjusted or not
 */
bool CSimulatorControl::RegulateException(CCodeBlock* pCB, IInstruction *pIns, IExceptionConfig* pCfg) {
	auto IsExpatEITBL = [&] (IExceptionConfig* pCfg) -> bool {
		bool bExpatEITBL = false;
		// Check whether MDP/SYSERR exception caused by EIINT interrupt
		if(pCfg->m_level == IExceptionConfig::EXP_LEVEL_FE) {

			UI32 cause_code = 0;
            if (IsGuestMode()) {
                m_pSim->ReadNcReg(&cause_code, 14, 9);
            } else {
                m_pSim->ReadNcReg(&cause_code, 14, 0);
            }
			cause_code &= 0x0ffff;
			if(cause_code == 0x95 /* MDP guest management*/ || cause_code == 0x9D /* MDP host management*/ || cause_code == 0x1c /* SYSERR */) {	// At EIINT
				bExpatEITBL = true;
			}
		}
		return bExpatEITBL;
	};

	UI32 insid = pIns->GetId();
	UI32 idx = pCB->GetIndex(pIns);
	bool bExpatEITBL = IsExpatEITBL(pCfg);
	UI32 feic = 0;
    if (IsGuestMode()) {
        m_pSim->ReadNcReg(&feic, 14, 9);
    } else {
        m_pSim->ReadNcReg(&feic, 14, 0);
    }

    feic &= 0xffff;
	// The exception was regulated or is a interrupt
	if(m_bRollback)
		return true;

	if(pCfg->m_bIsInterrupt && (pCfg->m_lcode != 0x0010 /*SYSERR*/ || feic == 0x0018 /*SYSEROR when RW*/))
		return true;

	// These exception was processed beforehand due to read-only register DIR0
	if(insid == INS_ID_DBT || insid == INS_ID_RMT || insid == INS_ID_DBHVTRAP)
		return true;

    auto CauseConsecutive = [=] (CCodeBlock* pCB, IInstruction *pPrev) {
        // Mismatch between CFOREST and RTL in G4MH1.0
        // 1. EI        <-- EIINT is pending
        // 2. Ins       <-- Cause exception and de-assert EIINT
        if(pPrev->GetId() == INS_ID_EI) {
            std::vector<CIntInfo*>::iterator itr;
		    for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
			    CIntInfo* p = (*itr);
			    /* EIINT or GMEIINT or GMEIINT or EITBL or GMEITBL */
				if((p->sName.find("eiint") != std::string::npos) || (p->sName.find("eitbl") != std::string::npos)) {
					break;
                }
		    }

		    // There is pending EITBL/EIINT 
		    if(itr != m_vRequestedIntStack.end()) {
			    return true;
		    }
        }
        return false;
    };

	// Remove consecutive interrupt/event. Error case:
	//	1. Instruction 1 <-- Interrupt request
	//	2. Instruction 2 <-- Exception
	if(idx > 0 && pCfg->m_name != "MIP" && pCfg->m_name != "MIP_HM") {
		IInstruction *pPrev = pCB->at(idx - 1);
        if(pPrev->GetRiePartner() != NULL)
            pPrev = pCB->at(idx - 2); // Checked: (idx - 2) > 0
		if((pPrev->HasAssertLabel() || CauseConsecutive(pCB, pPrev) == true) && !bExpatEITBL) {
			IInstruction * p = NOP();
			p->AppendComment("Additional instruction for Remove consecutive interrupt/event");
			pIns->DirMoveTo(p);
			pIns->AsyncMoveTo(p);
			pCB->AddOpeCode(p, idx);
			pCB->Update();
			m_pRollbackIns = pIns;
			return false; /* Rollback & Re-Compile & Re-Sim */
		}
	}

	return true;
}

void CSimulatorControl::SetException(IInstruction *pIns, IExceptionConfig *pExp, CCodeBlock* pCB) {

	// Get cause code of occurred exception
    UI32 cause_code = m_pSim->GetCauseCode() & 0xffff;

	// Set exception information
	pIns->SetException(cause_code, GetTargetHandlerAddress(pExp));

	// Remove interrupt out of interrupt stack
	std::string name = pExp->m_name;
	std::transform(name.begin(), name.end(), name.begin(), [] (int ch) {return std::tolower(ch);});
	std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
	while(itr != m_vRequestedIntStack.end()) {
		CIntInfo *p = *itr;
		// Remove accepted event.
		if(CheckSameInterruptType(p->sName,name)) {
			itr = m_vRequestedIntStack.erase(itr);
			delete p;
		} else {
			// 2. SYSERR will be serviced at FENMI/FEIINT vector handler, it is uncontrollable
			if((name == "fenmi" || name == "feint") && p->sName == "syserr") {
				UI32 n = 0;
				IDirective *pDir = nullptr;
				while((pDir = pIns->GetDirective(n)) != nullptr) {
					CAsyncLabel* pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAsyncLabel != NULL && pAsyncLabel->m_name == p->sName) {
						break;
					}
					n++;
				}

				// Event is requested by current instruction
				if(pDir != nullptr) {
					pIns->RemoveDirective(pDir);
					delete pDir;
				} 

				itr = m_vRequestedIntStack.erase(itr);
				m_pSim->ClearInterrupt(0, p->nEventId, p->sName);
				delete p;
            } else {
                itr++;
            }
		}
	}
}

bool CSimulatorControl::RegulateBeforeException(CCodeBlock *pCB, IInstruction *pIns) {

	// De-assert interrupt
	if(DeassertInterrupt(pCB, pIns)) {
		return true; /* Re-Compile & Re-Sim */
	}  

    // Check and adjust requests at current instruction
    AdjustRequestInt(pCB, pIns);

    if (pIns->GetId() == INS_ID_HALT) {
        // Checking HALT release condition
        if (CheckHALTReleaseCond(pIns)) {
            IInstruction *p = NOP();
            p->AppendComment("Replace HALT instruction");
            pIns->DirMoveTo(p);
            pIns->AsyncMoveTo(p);
            PrepareDeletedIns(pCB, pIns);
            p = pCB->Replace(pIns, p);
            delete p;
            pCB->Update();
            return true;
        }
    }

    // Prevent consecutive interrupt request
    // Background: G4MH support executing 2 instruction in parallel.
    // Interrupt will be considered requesting at 2 instruction.
    if (RemoveConsecutiveRequest(pCB, pIns)) {
        return true;
    }

	return false;
}

/**
*@brief	Check and adjust assert label of current instruction
*/
void CSimulatorControl::AdjustRequestInt(CCodeBlock *pCB, IInstruction *pIns) {
    CAsyncLabel*	pAsyncLabel = nullptr;
    IDirective*		pDir = nullptr;
    UI32			insid = pIns->GetId();

    typedef enum {
        EXIT_BY_HVTRAP,
        EXIT_BY_GMEIINT,
        EXIT_BY_GMFEINT,
        EXIT_BY_BGEIINT,
        EXIT_BY_BGFEINT,
        EXIT_BY_EIINT,
        EXIT_BY_FEINT,
        EXIT_BY_FENMI,
        EXIT_CURRENT_GM_NONE
    }  EXIT_CURRENT_GM;

    // Bitset variable inform status (occur or not) of GM/BGxx, EI/FExx, HVTRAP(0->7, 0x1e)
    std::bitset<EXIT_CURRENT_GM_NONE>	exitSituation; 
    auto CheckRequestExist = [=](CAsyncLabel* pAsyncLabel) {
        std::vector<CIntInfo*>::iterator itr;
        for (itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
            CIntInfo* p = *itr;
            // Same assert event type is requested again with different channel or priority
            if (p->nClear != CIntInfo::ASYNC_CLEAR_PEND && CheckSameInterruptType(p->sName, pAsyncLabel->m_name)) {
                return true;
            }
        }
        return false;
    };
    // Exit current GM by HVTRAP or INS_CID_CHANGE_MODE (same as HVTRAP)
    auto ReadyExitCurrentGM_byHVTRAP = [=]() -> bool {
        UI32 gmpsw = 0;
        m_pSim->ReadSysRegister(&gmpsw, "GMPSW", 0);

        if (pIns->GetId() == INS_ID_HVTRAP) {
            UI32 select_code = pIns->opr(0)->GetRegVal();
            if ((select_code <= 0x7 || select_code == 0x1e) && ((gmpsw >> 30) & 0x1) == 0) {
                return true;
            }
        }

        if (((gmpsw >> 30) & 0X1) == 0) {
            for (UI32 i = 0; i <= pIns->GetOpNum(); i++) {
                if (pIns->opr(i) == nullptr || pIns->opr(i)->GetLabel() == nullptr)
                    continue;
                std::string oprLabel(pIns->opr(i)->GetLabel());
                if (oprLabel != "" && oprLabel.find("function_ChangeModetoHM") != std::string::npos) {
                    return true;
                }
            }
        }

        return false;
    };

    // Remove condition to exit from current GM
    auto MustNotExitCurrentGM = [=]() -> bool {
        UI32 pswh = 0;
        m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
        if ((pswh >> 31) == 0) return false;
        UI32	insid = pIns->GetId();
        if (insid == INS_ID_FERET || insid == INS_ID_EIRET || insid == INS_ID_CTRET) {
            return true;
        }

        if (pIns->InLoop() || insid == INS_ID_LOOP) {
            UI32 start_loop = pCB->GetIndex(pIns);
            IInstruction* ptempIns = pIns;
            if (insid == INS_ID_LOOP && (pCB->at(start_loop - 1)->GetRegulationTarget() == pIns || pIns->InSequence(IInstruction::IF_SEQ_FWD))) {
                // Do nothing
            } else {
                while (ptempIns->GetLabel().find("_Lp_") == std::string::npos && start_loop != 0) {
                    start_loop--;
                    ptempIns = pCB->at(start_loop);
                    if (ptempIns->GetId() == INS_ID_HALT) {
                        return true;
                    }
                }
            }
        }

        return false;
    };

    UI32 pswh = 0, hvsb = 0;
    m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
    m_pSim->ReadSysRegister(&hvsb, "HVSB", 0);
    UI32 n = 0;
    // Check and adjust requests at current instruction
    while ((pDir = pIns->GetDirective(n)) != nullptr) {
        pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
        if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {

            // Remove request if it is pending
            if (CheckRequestExist(pAsyncLabel)) {
                pIns->RemoveDirective(pDir);
                delete pDir;
                continue;
            }
            // Limitation 2: Control interrupt in callt/syscall block
            if (!CheckAcceptanceCond(pAsyncLabel->m_nEventId, pAsyncLabel->m_priority)
                && (insid == INS_ID_CALLT || insid == INS_ID_SYSCALL || (insid >= INS_ID_JARLSD22 && insid <= INS_ID_JARL) || pIns->InLoop())) {
                pIns->RemoveDirective(pDir);
                delete pDir;
                continue;
            }
            // Checking target VM of BGINT is terminate or not
            if ((pAsyncLabel->m_nEventId == IException::EXP_BGFEINT || pAsyncLabel->m_nEventId == IException::EXP_BGEIINT)
                && IsTerminatedVM(pAsyncLabel->m_gpid) == true) {
                pIns->RemoveDirective(pDir);
                delete pDir;
                continue;
            }
            // Check if current mode is Host mode: BG and GM interrupt can not be requested in Host mode
            if ((pswh >> 31) == 0) {
                if (pAsyncLabel->m_nEventId >= IException::EXP_GMFEINT && pAsyncLabel->m_nEventId <= IException::EXP_BGEIINT) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    continue;
                }
            }
            // Check if current instruction is special instruction that can not generate deassert, but (BGxx or GMxx (after BGxx) or EI/FExx) is accepted ==> Remove assert label
            if (MustNotExitCurrentGM() && CheckAcceptanceCond(pAsyncLabel->m_nEventId, pAsyncLabel->m_priority)) {
                if (pAsyncLabel->m_nEventId == IException::EXP_FENMI || pAsyncLabel->m_nEventId == IException::EXP_FEINT
                    || pAsyncLabel->m_nEventId == IException::EXP_EIINT || pAsyncLabel->m_nEventId == IException::EXP_BGFEINT || pAsyncLabel->m_nEventId == IException::EXP_BGEIINT
                    || (pAsyncLabel->m_nEventId >= IException::EXP_GMFEINT && pAsyncLabel->m_nEventId <= IException::EXP_GMRBINT && ((hvsb >> 3) & 0x1) == 1)) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    continue;
                }
            }
            // Do not generate assert label at halt, in case --cpu_stop_in_time. Refer ticket #92188 note#17
            if ((g_cfg->m_cpuStopinTime != 0) && (insid == INS_ID_HALT)) {
                pIns->RemoveDirective(pDir);
                delete pDir;
                continue;
            }
            // Check if requested interrupt can occur, record for adjusting later
            if (CheckAcceptanceCond(pAsyncLabel->m_nEventId, pAsyncLabel->m_priority)) {
                switch (pAsyncLabel->m_nEventId) {
                case IException::EXP_FENMI:
                    exitSituation.set(EXIT_BY_FENMI);
                    break;
                case IException::EXP_FEINT:
                    exitSituation.set(EXIT_BY_FEINT);
                    break;
                case IException::EXP_EIINT:
                case IException::EXP_EITBL:
                case IException::EXP_RBINT:
                    exitSituation.set(EXIT_BY_EIINT);
                    break;
                case IException::EXP_BGFEINT:
                    exitSituation.set(EXIT_BY_BGFEINT);
                    break;
                case IException::EXP_BGEIINT:
                    exitSituation.set(EXIT_BY_BGEIINT);
                    break;
                case IException::EXP_GMFEINT:
                    exitSituation.set(EXIT_BY_GMFEINT);
                    break;
                case IException::EXP_GMEIINT:
                case IException::EXP_GMEITBL:
                case IException::EXP_GMRBINT:
                    exitSituation.set(EXIT_BY_GMEIINT);
                    break;
                default:
                    break;
                }
            }
        }
        n++;
    }
    // Do not need to check requested interrupt if current mode is Host mode or Convention 
    if ((pswh >> 31) == 0) return;

    if (ReadyExitCurrentGM_byHVTRAP() == true) {
        exitSituation.set(EXIT_BY_HVTRAP);
    }
    // Special case: GM#0: BGxxINT -> GM#1: GMxxINT (in stack) + assert label
    std::vector<CIntInfo*>::iterator itr;
    itr = m_vRequestedIntStack.begin();
    while (itr != m_vRequestedIntStack.end()) {
        CIntInfo* pIntInfo = *itr;
        if (CheckAcceptanceCond(pIntInfo->nEventId, pIntInfo->nPriority)) {
            switch (pIntInfo->nEventId) {
                case IException::EXP_GMFEINT:
                    exitSituation.set(EXIT_BY_GMFEINT);
                    break;
                case IException::EXP_GMEIINT:
                case IException::EXP_GMEITBL:
                case IException::EXP_GMRBINT:
                    exitSituation.set(EXIT_BY_GMEIINT);
                    break;
                default:
                    break;
            }
        }
        itr++;
    }
    // Convert bitset to integer for switching: 
    //Order: FENMI(bit 8) - FEINT(bit 7) - EIINT(bit 6) - BGFEINT(bit 5) - BGEIINT(bit 4) - GMFEINT(bit 3) - GMEIINT(bit 2) - HVTRAP(bit 1)
    UI32 exitSituation_int = (UI32)(exitSituation.to_ulong());

    n = 0;
    // Adjust assert label in case Guest mode -> Host mode or another Guest mode
    switch (exitSituation_int) {
    case 1: // Only HVTRAP
    case 32 ... 255: // HVTRAP (or not) + EI/FExx is accepted (100000 ... 11111111)
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
                // Clear all GM/BGxx
                if ((pAsyncLabel->m_nEventId >= IException::EXP_GMFEINT && pAsyncLabel->m_nEventId <= IException::EXP_BGEIINT)) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    continue;
                }
            }
            n++;
        }
        break;
    case 2 ... 3: // HVTRAP (or not) + GMEIINT is accepted (10 ... 11)
        if (((hvsb >> 3) & 0x1) == 1) {
            while ((pDir = pIns->GetDirective(n)) != nullptr) {
                pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
                    // Clear GMFEINT and BGxx 
                    if ((pAsyncLabel->m_nEventId == IException::EXP_GMFEINT || pAsyncLabel->m_nEventId == IException::EXP_BGFEINT || pAsyncLabel->m_nEventId == IException::EXP_BGEIINT)) {
                        pIns->RemoveDirective(pDir);
                        delete pDir;
                        continue;
                    }
                }
                n++;
            }
        }
        break;
    case 4 ... 7:// HVTRAP (or not) + GMFEINT is accepted (100 ... 111)
        if (((hvsb >> 3) & 0x1) == 1) {
            while ((pDir = pIns->GetDirective(n)) != nullptr) {
                pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
                    // Clear GMEIINT and BGxx 
                    if ((pAsyncLabel->m_nEventId >= IException::EXP_GMEIINT && pAsyncLabel->m_nEventId <= IException::EXP_BGEIINT)) {
                        pIns->RemoveDirective(pDir);
                        delete pDir;
                        continue;
                    }
                }
                n++;
            }
        }
        break;
    case 8 ... 15: // BGEIINT is accepted (1000 ... 1111)
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
                // Clear GMxx and BGFEINT
                if ((pAsyncLabel->m_nEventId >= IException::EXP_GMFEINT && pAsyncLabel->m_nEventId <= IException::EXP_GMRBINT)
                    || pAsyncLabel->m_nEventId == IException::EXP_BGFEINT) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    continue;
                }
            }
            n++;
        }
        break;
    case 16 ... 31: // BGFEINT is accepted or Both BGFEINT and BGEIINT are accepted (10000 ... 11111)
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
                // Clear BGEIINT and GMxx
                if (pAsyncLabel->m_nEventId == IException::EXP_BGEIINT
                    || (pAsyncLabel->m_nEventId >= IException::EXP_GMFEINT && pAsyncLabel->m_nEventId <= IException::EXP_GMRBINT)) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    continue;
                }
            }
            n++;
        }
        break;
    default:
        break;
    }
}

/**
*@brief	Preset memory for auto save interrupt
*/
void CSimulatorControl::InitmemoryforInterrupt(IInstruction *pIns) {

    UI32 n = 0;
    IDirective	*pDir = NULL;
    CAsyncLabel *pAsyncLabel = NULL;
    UI32 num_reg = 0, startAddress = 0;
    UI32 HVCFG = 0, RBCR0 = 0, RBCR0_BE = 0, RBIP = 0, RBNR = 0;

    m_pSim->ReadNcReg(&HVCFG, 16, 1);
    m_pSim->ReadNcReg(&RBCR0, 15, 2);
    m_pSim->ReadNcReg(&RBNR, 17, 2);
    m_pSim->ReadNcReg(&RBIP, 18, 2);
    RBCR0_BE = RBCR0 & 0xFFFF;

    // Calculating range of init memory.
    if ((RBCR0 >> 16) == 0) {
        startAddress = RBIP - 0x60 * RBNR - 4;
        num_reg = 24;
    } else {
        startAddress = RBIP - 0x90 * RBNR - 4;
        num_reg = 35;
    }

    auto SyserrOccur = [=] (std::string name) -> bool {
        UI32 RBNR = 0, INTCFG = 0;  
        m_pSim->ReadNcReg(&RBNR, 17, 2);

        if (name == "gmeitbl") {
            m_pSim->ReadNcReg(&INTCFG, 21, 9);	//GMINTCFG
        } else {
            m_pSim->ReadNcReg(&INTCFG, 13, 2);  //INTCFG
        }

        UI32 INTCFG_ULNR = (INTCFG >> 16) & 0x3F;
        if (RBNR > INTCFG_ULNR || RBNR == 63) {
            return true;
        }
        return false;
    };

    auto InitMemory = [=](UI32 startAddress, UI32 num_reg) {
        const UI32 PSIZE = 4;
        UI32 value = 0;

        for (UI32 i = num_reg; i > 0; --i) {
            value = g_rnd.Get() & 0xfffffff0;
            m_pSim->PresetMemory(true, 0, startAddress, PSIZE, value);
            startAddress -= PSIZE;
        }
    };

    // There is pending event.
    for (CIntInfo* itr_info : m_vRequestedIntStack) {
        std::string &name = itr_info->sName;
        UI32 priority = (itr_info->nPriority > 15 ? 15 : itr_info->nPriority);
        UI32 mask = (1 << priority);

        if ((name == "gmeitbl" || (name == "eitbl" && (HVCFG & 0x1) == 0))
            && CheckAcceptanceCond(itr_info->nEventId, itr_info->nPriority)) {
            if (((RBCR0_BE & mask) != 0) && !SyserrOccur(name)) {
                
            } else {
                startAddress = startAddress + ((RBCR0 >> 16) ? 0x90 : 0x60);
                num_reg = 1;
            }

            InitMemory(startAddress, num_reg);
            return;
        } else if ((name == "gmeiint" || (name == "eiint" && (HVCFG & 0x1) == 0)) 
            && CheckAcceptanceCond(itr_info->nEventId, itr_info->nPriority)
            && RBNR != 0) {
            // Support check auto save interrupt in EIINT handler
            // Preset memory at PC position
            startAddress = startAddress + ((RBCR0 >> 16) ? 0x90 : 0x60);
            InitMemory(startAddress, 1);
            return;
        }
    }

    // Check and adjust requests at current instruction
    while ((pDir = pIns->GetDirective(n)) != nullptr) {
        pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
        if (pAsyncLabel == NULL) {
            n++;
            continue;
        }

        std::string &name = pAsyncLabel->m_name;
        UI32 priority = (pAsyncLabel->m_priority > 15 ? 15 : pAsyncLabel->m_priority);
        UI32 mask = (1 << priority);

        if (pAsyncLabel->m_bAssert) {
            if ((name == "gmeitbl" || (name == "eitbl" && (HVCFG & 0x1) == 0))
                && CheckAcceptanceCond(pAsyncLabel->m_nEventId, pAsyncLabel->m_priority)) {
                if (((RBCR0_BE & mask) != 0) && !SyserrOccur(name)) {

                } else {
                    startAddress = startAddress + ((RBCR0 >> 16) ? 0x90 : 0x60);
                    num_reg = 1;
                }

                InitMemory(startAddress, num_reg);
                break;
            } else if ((name == "gmeiint" || (name == "eiint" && (HVCFG & 0x1) == 0))
                && CheckAcceptanceCond(pAsyncLabel->m_nEventId, pAsyncLabel->m_priority)
                && RBNR != 0) {
                // Support check auto save interrupt in EIINT handler
                // Preset memory at PC position
                startAddress = startAddress + ((RBCR0 >> 16) ? 0x90 : 0x60);
                InitMemory(startAddress, 1);
                break;
            }
        }
        n++;
    }
}
/**
 * @brief	Check status of requested event, then deciding clear un-accepted event
 * @param	pCB		current simulated code block
 * @param	pIns	Current simulated instruction
 * @return	If there is any event cleared, return true, otherwise, return false
 */
bool CSimulatorControl::DeassertInterrupt(CCodeBlock *pCB, IInstruction *pIns) {
	std::vector<CIntInfo*>::iterator itr;
	bool ret = false, flag = false;
    UI32 intPendAccepted = 0;
    UI32 pswh = 0, gmpsw = 0, hvsb = 0;
    m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
    m_pSim->ReadSysRegister(&gmpsw, "GMPSW", 0);
    m_pSim->ReadSysRegister(&hvsb, "HVSB", 0);

    // Check if there is any pending interrupt (exit current GM) can be accepted 
    itr = m_vRequestedIntStack.begin();
    while (itr != m_vRequestedIntStack.end()) {
        // Cannot exit from current GM if not in GM
        if ((pswh >> 31) == 0) {
            break;
        }
        CIntInfo* p = *itr;
        if (CheckAcceptanceCond(p->nEventId, p->nPriority)) {
            if (p->nEventId == IException::EXP_FENMI || p->nEventId == IException::EXP_FEINT
                || p->nEventId == IException::EXP_EIINT || p->nEventId == IException::EXP_BGFEINT || p->nEventId == IException::EXP_BGEIINT
                || (p->nEventId >= IException::EXP_GMFEINT && p->nEventId <= IException::EXP_GMRBINT && ((hvsb >> 3) & 0x1) == 1)) {
                intPendAccepted = p->nEventId;
                flag = true; // Need to generate deassert label for another pending interrupt in stack
                break;
            }
        }
        itr++;
    }

    //De-assert before change from Guest mode to Host mode
    auto ReadyExitCurrentGM = [=] () -> bool {
        // Cannot exit from current GM if not in GM
        if ((pswh >> 31) == 0) {
            return false;
        }
        // Exit current GM by HVTRAP (0->7, 0x1e)
        if (pIns->GetId() == INS_ID_HVTRAP) {
            UI32 select_code = pIns->opr(0)->GetRegVal();
            if ((select_code <= 0x7 || select_code == 0x1e) && ((gmpsw >> 30) & 0x1) == 0) {
                return true;
            }
        }
        // Change to Host mode by Custom instruction INS_CID_CHANGE_MODE (only valid with SV privilege)
        if (((gmpsw >> 30) & 0X1) == 0) {
            for (UI32 i = 0; i <= pIns->GetOpNum(); i++) {
                if (pIns->opr(i) == nullptr || pIns->opr(i)->GetLabel() == nullptr)
                    continue;
                std::string oprLabel(pIns->opr(i)->GetLabel());
                if (oprLabel != "" && oprLabel.find("function_ChangeModetoHM") != std::string::npos) {
                    return true;
                }
            }
        }
        // Exit current GM because interrupt BGxx or GMxx (after BGxx) or EI/FExx is requested (assert label) and accepted
        UI32 n = 0;
        IDirective	*pDir;
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAs != nullptr && CheckAcceptanceCond(pAs->m_nEventId, pAs->m_priority)) {
                if (pAs->m_nEventId == IException::EXP_FENMI || pAs->m_nEventId == IException::EXP_FEINT
                    || pAs->m_nEventId == IException::EXP_EIINT || pAs->m_nEventId == IException::EXP_BGFEINT || pAs->m_nEventId == IException::EXP_BGEIINT
                    || (pAs->m_nEventId >= IException::EXP_GMFEINT && pAs->m_nEventId <= IException::EXP_GMRBINT && ((hvsb >> 3) & 0x1) == 1)) {
                    return true;
                }
            }
            n++;
        }

        return false;
    };
    // Do not generate deassert label and remove condition to exit from current GM (if any)
    auto MustNotGenDeassert = [=]() -> bool {
        UI32	insid = pIns->GetId();
        if (insid == INS_ID_HALT || insid == INS_ID_FERET || insid == INS_ID_EIRET || insid == INS_ID_CTRET) {
            return true;
        }

        if (pIns->InLoop() || insid == INS_ID_LOOP) {
            UI32 start_loop = pCB->GetIndex(pIns);
            IInstruction* ptempIns = pIns;
            if (insid == INS_ID_LOOP && (pCB->at(start_loop - 1)->GetRegulationTarget() == pIns || pIns->InSequence(IInstruction::IF_SEQ_FWD))) {
                // Do nothing
            } else {
                while (ptempIns->GetLabel().find("_Lp_") == std::string::npos && start_loop != 0) {
                    start_loop--;
                    ptempIns = pCB->at(start_loop);
                    if (ptempIns->GetId() == INS_ID_HALT) {
                        return true;
                    }
                }
            }
        }

        // Do not generate deassert label at 2nd instruction of C2B1
        if (pIns->InSequence(IInstruction::IF_SEQ_C2B1) != false) {
            UI32 nInsIndex = pCB->GetIndex(pIns);
            UI32 pos = 2;
            IInstruction *pPreIns = (nInsIndex > 0 ? pCB->at(nInsIndex - 1) : nullptr);
            while (pPreIns != nullptr && pPreIns->GetRegulationTarget() == pIns && (SI32)(nInsIndex - pos) >= 0) {
                pPreIns = pCB->at(nInsIndex - pos);
                pos++;
            }
            if (pPreIns != nullptr && pPreIns->GetC2B1Ins() == pIns)
                return true;
        }

        // Consecutive: Instruction is destination of jump and jump has assert label --> Can not generate deassert
        if (pIns->GetLabel().length() > 0) {
            std::vector<std::string>::iterator itrJmpDest = std::find(m_vJmpDestStack.begin(), m_vJmpDestStack.end(), pIns->GetLabel());
            if (itrJmpDest != m_vJmpDestStack.end()) {       
                return true;
            }
        }

        return false;
    };

    auto NeedDeassert = [=](CIntInfo* p) {
        UI32	insid = pIns->GetId();

        // Reached maximum of pending step
        if (p->nPeriod == 0) {  
            return true;
        }

        if (!CheckAcceptanceCond(p->nEventId, p->nPriority)
            && ((insid >= INS_ID_JARLSD22 && insid <= INS_ID_JARL) || insid == INS_ID_SYSCALL || insid == INS_ID_CALLT || insid == INS_ID_HVCALL))
            return true;

        // Checking target VM of BGINT is terminate or not
        if ((p->nEventId == IException::EXP_BGFEINT || p->nEventId == IException::EXP_BGEIINT) && IsTerminatedVM(p->nGpId) == true)
            return true;

        // Same event is requested in next instruction.
        if (!pIns->Behavior(IInstruction::JMP)) {
            IInstruction *pNext = nullptr;
            if (pIns->InSequence(IInstruction::IF_SEQ_C2B1) && pIns->GetC2B1Ins() != nullptr && !pIns->GetC2B1Ins()->Behavior(IInstruction::JMP)) {
                pNext = pCB->at(pCB->GetIndex(pIns) + 2); // Next instruction is always valid
            } else {
                pNext = pCB->at(pCB->GetIndex(pIns) + 1); // Next instruction is always valid
            }
            if (pNext != nullptr) {
                UI32 n = 0;
                IDirective	*pDir;
                while ((pDir = pNext->GetDirective(n)) != nullptr) {
                    CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                    if (pAs != NULL && CheckSameInterruptType(pAs->m_name, p->sName)) {
                        return true;
                    }
                    n++;
                }
            }
        }
        // De-assert all pending events after TRAP 0x1d
        if (pCB->GetLabel().find("th_end_sync_sub") != std::string::npos) {
            return true;
        }

        if (pIns->GetComment().find("Changing privilege") != std::string::npos && pIns->GetRegulationTarget() != nullptr)
            return true;

        // De-assert all pending events after finishing simulating random code block
        if (pIns->GetChain()) {
            if (pIns->GetJumpTarget().find("th_end_sync") != std::string::npos)
                return true;
        }

        return false;
    };

    // Adjustment may be adjusted after simulating, don't generate deassert label; except instruction regulate for INS_CID_CHANGE_MODE
    if (pIns->GetRegulationTarget() != nullptr && ReadyExitCurrentGM() == false) {
        return false;
    }

    std::vector<IDirective *> vDeassertDir;

    itr = m_vRequestedIntStack.begin();
    while (itr != m_vRequestedIntStack.end()) {
        CIntInfo* pIntInfo = *itr;

        // This event was already cleared.
        if (pIntInfo->nClear != CIntInfo::ASYNC_CLEAR_NONE) {
            itr++;
            continue;
        }

        if ((NeedDeassert(pIntInfo) == true || ReadyExitCurrentGM() == true || flag == true) && MustNotGenDeassert() == false) {
            // Generate de-assert label
            CAsyncLabel *pAsyncLabel = new CAsyncLabel(pIntInfo->sName, GetTContext(), m_nDeassertIdx++, false);
            pAsyncLabel->m_nEventId = pIntInfo->nEventId;

            UI32 n = 0;
            IDirective	*pDir;
            while ((pDir = pIns->GetDirective(n)) != nullptr) {
                CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                // Remove assert and deassert for same events at the same time.
                if (pAs != nullptr && CheckSameInterruptType(pAs->m_name, pIntInfo->sName)) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    continue;
                }
                n++;
            }

            // Only force to generate deassert label for GM/BGxx interrupt when exit from current GM
            if ((ReadyExitCurrentGM() == true || flag == true) && NeedDeassert(pIntInfo) == false) {
                if (pAsyncLabel->m_nEventId < IException::EXP_GMFEINT || pAsyncLabel->m_nEventId > IException::EXP_BGEIINT){
                    itr++;
                    continue;
                }
            }
            // Do not generate deassert label for pending interrupt (exit current GM) will be accepted
            if (pIntInfo->nEventId == intPendAccepted) {
                itr++;
                continue;
            }

 			vDeassertDir.push_back(pAsyncLabel);
			pIntInfo->nClear = CIntInfo::ASYNC_CLEAR_PEND;
		}
		itr++;
	}

	std::for_each(vDeassertDir.begin(), vDeassertDir.end(), [&pIns] (IDirective *pDir) {pIns->SetDirective(pDir);});
	return ret;
}

/**
 * @brief	Check EXP/Interrupt due to internal priority
 * @param	pIns instruction need to check EXP/Interrupt
 * @param	pCB code block has internal priority
 * @return	True: Exp can occured at pIns
	        False: Exp can not occured at pIns
 */
bool CSimulatorControl::PredictException (CCodeBlock *pCB, IInstruction *pIns, UI32 expAddr) {

	bool result = false;
	UI32 InsId = pIns->GetId();
	auto GetOperand = [&pIns](UI32* sr) -> bool {
		if(pIns->GetId() == INS_ID_STSR){
			*sr = (UI32) *(pIns->opr(0));
			return true;
			}
		if(pIns->GetId() == INS_ID_LDSR){
			*sr = (UI32) *(pIns->opr(1));
			return true;
			}
		return false;
	};

	auto PSWEnableBit = [&](UI32 bitPos) -> bool {

		UI32 psw = GetPSW();
		if (((psw >> bitPos) & 0x1) == 1) return true;
			return false;
	};

	//Check EXP cause by instruction
	switch (expAddr) {
	case IBlockManager::ADR_VECTOR_RESET:
		break;
	// Not check yet 
	case IBlockManager::ADR_VECTOR_SYSERR:
        {
            if (pIns->GetId() == INS_ID_RESBANK) {
                UI32 RBNR = 0;
                m_pSim->ReadNcReg(&RBNR, 17, 2);
                if (RBNR == 0)
                    result = true;
            }
        }
        break;

	case IBlockManager::ADR_VECTOR_HVTRAP:

		{
		UI32 hvcfg = 0, pswh = 0, um = 0, psw = 0, gmpsw = 0;
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		m_pSim->ReadSysRegister(&psw, "PSW", 0);
		m_pSim->ReadSysRegister(&gmpsw, "GMPSW", 0);
		if(((hvcfg & 0x1) == 1) && InsId == INS_ID_HVTRAP){
			if((pswh >> 31) & 1) // Guest mode
				um = (gmpsw >> 30);
			else
				um = (psw >> 30);

			if(um == 0)
				result = true;
			}
		}

		break;

	case IBlockManager::ADR_VECTOR_FETRAP:
		if(InsId == INS_ID_FETRAP)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_TRAP0:
		if(InsId == INS_ID_TRAP) {
			UI32 vecTrap = (UI32)* (pIns->opr(0));
			if(vecTrap <= 0xf)
				result = true;
		}
		break;

	case IBlockManager::ADR_VECTOR_TRAP1:
		if(InsId == INS_ID_TRAP) {
			UI32 vecTrap = (UI32)* (pIns->opr(0));
			if(vecTrap > 0xf)
				result = true;
		}
		break;

	case IBlockManager::ADR_VECTOR_RIE:
		{
		if(InsId == INS_ID_RIE || InsId == INS_ID_RIE_I9 || InsId == INS_ID_HVCALL || (InsId >= INS_CID_RIE_FPU32 && InsId <= INS_CID_RIE_INT64))
			result = true;

		UI32 hvcfg = 0;
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		if((hvcfg & 0x1) == 0) {
			if ((InsId == INS_ID_HVTRAP) || (InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP))
				result = true;
		}
		}
		break;

	// Not check yet
	case IBlockManager::ADR_VECTOR_FPPFPI:
		{
		//Check FPU instruction
		if (PSWEnableBit(16) == true)	{
			UI32 fpsr = 0;		
			m_pSim->ReadSysRegister(&fpsr, "FPSR", 0);

			// Check FPU exception I V Z O U E
			//E3V5 spec page 340
			if ((/*XE enable*/(fpsr & 0x3E0) || /*no flush*/((fpsr & 0x20000) == 0)) 
				&& (InsId >= INS_ID_ABSF_D && InsId <= INS_ID_TRNCF_SW))
				result = true;
		}

		//Check FPSIMD instruction
		if(PSWEnableBit(17) == true){
			UI32 fxsr = 0;
			m_pSim->ReadSysRegister(&fxsr, "FXSR", 0);
			// Check FXU exception I V Z O U E
			if ((/*XE enable*/(fxsr & 0x3E0) || /*no flush*/((fxsr & 0x20000) == 0))
				&& (InsId >= INS_ID_CMOVF_W4 && InsId <= INS_ID_CMPF_S4))
				result = true;
		}
		}

		break;

	// Not check yet
	case IBlockManager::ADR_VECTOR_UCPOP:
		{
		UI32 sr = 0;
		GetOperand(&sr);
		// Check User Mode
		//Check FPU instruction
		if ((PSWEnableBit(16) == false) && ((InsId >= INS_ID_ABSF_D && InsId <= INS_ID_TRNCF_SW)
			|| ((InsId == INS_ID_LDSR || InsId == INS_ID_STSR) && ((sr >= (0*32) + 6) && (sr <= (0*32) + 11))))){
			result = true;
		}

		//Check SIMD instruction
		if (InsId >= INS_ID_CNVQ15Q30 && InsId <= INS_ID_VXOR){
			result = true;
		}

		//Check not support FPSIMD instruction
		if ( InsId == INS_ID_LDV_DW_2REG || InsId == INS_ID_LDV_QW_2REG || InsId == INS_ID_LDV_W_2REG || InsId == INS_ID_LDVZ_H4_2REG 
		|| InsId == INS_ID_STV_DW_2REG || InsId == INS_ID_STV_QW_2REG || InsId == INS_ID_STV_W_2REG || InsId == INS_ID_STVZ_H4_2REG ) {
	       result = true;
		}

		//Check FPSIMD instruction
		if ((InsId >= INS_ID_CMOVF_W4 && InsId <= INS_ID_CMPF_S4) || (((sr >= (10*32) + 0) && (sr <= (10*32) + 31)))){
			if(PSWEnableBit(17) == false) result = true;

		}

		}
		break;

	case IBlockManager::ADR_VECTOR_MPUMMU:
		//Check MDP 
		if (pIns->GetException().first == 0x91)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_PIE:
		{
		UI32 psw = 0, dir0 = 0, hvcfg = 0, pswh = 0;
		UI32 sr = 0;

		m_pSim->ReadSysRegister(&psw, "PSW", 0);
		m_pSim->ReadSysRegister(&dir0, "DIR0", 0);

		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);

		// Check User Mode
		auto IsUM = [=]() ->bool {
			return PSWEnableBit(30);
		};

				// Check HV priviledge system register
		auto IsHV = [&](UI32 hvcfg, UI32 pswh) -> bool {
			if(((hvcfg & 0x1) == 1) && ((pswh >> 31) == 0)) {
				return true;
			}
			return false;
		};

		if (IsUM() == true)	{
			if(InsId == INS_ID_HALT || InsId == INS_ID_DI || InsId == INS_ID_EI || InsId == INS_ID_SYSCALL || InsId == INS_ID_DST 
				|| InsId == INS_ID_EST || InsId == INS_ID_HVTRAP || InsId == INS_ID_EIRET || InsId == INS_ID_FERET
				|| (InsId >= INS_ID_RESBANK && InsId <= INS_ID_LDM_MP))	{
				result = true;
				break;
			}
			if(InsId == INS_ID_CACHE){
				UI32 cacheop = (UI32) *(pIns->opr(0));
				// CIBII, CFALI, CISTI, CILDI
				if(cacheop == 1 || cacheop == 2 || cacheop == 3 || cacheop == 4)	{
					result = true;
					break;
				}
			}
		}
		// Check Debug mode
        if ((dir0 & 0x1) == 0 && InsId == INS_ID_DBRET) {
            result = true;
            break;
        }

		if(IsHV(hvcfg, pswh) == false) {
			if(InsId == INS_ID_STM_GSR || InsId == INS_ID_LDM_GSR) {
				result = true;
				break;
			}

			// Check cache priviledge
			if(InsId == INS_ID_CACHE){
				UI32 cacheop = (UI32) *(pIns->opr(0));
				// CIBII, CFALI, CISTI, CILDI
				if(cacheop == 1 || cacheop == 2 || cacheop == 3 || cacheop == 4)	{			
					result = true;
					break;
				}
			}
		}

        if (InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
            GetOperand(&sr);

 			if (sr == (0 * 32) + 5 /*PSW*/) break;
 			
            if (IsUM() == true) {
                if ((sr >= (0 * 32) + 8 /*FPST*/) && (sr <= (0 * 32) + 10 /*FPCFG*/)) {
                    // Check CU0 bit
                    if (PSWEnableBit(16) == false) {
                        result = true;
                    }
                    break;
                }

                if ((sr >= (10 * 32) + 8 /*FXST*/) && (sr <= (10 * 32) + 13 /*FXXP*/)) {
                    // Check CU1 bit
                    if (PSWEnableBit(17) == false) {
                        result = true;
                    }
                    break;
                }

                // Check UM system register 
                if (g_srs->IsUMpriv((sr & 0x1f), (sr >> 5)) == false) {
                    result = true;
                    break;
                }
            } else {
                if ((sr == (0 * 32) + 6 /*FPSR*/) || (sr == (0 * 32) + 7 /*FPEPC*/)) {
                    // Check CU0 bit
                    if (PSWEnableBit(16) == false) {
                        result = true;
                    }
                    break;
                }

                if ((sr == (10 * 32) + 6 /*FXSR*/)) {
                    // Check CU1 bit
                    if (PSWEnableBit(17) == false) {
                        result = true;
                    }
                    break;
                }

                // Check HV system register in SV mode
                if (((pswh >> 31) != 0) && g_srs->IsHVpriv((sr & 0x1f), (sr >> 5)) == true) {
                    result = true;
                    break;
                }
            }
        }

		}
		break;

	case IBlockManager::ADR_VECTOR_DEBUG:
		if(InsId == INS_ID_DBT || InsId == INS_ID_DBHVTRAP || InsId == INS_ID_RMT)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_MAE:
		{
		if ((pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) ){
			IValConstraint* pVc = NULL;
			// STC in couple has not constraint
			if(InsId == INS_ID_STC_W || InsId == INS_ID_STC_H){
				UI32 accMem = 0;
				m_pSim->ReadGrReg(&accMem, pIns->opr(1)->Idx(), 0);
				if((InsId == INS_ID_STC_W && ((accMem & 0x3) != 0)) || (InsId == INS_ID_STC_H && ((accMem & 0x1) == 1)) ){
					result = true;
					break;
				}
			}
			for (UI32 N = 0; N< pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					continue;
				}
				if (popr->Attr(IOperand::OPR_ATTR_SMEM) || popr->Attr(IOperand::OPR_ATTR_LMEM)) {
					if (((pVc = popr->GetConstraint()) != NULL) && pVc->m_nMsk && (pVc->m_nUnA >= 1 && pVc->m_nUnA <= pVc->m_nMsk)) {
						result = true;
						break;
					}
				}
				
			}
		}
		break;
		}
	default :
		break;
	}

	// Predict syscall exception
	if (pIns->GetMne() == "syscall")
		result = true;

	return result;

}

/**
 * @brief	Check and prevent consecutive interrupt request
 * @param	pCB		current simulated code block
 * @param	pIns	Current simulated instruction
 * @return	If there is consecutive request, return true; otherwise, return false
 */
bool CSimulatorControl::RemoveConsecutiveRequest(CCodeBlock *pCB, IInstruction *pIns) {

    if (pCB == NULL || pIns == NULL)
        return false;

    auto SetInterrupt = [](std::vector<CIntInfo*> *v) {
        std::vector<CIntInfo*>::iterator itr;
        for (itr = v->begin(); itr < v->end(); itr++)
            (*itr)->nClear = CIntInfo::ASYNC_CLEAR_REJECT;

    };

    auto CanMoveToNext = [](CCodeBlock *pCb, IInstruction *p) ->bool {
        UI32 idx = pCb->GetIndex(p);
        IInstruction *pNext = (idx < pCb->GetInstructionNum() - 1) ? pCb->at(idx + 1) : NULL;
        if (pNext == NULL)
            return false;
        if (p->Behavior(IInstruction::JMP))
            return false;
        if (p->InSequence(IInstruction::IF_SEQ_C2B1) && p->GetC2B1Ins() == pNext)
            return false;
        if (pNext->InSequence() || pNext->InLoop())
            return false;
        if (p->GetId() == INS_ID_HALT) {
            return false;
        }

        return true;
    };

    auto CheckAsyncExist = [=](IInstruction *p, std::string name) {
        for (UI32 n = 0; n < p->GetDirectiveNum(); n++) {
            CAsyncLabel *pAL = static_cast<CAsyncLabel*> (p->GetDirective(n)->GetAsyncLabel());
            if (pAL == NULL)
                continue;
            if (CheckSameInterruptType(pAL->m_name, name)) {
                return true;
            }
        }
        return false;
    };

    auto ResolveConsecutiveRequest = [=](CCodeBlock* pCB, IInstruction *p, bool bCanMoveToNext) -> void {
        UI32 idx = pCB->GetIndex(p);
        // It has consecutive request. Move the request to next instruction
        if (idx < pCB->GetInstructionNum() - 1) {
            IInstruction *pNext = pCB->at(idx + 1);
            // The next instruction may be executed already.
            if (bCanMoveToNext) {
                UI32 n = 0;
                IDirective *pDir = nullptr;
                while ((pDir = p->GetDirective(n)) != NULL) {
                    CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                    if (pAL != NULL  && pAL->m_bAssert && CheckAsyncExist(pNext, pAL->m_name) == false) {
                        p->RemoveDirective(pAL);
                        pNext->SetDirective(pAL);
                        continue;
                    }
                    n++;
                }
            }
            p->ClearAsync();
        } else {
            p->ClearAsync();
        }
    };

    auto InsAffectInt = [=](IInstruction *pIns) -> UI32 {
        UI32 ins_code = 0;
        if (pIns->GetId() == INS_ID_EI) { 
            ins_code = 1; 
        }
        return ins_code;
    };

    auto IsReadIMSR_ICSR = [](IInstruction *pIns) -> bool {
        if (pIns->GetId() == INS_ID_STSR) {
            UI32 sr = (UI32)*(pIns->opr(0));
            if ((sr == (2 * 32) + 11 /*IMSR*/)
                || (sr == (2 * 32) + 12 /*ICSR*/)) return true;
        }
        return false;
    };

    IInstruction* FirstC2B1Ins = nullptr;

    auto FirstC2B1Async = [&FirstC2B1Ins](CCodeBlock* pCB, IInstruction *pIns, std::string label) -> bool {
        UI32 nInsIndex = pCB->GetIndex(pIns);
        UI32 pos = 2;
        if (pIns->InSequence(IInstruction::IF_SEQ_C2B1) != false) {
            FirstC2B1Ins = (nInsIndex > 0 ? pCB->at(nInsIndex - 1) : nullptr); //C2B1 first instruction
            while (FirstC2B1Ins != nullptr && FirstC2B1Ins->GetRegulationTarget() == pIns && (SI32)(nInsIndex - pos) >= 0) {
                FirstC2B1Ins = pCB->at(nInsIndex - pos);
                pos++;
            }
            if (FirstC2B1Ins != nullptr && FirstC2B1Ins->GetC2B1Ins() == pIns) {
                if (label == "async" && FirstC2B1Ins->HasAsyncLabel()) return true;
                if (label == "assert" && FirstC2B1Ins->HasAssertLabel()) return true;
                if (label == "deassert" && FirstC2B1Ins->HasDeassertAsyncLabel()) return true;
            }
        }
        return false;
    };

    auto CurrentHasEIINTPending = [=]() {
        std::vector<CIntInfo*>::iterator itr;
        for (itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
            CIntInfo* p = (*itr);
            /* EIINT or GMEIINT or EITBL or GMEITBL or BGFEINT */
            if (p->sName.find("eiint") != std::string::npos || p->sName.find("eitbl") != std::string::npos) {
                break;
            }
        }
        // There is pending EITBL/EIINT 
        if (itr != m_vRequestedIntStack.end()) {
            return true;
        }
        return false;
    };

    auto ReadyExitCurrentGM_byHVTRAP = [=]() -> bool {
        if (pIns->GetId() == INS_ID_HVTRAP) {
            UI32 gmpsw = 0, pswh = 0;
            m_pSim->ReadSysRegister(&gmpsw, "GMPSW", 0);
            m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
            UI32 select_code = pIns->opr(0)->GetRegVal();
            if ((pswh >> 31) == 0) return false;
            if ((select_code <= 0x7 || select_code == 0x1e) && ((gmpsw >> 30) & 0x1) == 0) {
                return true;
            }
        }
        return false;
    };

    auto OccuredInt_Exp = [](IInstruction *pIns) -> bool {
        UI32 causecode = pIns->GetException().first;
        if (causecode != 0) return true;
        return false;
    };

    auto AssertLabelCanBeAccepted = [=](IInstruction *pIns) -> bool {
        UI32 n = 0;
        IDirective	*pDir;
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAs != nullptr && CheckAcceptanceCond(pAs->m_nEventId, pAs->m_priority)) {
                return true;
            }
            n++;
        }
        return false;
    };

    auto HasSameTypeInterrupt = [=] (IInstruction *pPrev, IInstruction *pIns) -> bool {
        UI32 n = 0;
        IDirective	*pDir;
        UI32 pIns_ei_type = 0, pIns_fe_type = 0, pIns_dbint = 0, pIns_dbnmi = 0;
        UI32 pPrev_ei_type = 0, pPrev_fe_type = 0, pPrev_dbint = 0, pPrev_dbnmi = 0;
        if (pPrev == nullptr || pIns == nullptr)
            return false;
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAs != nullptr) {
                if (pAs->m_name.find("eiint") != std::string::npos || pAs->m_name.find("eitbl") != std::string::npos) pIns_ei_type = 1;
                if (pAs->m_name.find("feint") != std::string::npos) pIns_fe_type = 1;
                if (pAs->m_name.find("dbint") != std::string::npos) pIns_dbint = 1;
                if (pAs->m_name.find("dbnmi") != std::string::npos) pIns_dbnmi = 1;
            }
            n++;
        }

        n = 0;
        while ((pDir = pPrev->GetDirective(n)) != nullptr) {
            CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAs != nullptr) {
                if (pAs->m_name.find("eiint") != std::string::npos || pAs->m_name.find("eitbl") != std::string::npos) pPrev_ei_type = 1;
                if (pAs->m_name.find("feint") != std::string::npos) pPrev_fe_type = 1;
                if (pAs->m_name.find("dbint") != std::string::npos) pPrev_dbint = 1;
                if (pAs->m_name.find("dbnmi") != std::string::npos) pPrev_dbnmi = 1;
            }
            n++;
        }
        return ((pIns_ei_type & pPrev_ei_type) || (pIns_fe_type & pPrev_fe_type) || (pIns_dbint & pPrev_dbint) || (pIns_dbnmi & pPrev_dbnmi));
    };

    UI32 idx = pCB->GetIndex(pIns);
    IInstruction *pPrev = nullptr;
    std::string async = "async";
    std::string assert = "assert";
    std::string deassert = "deassert";
    pIns->ClearAttrPending();
    if (CurrentHasEIINTPending()) {
        pIns->SetAttrPending(IInstruction::IF_PEND_EI);
    } else {
        pIns->SetAttrPending(IInstruction::IF_PEND_NONE);
    }

    // Abtract:
    // For more detail about consecutive cases, please refer ticket #91630, document "Async_event.xlsx"

    // Consecutive
    // 1. Instruction affect interrupt: ei + deassert label (there is pending EI interrupt)
    if ((InsAffectInt(pIns) == 1) && pIns->HasDeassertAsyncLabel() && CurrentHasEIINTPending()) {
        
        IInstruction * p = NOP();
        p->AppendComment("--Insert instruction to avoid consecutive 1");
        pIns->DirMoveTo(p);
        pIns->AsyncMoveTo(p);
        pCB->AddOpeCode(p, idx);
        pCB->Update();
        return true;
    }
    
    // Consecutive when jump hit PC1. For more detail, please refer ticket #91630 note #20
    //    Ins1: Jump behavior + async label
    //    Ins2: (Target of jump) + async label (except case: deassert - deassert)
    // Or Ins2: (Target of jump) --> ei/Read IMSR, ICSR
    // Note: Do not re-sim. Only move async label. 
    if (pIns->Behavior(IInstruction::JMP)) {
        std::string TargetJump = pIns->GetJumpTarget();
        if (TargetJump != "") {
            UI32 TargetAddress = g_asf->SearchAddress(TargetJump);
            IInstruction* TargetIns = pCB->Fetch(TargetAddress);
            if (TargetIns != nullptr
                && ((pIns->HasDeassertAsyncLabel() && IsReadIMSR_ICSR(TargetIns))
                    || (pIns->HasAssertLabel() && !AssertLabelCanBeAccepted(pIns) && IsReadIMSR_ICSR(TargetIns))
                    || (pIns->HasAssertLabel() && TargetIns->HasDeassertAsyncLabel() && HasSameTypeInterrupt(TargetIns, pIns))
                    || (pIns->HasDeassertAsyncLabel() && TargetIns->HasAssertLabel() && HasSameTypeInterrupt(TargetIns, pIns))
                    || (pIns->HasAssertLabel() && TargetIns->HasAssertLabel()))) {
                if (pIns->HasDeassertAsyncLabel()) {
                    SetInterrupt(&m_vRequestedIntStack);
                }
                bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
                ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
            }
            // Store label of jump to not generate deassert at destination
            if (TargetIns != nullptr && pIns->HasAssertLabel()) {
                m_vJmpDestStack.push_back(TargetJump);
            }
        }
        // Jump target of Ins_084_jmp is removed so we can not check this case
        if (pIns->GetId() == INS_ID_JMPD32 && pIns->HasAsyncLabel()) {
            if (pIns->HasDeassertAsyncLabel()) {
                SetInterrupt(&m_vRequestedIntStack);
            }
            bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
            ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
        }
    }
    
    if (idx == 0) return false;

    pPrev = pCB->at(idx - 1);
    if (pPrev->GetRiePartner() != NULL)
        pPrev = pCB->at(idx - 2);   // Checked: (idx - 2) > 0

    // Consecutive when change from Guest to Host/another Guest, please refer ticket #92256
    // 2.1  Ins1: Instruction affect interrupt: ei (there is pending EI interrupt)
    //      Ins2: HVTRAP(0->7, 0x1e) + deassert label
    // Or   Ins1: assert label
    //      Ins2: HVTRAP(0->7, 0x1e)
    if (((InsAffectInt(pPrev) == 1 && CurrentHasEIINTPending() && pIns->HasDeassertAsyncLabel()) || pPrev->HasAssertLabel())
        && ReadyExitCurrentGM_byHVTRAP()) {
        
        IInstruction * p = NOP();
        p->AppendComment("--Insert instruction to avoid consecutive 2");
        pIns->DirMoveTo(p);
        pIns->AsyncMoveTo(p);
        pCB->AddOpeCode(p, idx);
        pCB->Update();
        return true;
    }
    
    // Consecutive
    // 2.2  Ins1: Instruction affect interrupt: ei (there is pending EI interrupt)
    //      Ins2: deassert label
    if ((InsAffectInt(pPrev) == 1) && pIns->HasDeassertAsyncLabel() && CurrentHasEIINTPending()) {
        
        if (pIns->HasDeassertAsyncLabel()) {
            SetInterrupt(&m_vRequestedIntStack);
        }
        bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
        ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
        return true;
    }
    
    // Consecutive
    // 3. Ins1: deassert label
    //    Ins2: Read reg IMSR/ICSR
    // Or Ins1: assert label (interrupt not occured)
    //    Ins2: Read reg IMSR/ICSR
    // Or Ins1: Read reg IMSR + deassert label
    // Or Ins1: Read reg IMSR + assert label cannot be occured
    if ((pPrev->HasDeassertAsyncLabel() && IsReadIMSR_ICSR(pIns))
        || (pPrev->HasAssertLabel() && !OccuredInt_Exp(pPrev) && IsReadIMSR_ICSR(pIns))
        || (IsReadIMSR_ICSR(pIns) && pIns->HasDeassertAsyncLabel())
        || (IsReadIMSR_ICSR(pIns) && pIns->HasAssertLabel() && !AssertLabelCanBeAccepted(pIns))){
        
        IInstruction * p = SYNCP();
        p->AppendComment("--Insert instruction to avoid consecutive 3");
        pIns->DirMoveTo(p);
        pIns->AsyncMoveTo(p);
        pCB->AddOpeCode(p, idx);
        pCB->Update();
        return true;
    }
    
    // Consecutive
    // 4. Ins1: assert/deassert (or assert/deassert at 1st C2B1 instruction)
    //    Ins2: deasert/assert
    // Case: assert - deassert and deassert - assert only check for same type interrupt
    // Except case: Ins1: deassert
    //              Ins2: deassert
    if ((pPrev->HasAssertLabel() && pIns->HasDeassertAsyncLabel() && HasSameTypeInterrupt(pPrev, pIns))
        || (FirstC2B1Async(pCB, pPrev, assert) && pIns->HasDeassertAsyncLabel() && HasSameTypeInterrupt(FirstC2B1Ins, pIns))
        || (pPrev->HasDeassertAsyncLabel() && pIns->HasAssertLabel() && HasSameTypeInterrupt(pPrev, pIns))
        || (FirstC2B1Async(pCB, pPrev, deassert) && pIns->HasAssertLabel() && HasSameTypeInterrupt(FirstC2B1Ins, pIns))
        || ((pPrev->HasAssertLabel() || FirstC2B1Async(pCB, pPrev, assert)) && pIns->HasAssertLabel())){
        
        if (pIns->HasDeassertAsyncLabel()) {
            SetInterrupt(&m_vRequestedIntStack);
        }
        bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
        ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
        return true;
    }

    // Consecutive
    // 6. Ins1: C2B1 first
    //    Ins2: C2B1 second + assert/deassert label 
    if (pIns->HasAsyncLabel() && pIns->InSequence(IInstruction::IF_SEQ_C2B1) && (pPrev->GetForwardIns() == pIns)) {
        if (pIns->HasDeassertAsyncLabel()) {
            SetInterrupt(&m_vRequestedIntStack);
        }
        bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
        ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
        return true;
    }

    // Consecutive - Mismatch between RTL and CompRunner when enable cpu_stop. Please refer ticket #92188
    if ((g_cfg->m_cpuStopinTime != 0) && pPrev->GetId() == INS_ID_HALT && pIns->HasDeassertAsyncLabel()) {
        if (pIns->HasDeassertAsyncLabel()) {
            SetInterrupt(&m_vRequestedIntStack);
        }
        bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
        ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
        return true;
    }

    return false;
}


/**
*@brief	Store information about exception (return PC or code block of breakPC)
*@param	Exception cause code
*@param	pIns pointer to current executing instruction
*/
void CSimulatorControl::StoreExceptionInfo(UI32 cause_code, IInstruction* pIns, CCodeBlock* pCB) {

	static UI32 DBIdx[8] = {0, 0, 0, 0, 0, 0, 0, 0};
	static std::string sCurBlk[8] = {"", "", "", "", "", "", "", ""};
	UI64 DBevent[8]= {g_wm->DBTRAP_PC_INDEX, g_wm->DBTRAP_PC_INDEX + 2044, g_wm->DBTRAP_PC_INDEX + 2044*2, g_wm->DBTRAP_PC_INDEX + 2044*3,
			g_wm->DBTRAP_PC_INDEX + 2044*4, g_wm->DBTRAP_PC_INDEX + 2044*5, g_wm->DBTRAP_PC_INDEX + 2044*6, g_wm->DBTRAP_PC_INDEX + 2044*7};
	
	// Preset the return value for FEPC
	if (cause_code == 0xC0 /*MAE*/ || cause_code == 0xA0 /*PIE*/ || cause_code == 0x60 /*RIE*/ || cause_code == 0x71 /*FPE*/ || cause_code == 0x75 /*FXE*/ ||
		( cause_code >= 0x80 && cause_code <= 0x82 /*UCPOP*/ ) || 
		( cause_code > 0x10 && cause_code <= 0x1F && cause_code != 0x1c && cause_code != 0x18 /*SYSERR == 18, 1c is reexecute type*/)) 
	{ 
		UI64 Idxval;

		if (pIns->GetRiePartner() != nullptr) {
			m_pSim->ReadMemory( g_wm->EXP_RET_PC_INDEX , 4 , &Idxval );
			m_pSim->PresetMemory(true, 0, Idxval + 4, 4, 6);// RIE has size=6,implement by .word and .hword
		} else {
			m_pSim->ReadMemory( g_wm->EXP_RET_PC_INDEX , 4 , &Idxval );
			m_pSim->PresetMemory(true, 0, Idxval + 4, 4, pIns->GetLen());
		}

	}

	if (cause_code == 0xB1 /*DBTRAP*/) {
		UI32 gpid = 0;
		if (g_cfg->m_mGMs.size() > 1) {
			UI32 pswh = 0;
			m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
			gpid = (pswh >> 8) & 0x7;
		}
		
		std::string sBlkLabel = pCB->GetLabel();
		if (sBlkLabel.find("_codeblock_") != std::string::npos) {
			if (sBlkLabel != sCurBlk[gpid]) {
				//Each value was assigned for a code block.
				DBIdx[gpid] += 4;
				sCurBlk[gpid] = sBlkLabel;
				//Increase the store address
				DBevent[gpid] += 4;
				// Store to that index value
				m_pSim->PresetMemory(true, 0, DBevent[gpid], 4, DBIdx[gpid]);
			} else {
				//Increase the index value
				DBevent[gpid] += 4;
				// Store to that address
				m_pSim->PresetMemory(true, 0, DBevent[gpid], 4, DBIdx[gpid]);
			}

		} else {
			DBevent[gpid] += 4;
			m_pSim->PresetMemory(true, 0, DBevent[gpid], 4, 0);
		}
	}
}


/**
 * @brief
 * 
 * コードブロックのシミュレーションを実施する。
 * 
 */
bool CSimulatorControl::BlockSimulation(IBlockSimParam* p) {
	_ASSERT(m_pSim);
	_ASSERT(p);
	_ASSERT(p->pCodeBlock);

	UI32 break_point_weight = g_exp->GetBreakPointWeight(); // ブレークポイント生成比率取得
	CCodeBlock*		pBlk	= p->pCodeBlock;
	IInstruction*	pIns = nullptr;
    IInstruction*   pNewIns = nullptr;
    UI32 break_type = IBreakParam::BREAK_NONE;
    std::string labelStr;
#if DBGMODE
    std::stringstream ss;
#endif

	{	// Native Dataの展開
		std::vector<UI32> vndl = pBlk->GetNativeDataArray();
		for (UI32 i = 0; i < vndl.size(); i++) {
			IInstruction* pNd = pBlk->Fetch(vndl[i]);
			m_pSim->WriteMemory (vndl[i], pNd->GetLen(), (UI32)(*pNd->opr(0)));
		}
	}

	// take snapshot(for self-check verifier)
	if (pBlk->IsEnableSnapShot() && pBlk->GetSnapShot()==nullptr) {
		CSimResource* res = GetResource();
		pBlk->SetSnapShot(res); 
	}

	if(pBlk->GetLabel() == (GetPEContext() + "NM_memory_init") && m_bNewWRMemBlock) {
		IInstruction *pNewIns;
		std::stringstream ss;
		std::string label;
		m_bNewWRMemBlock = false;
        ss << GetPEContext();
		ss << "NMNT_wr_preset_memory_" << m_nWRMemBlockCount;
		ss << "_ret";
		ss >> label;
		pNewIns = MOV32P(label,11);
		pBlk->AddOpeCode(pNewIns);
		pNewIns = JMP32(11);
		pBlk->AddOpeCode(pNewIns);

		std::stringstream ss1;
        ss1 << GetPEContext();
		ss1 << "NMNT_wr_preset_memory_" << (m_nWRMemBlockCount + 1);
		ss1 >> label;
		pNewIns = NOP();
		pNewIns->SetLabel(label);
		pBlk->AddOpeCode(pNewIns);
		p->result.set(IBlockSimParam::BSR_REASM);
        return true; /* Re-Compile & Re-Sim */
	}

	while (true) {
		//!< Fetch Next Instrcution	
		pIns = pBlk->Fetch(p->ppc);
		if (pIns == NULL) {
			if ((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize()))) {
				MSG_ERROR(0, "Detected invalid PC={ LA:%08X, PA:%08X }\n", p->lpc, p->ppc);
				p->result.set(IBlockSimParam::BSR_FATALERROR);
				return false;	/* Sim Stop */
			}else{
				UI32 gpid = 0;
				if(g_cfg->m_mGMs.size() > 1) {
					UI32 pswh = 0;
					m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
					gpid = (pswh >> 8) & 0x7;
				}
                // Issue #2 on ticket #86972
  				if(pBlk->IsRegulation() && pBlk->GetBreakSetupInsFlag() && (p->bPrevChain == true)) {
				    if((p->pBreakParam[gpid].size() == 0) &&(p->pNotBreakParam[gpid].size() == 0)) {
                         // Create break point dummy
                        IBreakParam bparam = IBreakParam();
                        bparam.m_addr = 0xff; // Hit to ceate label
                        bparam.m_block_label = pBlk->GetLabel();
                        p->pBreakParam[gpid].push_back(bparam);
                        pBlk->SetBreakSetupInsFlag(false);
                    } else {
                        pBlk->SetBreakSetupInsFlag(false);
                    }
				}
				p->result.set(IBlockSimParam::BSR_JUMPING);
				p->result.set(IBlockSimParam::BSR_SUCCESS); 
				return true;	/* Jumped to other blocks */
			}
		}

        //!< BreakSetupInsert
		if(break_point_weight && (!pIns->GetValid())) {	// WeightがzeroならBreak対象としない
			if((! pBlk->GetBreakSetupInsFlag()) && pBlk->IsRegulation() && pBlk->GetHandlerAddress() == 0
				&& (pBlk->GetLabel().find("callt") == std::string::npos && pBlk->GetLabel().find("syscall") == std::string::npos 
				&& pBlk->GetLabel().find("th_end_sync") == std::string::npos )) {	// Exclude CALLT and SYSCALL block
                // ブレーク例外設定用DBTRAPをランダムコードブロックの先頭に挿入する
                pNewIns = new CIns_218_dbtrap();
                pNewIns->SetValid(true);
                pNewIns->AppendComment("for Break Setup");
				UI32 pos = ((pBlk->GetLabel().find("_00") == std::string::npos) ? 0 : 1);
                pBlk->AddOpeCode(pNewIns, pos); //! 0 for DBTAG 
                pBlk->SetBreakSetupInsFlag();

				UI32 tmpR = 10;
				pNewIns = MOV32(g_wm->BREAK_INFO_PRESET, tmpR);
				pNewIns->SetValid(true);
				pNewIns->AppendComment("for Break Setup");
				pBlk->AddOpeCode(pNewIns, pos); //! 0 for DBTAG

				pNewIns = STW16(tmpR,0,tmpR);
                pNewIns->SetValid(true);
				pNewIns->AppendComment("for Break Setup");
				pBlk->AddOpeCode(pNewIns, pos + 1); //! 0 for DBTAG
#if DBGMODE
                fprintf(stdout,"==> Insert DBTRAP into CodeBlock Top.\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
		}

		//!< Regulation (skip regulation of instruction in which fixed code, that has no constraint, and done.) 
        UI32 psw = GetPSW();

		if (pBlk->IsRegulation()){
			IInstruction *pTmp = pIns->GetRegulationTarget();
			if(pTmp != NULL && pTmp->InSequence(IInstruction::IF_SEQ_FWD) == false // MPU_Function was not generated as fowarding
				&& pTmp->GetId() == INS_ID_JARL && pIns->opr(0)->GetLabel() != nullptr) {
				std::string label(pIns->opr(0)->GetLabel());
				// Delete instruction that jump into code block that updates MPU config in UM mode
				if(label.find("mpu_function_") != std::string::npos && (psw & 0x40000000) != 0) {// UM mode
					IInstruction *pTargetIns = pIns->GetRegulationTarget();
					pTmp = pBlk->at(pBlk->GetIndex(pTargetIns) + 1);
					if(pTmp->GetLabel().size() == 0) {
						pIns->DirMoveTo(pTmp);
						pBlk->Remove(pIns); // Remove jarl's adjustment instruction.
						pBlk->Remove(pTargetIns); // Remove JARL instruction
					} else {
						pBlk->Remove(pTargetIns); // Remove JARL instruction
						pIns->SetRegulationTarget(NULL);
						pIns->opr(0)->SetLabel("");
						pIns->opr(0)->Replace(g_rnd.Get());
					}
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
			}
			
			if(pIns->GetValid() != true) {

				if (RegulateInsinAsyncTime(pBlk, pIns) == true){
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

                if (pBlk->GetHandlerAddress() == 0) {
                    if (RegulateLLbit(pBlk, pIns)) {
                        p->result.set(IBlockSimParam::BSR_REASM);
                        return true;
                    }
                }

				if (RegulateBranchCondition(pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				if (RegulateValueConstraint(pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				if(RegulateBeforeException(pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

                if (pIns->IsLDL_STC_CusIns()) {
                    GetLLbitInfor(pIns);
                }

            } else {

                if (pIns->GetId() == INS_ID_JARL /*CIns_82_jarl*/) {
                    std::string sJmpTarget = pIns->GetJumpTarget();
                    if (sJmpTarget.find("mpu_function_") != std::string::npos) {
                        CCodeBlock*	pcb = nullptr;
                        std::vector<INode*> FunctionList = g_asf->GetFunctionBlock();
                        std::vector<INode*>::iterator func_itr = FunctionList.begin();

                        for (; func_itr != FunctionList.end(); func_itr++) {
                            pcb = static_cast<CCodeBlock*>(*func_itr);
                            if (pcb->GetLabel() == sJmpTarget) break;
                        }

                        if (pcb->IsRegulation()) {
                            if (RegulateMPUupdate(pcb, (pIns->opr(1)->Idx())) == false) {
                                PrepareDeletedIns(pBlk, pIns);
                                pBlk->Remove(pIns);
                                p->result.set(IBlockSimParam::BSR_REASM);
                                return true; /* Re-Compile & Re-Sim */
                            }
                        }
                    }
                }
            }
		} else { // if(!pBlk->IsRegulation()){ // Generate preset memory for code block other than random code block.
			// Memory Init before first access! --> to create __preload codeblock.
			if ( pIns->Behavior(IInstruction::STORE_MEMORY) ) 
			{
				IOperand		*pOpr;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;
				for(UI32 nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++)
				{
					pOpr = pIns->opr(nOpr);
					pOpr->AlignData(m_pSim, PFETCHSIZE);
					
				}
			}

            // regulate adjustment code of LDSR (update MPM) in MPU update
            if (pBlk->GetLabel().find("mpu_function_") != std::string::npos && pIns->GetRegulationTarget() != nullptr) {
                UI32 new_mpm = (UI32)*(pIns->opr(0)) & 0x7;
                UI32 old_mpm = m_pSim->GetMPM();
                new_mpm |= (old_mpm & 0xfffffffc);
                UI32 PC = 0;
                m_pSim->ReadPC(&PC);
                m_pSim->SetMPM(new_mpm);
                // Check MIP at SYNCI
                if (IsMIPexception(PC + 6, 0x2) != NO_ERROR) {
                    pIns->opr(0)->Replace(old_mpm);
                } 
                m_pSim->SetMPM(old_mpm);
            }
		}

        //!< BreakSet
		if(break_point_weight && pBlk->GetBreakSetupInsFlag() && !pBlk->GetBreakSetupDone() && pBlk->GetHandlerAddress() == 0 && !pIns->InSequence(IInstruction::IF_SEQ_DCU)) {
          
			if((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize())) && (pBlk->IsRegulation()) && (! p->bDebugExcep) && (pIns->GetId() != INS_ID_DBT)) {
               
                if(( pIns->GetRegulationTarget() == nullptr ) && ( ! pIns->m_bBreakTargetIns ) && ( ! pIns->m_bBreakInsertIns )) {
                    if( pIns->m_bBreakCheckDone ) {
                        break_type = IBreakParam::BREAK_NONE;
                    } else {
                        break_type = GenerateBreakPointBeforeSetup(p,pIns,pBlk);
                        pIns->m_bBreakCheckDone = true;
 
                        if( break_type != IBreakParam::BREAK_NONE ) {
                            pIns->m_bBreakTargetIns = true;

                        }
                    }
                }
            }

            if( break_type == IBreakParam::BREAK_AE ) {
				UI32 AddrReg = 3;
				UI32 insId = pIns->GetId();
				if (insId == INS_ID_STM_GSR || insId == INS_ID_LDM_GSR || insId == INS_ID_LDM_MP)
					AddrReg = pIns->opr(0)->Idx();
				if (insId == INS_ID_STM_MP)
					AddrReg = pIns->opr(2)->Idx();

                UI32 RegVal = 0;
                m_pSim->ReadGrReg(&RegVal, AddrReg, 0);
                if ((RegVal & 0x00000001) == 0) {
                    pNewIns = ORI(0x1, AddrReg, AddrReg);
                    pNewIns->SetValid(true);
                    pNewIns->AppendComment(" for Break_AE ");
                    if (pIns->GetId() != INS_ID_DISPOSE_R3)
                        pIns->SetValid(true);
                    pIns->OnlyDirMoveTo(pNewIns);
                    pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                    pNewIns->m_bBreakInsertIns = true;
#if DBGMODE
                    fprintf(stdout, "==> Insert ori instruction for Break_AE\n");
#endif
                }
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
        }

		break_type = IBreakParam::BREAK_NONE;

		//Remove gap code if there are an increase in the size of code 
		if (pBlk->GetCodeSize() != pBlk->m_orgsize && pBlk->IsRegulation()) {
			if (pBlk->RecoverCodesize(pIns)) {
				p->result.set(IBlockSimParam::BSR_REASM);
				return true; /* Re-Compile & Re-Sim */
			} else if (pBlk->GetCodeSize() > pBlk->m_orgsize && pBlk->IsRegulation()) {
				MSG_ERROR(0, "Not enought Gap Code at : \"%s\"\n", pIns->GetCode().c_str());
				p->result.set(IBlockSimParam::BSR_FATALERROR); 
				return false; /* Sim Stop */
			}
		}

        InitmemoryforInterrupt(pIns);

		//!< Regulation done!
        pIns->SetValid(true);

        // The interrupt is asserted/de-asserted before rollback.
		auto IsRequested = [=] (IInstruction *pIns) -> bool {
			std::vector<IInstruction*>::iterator itr;
			itr = std::find_if(m_vRequestedIns.begin(), m_vRequestedIns.end(), [=](IInstruction *p) {return (p == pIns);});
			if(itr == m_vRequestedIns.end())
				return false;
			return true;
		};
		if(m_bRollback && pIns == m_pRollbackIns) {
			if(m_vRequestedIns.back() == m_pRollbackIns) {
				m_vRequestedIns.pop_back();
				m_vRequestedIns.push_back(pIns);
			}
			m_pRollbackIns = NULL;
		}

        if (( pBlk->GetHandlerAddress() == IBlockManager::ADR_VECTOR_BGINT || pBlk->IsRegulation()) && !IsRequested(pIns)) {
            // Update status of pending interrupt, just in random code block
            if (pBlk->GetHandlerAddress() == 0) {
                for (auto itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
                    CIntInfo* p = *itr;
                    if (p->nPeriod > 0)
                        p->nPeriod--;
                    if (p->nClear == CIntInfo::ASYNC_CLEAR_REJECT)
                        p->nClear = CIntInfo::ASYNC_CLEAR_NONE;
                }
            }

            CheckInterruptRequest(pBlk, pIns);
            // Update interrupt  timer base on random instruction.
            if (pBlk->GetHandlerAddress() != IBlockManager::ADR_VECTOR_BGINT)
                UpdateAssertINTatTime();

        }

#if DBGMODE
        {
            UI32       nOpr = 0;
            IOperand*  pOpr = nullptr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintRetVal(m_pSim, ss);
            }
        }
#endif
		
		//!< Send operation code.
		ISimulatorStepResp res;
		if (Step(0, p->lpc, p->ppc, pIns, &res) == false) {
			UI32 code = 0;
			m_pSim->GetErrorInfo(&code);
			if (code == ERR_THREAD_IS_HALT) {
				// Exit successfully
				// TODO: TO BE FIXED ( On multi thread )
				p->result.set(IBlockSimParam::BSR_EXIT_SUCCESS);
				return true;/* Sim Complete */
			}
			MSG_ERROR(0, "Simulation failed (%08X) : \"%s\"\n", code, pIns->GetCode().c_str());
			p->result.set(IBlockSimParam::BSR_FATALERROR); 
			return false; /* Sim Stop */
		}
#if DBGMODE
        {
            UI32       nOpr = 0;
            IOperand*  pOpr = nullptr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintGetVal(m_pSim, ss);
            }
        }
#endif

		//!< Exception Handling --> No operation for any exceptions without counting for report.
		if (res.exception) {
			IExceptionConfig* pExp = IdentifyException(p->pException, (res.exception & 0x0ffff));
            if (pExp != NULL) {
                UI32 cause_code = (res.exception & 0x0ffff);
                StoreExceptionInfo(cause_code, pIns, pBlk);

                // Set interrupt/exception information
                SetException(pIns, pExp, pBlk);

                //!< BreakSet
                if (break_point_weight && pBlk->GetBreakSetupInsFlag() && !pBlk->GetBreakSetupDone() && pBlk->GetHandlerAddress() == 0) {	// WeightがzeroならBreak対象としない
                    UI32 gpid = 0;
                    if (g_cfg->m_mGMs.size() > 1) {
                        UI32 pswh = 0;
                        m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
                        gpid = (pswh >> 8) & 0x7;
                    }
                    // The condition of the instruction subject to break generation is prefetch even in the DBTRAP instruction in the random code block? (The next instruction of DBTRAP)
                    if ((pBlk->IsRegulation()) && (!p->bDebugExcep)) {
                        UI32 cause_code = (res.exception & 0x0ffff);
						
                        if ((pExp->m_id == IException::EXP_EITBL) || (pExp->m_id == IException::EXP_GMEITBL) || cause_code == 0x95 /*MDP*/ || cause_code == 0x9d /*MDP_HM*/ || cause_code == 0x1c /*SYSERR*/) {
							// Generate a breakpoint and corresponding parameter
                            break_type = GenerateBreakPointBeforeSetup(p, pIns, pBlk);
                            if (break_type == IBreakParam::BREAK_LSAB) {
                                pIns->m_bBreakTargetIns = true;
                                pIns->m_bBreakCheckDone = true;
                            } else if (break_type != IBreakParam::BREAK_NONE) {
                                if (break_type == IBreakParam::BREAK_AE || break_type == IBreakParam::BREAK_SS)
                                    p->pNotBreakParam[gpid].pop_back();
                                else
                                    p->pBreakParam[gpid].pop_back();

                                // Remove breakpoint label that has set.
                                if (break_type == IBreakParam::BREAK_PCB || break_type == IBreakParam::BREAK_AE) {
                                    UI32 nDirNum = pIns->GetDirectiveNum();
                                    IDirective *pDir = pIns->GetDirective(nDirNum - 1);
                                    pIns->RemoveDirective(pDir);
                                }
                                break_type = IBreakParam::BREAK_NONE;
                            }
                        }
                    }
                }

                p->pException->CountUp(pExp->m_id);
            }
			
		} else { // TODO: Delete the couple if excetion occur at some instructions that make the instruction be not executed
			// The random code that using for Overwrite precision error (not LDL)
			if (pIns->GetCoupleIns() != nullptr && pIns->GetMne().find("ldl") == std::string::npos) {
				IInstruction* pOverW = pIns->GetCoupleIns();
				if (pOverW->GetComment().find("Overwrite precision error")) {
					pIns->SetCoupleIns(nullptr);
					pBlk->Remove(pOverW);
					pBlk->Update();
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
			}
            if (pBlk->IsRegulation()) {
                m_nPreciMismatchReg &= ~(UI64)((UI64)(pIns->GetWrDst()) << 32);
                m_nPreciMismatchReg &= ~(UI64)(pIns->GetGrDst());
                m_nPreciMismatchReg |= pIns->GetOprIdxMistmatch();

                UI32 m_nMismatchRegSet = g_mgr->GetMismatchReg();
                if (m_nMismatchRegSet != 0) {
                    const std::string &mne = pIns->GetMne();
                    if (mne == "clr1" || mne == "not1" || mne == "set1" || mne == "tst1") {
                        m_nPreciMismatchFlag |= IInstruction::INS_FLG_Z;
                    } else if (mne == "caxi") {
                        m_nPreciMismatchFlag |= (IInstruction::INS_FLG_Z | IInstruction::INS_FLG_S | IInstruction::INS_FLG_OV | IInstruction::INS_FLG_CY);
                    } else {
                        m_nPreciMismatchFlag &= ~(pIns->UpdateFlag());
                    }
                }
            }
        }
		m_bRollback = false;
		// Set constraint for second instruction in forwarding
		if(pIns->Behavior(IInstruction::LOAD_MEMORY) && pIns->GetForwardIns() != nullptr) {
			IInstruction *pFW = pIns->GetForwardIns();
			if (pFW->Behavior(IInstruction::LOAD_MEMORY) | pFW->Behavior(IInstruction::STORE_MEMORY)) {
				IOperand * pOpr = nullptr;
				for(UI32 i = 0; i < pFW->GetOpNum(); i++) {
					if(pFW->opr(i)->GetConstraint() != NULL && (pFW->opr(i)->GetConstraint()->GetType(IValConstraint::DUMMY))){
						pOpr = pFW->opr(i);
						break;
					}
				}
				if (pOpr != nullptr) {
					UI32 val = 0;
					m_pSim->ReadGrReg(&val, pOpr->Idx(), 0);
					UI32 size = pOpr->GetConstraint()->GetSize();
					UI32 mask = pOpr->GetConstraint()->GetMask();
					pOpr->RemoveConstraint(); // Remove dummy constraint
					IValConstraint* pVc = new INumConstraint(val, val, mask, size);
					if (val % size)	pVc->Unalign();
					pOpr->SetConstraint(pVc);
				}
			}
		}

        //!< GetBreakInfo
        // デバッグ例外発生対象命令ならば、ブレークパラメータを設定する 
        if( pIns->m_bBreakTargetIns ) {
            GenerateBreakPointSetup(p,pIns,pBlk);
			pIns->m_bBreakTargetIns = false;
		}
// -- Debug print
#if LOGSW_INS_SIM
		{
			UI32 psw; m_pSim->ReadNcReg(&psw, 5, 0);
			std::cout << '[';
			std::cout << ((psw & 0x80000000) ? 'V':'N'); 
			if ((psw & 0x80000000) == 0) {
				std::cout << ((psw & 0x40000000) ? 'U':'S'); 
				std::cout << ((psw & 0x00010000) ? '0':'-'); 
				std::cout << ((psw & 0x00020000) ? '1':'-'); 
				std::cout << ((psw & 0x00040000) ? '2':'-');
				std::cout << ':';
				std::cout << ((psw & 0x00000010) ? 'A':'-');
				std::cout << ((psw & 0x00000008) ? 'C':'-');
				std::cout << ((psw & 0x00000004) ? 'V':'-');
				std::cout << ((psw & 0x00000002) ? 'S':'-');
				std::cout << ((psw & 0x00000001) ? 'Z':'-');
			}else{
				UI32 vsw; m_pSim->ReadTcReg(&vsw, 5, 0, 0);
				std::cout << ((vsw & 0x40000000) ? 'U':'S'); 
				std::cout << ((vsw & 0x00010000) ? '0':'-'); 
				std::cout << ((vsw & 0x00020000) ? '1':'-'); 
				std::cout << ((vsw & 0x00040000) ? '2':'-');
				std::cout << ':';
				std::cout << ((vsw & 0x00000010) ? 'A':'-');
				std::cout << ((vsw & 0x00000008) ? 'C':'-');
				std::cout << ((vsw & 0x00000004) ? 'V':'-');
				std::cout << ((vsw & 0x00000002) ? 'S':'-');
				std::cout << ((vsw & 0x00000001) ? 'Z':'-');
			} 
			std::cout << "]: ";
			
			UI32 tabstop = pBlk->IsRegulation() ? 8 : 12;
			std::cout << std::hex << std::setw(tabstop) << std::setfill(' ') << p->lpc << "(L):" << std::setw(tabstop) << std::setfill(' ') << p->ppc<<"(P)";
			std::cout << (((pIns->GetComment().find("Regulation")) == std::string::npos) ? " : " : " ! ");
			std::cout << pIns->GetCode();

			if (0) {
				std::bitset<32> r = pIns->GetGrSrc();
				std::bitset<32> w = pIns->GetGrDst();
				std::cout << "\tR:" << r << " W:" << w;
			}
            std::cout << " # " << ss.str() << std::endl;
            ss.str(""); ss.clear(std::stringstream::goodbit);
		}
#endif
		// -- Debug print

        // Debug Exception Flag set/reset
        switch( pIns->GetId() ) {
        case INS_ID_DBT: // DBTRAP
        case INS_ID_RMT: // RMTRAP
            p->bDebugExcep = true;
            break;
        case INS_ID_DBRET: // DBRET
            p->bDebugExcep = false;
            break;
        }

		// PC Update
		p->bPrevChain = pIns->GetChain(); // コードブロック終端判定用
		if (DecodeAddress(res.pc, &p->lpc, &p->ppc) != true) {
			MSG_ERROR(0, "Fail to transfer PC(LA:%08X)\n", p->lpc);
			return false; /* Sim Stop */
		}
	}
	
	p->result.set(IBlockSimParam::BSR_FATALERROR);
	return false; /* Sim abended */
}

/**
 *	@brief
 * 
 *	リソースデータを抽出する。
 * 
 */
CSimResource* CSimulatorControl::GetResource () {

	// Prepare
	CSimResource* res = new CSimResource();

	ISimulatorHwInfo si;
	if (m_pSim->GetSimulatorInfo(si) != true) {
		delete res;
		return nullptr;
	}
	const UI32 V = si.m_vmnum;
	const UI32 T = si.m_htnum;

	// Get GR
	for (UI32 t = 0; t < T; t++) {
		GRSET gset;
		for (UI32 r = 0; r < 32; r++) {
			UI32 val;
			m_pSim->ReadGrReg(&val, r, t);
			gset.push_back(val);
		}
		res->m_gr.push_back(gset);
	}

	// Get VR
	if (0) {
		for (UI32 t = 0; t < T; t++) {
			VRSET vset;
			for (UI32 r = 0; r < 32; r++) {
				UI64 val;
				m_pSim->ReadVeReg(&val, r, t);
				vset.push_back(val);
			}
			res->m_vr.push_back(vset);
		}
	}

	// Get SR
	std::vector <BKREG> sr;
	std::vector <BKREG>::iterator i;
	g_srs->MatchContext (0/* CSysReg::SR_CONTEXT_NC */, &sr);
	// Verify対象のNCSRを取得したので、SIMから期待値を取得
	for (i = sr.begin(); i != sr.end(); ++i) {
		UI32 val = 0;
		m_pSim->ReadNcReg(&val, (*i) & 0x1f,  (*i)>>5);
		res->m_nc.push_back( SRVAL(*i, val) );
	}
	//std::cout << res->m_nc.size();
		
	sr.clear();
	g_srs->MatchContext (1/* CSysReg::SR_CONTEXT_VC */, &sr);
	for (UI32 v = 0; v < V; v++) {
		SRSET vs;
		for (i = sr.begin(); i != sr.end(); ++i) {
			UI32 val;
			m_pSim->ReadVcReg(&val, (*i)&0x1f,  (*i)>>5, v);
			vs.push_back( SRVAL(*i, val) );
		}
		res->m_vc.push_back(vs);
	}

	sr.clear();
	if (V > 0) {
		g_srs->MatchContext (2/* CSysReg::SR_CONTEXT_TC*/, &sr);
		for (UI32 t = 0; t < T; t++) {
			SRSET ts;
			for (i = sr.begin(); i != sr.end(); ++i) {
				UI32 val;
				m_pSim->ReadTcReg(&val, (*i)&0x1f,  (*i)>>5, t);
				ts.push_back( SRVAL(*i, val) );	
			}
			res->m_tc.push_back(ts);
		}
	}	

	m_pSim->GetMemoryWritenData(&res->m_logs);

	if (1) {
		std::ofstream ofs;
		ofs.open("expected.res");
		ofs << (*res);
		ofs << std::endl;
		ofs.close();
	}	
	
	return res;
}

bool CSimulatorControl::IsFirstRegulationIns(CCodeBlock* pCB, IInstruction* pIns) {
    IInstruction *pPrev = nullptr;
    UI32 nInsPos = 0;

    // The first instruction of CB
    nInsPos = pCB->GetIndex(pIns);
    if (nInsPos == 0)
        return true;

    // Not the first regulation instruction
    pPrev = pCB->at(nInsPos - 1);
    if (pPrev->GetRegulationTarget() != NULL)
        return false;

    return true;
}

bool CSimulatorControl::HasGapBetweenJumpAndDest(CCodeBlock* pCB, IInstruction* pIns) {

    UI32 PC = 0;
    m_pSim->ReadPC(&PC);

    std::string TargetJump = pIns->GetJumpTarget();
    UI32 TargetAddress = g_asf->SearchAddress(TargetJump);
    IInstruction* TargetIns = pCB->Fetch(TargetAddress);

    if (PC < TargetAddress && TargetIns != nullptr) {
            UI32 dstId = pCB->GetIndex(TargetIns);
            bool hasGap = true;
            for (UI32 n = pCB->GetIndex(pIns); n < dstId; n++) {
                std::string sfoot = pCB->at(n)->GetLabel();
                if (sfoot.find("foot") != std::string::npos) {
                    hasGap = false;
                    break;
                }
            }
            if (hasGap) return false;
    }

    return true;
}

UI32 CSimulatorControl::FindSuitableReg(CCodeBlock* pCB, IInstruction* pIns) {
    UI32 ban_reg = (UI32)(m_nPreciMismatchReg & 0xffffffff);

    // Avoid overwrite register store memory address or reg jump
    ban_reg |= pIns->GetGrSrc();

    if (pIns->Behavior(IInstruction::JMP)) {
        IInstruction* seqJmp = (pIns->GetSequentialIns().size() > 0 ? pIns->GetSequentialIns().back() : nullptr);
        if (seqJmp != nullptr)  ban_reg |= seqJmp->GetGrSrc();
    }

    if (pIns->InLoop() || pIns->GetId() == INS_ID_LOOP) {
        UI32 start_loop = pCB->GetIndex(pIns);
        IInstruction* ptempIns = pIns;

        while (ptempIns->GetLabel().find("_Lp_") == std::string::npos && start_loop != 0) {
            start_loop--;
            ptempIns = pCB->at(start_loop);
        }

        for (UI32 i = start_loop; i < pCB->GetInstructionNum(); ++i) {
            ptempIns = pCB->at(i);
            if (ptempIns->GetId() == INS_ID_LOOP) {
                ban_reg |= (1 << ptempIns->opr(0)->Idx());
                break;
            } else {
                ban_reg |= ptempIns->GetConstraintBit();
                ban_reg |= ptempIns->GetGrDst();
            }
        }
    }

    UI32 regbit = ~ban_reg & 0xfffffffe;
    return regbit;
}


bool CSimulatorControl::SelectRegForLDL_STC(UI32 reglist, LDL_STC_CusIns_Sim* lspsim, UI32 LLBit) {

    std::set<UI32>::iterator itr_randomlist;
    UI32 index = 0;
    std::set<UI32> sRandomList;

    for (UI32 i = 1; i < 32; ++i) {
        reglist = reglist >> 0x1;
        if (reglist & 0x1) {
            sRandomList.insert(i);
        }
    }
    if (sRandomList.size() < 2) {
        return false;
    }

    index = g_rnd.GetRange(0U, (UI32)sRandomList.size() - 1);
    itr_randomlist = sRandomList.begin();
    std::advance(itr_randomlist, index);

    lspsim->LLBitSTC[LLBit].STCSourReg = *itr_randomlist;
    sRandomList.erase(itr_randomlist);

    index = g_rnd.GetRange(0U, (UI32)sRandomList.size() - 1);
    itr_randomlist = sRandomList.begin();
    std::advance(itr_randomlist, index);
    lspsim->LLBitSTC[LLBit].STCDestReg = *itr_randomlist;

    return true;
}

void CSimulatorControl::GetLLbitInfor(IInstruction* pIns) {

    IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
    LDL_STC_CusIns_Sim* lspsim = &m_stLDL_STC_Sim;

    auto IsMAE = [=]() -> bool {
        IValConstraint* pVc = pIns->opr(0)->GetConstraint();

        if (pVc->m_nUnA > 0) {
            return true;
        }
        return false;
    };
    //------------------------------------------------------------
    // lambda : LDL_STCInitValue
    //------------------------------------------------------------
    //        Init value for starting sequence insert stc instruction. 
    //------------------------------------------------------------
    auto LDL_STCInitValue = [&](IInstruction* pIns, UI32 LLBit, UI32 Address, LDL_STC_CusIns_Sim* lspsim) {
        LLBit--;
        //!< Checking init value at the first time when staring sequence. 
        if ((lspsim->LLBitSTC[LLBit].InSTCSequence == false)) {
            //!< Init value for LDL_STC sequence.
            lspsim->LLBitSTC[LLBit].STCTargetPosition = lspsim->m_nSTCTargetCounter + g_rnd.GetRange(0, 0x10);
            lspsim->LLBitSTC[LLBit].STCAddress = Address;
            lspsim->LLBitSTC[LLBit].IsSTCSuccess = pIns->IsSTCSuccess();

            char buff[32];
            sprintf(buff, "%#x", lspsim->LLBitSTC[LLBit].STCTargetPosition);
            lspsim->LLBitSTC[LLBit].pInsSTC = pIns->GetCoupleIns();
            lspsim->LLBitSTC[LLBit].pInsSTC->AppendComment(buff);
            lspsim->LLBitSTC[LLBit].pInsLDL = pIns;
            pIns->AppendComment(buff);
        }
    };

    if (IsMAE() == false) {
        UI32 nAddress = 0;
        if (m_pSim->ReadGrReg(&nAddress, (SI32)pIns->opr(0)->Idx(), r.m_ht) != true) {
            std::runtime_error excep("Simulator error : Read GR");
            throw excep;
        }
        UI32 LLBitNum = g_LnkBitAddr->GetLnk(nAddress);
        if (LLBitNum != 0) {
            // Init value of sequence at starting time.
            LDL_STCInitValue(pIns, LLBitNum, nAddress, lspsim);
        }
    }
}
/**
 *	@brief
 * 
 *	This function regulate special custom instruction。
 * 
 */
bool CSimulatorControl::RegulateLLbit(CCodeBlock* pCB, IInstruction* pIns) {

	_ASSERT(pCB);
	_ASSERT(pIns);

	LDL_STC_CusIns_Sim* lspsim = &m_stLDL_STC_Sim;
    const UI32 LLBitMax = 2;

	//!< Update LLBit vector from Undo buffer.
	m_pSim->GetLLBitData(&(lspsim->m_vLLBitData));
    if (lspsim->m_vLLBitData.empty()) {
        for (UI32 LLBitNum = 0; LLBitNum < LLBitMax; ++LLBitNum) {
            lspsim->LLBitSTC[LLBitNum].LLBit = false;
        }
    }

	while ( lspsim->m_vLLBitData.size()) {
		lspsim->m_stLLBitData = lspsim->m_vLLBitData.back();
		lspsim->m_vLLBitData.pop_back();
		
		//!< Update LLBit status.
		UI32 LLBitNum = g_LnkBitAddr->GetLnk (lspsim->m_stLLBitData.m_address);
		if (LLBitNum != 0 ) {
			LLBitNum--;
			if (lspsim->LLBitSTC[LLBitNum].STCAddress == lspsim->m_stLLBitData.m_address) {
				lspsim->LLBitSTC[LLBitNum].LLBit = true;
			    lspsim->LLBitSTC[LLBitNum].InSTCSequence = true;
			} else {
				lspsim->LLBitSTC[LLBitNum].LLBit = false;
			}
		}
	}

	//!< Update position of instruction.
    if (pIns->IsRandomIns()) { 
        lspsim->CounterLDL_STC_Target(pIns);
    }

	//!< Sequence Checking to Update ldl status then generating stc instruction.	
	for (UI32 i = 0; i < LLBitMax; i++) {
		if (lspsim->LLBitSTC[i].InSTCSequence ) {
			//!< Check condition and insert stc Ins.
			if (InsertSTCforSuccessFail( pCB, pIns,i,lspsim)) {
				return true;
			}
		}
	}

	return false;
}
/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::InsertSTCforSuccessFail(CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {

    auto IsSpecicalIns = [=]() -> bool {
        UI32 insid = pIns->GetId();
        bool SpecicalIns = (pIns->GetMne() == ".word" || pIns->GetMne() == ".hword" || insid == INS_ID_EIRET || insid == INS_ID_FERET || insid == INS_ID_CTRET);
        if (pIns->GetRegulationTarget() == NULL) {
            SpecicalIns |= pIns->InSequence(IInstruction::IF_SEQ_FWD) | pIns->InSequence(IInstruction::IF_SEQ_C2B1)
                        | pIns->InSequence(IInstruction::IF_SEQ_RECOVERY) | pIns->InSequence(IInstruction::IF_SEQ_DCU);
        } else {
            SpecicalIns |= pIns->GetRegulationTarget()->InSequence(IInstruction::IF_SEQ_FWD) | pIns->GetRegulationTarget()->InSequence(IInstruction::IF_SEQ_C2B1);
        }

        if (pIns->Behavior(IInstruction::JMP) && pIns->GetJumpTarget().size()) {
            if (pIns->InLoop()) {
                SpecicalIns = true;
            } else if (HasGapBetweenJumpAndDest(pCB, pIns) == false) {
                SpecicalIns = true;
            }
        }

        if (insid == INS_ID_LOOP) {
            UI32 index = pCB->GetIndex(pIns);
            IInstruction* pPrev = pCB->at(index - 1);
            SpecicalIns |= (pPrev->GetRegulationTarget() == pIns);
        }

        UI32 insIdx = pCB->GetIndex(pIns);
        if (insid == INS_ID_SYNCI && insIdx != 0) {
            IInstruction* pPrev = pCB->at(insIdx - 1);
            SpecicalIns |= ( (pPrev->GetId() == INS_ID_LDSR) | (pPrev->GetId() == INS_ID_LDM_MP) );
        }

        return SpecicalIns;
    };

    auto GenerateSTC = [&]() {
        // Adjust address.
        bool InLoop = (pIns->InLoop() || pIns->GetId() == INS_ID_LOOP);
        UI32 addr = lspsim->LLBitSTC[LLBit].STCAddress;
        IInstruction* pNewIns = MOV32(addr, lspsim->LLBitSTC[LLBit].STCDestReg);
        pIns->DirMoveTo(pNewIns);
        pNewIns->SetRegulationTarget(lspsim->LLBitSTC[LLBit].pInsSTC);
        pNewIns->AppendComment(" Regulate for STC ");
        pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
		
        lspsim->LLBitSTC[LLBit].pInsSTC->SetInLoop(InLoop);
        lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Replace(lspsim->LLBitSTC[LLBit].STCSourReg);
        lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Replace(lspsim->LLBitSTC[LLBit].STCDestReg);
        // Support access competitive memory
        UI32 size = lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->GetConstraint()->GetSize();
        lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->SetConstraint(new IDummyConstraint(size - 1, size));
        pCB->AddOpeCode(lspsim->LLBitSTC[LLBit].pInsSTC, pCB->GetIndex(pIns));

        lspsim->LLBitSTC[LLBit].Reset();
    };
	//------------------------------------------------------------
	// lambda : InsertSTCSuccess
	//------------------------------------------------------------
	//        Find condition and insert stc for successfull case. 
	//------------------------------------------------------------
	auto InsertSTCSuccess = [&] ( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {	
		//!< Checking exceed max step or found clear LLBit condition. 
		if ((lspsim->m_nSTCTargetCounter > lspsim->LLBitSTC[LLBit].STCTargetPosition) || (PredictLLBitInNextIns(pCB,pIns,LLBit,lspsim))) {
			if (IsSpecicalIns()) {
				lspsim->LLBitSTC[LLBit].STCTargetPosition++;

			} else {			
				if (lspsim->LLBitSTC[LLBit].LLBit) {					
                    UI32 reglist = FindSuitableReg(pCB, pIns);
                    reglist &= (~g_mgr->GetMismatchReg());
                    if (SelectRegForLDL_STC(reglist, lspsim, LLBit) == false) {
                        lspsim->LLBitSTC[LLBit].Reset();
                        return false;
                    }

                    GenerateSTC();

					return true;
				} else  {
					lspsim->LLBitSTC[LLBit].Reset();
				}
			}
		}

		return false;
	};

	//------------------------------------------------------------
	// lambda : InsertSTCFail
	//------------------------------------------------------------
	//        Find condition and insert stc for false case. 
	//------------------------------------------------------------
	auto InsertSTCFail = [&] ( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
		//!< Checking exceed max step. 
        
		if ((lspsim->m_nSTCTargetCounter > lspsim->LLBitSTC[LLBit].STCTargetPosition) || (!lspsim->LLBitSTC[LLBit].LLBit)) {
			if (IsSpecicalIns()) {
				lspsim->LLBitSTC[LLBit].STCTargetPosition++;

			} else {
				if (!lspsim->LLBitSTC[LLBit].LLBit) {
					//Interrup exception occur in force instruction.
					if ((pIns == lspsim->LLBitSTC[LLBit].pInsForce) || (lspsim->m_pInsExp == pIns) || (pIns->GetRegulationTarget() != NULL && !IsFirstRegulationIns(pCB, pIns))) {
						return false;
					}

                    UI32 reglist = FindSuitableReg(pCB, pIns);
                    reglist &= (~g_mgr->GetMismatchReg());
                    if (SelectRegForLDL_STC(reglist, lspsim, LLBit) == false) {
                        lspsim->LLBitSTC[LLBit].Reset();
                        return false;
                    }

                    GenerateSTC();

					return true;
				} else {
					//!< Force LLBit clear.	
					if (!lspsim->LLBitSTC[LLBit].ForceSTCFail) {
						if (ForceClearLLBit (pCB, pIns,LLBit,lspsim)) {
							return true;
						}
					}
				}	
			}
		}
		
		// Intruction cause Interrupt/Exception.
		lspsim->m_pInsExp = pIns;
		return false;
	};
	
	/*
	 Function starting here.
	*/
	//!< Checking and generating stc instruction.
	if (lspsim->LLBitSTC[LLBit].IsSTCSuccess) {
		return InsertSTCSuccess(pCB,pIns,LLBit,lspsim);
	} else {
		return InsertSTCFail(pCB,pIns,LLBit,lspsim);
	}
}
/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::PredictLLBitInNextIns( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
	 
	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	//!< Check .
	UI32 nSTCaddress = lspsim->LLBitSTC[LLBit].STCAddress;
	std::string sMneIns = pIns->GetMne();
	bool bClearLLBit = false;
	UI32 cRange32Byte = 0xFFFFFFE0; 
	
	/*
	 @Brief  - Checking momery range 32 byte access.
			 - Pridiction condition 1.
	*/
	// Checking memory access of ST kind instructions.
	if ((sMneIns == "st.b") || (sMneIns == "st.h") || (sMneIns == "st.w") || (sMneIns == "st.dw")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of SSTC kind instructions.
	if ((sMneIns == "sst.b") || (sMneIns == "sst.h") || (sMneIns == "sst.w")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		naddress+= (UI32)(*pIns->opr(1));
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of VST instruction.
	if ((sMneIns == "vst.b") || (sMneIns == "vst.h") 
		|| (sMneIns == "vst.w") || (sMneIns == "vst.dw")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}

		//TODO [NP]: Need to check modulo address calculating.
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of SET1 & NOT1 & CLR1 instruction.
	if ((sMneIns.find("set1") != std::string::npos) || (sMneIns.find("not1") != std::string::npos) || (sMneIns.find("clr1") != std::string::npos) ) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		SI32 nImm = (SI32)((UI32)(*pIns->opr(1))); // if Disp 16 return Imm else return 0.
		naddress += nImm; 
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}	
	}
	// Checking access of CAXI instruction.
	if (sMneIns.find("caxi") != std::string::npos) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true){
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		} 
	}
	// Remain prepare and push instruction.
	
	/*
	 @Brief  - Using clear CLL Instruction.
			 - Pridiction condition 2.
	*/
	if ((sMneIns == "cll") || (sMneIns == "est") ||(sMneIns == "dst") ) {
		bClearLLBit = true;
	}

	/*
	 @Brief  - FE/IE return Instruction.
			 - Pridiction condition 3.
	*/
	if (pIns->GetRegulationTarget() != NULL ) {
		if ((pIns->GetRegulationTarget()->GetMne() == "feret") || (pIns->GetRegulationTarget()->GetMne() == "eiret")) {
			bClearLLBit = true;
		}
	}
	/*
	 @Brief  - LDL STC With difference type and address access.
			 - Pridiction condition 4.
	*/
	if (sMneIns == "ldl.w") {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true){
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		
		UI32 LLBitNum = g_LnkBitAddr->GetLnk (naddress);
		UI32 nLLBit   = (LLBit+1);
		if (LLBitNum == nLLBit) {
			bClearLLBit = true;
		}
	}

	if (sMneIns == "stc.w") {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
			
		UI32 LLBitNum = g_LnkBitAddr->GetLnk (naddress);
		UI32 nLLBit   = (LLBit+1);
		if (LLBitNum == nLLBit) {
			bClearLLBit = true;
		}
	}

    for (UI32 handlerAddr = IBlockManager::ADR_VECTOR_RESET; handlerAddr < IBlockManager::ADR_VECTOR_NUM; handlerAddr += 0x10) {
        if (PredictException(pCB, pIns, handlerAddr)) {
            bClearLLBit = true;
        }
    }
	//[FROG]TODO Support predict handler. 

	// Checking access of 
	if (bClearLLBit) {
		return true;
	} else {
		return false;
	}
}

/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::ForceClearLLBit( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
    bool InloopSequence = (pIns->InLoop() || pIns->GetId() == INS_ID_LOOP);
	
    UI32 reglist = FindSuitableReg(pCB, pIns);
    reglist &= (~g_mgr->GetMismatchReg());
    if (SelectRegForLDL_STC(reglist, lspsim, LLBit) == false) {
        lspsim->LLBitSTC[LLBit].Reset();
        return false;
    }
	//------------------------------------------------------------
	// lambda : AccessToRange32Byte
	//------------------------------------------------------------
	//     Insert into store instruction access to range 32 byte protected.  
	//------------------------------------------------------------
    auto AccessToRange32Byte = [&](CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) -> bool {
		
		const UI32 cRange32Byte = 0xFFFFFFE0;
		UI32 nAccessAddress = (lspsim->LLBitSTC[LLBit].STCAddress & cRange32Byte);
		UI32 nRegSTCDest = lspsim->LLBitSTC[LLBit].STCDestReg;
		UI32 nRegSTCSour = lspsim->LLBitSTC[LLBit].STCSourReg;
		IInstruction* pNewIns = nullptr;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());

		UI32 ncase;
        IValConstraint *pConst;
		
        if ((m_nPreciMismatchReg & 0xfffffffe) != 0) {
            ncase = g_rnd.GetRange(1, 5);
        } else {
            ncase = ((GetPSW() & 0x40000000) == 0) ? g_rnd.GetRange(1, 9) : g_rnd.GetRange(1, 7);       // STM.MP/STM.GSR require SV privilege
        }

		switch (ncase) {
			//!< Insert ST Instruction.
			case 1:
				// Id Ins 165 to 171 are Id ins of st instruction.
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_ST_B_SD16, INS_ID_ST_W_SD23))->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				{
                    UI32 mismatchReg = g_mgr->GetMismatchReg();
                    UI32 reglist = FindSuitableReg(pCB, pIns);
                    if (mismatchReg != 0 && pNewIns->GetId() == INS_ID_ST_DW) {
                        reglist &= (~mismatchReg & 0xfffffffe);
                        pNewIns->opr(0)->ReplaceIdxFromList(reglist);
                        nRegSTCSour = pNewIns->opr(0)->Idx();
                    }
                }
                pNewIns->opr(0)->Replace(nRegSTCSour);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				//nAccessAddress &=  (~(pNewIns->opr(1)->GetConstraint()->m_nMsk));
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
            // Id Ins 649 to 654 are Id ins of st instruction.
            case 2:
                pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_ST_B_INC, INS_ID_ST_W_DEC))->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
                pNewIns->SetInLoop(InloopSequence);
                pIns->DirMoveTo(pNewIns);
                pNewIns->opr(0)->Replace(nRegSTCSour);
                pNewIns->opr(1)->Replace(nRegSTCDest);
                pConst = pNewIns->opr(1)->GetConstraint();
                if (pConst != NULL) {
                    pConst->SetRange(nAccessAddress, nAccessAddress + 32);
                    pConst->SetType(IValConstraint::ACCESS_RANGE);
                }
                //nAccessAddress &=  (~(pNewIns->opr(1)->GetConstraint()->m_nMsk));
                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                break;
			//!< Insert SST Instruction.
			case 3:
				// Ins Id of SST is 162 to 164
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_SST_B, INS_ID_SST_W))->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pConst = pNewIns->opr(1)->GetConstraint();
                pNewIns->opr(0)->Replace(nRegSTCSour);
				
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert SET1 CLR1 NOT1 Instruction.
			case 4:
				switch (g_rnd.GetRange(1,3)) {
					//!< CLR1 Instruction.
					case 1:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_CLR1_SD16, INS_ID_CLR1))->Fix();
					break;
					//!< NOT1 Instruction.
					case 2:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_NOT1SD16, INS_ID_NOT1))->Fix();
					break;
					//!< SET1 Instruction.
					case 3:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_SET1_SD16, INS_ID_SET1))->Fix();
					break;
				}
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
                pNewIns->opr(0)->Replace(nRegSTCSour);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                // Overwrite mismatch flag
                // TODO: Regulate instruction access in range is not successful
                if (g_prf->IsCompetitiveMem(nAccessAddress) == true) {
                    UI32 validRegList = FindSuitableReg(pCB, pIns);
                    UI32 invalidRegList = ~validRegList;
                    OverwriteMismatchFlag(pCB, pNewIns, invalidRegList);
                }
			break;
			// Insert CAXI Instruction.
			case 5:
                {
                 //Using mismacth register to store mismatch value from memory
                 UI32 mismatchReg = g_mgr->GetMismatchReg();
                 UI32 validRegList = FindSuitableReg(pCB, pIns);

                 if (mismatchReg != 0) {                  
                     reglist = validRegList & mismatchReg;
                    UI32 reg = g_rnd.GetRange(0, 31);
                     while (((reglist >> reg) & 1) == 0){
                        reg = g_rnd.GetRange(0, 31);
                    }
                    nRegSTCSour = reg;
                 }
				pNewIns = pInsSet->CreateIns(INS_ID_CAXI)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pNewIns->opr(0)->Replace(nRegSTCDest);
                pNewIns->opr(1)->Replace(nRegSTCDest);
				pNewIns->opr(2)->Replace(nRegSTCSour);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                // Overwrite mismatch flag
                // TODO: Regulate CAXI access in range is not successful
                if (g_prf->IsCompetitiveMem(nAccessAddress) == true) {
                    UI32 invalidRegList = ~validRegList;
                    OverwriteMismatchFlag(pCB, pNewIns, invalidRegList);
                }

                }
			break;
			// Insert Push Instruction.
			case 6:
            {
                 pNewIns = pInsSet->CreateIns(INS_ID_PUSHSP)->Fix();
                 UI32 rh = g_rnd.GetRange(0, 31);
                 UI32 rt = (rh + 7 > 31) ? 31 : g_rnd.GetRange(rh, rh + 7);
                 pNewIns->opr(0)->Replace(rh);
                 pNewIns->opr(1)->Replace(rt);
                {
                    UI32 mismatchReg = g_mgr->GetMismatchReg();
                    if (mismatchReg != 0) {
                        UI32 reglist = FindSuitableReg(pCB, pIns);
                        mismatchReg |= (~reglist);
                        pNewIns->RemoveRegInList(mismatchReg, 0);
                        UI32 rh = pNewIns->opr(0)->Idx();
                        UI32 rt = pNewIns->opr(1)->Idx();
                        while ((rt - rh) > 7) {
                           rt--;
                        }
                         pNewIns->opr(1)->Replace(rt);

                    }
                }
               
                pNewIns->AppendComment(" Force Clear LLBit ");
                // Because size of llbit area is 32 byte. So range of pushsp less than 8 register
                
                pIns->DirMoveTo(pNewIns);
                pNewIns->SetInLoop(InloopSequence);
                pConst = pNewIns->opr(0)->GetConstraint();
                if (pConst != NULL) {
                    pConst->SetRange(nAccessAddress, nAccessAddress + 32);
                    pConst->SetType(IValConstraint::ACCESS_RANGE);
                }
                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
            }
			break;
			// Insert Prepare Instruction.
			case 7:
                pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INST_ID_PREPARE, INST_ID_PREPARE_I32))->Fix();
                {
                    UI32 mismatchReg = g_mgr->GetMismatchReg();
                    if (mismatchReg != 0) {
                        UI32 reglist = FindSuitableReg(pCB, pIns);
                        mismatchReg |= (~reglist);
                        UI32 msk_list12 = CToolFnc::ConvertRegListToList12(mismatchReg);
                        msk_list12 = ~msk_list12;
                        UI32 list12 = (UI32)*pNewIns->opr(0);
                        // Remove all violated bits
                        list12 &= msk_list12;
                        pNewIns->opr(0)->Replace(list12);
                    }
                }
				
                pNewIns->AppendComment(" Force Clear LLBit ");
				pIns->DirMoveTo(pNewIns);
				pNewIns->SetInLoop(InloopSequence);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
            // Insert STM.MP Instruction.
            case 8:
            {
                if (pInsSet->GetWeight(INS_ID_STM_MP) == 0) break;

                pNewIns = pInsSet->CreateIns(INS_ID_STM_MP)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
                SI32 rh = 0, rt = 0;
                UI32 mpu_num = g_hwInfo->m_mpnum - 1;
               
                // In case multicore
                UI32 mismatchEntry = g_mgr->GetMismatchEntry();
                if (mismatchEntry != 0) {
                    std::vector<UI32> vReg;
                    for (UI32 i = 0; i <= mpu_num; i++) {
                        if (((mismatchEntry >> i) & 1)) {
                            vReg.push_back(i);
                        }
                    }
                    UI32 startMismatchEntry = vReg.front();
                    UI32 endMismatchEntry = vReg.back();
                    if (startMismatchEntry == 0 || endMismatchEntry == mpu_num) {
                        if (endMismatchEntry < mpu_num) {
                            rh = g_rnd.GetRange((UI32)(endMismatchEntry + 1), (UI32)mpu_num);
                            rt = ((UI32)rh + 7 > mpu_num) ? mpu_num : g_rnd.GetRange((UI32)rh, (UI32)(rh + 7));
                        } else if (startMismatchEntry > 0) {
                            rt = g_rnd.GetRange((UI32)0, (UI32)(startMismatchEntry - 1));
                            rh = (rt - 7 < 0) ? 0 : g_rnd.GetRange((UI32)(rt - 7), (UI32)rt);
                        } else {
                            std::runtime_error excep("Fail calculate entry of LDM.MP/STM.MP - Force clear LL Bit\n ");
                            throw excep;
                        }
                    } else {
                        if (g_rnd.GetRange(0, 1)) {
                            rt = g_rnd.GetRange((UI32)0, (UI32)(startMismatchEntry - 1));
                            rh = (rt - 7 < 0) ? 0 : g_rnd.GetRange((UI32)(rt - 7), (UI32)rt);
                        } else {
                            rh = g_rnd.GetRange((UI32)(endMismatchEntry + 1), (UI32)mpu_num);
                            rt = ((UI32)rh + 7 > mpu_num) ? mpu_num : g_rnd.GetRange((UI32)rh, (UI32)(rh + 7));
                        }
                    }
                    if (rh > rt) {
                        std::cout << "***rh = " << rh << "\trt = " << rt << std::endl;
                        std::runtime_error excep("Calculate entry of LDM.MP/STM.MP is wrong - Force clear LL Bit\n ");
                        throw excep;
                    }
                } else {
                    // Because size of llbit area is 32 byte. So range of stm.mp less than 8 entry
                    rh = g_rnd.GetRange((UI32)0, (UI32)mpu_num);
                    rt = ((UI32)rh + 7 > mpu_num) ? mpu_num : g_rnd.GetRange((UI32)rh, (UI32)(rh + 7));
                }                
                pNewIns->opr(0)->Replace(rh);
                pNewIns->opr(1)->Replace(rt);

                pIns->DirMoveTo(pNewIns);
                pNewIns->SetInLoop(InloopSequence);
                pConst = pNewIns->opr(2)->GetConstraint();
                pConst->SetRange(nAccessAddress, nAccessAddress + 32);
                pConst->SetType(IValConstraint::ACCESS_RANGE);

                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
            }
            break;
            // Insert STM.GSR Instruction.
            case 9:
            {
                if (pInsSet->GetWeight(INS_ID_STM_GSR) == 0) break;

                pNewIns = pInsSet->CreateIns(INS_ID_STM_GSR)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");

                pIns->DirMoveTo(pNewIns);
                pNewIns->SetInLoop(InloopSequence);
                pConst = pNewIns->opr(0)->GetConstraint();
                pConst->SetRange(nAccessAddress, nAccessAddress + 32);
                pConst->SetType(IValConstraint::ACCESS_RANGE);

                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
            }
            break;
		}
		
        if (pNewIns == nullptr) {
            // Can't find suitable instruction to force clear llbit
            return false;
        } else {
            //Record Instruction use to Force.
            lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
            return true;
        }
	};
	//------------------------------------------------------------
	// lambda : ClearByIERET_FERET
	//------------------------------------------------------------
	//          Insert one of FERET and IERET instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByIERET_FERET = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) -> bool {
		UI32 ncase =  g_rnd.GetRange(1,2);
		IInstruction* pAdjustIns;
		IInstruction* pNewIns = NULL;
		UI32 reg1 = lspsim->LLBitSTC[LLBit].STCDestReg;
		//UI32 reg2 = lspsim->m_nSTCSourtReg;
		
		char buff[100];
		sprintf(buff, "_ldl_stc_%#x_%#x_%#x", lspsim->LLBitSTC[LLBit].STCAddress, lspsim->LLBitSTC[LLBit].STCTargetPosition, (LLBit+1));
		std::string dstInsLabel = pCB->GetLabel()+buff;
			
		switch (ncase) {
			//!< Generating eiret instruction.
			case 1:
				pNewIns = new CIns_74_eiret();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->m_bBreakNotSS = true;
				pNewIns->SetTaken(true);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                if (IsHostMode()) {
                    pAdjustIns = STSR(15, reg1, 0);
                    pIns->DirMoveTo(pAdjustIns);
                    pAdjustIns->SetRegulationTarget(pNewIns);
                    pAdjustIns->SetInLoop(InloopSequence);
                    pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                    pAdjustIns = LDSR(reg1, 18, 0); 
                    pAdjustIns->m_bBreakNotSS = true;
                    pAdjustIns->SetInLoop(InloopSequence);
                    pAdjustIns->SetRegulationTarget(pNewIns);
                    pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));
                }

				pAdjustIns = STSR (5, reg1, 0); // psw->R // Rの値を潰してPC依存を切断
                pIns->DirMoveTo(pAdjustIns);
				pAdjustIns->SetRegulationTarget(pNewIns);
                pAdjustIns->SetInLoop(InloopSequence);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns = LDSR (reg1, 1, 0); // R->eipsw
				pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                pAdjustIns = MOV32P(dstInsLabel, reg1);
                pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
                pAdjustIns->SetRegulationTarget(pNewIns);
                pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                pAdjustIns = LDSR(reg1, 0, 0); // R->eipc
                pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
                pAdjustIns->SetRegulationTarget(pNewIns);
                pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                pAdjustIns = MOV32(g_rnd.Get(), reg1);
                pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
                pAdjustIns->SetRegulationTarget(pNewIns);
                pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pIns->SetLabel(dstInsLabel);

			break;

			case 2:
				pNewIns = new CIns_75_feret();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->m_bBreakNotSS = true;
				pNewIns->SetTaken(true);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                if (IsHostMode()) {
                    pAdjustIns = STSR(15, reg1, 0); 
                    pIns->DirMoveTo(pAdjustIns);
                    pAdjustIns->SetRegulationTarget(pNewIns);
                    pAdjustIns->SetInLoop(InloopSequence);
                    pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                    pAdjustIns = LDSR(reg1, 19, 0);
                    pAdjustIns->m_bBreakNotSS = true;
                    pAdjustIns->SetInLoop(InloopSequence);
                    pAdjustIns->SetRegulationTarget(pNewIns);
                    pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));
                }

				pAdjustIns = STSR (5, reg1, 0); // psw->R // Rの値を潰してPC依存を切断
                pIns->DirMoveTo(pAdjustIns);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns = LDSR (reg1, 3, 0); // R->fepsw
				pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                pAdjustIns = MOV32P(dstInsLabel, reg1);
                pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
                pAdjustIns->SetRegulationTarget(pNewIns);
                pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                pAdjustIns = LDSR(reg1, 2, 0); // R->fepc
                pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
                pAdjustIns->SetRegulationTarget(pNewIns);
                pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

                pAdjustIns = MOV32(g_rnd.Get(), reg1);
                pAdjustIns->m_bBreakNotSS = true;
                pAdjustIns->SetInLoop(InloopSequence);
                pAdjustIns->SetRegulationTarget(pNewIns);
                pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pIns->SetLabel(dstInsLabel);
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
        return true;
	};
	//------------------------------------------------------------
	// lambda : ClearByCLL
	//------------------------------------------------------------
	//          Insert one of CLL instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByCLL_EST_DST = [&] (CCodeBlock* pCB, IInstruction* pIns) -> bool {
		IInstruction* pNewIns;
		// Insert CLL Instruction.
		pNewIns = new CIns_55_cll();
        pNewIns->AppendComment(" Force Clear LLBit ");
		pNewIns->SetInLoop(InloopSequence);
		pIns->DirMoveTo(pNewIns);
		pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
        return true;
	};

	//------------------------------------------------------------
	// lambda : ClearByLDL_STC
	//------------------------------------------------------------
	//          Insert ldl and stc instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByLDL_STC = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) -> bool {
		UI32 ncase =  g_rnd.GetRange(1,2);
		UI32 nRegSTCDest = lspsim->LLBitSTC[LLBit].STCDestReg;
		UI32 nRegSTCSour = lspsim->LLBitSTC[LLBit].STCSourReg;
		IInstruction* pNewIns = NULL;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());	

		switch (ncase) {
			//!< Generating ldl instruction.
			case 1:
                {
                //Using mismacth register to store mismatch value from memory
                UI32 mismatchReg = g_mgr->GetMismatchReg();
                if (mismatchReg != 0) {
                   UI32 reglist = FindSuitableReg(pCB, pIns);
                   reglist &= g_mgr->GetMismatchReg();
                   UI32 reg = g_rnd.GetRange(0, 31);
                   while (((reglist >> reg) & 1) == 0){
                      reg = g_rnd.GetRange(0, 31);
                    }
                 nRegSTCSour = reg;
                 }
				pNewIns = pInsSet->CreateIns(INS_ID_LDL_W)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->opr(0)->Replace(nRegSTCDest);
				pNewIns->opr(1)->Replace(nRegSTCSour);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                }
			break;

			case 2:
				pNewIns = pInsSet->CreateIns(INS_ID_STC_W)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->opr(0)->Replace(nRegSTCSour);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
        return true;
	};

	//------------------------------------------------------------
	// lambda : ClearByExecption
	//------------------------------------------------------------
	//      Insert expection or interupt to clear LLBit  
	//------------------------------------------------------------
	auto ClearByExecption = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) -> bool {
	
		UI32 ncase =  g_rnd.GetRange(0,6);
		IInstruction* pNewIns = NULL;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());
 
		// Collect the weight of exception to avoid generating the disabled exception
		UI32 ExpWeight[7] = {
			pInsSet->GetWeight(CIns_76_fetrap::m_id) + g_exp->GetWeight(IException::EXP_FETRAP), 
			pInsSet->GetWeight(CIns_184_trap::m_id) + g_exp->GetWeight(IException::EXP_TRAP0) + g_exp->GetWeight(IException::EXP_TRAP1),
			pInsSet->GetWeight(CIns_193_hvtrap::m_id),
			pInsSet->GetWeight(CIns_127_rie::m_id) + pInsSet->GetWeight(CIns_128_rie::m_id) + g_exp->GetWeight(IException::EXP_RIE),
			pInsSet->GetWeight(CIns_192_hvcall::m_id),
			pInsSet->GetWeight(CIns_183_syscall::m_id ),
			g_exp->GetWeight(IException::EXP_UCPOP0) + g_exp->GetWeight(IException::EXP_UCPOP1) + g_exp->GetWeight(IException::EXP_UCPOP2)
		};

		for (UI32 i = 0; i < 7 /*size of above array*/; i++) {
			if (ExpWeight[ncase] != 0) 
				break;
			else 
				ncase = (ncase + 1) % 7;
		}
		
		if (ExpWeight[ncase] == 0)
			ncase = 7;

		switch (ncase) {
			//!< Generating FETRAP.
			case 0:
				pNewIns = pInsSet->CreateIns(INS_ID_FETRAP)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating TRAP.
			case 1:
				pNewIns = pInsSet->CreateIns(INS_ID_TRAP)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating HVTRAP.
			case 2:
				pNewIns = pInsSet->CreateIns(INS_ID_HVTRAP)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating RIE.
			case 3:
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_RIE, INS_ID_RIE_I9))->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating HVCALL.
			case 4:
				pNewIns = pInsSet->CreateIns(INS_ID_HVCALL)->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating SYSCALL.
			case 5:
                // Do not insert syscall because of can control mismatch flag in syscall codeblock
                if (m_nPreciMismatchFlag) {
                    AccessToRange32Byte(pCB, pIns, LLBit, lspsim);
                } else {
                    pNewIns = pInsSet->CreateIns(INS_ID_SYSCALL)->Fix();
                    pNewIns->AppendComment(" Force Clear LLBit ");
                    pNewIns->SetInLoop(InloopSequence);
                    pIns->DirMoveTo(pNewIns);
                    pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                }
			break;
			//!< Generating UCPOP.
			case 6:
				// [FROG]TODO: If SIMD was enable, it is not cause UCPOP
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_CNVQ15Q30, INS_ID_VXOR))->Fix();
                pNewIns->AppendComment(" Force Clear LLBit ");
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			default:
				// If there are no suiatble exception, clear by accessing memory
				AccessToRange32Byte(pCB,pIns,LLBit,lspsim);
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
        return true;
	};

    bool result = false;
    UI32 nFailCase = 0;
    UI32 tail = ((GetPSW() & 0x40000000) == 0) ? 5 : 4;     // FERET/EIRET require SV privilege

    while (result == false) {
        if (InloopSequence) {
            nFailCase = g_rnd.GetRange(3U, tail);
        } else {
            nFailCase = g_rnd.GetRange(1U, tail);
        }

        switch (nFailCase) {
            // Generate access to range 32 byte link bit protected. 
            case 1:
                result = AccessToRange32Byte(pCB, pIns, LLBit, lspsim);
                break;
                // Clear by expection.
            case 2:
                result = ClearByExecption(pCB, pIns, LLBit, lspsim);
                break;
                // Clear by CLL instruction.
            case 3:
                result = ClearByCLL_EST_DST(pCB, pIns);
                break;
                // Clear by ldl and stc instruction.
            case 4:
                result = ClearByLDL_STC(pCB, pIns, LLBit, lspsim);
                break;
                // Clear by eiret, feret instructions.
            case 5:
                result = ClearByIERET_FERET(pCB, pIns, LLBit, lspsim);
                break;
            default:
                std::runtime_error excep("Fail to Force Clear llbit \n ");
                throw excep;
                break;
        }
    }

    lspsim->LLBitSTC[LLBit].ForceSTCFail = result;
	return result;

}

void CSimulatorControl::PrepareDeletedIns(CCodeBlock *pCB, IInstruction *pIns) {
	SI32 idx = pCB->GetIndex(pIns) - 1;
	IInstruction *p = nullptr;
	UI32 max_try = 10;	// [FROG]TODO: Define this

	if (pIns->GetRiePartner() != nullptr) {
		pCB->Remove(pIns->GetRiePartner());
		pIns->SetRiePartner(nullptr);
		pCB->Update();
	}

	// Remove link to its adjustment code.
	while(idx >= 0 && max_try >= 0) {
		p = pCB->at(idx);

		if(p->GetRegulationTarget() != NULL) {
			if(p->GetRegulationTarget() == pIns)
				p->SetRegulationTarget(nullptr);
		}
        // If removed instruction is 2nd ins. of C2B1
		if(p->GetC2B1Ins() != NULL) { 
			if(p->GetC2B1Ins() == pIns)
				p->SetC2B1Ins(nullptr);
		}

        // If removed instruction is 2nd ins. of forwarding couple
        if(p->InSequence(IInstruction::IF_SEQ_FWD)) {
            if(p->GetForwardIns() == pIns) {
				p->SetForwardIns(nullptr);
                p->SetSequence(IInstruction::IF_SEQ_FWD, false);
            }
        }/*else
			break;*/
		idx--;
		max_try--;
	}
}

IExceptionConfig* CSimulatorControl::IdentifyException(IException* pExp, UI32 code) {
	std::vector<IExceptionConfig*> vExp;
	std::vector<IExceptionConfig*>::iterator itr;
	IExceptionConfig* pCfg = NULL;

	vExp = pExp->GetConfigByCode(code);

	if(vExp.size() == 0)
		return NULL;

	if(vExp.size() == 1)
		return vExp[0];

	itr = vExp.begin();
	while(itr < vExp.end()) {
		std::string exp = (*itr)->m_name;
		std::vector<CIntInfo*>::iterator itrReqEvent;
		// Convert to lower cases
		std::transform(exp.begin(), exp.end(), exp.begin(), [] (int ch) {return std::tolower(ch);});
		if((*itr)->m_bIsInterrupt) {
			for(itrReqEvent = m_vRequestedIntStack.begin(); itrReqEvent < m_vRequestedIntStack.end(); itrReqEvent++){
				if(exp == (*itrReqEvent)->sName) {
					break;
				}
			}	
			if(itrReqEvent == m_vRequestedIntStack.end()) {
				itr = vExp.erase(itr);
				continue;
			}
		} else {
			pCfg = (*itr);
			itr = vExp.erase(itr);
			continue;
		}
		itr++;
	}
	// There is no async. event requested.
	if(vExp.size() == 0)
		return pCfg;
	else {
		//TODO: Generalize this sequence
		if(vExp.size() == 2 && vExp[1]->m_name == "dbnmi"){
			pCfg = vExp[1];
		} else
			pCfg = vExp[0];
	}
	return pCfg;
}


UI32 CSimulatorControl::IsMDPexception(MEMADDR start_addr, UI32 size, bool IsLoad, bool IsStore) {
	// Checking MDP ignore mode MPCFG.DMDP = 1./ MDP will not occur in MDP ignore mode
    UI32 mpcfg = m_pSim->GetMPCFG();
	if (((mpcfg >> 24) & 0x1) == 1)
		return NO_ERROR; // Enable MDP suppress mode

    UI32 psw = m_pSim->GetPSW();
    UI32 mdp_mask = 0;

    if (IsLoad)
        mdp_mask |= (psw & 0x40000000) ? 0x1 : 0x8;

    if (IsStore)
        mdp_mask |= (psw & 0x40000000) ? 0x2 : 0x10;

    UI32 error_code = CheckMPUexception(start_addr, size, mdp_mask);
    return error_code;
}

/**
*@brief	Regulate MPU update sequence
*/
bool CSimulatorControl::RegulateMPUupdate(CCodeBlock *pCB, UI32 jump_reg) {
    UI32 hvcfg = 0;
    IInstruction* pIns = nullptr;
    IInstruction* target_ins = nullptr;
    UI32 reg = 0, mpm = 0;
    char str[80]; // Comment

    do {
        reg = g_rnd.GetRange(1, 30);
    } while (reg == jump_reg || jump_reg == (reg + 1));

    m_pSim->ReadNcReg(&hvcfg, 16, 1);
    // HVCFG.HVE = 1
    if ((hvcfg & 0x1) != 0) {
        if (RandomGuest_HostEntries(pCB, reg) == false)
            return false;
    } else {
        // Convention Mode
        if (RandomMPUofConventionMode(pCB, reg) == false)
            return false;
    }

    mpm = g_rnd.GetRange(0, 7);
    pIns = new CIns_104_mov();
    pIns->opr(0)->Replace(mpm);
    pIns->opr(1)->Replace(reg);
    sprintf(str, "MPM= 0x%08x", mpm);
    pIns->AppendComment((LPCTSTR)str);
    pCB->AddOpeCode(pIns);
    target_ins = LDSR(reg, 0, 5);
    pIns->SetRegulationTarget(target_ins);
    pCB->AddOpeCode(target_ins);
    pIns = SYNCI();
    pIns->SetSequence();
    pCB->AddOpeCode(pIns);

    pIns = JMP32(jump_reg);
    pIns->AppendComment("--> Return");
    pCB->AddOpeCode(pIns);
    g_mgr->AddDeadCode(pCB);

    pCB->SetBlockGap(0x10);
    pCB->EnableRegulation(false);

    if (g_asf->MakeLabelHash(pCB) != true || g_asf->LabelResolve(pCB) != true) {
        MSG_ERROR(0, "Fail to allocate cobe block");
        return false;
    }

    return true;
}

/**
*@brief	Random value for MPIDn (n: 0 -> 7) and SPID
*/
void CSimulatorControl::RandomMPIDn_SPID(CCodeBlock *pCB, UI32 reg) {
    const UI32 SPID_MAX = 31; //!< Maximum value of SPID.
    const UI32 MPID_NUM = 8;
    UI32 hvcfg = 0;
    UI32 selId = 5;    // selId MPID0
    UI32 regId = 24;    // regId MPID0
    UI32 SPID_value = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
    UI32 SPID_Hit = g_rnd.GetRange((UI32)0, (UI32)MPID_NUM);
    UI32 MPIDn_List[MPID_NUM]; //!< List random value of MPIDn.
    m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);

    for (UI32 i = 0; i< MPID_NUM; i++) {
        if (SPID_Hit == 0) {
            MPIDn_List[i] = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
        } else {
            if (i <= (SPID_Hit - 1)) {
                MPIDn_List[i] = SPID_value;
            } else {
                do {
                    MPIDn_List[i] = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
                } while (MPIDn_List[i] == SPID_value);
            }
        }
    }
    std::random_shuffle(std::begin(MPIDn_List), std::end(MPIDn_List), g_rnd);
    for (UI32 i = 0; i < MPID_NUM; i++) {
        NewINS(pCB, MOV5(MPIDn_List[i], reg));
        NewINS(pCB, LDSR(reg, regId + i, selId));
    }

    NewINS(pCB, MOV5(SPID_value, reg));
    NewINS(pCB, LDSR(reg, 0, 1));       // SPID

    if ((hvcfg & 0x1) != 0) {
        NewINS(pCB, LDSR(reg, 16, 9));       // GMSPID
    }
}

/**
*@brief Update MPU register of Host management and Guest Entries
*/
bool CSimulatorControl::RandomGuest_HostEntries(CCodeBlock *pCB, UI32 reg) {
    UI32 pswh = 0;
    UI32 val = 0;
    UI32 mpnum = g_hwInfo->m_mpnum;
    T_MP_SETTING 	m_mp_table;
    IInstruction* pIns = nullptr;
    UI32 mpcfg = m_pSim->GetMPCFG();

    m_pSim->ReadNcReg(&pswh, 15, 0);
    UI32 hbe = (mpcfg >> 8) & 0x3f;
    UI32 end_entry = hbe - 1;
    UI32 gpid = (pswh >> 8) & 0x7;

    // each entry has 3 regester (MPLA, MPUA, MPAT) which need to initialize
    // we use 4 byte to store value of each register
    MEMADDR vacancy_mem = m_pSim->FindVacantMemory(mpnum * 3 * 4, 4);
    if (vacancy_mem == 0) return false;
    MEMADDR temp_vacancy_mem = 0;

    if ((pswh >> 31) == 0) {
        // Host Mode
        end_entry = mpnum - 1;
        hbe = m_MPUlist->RandomHBE();
        NewINS(pCB, MOV32((hbe << 8), reg + 1));
        NewINS(pCB, LDSR(reg + 1, 2, 5));        // MPCFG

        UI32 gmmpm = g_rnd.GetRange(0, 7);
        NewINS(pCB, MOV5(gmmpm, reg + 1));
        NewINS(pCB, LDSR(reg + 1, 25, 9));        // GMMPM

        m_MPUlist->Fix(HOST_ENTRY);
        m_MPUlist->OutMpuSetting(&m_mp_table, HOST_ENTRY, hbe, mpnum);
        // find locate of memory to start store MPU information of host management to memory
        temp_vacancy_mem = vacancy_mem + hbe * 4 * 3;

        for (UI32 mp_idx = hbe; mp_idx < mpnum; mp_idx++) {
            for (UI32 idx = 0; idx < 3; idx++) {
                val = m_mp_table[mp_idx][idx];
                m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
                temp_vacancy_mem = temp_vacancy_mem + 4;
            }
        }

        // Random value for MPIDn(n: 0 -> 7) and SPID
        RandomMPIDn_SPID(pCB, reg + 1);
    }

    m_MPUlist->Fix(gpid);
    m_MPUlist->OutMpuSetting(&m_mp_table, gpid, 0, hbe);
    temp_vacancy_mem = vacancy_mem;
    // store MPU information of guest management to memory
    for (UI32 mp_idx = 0; mp_idx < hbe; mp_idx++) {
        for (UI32 idx = 0; idx < 3; idx++) {
            val = m_mp_table[mp_idx][idx];
            m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
            temp_vacancy_mem = temp_vacancy_mem + 4;
        }
    }

    pIns = MOV32(vacancy_mem, reg);
    pIns->AppendComment(" Prepare memory for MPU update ");
    pCB->AddOpeCode(pIns);
    pIns = LDM_MP(reg, 0, end_entry);
    pIns->AppendComment(" MPU update ");
    pCB->AddOpeCode(pIns);
    return true;
}

bool CSimulatorControl::IsTerminatedVM(UI32 gpid){
	// Start terminate address 
	UI32 addr = g_wm->GM_TERMINATE_FLAG;
	UI64 val = 0;
	// Calculate terminate address for gpid
	addr += 4 * gpid;
	m_pSim->ReadMemory(addr, 2, &val);

	return (val & 1);
}

void CSimulatorControl::SetAssertINTatTime(UI32 intId, UI32 time) {
	
	if(intId == IException::EXP_EITBL)		intId = IException::EXP_EIINT;
	if(intId == IException::EXP_GMEITBL)	intId = IException::EXP_GMEIINT;
	std::map<UI32, UI32>::iterator intTime = m_mAssertINTatTime.find(intId);
	if (intTime != m_mAssertINTatTime.end()){
		intTime->second = time;
	} else {
		MSG_ERROR(0, "Can not set interrupt id %d in storage", intId);
	}
}

UI32 CSimulatorControl::GetAssertINTatTime(UI32 intId) {
	UI32 time = 0;
	if(intId == IException::EXP_EITBL)		intId = IException::EXP_EIINT;
	if(intId == IException::EXP_GMEITBL)	intId = IException::EXP_GMEIINT;

	std::map<UI32, UI32>::iterator intTime = m_mAssertINTatTime.find(intId);
	if (intTime != m_mAssertINTatTime.end()){
		time = intTime->second;
	} else {
		MSG_ERROR(0, "Can not find interrupt id %d in storage", intId);
	}
	 return time;
}

/**
*@brief	increase time +1 that assert event is requested
*/
void CSimulatorControl::UpdateAssertINTatTime() {
	if(g_cfg->m_cpuStopinTime == 0)
		return;

	std::map<UI32, UI32>::iterator intTime = m_mAssertINTatTime.begin();
	for (;intTime != m_mAssertINTatTime.end(); ++intTime) {
		if(intTime->second > 0) 
			intTime->second -= 1;
	}
}

bool CSimulatorControl::RegulateInsinAsyncTime(CCodeBlock* pCB, IInstruction* pIns) {

	if(g_cfg->m_cpuStopinTime == 0)
		return false;

	// Checking assert label
	IDirective	*pDir;
	UI32 n = 0;
	while((pDir = pIns->GetDirective(n)) != nullptr) {
		CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		// Remove assert events until restart INT timer.
		if(pAs != NULL && (pAs->m_bAssert == true)) {
			UI32 time = GetAssertINTatTime(pAs->m_nEventId);
			if (time > 0) {
				pIns->RemoveDirective(pDir);
				delete pDir;
				break;
			}
		}
		n++;
	}

	UI32 insId = pIns->GetId();
	for (std::pair<UI32, UI32> intTime : m_mAssertINTatTime) {
		// Do not assert interrupt in time CPU stand by
		if(intTime.second == 0) 
			continue;
        // (2)Do not generate LDL/STC success couple for at least val instructions from the previous assert label Remine #92188 note-15
        if (pIns->IsLDL_STC_CusIns()) {
            IInstruction *p = NOP();
            p->AppendComment("Replace instruction changing INT status");
            pIns->DirMoveTo(p);
            pIns->AsyncMoveTo(p);
            PrepareDeletedIns(pCB, pIns);
            p = pCB->Replace(pIns, p);
            return true;
        }

		UI32 IntId = intTime.first;
		switch (IntId) {

		case IException::EXP_DBNMI: // No condition
		case IException::EXP_DBINT: // DIR0.DM = 0. FROG does not support random code in Debug Mode
		case IException::EXP_FENMI: // DIR0.DM = 0. FROG does not support random code in Debug Mode
			break;

		case IException::EXP_FEINT:
			{
				// Change PSW
				if(insId == INS_ID_RESBANK) {
					IInstruction *p = NOP();
					p->AppendComment("Replace instruction changing INT status");
					pIns->DirMoveTo(p);
					pIns->AsyncMoveTo(p);
					PrepareDeletedIns(pCB, pIns);
					p = pCB->Replace(pIns, p);
					return true;
				}
				if(insId == INS_ID_LDSR){
					UI32 sr = (UI32) *(pIns->opr(1));
					if (sr == (32*0 + 5) /*PSW*/) {
						IInstruction *p = NOP();
						p->AppendComment("Replace instruction changing INT status");
						pIns->DirMoveTo(p);
						pIns->AsyncMoveTo(p);
						PrepareDeletedIns(pCB, pIns);
						p = pCB->Replace(pIns, p);
						return true;
					}
				}
				break;
			}

		case IException::EXP_BGFEINT:
			MSG_ERROR(0, "Do not support BGFEINT when enbale cpu stop ");
			break;

		case IException::EXP_GMFEINT:
			{
				if(insId == INS_ID_JARL) {
					std::string targetLabel = pIns->GetJumpTarget();
					if (targetLabel.find ("function_ChangeModeto") != std::string::npos) {
						IInstruction *p = NOP();
						p->AppendComment("Replace instruction changing INT status");
						pIns->DirMoveTo(p);
						pIns->AsyncMoveTo(p);
						PrepareDeletedIns(pCB, pIns);
						p = pCB->Replace(pIns, p);
					}
				}
				// Change GMPSW
				if(insId == INS_ID_RESBANK || insId == INS_ID_LDM_GSR) {
					IInstruction *p = NOP();
					p->AppendComment("Replace instruction changing INT status");
					pIns->DirMoveTo(p);
					pIns->AsyncMoveTo(p);
					PrepareDeletedIns(pCB, pIns);
					p = pCB->Replace(pIns, p);
					return true;
				}

				if(insId == INS_ID_LDSR) {
					UI32 pswh;
					m_pSim->ReadNcReg(&pswh, 15, 0);
					UI32 sr = (UI32) *(pIns->opr(1));
					if ((pswh >> 31) && (sr == (32*0 + 5))) {
						IInstruction *p = NOP();
						p->AppendComment("Replace instruction changing INT status");
						pIns->DirMoveTo(p);
						pIns->AsyncMoveTo(p);
						PrepareDeletedIns(pCB, pIns);
						p = pCB->Replace(pIns, p);
						return true;
					}
				}
				break;
			}
		
		case IException::EXP_EIINT:
			{
				if(insId == INS_ID_DI || insId == INS_ID_RESBANK) {
					IInstruction *p = NOP();
					p->AppendComment("Replace instruction changing INT status");
					pIns->DirMoveTo(p);
					pIns->AsyncMoveTo(p);
					PrepareDeletedIns(pCB, pIns);
					p = pCB->Replace(pIns, p);
					return true;
				}
				if(insId == INS_ID_LDSR){
					UI32 sr = (UI32) *(pIns->opr(1));
					if ((sr == (32*0 + 5) /*PSW*/) || (sr == (32*2 + 14) /*PLMR*/) || (sr == (32*2 + 13) /*INTCFG*/)) {
						IInstruction *p = NOP();
						p->AppendComment("Replace instruction changing INT status");
						pIns->DirMoveTo(p);
						pIns->AsyncMoveTo(p);
						PrepareDeletedIns(pCB, pIns);
						p = pCB->Replace(pIns, p);
						return true;
					}
				}
				break;
			}

		case IException::EXP_GMEIINT:
			{
				if(insId == INS_ID_JARL) {
					std::string targetLabel = pIns->GetJumpTarget();
					if (targetLabel.find ("function_ChangeModeto") != std::string::npos) {
						IInstruction *p = NOP();
						p->AppendComment("Replace instruction changing INT status");
						pIns->DirMoveTo(p);
						pIns->AsyncMoveTo(p);
						PrepareDeletedIns(pCB, pIns);
						p = pCB->Replace(pIns, p);
					}
				}

				if(insId == INS_ID_DI || insId == INS_ID_RESBANK) {
					IInstruction *p = NOP();
					p->AppendComment("Replace instruction changing INT status");
					pIns->DirMoveTo(p);
					pIns->AsyncMoveTo(p);
					PrepareDeletedIns(pCB, pIns);
					p = pCB->Replace(pIns, p);
					return true;
				}
				if(insId == INS_ID_LDSR){
					UI32 sr = (UI32) *(pIns->opr(1));
					UI32 pswh;
					m_pSim->ReadNcReg(&pswh, 15, 0);
					if ((pswh >> 31) && ((sr == (32*0 + 5)/*GMPSW*/) || (sr == (32*2 + 14) /*GMPLMR*/) 
						|| (sr == (32*2 + 13) /*GMINTCFG*/))) {
						IInstruction *p = NOP();
						p->AppendComment("Replace instruction changing INT status");
						pIns->DirMoveTo(p);
						pIns->AsyncMoveTo(p);
						PrepareDeletedIns(pCB, pIns);
						p = pCB->Replace(pIns, p);
						return true;
					}
				}
			break;
			}

		case IException::EXP_BGEIINT:
			MSG_ERROR(0, "Do not support BGEIINT when enbale cpu stop ");
			break;

		default:
			break;
		}
	}
	return false;
}


/**
*@brief	Update MPU register of Convention entries
*/
bool CSimulatorControl::RandomMPUofConventionMode(CCodeBlock *pCB, UI32 reg) {
    UI32 val = 0, id = 0;
    UI32 mpnum = g_hwInfo->m_mpnum;
    T_MP_SETTING 	m_mp_table;
    IInstruction* pIns = nullptr;

    UI32 start_entry = g_rnd.GetRange((UI32)0, mpnum - 1);
    UI32 end_entry = g_rnd.GetRange(start_entry + 1, mpnum);

    // each entry has 3 regester (MPLA, MPUA, MPAT) which need to initialize
    // we use 4 byte to store value of each register
    MEMADDR vacancy_mem = m_pSim->FindVacantMemory((end_entry - start_entry) * 3 * 4, 4);
    if (vacancy_mem == 0) return false;

    // Random a setting  machine for convention mode
    if (g_cfg->m_mGMs.size()) {
        // support random HVCFG register
        std::map<UI32, GM_Infor>::iterator gm_itr = g_cfg->m_mGMs.begin();
        UI32 idx = g_rnd.GetRange(0U, (UI32)g_cfg->m_mGMs.size() - 1);
        std::advance(gm_itr, idx);
        id = gm_itr->first;  //GMID
    } else {
        id = CONVENTION_ENTRY;
    }

    m_MPUlist->Fix(id);
    m_MPUlist->OutMpuSetting(&m_mp_table, id, start_entry, end_entry);
    UI32 temp_vacancy_mem = vacancy_mem;
    // store MPU information to memory
    for (UI32 mp_idx = start_entry; mp_idx < end_entry; mp_idx++) {
        for (UI32 idx = 0; idx < 3; idx++) {
            val = m_mp_table[mp_idx][idx];
            m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
            temp_vacancy_mem = temp_vacancy_mem + 4;
        }
    }

    pIns = MOV32(vacancy_mem, reg);
    pIns->AppendComment(" Prepare memory for MPU update ");
    pCB->AddOpeCode(pIns);
    pIns = LDM_MP(reg, start_entry, end_entry - 1);
    pIns->AppendComment(" MPU update ");
    pCB->AddOpeCode(pIns);

    // Random value for MPIDn(n: 0 -> 7) and SPID
    RandomMPIDn_SPID(pCB, reg + 1);

    return true;
}

UI32 CSimulatorControl::IsMIPexception(MEMADDR start_addr, UI32 size) {
    UI32 PSW = m_pSim->GetPSW();
    UI32 mip_mask = (PSW & 0x40000000) ? 0x4 : 0x20;
    UI32 error_code = CheckMPUexception(start_addr, size, mip_mask);

    return error_code;
}

/* @brief check whether memory area(start to end) have occur MIP/MDP or not.
* @return true if memory area occur MIP/MDP exception
*/
UI32 CSimulatorControl::CheckMPUexception(MEMADDR start_addr, UI32 size, UI32 mask) {
    UI32 error_code = NO_ERROR;
    UI32 mpm = m_pSim->GetMPM();
    UI32 hvcfg = m_pSim->GetHVCFG();
    UI32 spid_mpidn = m_pSim->GetSPID_MPIDn();
    UI32 mpcfg = m_pSim->GetMPCFG();
    UI32 permission = 0;

    UI32 hbe = (mpcfg >> 8) & 0x3f;

    UI32 end_addr = start_addr + size - 1;

    // match: checking whether addr has belong to any MPU channel or not.
    // start, end is start channel and end channel. 
    // svp_mask: variable to check permission depend on GMMPM.SVP

    auto GetPermission = [=](UI32 start_entry, UI32 end_entry) -> UI32 {
        UI32 permission = 0;

        for (UI32 mpidx = start_entry; mpidx < end_entry; mpidx++) {
            UI32 mpu_lower = m_pSim->GetMPLA(mpidx);
            UI32 mpu_upper = m_pSim->GetMPUA(mpidx) | 0x3;
            if (mpu_lower >= mpu_upper) {
                continue;
            }
            if ((mpu_lower > start_addr) || (end_addr > mpu_upper)) {
                //!・・OutOfRange
                continue;
            }

            UI32 mpat = m_pSim->GetMPAT(mpidx);
            if ((mpat & 0x80) == 0) {
                // channel is disable
                continue;
            }

            if ((mpat & 0x4000) != 0 || ((mpat >> 16) & spid_mpidn) != 0) {	// Check XR permission
                permission |= (mpat & 0x2d);
            }

            if ((mpat & 0x8000) != 0 || ((mpat >> 24) & spid_mpidn) != 0) { // Check W permission
                permission |= (mpat & 0x12);
            }
        }
        return permission;
    };

    if ((hvcfg & 0x1) != 0) {
        if ((mpm & 0x1) != 0) {
            permission = IsGuestMode() ? GetPermission(0, hbe) : GetPermission(hbe, g_hwInfo->m_mpnum);
            if ((mpm & 0x2) == 0) permission |= 0x38;  // MPM.SVP

            if ((permission & mask) != mask) {
                error_code = IsGuestMode() ? VIOLATE_GUEST_ENTRY : VIOLATE_HOST_ENTRY;
                return error_code;
            }
        } 

        if((mpm & 0x4) != 0) {
            permission = GetPermission(hbe, g_hwInfo->m_mpnum);

            if ((permission & mask) != mask) {
                error_code = VIOLATE_HOST_ENTRY;
                return error_code;
            }
        }

    } else {
        // Convention mode
        if ((mpm & 0x1) != 0) {
            permission = GetPermission(0, g_hwInfo->m_mpnum);
            if ((mpm & 0x2) == 0) permission |= 0x38;     // MPM.SVP

            if ((permission & mask) != mask) {
                error_code = VIOLATE_CONVENTION_ENTRY;
                return error_code;
            }
        }
    }

    return error_code;
}

bool CSimulatorControl::IsNotSelfCheckMemory(UI32 address) {

    for (std::pair<UI32, UI32> e : m_mNotSelfCheckMemoryList) {
        if (address >= e.first && address <= e.second)
            return true;
    }
    return false;
}

UI32 CSimulatorControl::GetRegisterInLoop(CCodeBlock* pCB, IInstruction* pIns) {
    UI32 regInLoop = 0;
    //Get register in loop sequence
    if (pIns->InLoop() == true) {
        UI32 idx = pCB->GetIndex(pIns);
        IInstruction *pLoopIns = NULL;
        // Find end point of loop sequence-> LOOP instruction
        while (idx < pCB->GetInstructionNum()) {
            pLoopIns = pCB->at(idx);
            if (pLoopIns->GetId() == INS_ID_LOOP)
                break;
            idx++;
        }
        //Find the register that is used as source or dest of ld/st instructions
        if (pIns->GetLabel().find("_Lp") == std::string::npos) {
            while (idx >= 0) {
                IInstruction* pTmp = pCB->at(idx);
                regInLoop |= pTmp->GetConstraintBit();

                if (pTmp->GetLabel().find("_Lp") != std::string::npos)
                    break;
                idx--;
            }
        }
    } else {
        return regInLoop;
    }
    return regInLoop;
}

void CSimulatorControl::ImprovingStoreCompetitive(CCodeBlock* pcb, IInstruction* pIns) {

    bool canImprove = true;
    // Get operand hold value to store into memory
    IOperand* poprVal = pIns->opr(0);
    UI32 pInsId = pIns->GetId();
    if (pInsId == INS_ID_STV_W || pInsId == INS_ID_STV_DW)
        poprVal = pIns->opr(1);
    if (pInsId == INS_ID_CAXI)
        poprVal = pIns->opr(2);

    // Get operand hold memory address
    IOperand* poprMem = pIns->opr(1);
    for (UI32 i = 0; i < pIns->GetOpNum(); i++) {
        if (pIns->opr(i)->GetConstraint() != NULL) {
            poprMem = pIns->opr(i);
            break;
        }
    }

    UI32 mismatchReg = g_mgr->GetMismatchReg();
    UI32 constraintReg = GetRegisterInLoop(pcb, pIns);
    constraintReg |= 1 << poprMem->Idx();
    constraintReg |= (UI32)((m_nPreciMismatchReg & 0xffffffff) | (m_nPreciMismatchReg >> 32));
    UI32 usemisReg = mismatchReg & (~constraintReg);

    if (pInsId == INS_ID_PUSHSP && (pIns->opr(1)->Idx() >= pIns->opr(0)->Idx()))
        canImprove = false;
    //RMW
    if (pIns->Behavior(IInstruction::LOAD_MEMORY) == true && pInsId != INS_ID_CAXI)
        canImprove = false;
    // Replace list12
    if (pInsId >= INST_ID_PREPARE && pInsId <= INST_ID_PREPARE_I32) {
        UI32 list12 = (UI32)* pIns->opr(0);
        UI32 msk_list12 = CToolFnc::ConvertRegListToList12(usemisReg);
        list12 &= msk_list12;
        if (list12 == 0) list12 = msk_list12;
        if (pIns->opr(0)->Replace(list12) == false)
            canImprove = false;
    } else if (pInsId == INS_ID_STM_GSR) {
        canImprove = false;
    } else if (pInsId == INS_ID_STM_MP) {
        /*UI32 mismatchEntry = g_mgr->GetMismatchEntry();
        UI32 rh = pIns->opr(0)->Idx();
        UI32 rt = pIns->opr(1)->Idx();
        UI32 pswh = 0, mpcfg = 0, hbe = 0;
        m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
        bool isGuestMode = (pswh >> 31) & 0x1;
        m_pSim->ReadSysRegister(&mpcfg, "MPCFG", 0);
        hbe = (mpcfg >> 8) & 0x3F;
        if (g_prf->m_is_mpu == false && rh <= rt) {
            UI32 trytime = 10;
            do {
                pIns->opr(0)->ReplaceIdxFromList(mismatchEntry);
                pIns->opr(1)->ReplaceIdxFromList(mismatchEntry);
                if (rh <= rt && (isGuestMode == false || (isGuestMode && (rt < hbe))))
                    break;
                trytime--;
            } while (trytime > 0);        
            if (trytime == 0) canImprove = false;
        } else {
            canImprove = false;
        }*/
        canImprove = false;
    } else { //Replace normal operand
        if (poprVal->ReplaceIdxFromList(usemisReg) == false)
            canImprove = false;
    }
    // Replace by NOP
    if (canImprove == false) {
        PrepareDeletedIns(pcb, pIns);
        IInstruction * nop = NOP();
        nop->AppendComment("Give up STORE into competitive memory");
        pIns->DirMoveTo(nop);
        pIns->AsyncMoveTo(nop);
        nop = pcb->Replace(pIns, nop);
        delete nop;
        pcb->Update();

    }
}


bool CSimulatorControl::CanStoreMem(CCodeBlock* pcb, IInstruction* pIns, UI32 accessMem) {
    //Check STORE into Competitive memory (PE0-CIWR, PE1 CRW, PE2 CW)
    if (pIns->Behavior(IInstruction::STORE_MEMORY) && pIns->GetInsNeed().size() == 0
        && g_prf->IsCompetitiveMem((MEMADDR)(accessMem)) == true) {

        //RMW access into fetched memory.		
        if (pIns->Behavior(IInstruction::LOAD_MEMORY) == true && pIns->GetId() != INS_ID_CAXI) {
            // Instruction was NOT executed.
            if (g_prf->IsFetchMem((MEMADDR)(accessMem)) && g_asf->IsExecutedAddress(accessMem) == false) {
                return false;
            } else {
                return true;
            }
        } else { // STORE into competitive memory
                 // Get operand hold value to store into memory
            IOperand* poprVal = pIns->opr(0);
            UI32 pInsId = pIns->GetId();
            if (pInsId == INS_ID_STV_W || pInsId == INS_ID_STV_DW)
                poprVal = pIns->opr(1);
            if (pInsId == INS_ID_CAXI)
                poprVal = pIns->opr(2);
            // Get operand hold memory address
            IOperand* poprMem = pIns->opr(1);
            for (UI32 i = 0; i < pIns->GetOpNum(); i++) {
                if (pIns->opr(i)->GetConstraint() != NULL) {
                    poprMem = pIns->opr(i);
                    break;
                }
            }

            UI32 mismatchReg = g_mgr->GetMismatchReg();
            UI32 constraintReg = GetRegisterInLoop(pcb, pIns);
            constraintReg |= 1 << poprMem->Idx();
            constraintReg |= (UI32)( (m_nPreciMismatchReg & 0xffffffff) | (m_nPreciMismatchReg >> 32) );
            UI32 usemisReg = mismatchReg & (~constraintReg);           

            if (pInsId == INS_ID_STM_GSR) {
                if (g_prf->IsCIMemory(accessMem) == false)  return true;
                return false;
            } else if (pInsId == INS_ID_STM_MP) {
                UI32 rh = pIns->opr(0)->Idx();
                UI32 rt = pIns->opr(1)->Idx();
                /*UI32 mismatchEntry = g_mgr->GetMismatchEntry();
                UI32 pswh = 0, mpcfg = 0, hbe = 0;
                m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
                bool isGuestMode = (pswh >> 31) & 0x1;
                m_pSim->ReadSysRegister(&mpcfg, "MPCFG", 0);
                hbe = (mpcfg >> 8) & 0x3F;
                if (rh <= rt && (isGuestMode == false || (isGuestMode && (rt < hbe)))) {
                    if (g_prf->IsCIMemory(accessMem) == false)  return true;
                    if (g_prf->m_is_mpu == false) {
                        if (((1 << rh) & mismatchEntry) && ((1 << rt) & mismatchEntry)) return true;
                    }
                }*/
                if (rh <= rt && g_prf->IsCIMemory(accessMem) == false) return true;
                return false;
            }

            // Check mismatch register
            if (usemisReg == 0) {
                return false;     
            }
            // Check register in rh-rt
            if (pInsId == INS_ID_PUSHSP) {
                if (pIns->opr(1)->Idx() >= pIns->opr(0)->Idx()) {
                    for (UI32 oprId = pIns->opr(0)->Idx(); oprId <= pIns->opr(1)->Idx(); oprId++) {
                        if ((usemisReg & (1 << oprId)) == 0)
                            return false;
                    }
                }
            // Check register in list12
            } else if (pInsId >= INST_ID_PREPARE && pInsId <= INST_ID_PREPARE_I32) {
                UI32 list12 = (UI32)*pIns->opr(0);
                UI32 msk_list12 = CToolFnc::ConvertRegListToList12(usemisReg);
                if ((list12 & msk_list12) != list12)
                    return false;
            } else {
                UI32 oldIdx = ((poprVal->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << poprVal->Idx());
                if ((oldIdx & usemisReg) != oldIdx) {
                    return false;
                }
            }
        }
    }
    return true;
}

bool CSimulatorControl::PrepareValBeforeStore(CCodeBlock* pcb, IInstruction* pIns, UI32 trgV, UI32 reg) {
    IInstruction* newpIns = NULL;
    std::vector<IInstruction*> vNewpIns;
    UI32 pInsId = pIns->GetId();
    pIns->AppendComment("  -> Access_competitive_memory");
    // Get operand hold memory address
    IOperand* poprMem = pIns->opr(1);
    for (UI32 i = 0; i < pIns->GetOpNum(); i++) {
        if (pIns->opr(i)->GetConstraint() != NULL) {
            poprMem = pIns->opr(i);
            break;
        }
    }

    // Calculate memory address
    UI32 disp = poprMem->GetDisp();

    // Get operand hold value to store into memory
    IOperand* poprVal = pIns->opr(0);
    if (pInsId == INS_ID_STV_W || pInsId == INS_ID_STV_DW)
        poprVal = pIns->opr(1);
    if (pInsId == INS_ID_CAXI)
        poprVal = pIns->opr(2);

    // Recalculate Stack Point for popsp/dispose 
    UI32 gapMem = 0;
    if (pInsId == INS_ID_PUSHSP && (pIns->opr(1)->Idx() >= pIns->opr(0)->Idx())) {
        gapMem = (pIns->opr(1)->Idx() - pIns->opr(0)->Idx()) + 1;
        gapMem = gapMem * 4;
    } else if (pInsId >= INST_ID_PREPARE && pInsId <= INST_ID_PREPARE_I32) {
        gapMem = pIns->opr(0)->GetBitCount();
        gapMem = gapMem * 4;
        gapMem = gapMem + ((UI32)*pIns->opr(1) << 2);
    }
    // Move destinate memory address for next access
    newpIns = MOV32(trgV - gapMem, reg);
    newpIns->AppendComment("  -> Prepare_competitive_memory");
    pIns->SetInsNeed(newpIns);
    vNewpIns.push_back(newpIns);

    // Generate need instruction
    if (pIns->Behavior(IInstruction::LOAD_MEMORY) == true && pIns->GetId() != INS_ID_CAXI) {
        newpIns = nullptr; // RMW instruction has LOAD memory by it self
    } else if (pIns->GetId() == INS_ID_PUSHSP) {
        if (pIns->opr(0)->Idx() <= pIns->opr(1)->Idx()) {
            newpIns = POPSP(pIns->opr(0)->Idx(), pIns->opr(1)->Idx());
        } else {
            newpIns = nullptr;
        }
    } else if (pIns->GetId() >= INST_ID_PREPARE && pIns->GetId() <= INST_ID_PREPARE_I32) {
        UI32 list12 = (UI32)*pIns->opr(0);
        newpIns = DISPOSE((UI32)*pIns->opr(1), list12);
    } else if (pIns->GetId() == INS_ID_STM_GSR) {
        newpIns = nullptr;
    } else if (pIns->GetId() == INS_ID_STM_MP) {
        /*if (pIns->opr(1)->Idx() >= pIns->opr(0)->Idx()) {
            if (g_prf->IsCIMemory(trgV + disp) == true && g_prf->m_is_mpu == false) {
                newpIns = LDM_MP(pIns->opr(2)->Idx(), pIns->opr(0)->Idx(), pIns->opr(1)->Idx());
            } else {
                newpIns = nullptr;
            }            
        }*/
        newpIns = nullptr;
    } else if (g_prf->IsCIMemory(trgV + disp) == true) {
        UI32 size = 0;// Get Access size
        if (poprMem->GetConstraint() != NULL)
            size = poprMem->GetConstraint()->GetSize();
        switch (size) {
            case 1:
                newpIns = LDB23(disp, poprMem->Idx(), poprVal->Idx());
                break;
            case 2:
                newpIns = LDH23(disp, poprMem->Idx(), poprVal->Idx());
                break;

            case 4:
                if (poprVal->IsWR() == true) {
                    UI32 imm = (UI32)* pIns->opr(0);
                    imm = 1 << imm;
                    newpIns = LDVW(imm, disp, poprMem->Idx(), poprVal->Idx());
                } else {
                    newpIns = LDW23(disp, poprMem->Idx(), poprVal->Idx());
                }
                break;
            case 8:
                if (poprVal->IsWR() == true) {
                    UI32 imm = (UI32)* pIns->opr(0);
                    if (pInsId == INS_ID_STVZ_H4) {
                        newpIns = LDVZ_H4(disp, poprMem->Idx(), poprVal->Idx());
                    } else {
                        imm = 1 << imm;
                        newpIns = LDVDW(imm, disp, poprMem->Idx(), poprVal->Idx());
                    }
                } else {
                    newpIns = LDDW23(disp, poprMem->Idx(), poprVal->Idx());
                }
                break;
            case 0x10:
                newpIns = LDVQW(disp, poprMem->Idx(), poprVal->Idx());
                break;
            default:
                newpIns = LDW23(disp, poprMem->Idx(), poprVal->Idx());
                break;
        }
    } else {
        newpIns = nullptr;
    }

    if (newpIns != nullptr) {
        pIns->SetInsNeed(newpIns);
        newpIns->AppendComment("  -> Prepare_competitive_memory");
        vNewpIns.push_back(newpIns);
    }

    return true;
}

/**
* @brief	Overwrite Mismatch Flag
* @param	pCB		current simulated code block
* @param	pIns	Current simulated instruction
*/
void CSimulatorControl::OverwriteMismatchFlag(CCodeBlock* pcb, IInstruction* pIns, UI32 ExcludeReg) {

    CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());
    UI32 nMismatchRegs = g_mgr->GetMismatchReg();
    ExcludeReg |= nMismatchRegs;
   
    auto GenOverwriteFlagIns = [=](UI32 nFlag, UI32 ExcludeReg) -> IInstruction* {
        const UI32 max_challenge = 30;
     
        for (UI32 n = 0; n < max_challenge; n++) {
            IInstruction* pIns = pInsSet->CreateIns();
            //
            std::string mne = pIns->GetMne();
            UI32 id = pIns->GetId();
            if ((pIns->UpdateFlag() & nFlag) == 0) {
                delete pIns;
                continue;
            }

            // These instruction may cause next mismatched
            if (mne == "clr1" || mne == "not1" || mne == "set1" || mne == "tst1" || mne == "caxi") {
                delete pIns;
                continue;
            }

            // These instruction may used mismatched flag
            if (id == INS_ID_ADF || id == INS_ID_CMOV || id == INS_ID_CMOV_SI5 || id == INS_ID_SASF || id == INS_ID_SBF || id == INS_ID_SETF) {
                delete pIns;
                continue;
            }

            // The instruction need to handle complicated
            if (id == INS_ID_LOOP) {
                delete pIns;
                continue;
            }

            // G3M DIV does not write back gr on dividing ZERO.
            if (mne.find("div", 0) == 0) {
                delete pIns;
                continue;
            }
            // Exclude multi-core mismatched register set
            if (ExcludeReg) {
                for (UI32 p = 0; p < pIns->GetOpNum(); p++) {
                    IOperand *pOpr = pIns->opr(p);
                    while ((pOpr->GetGrSrc() | pOpr->GetGrDst()) & ExcludeReg) {
                        pOpr->Replace(g_rnd.GetRange(1, 31));
                    }
                }
            }
            return pIns;
        }

        return ADD(0, 0);
    };


    auto GetDepFlag = [=](IInstruction *p) -> UI32 {
        if (nMismatchRegs == 0) {
            return 0;
        }
        const std::string &mne = p->GetMne();
        if (mne == "clr1" || mne == "not1" || mne == "set1" || mne == "tst1") {
            return IInstruction::INS_FLG_Z;
        }

        if (mne == "caxi")
            return (IInstruction::INS_FLG_Z | IInstruction::INS_FLG_S | IInstruction::INS_FLG_OV | IInstruction::INS_FLG_CY);

        return 0;
    };

    UI32 nDependFlag = GetDepFlag(pIns);
    UI32 pos = pcb->GetIndex(pIns) + 1;
    // Generate random instruction to overwrite PSW
    while (nDependFlag) {
        IInstruction* dlnk = GenOverwriteFlagIns(nDependFlag, ExcludeReg);
        dlnk->AppendComment("Overwrite precision error!");
        pcb->AddOpeCode(dlnk, pos);
        nDependFlag &= ~(dlnk->UpdateFlag());
    }
}