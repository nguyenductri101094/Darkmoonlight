#include "operand.h"
#include "adr_selector.h"
#define	OPR_CODEBUF		(32)

	
/**
 * @brief このオブジェクトを破棄します
 */
bool IOprE3V5::SetMemoryErrorControl(IRegulation* pReg) {

CSegmentList* pSl = NULL;
eMXU_ACCESS_TYPE atype = MXU_ACC_READ;

CAddressWeight	aw;
CAddressWeight	awf;
MEMRANGE		mr;
bool OprAtt_SMEM = Attr(IOperand::OPR_ATTR_SMEM);
bool OprAtt_LMEM = Attr(IOperand::OPR_ATTR_LMEM);

#ifdef DBGMODE
	bool debug_flag = false;
#endif
	
	if (m_vConst == NULL){
		return true;
	}

	// The constraint is not for Load/Store
	if(m_vConst->GetMemmoryArea(&aw, &atype, OprAtt_SMEM, OprAtt_LMEM) == false)
		return true;

	//// Adjust memories for handler code to MPU fixed area.
	//if(m_vConst->GetType(IValConstraint::FIXED_MPU)) {
	//	std::set<MEMRANGE> s = aw.KeySet();
	//	std::vector<std::pair<UI32, MEMRANGE>>::iterator itrFixedMPU;
 //       UI32 gpid = 0, pswh = 0, hvcfg = 0;

 //       pReg->m_pSim->ReadNcReg(&hvcfg, 16, 1);
 //       if ((hvcfg & 0x1) != 0) {
 //           pReg->m_pSim->ReadNcReg(&pswh, 15, 0);
 //           gpid = (pswh >> 8) & 0x7;
 //       } else {
 //           gpid = g_hwInfo->m_gmnum;
 //       }

	//	for(itrFixedMPU = g_FixedMPU.begin(); itrFixedMPU != g_FixedMPU.end(); itrFixedMPU++) {
	//		if(itrFixedMPU->first != gpid) {
	//			continue;
	//		}
	//		UI32 mpu_start = itrFixedMPU->second.first;
	//		UI32 mpu_end = itrFixedMPU->second.second;
	//		std::set<MEMRANGE>::iterator itr;
	//		for(itr = s.begin(); itr != s.end(); itr++) {
	//			UI32 mem_start = itr->first;
	//			UI32 mem_end = itr->second;
	//			UI32 start = 0, end = 0;
	//			if(mpu_start <= mem_start && mpu_end >= mem_start) {
	//				start = mem_start;
	//				end = (mpu_end >= mem_end) ? mem_end : mpu_end;
	//			} else if(mpu_start >= mem_start && mpu_start <= mem_end) {
	//				start = mpu_start;
	//				end = (mpu_end <= mem_end) ? mpu_end : mem_end;
	//			}
	//			if(start != end){
	//				awf.Set(start, end, aw.GetWeight(*itr));
	//			}
	//		}
	//	}
	//	aw = awf;
	//}

	if(aw.Count() == 0) {
		return false;
	}
	
	// アクセス（R/W)に即した検証空間のアドレス重み一覧を得る（コピー取得）

	if (m_vConst->IsLock() == true) {
		// 前回のセグメントリストを復帰させる
		pReg->m_pSim->GetSegmentList(pSl, m_mr.first, m_mr.second, atype, pReg->m_ht, m_vConst->m_nSzm);
		return true;
	}

#ifdef DBGMODE
	if (debug_flag) {
		aw.Dump();
	}
#endif
	
	// アドレス重み一覧（aw）から候補を得る（重みに従って候補を探す）
	// （アラインを加味して）適合するサイズに満たないものは候補外となる。
	// 適合する領域が見付かった場合、そのアドレス範囲の情報（MPU/MMUアクセス情報）を得る。
	while (aw.Count()) {
		mr = aw.SelectRange();
		
		MEMADDR mrlen = (mr.second - mr.first + 1);
		if (mrlen < m_vConst->m_nSzm) {
			// サイズそのものが足りない場合は候補削除
			aw.Delete(mr);
			continue;
		}
#ifdef DBGMODE
		if (debug_flag) {
			printf ("range = %llx - %llx\n", mr.first,mr.second);	
			printf ("mrlen = %lld\n", mrlen);	
			printf ("asize = %d\n", m_vConst->m_nSzm);	
			printf ("align = 0x%x\n", m_vConst->m_nUnA);	
			printf ("mask  = 0x%llx\n", m_vConst->m_nMsk);
		}
#endif
		if (m_vConst->m_nUnA) {
			// fa = 最初にミスアラインアクセス可能な位置
			MEMADDR  fa = ((mr.first & ~m_vConst->m_nMsk) +m_vConst->m_nUnA);
			if (mr.second < fa) {
				aw.Delete(mr);
				continue;
			} 
			if ( (mr.second - fa + 1) < m_vConst->m_nSzm ) {
				aw.Delete(mr);
				continue;
			}
		}else{
			// fa = (切り上げ方式で)最初にアラインアクセス可能な位置
			MEMADDR fa = (mr.first + m_vConst->m_nMsk) & ~m_vConst->m_nMsk;
			if (mr.second < fa) {
				aw.Delete(mr);
				continue;
			}
			if ( (mr.second - fa + 1) < m_vConst->m_nSzm ) {
				aw.Delete(mr);
				continue;
			}
		}
		bool raise = m_vConst->GetType(IValConstraint::RAISE_MERROR);

		pReg->m_pSim->GetSegmentList(pSl, mr.first, mr.second, atype, pReg->m_ht, m_vConst->m_nSzm);
		#ifdef DBGMODE
		if (debug_flag) {
			printf("Range 0x%08llx - 0x%08llx\n", mr.first, mr.second);
			pSl->Dump();
		}
		#endif
		UI32 judgeSize = m_vConst->m_nSzm + m_vConst->m_nUnA;
		if (pSl->IsAdjustable(!raise, judgeSize) != true) {
			aw.Delete(mr);
			continue;
		}else{
			m_vConst->SetSegmentList(pSl);
			m_mr = mr;
			return true;
		}
	}

	return false;	
}



/////////////////////////////////////////////////////////
// Class :: COprGR
// Desc  :: 汎用レジスタ オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
void COprGR::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	
	//!< Align制御
	if (m_vConst==NULL || m_vConst->IsValid(cur)) {
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)cur));
		}
		return;
	}
	
	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	UI64 sv = m_vConst->SelectValue();
	
	//!< 補正情報
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)sv));
}


std::string COprGR::GetCode() {
	char code[OPR_CODEBUF];
	(void*)Fix();
	sprintf(code, "r%d", m_reg);
	return std::string(code);
}

IOperand* COprGR::Fix() {
	if (!m_bFixed) {
		m_reg	 = m_pRand->GetRange(m_rh, m_rt);
		m_bFixed = true;
	}
	return this;
}

UI32 COprGR::Idx() {
	(void*)Fix();
	return m_reg;
}

bool COprGR::Replace(UI32 index) {
	if (m_rh <= index && index <= m_rt) {
		m_reg = index;
		m_bFixed = true;
		return true;
	}
	return false;
}

bool COprGR::SetRange(UI32 rh, UI32 rt) {
	m_rh = rh;
	m_rt = rt;
	return true;
}


/////////////////////////////////////////////////////////
// Class :: COprGRm
// Desc  :: 汎用レジスタ(MemoryAccess)オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
void COprGRm::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	
	//!< Align制御
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	if (m_vConst==NULL || m_vConst->IsValid(cur)) {
		if (Attr(OPR_ATTR_IRAM) != true){
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		}
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)cur));
		}
		return;
	}
	
	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	UI64 sv = m_vConst->SelectValue();
	
	//!< 補正情報
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)sv));
}
/////////////////////////////////////////////////////////
// Class :: COprGRm
// Desc  :: 汎用レジスタ(MemoryAccess)オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
void COprGRm::Regulate(IRegulation* r, UI32 lnk) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	//!< Align制御
	if(!SetMemoryErrorControl(r, lnk)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r, lnk)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	
	if (m_vConst==NULL || m_vConst->IsValid(cur)) {
		if (Attr(OPR_ATTR_IRAM) != true){
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		}
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)cur));
		}
		return;
	}
	
	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	UI64 sv = m_vConst->SelectValue();
	
	//!< 補正情報
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)sv));
}

std::string COprGRm::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "[r%d]", m_reg);
	return std::string(code);
}

/**
 * @brief このオブジェクトを破棄します
 */
bool COprGRm::SetMemoryErrorControl(IRegulation* pReg) {

CSegmentList* pSl = NULL;
eMXU_ACCESS_TYPE atype = MXU_ACC_READ;

CAddressWeight	aw;
CAddressWeight	awf;
MEMRANGE		mr;
bool OprAtt_SMEM = Attr(IOperand::OPR_ATTR_SMEM);
bool OprAtt_LMEM = Attr(IOperand::OPR_ATTR_LMEM);

#ifdef DBGMODE
	bool debug_flag = false;
#endif
	
	if (m_vConst == NULL){
		return true;
	}
	// The constraints is not for Load/Store
	if(m_vConst->GetMemmoryArea(&aw, &atype, OprAtt_SMEM, OprAtt_LMEM) == false)
		return true;

	// Adjust memories for handler code to MPU fixed area.
	/*if(m_vConst->GetType(IValConstraint::FIXED_MPU)) {
		std::set<MEMRANGE> s = aw.KeySet();
		std::vector<std::pair<UI32, MEMRANGE>>::iterator itrFixedMPU;
        UI32 gpid = 0, pswh = 0, hvcfg = 0;

        pReg->m_pSim->ReadNcReg(&hvcfg, 16, 1);
        if ((hvcfg & 0x1) != 0) {
            pReg->m_pSim->ReadNcReg(&pswh, 15, 0);
            gpid = (pswh >> 8) & 0x7;
        } else {
            gpid = g_hwInfo->m_gmnum;
        }

		for(itrFixedMPU = g_FixedMPU.begin(); itrFixedMPU != g_FixedMPU.end(); itrFixedMPU++) {
			if(itrFixedMPU->first != gpid) {
				continue;
			}
			UI32 mpu_start = itrFixedMPU->second.first;
			UI32 mpu_end = itrFixedMPU->second.second;
			std::set<MEMRANGE>::iterator itr;
			for(itr = s.begin(); itr != s.end(); itr++) {
				UI32 mem_start = itr->first;
				UI32 mem_end = itr->second;
				UI32 start = 0, end = 0;
				if(mpu_start <= mem_start && mpu_end >= mem_start) {
					start = mem_start;
					end = (mpu_end >= mem_end) ? mem_end : mpu_end;
				} else if(mpu_start >= mem_start && mpu_start <= mem_end) {
					start = mpu_start;
					end = (mpu_end <= mem_end) ? mpu_end : mem_end;
				}
				if(start != end){
					awf.Set(start, end, aw.GetWeight(*itr));
				}
			}
		}
		aw = awf;
	}*/

	if(aw.Count() == 0) {
		return false;
	}
	
	// アクセス（R/W)に即した検証空間のアドレス重み一覧を得る（コピー取得）

	if (m_vConst->IsLock() == true) {
		// 前回のセグメントリストを復帰させる
		pReg->m_pSim->GetSegmentList(pSl, m_mr.first, m_mr.second, atype, pReg->m_ht, m_vConst->m_nSzm);
		return true;
	}

#ifdef DBGMODE
	if (debug_flag) {
		aw.Dump();
	}
#endif
	
	// アドレス重み一覧（aw）から候補を得る（重みに従って候補を探す）
	// （アラインを加味して）適合するサイズに満たないものは候補外となる。
	// 適合する領域が見付かった場合、そのアドレス範囲の情報（MPU/MMUアクセス情報）を得る。
	while (aw.Count()) {
		mr = aw.SelectRange();
		
		MEMADDR mrlen = (mr.second - mr.first + 1);
		if (mrlen < m_vConst->m_nSzm) {
			// サイズそのものが足りない場合は候補削除
			aw.Delete(mr);
			continue;
		}
#ifdef DBGMODE
		if (debug_flag) {
			printf ("range = %llx - %llx\n", mr.first,mr.second);	
			printf ("mrlen = %lld\n", mrlen);	
			printf ("asize = %d\n", m_vConst->m_nSzm);	
			printf ("align = 0x%x\n", m_vConst->m_nUnA);	
			printf ("mask  = 0x%llx\n", m_vConst->m_nMsk);
		}
#endif
		if (m_vConst->m_nUnA) {
			// fa = 最初にミスアラインアクセス可能な位置
			MEMADDR  fa = ((mr.first & ~m_vConst->m_nMsk) +m_vConst->m_nUnA);
			if (mr.second < fa) {
				aw.Delete(mr);
				continue;
			} 
			if ( (mr.second - fa + 1) < m_vConst->m_nSzm ) {
				aw.Delete(mr);
				continue;
			}
		}else{
			// fa = (切り上げ方式で)最初にアラインアクセス可能な位置
			MEMADDR fa = (mr.first + m_vConst->m_nMsk) & ~m_vConst->m_nMsk;
			if (mr.second < fa) {
				aw.Delete(mr);
				continue;
			}
			if ( (mr.second - fa + 1) < m_vConst->m_nSzm ) {
				aw.Delete(mr);
				continue;
			}
		}
		bool raise = m_vConst->GetType(IValConstraint::RAISE_MERROR);

		pReg->m_pSim->GetSegmentList(pSl, mr.first, mr.second, atype, pReg->m_ht, m_vConst->m_nSzm);
		#ifdef DBGMODE
		if (debug_flag) {
			printf("Range 0x%08llx - 0x%08llx\n", mr.first, mr.second);
			pSl->Dump();
		}
		#endif

		UI32 judgeSize = m_vConst->m_nSzm + m_vConst->m_nUnA;
		if (pSl->IsAdjustable(!raise, judgeSize) != true) {
			aw.Delete(mr);
			continue;
		}else{
			m_vConst->SetSegmentList(pSl);
			m_mr = mr;
			return true;
		}
	}

	return false;
}

/**
 * @brief このオブジェクトを破棄します
 */
bool COprGRm::SetMemoryErrorControl(IRegulation* pReg, UI32 lnk) {

CSegmentList* pSl = NULL;
eMXU_ACCESS_TYPE atype = MXU_ACC_READ;

CAddressWeight	aw;
CAddressWeight	awf;
MEMRANGE		mr;
bool OprAtt_SMEM = Attr(IOperand::OPR_ATTR_SMEM);
bool OprAtt_LMEM = Attr(IOperand::OPR_ATTR_LMEM);

#ifdef DBGMODE
	bool debug_flag = false;
#endif
	
	if (m_vConst == NULL){
		return true;
	}

	// The constraints is not for Load/Store
	if(m_vConst->GetMemmoryArea(&aw, &atype, OprAtt_SMEM, OprAtt_LMEM, lnk) == false) {
		return true;
	}

	// Adjust memories for handler code to MPU fixed area.
	//if(m_vConst->GetType(IValConstraint::FIXED_MPU)) {
	//	std::set<MEMRANGE> s = aw.KeySet();
	//	std::vector<std::pair<UI32, MEMRANGE>>::iterator itrFixedMPU;
 //       UI32 gpid = 0, pswh = 0, hvcfg = 0;

 //       pReg->m_pSim->ReadNcReg(&hvcfg, 16, 1);
 //       if ((hvcfg & 0x1) != 0) {
 //           pReg->m_pSim->ReadNcReg(&pswh, 15, 0);
 //           gpid = (pswh >> 8) & 0x7;
 //       } else {
 //           gpid = g_hwInfo->m_gmnum;
 //       }

	//	for(itrFixedMPU = g_FixedMPU.begin(); itrFixedMPU != g_FixedMPU.end(); itrFixedMPU++) {
	//		if(itrFixedMPU->first != gpid) {
	//			continue;
	//		}
	//		UI32 mpu_start = itrFixedMPU->second.first;
	//		UI32 mpu_end = itrFixedMPU->second.second;
	//		std::set<MEMRANGE>::iterator itr;
	//		for(itr = s.begin(); itr != s.end(); itr++) {
	//			UI32 mem_start = itr->first;
	//			UI32 mem_end = itr->second;
	//			UI32 start = 0, end = 0;
	//			if(mpu_start <= mem_start && mpu_end >= mem_start) {
	//				start = mem_start;
	//				end = (mpu_end >= mem_end) ? mem_end : mpu_end;
	//			} else if(mpu_start >= mem_start && mpu_start <= mem_end) {
	//				start = mpu_start;
	//				end = (mpu_end <= mem_end) ? mpu_end : mem_end;
	//			}
	//			if(start != end){
	//				awf.Set(start, end, aw.GetWeight(*itr));
	//			}
	//		}
	//	}
	//	aw = awf;
	//}

	if(aw.Count() == 0) {
		return false;
	}
	
	// アクセス（R/W)に即した検証空間のアドレス重み一覧を得る（コピー取得）

	if (m_vConst->IsLock() == true) {
		// 前回のセグメントリストを復帰させる
		pReg->m_pSim->GetSegmentList(pSl, m_mr.first, m_mr.second, atype, pReg->m_ht, m_vConst->m_nSzm);
		return true;
	}

#ifdef DBGMODE
	if (debug_flag) {
		aw.Dump();
	}
#endif
	
	// アドレス重み一覧（aw）から候補を得る（重みに従って候補を探す）
	// （アラインを加味して）適合するサイズに満たないものは候補外となる。
	// 適合する領域が見付かった場合、そのアドレス範囲の情報（MPU/MMUアクセス情報）を得る。
	while (aw.Count()) {
		mr = aw.SelectRange();
		
		MEMADDR mrlen = (mr.second - mr.first + 1);
		if (mrlen < m_vConst->m_nSzm) {
			// サイズそのものが足りない場合は候補削除
			aw.Delete(mr);
			continue;
		}
#ifdef DBGMODE
		if (debug_flag) {
			printf ("range = %llx - %llx\n", mr.first,mr.second);	
			printf ("mrlen = %lld\n", mrlen);	
			printf ("asize = %d\n", m_vConst->m_nSzm);	
			printf ("align = 0x%x\n", m_vConst->m_nUnA);	
			printf ("mask  = 0x%llx\n", m_vConst->m_nMsk);
		}
#endif
		if (m_vConst->m_nUnA) {
			// fa = 最初にミスアラインアクセス可能な位置
			MEMADDR  fa = ((mr.first & ~m_vConst->m_nMsk) +m_vConst->m_nUnA);
			if (mr.second < fa) {
				aw.Delete(mr);
				continue;
			} 
			if ( (mr.second - fa + 1) < m_vConst->m_nSzm ) {
				aw.Delete(mr);
				continue;
			}
		}else{
			// fa = (切り上げ方式で)最初にアラインアクセス可能な位置
			MEMADDR fa = (mr.first + m_vConst->m_nMsk) & ~m_vConst->m_nMsk;
			if (mr.second < fa) {
				aw.Delete(mr);
				continue;
			}
			if ( (mr.second - fa + 1) < m_vConst->m_nSzm ) {
				aw.Delete(mr);
				continue;
			}
		}
		bool raise = m_vConst->GetType(IValConstraint::RAISE_MERROR);

		pReg->m_pSim->GetSegmentList(pSl, mr.first, mr.second, atype, pReg->m_ht, m_vConst->m_nSzm);
		#ifdef DBGMODE
		if (debug_flag) {
			printf("Range 0x%08llx - 0x%08llx\n", mr.first, mr.second);
			pSl->Dump();
		}
		#endif
	
		UI32 judgeSize = m_vConst->m_nSzm + m_vConst->m_nUnA;
		if (pSl->IsAdjustable(!raise, judgeSize) != true) {
			aw.Delete(mr);
			continue;
		}else{
			m_vConst->SetSegmentList(pSl);
			m_mr = mr;
			return true;
		}
	}

	return false;
}




/////////////////////////////////////////////////////////
// Class :: COprGRpi
// Desc  :: PREFETCH用のスペシャルオペランド
//          現在PC近傍に補正する。MPU/MAEなど一切無関係。
//          プリロードも作成しない
/////////////////////////////////////////////////////////
void COprGRpi::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();

	if (m_vConst==NULL){
		return;
	}
		
	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	
	//!< シミュレータから現在のPC値を読む
	UI32 pc = 0;
	UI32 psw = 0;
    psw = r->m_pSim->GetPSW();
	if ((psw & 0x80000000)==0) {
		if (r->m_pSim->ReadPC(&pc) != true) {
			std::runtime_error excep("Simulator error : Read NC:PC");
			throw excep;
		}
	}else{
		if (r->m_pSim->ReadPC(&pc, (SI32)r->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read TC:PC");
			throw excep;
		}
	}
	
	m_vConst->m_nMin = pc - 64;	// RedMine #62133#note-7
	m_vConst->m_nMax = pc + 64;	// RedMine #62133#note-7
	

	//!< Align制御
	if (m_vConst->IsValid(cur)) {
		if(r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)cur));
		}
		return;
	}
	
	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	UI64 sv = m_vConst->SelectValue();

    // Mechanism to reduce adjustment code
    if (sv < m_vConst->m_nMin + 6) sv += 6;  // Because inserting adjustment code cause PC of current instruction increase 6 byte

	//!< 補正情報
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)sv));
}


/////////////////////////////////////////////////////////
// Class :: COprGRmx
// Desc  :: 汎用レジスタ(MemoryAccess+Index)オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprGRmx::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "[r%d]%c", m_reg, m_idx);
	return std::string(code);
}


void COprGRmx::Regulate(IRegulation* r) {
	
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 base = 0, step = 0;
	UI32 size = (m_vConst==NULL) ? 4 : m_vConst->m_nSzm;
	UI32 repeat = r->GetRepeat();
	

	if (r->m_pSim->ReadGrReg(&base, (SI32)this->m_reg/* reg1 */, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
#ifdef DBGMODE
	printf(" now reg1(reg%d) : 0x%08x\n", m_reg, base) ;
#endif	
	if (r->m_depends != NULL) {
		if (r->m_pSim->ReadGrReg(&step, (SI32)r->m_depends->Idx()/* reg2 */, (SI32)r->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
    } else {
        step = size;
    }
	
	//!<  Post Inc/Dec addressing
	if(m_idx == '-') {
		base = base - (repeat - 1) * step;
	}
	size = size + (repeat - 1) * step;
    if (m_vConst != NULL) {
        m_vConst->m_nSzm = size;
    }
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}

	if (m_vConst == NULL || m_vConst->IsValid(base)) {
		//!< 現状が適正値である場合はそのままシミュレーションさせる
		r->m_vEa.push_back (std::pair<UI32,UI32>(base, size));
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)base));
			if(r->m_depends != NULL) {
				r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)r->m_depends->Idx()/* reg2 */, (UI32)step));
			}
		}
		return;
	}

	// この時点で何らかの補正が必要であることが確定する。
	r->ReSim();

	// 目標値取得
	UI64 sv = m_vConst->SelectValue();
    m_vConst->m_nSzm = size - (repeat - 1) * step;

#ifdef DBGMODE
	printf("m_nUnA  : %uld\n", m_vConst->m_nUnA) ;
	printf("m_nMsk  : %lld\n", m_vConst->m_nMsk) ;
	printf(" now sv : 0x%08llx\n", sv) ;
#endif
	// オフセットより目標値が大きい場合は、補正不可能になる。
	// オフセット側に合わせてベースを調整する(オフセットにr0が指定された場合、補正対象にならない)
	UI32 newBase;			// 調整後ベースアドレス

	//!< ベース補正	
	newBase = (UI32)sv;
	if(m_idx == '-') {
		newBase += (repeat - 1) * step;
	}
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, newBase));
	r->ReAsm();
	
	return;	
}



/////////////////////////////////////////////////////////
// Class :: COprRTypeGR
// Desc  :: 汎用レジスタ(MemoryAccess+Index)オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprRTypeGR::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "[r%d]!", m_reg);
	return std::string(code);
}


UI32 COprRTypeGR::BitReverse(UI32 v) {
 	v = ((v >> 1) & 0x55555555) | ((v & 0x55555555) << 1);
	v = ((v >> 2) & 0x33333333) | ((v & 0x33333333) << 2);
 	v = ((v >> 4) & 0x0F0F0F0F) | ((v & 0x0F0F0F0F) << 4);
	v = ((v >> 8) & 0x00FF00FF) | ((v & 0x00FF00FF) << 8);
	v = (v >> 16) | (v << 16);
	return v;
}


void COprRTypeGR::Regulate(IRegulation* r) {
	
	_ASSERT(r);
	_ASSERT(r->m_pSim);
	_ASSERT(r->m_depends);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 base, offset;
	UI16 e_offset;	/* effective-offset */
	
	if (r->m_pSim->ReadGrReg(&base, (SI32)this->m_reg/* reg1 */, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	if (r->m_depends != NULL) {
		if (r->m_pSim->ReadGrReg(&offset, (SI32)r->m_depends->Idx()/* reg2 */, (SI32)r->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
	}
	
	//!< アドレッシング方式セレクタ1
	e_offset = (UI16)this->BitReverse(offset << 16);
	
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	if (m_vConst == NULL || m_vConst->IsValid(base + e_offset)) {
		//!< 現状が適正値である場合はそのままシミュレーションさせる
		r->m_vEa.push_back (std::pair<UI32,UI32>(base + e_offset, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)base));
			if (r->m_depends != NULL) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx(), (UI32)offset));
			}
		}
		return;
	}

	// この時点で何らかの補正が必要であることが確定する。
	r->ReSim();

	// 目標値取得
	UI64 sv = m_vConst->SelectValue();
	
	// 補正開始
	// オフセットより目標値が大きい場合は、補正不可能になる。
	// オフセット側に合わせてベースを調整する(オフセットにr0が指定された場合、補正対象にならない)
	bool b_offset = false;	// オフセット側の補正有無
	UI32 newBase;			// 調整後ベースアドレス
	
	// ベースレジスタとオフセットレジスタが同一の場合(i.e. vld.dw [r6]%, r6, vr23)
	if ((r->m_depends != NULL) && (Idx() == r->m_depends->Idx())) {
		sv &= 0xffff0000;	// TODO:計算方法
		e_offset = 0;		// TODO:計算方法
		/* 必ずアラインアクセスにする! */
		m_vConst->m_nUnA = 0;
		b_offset = false;	// ベースの修正がオフセット側の補正になる（同一レジスタの為）
	}
	
	// e_offsetは符号拡張がないので補正不可能な場合をケアする 
	while (e_offset > sv) {
		e_offset >>= 1;		// オフセットを半減して調整可能にする
		b_offset = true;	// オフセット側も補正が必要
	}
	
	//!< ベース補正	
	newBase = (UI32)(sv - e_offset);
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg,newBase));
	
	//!< オフセット補正	
	if (b_offset) {
		//!< R-TYPE Addressing
		e_offset = this->BitReverse(e_offset << 16);
		offset = (offset & 0xFFFF0000) | e_offset;
		r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx(), offset));
	} else if (r->m_depends != NULL && r->IsForce()) {
		r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx(), offset));
	}
	
	r->ReAsm();
	
	return;	
}



/////////////////////////////////////////////////////////
// Class :: COprMTypeGR
// Desc  :: 汎用レジスタ(Modulo)オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprMTypeGR::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "[r%d]%%", m_reg);
	return std::string(code);
}

/* RTLのH/W実装節約により、意図外の動作はModuloにならない */
/* step > limitとならないように、命令として生成しないよう補正する */
bool COprMTypeGR::ModuloValid(UI16 index, SI16 step, UI16 limit) {

	/* step, limit, index に余計な補正しない場合、return trueする */

	if (0 || step < 0) {
		return (index <= limit);
	}

	return true;
}



void COprMTypeGR::Regulate(IRegulation* r) {
	
	_ASSERT(r);
	_ASSERT(r->m_pSim);
	_ASSERT(r->m_depends);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 base, offset, limit;
	SI16 step;
	UI16 index;		/* effective-offset (M-Typeの場合はindex) */
	UI16 limit16;	/* effective-offset (M-Typeの場合はindex) */
	
	/* reg1 */
	if (r->m_pSim->ReadGrReg(&base, (SI32)this->m_reg, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	/* reg2 */
	if (r->m_pSim->ReadGrReg(&offset, (SI32)r->m_depends->Idx(), (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	/* reg2 + 1 */
	if (r->m_pSim->ReadGrReg(&limit, (1 | (SI32)r->m_depends->Idx()), (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	step   = (SI16)(offset >> 16);
	index  = (UI16)(offset & 0xffff);
	limit16 = limit & 0xffff;
	
	//!< 現状が適正値である場合はそのままシミュレーションさせる
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	if (ModuloValid(index, step, (UI16)limit16) && (m_vConst == NULL || m_vConst->IsValid(base + index))) {
		r->m_vEa.push_back (std::pair<UI32,UI32>(base + index, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)base));
			r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx(), (UI32)offset));
			r->m_vGr.push_back(std::pair<UI32,UI32>((1 | (SI32)r->m_depends->Idx()), (UI32)limit));
		}
		return;
	}

	// この時点で何らかの補正が必要であることが確定する。
	r->ReSim();

	// 目標値取得
	// M-Typeの場合、目標値としては不完全な状態
	// step < 0のとき(step + index) > limitは通常の用途ではないため
	// RTLの動作と異なる(RTLは演算回路が省略されている)
	UI64 sv = m_vConst->SelectValue();
	
	// オフセットより目標値が大きい場合は、補正不可能になる。
	// オフセット側に合わせてベースを調整する(オフセットにr0が指定された場合、補正対象にならない)
	bool b_reg2  = false;	// オフセット&ステップレジスタの補正有無
	UI32 newBase;			// 調整後ベースアドレス
	UI32 U  = m_vConst ? m_vConst->m_nUnA : 0;
	UI32 M  = m_vConst ? m_vConst->m_nMsk : 0;
		
	// 2. (A-A-C) ベースレジスタとオフセットレジスタが同一の場合(i.e. vld.dw [r6]%, r6, vr23)
	if (Idx() == r->m_depends->Idx()) {
		// stepが負の場合のみlimitを修正する可能性がある。
		if(U != 0 && ((M + 1) >> 1) == U) {
			U--;
			m_vConst->m_nUnA = U;
		}
		UI16 newIndex = (((sv & 0xffff) >> 1) & ~(M>>1)) + U;		// Index部を抽出しMEA制御する(Baseとかぶるので補正必須)
		UI32 newBase = (sv & 0xffff0000) | newIndex;						// Baseの値作成
		r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, newBase));	// Baseの補正確定させる
		
		SI16 newStep  = (SI16)(sv >> 16);
		if (ModuloValid(newIndex, newStep, limit16) != true) {
			limit16 = g_rnd.GetRange((UI32)newIndex, 0xffffUL);
			limit = (limit & 0xffff0000) | limit16;
			r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx() | 1 , limit));	// limitの補正確定させる
		} else if(r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>((1 | (SI32)r->m_depends->Idx()), (UI32)limit));
		}
		r->ReAsm();
		return;	
	}

	// 3.(A-B-A) ベースレジスタとリミットレジスタが同一の場合(i.e. vld.dw [r7]%, r6, vr23)
	if (Idx() == (r->m_depends->Idx() | 1 )) {
		
		if (ModuloValid(index, step, limit16) != true) {
			index = g_rnd.GetRange(0UL, (UI32)(limit>>1));
			b_reg2 = true;
		}

		if (index & M) {
			// indexはアライン
			index &= ~M;
			b_reg2 = true;
		}
		if (step & M) {
			// stepはアライン
			step &= ~M;
			b_reg2 = true;
		}
		
		UI32 newBase = ((UI32)(sv - index) & ~M) + U;	/* 必ず補正 */
		r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, newBase));	// Baseの補正確定させる
		if (b_reg2) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx() , (((UI16)step)<<16)|index));	// step||indexの補正確定させる
		} else if (r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx() , (UI32) offset));
		}
		return;
	}
	
	// 1. ばらばら	
	// indexは符号拡張がないので補正不可能な場合をケアする 
	while (index > sv) {
		index >>= 1;		// オフセットを半減して調整可能にする
		b_reg2 = true;	// オフセット側も補正が必要
	}
	if (ModuloValid(index, step, limit16) != true) {
		index = g_rnd.GetRange(0UL, (UI32)limit16);
		b_reg2 = true;
	}
	if (index & M) {
		// indexはアライン
		index &= ~M;
		b_reg2 = true;
	}
	if (step & M) {
		// stepはアライン
		step &= ~M;
		b_reg2 = true;
	}
		
	//!< ベース補正	
	newBase = ((UI32)(sv - index) & ~M) + U;
	r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, newBase));
	
	//!< オフセット補正	
	if (b_reg2) {
		offset = (((UI16)step) << 16) | index;
		r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx(), offset));
	} else if (r->IsForce()) {
		r->m_vGr.push_back(std::pair<UI32,UI32>(r->m_depends->Idx(), offset));
	}
	if(r->IsForce()) {
		r->m_vGr.push_back(std::pair<UI32,UI32>((1 | (SI32)r->m_depends->Idx()), (UI32)limit));
	}
		
	r->ReAsm();
	
	return;	
}



/////////////////////////////////////////////////////////
// Class :: COprGRi1b
// Desc  :: 汎用レジスタ(ignore 0b) オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
IOperand* COprGRi1b::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt) & ~1U;
		m_bFixed	= true;
	}
	return this;
}

bool COprGRi1b::Replace(UI32 index) {
	if ((m_rh <= index) && (index <= m_rt) && ((index & 1) == 0)) {
		m_reg		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}



/////////////////////////////////////////////////////////
// Class :: COprGRi2b
// Desc  :: 汎用レジスタ(ignore 1-0b) オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
IOperand* COprGRi2b::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt) & ~3U;
		m_bFixed	= true;
	}
	return this;
}

bool COprGRi2b::Replace(UI32 index) {
	if ((m_rh <= index) && (index <= m_rt) && ((index & 3) == 0)) {
		m_reg		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}

/////////////////////////////////////////////////////////
// Class :: COprGRrh
// Desc  :: 汎用レジスタ(ignore 1-0b) オペランドを抽象化したクラス
//          マルチサイクル命令のオペランド
//          ミスアライン例外が起きずに暗黙でワードアラインされる
//          Storeは先減算で0側へ向かう、Loadは後加算で逆方向へ向かう
/////////////////////////////////////////////////////////
void COprGRrh::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);
	_ASSERT(r->m_depends);
	
	//!< 値制約を持たない場合はそのままシミュレーションさせる
	//if (m_vConst == NULL) {
	//	return;
	//}
	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)3/*SP*/, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}

	//!< Update protection info
	// SetMemoryErrorControl(r);
	
	//!< オペレーションタイプ(Load or Store)取得
	bool load = m_vConst->GetType(IValConstraint::LOAD_MEMORY);
	
	UI32 rh		= Idx();						/* start index */
	UI32 rt		= r->m_depends->Idx();			/* end   index */
	UI32 count	= (rh > rt) ? 0 : (rt - rh + 1);	/* count of load/store */
	UI32 e_adr	= cur & ~3;
	
    // Do not regulate operand in case of it does not access memory
    if (count == 0) return;

	if (m_vConst) {
		m_vConst->m_nSzm = (4 * count);		// 実効サイズを調整
	}

	//!< Update protection info
	m_vConst->m_nMsk = 3;	// 暗黙的に丸められる
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	m_vConst->m_nMsk = 0;	// アドレスとしてはアラインでなくてよい

	if (load != true && count != 0) {
		// Store(pushsp)はアドレスが０側へ進むため終端領域から検証する
		// またStoreは先に-4減算される
		e_adr = e_adr - (count * 4);
	}

	if (m_vConst == NULL || m_vConst->IsValid(e_adr)) {

		UI32 rh, rt, count = 0;
		
		// 実行時暗黙の丸め
		UI32 addr = cur & (~3UL);
		
		rh = Idx();
		rt = r->m_depends->Idx();
		for (UI32 p = rh; p <= rt; p++) {
			count++;	// popsp r3, r0もライトバックされないがロードはされる
		}
		if (load) {
			// アドレス後加算(popsp)
			for (UI32 i = 0; i < count; i++) {
				r->m_vEa.push_back(std::pair<UI32,UI32>(addr, 4));
				addr += 4;
			}
		}else{
			// アドレス前減算(pushsp/dbpush)
			for (UI32 i = 0; i < count; i++) {
				addr -= 4;
				r->m_vEa.push_back(std::pair<UI32,UI32>(addr, 4));
			}
		}
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(3/*SP*/, (UI32)cur));
		}
		return;
	}

	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	UI64 sv = m_vConst->SelectValue();
	if (load != true && count != 0) {
		//sv = sv - ((count - 1) * 4);	// Store(pushsp)はアドレスが０側へ進むため終端領域から検証する
		sv = sv + (count * 4);
	}
	
	//!< 補正情報
	r->m_vGr.push_back(std::pair<UI32,UI32>(3/*SP*/, (UI32)sv));
}


/////////////////////////////////////////////////////////
// Class :: COprPR
// Desc  :: 汎用ペアレジスタ オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
IOperand* COprPR::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt) & ~1U;
		m_bFixed	= true;
	}
	return this;
}

bool COprPR::Replace(UI32 index) {
	if ((m_rh <= index) && (index <= m_rt) && ((index & 1U) == 0)) {
		m_reg		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}

// ペアレジスタをメモリアドレスに補正することは無いはず
void COprPR::Regulate(IRegulation* pReg) {
	_ASSERT(pReg);
	_ASSERT((m_reg & 1) == 0);
	_ASSERT(pReg->m_pSim);
	
	//!< 値制約を持たない場合はそのままシミュレーションさせる
	if (m_vConst == NULL) {
		return;
	}

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 high, low;
	UI64 dw;
	if (pReg->m_pSim->ReadGrReg(&low, (SI32)Idx(), pReg->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	if (pReg->m_pSim->ReadGrReg(&high, (SI32)Idx() + 1, pReg->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	dw = ( ( ((UI64)high) << 32 ) | low );
	
	//!< 現状が適正値である場合はそのままシミュレーションさせる
	if (m_vConst->IsValid(dw)) {
		if(pReg->IsForce()) {
			pReg->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)low));
			pReg->m_vGr.push_back(std::pair<UI32,UI32>(m_reg + 1, (UI32)high));
		}
		return;
	}

	//!< この時点で何らかの補正が必要であることが確定する。
	pReg->ReSim();
	pReg->ReAsm();
		
	UI64 sv = m_vConst->SelectValue();
	pReg->m_vGr.push_back(std::pair<UI32,UI32>(Idx()+1,(UI32)(sv>>32)));
	// Highだけの補正で適合するか
	if (m_vConst->IsValid((sv & 0xffffffff00000000) | low) != true) {
		pReg->m_vGr.push_back(std::pair<UI32,UI32>(Idx(),(UI32)(sv & 0xffffffff)));
	} else if(pReg->IsForce()) {
		pReg->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)low));
	}
	
	return;	
}

UI32 COprPR::Idx() {
	(void*)Fix();
	return m_reg;
}



/////////////////////////////////////////////////////////
// Class :: COprPRMod
// Desc  :: 汎用レジスタ(Modulo)オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
void COprPRMod::Regulate(IRegulation* r) {
	
	_ASSERT(r);
	_ASSERT(r->m_pSim);
	
	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 reg2, reg2p;
	SI16 step;
	UI16 index;		/* effective-offset (M-Typeの場合はindex) */
	UI16 limit;	/* effective-offset (M-Typeの場合はindex) */
	
	/* reg2 */
	if (r->m_pSim->ReadGrReg(&reg2, (SI32)this->m_reg, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	/* reg2+1 */
	if (r->m_pSim->ReadGrReg(&reg2p, (1 | (SI32)this->m_reg), (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	
	step	= (SI16)(reg2  >> 16);
	index	= (UI16)(reg2  & 0xffff);
	limit	= (UI16)(reg2p & 0xffff);
	
	UI32 rvalue = g_rnd.Get();
	
	// 両方ゼロの場合は５０％の確率で補正してみる。
	if (((reg2|reg2p)==0) && (rvalue & 1)) {
		// ng
	}else{
		if (index <= limit) { //(ModuloValid(index, step, (UI16)limit)) {
			//MSG_ERROR(0, "MODADD r%d (r%d=%08X, r%d=%08X)\n", m_reg, m_reg, reg2, 1|m_reg, reg2p);
			if(r->IsForce()) {
				r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)this->m_reg, (UI32)reg2));
				r->m_vGr.push_back(std::pair<UI32,UI32>((1 | (SI32)this->m_reg), (UI32)reg2p));
			}
			return; // OK
		}
	}
	
	// 補正確定
	r->ReAsm();
	
	bool bR2  = false;
	bool bR2p = false;
	
	rvalue = g_rnd.Get();
	bR2 = ((rvalue & 1) == 0);
	bR2p = !bR2;
	
	rvalue >>= 4;
	if (index == 0 && ((rvalue & 7) != 0)) {
		UI32 n = g_rnd.Get();
		index = (UI16)(n & 0xffff);
		step  = (SI16)(n >> 16);
		bR2 = true;
	}
	
	// Indexを補正する
	if (bR2 || (rvalue & 0x80)) {
		// indexを補正する
		index = g_rnd.GetRange((UI32)0, (UI32)limit);
		r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (step<<16 | index)));
	} else if(r->IsForce()) {
		r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)this->m_reg, (UI32)reg2));
	}
	if (bR2p && (index > limit)) {
		// limitを補正する
		limit = g_rnd.GetRange((UI32)index, (UI32)0xffff);
		r->m_vGr.push_back(std::pair<UI32,UI32>((m_reg|1), ((reg2p & 0xffff0000) | limit)));
	} else if(r->IsForce()) {
		r->m_vGr.push_back(std::pair<UI32,UI32>((1 | (SI32)this->m_reg), (UI32)reg2p));
	}
	_ASSERT(index <= limit);
	return;
}



/////////////////////////////////////////////////////////
// Class :: COprDispReg
// Desc  :: ディスプレースメント+汎用レジスタを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprDispReg::GetCode() {
	char code[OPR_CODEBUF];
	(void*)Fix();
	sprintf(code, "0x%x[r%d]", m_disp, m_reg);
	return std::string(code);
}

IOperand* COprDispReg::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt);// & ~1U;
		m_disp		= m_pRand->GetRange((SI32)m_dh, (SI32)m_dt) & ~3U;
		m_bFixed	= true;
	}
	return this;
}

UI32 COprDispReg::Idx() {
	(void*)Fix();
	return m_reg;
}

void COprDispReg::Regulate(IRegulation* r) {
	
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	// Load protection info)
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	
	// Load protection info
	Correction(r);
}

void COprDispReg::Correction(IRegulation* r) {

	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}

	//!< 現状が適正値である場合はそのままシミュレーションさせる
	if ((m_vConst == NULL) || m_vConst->IsValid(m_disp + cur)) {
		r->m_vEa.push_back(std::pair<UI32,UI32>(m_disp + cur,(m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		if(r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)m_reg, (UI32)cur));
		}
		return;
	}
	
	if (m_vConst != NULL) {
        SetDisp(m_pRand->GetRange((SI32)m_dh, (SI32)m_dt) & m_nMask);
		m_vConst->SelectValue(); // Update upper-lower
	}
	
	UI32 U  = m_vConst->m_nUnA;
	UI32 M  = m_vConst->m_nMsk;
	UI32 mx = (m_vConst->m_nMax+1 >= m_vConst->m_nSzm) ? (m_vConst->m_nMax-m_vConst->m_nSzm+1):0;
	UI32 mn = m_vConst->m_nMin;

    if (mn > mx) {
        r->GiveUp();
        return;
    }

	UI32 tmp_disp = m_disp;
	
	/**
	 *   @brief dispが＋側に大きすぎて目標値に調整不可能である。<br>
	 * 
	 *  <pre>
	 *   0           REG                        L********U                    FF..FF 
	 *   ├──────┼─────────────┼━━━━┼───────────┤
	 *   #-------------------------------------------------------> disp
	 *  </pre>
	 */
	while (tmp_disp > mx) {
		tmp_disp /= 2;
	}
	tmp_disp &= ~M;
	
	/* 一時補正（dispだけで調整が不可能である部分について補正） */
	if (tmp_disp != m_disp) {
		m_disp = tmp_disp;
	}
	r->ReAsm();
	m_dh &= ~M;
	m_dt &= ~M;
		
	/**
	 * @brief 1. レジスタ値が範囲の下限以下の場合<br>
	 * 
	 * <pre>
	 *   0           REG                        L********U                    FF..FF 
	 *   ├──────┼─────────────┼━━━━┼───────────┤
	 *          1.1   #---- disp ---->
	 *          1.2   #------------ disp ----------->
	 *          1.3   #------------------ disp ----------------->
	 * </pre>
	 */
	if (cur < mn) {	
		//!<  目標下限値とレジスタ値の差がDispNで表現しきれない大きさ
		if ((mn - cur) > m_dt) {
			//!< 1.1  補正不可(最大の補正を行っても目標に届かない)
			UI32 val = (m_pRand->GetRange(mn,mx) & ~M) + U;		// 目標値決定
			r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), (val-m_disp)));
		} else {
			//!< 1.2, 1,3  補正により届く範囲
			UI32 upper = std::min(mx - cur, m_dt); 
			tmp_disp = m_pRand->GetRange((mn - cur), upper) & ~M;
			SetDisp(tmp_disp);
			cur = cur + (tmp_disp - m_disp);                       // SetDisp may not be successful
			
			//!< アライン制御でGRの値が補正必要な場合がある。
			if ((U != 0) && (m_vConst->IsAligned(cur) == true)) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur + U));
			}else
			if ((U == 0) && (m_vConst->IsAligned(cur) != true)) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur & ~M));
			} else
			if(r->IsForce() || tmp_disp != m_disp) {
				r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)m_reg, (UI32)cur));
			}
		}	
	} else
	/**
	 * @brief 2. レジスタ値が範囲の上限以上の場合、dispを符号拡張子無い為、調整不可能<br>
	 * 
	 * <pre>
	 *   0            L********U      REG                                      FF..FF 
	 *   ├──────┼━━━━┼───┼─────────────────────┤
	 *                                 #--------- disp ---------->
	 *
	 *   2.1. REG=0にしても目標に調整不可能なケースは既に調整してある
	 *  
	 *   REG          L********U                                               FF..FF 
	 *   ├──────┼━━━━┼─────────────────────────┤
	 *   #--------- disp ---------->
	 * </pre>
	 */
	if (cur > mx) {
		//!< 2. レジスタ値が範囲の上限以上の場合
		// (cur - (cur + m_disp - val)) => (val - m_disp)
		UI32 val = (m_pRand->GetRange(mn, mx) & ~M) + U; // 目標値決定
		r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), val-m_disp));
	} else
	{
		//!< 3. レジスタ値が範囲内にある場合
		//!< アンアライン検出
		UI32 upper = std::min(mx - cur, m_dt); 
		tmp_disp = m_pRand->GetRange((UI32)0, upper) & ~M;
		SetDisp(tmp_disp);
		cur = cur + (tmp_disp - m_disp);
		//!< アライン制御でGRの値が補正必要な場合がある。
		if ((U != 0) && (m_vConst->IsAligned(cur) == true)) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur + U));
		}else
		if ((U == 0) && (m_vConst->IsAligned(cur) != true)) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur & ~M));
		} else
		if(r->IsForce() || tmp_disp != m_disp) {
			r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)m_reg, (UI32)cur));
		}
	}
	
	return;
}


bool COprDispReg::Replace(UI32 index) {
	if ((m_rh <= index) && (index <= m_rt)) {
		m_reg		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}

/**
* @brief aline memory data
* @param PFETCHSIZE: size data will be align
*/
void COprDispReg::AlignData(ISimulator* m_pSim, UI32 PFETCHSIZE) {
    UI32 addr;
    UI64	addr_a;
    const UI64 PSIZE = 4ULL;
    const UI64 ALIGN = ~(PFETCHSIZE - 1);
    UI32 DispVal = (UI32)(*this);
    m_pSim->ReadGrReg(&addr, Idx(), 0); //TODO:Multi thread not support
    addr += DispVal;					// No Align head
    addr_a = addr & ALIGN;			// Align head
    m_pSim->SetSysMemPreset(addr_a, PSIZE, 0ULL);
    if (PFETCHSIZE == 8)
        m_pSim->SetSysMemPreset(addr_a + PSIZE, PSIZE, 0ULL);
}



/////////////////////////////////////////////////////////
// Class :: COprSDispReg
// Desc  :: 符号つきディスプレースメント+汎用レジスタを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprSDispReg::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	if (m_disp < 0) {//& 0x80000000) {
		sprintf(code, "%d[r%d]", (SI32)m_disp, m_reg);
	} else {
		sprintf(code, "0x%x[r%d]",(UI32)m_disp, m_reg);
	}
	return std::string(code);
}

IOperand* COprSDispReg::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt);// & ~1U;
		m_disp		= m_pRand->GetRange((SI32)m_dh, (SI32)m_dt) & m_nMask;
		m_bFixed	= true;
	}
	return this;
}

UI32 COprSDispReg::Idx() {
	(void*)Fix();
	return m_reg;
}


void COprSDispReg::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	// Load protection info
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	Correction(r);
}


void COprSDispReg::Correction(IRegulation* r) {

	//!< シミュレータから現在の値を読む
	UI32 regValue;
	if (r->m_pSim->ReadGrReg(&regValue, (SI32)m_reg, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}

	SI64 cur = regValue;								// 符号計算の為
	SI32 tmp_disp = m_disp;
	
	//!< 現状が適正値である場合はそのままシミュレーションさせる
	if ((m_vConst == NULL) || m_vConst->IsValid(m_disp + regValue)) {
		r->m_vEa.push_back(std::pair<UI32,UI32>(m_disp + cur,(m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		if(m_vConst != NULL && r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)regValue));
		}
		return;
	}

	if (m_vConst) {
        SetDisp(m_pRand->GetRange((SI32)m_dh, (SI32)m_dt) & m_nMask);
        tmp_disp = m_disp;
		m_vConst->SelectValue(); // Update upper-lower
	}
	UI32 M  = m_vConst ? m_vConst->m_nMsk : 0;			// アラインマスク(i.e. M=0ならミスアラインが発生しないバイトアクセス)
	UI32 U  = m_vConst ? m_vConst->m_nUnA : 0;			// アラインされた値に足す値（強制的なアンアラインドアクセス　i.e.U=0ならアラインアクセスを意味する）
	SI64 mx = m_vConst ? (SI64)((m_vConst->m_nMax+1 >= m_vConst->m_nSzm) ? (m_vConst->m_nMax-m_vConst->m_nSzm+1):0) : 0;    // 符号計算の為
	SI64 mn = m_vConst ? (SI64)m_vConst->m_nMin : 0;	// 符号計算の為

    if (mn > mx) {
        r->GiveUp();
        return; 
    }
	//m_vConst->Dump();
	//!< この時点で何らかの補正が必要であることが確定する。
	r->ReSim();
	
	/*
	 *   0           REG                        L********U                   FF..FF 
	 *   ├──────┼─────────────┼━━━━┼───────────┤
	 *    -------------------------------------------------------> disp
	 *   dispが＋側に大きすぎて目標値に調整不可能である。
	 *   REG（Base）だけで補正が出来ない(ラップアラウンドすれば良いが検討)
	 */
	while (tmp_disp > mx) {
		tmp_disp /= 2;
	}

	/*
	 *   0              L********U                   Reg                    FF..FF 
	 *   ├───────┼━━━━┼──────────┼────────────┤
	 * 		 disp <-----------------------------------------------------------
	 * 	     dispが-側に大きすぎて目標値に調整不可能である。
	 *       REG（Base）だけで補正が出来ない(ラップアラウンドすれば良いが検討)
	 */
	while (std::abs(tmp_disp) > std::abs(mn - 0xffffffff)) {
		tmp_disp /= 2;
	}
	
	tmp_disp &= ~M;

	/* 一時補正（dispだけで調整が不可能である部分について補正） */
	if (tmp_disp != m_disp) {
		SetDisp(tmp_disp);
	}
	tmp_disp = m_disp;

#if !defined(NDEBUG) && 0
/*DEBUG*/		printf("-------%s(%d)---------\n", __FUNCTION__, __LINE__);
/*DEBUG*/		printf("cur  = %016llX\n", cur);
/*DEBUG*/		printf("disp = %d (0x%08X)\n", m_disp, m_disp);
/*DEBUG*/		printf("MAX = %016llX\n", m_vConst->m_nMax);
/*DEBUG*/		printf("MIN = %016llX\n", m_vConst->m_nMin);
/*DEBUG*/		printf("MSK = %08X\n", M);
#endif
	
	r->ReAsm();
	
	/**
	 * @brief 1. インデックスレジスタの現在値が目標範囲の下限以下の場合<br>
	 * <pre>
	 *     0           REG                        L********U                     FF..FF 
	 *     ├──────┼─────────────┼━━━━┼───────────┤
	 * 1.1 dispX表現範囲 ------>                                                     reg値(base)アドレスの補正
	 * 1.2 dispY表現範囲 --------------------------->                                disp値(offset)の補正(余分な命令を挿入せずに済む)
	 * 1.3 dispZ表現範囲 --------------------------------------------------->        disp値(offset)の補正(余分な命令を挿入せずに済む)
	 * </pre>
	 */
	m_dh &= ~M;
	m_dt &= ~M;
	
	if (cur < mn) {	
		//!< 1.1 目標下限値とレジスタ値の差がDispNで表現しきれない大きさ
		if ((mn - cur) > m_dt) { // if ((目標下限 - 現在レジスタ値) > disp表現最大値+アンアラインシフト)
			UI32 val = (m_pRand->GetRange(mn,mx) & ~M) + U; // 目標値決定 
			if (m_disp > 0) {
				//!< dispの符号は正方向
				while ((UI32)tmp_disp > (UI32)val) {
					tmp_disp >>=1; // disp大きすぎる
				}
				SetDisp (tmp_disp);
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), (UI32)(val-m_disp)));
				
			} else {
				//!< dispの符号は負方向
				while ((UI32)(std::abs(tmp_disp)) > (0xffffffff - val)) {
					tmp_disp >>= 1; // disp大きすぎる
				}
				SetDisp (tmp_disp);
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), (UI32)(val-m_disp)));				
			}
		} else {
			//!< 1.2, 1,3  Dispを補正することにより目標範囲に届く
			UI32 upper = std::min((UI32)(mx - cur), (UI32)std::abs(m_dt)); 
			tmp_disp = m_pRand->GetRange((UI32)(mn - cur), upper) & ~M; // dispは常にアライン値にしないとアセンブル出来ない
			SetDisp (tmp_disp);
            cur = cur + (tmp_disp - m_disp);                       // SetDisp may not be successful
			
			//!< アライン制御でGRの値が補正必要な場合がある。
			if ((U != 0) && (m_vConst->IsAligned(cur) == true)) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur + U));
			}else
			if ((U == 0) && (m_vConst->IsAligned(cur) != true)) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur & ~M));
			} else
			if(r->IsForce() || tmp_disp != m_disp) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)regValue + (tmp_disp - m_disp)));
			}
		}		
	} else
	/**
	 * @brief 2. インデックスレジスタの現在値が目標範囲の上限以上の場合
	 * <pre>
	 *            mn       mx                        cur
	 *   0         L********U                        Reg                    FF..FF 
	 *   ├────┼━━━━┼─────────────┼────────────┤
	 *                      <------------------------>  disp(negative)
	 *                 <----------------------------->  disp(negative)
	 *                (A)  (D)                       (B)
	 * 
	 *       <--------------------------------------->  disp(negative)
	 *      (C)
	 * </pre>
	 */
	if (cur > mx) {
		//!< dispの符号は負方向
		//!< 2.1 上限値とレジスタ値の差がDispNで表現しきれない大きさ
		if ((cur + m_dh) > mx) {
			/* レジスタ側で補正 */
			SI64 val = (m_pRand->GetRange(mn, mx) & ~M) + U; // 目標値決定
			r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), (val-m_disp))); //#9060Q33 
		} else {
			/* ！ dispで補正 */
			/* NewDisp = Random ((A)-(B) 〜 (D)-(B)) */
			/*     (D)-(B) = mx - cur */
			/*     (A)-(B) = mx - cur */
			//SI64 lower = std::min((SI64)cur-std::abs(m_dh), (SI64)m_dt);
			SI64 lower = std::max((SI64)cur+m_dh, (SI64)mn);
			tmp_disp = m_pRand->GetRange((SI64)lower-cur, (SI64)mx-cur)  & ~M;
			SetDisp (tmp_disp);
			cur = cur + (tmp_disp - m_disp);
			
			// アライン制御でGRの値が補正必要な場合がある。
			if ((U != 0) && (m_vConst->IsAligned(cur) == true)) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur + U));
			}else
			if ((U == 0) && (m_vConst->IsAligned(cur) != true)) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur & ~M));
			} else
			if(r->IsForce() || tmp_disp != m_disp) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)regValue + (tmp_disp - m_disp)));
			}
		}
	} else
	//!< 3. インデックスレジスタの現在値が目標範囲内にある場合
	{
		//!< アライン制御でGRの値が補正必要な場合がある。
		if ((U != 0) && (m_vConst->IsAligned(cur) == true)) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur + U));
		}else
		if ((U == 0) && (m_vConst->IsAligned(cur) != true)) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(Idx(), cur & ~M));
		} else
		if (m_vConst->IsValid(cur + m_disp) != true) {
			SetDisp(0);
			if(r->IsForce() || m_disp != 0) {
				r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)(regValue - m_disp)));
			}
		} else
		if(r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)regValue));
		}
	}
}


bool COprSDispReg::Replace(UI32 index) {
	if ((m_rh <= index) && (index <= m_rt)) {
		m_reg		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}

bool COprSDispReg::SetRange(UI32 rh, UI32 rt) {
	m_rh = rh;
	m_rt = rt;
	return true;
}

/**
* @brief aline memory data
* @param PFETCHSIZE: size data will be align
*/
void COprSDispReg::AlignData(ISimulator* m_pSim, UI32 PFETCHSIZE) {
    UI32 addr;
    UI64	addr_a;
    const UI64 PSIZE = 4ULL;
    const UI64 ALIGN = ~(PFETCHSIZE - 1);
    UI32 DispVal = (UI32)(*this);
    m_pSim->ReadGrReg(&addr, Idx(), 0); //TODO:Multi thread not support
    addr += DispVal;					// No Align head
    addr_a = addr & ALIGN;			// Align head

    m_pSim->SetSysMemPreset(addr_a, PSIZE, 0ULL);
    if (PFETCHSIZE == 8)
        m_pSim->SetSysMemPreset(addr_a + PSIZE, PSIZE, 0ULL);
}


/////////////////////////////////////////////////////////
// Class :: COprDispEP
// Desc  :: ディスプレースメント + EPを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprDispEP::GetCode() {
	char code[8];
	(void*)Fix();
	sprintf(code, "0x%x[ep]", m_disp);
	return std::string(code);
}



/////////////////////////////////////////////////////////
// Class :: COprSP
// Desc  :: SPを抽象化するクラス
/////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////
// Class :: COprSR
// Desc  :: システムレジスタオペランドを抽象化したクラス
/////////////////////////////////////////////////////////

ISysRegSet* COprSR::m_pSrSource = NULL;

IOperand* COprSR::Fix() {
	
	if (!m_bFixed) {
		if (m_pSrSource) {
			m_sr = m_pSrSource->Select(m_filter);
		} 
		m_bFixed	= true;
	}
	return this;
}



/////////////////////////////////////////////////////////
// Class :: COprFSR
// Desc  :: 固定システムレジスタオペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprFSR::GetCode() {
	_ASSERT(0);
	return std::string("");
}


COprFSR::operator UI32(){
	return m_sel * 32 + m_reg;
}



/////////////////////////////////////////////////////////
// Class :: COprVR
// Desc  :: ベクトルレジスタオペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprVR::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "vr%d", m_vr);
	return std::string(code);
}

IOperand* COprVR::Fix() {
	if (!m_bFixed) {
		m_vr		= m_pRand->GetRange(m_rh, m_rt);
		m_bFixed	= true;
	}
	return this;
}

bool COprVR::Replace(UI32 index) {
	if (m_rh <= index && index <= m_rt) {
		m_vr = index;
		m_bFixed = true;
		return true;
	}
	return false;
}



/////////////////////////////////////////////////////////
// Class :: COprVPR
// Desc  :: ベクトルペアレジスタオペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprVPR::GetCode() {
	char code[8];
	(void*)Fix();
	
	sprintf(code, "vr%d", m_vr);
	return std::string(code);
}

IOperand* COprVPR::Fix() {
	if (!m_bFixed) {
		m_vr		= m_pRand->GetRange(m_rh, m_rt) & ~1U;
		m_bFixed	= true;
	}
	return this;
}



/////////////////////////////////////////////////////////
// Class :: COprImm
// Desc  :: 即値オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprImm::GetCode() {
	
	char code[32];
	
	(void*)Fix();
	sprintf(code, "%#x", m_nVal);
	return std::string(code);
}

IOperand* COprImm::Fix() {
	if (!m_bFixed) {
		m_nVal		= m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax) & m_nMask;
		m_bFixed	= true;
	}
	return this;
}

bool COprImm::Replace(UI32 new_val) {
	if (m_nMin <= new_val && new_val <= m_nMax && (new_val == (new_val & m_nMask))) {
		m_nVal		= new_val;
		m_bFixed	= true;
		return true;
	}
	return false;
}
bool COprImm::SetRange(UI32 rh, UI32 rt) {
	m_nMin = rh;
	m_nMax = rt;
	return true;
}

void COprImm::Regulate(IRegulation* r) {
	(void*)Fix();
	
	//!< 値制約を持たない場合はそのままシミュレーションさせる
	if (m_vConst == NULL) {
		return;
	}
	if (m_vConst->IsValid(m_nVal)) {
		return;
	}
	this->Replace(m_vConst->SelectValue());
}

COprImm::operator UI32() {
	(void*)Fix();
	return m_nVal;
}


/////////////////////////////////////////////////////////
// Class :: COprSImm
// Desc  :: 即値オペランドを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprSImm::GetCode() {
	
	char code[32];
	
	(void*)Fix();
	sprintf(code, "%d", m_nVal);
	return std::string(code);
}

IOperand* COprSImm::Fix() {
	if (!m_bFixed) {
		m_nVal		= m_pRand->GetRange((SI32)m_nMin,(SI32)m_nMax);
		m_bFixed	= true;
	}
	return this;
}

bool COprSImm::Replace(UI32 index) {
	SI32 vtmp = (SI32) index;
	if (m_nMin <= vtmp && vtmp <= m_nMax) {
		m_nVal		= vtmp;
		m_bFixed	= true;
		return true;
	}
	return false;
}

COprSImm::operator UI32() {
	(void*)Fix();
	return (UI32)(m_nVal);
}



/////////////////////////////////////////////////////////
// Class :: COprDisp
// Desc  :: ディスプレースメントを抽象化したクラス
/////////////////////////////////////////////////////////
IOperand* COprDisp::Fix() {
	if (!m_bFixed) {
		m_nVal		= m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax) & ~1U;
		m_bFixed	= true;
	}
	return this;
}

bool COprDisp::Replace(UI32 index) {
	if (m_nMin <= index && index <= m_nMax && ((index&1)==0)) {
		m_nVal		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}



/////////////////////////////////////////////////////////
// Class :: COprSDisp
// Desc  :: 符号拡張ありディスプレースメントを抽象化するクラス
/////////////////////////////////////////////////////////
IOperand* COprSDisp::Fix() {
	if (!m_bFixed) {
		m_nVal		= m_pRand->GetRange((SI32)m_nMin,(SI32)m_nMax) & ~1U;
		m_bFixed	= true;
	}
	return this;
}

bool COprSDisp::Replace(UI32 index) {
	SI32 vtmp = (SI32)index;
	if (m_nMin <= vtmp && vtmp <= m_nMax && ((vtmp&1)==0)) {
		m_nVal		= vtmp;
		m_bFixed	= true;
		return true;
	}
	return false;
}



/////////////////////////////////////////////////////////
// Class :: COprCond
// Desc  :: condを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprCond::GetCode() {
	
	static const char* const cond[] = {
		"V",	"C/L",	"Z",	"NH",
		"S/N",	"T",	"LT",	"LE",
		"NV",	"NC/NL","NZ",	"H",
		"NS/P",	"SA",	"GE",	"GT"
	};
	
	(void*)Fix();
	_ASSERT(m_nVal < 0x10);
	return std::string(cond[m_nVal]);
}



/////////////////////////////////////////////////////////
// Class :: COprCondn13
// Desc  :: cond(cccc ≠ 13)を抽象化するクラス
/////////////////////////////////////////////////////////
IOperand* COprCondn13::Fix() {
	while (!m_bFixed || m_nVal==13) {
		m_nVal		= m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
		m_bFixed	= true;
	}
	return this;
}

bool COprCondn13::Replace(UI32 index) {

	if (m_nMin <= index && index <= m_nMax && (index!=13)) {
		m_nVal		= index;
		m_bFixed	= true;
		return true;
	}
	return false;
}



/////////////////////////////////////////////////////////
// Class :: COprPrefOp
// Desc  :: prefopを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprPrefOp::GetCode() {
	
	static const char* const prefop[] = {
		"PREFI", "PREFD"
	};
	
	(void*)Fix();
	_ASSERT(m_nVal < 0x2);
	return std::string(prefop[m_nVal]);
}



/////////////////////////////////////////////////////////
// Class :: COprCacheOp
// Desc  :: cacheopを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprCacheOp::GetCode() {
	
	static const char* const cacheop[] = {
		"CHBII",	"CIBII",	"CFALI",	"CISTI",
		"CILDI",	"CHBID",	"CHBIWBD",	"CHBWBD",
		"CIBID",	"CIBIWBD",	"CIBWBD",	"CFALD",
		"CISTD",	"CILDD",	"CLL"
	};
	
	(void*)Fix();
	
	/* 暫定 CLL非対応*/
	if (m_nVal == m_nMax) {m_nVal=0;} 
	
	_ASSERT(m_nVal < 0xF);
	return std::string(cacheop[m_nVal]);
}



/////////////////////////////////////////////////////////
// Class :: COprFCond
// Desc  :: fcondを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprFCond::GetCode() {
	
	static const char* const cond[] = {
		"F",	"UN",	"EQ",	"UEQ",
		"OLT",	"ULT",	"OLE",	"ULE",
		"SF",	"NGLE",	"SEQ",	"NGL",
		"LT",	"NGE",	"LE",	"NGT"
	};
	
	(void*)Fix();
	_ASSERT(m_nVal < 0x10);
	return std::string(cond[m_nVal]);
}



/////////////////////////////////////////////////////////
// Class :: COprFcbit
// Desc  :: fcbitを抽象化するクラス
/////////////////////////////////////////////////////////
std::string COprFcbit::GetCode() {

	(void*)Fix();
	_ASSERT(m_nVal < 0x8);
		
	std::stringstream ss;
	ss << std::dec << m_nVal;
	return ss.str();
}



/////////////////////////////////////////////////////////
// Class :: COprVector
// Desc  :: vectorを抽象化するクラス
/////////////////////////////////////////////////////////

IOperand* COprVector::Fix() {
	if (!m_bFixed) {
		if (m_nMin != m_nMax) {
			m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
			while (m_nVal == m_chToSV || m_nVal == m_chToUM){
				m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
			}
		}else{
			m_nVal = m_nMin;
		}
		m_bFixed = true;
	}
	return this;
}

bool COprVector::Replace(UI32 new_val) {
	if (new_val == m_chToSV || new_val == m_chToUM ) {
		return false;
	}
	return COprImm::Replace(new_val);
}

/////////////////////////////////////////////////////////
// Class :: COprVector4
// Desc  :: vector(vector ≠ 0)を抽象化するクラス
/////////////////////////////////////////////////////////

IOperand* COprVector4::Fix() {
	if (!m_bFixed) {
		if (m_nMin != m_nMax) {
			m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
			while (m_nVal == m_chToSV || m_nVal == m_chToUM){
				m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
			}
		}else{
			m_nVal = m_nMin;
		}
		m_bFixed = true;
	}
	return this;
}

bool COprVector4::Replace(UI32 new_val) {
	if (new_val == m_chToSV || new_val == m_chToUM ) {
		return false;
	}
	return COprImm::Replace(new_val);
}

/////////////////////////////////////////////////////////
// Class :: COprVector5
// Desc  :: vector(vector ≠ 0x1d)を抽象化するクラス
/////////////////////////////////////////////////////////

IOperand* COprVector5::Fix() {
	if (!m_bFixed) {
		if (m_nMin != m_nMax) {
			m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
			while (m_nVal == m_chToSV || m_nVal == m_chToUM || m_nVal == m_swReset){
				m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax);
			}
		}else{
			m_nVal = m_nMin;
		}
		m_bFixed = true;
	}
	return this;
}

IOperand* COprVector5::ReFix(){
	m_bFixed = false;
	return COprVector5::Fix();
}

bool COprVector5::Replace(UI32 new_val) {
	if (new_val == m_chToSV || new_val == m_chToUM ) {
		return false;
	}
	return COprImm::Replace(new_val);
}


/////////////////////////////////////////////////////////
// Class :: COprList12
// Desc  :: LIST12を抽象化するクラス
/////////////////////////////////////////////////////////
void COprList12::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

    if (m_vConst == nullptr)
        return;
	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)3/*SP*/, (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}

	bool load = m_vConst->GetType(IValConstraint::LOAD_MEMORY);
	UI32 imm5 = 0;
	if (load) {
		imm5 = ((UI32)(*r->m_depends) << 2); // zero-extend (imm5 logically shift by 2)
		cur += imm5;
	}
	
	UI32 count = GetBitCount();		// Count the number of registers to be loaded / stored
    // Do not regulate operand in case of it does not access memory
    if (count == 0) return;
	
	// Multi-Cycle命令は複数レジスタに対して処理されるため
	// Protection制御するときは実効サイズに置き換える
	UI32 eaddr = cur & ~3UL;
	if (m_vConst) {
		m_vConst->m_nSzm = count * 4; // 実効サイズ
		if (m_vConst->GetType(IValConstraint::STORE_MEMORY) ) {
			eaddr = (cur & ~3UL) - (count * 4);
		}
	}
	
	m_vConst->m_nMsk = 3;
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	m_vConst->m_nMsk = 0;
	
	if (m_vConst == NULL || m_vConst->IsValid(eaddr)) {
		
		// 実行時暗黙の丸め
		UI32 addr = cur & (~3UL);
		
		if (load) {
			// アドレス後加算(dispose)
			for (UI32 i = 0; i < count; i++) {
				r->m_vEa.push_back(std::pair<UI32,UI32>(addr, 4));
				addr += 4;
			}
		}else{
			// アドレス前減算(prepare)
			for (UI32 i = 0; i < count; i++) {
				addr -= 4;
				r->m_vEa.push_back(std::pair<UI32,UI32>(addr, 4));
			}
		}
		//r->m_vEa.push_back(std::pair<UI32,UI32>(cur,4));
		if(r->IsForce()) {
			r->m_vGr.push_back(std::pair<UI32,UI32>(3/*SP*/, (UI32)cur - imm5));
		}
		return;
	}

	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	UI64 sv = m_vConst->SelectValue();
	if (m_vConst->GetType(IValConstraint::STORE_MEMORY) ) {
		// Prepareはアドレス減算ストア（先引き）
		// 例えばちょうど３REGストアの許可領域に3regストアをする場合、 
		// SV（目標値）を調整する。
		// 
		// 80[ ng ng ng ng ]
		// 84[ ok ok ok ok ] <- SelectValueの戻りアドレスはここだが
		// 88[ ok ok ok ok ] <-
		// 8C[ ok ok ok ok ] <-
		// 90[ ng ng ng ng ] <- 目標値はこのアドレスにする。
		//                      先に-4されて、３reg分ストアされる
		//                      次回の補正では84アドレスからValid検証される
		sv = (sv + count * 4)/* - 4*/;
	}
	
	//!< 補正情報
	r->m_vGr.push_back(std::pair<UI32,UI32>(3/*SP*/, (UI32)sv-imm5));
}


std::string COprList12::GetCode() {
	
	char code[32];
	
	(void*)Fix();
	//_ASSERT(m_nVal < 0x1000);
	 //m_nVal = ((m_nVal & 0xfffffffe) << 20) | (m_nVal & 1); 
	sprintf(code, "0x%08x", m_nVal);
	
	return std::string(code);
}

/**
 * @brief  ランダム選択によりオペランドの値を固定します
 * @return このオブジェクト参照
 */	
IOperand* COprList12::Fix() {

	if (!m_bFixed) {
		m_nVal = m_pRand->GetRange((UI32)m_nMin,(UI32)m_nMax) & m_nMask;
		m_nVal = ((m_nVal & 0xfffffffe) << 20) | (m_nVal & 1); 
		m_bFixed	= true;
	}	
	return this;
}
/**
	* @brief  オペランドの値を上書きします。
	* @param  index 上書きする値
	* @return 上書き出来た場合に真を返します。
	*/	
bool COprList12::Replace(UI32 new_val) {
    UI32 val = new_val >> 21;
    if (m_nMin <= val && val <= m_nMax && (val == (val & m_nMask))) {
		m_nVal		= new_val;
		m_bFixed	= true;
		return true;
	}
    return false;
}

UI32 COprList12::GetBitCount() {
	
	(void*)Fix();
    if(m_nVal < 0x80000){//bits 0-20
		if((m_nVal & 0x1) == 1) return 1; // bit 30
		return 0;
	}
	
	//_ASSERT(m_nVal < 0x1000);
	
	UI32 bits = m_nVal;
    bits = (bits & 0x55555555) + (bits >> 1 & 0x55555555);
    bits = (bits & 0x33333333) + (bits >> 2 & 0x33333333);
    bits = (bits & 0x0f0f0f0f) + (bits >> 4 & 0x0f0f0f0f);
    bits = (bits & 0x00ff00ff) + (bits >> 8 & 0x00ff00ff);
    return (bits & 0x0000ffff) + (bits >>16 & 0x0000ffff);
}

/////////////////////////////////////////////////////////
// Class :: COprWR
// Desc  :: FPベクトルレジスタオペランドを抽象化したクラス
/////////////////////////////////////////////////////////
void COprWR::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	__uint128_t cur;
	if (r->m_pSim->ReadWrReg(&cur, m_wr, r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read WR");
		throw excep;
	}
	
	//!< TypeCheck
	if (m_vConst==NULL || m_vConst->IsValidWR(cur)) {
		return;
	}
	
	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	std::pair<std::bitset<4> ,__uint128_t> sv = m_vConst->SelectValueWR();
	
	//!< 補正情報
	r->m_vWr.push_back(std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> >(m_wr,sv));
}

std::string COprWR::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "wr%d", m_wr);
	return std::string(code);
}

IOperand* COprWR::Fix() {
	if (!m_bFixed) {
		m_wr		= m_pRand->GetRange(m_rh, m_rt);
		m_bFixed	= true;
	}
	return this;
}

UI32 COprWR::Idx() {
	(void*)Fix();
	return m_wr;
}

bool COprWR::Replace(UI32 index) {
	if (m_rh <= index && index <= m_rt) {
		m_wr = index;
		m_bFixed = true;
		return true;
	}
	return false;
}


/////////////////////////////////////////////////////////
// Class :: COprPWR
// Desc  :: FPベクトルペアレジスタオペランドを抽象化したクラス
/////////////////////////////////////////////////////////
void COprPWR::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT((m_wr & 1) == 0);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	__uint128_t cur0;
	__uint128_t cur1;
	if (r->m_pSim->ReadWrReg(&cur0, m_wr,   r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read WR");
		throw excep;
	}
	if (r->m_pSim->ReadWrReg(&cur1, m_wr+1, r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read WR");
		throw excep;
	}
	
	//!< TypeCheck
	if (m_vConst==NULL || m_vConst->IsValidWR(cur0) || m_vConst->IsValidWR(cur1)) {
		return;
	}
	
	r->ReAsm();
	r->ReSim();
	
	//!< 目標値取得
	std::pair<std::bitset<4> ,__uint128_t> sv0 = m_vConst->SelectValueWR();
	std::pair<std::bitset<4> ,__uint128_t> sv1 = m_vConst->SelectValueWR();
	
	//!< 補正情報
	r->m_vWr.push_back(std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> >(m_wr,  sv0));
	r->m_vWr.push_back(std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> >(m_wr+1,sv1));
}


std::string COprPWR::GetCode() {
	char code[OPR_CODEBUF];
	
	(void*)Fix();
	sprintf(code, "wr%d", m_wr);
	return std::string(code);
}

IOperand* COprPWR::Fix() {
	if (!m_bFixed) {
		m_wr		= m_pRand->GetRange(m_rh, m_rt);
		m_bFixed	= true;
	}
	return this;
}

UI32 COprPWR::Idx() {
	(void*)Fix();
	return m_wr;
}

bool COprPWR::Replace(UI32 index) {
	if ( (m_rh <= index) && (index <= m_rt)) {
		m_wr = index;
		m_bFixed = true;
		return true;
	}
	return false;
}


/////////////////////////////////////////////////////////
// Class :: COprRegReg
// Desc  :: 汎用レジスタx2を抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprRegReg::GetCode() {
	char code[OPR_CODEBUF];
	(void*)Fix();
	sprintf(code, "r%d[r%d]", m_reg2, m_reg1);
	return std::string(code);
}

IOperand* COprRegReg::Fix() {
	if (!m_bFixed) {
		//現在の設定ではm_reg1 == m_reg2を許容する
		m_reg1		= m_pRand->GetRange(m_rh, m_rt);
		m_reg2		= m_pRand->GetRange(m_rh, m_rt);
		m_bFixed	= true;
	}
	return this;
}


REGFLG COprRegReg::GetGrSrc(bool regulation = false) {
	REGFLG rf = 0;
	if (Attr(IOperand::OPR_ATTR_GR) && Attr(IOperand::OPR_ATTR_SRC)) {
		rf = ( (Attr(OPR_ATTR_PAIR) ? 3 : 1) << IdxReg1() ) |
			 ( (Attr(OPR_ATTR_PAIR) ? 3 : 1) << IdxReg2() )  ;
	}
	return rf;
}


REGFLG COprRegReg::GetGrDst() {
	REGFLG rf = 0;
	if (Attr(IOperand::OPR_ATTR_GR) && Attr(IOperand::OPR_ATTR_DST)) {
		rf = ( (Attr(OPR_ATTR_PAIR) ? 3 : 1) << IdxReg1() ) |
			 ( (Attr(OPR_ATTR_PAIR) ? 3 : 1) << IdxReg2() )  ;
	}
	return rf;
}

UI32 COprRegReg::IdxReg1() {
	(void*)Fix();
	return m_reg1;
}

UI32 COprRegReg::IdxReg2() {
	(void*)Fix();
	return m_reg2;
}

void COprRegReg::Regulate(IRegulation* r) {
	
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	// Load protection info
	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	
	// Load protection info
	Correction(r);
}

void COprRegReg::Correction(IRegulation* r) {

	//!< シミュレータから現在の値を読む
	UI32 cur1;
	UI32 cur2;
	if (r->m_pSim->ReadGrReg(&cur1, (SI32)m_reg1, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	if (r->m_pSim->ReadGrReg(&cur2, (SI32)m_reg2, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	UI64 sv = m_vConst==NULL ? (UI64)4 : (UI64)(m_vConst->m_nSzm) ;
	//UI64 cur = (UI32)(cur1 + cur2) ;

#ifdef DBGMODE
	printf(" now reg1(reg%-2d) : 0x%016x\n", m_reg1, cur1) ;
	printf(" now reg2(reg%-2d) : 0x%016x\n", m_reg2, cur2) ;
	printf(" now reg1 + reg2 : 0x%016llx\n", (UI64)(cur1)+(UI64)(cur2)) ;
#endif

	//!< 現状が適正値である場合はそのままシミュレーションさせる
	if (m_vConst->IsValid((UI64)cur1 + (UI64)cur2)) {
		r->m_vEa.push_back(std::pair<UI32,UI32>(cur1+cur2, sv));
		return;
	}
		
	UI32 M  = m_vConst ? m_vConst->m_nMsk : 0;			// アラインマスク(i.e. M=0ならミスアラインが発生しないバイトアクセス)
	UI32 U  = m_vConst ? m_vConst->m_nUnA : 0;			// アラインされた値に足す値（強制的なアンアラインドアクセス　i.e.U=0ならアラインアクセスを意味する）
	UI64 mx = m_vConst ? (UI64)((m_vConst->m_nMax+1 >= m_vConst->m_nSzm) ? (m_vConst->m_nMax-m_vConst->m_nSzm+1):0) : 0;    // 符号計算の為
	UI64 mn = m_vConst ? (UI64)m_vConst->m_nMin : 0;	// 符号計算の為

    if (mn > mx) {
        r->GiveUp();
        return;
    }
 	//!< 目標値取得
 	if (m_vConst != NULL) {
 		sv = ((m_vConst->SelectValue()) & ~M) + U ; 
 	}

#ifdef DBGMODE
	printf(" mask    M: 0x%02x\n", M) ;
	printf(" unMask  U: 0x%02x\n", U) ;
	printf(" max    mx: 0x%16llx\n", mx) ;
	printf(" min    mn: 0x%16llx\n", mn) ;
#endif
	// reg1番号 == reg2番号 
	if( m_reg1 == m_reg2 ){
		cur1 = ( sv ) / 2 ;
		r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg1(), cur1));
	} else 
	if ( (UI64)cur1 + (UI64)cur2 < mn) {
		//!< 1. レジスタ値が範囲の下限以下の場合
		UI32 val = ((UI64)m_pRand->GetRange(mn, mx) & ~M) + U; // 目標値決定
#ifdef DBGMODE
		printf(" now 0 val : %08x\n", val) ;
#endif
		r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg1(), val-cur2));
	} else
	if ((UI64)cur1 + (UI64)cur2 > mx) {
		//!< 2. レジスタ値が範囲の上限以上の場合
		if( (cur1 > mx) && (cur2 > mx) ){
			UI32 val      = (m_pRand->GetRange(mn, mx) & ~M) + U; // 目標値決定
			UI32 val_reg1 = (m_pRand->GetRange(mn, (UI64)val)) ; // reg1目標値決定
#ifdef DBGMODE
			printf(" now 1 val : %08x\n", val) ;
#endif
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg1(), val_reg1));
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg2(), val-val_reg1));
		} else 
		if( cur1 > mx ){
			UI64 tmp = (cur2 > mn) ? cur2 : mn ;
			UI32 val = (m_pRand->GetRange(tmp, mx) & ~M) + U; // 目標値決定
#ifdef DBGMODE
			printf(" now 2 val : %08x\n", val) ;
#endif
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg1(), val-cur2));
		} else 
		if( cur2 > mx ){
			UI64 tmp = (cur1 > mn) ? cur1 : mn ;
			UI32 val = (m_pRand->GetRange(tmp, mx) & ~M) + U; // 目標値決定
#ifdef DBGMODE
			printf(" now 3 val : %08x\n", val) ;
#endif
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg2(), val-cur1));
		}
		else {
			UI64 tmp = (cur1 > cur2) ? ( (cur1 > mn) ? cur1 : mn ) : (cur2 > mn) ? cur2 : mn ;
			UI32 val = (m_pRand->GetRange(tmp, mx) & ~M) + U; // 目標値決定
#ifdef DBGMODE
			printf(" now 4 val : %08x\n", val) ;
#endif
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg2(), val-cur1));
		}

	} else
	{
		//!< 3. レジスタ値が範囲内にある場合
		//!< アンアライン検出
			
		UI32 val = ((cur1 + cur2) & ~M) + U ;
		if ( cur1 < M ){
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg2(), val-cur1));
		} else
		if ( cur2 < M ){
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg1(), val-cur2));
		} else {
			r->m_vGr.push_back(std::pair<UI32,UI32>(IdxReg2(), val-cur1));

		}
#ifdef DBGMODE
		printf(" *now reg1(reg%d) : 0x%08x\n", m_reg1, cur1) ;
		printf(" *now reg2(reg%d) : 0x%08x\n", m_reg2, cur2) ;
		printf(" *now reg1 + reg2 : 0x%08x\n", cur1+cur2) ;
#endif

	}
	
	return;
}


bool COprRegReg::Replace(UI32 index1, UI32 index2) {
	if ( ((m_rh <= index1) && (index1 <= m_rt)) &&
		 ((m_rh <= index2) && (index2 <= m_rt))
	   ) {
		m_reg1		= index1;
		m_reg2		= index2;
		m_bFixed	= true;
		return true;
	}
	return false;
}

/////////////////////////////////////////////////////////
// Class :: COprGtr2
// Desc  :: ギャザーアクセスを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprGtr2::GetCode() {
	char code[OPR_CODEBUF];
	(void*)Fix();
	sprintf(code, "r%d", m_reg);
	return std::string(code);
}

IOperand* COprGtr2::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt);
		m_bFixed	= true;
	}
	return this;
}

UI32 COprGtr2::Idx() {
	(void*)Fix();
	return m_reg;
}

void COprGtr2::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	UI32 offset;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	if (r->m_pSim->ReadGrReg(&offset, (SI32)r->m_depends->Idx(), (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
#ifdef DBGMODE
	printf(" now reg1(reg%-2d) : 0x%016x\n", m_reg, cur) ;
	printf(" now reg2(reg%-2d) : 0x%016x\n", (SI32)r->m_depends->Idx(), offset) ;
	printf(" now reg1 + reg2*1 : 0x%016llx\n", (UI64)(cur)+(UI64)(offset)) ;
#endif

	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	if (m_vConst == NULL || ( m_vConst->IsValid(cur) && m_vConst->IsValid(cur + offset) && ((UI64)cur + (UI64)offset <= 0xffffffffull ))) {
		//!< 現状が適正値である場合はそのままシミュレーションさせる
#ifdef DBGMODE
		printf("set cur       :%08x\n",cur);
		printf("set cur+offset:%08x\n",cur+offset);
#endif
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + offset, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		return;
	}

	if (m_vConst != NULL) {
		m_vConst->SelectValue(); // Upper, Lowerが更新される
	}
	
	UI32 U  = m_vConst->m_nUnA;
	UI32 M  = m_vConst->m_nMsk;
	UI64 mx = ( m_vConst->m_nMax + 1 >= m_vConst->m_nSzm ) ? ( m_vConst->m_nMax - m_vConst->m_nSzm + 1 ) : 0;
	UI64 mn = m_vConst->m_nMin;
#ifdef DBGMODE
	printf(" mask    M: 0x%02x\n", M) ;
	printf(" unMask  U: 0x%02x\n", U) ;
	printf(" max    mx: 0x%016llx\n", mx) ;
	printf(" min    mn: 0x%016llx\n", mn) ;
#endif

	UI64 sv;
	if(( (UI64)cur < mn ) || ( mx < (UI64)cur ) || (( cur & M ) != 0 )) {
		sv = ( m_pRand->GetRange((UI32)mn,(UI32)mx) & ~M ) + U;
#ifdef DBGMODE
		printf("set gr%d:%08x\n",m_reg,(UI32)sv);
#endif
		r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)sv));				
	} else if(( (UI64)cur + (UI64)offset < mn ) || ( mx < (UI64)cur + (UI64)offset ) || (((UI64)cur + (UI64)offset) > 0xffffffffull) || ((offset & M) != 0)) {
		sv = ( m_pRand->GetRange((UI32)cur,(UI32)mx) & ~M ) + U;
#ifdef DBGMODE
		printf("set gr%d:%08x\n",(SI32)r->m_depends->Idx(),(UI32)(sv - cur));
#endif
		r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)r->m_depends->Idx(), (UI32)( sv - cur )));				
	} else {
#ifdef DBGMODE
		printf("Unregulated.\n"); // ToDo: IsValid(cur) && IsValid(cur+offset)
		printf("set cur       :%08x\n",cur);
		printf("set cur+offset:%08x\n",cur+offset);
#endif
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + offset, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
	}
	return;
}

/////////////////////////////////////////////////////////
// Class :: COprGtr4
// Desc  :: ギャザーアクセスを抽象化したクラス
/////////////////////////////////////////////////////////
std::string COprGtr4::GetCode() {
	char code[OPR_CODEBUF];
	(void*)Fix();
	sprintf(code, "r%d", m_reg);
	return std::string(code);
}

IOperand* COprGtr4::Fix() {
	if (!m_bFixed) {
		m_reg		= m_pRand->GetRange(m_rh, m_rt);
		m_bFixed	= true;
	}
	return this;
}

UI32 COprGtr4::Idx() {
	(void*)Fix();
	return m_reg;
}

void COprGtr4::Regulate(IRegulation* r) {
	_ASSERT(r);
	_ASSERT(r->m_pSim);

	//!< ランダム成分を確定させる
	(void*)Fix();
	
	//!< シミュレータから現在の値を読む
	UI32 cur;
	UI32 offset;
	if (r->m_pSim->ReadGrReg(&cur, (SI32)m_reg, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	if (r->m_pSim->ReadGrReg(&offset, (SI32)r->m_depends->Idx(), (SI32)r->m_ht) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
#ifdef DBGMODE
	printf(" now reg1(reg%-2d) : 0x%016x\n", m_reg, cur) ;
	printf(" now reg2(reg%-2d) : 0x%016x\n", (SI32)r->m_depends->Idx(), offset) ;
	printf(" now reg1 + reg2*3 : 0x%016llx\n", (UI64)(cur)+((UI64)(offset)*3) ) ;
#endif

	if(!SetMemoryErrorControl(r)){
		if(m_vConst != NULL){
			m_vConst->SetType(IValConstraint::RAISE_MERROR, !(m_vConst->GetType(IValConstraint::RAISE_MERROR)));
			if(!SetMemoryErrorControl(r)) {
				r->GiveUp();
			}
		} else {
			r->GiveUp();
		}
	}
	if (m_vConst == NULL || ( m_vConst->IsValid(cur) && m_vConst->IsValid(cur + (offset * 3) ) && ((UI64)cur + ((UI64)offset * 3) <= 0xffffffffull ))) {
		//!< 現状が適正値である場合はそのままシミュレーションさせる
#ifdef DBGMODE
		printf("set cur         :%08x\n",cur);
		printf("set cur+offset  :%08x\n",cur+offset);
		printf("set cur+offset*2:%08x\n",cur+(offset*2));
		printf("set cur+offset*3:%08x\n",cur+(offset*3));
#endif
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + offset, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + (offset * 2), (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + (offset * 3), (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		return;
	}

	if (m_vConst != NULL) {
		m_vConst->SelectValue(); // Upper, Lowerが更新される
	}
	
	UI32 U  = m_vConst->m_nUnA;
	UI32 M  = m_vConst->m_nMsk;
	UI64 mx = ( m_vConst->m_nMax + 1 >= m_vConst->m_nSzm ) ? ( m_vConst->m_nMax - m_vConst->m_nSzm + 1 ) : 0;
	UI64 mn = m_vConst->m_nMin;
#ifdef DBGMODE
	printf(" mask    M: 0x%02x\n", M) ;
	printf(" unMask  U: 0x%02x\n", U) ;
	printf(" max    mx: 0x%016llx\n", mx) ;
	printf(" min    mn: 0x%016llx\n", mn) ;
#endif

	UI64 sv;
	if(( (UI64)cur < mn ) || ( mx < (UI64)cur ) || ((cur & M) != 0)) {
		sv = ( m_pRand->GetRange((UI32)mn,(UI32)mx) & ~M ) + U;
#ifdef DBGMODE
		printf("set gr%d:%08x\n",m_reg,(UI32)sv);
#endif
		r->m_vGr.push_back(std::pair<UI32,UI32>(m_reg, (UI32)sv));				
	} else if(( (UI64)cur + ((UI64)offset * 3) < mn ) || ( mx < (UI64)cur + ((UI64)offset * 3 )) || ((offset & M) != 0)) {
		sv = ( m_pRand->GetRange((UI32)cur,(UI32)(((mx-cur)>>2)+cur)) & ~M ) + U;
#ifdef DBGMODE
		printf("set gr%d:%08x\n",(SI32)r->m_depends->Idx(),(UI32)(sv - cur));
#endif
		r->m_vGr.push_back(std::pair<UI32,UI32>((SI32)r->m_depends->Idx(), (UI32)( sv - cur )));				
	} else {
#ifdef DBGMODE
		printf("Unregulated.\n"); // ToDo: IsValid(cur) && IsValid(cur+offset)
		printf("set cur         :%08x\n",cur);
		printf("set cur+offset  :%08x\n",cur+offset);
		printf("set cur+offset*2:%08x\n",cur+(offset*2));
		printf("set cur+offset*3:%08x\n",cur+(offset*3));
#endif
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + offset, (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + (offset * 2), (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
		r->m_vEa.push_back (std::pair<UI32,UI32>(cur + (offset * 3), (m_vConst==NULL ? 4 : m_vConst->m_nSzm)));
	}
}
/* End_of_file */

