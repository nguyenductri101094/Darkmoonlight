#ifndef OPERAND_H_
#define OPERAND_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"
#include	"ifoperand.h"
#include	"ifsysreg.h"



/**
 *  @brief  E3V5定義のオペランドを抽象化するクラス。
 */
 
class IOprE3V5 : public IOperand
{
	
public:

	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IOprE3V5() : IOperand() {}
	

	/**
	 * @brief  このオブジェクトを生成します
	 * @param  bs 属性を示すビットセット
	 */	
	IOprE3V5(std::bitset<IOperand::OPR_ATTR_NUM> bs) : IOperand(bs) {}
	

	/**
	 * @brief  このオブジェクトを生成します
	 * @param  bs 属性を示すビットセット
	 * @param  pVC 制約を示すオブジェクト
	 */	
	IOprE3V5(std::bitset<IOperand::OPR_ATTR_NUM> bs, IValConstraint* pVC) : IOperand(bs, pVC) {}
		
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~IOprE3V5(){};	

	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual bool SetMemoryErrorControl(IRegulation* pReg);


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual bool SetMemoryErrorControl(IRegulation* pReg, UI32 lnk){return false;}
	

	/**
	 * @brief get operand of array instruction  
	 */
	virtual void GetArrayInsOpr(UI32* srcReg, IOperand **pBaseOpr, IOperand** pSecOpr1, IOperand** pSecOpr2){

		*srcReg = Idx(); // srcReg is always 30.
		*pBaseOpr = NULL; // Do not replace.
	} 

	/**
	 * @brief   Clarify   system register that store mismatch value between CForest and RTL
	 * @return True: System Register has mismatch value
	           False: System Register has not mismatch value
	 */
	virtual bool OprHasMismatch() { return false; }

	// Segment Listを引いたアドレスを記憶しておく
	MEMRANGE m_mr;

};



/**
 *  @brief  汎用レジスタオペランドを抽象化するクラス。
 */
class COprGR : public IOprE3V5
{
public:

	/**
	 * @brief レジスタインデックスを指定してこのオブジェクトを生成します。
	 * @param r レジスタ番号
	 */
	COprGR(UI32 r)
		: IOprE3V5(1<<OPR_ATTR_GR, NULL), m_pRand(&g_rnd), m_rh(r), m_rt(r), m_reg(r)
	{
		m_bFixed = true;
	};


	/**
	 * @brief レジスタインデックス範囲を指定してこのオブジェクトを生成します。
	 *        r0が選択不可能なオペランド用にオブジェクトを生成する場合、rh=1, rt31として生成します。
	 * @param rh レジスタ番号範囲下限
	 * @param rt レジスタ番号範囲上限
	 */
	COprGR(UI32 rh, UI32 rt)
		: IOprE3V5((1<<OPR_ATTR_GR), NULL), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_reg(0)
	{};
	
		
	/**
	 * @brief レジスタインデックス範囲を指定してこのオブジェクトを生成します。
	 *        r0が選択不可能なオペランド用にオブジェクトを生成する場合、rh=1, rt31として生成します。
	 * @param rh レジスタ番号範囲下限
	 * @param rt レジスタ番号範囲上限
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprGR(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_reg(0)
	{};


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGR(){};


	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	           lnk: generate address in link bit area
	 */	
	virtual void Regulate(IRegulation* pReg, UI32 lnk){}

	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	/**
	 * @brief Re-generate system register index
	 * @return pointer to this object.
	 */
	virtual IOperand* ReFix(){
		m_bFixed = false;
		return Fix();
	}
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();
	
	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);

	/**
	 * @brief	This function replace the generating range.
	 * @param	(rh, rt) Generating range.
	 */
	virtual bool SetRange(UI32 rh, UI32 rt);

	/**
	 * @brief find operand need to change in JARL function.
	 * @return true if current operand is used in JARL instruction, false if not.
	 */
	virtual bool AdjustOprInFunction(UI32 F){
		if(this->Idx() != F)
			return false;
		else{
			UI32 r;
			for (r = 1; r < 32; r++) {
				UI32 q = (m_reg + r) & 0x1f; // GR[x]〜GR[(x+31)%32]までを置き換え可能か検査する
				if ((q != 0) && this->Replace( q ))  // r0は隠れた制限が多いためキャンセル
					break; // 書き換え完了 -> 次のオペランド検証
			}
			FROG_ASSERT(r < 32);
		}
		return true;
	}

	/**
	 * @brief get operand of array instruction  
	 */
	virtual void GetArrayInsOpr(UI32* srcReg, IOperand** pBaseOpr, IOperand** pSecOpr1, IOperand** pSecOpr2){

		if( *pSecOpr1 == NULL) 
			*pSecOpr1 = this;
		else
			*pSecOpr2 = this;
	} 
	 /**
	 * @brief print value in of operand in DEBUG MODE
	 */
	 void PrintGetVal(ISimulator* m_pSim, std::stringstream& ss){
		 UI32 addr;
		 m_pSim->ReadGrReg(&addr, this->Idx(), 0);
		 ss << "r" << std::dec << this->Idx() << "<=" << std::hex << std::setfill('0') << std::setw(8) << addr << " ";
	 }

	 /**
	 * @brief print value in of operand in DEBUG MODE
	 */
	 void PrintRetVal(ISimulator* m_pSim, std::stringstream& ss){
		 UI32 addr;
		 m_pSim->ReadGrReg(&addr, this->Idx(), 0);
		 ss << "r" << std::dec << this->Idx() << "=>" << std::hex << std::setfill('0') << std::setw(8) << addr << " ";
	 }

protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源
	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_reg;			//!< @brief 選択されたインデックス
};



/**
 *  @brief  汎用レジスタ(MemoryAccess)オペランドを抽象化するクラス。
 */
class COprGRm : public COprGR
{
public:

	/**
	 * @brief レジスタインデックスを指定してこのオブジェクトを生成します。
	 * @param re レジスタ番号
	 */
	COprGRm(UI32 re): COprGR(re), m_nMask(~0U) {};

	/**
	 * @brief レジスタインデックス範囲を指定してこのオブジェクトを生成します。
	 *        r0が選択不可能なオペランド用にオブジェクトを生成する場合、rh=1, rt31として生成します。
	 * @param rh レジスタ番号範囲下限
	 * @param rt レジスタ番号範囲上限
	 */
	COprGRm(UI32 rh, UI32 rt): COprGR(rh, rt), m_nMask(~0U)	{
		m_attr.set(OPR_ATTR_IRAM);
		m_attr.set(OPR_ATTR_SMEM);
		m_attr.set(OPR_ATTR_LMEM);
	};

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param mask マスク(未使用)
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprGRm(UI32 rh, UI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
	: COprGR(rh, rt, attr, pvc), m_nMask(mask) {};


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGRm(){};
		
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
		
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	           lnk: generate address in link bit area
	 */	
	virtual void Regulate(IRegulation* pReg, UI32 lnk);

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual bool SetMemoryErrorControl(IRegulation* pReg);

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual bool SetMemoryErrorControl(IRegulation* pReg, UI32 lnk);

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
	
	/**
	 * @brief get operand of array instruction
	 */
	void GetArrayInsOpr(UI32* srcReg, IOperand** pBaseOpr, IOperand** pSecOpr1, IOperand** pSecOpr2){
		*pBaseOpr = this;
	}

private:
	UI32		m_nMask;		/*!< @brief マスク(未使用)*/
};


/**
 *  @brief  汎用レジスタ(pref命令専用)オペランドを抽象化するクラス。
 *          メモリアクセスにおいて
 */
class COprGRpi : public COprGR
{
public:

	/**
	 * @brief レジスタインデックスを指定してこのオブジェクトを生成します。
	 * @param re レジスタ番号
	 */
	COprGRpi(UI32 re): COprGR(re) {};

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param mask マスク(未使用)
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprGRpi(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
	: COprGR(rh, rt, attr, pvc) {};

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
		
};


/**
 *  @brief  汎用レジスタ(MemoryAccess Inc/Dec Addrssing)オペランドを抽象化するクラス。
 */
class COprGRmx : public COprGRm
{
public:

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param c	   アドレッシングタイプ('+', '-')
	 */
	COprGRmx (UI32 rh, UI32 rt, SI8 c)
		: COprGRm(rh, rt), m_idx(c)
	{
		_ASSERT(0); // 呼ばれていないはず
		m_attr.set(OPR_ATTR_IRAM);
		m_attr.set(OPR_ATTR_SMEM);
		m_attr.set(OPR_ATTR_LMEM);
	};
		

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param c	   アドレッシングタイプ('+', '-')
	 * @param mask マスク(未使用)
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprGRmx (UI32 rh, UI32 rt, SI8 c, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprGRm(rh, rt, mask, attr, pvc), m_idx(c){};
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGRmx(){};
	
		
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	           lnk: generate address in link bit area
	 */	
	virtual void Regulate(IRegulation* pReg, UI32 lnk){}
		

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

protected:
	SI8						m_idx;			//!< @brief アドレッシング方式
};



/**
 *  @brief  汎用レジスタ(MemoryAccess R-Type Addressing)オペランドを抽象化するクラス。
 */
class COprRTypeGR : public COprGRm
{
public:

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 */
	COprRTypeGR (UI32 rh, UI32 rt)
		: COprGRm(rh, rt)
	{
		_ASSERT(0); // 呼ばれていないはず
		m_attr.set(OPR_ATTR_IRAM);
		m_attr.set(OPR_ATTR_SMEM);
		m_attr.set(OPR_ATTR_LMEM);
	};
		

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param mask マスク(未使用)
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprRTypeGR (UI32 rh, UI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprGRm(rh, rt, mask, attr, pvc){}
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprRTypeGR(){}
	
		
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	           lnk: generate address in link bit area
	 */	
	virtual void Regulate(IRegulation* pReg, UI32 lnk){}

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
	
protected:
	/**
	 * @brief  32bitをビットリバースします（R-Typeアドレッシング計算用）。
	 * @return ビットリバース値
	 */	
	UI32 BitReverse(UI32 v);

};



/**
 *  @brief  汎用レジスタ(MemoryAccess M-Type Addressing)オペランドを抽象化するクラス。
 */
class COprMTypeGR : public COprGRm
{
public:


	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 */
	COprMTypeGR (UI32 rh, UI32 rt)
		: COprGRm(rh, rt)
	{
		_ASSERT(0); // 呼ばれていないはず
		m_attr.set(OPR_ATTR_IRAM);
		m_attr.set(OPR_ATTR_SMEM);
		m_attr.set(OPR_ATTR_LMEM);
	};
		

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param mask マスク(未使用)
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprMTypeGR (UI32 rh, UI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprGRm(rh, rt, mask, attr, pvc){};
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprMTypeGR(){}
	
		
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	           lnk: generate address in link bit area
	 */	
	virtual void Regulate(IRegulation* pReg, UI32 lnk){}

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();


	/**
	 * @brief  M-Typeの演算へ入力するデータの妥当性を検証する。
	 * @param  index  インデックス値	( low(reg2) )
	 * @param  step   ステップ値	( high(reg2) )
	 * @param  limit  上限値		( low(reg2+1) )
	 * @return 妥当である場合、真を返す。
	 */	
	virtual bool ModuloValid(UI16 index, SI16 step, UI16 limit);		
};



/**
 *  @brief  汎用レジスタ(ignore 0b)オペランドを抽象化するクラス。
 */
class COprGRi1b : public COprGR
{
public:
	COprGRi1b(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc): COprGR(rh, rt, attr, pvc) {};

	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGRi1b(){}
	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
};



/**
 *  @brief  汎用レジスタ(ignore 1:0b)オペランドを抽象化するクラス。
 */
class COprGRi2b : public COprGR
{
public:
	COprGRi2b(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc): COprGR(rh, rt, attr, pvc) {};


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGRi2b(){}
	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
};



/**
 *  @brief  汎用レジスタrhオペランドを抽象化するクラス。
 *          マルチサイクル命令（pushsp, popsp）で指定されるオペランド
 *          通常のCOprGRクラスを使わないのはこのオペランドに特殊制約を設けるため。
 *          特殊制約：メモリアクセスにSP値が依存する。
 */
class COprGRrh : public COprGR
{
public:
	COprGRrh(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc): COprGR(rh, rt, attr, pvc) {};


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGRrh(){}
	
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
};



/**
 *  @brief  汎用ペアレジスタオペランドを抽象化するクラス。
 */
class COprPR : public COprGR
{
public:
	COprPR(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc): COprGR(rh, rt, attr, pvc) {
		m_attr.set(OPR_ATTR_PAIR);
		m_attr.set(OPR_ATTR_XDEPEND);
	}
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprPR(){}
	
	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();
	
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
			
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);

	/**
	 * @brief find operand need to change in JARL function.
	 * @return true if current operand is used in JARL instruction, false if not.
	 */
	virtual bool AdjustOprInFunction(UI32 F){
		if((this->Idx() != F) && ((this->Idx()+1) != F))
			return false;
		else{
			UI32 r;
			for (r = 1; r < 32; r++) {
				UI32 q = (m_reg + r) & 0x1f; // GR[x]〜GR[(x+31)%32]までを置き換え可能か検査する
				if ((q != 0) && this->Replace( q ))  // r0は隠れた制限が多いためキャンセル
					break; // 書き換え完了 -> 次のオペランド検証
			}
			FROG_ASSERT(r < 32);
		}
		return true;
	}

};
	


/**
 *  @brief  汎用レジスタ(M-TypeMemoryAccess)オペランドを抽象化するクラス。
 */
class COprPRMod : public COprPR
{
public:

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprPRMod (UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: COprPR(rh, rt, attr, pvc){}
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprPRMod(){}
	
			
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
};



/**
 *  @brief  ディスプレースメント+汎用レジスタを抽象化するクラス。
 */
class COprDispReg : public IOprE3V5
{
public:
	COprDispReg(UI32 w, UI32 rh, UI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_dh(0), m_dt( (1 << (w - 1)) - 1 + (1 << (w - 1)) ), m_disp(0), m_rh(rh), m_rt(rt), m_reg(0), m_nMask(mask), m_regVal(0) {};
	
	COprDispReg(UI32 dh, UI32 dt, UI32 rh, UI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_dh(dh), m_dt(dt), m_disp(0), m_rh(rh), m_rt(rt), m_reg(0), m_nMask(mask), m_regVal(0) {};

	COprDispReg(UI32 dh, UI32 dt, UI32 rh, UI32 rt)
		: m_pRand(&g_rnd), m_dh(dh), m_dt(dt), m_disp(0), m_rh(rh), m_rt(rt), m_reg(0), m_nMask(~0U), m_regVal(0) {};

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprDispReg(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();


	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual void SetRegVal(SI32 val){
		m_regVal = val;
	}
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual SI32 GetRegVal(){
		return m_regVal;
	}
	
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Correction(IRegulation* pReg);
		
		
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
	
	/**
	 * @brief  ディスプレースメント値を取得します。
	 * @return ディスプレースメント値。
	 */	
	virtual operator UI32() {
		(void*) Fix();
		return m_disp;
	}


	/**
	 * @brief  オペランドの即値部を上書きします。
	 * @param  val 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Imm(UI32 val) {
		UI32 v = m_disp; SetDisp(val);
		return v != val;
	}


	/**
	 * @brief  オペランドの即値部を上書きします。
	 * @param  val 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual void SetDisp(UI32 d) {
		if ( m_dh > d ) {
			d = m_dt - (d % (m_dt - m_dh + 1));
		}
		if ( m_dt < d ) {
			d = m_dh + (d % (m_dt - m_dh + 1));
		}
		if ( (m_dh <= d) && (d <= m_dt)) {
			m_disp = d;
		}
	}

    virtual UI32 GetDisp() {
        return m_disp;
    }
	/**
	 * @brief Set range of displacement
	 * @param lower/upper limitted value
	 * @return None
	 */
	virtual void SetDispRange(UI32 dh, UI32 dt) {
		m_dh = dh;
		m_dt = dt;
	}
	
	/**
	* @brief print value in of operand in DEBUG MODE
	*/
	void PrintGetVal(ISimulator* m_pSim, std::stringstream& ss){
		UI32 addr;
		m_pSim->ReadGrReg(&addr, this->Idx(), 0);
		ss << "r" << std::dec << this->Idx() << "<=" << std::hex << std::setfill('0') << std::setw(8) << addr << " ";
	}

	/**
	* @brief print value out of operand in DEBUG MODE
	*/
	void PrintRetVal(ISimulator* m_pSim, std::stringstream& ss){
		UI32 addr;
		m_pSim->ReadGrReg(&addr, this->Idx(), 0);
		ss << "r" << std::dec << this->Idx() << "=>" << std::hex << std::setfill('0') << std::setw(8) << addr << " ";
	}

	/**
	 * @brief aline memory data
	 * @param PFETCHSIZE: size data will be align
	 */
    virtual void AlignData(ISimulator* m_pSim, UI32 PFETCHSIZE);

protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源
	UI32		m_dh;			//!< @brief ディスプレースメント下限
	UI32		m_dt;			//!< @brief ディスプレースメント上限
	UI32		m_disp;			//!< @brief 選択されたディスプレースメント値
	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_reg;			//!< @brief 選択されたインデックス
	UI32		m_nMask;
	SI32        m_regVal;
};


/**
 *  @brief  ディスプレースメント+汎用レジスタを抽象化するクラス。
 */
class COprSDispReg : public IOprE3V5
{
public:
	COprSDispReg(UI32 w, SI32 rh, SI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_dh(-1 * (1 << (w-1))), m_dt((1 << (w-1)) - 1), m_disp(0), m_rh(rh), m_rt(rt), m_reg(0), m_nMask(mask) {};
		
	COprSDispReg(bool flg, SI32 dh, SI32 dt, UI32 reg, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_dh(dh), m_dt(dt), m_disp(0), m_rh(reg), m_rt(reg), m_reg(reg), m_nMask(mask) {};
		
	COprSDispReg(SI32 dh, SI32 dt, UI32 rh, UI32 rt)
		: m_pRand(&g_rnd), m_dh(dh), m_dt(dt), m_disp(0), m_rh(rh), m_rt(rt), m_reg(0), m_nMask(~0U) {};


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprSDispReg(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();


	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();


	/**
	 * @brief  オペランドの即値部を上書きします。
	 * @param  val 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Imm(UI32 val) {
		UI32 v = m_disp; SetDisp(val);
		return v != val;
	}	

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Correction(IRegulation* pReg);
		
	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
	/**
	 * @brief	This function replace the generating range.
	 * @param	(rh, rt) Generating range.
	 */
	virtual bool SetRange(UI32 rh, UI32 rt);
	
	/**
	 * @brief  ディスプレースメント値を取得します。
	 * @return ディスプレースメント値。
	 */	
	virtual operator UI32() {
		(void*) Fix();
		return m_disp;
	}
	
	virtual void SetDisp(UI32 d) {
		SI32 disp = (SI32) d;

		if ( m_dh > disp ) {
			disp = m_dt - (std::abs(disp) % (m_dt - m_dh + 1));
		}
		if ( m_dt < disp ) {
			disp = m_dh + (std::abs(disp) % (m_dt - m_dh + 1));
		}
		if ( (m_dh <= disp) && (disp <= m_dt)) {
			m_disp = disp & m_nMask;
		}
	}

    virtual UI32 GetDisp() {
        return m_disp;
    }
	/**
	 * @brief Set range of displacement
	 * @param lower/upper limitted value
	 * @return None
	 */
	virtual void SetDispRange(UI32 dh, UI32 dt) {
		m_dh = dh;
		m_dt = dt;
	}

	/**
	 * @brief get operand of array instruction  
	 */
	void GetArrayInsOpr(UI32* srcReg, IOperand** pBaseOpr, IOperand** pSecOpr1, IOperand** pSecOpr2){
	   *pBaseOpr = this;
	} 

	/**
	 * @brief print value out of operand in DEBUG MODE
	 */
	 void PrintGetVal(ISimulator* m_pSim, std::stringstream& ss){
		 UI32 addr;
		 m_pSim->ReadGrReg(&addr, this->Idx(), 0);
         ss << "r" << std::dec << this->Idx() << "<=" << std::hex << std::setfill('0') << std::setw(8) << addr << " ";
	 }

	 /**
	 * @brief print value in of operand in DEBUG MODE
	 */
	 void PrintRetVal(ISimulator* m_pSim, std::stringstream& ss){
		 UI32 addr;
		 m_pSim->ReadGrReg(&addr, this->Idx(), 0);
		 ss << "r" << std::dec << this->Idx() << "=>" << std::hex << std::setfill('0') << std::setw(8) << addr << " ";
	 }

	 /**
	 * @brief aline memory data
	 * @param PFETCHSIZE: size data will be align
	 */
     virtual void AlignData(ISimulator* m_pSim, UI32 PFETCHSIZE);

protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源
	SI32		m_dh;			//!< @brief ディスプレースメント下限
	SI32		m_dt;			//!< @brief ディスプレースメント上限
	SI32		m_disp;			//!< @brief 選択されたディスプレースメント値
	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_reg;			//!< @brief 選択されたインデックス
	UI32		m_nMask;
};


/**
 *  @brief  ディスプレースメント+汎用レジスタを抽象化するクラス。
 */
class COprDispEP : public COprDispReg
{
public:
	COprDispEP(UI32 w, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprDispReg (w, 30, 30, mask, attr, pvc) {}

	COprDispEP(UI32 dh, UI32 dt)
		: COprDispReg (dh, dt, 30, 30, ~0, (1<<OPR_ATTR_GR)|(1<<OPR_ATTR_IMM), NULL) {}

	COprDispEP(UI32 dh, UI32 dt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprDispReg (dh, dt, 30, 30, mask, attr, pvc) {}


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprDispEP(){}

	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx() {
		return 30U; /* EP */
	}
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
};


/**
 *  @brief  スタックポインタ(r3)を抽象化するクラス。
 */
class COprSP : public IOprE3V5
{
public:
	COprSP(BS_OPRATTR attr, IValConstraint* pvc) : IOprE3V5(attr, pvc)
	 {m_bFixed = true;}

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprSP(){}
	
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode() {
		return std::string("sp");
	}

	/**
	 * @brief get operand is General Register and the index is not in used list
	 * Update content of mUGrR
	 * @param mUGrR: <RegIndex, <RegFreq, fixedFlag>>
	 */
	void GetGrRegister(std::map<UI32, std::pair<UI32, bool>> *mUGrR){}

	/**
	 * @brief replace operand is General Register and the index is not in used list
	 * @param mUsedGrReg: <RegIndex, <RegFreq, fixedFlag>>
	 */
	void ReplaceOprInList(std::map<UI32, std::pair<UI32, bool>> *mUsedGrReg){}
};




/**
 *  @brief  システムレジスタを抽象化するクラス
 */
class COprSR : public IOprE3V5 {
public:

	/**
	 * @brief このオブジェクトを構築します
	 */
	COprSR() : IOprE3V5((1<<IOperand::OPR_ATTR_SR), NULL), m_sr(0), m_filter(1) {
	}

	/**
	 * @brief このオブジェクトを構築します
	 * @param filter オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprSR(UI32 filter, IValConstraint* pvc)
		: IOprE3V5((1<<IOperand::OPR_ATTR_SR), pvc), m_sr(0), m_filter(filter)
	{}	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprSR(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode() {_ASSERT(0); return std::string();}
	
	
	virtual operator UI32() {
		(void*) Fix();
		return m_sr;
	}
	
	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	
	/**
	 * @brief  SelID 
	 * @return このオブジェクト参照
	 */	
	static UI32 SelID(COprSR* obj) {
		return (((UI32)*(obj->Fix())) >> 5);
	}
	
	/**
	 * @brief  SelID 
	 * @return このオブジェクト参照
	 */	
	static UI32 SelID(COprSR& obj) {
		return (((UI32)*(obj.Fix())) >> 5);
	}

	/**
	 * @brief  RegID 
	 * @return このオブジェクト参照
	 */	
	static UI32 RegID(COprSR* obj) {
		return (((UI32)*(obj->Fix())) & 0x1f);
	}

	/**
	 * @brief  RegID 
	 * @return このオブジェクト参照
	 */	
	static UI32 RegID(COprSR& obj) {
		return (((UI32)*(obj.Fix())) & 0x1f);
	}

	/**
	 * @brief Re-generate system register index
	 * @return pointer to this object.
	 */
	virtual IOperand* ReFix(){
		m_bFixed = false;
		return Fix();
	}
	
	/**
	 * @brief   Clarify   system register that store mismatch value between CForest and RTL
	 * @return True: System Register has mismatch value
	           False: System Register has not mismatch value
	 */
	virtual bool OprHasMismatch() { 
		UI32 sr = (UI32)*(this);
		return	(sr == (32 *  0 +  0)) /* EIPC  */ ||
				(sr == (32 *  0 +  2)) /* FEPC  */ ||
				(sr == (32 *  0 +  7)) /* FPEPC */ ||
				(sr == (32 *  0 + 16)) /* CTPC  */ ||
				(sr == (32 *  0 + 20)) /* CTBP  */ ||
				(sr == (32 *  1 +  2)) /* RBASE */ ||
				(sr == (32 *  1 +  3)) /* EBASE */ ||
				(sr == (32 *  1 +  4)) /* INTBP */ ||
				(sr == (32 *  1 + 12)) /* SCBP  */ ||
				(sr == (32 *  1 + 14)) /* HVCBP */ ||
				(sr == (32 *  2 +  6)) /* MEA   */ ||
				(sr == (32 *  2 + 18)) /* RBIP  */ ||
				(sr == (32 *  3 + 18)) /* DBPC  */ ||
                (sr == (32 *  9 + 13)) /* GMEIPC*/ ||
                (sr == (32 *  9 + 14)) /* GMFEPC*/ ||
                (sr == (32 *  4 + 26)) /* ICCFG */ ||
				//TSCOUNTL and TSCOUNTH is not mean address but will mismatch 
				//because the different timing between CF internal and standalone
				(sr == (32 * 11 + 0)) /* TSCOUNTL  */ ||
				(sr == (32 * 11 + 1)) /* TSCOUNTH  */ ||
				(sr == (32 * 14 + 16)) /* PMCOUNT0  */ ||
				(sr == (32 * 14 + 17)) /* PMCOUNT1  */ ||
				(sr == (32 * 14 + 18)) /* PMCOUNT2  */ ||
				(sr == (32 * 14 + 19)) /* PMCOUNT3  */ ||
				(sr == (32 * 14 + 20)) /* PMCOUNT4  */ ||
				(sr == (32 * 14 + 21)) /* PMCOUNT5  */ ||
				(sr == (32 * 14 + 22)) /* PMCOUNT6  */ ||
				(sr == (32 * 14 + 23)) /* PMCOUNT7  */;
		}

public:
	static ISysRegSet*		m_pSrSource;
	
protected:
	UI32					m_sr;
	UI32					m_filter;
};



/**
 *  @brief  固定システムレジスタを抽象化するクラス
 */
class COprFSR : public IOprE3V5 {
public:
	COprFSR(UI32 sel, UI32 reg, BS_OPRATTR attr = (1<<OPR_ATTR_SR), IValConstraint* pvc = NULL)
	: IOprE3V5(attr, pvc), m_sel(sel), m_reg(reg) {
		m_bFixed = true;
	}
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
	
	virtual operator UI32();
	
public:
	UI32	m_sel;		//!< @brief SelID
	UI32	m_reg; 		//!< @brief RegID
};



/**
 *  @brief  ベクトルレジスタオペランドを抽象化するクラス。
 */
class COprVR : public IOprE3V5
{
public:
	COprVR(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_vr(0){}
		
	COprVR(IRandom* p): m_pRand(p), m_rh(0), m_rt(31), m_vr(0) {}
	COprVR(IRandom* p, UI32 rh, UI32 rt): m_pRand(p), m_rh(rh), m_rt(rt), m_vr(0){}
	COprVR(UI32 vr): m_pRand(&g_rnd), m_rh(vr), m_rt(vr), m_vr(vr){ m_bFixed = true; }

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprVR(){}
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源
	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_vr;			//!< @brief 選択されたインデックス
};



/**
 *  @brief  ベクトルレジスタオペランドを抽象化するクラス。
 */
class COprVPR : public COprVR
{
public:
	COprVPR(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: COprVR(rh, rt, attr, pvc) 
	{
		m_attr.set(OPR_ATTR_XDEPEND);
	}


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprVPR(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
};



/**
 *  @brief  即値オペランドを抽象化するクラス。
 */
class COprImm : public IOprE3V5
{
public:
	COprImm(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), 
		m_pRand(&g_rnd), m_nMin(min), m_nMax(max), m_nVal(0), m_nMask(mask){}

    COprImm(UI32 val, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
        : IOprE3V5(attr, pvc),
        m_pRand(&g_rnd), m_nMin(val), m_nMax(val), m_nVal(val), m_nMask(mask) 
    {
        m_bFixed = true;
    }

	COprImm(UI32 min, UI32 max, UI32 mask)
		: IOprE3V5((1 << OPR_ATTR_IMM), NULL), 
		m_pRand(&g_rnd), m_nMin(min), m_nMax(max), m_nVal(0), m_nMask(mask){}
	
	COprImm(UI32 val)
		: IOprE3V5((1 << OPR_ATTR_IMM), NULL), 
		m_pRand(&g_rnd), m_nMin(val), m_nMax(val), m_nVal(val), m_nMask(~0U)
	{
		m_bFixed = true;
	}
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprImm(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
	
	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);

	/**
	 * @brief	This function replace the generating range.
	 * @param	(rh, rt) Generating range.
	 */
	virtual bool SetRange(UI32 rh, UI32 rt);
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	 virtual void Regulate(IRegulation* r);

     virtual UI32 GetBitCount() {
         return 0;
     }
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual operator UI32();
	
protected:
	IRandom*	m_pRand;
	UI32		m_nMin;
	UI32		m_nMax;
	UI32		m_nVal;
	UI32		m_nMask;
};



/**
 *  @brief  即値オペランド(符号拡張)を抽象化するクラス。
 */
class COprSImm : public IOprE3V5
{
public:
	COprSImm(SI32 min, SI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprE3V5(attr, pvc), m_pRand(&g_rnd), m_nMin(min), m_nMax(max), m_nVal(0), m_nMask(mask) {}
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprSImm(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);

		
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual operator UI32();
	
protected:
	IRandom*	m_pRand;
	SI32		m_nMin;
	SI32		m_nMax;
	SI32		m_nVal;
	UI32		m_nMask;
};



/**
 *  @brief  ディスプレースメントを抽象化するクラス。
 */
class COprDisp : public COprImm
{
public:
	COprDisp(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm(0U, ~0U, mask, attr, pvc) {}
	COprDisp(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm(min, max, mask, attr, pvc) {}


	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprDisp(){}
	

	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
};



/**
 *  @brief  ディスプレースメントを抽象化するクラス。
 */
class COprSDisp : public COprSImm
{
public:
	COprSDisp(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprSImm((SI32)0x80000000, (SI32)0x7fffffff, mask, attr, pvc) {}
		
	COprSDisp(SI32 min, SI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprSImm(min, max, mask, attr, pvc){}

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual ~COprSDisp(){}

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
};



/**
 *  @brief  condオペランドを抽象化するクラス。
 */
class COprCond : public COprImm
{
public:
	COprCond(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprImm (min, max, mask, attr, pvc){}
		
	COprCond(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm ((UI32)0U, (UI32)15U, mask, attr, pvc){}


	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~COprCond(){}
	
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
	
	
	/**
	 * @brief  cccc値を取得します。
	 * @return cccc値。
	 */	
	virtual operator UI32() {
		(void*) Fix();
		return m_nVal;
	}
};


/**
 *  @brief  cond(!13)オペランドを抽象化するクラス。
 */
class COprCondn13 : public COprCond
{
public:
	COprCondn13(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprCond (min, max, mask, attr, pvc){}
	
	COprCondn13(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprCond ((UI32)0U, (UI32)15U, mask, attr, pvc){}


	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~COprCondn13(){}


	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();


	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
	/**
	 * @brief  cccc値を取得します。
	 * @return cccc値。
	 */	
	virtual operator UI32() {
		(void*) Fix();
		return m_nVal;
	}
};



/**
 *  @brief  cond(!13)オペランドを抽象化するクラス。
 */
class COprPrefOp : public COprImm
{
public:
	COprPrefOp(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: COprImm (min, max, mask, attr, pvc){}
	
	COprPrefOp(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm ((UI32)0U, (UI32)1U, mask, attr, pvc){}


	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~COprPrefOp(){}
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
};



/**
 *  @brief  cacheopオペランドを抽象化するクラス。
 */
class COprCacheOp : public COprImm
{
public:
	COprCacheOp(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm (min, max, mask, attr, pvc){}
	COprCacheOp(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm ((UI32)0U, (UI32)14U, mask, attr, pvc){}


	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~COprCacheOp(){}
	
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
};



/**
 *  @brief  fcondオペランドを抽象化するクラス。
 */
class COprFCond : public COprImm
{
public:
	COprFCond(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm (min, max, mask, attr, pvc){}
	COprFCond(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm ((UI32)0U, (UI32)15U, mask, attr, pvc){}

	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~COprFCond(){}
	
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
};



/**
 *  @brief  fcbitオペランドを抽象化するクラス。
 */
class COprFcbit : public COprImm
{
public:
	COprFcbit(UI32 min, UI32 max, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm (min, max, mask, attr, pvc){}
	COprFcbit(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm ((UI32)0U, (UI32)15U, mask, attr, pvc){}

		
	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~COprFcbit(){}
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();
};



/**
 *  @brief  Vectorを抽象化するクラス
 */
class COprVector : public COprImm
{
public:
	COprVector(UI32 val): 
		COprImm (val) {}
	COprVector(UI32 w, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): 
		COprImm ((UI32)0U, (UI32)((1<<w) - 1), mask, attr, pvc){}
		
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprVector(){}

	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);

	virtual operator UI32() {
		(void*) Fix();
		return m_nVal;
	}
	
	static const UI32 m_chToSV = 0x1d;
	static const UI32 m_chToUM = 0x1e;
};



/**
 *  @brief  Vector4を抽象化するクラス(Vector4 != 0としている)。
 *          (FETRAP Only)
 */
class COprVector4 : public COprImm
{
public:
	COprVector4(UI32 val): 
		COprImm (val) {}
	COprVector4(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): 
		COprImm ((UI32)1U, 15U, mask, attr, pvc){}
		
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprVector4(){}
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();


	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
	static const UI32 m_chToSV = 0xd;
	static const UI32 m_chToUM = 0xe;
};


/**
 *  @brief  Vector5を抽象化するクラス(Vector5 != 0x1dとしている)。
 *          (TRAP, HVTRAP Only)
 */
class COprVector5 : public COprImm
{
public:
	COprVector5(UI32 val): 
		COprImm (val) { /* この場合のみspcode指定可能 */ }
	COprVector5(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): 
		COprImm ((UI32)0U, 0x1fU, mask, attr, pvc){}
		
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprVector5(){}


	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	/**
	 * @brief Re-generate system register index
	 * @return pointer to this object.
	 */
	virtual IOperand* ReFix();
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
	static const UI32 m_chToSV = 0x1d;
	static const UI32 m_chToUM = 0x1e;
	static const UI32 m_swReset = 0x1f;
};



/**
 *  @brief  list12を抽象化するクラス。
 */
class COprList12 : public COprImm
{
public:
	COprList12(UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm(0U, 0xFFFU, mask, attr, pvc){}

    COprList12(UI32 val, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc): COprImm(val, mask, attr, pvc) {}

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprList12(){}

	/**
	 * @brief  値制約の補正を行います(SPの補正)。
	 * @param  pReg 値制約検証情報
	 * @return trueの場合、成功。falseの場合、失敗。
	 */	
	virtual void Regulate(IRegulation* pReg);
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

    /**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 new_val);

	/**
	 * @brief  List12のビット数を数えます。
	 * @return ビット数
	 */	
	UI32 GetBitCount(); 
};

/**
 *  @brief  G4MH定義のオペランドを抽象化するクラス。
 */
 
class IOprG4MH : public IOprE3V5
{
public:

	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IOprG4MH() : IOprE3V5() {}
	

	/**
	 * @brief  このオブジェクトを生成します
	 * @param  bs 属性を示すビットセット
	 */	
	IOprG4MH(std::bitset<IOperand::OPR_ATTR_NUM> bs) : IOprE3V5( bs) {}

	/**
	 * @brief  このオブジェクトを生成します
	 * @param  bs 属性を示すビットセット
	 * @param  pVC 制約を示すオブジェクト
	 */	
	IOprG4MH(std::bitset<IOperand::OPR_ATTR_NUM> bs, IValConstraint* pVC) : IOprE3V5(bs, pVC) {}
	
	
	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~IOprG4MH(){};
	
};


/**
 *  @brief  FPベクトルレジスタオペランドを抽象化するクラス。
 */
class COprWR : public IOprG4MH
{
public:
	COprWR(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprG4MH(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_wr(0){}
		
	COprWR(IRandom* p): m_pRand(p), m_rh(0), m_rt(31), m_wr(0) {}
	COprWR(IRandom* p, UI32 rh, UI32 rt): m_pRand(p), m_rh(rh), m_rt(rt), m_wr(0){}
	COprWR(UI32 wr): m_pRand(&g_rnd), m_rh(wr), m_rt(wr), m_wr(wr){ m_bFixed = true; }

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprWR(){}
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();


	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);

	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源
	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_wr;			//!< @brief 選択されたインデックス
};


/**
 *  @brief  FPベクトルペアレジスタオペランドを抽象化するクラス。
 */
class COprPWR : public IOprG4MH
{
public:
	COprPWR(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprG4MH(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_wr(0){}
		
	COprPWR(IRandom* p): m_pRand(p), m_rh(0), m_rt(31), m_wr(0) {}
	COprPWR(IRandom* p, UI32 rh, UI32 rt): m_pRand(p), m_rh(rh), m_rt(rt), m_wr(0){}
	COprPWR(UI32 wr): m_pRand(&g_rnd), m_rh(wr), m_rt(wr), m_wr(wr){ m_bFixed = true; }

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprPWR(){}
	

	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();


	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);


	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index);
	
protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源
	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_wr;			//!< @brief 選択されたインデックス
};


/**
 *  @brief  汎用レジスタx2を抽象化するクラス。
 */
class COprRegReg : public IOprG4MH
{
public:
	/**
	 * @brief レジスタインデックスを指定してこのオブジェクトを生成します。
	 * @param r1 レジスタ1番号
	 * @param r2 レジスタ2番号
	 * @param dummy ダミー
	 */
	COprRegReg(UI32 r1, UI32 r2, UI32 dummy)
		: IOprG4MH(1<<OPR_ATTR_GR, NULL), m_pRand(&g_rnd), m_rh(r1), m_rt(r1), m_reg1(r1), m_reg2(r2)  { /*m_bFixed = true ;*/ };

	/**
	 * @brief レジスタインデックス範囲を指定してこのオブジェクトを生成します。
	 *        r0が選択不可能なオペランド用にオブジェクトを生成する場合、rh=1, rt31として生成します。
	 * @param rh レジスタ番号範囲下限
	 * @param rt レジスタ番号範囲上限
	 */
	COprRegReg(UI32 rh, UI32 rt)
		: IOprG4MH((1<<OPR_ATTR_GR), NULL), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_reg1(0), m_reg2(1)
	{
		m_attr.set(OPR_ATTR_IRAM);
		m_attr.set(OPR_ATTR_SMEM);
		m_attr.set(OPR_ATTR_LMEM);
	}

	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param mask マスク(未使用)
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprRegReg(UI32 rh, UI32 rt, UI32 mask, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprG4MH(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_reg1(0), m_reg2(1), m_nMask(mask) {} ;

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprRegReg(){}


	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();

    /**                                                                                                                                                                               
     * @brief  ソースレジスタインデックスを３２ビットフラグ形式で取得する                                                                                                             
     * @return ３２ビットフラグ                                                                                                                                                       
     */
    virtual REGFLG GetGrSrc(bool regulation ) ;


    /**                                                                                                                                                                               
     * @brief  デスティネーションレジスタインデックスを３２ビットフラグ形式で取得する                                                                                                 
     * @return ３２ビットフラグ                                                                                                                                                       
     */
    virtual REGFLG GetGrDst() ;


	/**
	 * @brief  オペランドを数値化します。
	 * @brief 選択されたインデックスreg1  reg2[reg1]
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 IdxReg1();

	
	/**
	 * @brief  オペランドを数値化します。
	 * @brief 選択されたインデックスreg2  reg2[reg1]
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 IdxReg2();


	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
	
	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Correction(IRegulation* pReg);
		
		
	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index1 上書きする値(reg1)
	 * @param  index2 上書きする値(reg2)
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index1, UI32 index2);
	
	
protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源

	UI32		m_dh;			//!< @brief ディスプレースメント下限
	UI32		m_dt;			//!< @brief ディスプレースメント上限
	UI32		m_disp;			//!< @brief 選択されたディスプレースメント値

	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_reg;			//!< @brief 選択されたインデックス
	UI32		m_reg1;			//!< @brief 選択されたインデックス1  reg2[reg1]
	UI32		m_reg2;			//!< @brief 選択されたインデックス2  reg2[reg1]
	UI32		m_nMask;		/*!< @brief マスク(DW)*/
};

/**
 *  @brief  ギャザー用オペランドを抽象化するクラス。
 */
class COprGtr2 : public IOprG4MH
{
public:
	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprGtr2(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprG4MH(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_reg(0) {} ;

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGtr2(){}

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();

protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源

	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_reg;			//!< @brief 選択されたインデックス
};

/**
 *  @brief  ギャザー用オペランドを抽象化するクラス。
 */
class COprGtr4 : public IOprG4MH
{
public:
	/**
	 * @brief レジスタインデックス範囲、マスク、属性を指定してこのオブジェクトを生成します。
	 * @param rh   レジスタ番号範囲下限
	 * @param rt   レジスタ番号範囲上限
	 * @param attr オペランド属性
	 * @param pvc  制約オブジェクト
	 */
	COprGtr4(UI32 rh, UI32 rt, BS_OPRATTR attr, IValConstraint* pvc)
		: IOprG4MH(attr, pvc), m_pRand(&g_rnd), m_rh(rh), m_rt(rt), m_reg(0) {} ;

	/**
	 * @brief このオブジェクトを破棄します
	 */
	virtual ~COprGtr4(){}

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg);
	
	/**
	 * @brief  オペランドをアセンブラコードに変換します。
	 * @return オペランド文字列
	 */	
	virtual std::string GetCode();

	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix();
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx();

protected:
	IRandom*	m_pRand;		//!< @brief 乱数発生源

	UI32		m_rh;			//!< @brief レジスタ選択範囲の下限
	UI32		m_rt;			//!< @brief レジスタ選択範囲の上限
	UI32		m_reg;			//!< @brief 選択されたインデックス
};

#endif /*OPERAND_H_*/

