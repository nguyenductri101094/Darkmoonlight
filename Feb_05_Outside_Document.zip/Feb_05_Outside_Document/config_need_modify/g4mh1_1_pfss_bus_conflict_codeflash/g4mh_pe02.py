# -*- coding: utf-8 -*-
set_has_mpu ("on");
set_has_fxu ("on");
set_peripherals ("ipir",    "off");
set_peripherals ("mecnt",   "off");
set_peripherals ("barrier", "off");
set_peripherals ("intc1",   "on");
set_peripherals ("intc2",   "on");
set_peripherals ("simio",   "on"); # result_register
set_peripherals ("perf",    "on"); # perfcnt

#set_peinfo(peid, clid, core)
set_peinfo(2,     1,    'g4mh')
set_mpunum (24);

# set external pins
#set_rbase (0, "P0NC")  # RBASE.RBASE/DV/RINT
#set_icctrl (1, "P0NC") # ICCTRL.ICHEN
#set_peid (0, "P0NC")
#set_bmid (0, "P0NC")
#set_spidlist (0xFFFFFFFF, "P0NC")
#set_spid (0, "P0NC")
#set_mpudmdp (1, "P0NC")


#error_area_set (0x20000000, 0x2000FFFF)
#error_area_clear (0x20000000)

#                                   |  same cl   |  diff cl   |
#ms_cl|start     | end       | attr |  F,  R,  W |  F,  R,  W | clid       |outstand | repeat|
ms_cl (0x00600000, 0x008fffff, "RX" , 12,  8,  8,  12,  8,  8, 1,           6,        4) #FlashROM CL1 - Bank C
ms_cl (0x00900000, 0x00bfffff, "RX" , 12,  8,  8,  12,  8,  8, 1,           6,        4) #FlashROM CL1 - Bank D
ms_cl (0xfe080000, 0xfe0fffff, "RWX", 23,  5,  7,  23,  5,  7, 1,           8,        2) #CRAM @ CL1

#                                   |  same pe   |same cl     | diff cl   |
#ms_pe|start     | end       | attr |  F,  R,  W |  F,  R,  W | F,  R,  W | peid       |outstand| repeat|
ms_pe (0xfd800000, 0xfd80ffff, "RWX", 15,  2,  5,  15, 11,  9, 19, 16, 11,  2,          12,       1) #L1RAM PE2

self_set (0xfde00000, 0xfdffffff, -0x00200000) #L1RAM self
self_set (0xfffc0000, 0xfffc3fff,  0x00004000) #Local Peripheral self (INTC1)
self_set (0xfffe0000, 0xffffffff, -0x00002000) #self area for perfcnt and result_register

reset()
max(0x00FFFFFF)
#load("")
#run()
#q()
