awk '

BEGIN { 
	FS=","
} 
{ 
		print $4
}
 
' $1/sreg.profile > $1/sreg2.profile