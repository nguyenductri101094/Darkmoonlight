awk '
BEGIN {
	split("YES",arr)
	FS = ","
	OFS = ","
}
{
		if (NR == 109) {
			$11 = arr[1]
			$12 = arr[1]
		}
		print $0
	
}' $1/sreg.profile > $1/sreg1.profile

rm $1/sreg.profile

mv $1/sreg1.profile $1/sreg.profile
