#include "ifexception.h"
#include "ifblk_manager.h"
#include "weight_parser.h"
#include "rtg_app.h"
#include "mxu_parser.h"
#include "blk_manager.h"
#include "instruction.h"
#include "insid_set.h"
#include "rtg_cfg.h"
#include "sysreg.h"
#include "adr_selector.h"
#include "usr_src.h"


#define	NewINS(_CB_, _INS_)		((_CB_)->AddOpeCode(_INS_))
//#define BRANCH_DEBUG
extern std::shared_ptr<CUserSourceFile>			g_usf;
extern std::shared_ptr<CAssemblerSourceFile>	g_asf;
extern std::shared_ptr<CGeneratorConfig>		g_cfg;
extern CAddressWeight							g_ExceptionAddr;


CBlockManager::CBlockManager(LIST_INSSET* ws)
	: m_pWeightSet(ws),  m_nAsyncCount(0), m_nHandlerReg(0), m_nWorkReg(0), m_bsVector(0xfffffffff)
{
	SectionData sd;
	SectionData::iterator sdi;
	UI32 nMin, nMax;

	m_nrmSet.Clear();

	sd = g_prf->GetSectionData("::INSTRUCTION_GLOBAL");
	if (sd.size() == 0) {
		m_nrmSet.DefaultSet();
		return;
	}

	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		CsvRow& r = (*sdi);
		nMin = 0; nMax = 0;

		try {
			// 拡張命令に対するパラメータをとる
			// 本来この構想は無かった、、泥臭い処理が対応する。
			if (r.size() == 4 && r[2].length() && r[3].length()) {
				if (r[0] == "Ins_C010_ld_array") {
					m_nrmSet.m_ldArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C011_st_array") {
					m_nrmSet.m_stArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C012_ls_array") {
					m_nrmSet.m_lsArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C013_sld_array") {
					m_nrmSet.m_sldArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C014_sst_array") {
					m_nrmSet.m_sstArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C015_sls_array") {
					m_nrmSet.m_slsArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C016_caxi_array") {
					m_nrmSet.m_caxiArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else{
					nMin = CToolFnc::AtoI(r[2].c_str());
					nMax = CToolFnc::AtoI(r[3].c_str());
					//MSG_INFO (0, "Format error ::INSTRUCTION_GLOBAL has too many parameters. %s may be extended ins.\n", r[0].c_str() );
				}
			}else if (r.size() == 2){
				nMin = 1;
				nMax = 1;
			}else {
				// Format error
				MSG_INFO (0, "Format error ::INSTRUCTION_GLOBAL has too many parameters. %s may be extended ins.\n", r[0].c_str() );
				continue;
			}
			
			nMin = (nMin == 0 ? 1 : nMin);
			nMin = (nMin > 64 ? 64 : nMin);
			nMax = (nMax > 64 ? 64 : nMax);
			if(nMin > nMax)
				nMax = nMin;
			std::string key = r[0];
			UI32 w = CToolFnc::AtoI(r[1].c_str());
			if (w) {
				UI32 id = m_nrmSet.SetWeight(key, w);
				if(id){
					std::pair<UI32, UI32> p = std::pair<UI32, UI32> (nMin, nMax);
					m_nrmSet.m_seqInsNum.insert(std::pair<UI32, std::pair<UI32, UI32>>(id, p));
				}
			}
		}catch (std::exception e) {
			MSG_INFO (0, "Format error ::INSTRUCTION_GLOBAL Custom instruction parameters are invalid.\n" );
		}
	}
	m_nrmSet.ReCalc();

	std::vector<std::pair<std::string,UI32>> vUcRndKey;
	const UI32 UC_ID_BASE = MAX_INS_ID + 1;
	UI32 nIdx = UC_ID_BASE;

	g_usf->GetRndKey(vUcRndKey);
	std::vector<std::pair<std::string,UI32>>::iterator itrUc;
	for(itrUc = vUcRndKey.begin(); itrUc != vUcRndKey.end(); itrUc++){
		m_nrmSet.SetWeight(nIdx, itrUc->second);
		nIdx++;
	}
	nIdx = UC_ID_BASE + g_usf->GetUserCodeNum();
	std::map< UI32,IExceptionConfig*>& vExp = g_exp->GetException();
	std::map<UI32, IExceptionConfig*>::iterator itrExp;

	for(itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
		IExceptionConfig* pExpConfig = itrExp->second;
		if(pExpConfig->m_id == IException::EXP_RESET && pExpConfig->m_weight != 0) {
			m_nrmSet.SetWeight(nIdx, pExpConfig->m_weight);
		}
		if(pExpConfig->m_bIsInterrupt && pExpConfig->m_weight != 0) {
			m_nrmSet.SetWeight(nIdx, pExpConfig->m_weight);
		}
		nIdx++;
	}

	// Randomize mismatch register set to generate for LD/ST destination in case of access to shared memory
    m_nMismatchRegSet = 0;
    if (g_cfg->IsEnableDCU() == true) {
        UI32 nNumOfMisReg = g_rnd.GetRange((UI32)5, (UI32)15);
        UI32 nEnd = g_rnd.GetRange((UI32) 21, (UI32) 29); // Register 21 ~ 29 are necessary for dispose/prepare
        UI32 nStart = nEnd - nNumOfMisReg + 1;
        for(UI32 r = nStart; r <= nEnd; r++) {
            m_nMismatchRegSet |= (1 << r);  // Continuous registers to increase register in pushsp/popsp
        }
    }
    m_nrmSet.m_nMismatchRegSet = m_nMismatchRegSet;
}

/**
 * @brief  generate vector of block. Purpose jump to handler block
 * @return vector block
 */
void CBlockManager::GenerateCodeToHandler(TBlockConfig* pCfg, std::vector<CVectorBlock*>* vNode, std::string handlerModeStr) {
	UI32	reg = (m_nHandlerReg == 0) ? g_rnd.GetRange(4,29) : m_nHandlerReg;
	m_nHandlerReg = reg;

	BS_VECTOR bsv = m_bsVector;
	CVectorBlock* pVB;
	std::string &frog_pe = CLabel::m_prefix;
	std::string vectorStr = GetMContext(pCfg);
	if (handlerModeStr == "_" ){
		vectorStr = handlerModeStr;
		handlerModeStr = GetMContext(pCfg);
	}
	std::bitset<BSV_VECTOR_NUM> bsvUser(0x0);
	GetUserHandler(frog_pe + vectorStr, &bsvUser);
	bool isSys	= pCfg->m_bSys;

	if (isSys == false) {
		pVB = new CVectorBlock(vectorStr + "vector_reset");
		pVB->SetAlign(512);
		NewINS( pVB, LDSR(reg, 29 ,0) );
		NewINS( pVB, MOV32P( handlerModeStr + "syserr_handler", reg) );
		NewINS( pVB, JMP32(reg) );

		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_SYSERR]) {
		pVB = new CVectorBlock( vectorStr + ("vector_syserr"));
		if(bsvUser[BSV_VECTOR_SYSERR]){
			pVB->SetHandlerLabel(vectorStr + "syserr_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_syserr", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );
			NewINS( pVB, MOV32P( handlerModeStr + "syserr_handler", reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_HVTRAP]) {
		pVB = new CVectorBlock( vectorStr + ("vector_hvtrap"));
		pVB->SetHandlerLabel("hvtrap_handler" , 1 );
		if(bsvUser[BSV_VECTOR_HVTRAP]){
			GetUserHanlderBody(frog_pe + vectorStr + "vector_hvtrap", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3 (G4MH2.0)/ FEWR= r3 (G3KH)
			NewINS( pVB, MOV32P("hvtrap_handler", reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_FETRAP]) {
		pVB = new CVectorBlock( vectorStr + ("vector_fetrap"));
		if(bsvUser[BSV_VECTOR_FETRAP]){
			pVB->SetHandlerLabel(vectorStr + "fetrap_handler" , 1 );
			GetUserHanlderBody(frog_pe + vectorStr + "vector_fetrap", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "fetrap_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_TRAP0]) {
		pVB = new CVectorBlock( vectorStr + ("vector_trap0"));
		if(bsvUser[BSV_VECTOR_TRAP0]){
			pVB->SetHandlerLabel(frog_pe + vectorStr + "trap0_handler" , 0 );
			GetUserHanlderBody(frog_pe + vectorStr + "vector_trap0", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 ,0) );								// EIWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "trap0_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_TRAP1]) {
		pVB = new CVectorBlock( vectorStr + ("vector_trap1"));
		if(bsvUser[BSV_VECTOR_TRAP1]){
			pVB->SetHandlerLabel(vectorStr + "trap1_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_trap1", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 ,0) );								// EIWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "trap1_handler").c_str(), reg));
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_RIE]) {
		pVB = new CVectorBlock( vectorStr + ("vector_rie"));
		if(bsvUser[BSV_VECTOR_RIE]){
			pVB->SetHandlerLabel(vectorStr + "rie_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_rie", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "rie_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_FPPFPI]) {
		pVB = new CVectorBlock( vectorStr + ("vector_fpe"));
		if(bsvUser[BSV_VECTOR_FPPFPI]){
			pVB->SetHandlerLabel(vectorStr + "fpp_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_fpe", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 ,0) );								// EIWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "fpp_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_UCPOP]) {
		pVB = new CVectorBlock( vectorStr + ("vector_ucpop"));
		if(bsvUser[BSV_VECTOR_UCPOP]){
			pVB->SetHandlerLabel(vectorStr + "ucpop_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_ucpop", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "ucpop_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_MPUMMU]) {
		pVB = new CVectorBlock( vectorStr + ("vector_mp"));
		if(bsvUser[BSV_VECTOR_MPUMMU]){
			pVB->SetHandlerLabel(vectorStr + "mp_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_mp", pVB);
		} else{
			NewINS( pVB, LDSR(reg ,29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P(handlerModeStr + "mp_handler", reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_PIE]) {
		pVB = new CVectorBlock( vectorStr + ("vector_pie"));
		if(bsvUser[BSV_VECTOR_PIE]){
			pVB->SetHandlerLabel(vectorStr + "pie_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_pie", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "pie_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_DEBUG]) {
		pVB = new CVectorBlock( vectorStr + ("vector_debug"));
		if(bsvUser[BSV_VECTOR_DEBUG]){
			pVB->SetHandlerLabel("debug_handler" , 2);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_debug", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 30 ,3) );								// DBWR= r3
			NewINS( pVB, MOV32P("debug_handler", reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_MAE]) {
		pVB = new CVectorBlock( vectorStr + ("vector_mae"));
		if(bsvUser[BSV_VECTOR_MAE]){
			pVB->SetHandlerLabel(vectorStr + "mae_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_mae", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "mae_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_BGINT]) {
		pVB = new CVectorBlock( vectorStr + ("vector_bgint"));
		if(bsvUser[BSV_VECTOR_BGINT]){
			pVB->SetHandlerLabel(vectorStr + "vector_bgint" , 3);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_bgint", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P("bgint_handler", reg) );
			NewINS( pVB, JMP32(reg) );
		}
	vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_FENMI]) {
		pVB = new CVectorBlock( vectorStr + ("vector_fenmi"));
		if(bsvUser[BSV_VECTOR_FENMI]){
			pVB->SetHandlerLabel("fenmi_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_fenmi", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 , 0) );								// FEWR= r3
			NewINS( pVB, MOV32P("fenmi_handler", reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_FEINT]) {
		pVB = new CVectorBlock( vectorStr + ("vector_feint"));
		if(bsvUser[BSV_VECTOR_FEINT]){
			pVB->SetHandlerLabel(vectorStr + "feint_handler" , 1);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_feint", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 29 ,0) );								// FEWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "feint_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT000]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint000"));
		if(bsvUser[BSV_VECTOR_EIINT000]){
			pVB->SetHandlerLabel(vectorStr + "eiint000_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint000", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P(  (handlerModeStr + "eiint000_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT001]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint001"));
		if(bsvUser[BSV_VECTOR_EIINT001]){
			pVB->SetHandlerLabel(vectorStr + "eiint001_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint001", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint001_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT002]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint002"));
		if(bsvUser[BSV_VECTOR_EIINT002]){
			pVB->SetHandlerLabel(vectorStr + "eiint002_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint002", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint002_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT003]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint003"));
		if(bsvUser[BSV_VECTOR_EIINT003]){
			pVB->SetHandlerLabel(vectorStr + "eiint003_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint003", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint003_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT004]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint004"));
		if(bsvUser[BSV_VECTOR_EIINT004]){
			pVB->SetHandlerLabel(vectorStr + "eiint004_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint004", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint004_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT005]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint005"));
		if(bsvUser[BSV_VECTOR_EIINT005]){
			pVB->SetHandlerLabel(vectorStr + "eiint005_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint005", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint005_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT006]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint006"));
		if(bsvUser[BSV_VECTOR_EIINT006]){
			pVB->SetHandlerLabel(vectorStr + "eiint006_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint006", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint006_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT007]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint007"));
		if(bsvUser[BSV_VECTOR_EIINT007]){
			pVB->SetHandlerLabel(vectorStr + "eiint007_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint007", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint007_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT008]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint008"));
		if(bsvUser[BSV_VECTOR_EIINT008]){
			pVB->SetHandlerLabel(vectorStr + "eiint008_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint008", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint008_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT009]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint009"));
		if(bsvUser[BSV_VECTOR_EIINT009]){
			pVB->SetHandlerLabel(vectorStr + "eiint009_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint009", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint009_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT010]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint010"));
		if(bsvUser[BSV_VECTOR_EIINT010]){
			pVB->SetHandlerLabel(vectorStr + "eiint010_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint010", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint010_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT011]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint011"));
		if(bsvUser[BSV_VECTOR_EIINT011]){
			pVB->SetHandlerLabel(vectorStr + "eiint011_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint011", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint011_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT012]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint012"));
		if(bsvUser[BSV_VECTOR_EIINT012]){
			pVB->SetHandlerLabel(vectorStr + "eiint012_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint012", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint012_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT013]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint013"));
		if(bsvUser[BSV_VECTOR_EIINT013]){
			pVB->SetHandlerLabel(vectorStr + "eiint013_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint013", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint013_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT014]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint014"));
		if(bsvUser[BSV_VECTOR_EIINT014]){
			pVB->SetHandlerLabel(vectorStr + "eiint014_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint014", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint014_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT015]) {
		pVB = new CVectorBlock( vectorStr + ("vector_eiint015"));
		if(bsvUser[BSV_VECTOR_EIINT015]){
			pVB->SetHandlerLabel(vectorStr + "eiint015_handler" , 0);
			GetUserHanlderBody(frog_pe + vectorStr + "vector_eiint015", pVB);
		} else{
			NewINS( pVB, LDSR(reg, 28 , 0) );								// EIWR= r3
			NewINS( pVB, MOV32P( (handlerModeStr + "eiint015_handler").c_str(), reg) );
			NewINS( pVB, JMP32(reg) );
		}
		NewINS(pVB, NOP());
		NewINS(pVB, NOP());
		vNode->push_back(pVB);
	}
}

std::vector<CVectorBlock*>* CBlockManager::GenerateIntVector(TBlockConfig* pCfg)
{
	UI32	reg = (m_nHandlerReg == 0) ? g_rnd.GetRange(4,29) : m_nHandlerReg;
	m_nHandlerReg = reg;
	UI32 workReg;
	do {
		workReg = g_rnd.GetRange(4, 25);
	} while(workReg <= m_nHandlerReg && m_nHandlerReg <= (workReg + 4));

	if(m_nWorkReg == 0 )
		m_nWorkReg = workReg;

	std::vector<CVectorBlock*>* vNode = new std::vector<CVectorBlock*>();
	CVectorBlock* pVB;
	IInstruction * ins ;
	
	std::string contextStr = GetMContext(pCfg);
	bool isSys	= pCfg->m_bSys;

	if (isSys) {
		UI32 reg2 = g_rnd.GetRange(4, 29);
		std::string vectorStr = "_";
		while(reg2 == reg) {
			reg2 = g_rnd.GetRange(4, 29);
		}
		pVB = new CBootBlock (); // ! -> 2 param constructor does not work well....
		pVB-> SetAddress(ADR_VECTOR_RESET);
		pVB-> SetLabel("_pe_reset");
		NewINS( pVB, MOV32P("_pe_check", reg) );
		NewINS( pVB, JMP32(reg) );
		vNode->push_back(pVB);

		// Generate vector code for RBASE register
		GenerateCodeToHandler(pCfg, vNode, vectorStr);

		pVB = new CBootBlock ();  // ! -> 2 param constructor does not work well....
		pVB-> SetAddress(0x200);
		pVB-> SetLabel(vectorStr + "pe_check");

        NewINS(pVB, MOV32P(GetMContext(pCfg) + "vector_reset", workReg));
        NewINS(pVB, LDSR(workReg, 3, 1)->Note("->EBASE"));	//EBASE

		// PSW
		NewINS( pVB, MOV32(0x00008020, reg) );
		NewINS( pVB, LDSR(reg, 5, 0) );
		NewINS( pVB, MOV32P(contextStr + "sync_mem_init", reg) );
		NewINS( pVB, JARL32(reg, 31) );

        UI32 addr;

    	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;
    	NewINS( pVB, MOV32(addr, reg) );
    	NewINS( pVB, MOV5 (1, reg2) );
    	NewINS( pVB, ins = STB16 (reg2, 0, reg) );
		ins->AppendComment("disable SyncPe") ;

    	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_SKIP_PE_COMPLETE;
    	NewINS( pVB, MOV32(addr, reg) );
    	NewINS( pVB, MOV5 (1, reg2) );
    	NewINS( pVB, ins = STB16 (reg2, 0, reg) );
		ins->AppendComment("disable WaitCompletePe") ;
		NewINS( pVB, MOV32P( contextStr + "preload", reg) );
		NewINS( pVB, JMP32(reg) );
		NewINS( pVB, NOP() );
		vNode->push_back(pVB);
		
		return vNode;
	}
	contextStr = GetModeContext(pCfg);
	// Generate vector code for EBASE register
	GenerateCodeToHandler(pCfg, vNode, contextStr);

	return vNode;
}

std::vector<CPreloadBlock*>* CBlockManager::GeneratePreload(TBlockConfig* pCfg) {

	FROG_ASSERT(pCfg);

	std::vector<CPreloadBlock*>* vNode = new std::vector<CPreloadBlock*>();
	std::string contextStr = GetMContext(pCfg);
	bool bSrInit = (pCfg->m_pSrSet != NULL);
	bool bVrInit = false;
	
	// ------------------------------------------------------------------------
	// Main block of "__preload"
	// ------------------------------------------------------------------------
	UI32 reg = g_rnd.GetRange((UI32)4,(UI32)30);
	CPreloadBlock* pPB = new CPreloadBlock( contextStr + "preload");
	if(pCfg->m_bNC == true) {
		// 暫定
		if ( CU1isON() ) {
			SwitchCoProcessor(pPB,10,3); // CU0=On, CU1=On
		}else{
			SwitchCoProcessor(pPB,10,1); // CU0=On, CU1=Off
		}
		NewINS(pPB, NOP() );
		NewINS(pPB, NOP() );

		// VR Init entry
		if (bVrInit) {
			// TC#0-N:VR
			NewINS(pPB, MOVR(0, 20) );										// r20   <= 0;
			NewINS(pPB, MOV32(g_hwInfo.m_htnum, 21) );						// r21   <= HTNUM;
			NewINS(pPB, LDSR(20, 10, 1)->SetLabel(contextStr + "vr_init_tcsel"));	// TCSEL <= r20 ::__gr_init_tcsel
			NewINS(pPB, MOV32P( contextStr + "vr_init", 10) );				// call __vr_init
			NewINS(pPB, JARL32(10, 31) );
			NewINS(pPB, ADD5(1, 20) );										// r20   <= (r20 + 1)
			NewINS(pPB, CMPR(21, 20) );										// CMP "tcsel" with r20
			NewINS(pPB, BNE17P( contextStr + "vr_init_tcsel"));				// break loop
			NewINS(pPB, NOP() );
			NewINS(pPB, NOP() );
		}
		
		// SR Init entry
		if (bSrInit) {
			NewINS(pPB, MOV32P( contextStr + "sr_nc_init", 10) );
			NewINS(pPB, JARL32(10, 31) );
			NewINS(pPB, NOP() );
			NewINS(pPB, NOP() );
			if (g_hwInfo.m_vmnum > 1) { // Virtulazation in G4MH20
				NewINS(pPB, MOVR(0, 20) );								    // r20   <= 0;
				NewINS(pPB, LDSR(20, 15, 1)->Note("NC:VCSEL")->SetLabel(contextStr + "sr_vc_init_vcsel"));	// TCSEL <= r20 ::__gr_init_tcsel
				NewINS(pPB, MOV32P( contextStr + "sr_vc_init", 10) );
				NewINS(pPB, JARL32(10, 31) );
				NewINS(pPB, ADD5(1, 20) );									// r20   <= (r20 + 1)
				NewINS(pPB, CMP5(g_hwInfo.m_vmnum, 20) );                   // CMP "tcsel" with r20
				NewINS(pPB, BNE17P( contextStr + "sr_vc_init_vcsel") );     // break loop
				NewINS(pPB, NOP() );
				NewINS(pPB, NOP() );
			}
			
			if (g_hwInfo.m_vmnum /* htnumでなくvmnum */ > 0) { // Virtulazation in G4MH20
				// vmnumが1以上で仮想化機能が有効になる -> NTとHT0を区別する 
				NewINS(pPB, MOVR(0, 20) );								    // r20   <= 0;
				NewINS(pPB, MOV32(g_hwInfo.m_htnum, 21) );					// r21   <= HTNUM;
				NewINS(pPB, LDSR(20, 10, 1)->Note("TCSEL")->SetLabel( contextStr + "sr_tc_init_tcsel"));	// TCSEL <= r20 ::__gr_init_tcsel
				NewINS(pPB, MOV32P( contextStr + "sr_tc_init", 10) );
				NewINS(pPB, JARL32(10, 31) );
				NewINS(pPB, ADD5(1, 20) );									// r20   <= (r20 + 1)
				NewINS(pPB, CMPR(21, 20) );                                 // CMP "tcsel" with r20
				NewINS(pPB, BNE17P( contextStr + "sr_tc_init_tcsel") );     // break loop
				NewINS(pPB, NOP() );
				NewINS(pPB, NOP() );
			}
		}
		//Convention mode
		if (pCfg->m_bGM == false ) {
			// Jump to sub preload
		    NewINS(pPB, MOV32P(contextStr + "callt_init", 10) );
			NewINS(pPB, JARL32(10, 31) );

			NewINS(pPB, MOV32P(contextStr + "syscall_init", 10) );
			NewINS(pPB, JARL32(10, 31) );

			// Goto Next block => __prologue
			NewINS( pPB, MOV32P(contextStr + "prologue", reg) );
			NewINS( pPB, JMP32(reg) );
			vNode->push_back(pPB);

			//! Memory INIT
			pPB = new CPreloadBlock(contextStr + "memory_init");
			NewINS( pPB, JMP32(31) ); // return code
			/* <Initialise code will be generated here> */
			NewINS (pPB, NOP()->SetLabel("NMNT_wr_preset_memory_1"));
			vNode->push_back(pPB);

            // Generate code to change privilege to UM
            GenerateChangePrivilegetoUM(pCfg, vNode);

            // Generate code to change privielege to SV(HV)
            GenerateChangePrivilegetoSV_HV(pCfg, vNode);

            // Generate code to change mode to GM
            GenerateChangeModetoGM(pCfg, vNode);

            // Generate code to change mode to HM
            GenerateChangeModetoHM(pCfg, vNode);

			//CALLT INIT
			pPB = GenerateCalltBlock(pCfg);			
			vNode->push_back(pPB);

			//SYSCALL INIT
			pPB = GenerateSysCallBlock(pCfg);
			vNode->push_back(pPB);

			// Synchronization flag INIT
			pPB = new CPreloadBlock(contextStr + "sync_mem_init");
			NewINS( pPB, JMP32(31) );
			vNode->push_back(pPB);
			
		}else {
		    // Jump to sub preload
			for (UI32 pos = 0; pos < g_cfg->m_mGMs.size(); pos++) {
				// Virtual Context
				pCfg->m_bNC = false;
				std::map<UI32, GM_Infor>::iterator itr = g_cfg->m_mGMs.begin();
				std::advance( itr, pos);
				pCfg->m_GMID = itr->first;
				std::string GMcontextStr = GetMContext(pCfg);

				NewINS(pPB, MOV32P(GMcontextStr + "callt_init", 10) );
				NewINS(pPB, JARL32(10, 31) );

				NewINS(pPB, MOV32P(GMcontextStr + "syscall_init", 10) );
				NewINS(pPB, JARL32(10, 31) );

				// Goto Next block => __prologue
				NewINS( pPB, MOV32P(GMcontextStr + "prologue", 10) );
				NewINS(pPB, JARL32(10, 31) );
			}

			pCfg->m_bNC = true;
			// Goto Next block => __prologue
			NewINS( pPB, MOV32P(contextStr + "prologue", reg) );
			NewINS( pPB, JMP32(reg) );
			vNode->push_back(pPB);

			// Synchronization flag INIT
			pPB = new CPreloadBlock(contextStr + "sync_mem_init");
			NewINS( pPB, JMP32(31) );
			vNode->push_back(pPB);
			//! Memory INIT
			pPB = new CPreloadBlock(contextStr + "memory_init");
			NewINS( pPB, JMP32(31) ); // return code
			/* <Initialise code will be generated here> */
			NewINS (pPB, NOP()->SetLabel("NMNT_wr_preset_memory_1"));
			vNode->push_back(pPB);

            // Generate code to change privilege to UM
            GenerateChangePrivilegetoUM(pCfg, vNode);

            // Generate code to change privielege to SV(HV)
            GenerateChangePrivilegetoSV_HV(pCfg, vNode);

            // Generate code to change mode to GM
            GenerateChangeModetoGM(pCfg, vNode);

            // Generate code to change mode to HM
            GenerateChangeModetoHM(pCfg, vNode);
		}
			
	} else {
		//! Memory INIT
		pPB = new CPreloadBlock(contextStr + "memory_init");
		NewINS( pPB, JMP32(31) ); // return code
		/* <Initialise code will be generated here> */
		NewINS (pPB, NOP()->SetLabel("NMNT_wr_preset_memory_1"));
		vNode->push_back(pPB);

		//CALLT INIT
		pPB = GenerateCalltBlock(pCfg);
		vNode->push_back(pPB);

		//SYSCALL INIT
		pPB = GenerateSysCallBlock(pCfg);
		vNode->push_back(pPB);
	}
	return vNode;
}

std::vector<CPreloadBlock*>* CBlockManager::GenerateSRsInit(TBlockConfig* pCfg) {
	FROG_ASSERT(pCfg);

	std::vector<CPreloadBlock*>* vNode = new std::vector<CPreloadBlock*>();
	std::string contextStr = GetMContext(pCfg);
	bool bSrInit = (pCfg->m_pSrSet != NULL);
	bool bVrInit = false;
	CPreloadBlock* pPB = new CPreloadBlock();
	// ------------------------------------------------------------------------
	// Sub block of "__preload"
	// ------------------------------------------------------------------------
	//! VREG INIT
	if (bVrInit) {
		pPB = new CPreloadBlock(contextStr + "vr_init");
		InitLdtcVR( pPB );
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);
	}
		
	//! SR INIT
	if (bSrInit) {
			
		std::map<UI32,ISysReg*> list = pCfg->m_pSrSet->GetInitalList();
//		pCfg->m_pSrSet->Dump() ;
		pPB = new CPreloadBlock(contextStr + "sr_nc_init");
		InitNcSR(pPB, &list);
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);

		pPB = new CPreloadBlock(contextStr + "sr_vc_init");
		InitVcSR(pPB, &list);
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);
		
		pPB = new CPreloadBlock(contextStr + "sr_tc_init");
		InitTcSR(pPB, &list);
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);
	}
	return vNode;
}

/**
 * @brief		 Generate debug break set up block
 *               This is block that config for breakpoint exception
 * @param returnReg   reg is used for return to caller block
 * @param pCfg   TBlockConfig
 * @return       CPreloadBlock
 */
CPreloadBlock*	CBlockManager::GenerateDebugBreakSetUpBlock(TBlockConfig* pCfg, UI32 returnReg) {
	CPreloadBlock* pPB = new CPreloadBlock();
	UI32 reg = m_nWorkReg;
	pPB->SetOutputFlag(true);
	// Default is label for main block
	std::string label = "debug_breaksetup" ;
	// Determine CONVENTION MODE or VIRTUALIZATION SUPPORT
	if (pCfg->m_bGM == false){

	} else	if (pCfg->m_bNC == false){// Break set up sub block for each VM
		label = GetMContext(pCfg) + label;
	} else { // Main block jump to sub block to setting break point for each VM
		UI32 curGMID = pCfg->m_GMID;
		NewINS( pPB, STSR(15, reg, 0));  // PSWH
		NewINS( pPB, SHR5(0x8, reg));
        NewINS( pPB, ANDI(0x7, reg, reg));    // PSWH.GPID
		for (UI32 pos = 0; pos < g_cfg->m_mGMs.size(); pos++) {
			std::string subBlocklabel;		
			std::map<UI32, GM_Infor>::iterator itr = g_cfg->m_mGMs.begin();
			std::advance( itr, pos);
			pCfg->m_GMID = itr->first;
			std::stringstream ss;
			ss << label << "_not_GPID_"<< pCfg->m_GMID;
			NewINS( pPB, CMP5(pCfg->m_GMID, reg));
			NewINS( pPB, BNZ9P(ss.str().data()));
			pCfg->m_bNC = false;
			// Get label of VM
			subBlocklabel = GetMContext(pCfg) + "debug_breaksetup";
			pCfg->m_bNC = true;
			NewINS( pPB, MOV32P(subBlocklabel, reg));
			NewINS( pPB, JARL32(reg, returnReg - 1) );
			NewINS( pPB, BR9P(label + "_return_to_debug_handler"));
			NewINS( pPB, NOP()->SetLabel(ss.str().data()));
		}
		pCfg->m_GMID = curGMID;
	}
	pPB->SetLabel(label);
	NewINS( pPB, JMP32(returnReg)->SetLabel(label + "_return_to_debug_handler"));
	
	return pPB;
}

/**
 * @brief  メモリ初期化コードを生成します。
 * @param  メモリ初期化情報
 */
CPreloadBlock * CBlockManager::AppendMemPresetBlock(std::vector<T_MEMWRRECORD > * recode) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	MSG_INFO(0, "================================= Preset memory ======================================\n");
#endif
	auto GetWRPresetMem = [] (std::vector<T_MEMWRRECORD> *mpd, std::vector<T_MEMWRRECORD> *mpd_wr) {
		std::vector<T_MEMWRRECORD>::iterator itr;
		itr = mpd->begin();
		while(itr != mpd->end()){
			UI32 addr = itr->first;
			if(addr >= g_wm.BASE_WR_PRESET && addr <= g_wm.BASE_WORK_END) {
				std::pair<UI32, UI64> r = std::pair<UI32, UI64> (itr->second.first, itr->second.second);
				mpd_wr->push_back(T_MEMWRRECORD(itr->first, r));
				itr = mpd->erase(itr);
			} else {
				itr++;
			}
		}
	};

	TBlockConfig cfg;
	cfg.m_bNC = true;
	std::string contextStr = GetMContext(&cfg);
	std::vector<T_MEMWRRECORD> mpd_wr;
	GetWRPresetMem(recode, &mpd_wr);


	// Memory INIT
	CPreloadBlock* pPB = new CPreloadBlock(contextStr + "memory_init");

	UI32 reg= 10 ;
	UI32 memreg= 11 ;
	UI32 imm ;
	std::vector<T_MEMWRRECORD >::iterator  itr;	
#if 0
	char str[80] ;
	IInstruction * ins ;
	for (itr = recode->begin(); itr != recode->end(); itr++) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
				std::cout	<< "Info : "
							<< "Preset Memory: address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << itr->first 
							<< " size=0x"                  << itr->second.first
							<< " data=0x"                  << std::setw(16) << std::right << std::setfill('0') << std::hex << itr->second.second 
							<< std::endl;
#endif
		UI32 size= itr->second.first ;
		if ((size == 0)||(size > 8)) { continue ; }

		// ROM領域に対するプリロード処理（命令でかけないため.WORDで処理する）
		UI32 adr= itr->first ;
		UI64 val=itr->second.second;
		UI32 disp= 0 ;
		if (g_prf->IsInSconst(adr)) {
			continue;
		}
		// <-
		if(g_LoadableAddr.GetMemError(adr) == true || g_StorableAddr.GetMemError(adr) == true || g_RmwAddr.GetMemError(adr) == true)
			continue;

		NewINS( pPB,  ins= MOV32( adr , memreg ) );
		sprintf(str ,"0x%08x: 0x%016llx size_%d" ,adr ,val ,size ) ;
		ins->AppendComment((LPCTSTR)str) ;

		while (size >= 4) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STW16( reg , disp , memreg) );
			disp += 4 ;
			size -= 4 ;
			val >>= 32 ;
		}		
		if (size >= 2) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STH16( reg , disp , memreg) );
			disp += 2 ;
			size -= 2 ;
			val >>= 16 ;
		}		
		if (size != 0) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STB16( reg , disp , memreg) );
		}
	}

	if(mpd_wr.size() > 0) {
		NewINS(pPB, MOV32P("NMNT_wr_preset_memory_0",11));
		NewINS(pPB, JMP32(11));
		NewINS(pPB, NOP()->SetLabel("NMNT_wr_preset_memory_0_ret"));
	}
#endif

	InitMemory(pPB, 0xFEA00000, 0xFEFFFFFF, 0);
	NewINS( pPB, JMP32(31) ); // return code

	// Insert memory preset to preset WR Register
	UI32 nBlockCount = 0;
	for(itr = mpd_wr.begin(); itr != mpd_wr.end(); itr++) {
		UI32 adr = itr->first ;
		UI64 val = itr->second.second;

		if(adr == g_wm.BASE_WR_PRESET || itr == mpd_wr.begin()) {
			if(nBlockCount > 1) {
				std::stringstream ss;
				std::string label;
				ss << "NMNT_wr_preset_memory_" << (nBlockCount - 1);
				ss << "_ret";
				ss >> label;
				NewINS(pPB, MOV32P(label,11));
				NewINS(pPB, JMP32(11));
			}
			if(nBlockCount > 0) {
				std::stringstream ss1;
				std::string label;
				ss1 << "NMNT_wr_preset_memory_" << nBlockCount;
				ss1 >> label;
				imm = (UI32)val;
				NewINS( pPB,  MOV32( adr , memreg)->SetLabel(label));
				NewINS( pPB,  MOV32( imm , reg));
				NewINS( pPB,  STW16( reg , 0 , memreg));
			}
			nBlockCount++;
		} else if(nBlockCount > 1){
			imm = (UI32)val;
			NewINS( pPB,  MOV32( adr , memreg));
			NewINS( pPB,  MOV32( imm , reg));
			NewINS( pPB,  STW16( reg , 0 , memreg));
		}
		if(nBlockCount == 1)
			recode->push_back(*itr);
	}
	if(nBlockCount > 1) {
		std::stringstream ss;
		std::string label;
		ss << "NMNT_wr_preset_memory_" << nBlockCount - 1;
		ss << "_ret";
		ss >> label;
		NewINS(pPB, MOV32P(label,11));
		NewINS(pPB, JMP32(11));
	}

	return (pPB) ;
}

CPreloadBlock * CBlockManager::AppendShareMemPreset(std::vector<T_MEMWRRECORD > * recode)
{
	TBlockConfig cfg;
	cfg.m_bNC = true;
	std::string contextStr = GetMContext(&cfg);

	// Memory INIT
	CPreloadBlock* pPB = new CPreloadBlock(contextStr + "sync_mem_init");
	char str[80] ;
	IInstruction * ins ;
	UI32 reg= 10 ;
	UI32 memreg= 11 ;
	UI32 imm ;
	std::vector<T_MEMWRRECORD >::iterator  itr;	
	for (itr = recode->begin(); itr != recode->end(); itr++) {
		UI32 size= itr->second.first ;
		if ((size == 0)||(size > 8)) { continue ; }

		// ROM領域に対するプリロード処理（命令でかけないため.WORDで処理する）
		UI32 adr= itr->first ;
		UI64 val=itr->second.second;
		UI32 disp= 0 ;
		if (g_prf->IsInSconst(adr)) {
			continue;
		}
		// <-
		
		NewINS( pPB,  ins= MOV32( adr , memreg ) );
		sprintf(str ,"0x%08x: 0x%016llx size_%d" ,adr ,val ,size ) ;
		ins->AppendComment((LPCTSTR)str) ;

		while (size >= 4) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STW16( reg , disp , memreg) );
			disp += 4 ;
			size -= 4 ;
			val >>= 32 ;
		}		
		if (size >= 2) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STH16( reg , disp , memreg) );
			disp += 2 ;
			size -= 2 ;
			val >>= 16 ;
		}		
		if (size != 0) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STB16( reg , disp , memreg) );
		}
	}
	NewINS( pPB, JMP32(31) ); // return code
	return pPB;
}
CCodeBlock*	CBlockManager::InitGR(CCodeBlock* pCB) {
	
	FROG_ASSERT(pCB);

	for (UI32 i = 1; i < 30; i++) {
		NewINS( pCB, RANDGR(i) );
	}
	return pCB;
}

CCodeBlock*	CBlockManager::InitWR(CCodeBlock* pCB) {
	
	FROG_ASSERT(pCB);

	UI32 reg1 = 1; // Intermediate address to initialize WR
	UI32 addr = g_wm.BASE_WR_INIT;
	extern std::unique_ptr<ISimulatorControl>		g_sim;
	ISimulator* pSim = g_sim->GetSimulator();

	//variable using for store preset data for WR
	IRandom* pRand = new CMersenneTwister();
	UI32 PrsVal = 0;
	const UI32 PSIZE = 4;		//Memory size to preset: 4

	if ( CU1isON() ) {

        for (UI32 i = 0; i < 32; i++) {
            //Get the address that contain init value 
            NewINS(pCB, MOV32(addr, reg1));

            //Preset 4th word
            PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
            pSim->PresetMemory(true, 0, addr, PSIZE, PrsVal);
            //Preset 3rd word
            PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
            pSim->PresetMemory(true, 0, addr + PSIZE, PSIZE, PrsVal);
            //Preset 2nd word
            PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
            pSim->PresetMemory(true, 0, addr + 2 * PSIZE, PSIZE, PrsVal);
            //Preset 1st word
            PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
            pSim->PresetMemory(true, 0, addr + 3 * PSIZE, PSIZE, PrsVal);

            //Load the init value to wire register
            NewINS(pCB, LDVQW(0, reg1, i));
            addr += 4 * PSIZE;
        }
	}
	return pCB;
}



CCodeBlock*	CBlockManager::InitLdtcVR(CCodeBlock* pCB) {
	FROG_ASSERT(pCB);
	for (UI32 i = 0; i < 32; i++) {
		NewINS( pCB, LDTC_VR( (i & 0x1E), i) ) ;
	}
	return pCB;
}


CCodeBlock*	CBlockManager::InitNcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* pList) {
	
	FROG_ASSERT(pList);
	
	// NCコンテキスト以外をフィルタリングして初期化リストを作成する。
	std::map<UI32,ISysReg*>::iterator	itr;
	std::vector<std::pair<ISysReg*,UI32> >	nclist;
	
	for (itr = pList->begin(); itr != pList->end(); itr++) {
		// 検討：E3V5Arc部なのだが、I/Fとして公開た方が良いか

		if(itr->second->IsInitNC()) {
			UI32 nc = 0;
			itr->second->GetNcInit(&nc);
			nclist.push_back(std::pair<ISysReg*,UI32>(itr->second, nc));
		}
	}
	return this->InitSR(pCB, nclist);
}

CCodeBlock*	CBlockManager::InitVcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* pList) {
	
	FROG_ASSERT(pList);
	
	// VCコンテキスト以外をフィルタリングして初期化リストを作成する。
	std::map<UI32,ISysReg*>::iterator	itr;
	std::vector<std::pair<ISysReg*,UI32> >	vclist;
	
	for (itr = pList->begin(); itr != pList->end(); itr++) {
		// 検討：E3V5Arc部なのだが、I/Fとして公開た方が良いか
	
		if(itr->second->IsInitVC()) {
			UI32 vc = 0;
			itr->second->GetVcInit(&vc);
			vclist.push_back(std::pair<ISysReg*,UI32>(itr->second, vc));
		}
	}
	return this->InitLdvcSR(pCB, vclist);
}


CCodeBlock*	CBlockManager::InitTcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* pList) {
	
	FROG_ASSERT(pList);
	
	// VCコンテキスト以外をフィルタリングして初期化リストを作成する。
	std::map<UI32,ISysReg*>::iterator	itr;
	std::vector<std::pair<ISysReg*,UI32> >	tclist;
	
	for (itr = pList->begin(); itr != pList->end(); itr++) {
		// 検討：E3V5Arc部なのだが、I/Fとして公開た方が良いか
		
		if(itr->second->IsInitTC()) {
			UI32 tc = 0;
			itr->second->GetTcInit(&tc);
			tclist.push_back(std::pair<ISysReg*,UI32>(itr->second, tc));
		}
	}
	return this->InitLdtcSR(pCB, tclist);
}

CCodeBlock*	CBlockManager::InitSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf) {
	
	FROG_ASSERT(pCB);
	
	UI32 tmpR = 10;

    // Init default value of non-default value register
    // CTBP
    if(g_srs->IsInit(20, 0, CSysRegSet::CONTEXT_NC) == false) {
        IInstruction*  pIns = LDSR( 0, 20, 0); // r0を使う
        pIns->AppendComment("CTBP");
		NewINS (pCB, pIns);
    }

    // INTBP
    if(g_srs->IsInit(4, 1, CSysRegSet::CONTEXT_NC) == false) {
        IInstruction*  pIns = LDSR( 0, 4, 1); // r0を使う
        pIns->AppendComment("INTBP");
		NewINS (pCB, pIns);
    }

    // SCBP
    if(g_srs->IsInit(12, 1, CSysRegSet::CONTEXT_NC) == false) {
        IInstruction*  pIns = LDSR( 0, 12, 1); // r0を使う
        pIns->AppendComment("SCBP");
		NewINS (pCB, pIns);
    }
	
	std::vector< std::pair<ISysReg*,UI32> >::iterator itr;
	for (itr = srinf.begin(); itr != srinf.end(); itr++) {
		UI32 regId	= 0;
		itr->first->GetRegId(&regId);
		UI32 selId	= 0;
		itr->first->GetSelReg(&selId);// >> 5;	// selId = v / 23
		UI32 val	= itr->second;
		IInstruction* pIns = NOP();

		if (val) {
            if (selId == 5 && regId == 0) val &= 0xFFFFFFFE;
			NewINS( pCB, MOV32( val, tmpR ) );
			pIns = LDSR( tmpR, regId, selId);
		} else {
			pIns = LDSR( 0, regId, selId); // r0を使う
		}

		std::string regName("");
		itr->first->GetRegName(&regName);
		pIns->AppendComment(regName.data());
		NewINS (pCB, pIns);
	}
    // Re-init PSW register due to ticket #19466 (New Redmine): PSW.EIMASK, GMPSW.EIMASK can not be updated if INTCFG.EPL = 0
    UI32 val_PSW = g_srs->GetNcInit(5, 0);
    UI32 val_GMPSW = g_srs->GetNcInit(5, 9);
    if (val_PSW) {
        NewINS(pCB, MOV32(val_PSW, tmpR));
        IInstruction* pIns = LDSR(tmpR, 5, 0);
        NewINS(pCB, pIns);
    }
    if (val_GMPSW) {
        NewINS(pCB, MOV32(val_GMPSW, tmpR));
        IInstruction* pIns = LDSR(tmpR, 5, 9);
        NewINS(pCB, pIns);
    }

	return pCB;
}

CCodeBlock*	CBlockManager::InitLdvcSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf) {
	
	FROG_ASSERT(pCB);
	
	UI32 tmpR = 10;
	
	std::vector< std::pair<ISysReg*,UI32> >::iterator itr;
	for (itr = srinf.begin(); itr != srinf.end(); itr++) {
		UI32 regId	= 0;
		itr->first->GetRegId(&regId);
		UI32 selId	= 0;
		itr->first->GetSelReg(&selId);// >> 5;	// selId = v / 23
		UI32 val	= itr->second;
		IInstruction* pIns;
		if (val) {
			NewINS( pCB, MOV32( val, tmpR ) );
			pIns = LDVC_SR( tmpR, regId, selId);
		} else {
			pIns = LDVC_SR( 0, regId, selId); // r0を使う
		}

		std::string regName("");
		itr->first->GetRegName(&regName);
		pIns->AppendComment(regName.data());

		NewINS (pCB, pIns);
	}
	return pCB;
}

CCodeBlock*	CBlockManager::InitLdtcSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf) {
	
	FROG_ASSERT(pCB);
	
	UI32 tmpR = 10;

    // Init default value of non-default value register
    // CTBP
    if(g_srs->IsInit(20, 0, CSysRegSet::CONTEXT_TC) == false) {
        IInstruction*  pIns = LDTC_SR( 0, 20, 0); // r0を使う
        pIns->AppendComment("CTBP");
		NewINS (pCB, pIns);
    }

    // INTBP
    if(g_srs->IsInit(4, 1, CSysRegSet::CONTEXT_TC) == false) {
        IInstruction*  pIns = LDTC_SR( 0, 4, 1); // r0を使う
        pIns->AppendComment("INTBP");
		NewINS (pCB, pIns);
    }

    // SCBP
    if(g_srs->IsInit(12, 1, CSysRegSet::CONTEXT_TC) == false) {
        IInstruction*  pIns = LDTC_SR( 0, 12, 1); // r0を使う
        pIns->AppendComment("SCBP");
		NewINS (pCB, pIns);
    }
	
	std::vector< std::pair<ISysReg*,UI32> >::iterator itr;
	for (itr = srinf.begin(); itr != srinf.end(); itr++) {
		UI32 regId	= 0;
		itr->first->GetRegId(&regId);
		UI32 selId	= 0;
		itr->first->GetSelReg(&selId);// >> 5;	// selId = v / 23
		UI32 val	= itr->second;
		IInstruction* pIns = NOP();

		if((( CU1isON()==0 )&&(selId==8))&&((regId==6)||(regId==7)||(regId==8)||(regId==9)||(regId==10)||(regId==11)||(regId==12)||(regId==13)))
		{
		}else{

			if (val) {
			NewINS( pCB, MOV32( val, tmpR ) );
			pIns = LDTC_SR( tmpR, regId, selId);
			} else {
			pIns = LDTC_SR( 0, regId, selId); // r0を使う
			}

		}

		std::string regName("");
		itr->first->GetRegName(&regName);
		pIns->AppendComment(regName.data());
		NewINS (pCB, pIns);
	}
	return pCB;
}

CCodeBlock*	CBlockManager::InitMemory(CCodeBlock* pCB, UI32 head, UI32 tail, UI64 val) {
	
	FROG_ASSERT (head < tail);
	
	return pCB;
}

void CBlockManager::ExpReturnPcInit() {
	/*This is rountine to initialize retPC index, TODO: Write a function later*/
	extern std::unique_ptr<ISimulatorControl> g_sim;
	ISimulator* pSim = g_sim->GetSimulator();
	const UI32 PC_INDEX_ADDR = g_wm.EXP_RET_PC_INDEX;
	const UI32 DBTRAP_PRESET_ADDR = g_wm.DBTRAP_PC_INDEX;
	pSim->PresetMemory(true, 0, PC_INDEX_ADDR, 4, PC_INDEX_ADDR);
	
	for(UI32 addr = DBTRAP_PRESET_ADDR; addr < g_wm.EXP_RET_PC_INDEX; addr += 2044){
		pSim->PresetMemory(true, 0, addr, 4, addr);
	}
}


CHandlerBlock* CBlockManager::GenerateExpReturnBlock(UI32 ExpLevel, UI32 reg) {
	std::string label = "Handler_calculate_PC_revert_GRs";
	if(ExpLevel == IExceptionConfig::EXP_LEVEL_FE)
		label += "_fe";
	else
		label += "_ei";

	CHandlerBlock* pHB = new CHandlerBlock(label);

	pHB->SetOutputFlag(true);
	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	UI32 reg3 = reg + 3;
	UI32 reg4 = reg + 4;
	UI32 XXPC_RegId = (ExpLevel == IExceptionConfig::EXP_LEVEL_EI ? 0 : 2);
	UI32 XXWR_RegId = (ExpLevel == IExceptionConfig::EXP_LEVEL_EI ? 28 : 29);
	IInstruction* pXXRET  = EIRET();
	if(ExpLevel == IExceptionConfig::EXP_LEVEL_FE)
		pXXRET  = FERET();
	IInstruction* pSTSR  = STSR(XXWR_RegId, m_nHandlerReg, 0);


	NewINS( pHB,  STSR(8, reg4, 1));		// Save SVLOCK
	NewINS( pHB,  LDSR(0, 8, 1));			// Disable SVLOCK

	NewINS( pHB,  STSR(0, reg2, 5)  );		// Save MPM
	NewINS( pHB,  LDSR(0, 0, 5) );			// disable MPM
	NewINS( pHB,  SYNCI());


	NewINS( pHB,  MOV32(g_wm.EXP_RET_PC_INDEX,reg)  );//Get Index'address
	NewINS( pHB,  LDW16(0, reg, reg1)  );	//Load index to reg1
	NewINS( pHB,  ADD5(4, reg1) );
	NewINS( pHB,  STW16(reg1, 0, reg) ); //update the index value
	NewINS( pHB,  LDW16(0, reg1, reg3)  );	//Using reg1 as index to loadPC
	NewINS( pHB,  STSR(XXPC_RegId, reg, 0)  );
	NewINS( pHB,  ADD(reg3, reg));

	NewINS( pHB,  LDSR(reg, XXPC_RegId, 0) );			// XXPC <- r31
	NewINS( pHB,  LDSR(reg2, 0, 5));			// Recover MPM
	NewINS( pHB,  SYNCI());


	NewINS( pHB,  LDSR(reg4, 8, 1));			// Recover SVLOCK

	NewINS( pHB,  POPSP(1, 31)) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB,  pSTSR) ;	pSTSR->AppendComment("r3= XXWR ; recover") ;
	NewINS( pHB,  pXXRET) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	return pHB;
}

CHandlerBlock* CBlockManager::GenerateReadSysRegBlock(UI32 reg) {

	CHandlerBlock* pHB = new CHandlerBlock("Handler_read_system_registers");
	pHB->SetOutputFlag(true);

	// EI/FE Common Exception SysReg
	NewINS( pHB,  STSR(  5,reg, 0)  );		// PSW
	NewINS( pHB,  STSR(  0,reg, 0)  );		// EIPC
	NewINS( pHB,  STSR(  2,reg, 0)  );		// FEPC
	NewINS( pHB,  STSR(  1,reg, 0)  );		// EIPSW
	NewINS( pHB,  STSR(  3,reg, 0)  );		// FEPSW
	NewINS( pHB,  STSR( 13,reg, 0)  );		// EIIC
	NewINS( pHB,  STSR( 14,reg, 0)  );		// FEIC
	NewINS( pHB,  STSR( 16,reg, 0)  );		// CTPC
	NewINS( pHB,  JR22P("read_basic_system_registers_end")  );		// Jump to the end

	NewINS( pHB,  STSR( 17,reg, 0)  );		// CTPSW
	NewINS( pHB,  STSR( 28,reg, 0)  );		// EIWR
	NewINS( pHB,  STSR( 29,reg, 0)  );		// FEWR
	NewINS( pHB,  JR22P("read_FPU_system_registers")  );		// Read fpu's system registers
	NewINS( pHB,  STSR(  0,reg, 1)  );		// MCFG0
	NewINS( pHB,  STSR(  1,reg, 1)  );		// MCFG1
	NewINS( pHB,  STSR(  2,reg, 1)  );		// RBASE
	NewINS( pHB,  STSR(  3,reg, 1)  );		// EBASE
	NewINS( pHB,  JR22P("read_basic_system_registers_end")  );		// Jump to the end

	NewINS( pHB,  STSR(  4,reg, 1)  );		// INTBP
	NewINS( pHB,  STSR(  5,reg, 1)  );		// MCTL
	NewINS( pHB,  STSR( 11,reg, 1)  );		// SCCFG

	NewINS( pHB,  STSR(  1,reg, 0)  );		// EIPSW
	NewINS( pHB,  STSR( 6,reg, 2)  );		// MEA
	NewINS( pHB,  JR22P("read_FPU_system_registers")  );		// Read fpu's system registers

	NewINS( pHB,  STSR( 12,reg, 1)  );		// SCBP
	NewINS( pHB,  STSR( 20,reg, 0)  );		// CTBP
	NewINS( pHB,  JR22P("read_basic_system_registers_end")  );		// Jump to the end

	NewINS( pHB,  STSR(  3,reg, 0)  );		// FEPSW
	NewINS( pHB,  STSR( 28,reg, 0)  );		// EIWR
	NewINS( pHB,  STSR( 29,reg, 0)  );		// FEWR
	NewINS( pHB,  STSR( 8,reg, 2)  );		// MEI
	NewINS( pHB,  JR22P("read_basic_system_registers_end")  );		// Jump to the end
	
	// FPU Sys
	NewINS( pHB,  STSR(  5,reg, 0)->SetLabel( "read_FPU_system_registers")   );		// PSW
	NewINS( pHB,  SHR5(17U,reg));
	NewINS( pHB,  BNC17P("read_basic_system_registers_end")  );
	NewINS( pHB,  STSR(  6,reg, 0)  );		// FPSR
	NewINS( pHB,  STSR(  7,reg, 0)  );		// FPEPC
	NewINS( pHB,  STSR(  8,reg, 0)  );		// FPST
	NewINS( pHB,  STSR(  9,reg, 0)  );		// FPCC
	NewINS( pHB,  STSR( 10,reg, 0)  );		// FPCFG
	NewINS( pHB,  STSR( 11,reg, 0)  );		// FPEC
	NewINS( pHB,  JR22P("read_basic_system_registers_end")  );

	// FXU Sys
	NewINS( pHB,  STSR(  5,reg, 0)->SetLabel( "read_FXU_system_registers")  );		// PSW
	NewINS( pHB,  SHR5( 18U,reg)     );
	NewINS( pHB,  BNC17P("read_basic_system_registers_end")  );
	NewINS( pHB,  STSR(  6,reg, 10)  );		// FXSR
	NewINS( pHB,  STSR(  8,reg, 10)  );		// FXST
	NewINS( pHB,  STSR(  9,reg, 10)  );		// FXINFO
	NewINS( pHB,  STSR( 10,reg, 10)  );		// FXCFG
	NewINS( pHB,  STSR( 12,reg, 10)  );		// FXXC
	NewINS( pHB,  STSR( 13,reg, 10)  );		// FXXP

	NewINS( pHB,  STSR( 15, reg, 0)->SetLabel("read_basic_system_registers_end")  );	// PSWH
	NewINS( pHB,  SHR5( 0x1F, reg));		// PSWH.GM
	NewINS( pHB,  ANDI( 0x1, reg, reg));
	NewINS( pHB,  BNZ9P("read_system_registers_end"));

	NewINS( pHB,  MOV32P( "start_read_new_SRs", reg));
	NewINS( pHB,  ANDI( 0x7c, reg+1, reg+1));
	NewINS( pHB,  ADD( reg, reg+1));	
	NewINS( pHB,  JARL32( reg+1, reg+1));

	// Read HV register in G4MH20	
	NewINS( pHB,  STSR( 18, reg, 0)->SetLabel("start_read_new_SRs") );	// EIPSWH
	NewINS( pHB,  STSR( 19, reg, 0)  );	// FEPSWH
	NewINS( pHB,  STSR( 0, reg, 3)  );	// DBGEN
	NewINS( pHB,  STSR( 16, reg, 1)  );	// HVCFG
	NewINS( pHB,  STSR( 20, reg, 1)  );	// HVSB
	NewINS( pHB,  JR22P("read_system_registers_end")  );		// Jump to the end
	NewINS( pHB,  STSR( 17, reg, 1)  );	// GMCFG
	NewINS( pHB,  STSR( 0, reg, 9)  );	// GMEIPC
	NewINS( pHB,  STSR( 1, reg, 9)  );	// GMEIPSWH
	NewINS( pHB,  STSR( 2, reg, 9)  );	// GMFEPC
	NewINS( pHB,  STSR( 3, reg, 9)  );	// GMFEPSW
	NewINS( pHB,  JR22P("read_system_registers_end")  );		// Jump to the end
	NewINS( pHB,  STSR( 5, reg, 9)  );	// GMPSW
	NewINS( pHB,  STSR( 6, reg, 9)  );	// GMMEA
	NewINS( pHB,  STSR( 8, reg, 9)  );	// GMMEI
	NewINS( pHB,  STSR( 13, reg, 9)  );	// GMEIIC
	NewINS( pHB,  STSR( 14, reg, 9)  );	// GMFEIC
	NewINS( pHB,  STSR( 30, reg, 9)  ); // GMPEID
	NewINS( pHB,  JR22P("read_system_registers_end")  );		// Jump to the end
	NewINS( pHB,  STSR( 16, reg, 9)  );	// GMSPID
	NewINS( pHB,  STSR( 17, reg, 9)  );	// GMSPIDLIST
	NewINS( pHB,  STSR( 19, reg, 9)  ); // GMEBASE
	NewINS( pHB,  STSR( 20, reg, 9)  ); // GMINTBP
	NewINS( pHB,  STSR( 21, reg, 9)  ); // GMINTCFG
	NewINS( pHB,  JR22P("read_system_registers_end")  );		// Jump to the end
	NewINS( pHB,  STSR( 22, reg, 9)  ); // GMPLMR
	NewINS( pHB,  STSR( 24, reg, 9)  ); // GMSVLOCK
	NewINS( pHB,  STSR( 25, reg, 9)  ); // GMMPM
	NewINS( pHB,  STSR( 28, reg, 9)  ); // GMEIWR
	NewINS( pHB,  STSR( 29, reg, 9)  ); // GMFEWR
	NewINS( pHB,  STSR( 30, reg, 9)  ); // GMPEID

	NewINS( pHB,  JMP32(31)->SetLabel("read_system_registers_end")); // Jump return
	return pHB;
}

CHandlerBlock* CBlockManager::GenerateWorkingAreaBlock(UI32 reg){

	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	UI32 reg3 = reg + 3;
	IInstruction* ins;
	CHandlerBlock* pHB = new CHandlerBlock("set_work_ptr");

	NewINS( pHB, ins= NOP() ) ;
	ins->AppendComment("r27= BASE_PE") ;
	NewINS( pHB, ins= NOP() ) ;
	ins->AppendComment("r28= (BASE_PE_VM + ((HTCFG0.NC) ?  8 : HTCFG0.VCID) * SIZE_VM") ;
	NewINS( pHB, ins= NOP() ) ;
	ins->AppendComment("r29= (BASE_PE_HT + ((HTCFG0.NC) ? 64 : HTCFG0.TCID) * SIZE_HT") ;
	NewINS( pHB, STSR(0,reg3,2) ) ;				// HTCFG0
	NewINS( pHB, SHR5(16,reg3) ) ;
	NewINS( pHB, BNC17P("set_work_ptr_01")) ;	//goto case_2

	//case_1: HTCFG0.NC == 1
	NewINS( pHB, MOV32(g_wm.BASE_PE,reg1)) ;
	NewINS( pHB, MOV32((g_wm.BASE_PE_VM + g_wm.SIZE_VM * g_wm.m_vmnum), reg2) ) ;
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.SIZE_HT * g_wm.m_htnum), reg3) ) ;
	NewINS( pHB, BR9P("set_work_ptr_02") );

	//case_2: HTCFG0.NC == 0
	NewINS( pHB, MOV32(g_wm.BASE_PE,reg1)->SetLabel("set_work_ptr_01") );
	NewINS( pHB, STSR(0,reg2,2) ) ;
	NewINS( pHB, SHR5(8,reg2) ) ;
	NewINS( pHB, ANDI(0x007,reg2,reg2) ) ;
	NewINS( pHB, MULHI((SI32)(SI16)(g_wm.SIZE_VM),reg2,reg2) ) ;
	NewINS( pHB, MOV32(g_wm.BASE_PE_VM,reg) ) ;
	NewINS( pHB, ADD(reg,reg2) ) ;
	NewINS( pHB, STSR(0,reg3,2) ) ;
	NewINS( pHB, ANDI(0x003f,reg3,reg3) ) ;
	NewINS( pHB, MULHI((SI32)(SI16)(g_wm.SIZE_HT),reg3,reg3) ) ;
	NewINS( pHB, MOV32(g_wm.BASE_PE_HT,reg) ) ;
	NewINS( pHB, ADD(reg,reg3) ) ;

	NewINS( pHB,  NOP()->SetLabel("set_work_ptr_02"));
	NewINS( pHB, JMP32(31) );

	return pHB;

}


/**
* @param  demand = 0: demand channel of guest mode
*         demand = 1: demand channel of host mode
*/
void CBlockManager::GenMpuHandler(TBlockConfig* pCfg, CHandlerBlock* pHB, UI32 demandIdx) {

	IInstruction * ins ;
	std::string contextStr = GetMContext(pCfg);
    const UI32 reg = m_nWorkReg;
    const UI32 reg1 = reg + 1;
    const UI32 reg2 = reg + 2;
    const UI32 reg3 = reg + 3;
    const UI32 reg4 = reg + 4;
    const UI32 regPSWH_GM = 2;

    //  Set guest management as a default value
    UI32 mip_causecode = 0x90;
    std::string label_jump = "check_mpu_exception_gm";
    std::string label = "_" + std::to_string(demandIdx);

    const UI32 demand = g_prf->m_mpdemand[demandIdx];
    // Get Reserve entry
    const UI32 mip = demand >> 16 ;
    const UI32 mdp = demand & 0x001f ;
    const UI32 mdp_as = (demand & 0x0000ffff) >> 10;      // auto save
    const UI32 mdp_rt = (demand & 0x000003ff) >> 5;       // reference table

    if (demandIdx == 1) {
        // if generate code for host management, correct the variable for suitable.
        mip_causecode = 0x98;
        label_jump = "check_mpu_exception_hm";
    }

    UI32 selId = 5;		 //selId of MPLA
	UI32 regId = 20;    //regId of MPLA

    NewINS(pHB, STSR(8, reg2, 2)->SetLabel(contextStr + label_jump));           // MEI
    NewINS(pHB, STSR(6, reg3, 2));           // MEA
     
    if (demandIdx == 1) {
        // If current mode is guest mode (SV privilege), insert HVTRAP 0x1e. So that change mode to host mode (HV privilege)
        NewINS(pHB, STSR(15, regPSWH_GM, 0));    // PSWH
        NewINS(pHB, SHR5(0x1f, regPSWH_GM));     // PSWH.GM
        NewINS(pHB, BZ9P(contextStr + "check_mip_exception_hm" ));
        NewINS(pHB, HVTRAP(0x1e));
        NewINS(pHB, NOP()->SetLabel(contextStr + "check_mip_exception_hm" ));
    }

    NewINS(pHB, STSR(8, reg4, 1));			// Save SVLOCK
    NewINS(pHB, LDSR(0, 8, 1));				// Disable SV lock	

    NewINS(pHB, SATSUBI(mip_causecode, reg, reg1));
    NewINS(pHB, BNZ9P(contextStr + "check_mdp_exception" + label));

    //Calculate memory protect area - mask is 0x3FF
    NewINS(pHB, ANDI(0x3FF, reg3, reg));
    NewINS(pHB, CMP5(0xF, reg));          // minimum fetch size is 0x10 byte
    NewINS(pHB, BH9P(contextStr + "Select_Protect_Area_Done" + label));
    NewINS(pHB, MOV32(0x10, reg)); 
    NewINS(pHB, NOP()->SetLabel(contextStr + "Select_Protect_Area_Done" + label));

    // [Protect for MIP exception]
    NewINS(pHB,  MOV5(mip, reg1));
	NewINS(pHB,  LDSR(reg1, 16, 5));	                  // MPIDX
	NewINS(pHB,  LDSR(reg3, regId, selId) );	              // MPLAy= MEA
	NewINS(pHB,  ADD(reg3, reg) );
	NewINS(pHB,  LDSR(reg, regId+1, selId) );	          // MPUAy= MEA + reg1
	NewINS(pHB,  ORI(0x40ad, 0, reg) );
	NewINS(pHB,  LDSR(reg, regId+2, selId) );	          // MPATy= 0x000040ad
    if (demandIdx == 1) {
        NewINS(pHB, JR22P(contextStr + "checking_change_mode"));
    } else {
        NewINS(pHB, JR22P(contextStr + "the_end_mpu_handler"));
    }

	// Check MDP exception
    NewINS(pHB, MOVR(reg2, reg)->SetLabel(contextStr + "check_mdp_exception" + label));            // reg = MEI 
    NewINS(pHB, ANDI(0x3e, reg, reg));              // MEI.ITYPE   

    NewINS(pHB, SATSUBI(0x2A, reg, reg2));         // 101010b: table reference
    NewINS(pHB, MOV5(mdp_rt, reg1));
    NewINS(pHB, MOV5(4, reg2));
    NewINS(pHB, BZ9P(contextStr + "mdp_handler" + label));

    NewINS(pHB, SATSUBI(0x2CU, reg, reg2));        // 101100b: register bank, auto save
    NewINS(pHB, MOV5(mdp_as, reg1));
    NewINS(pHB, MOV32(0x90U, reg2));              // Maximum bank size = 0x90                                             
    NewINS(pHB, BZ9P(contextStr + "mdp_handler" + label));

    NewINS(pHB, MOV5(mdp, reg1));

    if (demandIdx == 1) {
        NewINS(pHB, SATSUBI(0x1C, reg, reg2));           // 011100b: STM.GSR/LDM.GSR 
        NewINS(pHB, MOV32(0x94U, reg2));                // 0x94 = 37 * 4 (37 system register)
        NewINS(pHB, BZ9P(contextStr + "mdp_handler" + label));
    }

    NewINS(pHB, SATSUBI(0x1E, reg, reg2));           // 011100b: STM.MP/LDM.MP 
    NewINS(pHB, MOV32(0x180U, reg2));                // 0x180 = 32 * 3 * 4 (32 entry, each entry has 3 register)
    NewINS(pHB, BZ9P(contextStr + "mdp_handler" + label));

    NewINS(pHB, SATSUBI(0x1AU, reg, reg2));          // 011010b: PUSH/POP 
    NewINS(pHB, MOV32(0x80, reg2));                  // 0x80 = 32 * 4 (32 genereal-register) 
    NewINS(pHB, BZ9P(contextStr + "mdp_handler" + label));        // normal instruction
    NewINS(pHB, MOV32(0x30, reg2));                  // 0x30 = 12 * 4 (dispose, prepare use list 12)

    // [Protect for MDP exception]
    NewINS(pHB, LDSR(reg1, 16, 5)->SetLabel(contextStr + "mdp_handler" + label));	// MPIDX
    NewINS(pHB, SATSUBR3(reg2, reg3, reg1));     // reg3 = MEA	 
    NewINS(pHB, BNL9P(contextStr + "assigned_mpla" + label));
    NewINS(pHB, MOV5(0, reg1));
    NewINS(pHB, LDSR(reg1, regId, selId)->SetLabel(contextStr + "assigned_mpla" + label));    	// MPLAx = MEA - reg2
    NewINS(pHB, ADD(reg3, reg2));
    NewINS(pHB, LDSR(reg2, regId + 1, selId));	// MPUAx = MEA + reg2
    NewINS(pHB, ORI(0xc09b, 0, reg1));
    NewINS(pHB, LDSR(reg1, regId + 2, selId));	// MPATy= 0x0000c09b

    NewINS(pHB, LDSR(reg4, 8, 1));				// Restore SV lock

    if (demandIdx == 0) {
        NewINS(pHB, JR22P(contextStr + "the_end_mpu_handler")); 
    } else {
        // return mode to mode which before calling HVTRAP 0x1e
        NewINS(pHB, CMPR(0, regPSWH_GM)->SetLabel(contextStr + "checking_change_mode"));     // PSWH.GM
        NewINS(pHB, BZ9P(contextStr + "the_end_mpu_handler"));
        NewINS(pHB, STSR(18, reg, 0));      // EIPSWH
        NewINS(pHB, MOV32(0x80000000, reg1));
        NewINS(pHB, OR(reg1, reg));
        NewINS(pHB, LDSR(reg, 18, 0));     // Set EIPSWH
        NewINS(pHB, MOV32P(contextStr + "the_end_mpu_handler", reg));
        NewINS(pHB, LDSR(reg, 0, 0));     // Set EIPC
        NewINS(pHB, EIRET());
        UI32 newMPIDx = g_hwInfo.m_mpnum - 1;
        while (g_prf->IsWorkMPURegionByIdx(newMPIDx)) {
            newMPIDx = g_rnd.GetRange((UI32)0, (UI32)g_hwInfo.m_mpnum - 1);
        }
        NewINS(pHB, MOV32(newMPIDx, reg)->SetLabel(contextStr + "the_end_mpu_handler"));
        NewINS(pHB, LDSR(reg, 16, 5));

        NewINS(pHB, POPSP(1, 31));
        NewINS(pHB, MOVR(m_nHandlerReg, 3));
        NewINS(pHB, ins = STSR(29, m_nHandlerReg, 0)); ins->AppendComment("r3= FEWR ; recover");
        NewINS(pHB, FERET());
        NewINS(pHB, NOP());
        NewINS(pHB, NOP());
    }
}


void CBlockManager::GenMmuHandler (TBlockConfig* pCfg , CHandlerBlock* pHB , UI32 reg) {

	IInstruction * ins ;
	std::string contextStr = GetMContext(pCfg);
	char str[120] ;
		
	//!・・ITLBE/DTLBEハンドラはＭＭＵ搭載時のみ生成
	//[ ITLBE判定 ]
	NewINS( pHB,  CMP5(2U,reg));
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_50"));		// BNE
	
	//ITLBE例外処理
	NewINS( pHB,  STSR( 14,reg, 0) );			// FEIC
	NewINS( pHB,  SHR5(16, reg) );
	NewINS( pHB,  ANDI(0x0100, reg ,0) ); 		// if (FEIC.NP == 1) then Goto __fix_mp_handler_30
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_30") );
	NewINS( pHB,  ANDI(0x0040, reg ,0) ); 		// if (FEIC.V  == 0) then Goto __fix_mp_handler_40  ;TLB不一致違反
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_40") );
	NewINS( pHB,  ANDI(0x0200, reg ,0) ); 		// if (FEIC.ME == 1) then Goto __fix_mp_handler_40  ;TLB多重一致違反
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_40") );
	//!・・・ITLBE例外TLB特権違反の処理
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  JR22P( contextStr + "fix_mp_handler_42"));
	//__fix_mp_handler_30:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_30"));
	NewINS( pHB,  ANDI(0x0200, reg ,0) ); 		// if (FEIC.ME == 1) then Goto __fix_mp_handler_40  ;TLB次ページ多重一致違反
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_40"));
	NewINS( pHB,  ANDI(0x0040, reg ,0) ); 		// if (FEIC.V  == 0) then Goto __fix_mp_handler_32
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_32"));
	//ITLBE例外TLB次ページ特権違反の処理
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA + 8
	NewINS( pHB,  ADDI(0x0008, reg ,0) );
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  JR22P( contextStr + "fix_mp_handler_40"));
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
	//!・・・ITLBE例外TLB次ページ不一致違反の処理
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_32"));
	NewINS(pHB, MOV32P("set_work_ptr", reg) );
	NewINS(pHB, JARL32(reg, reg+1) );

	NewINS( pHB,  LDW16(g_wm.OFS_ITLB_INFO, 29, reg) );
	NewINS( pHB,  CMP5((-1),reg) );
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_38"));
	{
		//空きエントリ探査
		UI32 start= reg + 1 ;
		UI32 index= reg + 2 ;
		//TODO: startは乱数で決める
		NewINS( pHB,  MOV5(1, start) );
		NewINS( pHB,  MOVR(start, index) );
		//__fix_mp_handler_34:
		// index値でエントリー読み出し
		NewINS( pHB,  LDSR(index, 0, 4)->SetLabel(contextStr + "fix_mp_handler_34"));
		NewINS( pHB,  TLBR() );
		// if ((TEHI1.V == 0)&&(TEHI1.L == 0)) then Goto __fix_mp_handler_37  ; 空きエントリー発見
		NewINS( pHB,  STSR(7, reg, 4) );
		NewINS( pHB,  SHR5(30, reg) );
		NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_37"));	
		// index= index % (TLBCFG + 1)
		NewINS( pHB,  ADD5(1, index) );
		NewINS( pHB,  STSR(10, reg, 4) );
		NewINS( pHB,  ADD5(1, reg) );
		NewINS( pHB,  DIVHW(reg, index, index) );
		// if (start != index) then Goto __fix_mp_handler_34
		NewINS( pHB,  CMPR(start, index) );
		NewINS( pHB,  BNE17P(contextStr + "fix_mp_handler_34"));
		//TODO: 全エントリーが使用中だった場合の処理(不要エントリーを開放する)
		NewINS( pHB,  HALT() );
		NewINS( pHB,  NOP() );
		NewINS( pHB,  NOP() );
		//__fix_mp_handler_37:
		NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_37"));
		NewINS( pHB,  STW16(reg ,g_wm.OFS_ITLB_INFO ,29) );
	}
	//__fix_mp_handler_38:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_38"));
	//該当エントリーを検索して読み取り
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA + 10
	NewINS( pHB,  ADDI(0x10, reg, reg) );
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  STSR(7, reg, 2) );			// TEHI1= f(HTCFG0 ,ASID) 
	NewINS( pHB,  ANDI(0x00ff, reg ,0) ); 
	NewINS( pHB,  STSR(0, reg+1, 2) );
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBS() );
	NewINS( pHB,  STSR(0, reg+1, 4) );			// GR[reg+1]= TLBIDX   (dummy read)
	NewINS( pHB,  TLBR() );
	// GR[reg+2]= 1 << (TEHI0.PGSIZE + 10)
	// TEHI0 += GR[reg+2] ;
	// TELO0= (TELO0 + GR[reg2]) | 0x3f ;
	// TELO1= 0 ;
	NewINS( pHB,  STSR(6, reg, 4) );
	NewINS( pHB,  ANDI(0x001f, reg ,reg+1) );
	NewINS( pHB,  ADD5(10, reg+1 ) );
	NewINS( pHB,  MOV5(1, reg+2 ) );
	NewINS( pHB,  SHL(reg+1, reg+2) );
	NewINS( pHB,  ADD(reg+2, reg ) );
	NewINS( pHB,  LDSR(reg, 6, 4) );			
	NewINS( pHB,  STSR(4, reg, 4) );
	NewINS( pHB,  ADD(reg+2, reg ) );
	NewINS( pHB,  ORI(0x003f, reg ,reg) );
	NewINS( pHB,  LDSR(reg, 4, 4) );			
	NewINS( pHB,  LDSR(0, 5, 4) );				
	// TEHI1.VM= ~HTCFG0.NC ;
	// TEHI1.VCID= ~HTCFG0.VCID ;
	// TEHI1.V= 1 ;
	// TEHI1.L= 1 ;
	// TEHI1.G= 1 ;
	// TEHI1.ASID= 0x222 ;
	// TEHI1.HVC= 0 ;
	NewINS( pHB,  STSR(0, reg+1, 2) );				//HTCFG0
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  MOV32(0xc0100222 , reg+1) );
	NewINS( pHB,  OR(reg+1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	// エントリー書き込み
	NewINS( pHB,  LDW16(g_wm.OFS_ITLB_INFO ,29 ,reg) );
	NewINS( pHB,  LDSR(reg, 0, 4) );				// TLBIDX= reg
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_mp_handler_40:
	//!・・・ITLBE例外TLB不一致違反、TLB多重一致違反の処理
	NewINS( pHB,  NOP()->SetLabel(  contextStr + "fix_mp_handler_40"));
	//===========================================
	//!・・・・jarlブロックの呼び元への強制リターン処理
	//===========================================
	NewINS( pHB,  LDSR(31,2,0) );					// FEPC <- r31
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_mp_handler_42:
	//!・・・ITLBE例外TLB特権違反、TLB次ページ特権違反の処理
	//（TEHI0にMEA値をセットしてからここへjump )
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_42"));
	//!・・・・MEA値をもとにTLBS命令で該当エントリーを探査し、そのエントリーに必要な特権を付与
	NewINS( pHB,  STSR(7, reg, 2) );			// TEHI1= f(HTCFG0 ,ASID) 
	NewINS( pHB,  ANDI(0x00ff, reg ,0) ); 
	NewINS( pHB,  STSR(0, reg+1, 2) );
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBS() );
	NewINS( pHB,  STSR(0, reg+1, 4) );			// reg+1= TLBIDX   (dummy read)
	//
	NewINS( pHB,  TLBR() );
	NewINS( pHB,  STSR(4, reg+1, 4) );			// TELO1.PRIV |= FEIC[21:16]
	NewINS( pHB,  OR(reg+1,reg) );
	NewINS( pHB,  LDSR(reg, 4, 4) );
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );


	//[ DTLBE判定 ]
//__fix_mp_handler_50:
	NewINS( pHB,  CMP5(3U,reg)->SetLabel( contextStr + "fix_mp_handler_50"));
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_60"));		// BNE

	//DTLBE例外処理
	NewINS( pHB,  STSR( 14,reg, 0) );			// FEIC
	NewINS( pHB,  SHR5(16, reg) );
	NewINS( pHB,  ANDI(0x0100, reg ,0) ); 		// if (FEIC.PB == 1) then Goto __fepcInc Else Goto __fix_mp_handler_51
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_51"));
	//!・・・DTLBE例外TLBページ境界違反の処理<BR>
	//!・・・・FEPCを書き換えて、例外を発生した次の命令にFERET
	NewINS( pHB,  MOV32P( contextStr + "fepcInc", reg));
	NewINS( pHB,  JMP32(reg) );
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );	
//__fix_mp_handler_51:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_51" ));
	NewINS( pHB,  ANDI(0x0040, reg ,0) ); 		// if (FEIC.V  == 0) then Goto __fix_mp_handler_55
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_55" ));
//==== MEA値をもとにTLBS命令で該当エントリーを検索
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  STSR(7, reg, 2) );			// TEHI1= f(HTCFG0 ,ASID) 
	NewINS( pHB,  ANDI(0x00ff, reg ,0) ); 
	NewINS( pHB,  STSR(0, reg+1, 2) );
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBS() );
	NewINS( pHB,  STSR(0, reg+1, 4) );			// reg+1= TLBIDX   (dummy read)
//====
	NewINS( pHB,  STSR(14,reg, 0) );			// FEIC
	NewINS( pHB,  SHR5(16, reg) );
	NewINS( pHB,  ANDI(0x0200, reg ,0) ); 		// if (FEIC.ME == 1) then Goto __fepcInc Else __fix_mp_handler_52
	NewINS( pHB,  BE17P ( contextStr + "fix_mp_handler_52") );
	//!・・・DTLBE例外DTLB多重違反の処理<BR>
	//!・・・・MEA値をもとにTLBS命令で該当エントリーを検索し、見つかったエントリーを無効化
	NewINS( pHB,  TLBR() );
	NewINS( pHB,  STSR(7, reg, 4) );			// TEHI1.V= 0
	NewINS( pHB,  BINS(0 ,31 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
//__fix_mp_handler_52:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_52" ));
	NewINS( pHB,  ANDI(0x003f, reg ,reg) ); 
	//!・・・DTLBE例外TLB特権違反の処理<BR>
	//!・・・・・MEA値をもとにTLBS命令で該当エントリーを探査し、そのエントリーに必要な特権を付与
	NewINS( pHB,  TLBR() );
	NewINS( pHB,  STSR(4, reg+1, 4) );			// TELO1.PRIV |= FEIC[21:16]
	NewINS( pHB,  OR(reg+1,reg) );
	NewINS( pHB,  LDSR(reg, 4, 4) );
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
//__fix_mp_handler_55:
	//!・・・DTLBE例外TLB不一致違反の処理<BR>
	//!・・・・８つあるデマンドページング用のエントリーのうちの１つを、最小ページサイズでMEA値を含むように充てる。
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_55"));
	NewINS(pHB, MOV32P("set_work_ptr", reg) );
	NewINS(pHB, JARL32(reg, reg+1) );
	// TLBIDX= (r27 + g_wm.OFS_DTLB_INFO + 4)[g_wm.OFS_DTLB_INFO[r27] * 2] ;
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO ,27 ,reg ) );
	NewINS( pHB,  SHL5(1, reg) );
	NewINS( pHB,  ADD(27, reg) );
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO+4 ,reg ,reg) );
	NewINS( pHB,  LDSR(reg, 0, 4) );
	//OFS_DTLB_INFO[r27]= (OFS_DTLB_INFO[r27] + 1) % (OFS_DTLB_INFO+2)[r27] ;
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO+0 ,27 ,reg   ) );
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO+2 ,27 ,reg+1 ) );
	NewINS( pHB,  ADD5(1, reg) );
	NewINS( pHB,  CMPR(reg,reg+1));
	NewINS( pHB,  CMOV5(2 ,0, reg ,reg) );
	NewINS( pHB,  STH16(reg ,g_wm.OFS_DTLB_INFO ,27) );
	//エントリー読み込み
	NewINS( pHB,  TLBR() );
	// TEHI0= MEA & 0xFFFFFC00 ;
	// TELO1= 0 ;
	// TEHI1.VM= ~HTCFG0.NC ;
	// TEHI1.VCID= ~HTCFG0.VCID ;
	// TEHI1.V= 1 ;
	// TEHI1.L= 1 ;
	// TEHI1.G= 0 ;
	// TEHI1.ASID= ASID ;
	// TEHI1.HVC= 0 ;
	NewINS( pHB,  STSR(6, reg, 2) );				// MEA
	NewINS( pHB,  BINS(0 ,0 ,10 ,reg) );
	NewINS( pHB,  LDSR(reg, 6, 4) );			
	NewINS( pHB,  LDSR(0, 5, 4) );					// TEHI0
	NewINS( pHB,  STSR(0, reg+1, 2) );				// HTCFG0
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  MOVR(0, reg) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  MOV32(0xc0000000 , reg+1) );
	NewINS( pHB,  OR(reg+1, reg) );
	NewINS( pHB,  STSR(7, reg+1, 2) );				// ASID
	NewINS( pHB,  OR(reg+1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );				// TEHI1
	// エントリー書き込み
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_mp_handler_60:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_60"));
}


std::vector<CHandlerBlock*>* CBlockManager::GenerateHandler(TBlockConfig* pCfg) {
	//!<BR>[処理細目]<BR>

	UI32 reg = m_nWorkReg;
	UI32 jump_reg = m_nHandlerReg;
	
	std::vector<CHandlerBlock*>* vNode = new std::vector<CHandlerBlock*>();
	CHandlerBlock* pHB = nullptr;
	IInstruction * ins ;
	IInstruction * regins;
	
	std::string contextStr = GetModeContext(pCfg);
	std::string lable;
	UI32 machine = (pCfg->m_bNC) ? 0x1 : 0;

	//Lamda function to generate handler label base on address
	auto GetHandlerInfor = [&] (UI32 addr) -> std::pair<std::string, UI32 > {
		std::pair<std::string, UI32 > vExpInfo;
		std::string label = "_handler";
		UI32 level = IExceptionConfig::EXP_LEVEL_NONE;
		// Convert address -> string.
		switch (addr) {
		case ADR_VECTOR_SYSERR:	
			label = "syserr" + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_HVTRAP:
			label = "hvtrap" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_FETRAP:
			label = "fetrap" + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_TRAP0:
			label = "trap0"  + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_TRAP1:
			label = "trap1"  + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_RIE:
			label = "rie"    + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_FPPFPI:
			label = "fpp"    + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_UCPOP:
			label = "ucpop"  + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_MPUMMU:
			label = "mp"    + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_PIE:
			label = "pie"    + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_DEBUG:
			label = "debug"  + label;
			level = IExceptionConfig::EXP_LEVEL_DB;
			break;

		case ADR_VECTOR_MAE:
			label = "mae"    + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_BGINT:
			label = "bgint"  + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_FENMI:
			label = "fenmi"  + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_FEINT:
			label = "feint"  + label;
			level = IExceptionConfig::EXP_LEVEL_FE;
			break;

		case ADR_VECTOR_EIINT000:
			label = "eiint000" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT001:
			label = "eiint001" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT002:
			label = "eiint002" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT003:
			label = "eiint003" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT004:
			label = "eiint004" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT005:
			label = "eiint005" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT006:
			label = "eiint006" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT007:
			label = "eiint007" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT008:
			label = "eiint008" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT009:
			label = "eiint009" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT010:
			label = "eiint010" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT011:
			label = "eiint011" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
		    break;

		case ADR_VECTOR_EIINT012:
			label = "eiint012" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT013:
			label = "eiint013" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT014:
			label = "eiint014" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		case ADR_VECTOR_EIINT015:
			label = "eiint015" + label;
			level = IExceptionConfig::EXP_LEVEL_EI;
			break;

		default:
			label = "";
			level = IExceptionConfig::EXP_LEVEL_NONE;
			break;
		}
			
		vExpInfo = std::pair<std::string, UI32 >(label, level);
		
		return vExpInfo;
	};

	// Lamda function to generate a handler
	// Set Addr, level, SetOutputFlag
	auto GenerateHandlerTop = [&](UI32 addr) -> CHandlerBlock* {
		std::pair<std::string, UI32 > vExpInformation = GetHandlerInfor(addr);
		std::string label = vExpInformation.first;
		if (addr != ADR_VECTOR_HVTRAP && addr != ADR_VECTOR_DEBUG && addr != ADR_VECTOR_FENMI)
			label = contextStr + label;
		UI32 level = vExpInformation.second;
		CHandlerBlock* pHandlerBlock = new CHandlerBlock(label);
		pHandlerBlock->SetOutputFlag(true);
		pHandlerBlock->SetHandlerAddress(machine | addr);
		pHandlerBlock->SetExceptionLevel(level);
		if(addr == ADR_VECTOR_TRAP1 || (addr == ADR_VECTOR_FETRAP && m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV) > 0))
			ChangePrivilege(pHandlerBlock, reg, pCfg);
		return pHandlerBlock;
	};

	// Generate a chain of handler block
	for(UI32 i = ADR_VECTOR_SYSERR; i < ADR_VECTOR_NUM; i += 0x10) {
		
		// EXCEPTION using 1 handler by EBASE
		if(pCfg->m_bNC == false && (i == ADR_VECTOR_HVTRAP || i == ADR_VECTOR_DEBUG || i == ADR_VECTOR_BGINT || i == ADR_VECTOR_FENMI)) continue;

		pHB = GenerateHandlerTop(i);
		// Additional code for each handler
		if(i == ADR_VECTOR_SYSERR) {
			SaveRegisterFE(pHB, contextStr + "syserr_handler") ;
			LoadSregOfException(pHB, reg, contextStr + "syserr", pCfg) ;
			// Fix handler for syserr
			// Check cause code
			pHB = GenFixSyserrHandler(pCfg, pHB);
			pHB->SetOutputFlag(true);
		}

		if(i == ADR_VECTOR_DEBUG) {
			pHB = GenFixDeBugHandler(reg, "debug_handler", pCfg);
		}
		
		if(i == ADR_VECTOR_HVTRAP) {
			pHB = GenerateHVTRAPHandler(pCfg, "hvtrap_handler");
			pHB->SetOutputFlag(true);	
		}

		if(i == ADR_VECTOR_TRAP0 || i == ADR_VECTOR_TRAP1) {
			NewINS( pHB, (regins = MOV32P(contextStr + "fix_ei_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );
			regins->SetRegulationTarget(ins);
		}

		if(i == ADR_VECTOR_MPUMMU){
			SaveRegisterFE(pHB, contextStr+ "fix_mp_handler") ;
			LoadSregOfException(pHB, reg, contextStr+ "fix_mp", pCfg) ;
			NewINS( pHB, (regins = MOV32P("fix_mp_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );
			regins->SetRegulationTarget(ins);
		}
	
		if(i == ADR_VECTOR_BGINT) {
			pHB = GenerateBGINTHandler(pCfg, "bgint_handler");
			pHB->SetOutputFlag(true);	
		}

		if(i == ADR_VECTOR_MAE || i == ADR_VECTOR_RIE || i == ADR_VECTOR_UCPOP || i == ADR_VECTOR_PIE ){
			NewINS( pHB, (regins = MOV32P(contextStr + "fe_PcInc_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );	
			regins->SetRegulationTarget(ins);
		}

		if(i == ADR_VECTOR_FETRAP) {
			NewINS( pHB, (regins = MOV32P(contextStr + "fix_fetrap_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );
			regins->SetRegulationTarget(ins);
		}

		if(i == ADR_VECTOR_FENMI || i == ADR_VECTOR_FEINT) {
			NewINS( pHB, (regins = MOV32P(contextStr + "fix_fe_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );
			regins->SetRegulationTarget(ins);
		}

		if(i >= ADR_VECTOR_EIINT000 && i <= ADR_VECTOR_EIINT015) {
			NewINS( pHB, (regins = MOV32P(contextStr + "fix_ei_interrupt_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );
			regins->SetRegulationTarget(ins);
		}

		if(i == ADR_VECTOR_FPPFPI){
			NewINS( pHB, (regins = MOV32P(contextStr + "ei_PcInc_handler", jump_reg)) );
			NewINS( pHB, (ins = JMP32(jump_reg)) );
			regins->SetRegulationTarget(ins);
		}

		vNode->push_back(pHB);
	}

	// This block was used for EXP using EIPC value for return PC
	pHB = new CHandlerBlock(contextStr + "fix_ei_handler");
	pHB->SetOutputFlag(true);
	SaveRegisterEI(pHB, contextStr + "fix_ei_handler") ;
	LoadSregOfException(pHB, reg, contextStr + "ei_fix", pCfg) ;
	NewINS( pHB,  POPSP(1, 31)) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
    NewINS(pHB,   STSR(28, m_nHandlerReg, 0)->SetLabel(contextStr + "change_mode_end"));
	NewINS( pHB,  EIRET()) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
	vNode->push_back(pHB);

	// This block was used for EXP must be increase EIPC value for return PC(FPP)
	pHB = new CHandlerBlock( contextStr + "ei_PcInc_handler");
	pHB->SetOutputFlag(true);
	SaveRegisterEI(pHB, contextStr + "ei_PcInc_handler") ;
	LoadSregOfException(pHB, reg, contextStr + "ei_PcInc", pCfg) ;
	NewINS( pHB, (regins = MOV32P("Handler_calculate_PC_revert_GRs_ei", jump_reg)) );
	NewINS( pHB, (ins = JMP32(jump_reg)) );
	regins->SetRegulationTarget(ins);
	vNode->push_back(pHB);

	// This block was used for EXP using FEPC value for return PC(FEINT, FEMNI..)
	pHB = GenerateFEInterrupHandler(pCfg, contextStr + "fix_fe_handler");
	vNode->push_back(pHB);

	// This block was used for EXP using FEPC value for return PC(FEINT, FEMNI..)
	pHB = new CHandlerBlock( contextStr + "fix_fetrap_handler");
	pHB->SetOutputFlag(true);
	SaveRegisterFE(pHB, contextStr + "fix_fetrap_handler") ;
	LoadSregOfException(pHB, reg, contextStr + "fix_fetrap", pCfg) ;
	NewINS( pHB,  POPSP(1,31)) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
    ins->AppendComment("r3= FEWR ; recover");
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );					// NOP
	NewINS( pHB,  NOP() );					// NOP
	vNode->push_back(pHB);

	// This block was used for EXP must be increase FEPC value for return PC(PIE, RIE...)
	pHB = new CHandlerBlock( contextStr + "fe_PcInc_handler");
	pHB->SetOutputFlag(true);
	SaveRegisterFE(pHB, contextStr + "fe_PcInc_handler") ;
	LoadSregOfException(pHB, reg, contextStr + "fe_PcInc", pCfg) ;
	NewINS( pHB, (regins = MOV32P("Handler_calculate_PC_revert_GRs_fe", jump_reg)) );
	NewINS( pHB, (ins = JMP32(jump_reg)) );
	regins->SetRegulationTarget(ins);
	vNode->push_back(pHB);

	// This block was used for EI interrupt 
	// Checking MDP at auto save
	// Checking auto save
	pHB = GenEIInterruptHandler(reg, contextStr + "fix_ei_interrupt_handler", pCfg);
	vNode->push_back(pHB);

	return vNode;
}


CHandlerBlock* CBlockManager::GenerateFEInterrupHandler(TBlockConfig* pCfg, std::string label) {
	CHandlerBlock* pHB = new CHandlerBlock(label);
	UI32 reg = m_nWorkReg;
	UI32 addr = 0;
	const UI32 SP = 3;
	UI32 reg1 = reg + 1;
	pHB->SetOutputFlag(true);
	pHB->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_FE);
	// Backup register
	NewINS( pHB, MOVR(3, m_nHandlerReg));
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.OFS_SAVE_FE + g_wm.SIZ_SAVE_FE), SP) ) ;
	// Change VM checking sequence
	if(g_cfg->m_mGMs.size() > 1) {
		// Back up reg. This register use to calculate address	
		NewINS( pHB, STW16(reg, 0x0, SP));
		if(pCfg->m_bNC) {
			addr = g_wm.EXP_INT_TO_HOST_BACKUP_PC;
			//Check FEINT/FENMI in HV or SV. If HV does not change VM
			NewINS( pHB, STSR (19, reg, 0));
			NewINS( pHB, SHR5 (0x1f, reg));
			NewINS( pHB, CMPR (0, reg));
			NewINS( pHB, BZ9P (label + "_nomarl_sequence"));
			// Tranfer FEWR -> GMFEWR to store by stm.gsr
			NewINS( pHB, STSR (29, reg, 0));
			NewINS( pHB, LDSR (reg, 29, 9));
			// Tranfer FEPSW -> GMFEPSW to store by stm.gsr
			NewINS( pHB, STSR (3, reg, 0));
			NewINS( pHB, LDSR (reg, 3, 9));
			NewINS( pHB, BR9P(label + "_interrupt_switch_VM"));
		} else {
			// Get next GPID by HVSB (HVSB[3] = 1, HVSB[2:0] = GPID) for VM switching
            NewINS(pHB, STSR(20, reg, 1));
            NewINS(pHB, SHR5(0x4, reg));
            NewINS(pHB, BC9P(label + "_interrupt_switch_VM"));
		}
		// Restore backup reg
		NewINS( pHB, LDW16(0x0, SP, reg)->SetLabel(label + "_nomarl_sequence"));		
	}
	NewINS( pHB, PUSHSP(1, 31));
	LoadSregOfException(pHB, reg, label, pCfg) ;
	NewINS( pHB, JR22P(label + "_restore_sequence"));


	/**********   START interrupt change virtual machine code   ************/
	// Calculate address for backup
	NewINS( pHB, STSR (15, reg, 0)->SetLabel(label + "_interrupt_switch_VM"));      //PSWH
	// Calculate address for back up GRs. reg = current PSWH	
	NewINS( pHB, SHR5 (0x8, reg));
    NewINS( pHB, ANDI (0x7, reg, reg));
	NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;
	NewINS( pHB, MULHI(660, reg, reg)); //backupReg = current GPID*660
	NewINS( pHB, ADD  (reg, SP));
	NewINS( pHB, ADDI (660, SP, SP)); 
	// Restore reg. This register use to calculate address
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.OFS_SAVE_FE + g_wm.SIZ_SAVE_FE), reg) ) ;
	NewINS( pHB, LDW16(0x0, reg, reg));
	NewINS( pHB, PUSHSP(1, 31));
	LoadSregOfException(pHB, reg, label + "_in_HV", pCfg) ;
	// Read HVSB to determine BGINT request in other VM 
	// VM accept as GMFEINT 
	// Need switching to original VM
	if (pCfg->m_bNC == false) { // GMFEINT
		pHB = GuestINTSwitchVM (pHB, reg1);
	} else {
		// Jump to change machine block
		NewINS( pHB, MOV32P("Random_next_GPID", reg));
		NewINS( pHB, JARL32(reg, reg + 3));
		// Read HVSB to determine whether changing VM
		NewINS( pHB, STSR (20, reg, 1));
		NewINS( pHB, ANDI (0xf, reg, reg1));
		NewINS( pHB, SHR5 (0x5, reg));
		NewINS( pHB, BNC17P (label + "_restore_sequence"));
		// Clear HVSB[4]
		NewINS( pHB, LDSR (reg1, 20, 1));
		NewINS( pHB, STSR (15, reg, 0));
		NewINS( pHB, SHR5 (0x8, reg));
		NewINS( pHB, ANDI (0x7, reg, reg));
		NewINS( pHB, MULHI(4, reg, reg)); //reg = current GPID * 4
		NewINS( pHB, MOV32 (addr, SP));
		NewINS( pHB, ADD  (reg, SP));
		// 1. Back up PC
		NewINS( pHB, STSR (2, reg, 0));
		NewINS( pHB, STW16 (reg, 0x0, SP));
		// Update new PC => FEPC
		NewINS( pHB, MOV32P(label + "_to_get_PC", reg));
		NewINS( pHB, LDSR (reg, 2, 0));
		// Backup FEPSW=>GMEIPSW
        NewINS( pHB, STSR (3, reg, 0));
        NewINS( pHB, LDSR (reg, 3, 9));

		NewINS( pHB, MOV32P("Change_virtual_machine_FE", reg));
		NewINS( pHB, JMP32(reg));

		// Tranfer GMFEWR -> FEWR to store by stm.gsr
		NewINS( pHB, STSR (29, reg, 9)->SetLabel(label + "_to_get_PC"));
		NewINS( pHB, LDSR (reg, 29, 0));
		// Tranfer GMFEPSW -> FEPSW to store by stm.gsr
		NewINS( pHB, STSR (3, reg, 9));
		NewINS( pHB, LDSR (reg, 3, 0));
		// Get next GPID from PSWH
		NewINS( pHB, MOV32 (addr, reg));
		NewINS( pHB, STSR (15, reg1, 0));
		NewINS( pHB, SHR5 (0x8, reg1));// backupReg = GPID
		NewINS (pHB, ANDI (0x7, reg1, reg1));
		NewINS( pHB, MULHI(4, reg1, SP)); //SP = current GPID*4
		NewINS( pHB, ADD  (SP, reg));
		NewINS( pHB, LDW16 (0x0, reg, SP));
		// Restore FEPC
		NewINS( pHB, LDSR (SP, 2, 0));
		// Update FEPSWH.GM bit
		NewINS( pHB, STSR(19, reg, 0) );
		NewINS( pHB, MOV32(0x80000000, SP) );
		NewINS( pHB, OR(SP, reg) );
		NewINS( pHB, LDSR(reg, 19, 0) );
		// Calculate address for back up GRs. backupReg = GPID *4
		NewINS( pHB, MULHI(660, reg1, reg1)); //backupReg = current GPID*660
		NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;

		NewINS( pHB, ADD (reg1, SP));
		NewINS( pHB, ADDI (536, SP, SP));
	}
	
	// Interrupt does not switch VM
	NewINS( pHB,  POPSP(1,31)->SetLabel(label + "_restore_sequence")) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB,  STSR(29,m_nHandlerReg, 0) ) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );					// NOP
	NewINS( pHB,  NOP() );					// NOP
	return pHB;
}

CHandlerBlock* CBlockManager::UpdateBGINTRequest(TBlockConfig* pCfg, std::string label) {
	UI32 reg = m_nWorkReg;
	UI32 reg1 = reg + 1;
	const UI32 SP = 3;
	IInstruction * pIns = nullptr;
	CHandlerBlock* pHB = new CHandlerBlock(label);
	pHB->SetOutputFlag(true);
	pHB->SetHandlerAddress( ADR_VECTOR_BGINT);
	pHB->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_EI);

	auto CreateIntLabel = [=](UI32 gpid, IExceptionConfig::EXP_LEVEL level)-> CAsyncLabel *{
		IExceptionConfig* pExpCfg ;
		CAsyncLabel *pLabel = nullptr;
		if (level == IExceptionConfig::EXP_LEVEL_FE) {
			pExpCfg = g_exp->GetConfigByCode(0x00d800)[0]; // BGFEINT
			if (pExpCfg == nullptr)	pExpCfg = g_exp->GetConfigByCode(0x00d000)[0];// BGEIINT
			
			pLabel = new CAsyncLabel("gmfeint", GetTContext(pCfg), m_nAsyncCount, true, 1000);
			pLabel->m_nEventId = IException::EXP_GMFEINT;
		} else {
			pExpCfg = g_exp->GetConfigByCode(0x00d000)[0];// BGEIINT
			if (pExpCfg == nullptr)	pExpCfg = g_exp->GetConfigByCode(0x00d800)[0];// BGFEINT
			
			pLabel = new CAsyncLabel("gmeiint", GetTContext(pCfg), m_nAsyncCount, true, 1000);
			pLabel->m_priority = g_rnd.GetRange(0, 63);
			pLabel->m_nEventId = IException::EXP_GMEIINT;
		}
			
		pLabel->m_gpid = gpid;
		if(pExpCfg->m_uchannel != 0){
				// Randomizing interrupt channel
			UI32 channel = g_rnd.GetRange(pExpCfg->m_lchannel, pExpCfg->m_uchannel);
			pLabel->m_channel = channel;

			// Convert from channel -> interrupt cause code
			UI32 causecode = pExpCfg->m_lcode + channel;
			if(causecode > pExpCfg->m_ucode)
				causecode = pExpCfg->m_ucode;
			pLabel->m_causecode = causecode;
		} else {
			pLabel->m_causecode = pExpCfg->m_lcode;
		}

		return pLabel;
	};

	// Get exception cause code bit 16:18 of EIIC
	NewINS( pHB, STSR(13, reg1, 0));
	NewINS( pHB, SHR5(0x8, reg1));
	NewINS( pHB, ANDI(0xffU, reg1, SP));
	NewINS( pHB, SHR5(0x8, reg1));
	NewINS( pHB, SATSUBI(0xD8U, SP, SP));
	// Using HVSB to store next GPID
	NewINS( pHB, LDSR (reg1, 20, 1));
	// Clear BGFEINT or BGEIINT
	pIns = BP9P(label + "_clear_BGFEINT");
	pHB->AddOpeCode(pIns);

	bool context = pCfg->m_bNC;
	// Clear BGINT  
	pCfg->m_bNC = false;
	CAsyncLabel *pAsyncLabel = new CAsyncLabel("bgeiint", GetTContext(pCfg), m_nAsyncCount, false, 1000);
	pIns = NOP();
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, pIns);
	
	// Send new request return VM
	NewINS( pHB,  CMP5(0x3, reg1));
	NewINS( pHB,  BP9P(label + "_EI_return_GPID_4_7")); //jmp mean GPID in 4:7
	NewINS( pHB,  BE9P(label + "_EI_GPID_0x3"));
	NewINS( pHB,  CMP5(0x1, reg1));
	NewINS( pHB,  BN9P(label + "_EI_GPID_0x0"));
	NewINS( pHB,  BE9P(label + "_EI_GPID_0x1"));

	// HVTRAP 0x2
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(2, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x0
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(0, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	pIns->SetLabel(label + "_EI_GPID_0x0");
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x1
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(1, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	pIns->SetLabel(label + "_EI_GPID_0x1");
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x3
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_EI_GPID_0x3");
	pAsyncLabel = CreateIntLabel(3, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x4_7
	NewINS( pHB,  pIns= CMP5(0x6, reg1));
	pIns->SetLabel(label + "_EI_return_GPID_4_7");
	NewINS( pHB,  BP9P(label + "_EI_GPID_0x7")); //jmp mean GPID in 4:7
	NewINS( pHB,  BE9P(label + "_EI_GPID_0x6"));
	NewINS( pHB,  CMP5(0x4, reg1));
	NewINS( pHB,  BE9P(label + "_EI_GPID_0x4"));

	// _GPID_0x5
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(5, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x4
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_EI_GPID_0x4");
	pAsyncLabel = CreateIntLabel(4, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x6
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_EI_GPID_0x6");
	pAsyncLabel = CreateIntLabel(6, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x7
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_EI_GPID_0x7");
	pAsyncLabel = CreateIntLabel(7, IExceptionConfig::EXP_LEVEL_EI);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB,  JR22P(label + "_ret" ));

	// Label to clear bgfeint
	pAsyncLabel = new CAsyncLabel("bgfeint", GetTContext(pCfg), m_nAsyncCount, false, 1000);
	pIns = NOP();
	pIns->SetLabel(label + "_clear_BGFEINT");
	pHB->AddOpeCode(pIns);
	pIns->SetDirective(pAsyncLabel);
	// Send new request return VM
	NewINS( pHB,  CMP5(0x3, reg1));
	NewINS( pHB,  BP9P(label + "_FE_return_GPID_4_7")); //jmp mean GPID in 4:7
	NewINS( pHB,  BE9P(label + "_FE_GPID_0x3"));
	NewINS( pHB,  CMP5(0x1, reg1));
	NewINS( pHB,  BN9P(label + "_FE_GPID_0x0"));
	NewINS( pHB,  BE9P(label + "_FE_GPID_0x1"));

	// _GPID_0x2
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(2, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x0
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(0, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	pIns->SetLabel(label + "_FE_GPID_0x0");
	NewINS( pHB, JR22P(label + "_ret" ));

	// _GPID_0x1
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(1, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	pIns->SetLabel(label + "_FE_GPID_0x1");
	NewINS( pHB,  JR22P(label + "_ret" ));

	// _GPID_0x3
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_FE_GPID_0x3");
	pAsyncLabel = CreateIntLabel(3, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB,  JR22P(label + "_ret" ));

	// _GPID_0x4_7
	NewINS( pHB,  pIns= CMP5(0x6, reg1));
	pIns->SetLabel(label + "_FE_return_GPID_4_7");
	NewINS( pHB,  BP9P(label + "_FE_GPID_0x7")); //jmp mean GPID in 4:7
	NewINS( pHB,  BE9P(label + "_FE_GPID_0x6"));
	NewINS( pHB,  CMP5(0x4, reg1));
	NewINS( pHB,  BE9P(label + "_FE_GPID_0x4"));

	// _GPID_0x5
	NewINS( pHB,  pIns= NOP());
	pAsyncLabel = CreateIntLabel(5, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB,  JR22P(label + "_ret" ));

	// _GPID_0x4
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_FE_GPID_0x4");
	pAsyncLabel = CreateIntLabel(4, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB,  JR22P(label + "_ret" ));

	// _GPID_0x6
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_FE_GPID_0x6");
	pAsyncLabel = CreateIntLabel(6, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB,  JR22P(label + "_ret" ));

	// _GPID_0x7
	NewINS( pHB,  pIns= NOP());
	pIns->SetLabel(label + "_FE_GPID_0x7");
	pAsyncLabel = CreateIntLabel(7, IExceptionConfig::EXP_LEVEL_FE);
	pIns->SetDirective(pAsyncLabel);
	NewINS( pHB,  JR22P(label + "_ret" ));

	pCfg->m_bNC = context;

	return pHB;
}

CHandlerBlock* CBlockManager::GenerateBGINTHandler(TBlockConfig* pCfg, std::string label) {
	UI32 reg = m_nWorkReg;
	const UI32 SP = 3;
	UI32 reg1 = reg + 1;

	CHandlerBlock* pHB = new CHandlerBlock(label);
	pHB->SetOutputFlag(true);
	pHB->SetHandlerAddress( ADR_VECTOR_BGINT);
	pHB->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_EI);
	// Back up SP
	NewINS( pHB, MOVR(SP, m_nHandlerReg));
	// Back up SP + 1. This register use to calculate address
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY), SP) ) ;
	NewINS( pHB, STW16(reg1, 0x0, SP));
	
	// Update interrupt request
	NewINS( pHB, MOV32P("bgint_update_interrupt_label", reg1));
	NewINS( pHB, JMP32(reg1));
	
	// Calculate address for back up GRs. reg1 = current GPID
	NewINS( pHB, STSR (15, reg1, 0)->SetLabel("bgint_update_interrupt_label_ret"));      //PSWH
	NewINS( pHB, SHR5 (0x8, reg1));
    NewINS( pHB, ANDI (0x7, reg1, reg1));
	NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;
	NewINS( pHB, MULHI(660, reg1, reg1)); //reg1 = current GPID*660
	NewINS( pHB, ADD  (reg1, SP));
	NewINS( pHB, ADDI (660, SP, SP));
	// Restore SP + 1. This register use to calculate address
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY), reg1) ) ;
	NewINS( pHB, LDW16(0x0, reg1, reg1));
	NewINS( pHB, PUSHSP(1, 31));
	LoadSregOfException(pHB, reg, label, pCfg) ;
	// Back up PC by memory
	UI32 addr = g_wm.EXP_INT_TO_HOST_BACKUP_PC;
	// Get current GPID
	NewINS( pHB, STSR (15, reg1, 0));
	NewINS( pHB, SHR5 (0x8, reg1));
    NewINS( pHB, ANDI (0x7, reg1, reg1));

	NewINS( pHB, MULHI(4, reg1, reg1)); //reg1 = current GPID*4
	NewINS( pHB, MOV32 (addr, reg));
	NewINS( pHB, ADD  (reg1, reg));
	// Store PC at BGINT is requested
	NewINS( pHB, STSR (0, reg1, 0));
	NewINS( pHB, STW16 (reg1, 0x0, reg));
	//  Update EIPC by PC in handler
	NewINS( pHB, MOV32P(label + "_to_get_PC", reg1));
	NewINS( pHB, LDSR (reg1, 0, 0));
	// Tranfer EIWR -> GMEIWR to store by stm.gsr
	NewINS( pHB, STSR (28, reg, 0));
	NewINS( pHB, LDSR (reg, 28, 9));
	// Tranfer EIPSW -> GMEIPSW to store by stm.gsr
	NewINS( pHB, STSR (1, reg, 0));
	NewINS( pHB, LDSR (reg, 1, 9));
	// Switch VM here
	// Jump to change machine block
	NewINS( pHB,  MOV32P("Change_virtual_machine_EI", reg)) ;
	NewINS( pHB,  JMP32(reg)) ;

	// Tranfer GMEIWR -> EIWR
	NewINS( pHB, STSR (28, reg, 9)->SetLabel(label + "_to_get_PC") );
	NewINS( pHB, LDSR (reg, 28, 0));
	// Tranfer GMEIPSW -> EIPSW to store by stm.gsr
	NewINS( pHB, STSR (1, reg, 9));
	NewINS( pHB, LDSR (reg, 1, 0));
	NewINS( pHB, MOV32 (addr, reg));
	// Get next GPID from PSWH 
	NewINS( pHB, STSR (15, reg1, 0));      //PSWH
	NewINS( pHB, SHR5 (0x8, reg1));// reg1 = GPID
    NewINS( pHB, ANDI (0x7, reg1, reg1));
	NewINS( pHB, MULHI(4, reg1, SP)); //SP = current GPID*4
	NewINS( pHB, ADD  (SP, reg));
	NewINS( pHB, LDW16 (0x0, reg, SP));
	NewINS( pHB, LDSR (SP, 0, 0));
	
	// Update EIPSWH.GM bit
	NewINS( pHB, STSR(18, reg, 0) );
	NewINS( pHB, MOV32(0x80000000, SP) );
	NewINS( pHB, OR(SP, reg) );
	NewINS( pHB, LDSR(reg, 18, 0) );
	// Calculate address for back up GRs.
	NewINS( pHB, MULHI(660, reg1, reg1)); //reg1 = current GPID*660
	NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;

	NewINS( pHB, ADD (reg1, SP));
	NewINS( pHB, ADDI (536, SP, SP));

	NewINS( pHB, POPSP(1, 31)) ;
	NewINS( pHB, MOVR(m_nHandlerReg, 3));
    NewINS( pHB, STSR(28, m_nHandlerReg, 0));
	NewINS( pHB, EIRET()) ;

	return pHB;
}

bool CBlockManager::EnabelHVTRAPFor(UI32 changeto) {
	bool result = false;
	switch (changeto) {
	case IException::EXP_RESET:
		result = (g_exp->GetWeight(IException::EXP_RESET) > 0);
		break;

	case INS_CID_CHANGE_MODE:
		 result = (m_nrmSet.GetWeight(INS_CID_CHANGE_MODE) || g_prf->m_is_mpu);
		 break;

	case INS_CID_CHANGE_VMACHINE:
		 result = (g_cfg->m_mGMs.size() > 1);
		 break;

	default:
		break;
	}
	return result;
}


CHandlerBlock* CBlockManager::GenerateHVTRAPHandler(TBlockConfig* pCfg, std::string label) {
	UI32 reg = m_nWorkReg;
	UI32 reg1 = reg + 1;
	std::string contextStr = GetModeContext(pCfg);
	IInstruction * pIns = nullptr;
	CHandlerBlock* pHB = new CHandlerBlock(label);
	SaveRegisterEI(pHB, label) ;
	if(EnabelHVTRAPFor(INS_CID_CHANGE_MODE) || EnabelHVTRAPFor(INS_CID_CHANGE_VMACHINE) 
		|| EnabelHVTRAPFor(IException::EXP_RESET)) {
		//Read EIIC
		NewINS( pHB, STSR(13, reg, 0) );
		//Get exception cause code
		NewINS( pHB, ANDI(0x1fU, reg, reg));
	
		if(EnabelHVTRAPFor(INS_CID_CHANGE_VMACHINE)) {
			// Check cause code 0x0-0x7
			NewINS( pHB, CMP5(8, reg));
			// Check CY = 1
			NewINS( pHB, BNC17P("check_next_cause_code_0x1e"));
			// Using HVSB to store next GPID
			NewINS( pHB, STSR (20, reg1, 1) );
			NewINS( pHB, SHR5 (4, reg1) ); // Clear old GPID
			NewINS( pHB, SHL5 (4, reg1) );
			NewINS( pHB, OR ( reg, reg1) );
			NewINS( pHB, LDSR (reg1, 20, 1) );
			// Calculate address to store PC before changing VM 
			UI32 addr = g_wm.EXP_INT_TO_HOST_BACKUP_PC;		
			NewINS( pHB, MOV32 (addr, reg1));
			// Get current GPID by PSWH
			NewINS( pHB, STSR (15, reg, 0) );
			NewINS( pHB, SHR5 (0x8, reg) );
			NewINS( pHB, ANDI (0x7, reg, reg) );
			NewINS( pHB, MULHI (4, reg, reg)); // reg = GPID * 4
			NewINS( pHB, ADD (reg1, reg));	   // reg = addr + GPID * 4		
			// Store PC before changing VM
			NewINS( pHB, STSR (0, reg1, 0));
			NewINS( pHB, STW16 (reg1, 0x0, reg));
			NewINS( pHB, MOV32P(label + "_to_get_PC", reg1));
			// Update EIPC
			NewINS( pHB, LDSR (reg1, 0, 0));
			// Tranfer EIWR -> GMEIWR to store by stm.gsr
			NewINS( pHB, STSR (28, reg1, 0));
			NewINS( pHB, LDSR (reg1, 28, 9));
			// Jump to change machine block
			NewINS( pHB, MOV32P("Change_virtual_machine_EI", reg1));
			NewINS( pHB, JMP32(reg1));
	
			// Tranfer GMEIWR -> EIWR. Because we can backup GMEIWR by STM.GSR only
			// HVTRAP -> EIWR<=handlerReg -> GMEIWR <= EIWR -> Backup resource
			NewINS( pHB, STSR (28, reg1, 9)->SetLabel(label + "_to_get_PC") );
			NewINS( pHB, LDSR (reg1, 28, 0));
			// Get PC return to random code EIPC by HVTRAP
			NewINS( pHB, STSR (15, reg1, 0));
			NewINS( pHB, SHR5 (0x8, reg1));
            NewINS( pHB, ANDI (0x7, reg1, reg1)); //reg1 = PSWH.GPID
			NewINS( pHB, MOV32 (addr, reg));
			NewINS( pHB, MULHI (4, reg1, reg1)); // reg = GPID * 4
			NewINS( pHB, ADD (reg1, reg));	   // reg = addr + GPID * 4	
			NewINS( pHB, LDW16 (0x0, reg, reg1));
			NewINS( pHB, LDSR (reg1, 0, 0));

			// Update EIPSWH.GM bit
			NewINS( pHB, STSR(18, reg, 0) );
			NewINS( pHB, MOV32(0x80000000, reg1) );
			NewINS( pHB, OR(reg, reg1) );
			NewINS( pHB, LDSR(reg1, 18, 0) );
			NewINS( pHB, MOV32(((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY) - (31 * 4)), 3) );
            // Update GMEIPSW => EIPSW before changing to Guest Mode
            NewINS( pHB, STSR(1, reg, 9) );
            NewINS( pHB, LDSR(reg, 1, 9) );
			NewINS( pHB, POPSP(1,31));
			NewINS( pHB, MOVR(m_nHandlerReg, 3));
			NewINS( pHB, STSR(28, m_nHandlerReg, 0) );
			NewINS( pHB, EIRET() );
		}
		
		pIns = NOP();
		pIns->SetLabel("check_next_cause_code_0x1e");
		pHB->AddOpeCode(pIns);
		if(EnabelHVTRAPFor(INS_CID_CHANGE_MODE)) {
			//Check cause code 0x1e
			NewINS( pHB, SATSUBI(0x1e, reg, reg1));
			NewINS( pHB, BNZ9P("check_next_cause_code_0x1f"));
			NewINS( pHB, STSR(18, reg, 0));     // EIPSWH
			NewINS( pHB, SHL5(1, reg));
			NewINS( pHB, SHR5(1, reg));
			NewINS( pHB, LDSR(reg, 18, 0)); 
            // Assign EIPSW.UM = 0
            NewINS(pHB, STSR(1, reg, 0));		// EIPSW
            NewINS(pHB, SHL5(2, reg));
            NewINS(pHB, SHR5(2, reg));
            NewINS(pHB, LDSR(reg, 1, 0));

			NewINS( pHB, JR22P(pHB->GetLabel() + "_end_of_handler"));
		}
		pIns = NOP();
		pIns->SetLabel("check_next_cause_code_0x1f");
		pHB->AddOpeCode(pIns);
		if(EnabelHVTRAPFor(IException::EXP_RESET)) {
			//Check cause code 0x1f
			NewINS( pHB, SATSUBI(0x1f, reg, reg1));
			NewINS( pHB, BNZ9P(pHB->GetLabel() + "_checking_causecode_end"));
			
			// Jump to software reset handler block
			NewINS( pHB, MOV32P("SW_Reset_handler", reg));
			NewINS( pHB, JMP32(reg));
		}
	}
	// Normal cause code
	pIns = NOP()->SetLabel(pHB->GetLabel() + "_checking_causecode_end");
	pHB->AddOpeCode(pIns);
	// Executing normal processing for exception
	LoadSregOfException(pHB, reg, contextStr + "hvtrap_handler", pCfg) ;
	NewINS( pHB, pIns = MOV32(((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY) - 31*4), 3) ) ;
	pIns->SetLabel(pHB->GetLabel() + "_end_of_handler");
	NewINS( pHB,  POPSP(1, 31)) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
    NewINS( pHB,  STSR(28, m_nHandlerReg, 0));
	NewINS( pHB,  EIRET()) ;

	return pHB;

}

CHandlerBlock* CBlockManager::SWResetHandler(TBlockConfig* pCfg) {
	CHandlerBlock* pHB = new CHandlerBlock("SW_Reset_handler");
	pHB->SetOutputFlag(true);
	const UI32 reg = m_nWorkReg;
	const UI32 reg1 = reg + 1; // back up svlock register
    const UI32 mem_addr_reg = reg + 2; // calculate mem address to load MPU infor

    std::multimap<UI32, UI32> mInitSR;      // pair of SelId and RegId
    // Re-init interrupt related system register
    for (UI32 id = 13; id < 18; id++) {
        mInitSR.insert(std::make_pair(2, id));
    }
    mInitSR.insert(std::make_pair(2, 10)); // ISPR
    // Re-init interrupt related system register in Guest Mode
    mInitSR.insert(std::make_pair(9, 21)); // GMINTCFG
    mInitSR.insert(std::make_pair(9, 22)); // GMPLMR
   // Re-init MPU related system register
    mInitSR.insert(std::make_pair(1, 0)); // SPID
    mInitSR.insert(std::make_pair(5, 0)); // MPM
    // Re-init MPU related system register in Guest Mode 
    mInitSR.insert(std::make_pair(9, 16)); // GMSPID
    mInitSR.insert(std::make_pair(9, 17)); // GMSPIDLIST
    mInitSR.insert(std::make_pair(9, 25)); // GMMPM

	// Back up SVLOCK
	NewINS(pHB, STSR (8, reg1, 1));
	NewINS(pHB, LDSR (0, 8, 1));
	//!・When MPU is installed, re-init MPU entry
	if (m_MmList.Size() != 0) {
        const UI32 mpnum = g_hwInfo.m_mpnum;
        // Calculate memory to store MPU infor
        const UI32 size_of_mpu = (mpnum * 3 * 4);
        //  Disable MPM
		NewINS(pHB, LDSR(0, 0, 5));     // MPM
        NewINS(pHB, SYNCI());

        UI32 hbe = m_MmList.GetHBE();
        NewINS(pHB, MOV32((hbe << 8), reg));
        NewINS(pHB, LDSR(reg, 2, 5));         //MPCFG

        // Calculate address to load MPU infor
        NewINS(pHB, STSR(15, reg, 0));      //PSWH
        NewINS(pHB, SHR5(0x8, reg));
        NewINS(pHB, ANDI(0x7, reg, reg));   // PSWH.GPID
        NewINS(pHB, MULHI(size_of_mpu, reg, reg));
        NewINS(pHB, MOV32(g_wm.STORE_MPU_INFO, mem_addr_reg));
        NewINS(pHB, ADD(mem_addr_reg, reg));

        NewINS(pHB, LDM_MP(reg, 0, mpnum - 1));

		// set new value for MPIDX if it is same as reserve entry 
		UI32 curMPIDx = g_hwInfo.m_mpnum - 1;  // default is value of convention mode
		if (pCfg->m_bGM) curMPIDx = g_srs->GetNcInit(16, 5);
		UI32 newMPIDX = curMPIDx;

		while (g_prf->IsWorkMPURegionByIdx(newMPIDX)) {
		    newMPIDX = g_rnd.GetRange((UI32)0, (UI32)g_hwInfo.m_mpnum - 1);
		}
		if (newMPIDX != curMPIDx) {
		    NewINS(pHB, MOV32(newMPIDX, reg));
		    NewINS(pHB, LDSR(reg, 16, 5));
		}
    } else {
        mInitSR.insert(std::make_pair(5, 17)); // MPBK
        mInitSR.insert(std::make_pair(5, 2)); // MPCFG
    }

    //Get value for SRs
    IInstruction* pIns = NOP();
    UI32 val = 0;
    std::string regName;

    for (std::pair<UI32, UI32> reg_id : mInitSR) {
        regName = g_srs->GetName(reg_id.second, reg_id.first);
        val = g_srs->GetNcInit(reg_id.second, reg_id.first);
        NewINS(pHB, MOV32(val, reg));
        pIns = LDSR(reg, reg_id.second, reg_id.first);
        pIns->AppendComment(regName.data());
        NewINS(pHB, pIns);
    }

	// Revert SVLOCK
	NewINS(pHB, LDSR (reg1, 8, 1));

	// Return from hvtrap handler
	NewINS( pHB,  POPSP(1, 31)) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
    NewINS( pHB,  STSR(28, m_nHandlerReg, 0));
	NewINS( pHB,  EIRET()) ;

	return pHB;

}

CHandlerBlock* CBlockManager::ChangeVirtualMachine(TBlockConfig* pCfg, UI32 expLevel) {

	const UI32 regMem = 3;
	UI32 gpidReg = m_nWorkReg;
	UI32 reg = m_nWorkReg + 1;

	//PC 4 + GRs 31*4 + SRs 37*4 + MPU 32*4*3 registers
	const UI32 memSize = 660;
	IInstruction * pIns = nullptr;
	std::string label = "Change_virtual_machine";
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		label += "_EI";
	} else {
		label += "_FE";
	}
	CHandlerBlock* pHB = new CHandlerBlock(label);
	pHB->SetOutputFlag(true);
	//Start backup resource
	pIns = MOV32 (g_wm.BACKUP_RESTORE_GM_RESOURCE, regMem);
	pHB->AddOpeCode(pIns);
	//Read PSWH to get GPID
	pIns = STSR (15, reg, 0);
	pHB->AddOpeCode(pIns);
	//Get GPID value
	pIns = SHR5 (8, reg);
	pHB->AddOpeCode(pIns);
    pIns = ANDI(0x7, reg, reg);
    pHB->AddOpeCode(pIns);
	//Calculate backup memory
	pIns = MULHI (memSize, reg, reg);
	pHB->AddOpeCode(pIns);
	pIns = ADD (reg, regMem);
	pHB->AddOpeCode(pIns);
	BackupMachineResource(pHB, regMem, expLevel);

	//Start restore resource
	pIns = MOV32 (g_wm.BACKUP_RESTORE_GM_RESOURCE, regMem);
	pHB->AddOpeCode(pIns);
	//Read GPID from HVSB
	pIns = STSR(20, gpidReg, 1);
	pHB->AddOpeCode(pIns);
	// Get GPID
	pIns = ANDI(0x7, gpidReg, gpidReg);
	pHB->AddOpeCode(pIns);
	//Calculate restore memory
	pIns = MULHI (memSize, gpidReg, reg);
	pHB->AddOpeCode(pIns);
	pIns = ADD (reg, regMem);
	pHB->AddOpeCode(pIns);
	RestoreMachineResource(pCfg, pHB, gpidReg, regMem, expLevel);	
	// Clear HVSB
	NewINS( pHB, LDSR (0, 20, 1));
	//Check BGINT to update HVSB
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		pIns = STSR(13, reg, 0); //Read EIIC
	} else {
		pIns = STSR(14, reg, 0); //Read FEIC
	}

	pHB->AddOpeCode(pIns);
	// Get Cause code bits [4]
    pIns = ANDI(0xf000, reg, reg);
	pHB->AddOpeCode(pIns);
    //Compare to find BGxx cause code
    pIns = MOV32(0xd000, gpidReg);
	pHB->AddOpeCode(pIns);
	// Compare to determine BG interrupt
	pIns = CMPR(gpidReg, reg);
	pHB->AddOpeCode(pIns);
	label = "_not_update_HVSB";
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		label += "_EI";
	} else {
		label += "_FE";
	}
    pIns = BNE17P(label);
	pHB->AddOpeCode(pIns);
	// Random update HVSB for GMINT switch VM
	pIns = CMPR(g_rnd.GetRange(0, 31), reg);
	pHB->AddOpeCode(pIns);
	
	pIns = BN9P(label);
	pHB->AddOpeCode(pIns);

	// Set 0x8 + current GPID to HVSB for BGINT
	// Read PSWH to get GPID
	pIns = STSR (15, reg, 0);
	pIns->SetLabel(pHB->GetLabel() + "_BGINT_update_HVSB" );
	pHB->AddOpeCode(pIns);
	// Get GPID value
	pIns = SHR5 (8, reg);
	pHB->AddOpeCode(pIns);
    pIns = ANDI(0x7, reg, reg);
    pHB->AddOpeCode(pIns);

	// Set 0x8 + GPID value
	pIns = ORI (0x8, reg, reg);
	pHB->AddOpeCode(pIns);

	pIns = LDSR (reg, 20, 1);
	pIns->SetLabel(pHB->GetLabel() + "_update_HVSB" );
	pHB->AddOpeCode(pIns);

	// VM switching
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		// Clear UM
		pIns = STSR (1, reg, 0);
		pIns->SetLabel(label);
		pHB->AddOpeCode(pIns);
		pIns = SHL5 (0x3, reg);
		pHB->AddOpeCode(pIns);
		pIns = SHR5 (0x3, reg);
		pHB->AddOpeCode(pIns);
		pIns = LDSR (reg, 1, 0);
		pHB->AddOpeCode(pIns);
		pIns = EIRET ();
		pHB->AddOpeCode(pIns);
	} else {
		// Clear UM
		pIns = STSR (3, reg, 0);
		pIns->SetLabel(label);
		pHB->AddOpeCode(pIns);
		pIns = SHL5 (0x3, reg);
		pHB->AddOpeCode(pIns);
		pIns = SHR5 (0x3, reg);
		pHB->AddOpeCode(pIns);
		pIns = LDSR (reg, 3, 0);
		pHB->AddOpeCode(pIns);
		pIns = FERET ();
		pHB->AddOpeCode(pIns);
	}
	
	return pHB;
}
 
std::vector<CHandlerBlock*>* CBlockManager::GenerateFixHandlerBlock(TBlockConfig* pCfg) {

	std::vector<CHandlerBlock*>* vNode = new std::vector<CHandlerBlock*>();
	CHandlerBlock* pHB = nullptr;
	// m_nWorkReg was set value in GenerateHandler
	UI32 reg = m_nWorkReg;

	// Generate code for changing virtual machine
	//if(g_cfg->m_mGMs.size() > 1){
		// Change by Exception/ interrupt level EI
		pHB = ChangeVirtualMachine(pCfg, IExceptionConfig::EXP_LEVEL_EI);
		vNode->push_back(pHB);

		// Change by Exception/ interrupt level FE
		pHB = ChangeVirtualMachine(pCfg, IExceptionConfig::EXP_LEVEL_FE);
		vNode->push_back(pHB);

	//}

	// Fix handler for MDP, MIP exception
	// Check cause code
	pHB = GenFixMPHandler(reg, "fix_mp_handler", pCfg);
	vNode->push_back(pHB);

	// Generate SW reset exception handler
	if(g_exp->GetWeight(IException::EXP_RESET) > 0){
		pHB = SWResetHandler(pCfg);
		vNode->push_back(pHB);
	}

	//__Read_system_register_block:
	pHB = GenerateReadSysRegBlock(reg);
	vNode->push_back(pHB);

	// ＥI例外発生命令の次命令アドレス計算処理
	/*The lenght of Instruction that has exception was stored to memory before, 
	load that value and add to EIPC to create return value*/
	pHB = GenerateExpReturnBlock(IExceptionConfig::EXP_LEVEL_EI, reg);
	vNode->push_back(pHB);

	// Get return value and updating to XXPC
	pHB = GenerateExpReturnBlock(IExceptionConfig::EXP_LEVEL_FE, reg);
	vNode->push_back(pHB);

	pHB = GenPCIncDeBugHandler(reg, "dbpcInc", pCfg);
	vNode->push_back(pHB);

    // 例外系フラグクリア処理
//__dbpcIns
	pHB = GenPCIncBreakPointHandler(reg, "dbpcInc_break", pCfg);    
	vNode->push_back(pHB);

	//	pHB = GenerateWorkingAreaBlock(reg);
	//	vNode->push_back(pHB);
	//Disable MPM block
	pHB = new CHandlerBlock("disable_mpu");
	pHB->SetOutputFlag(true);
	NewINS( pHB, LDSR(0, 8, 1));	// Disable SVLOCK
	NewINS( pHB, LDSR(0, 0, 5));	// Disable MPM
	NewINS( pHB, SYNCI());
	NewINS( pHB, JMP32(31) ); // return code
	vNode->push_back(pHB);
	pHB = UpdateBGINTRequest(pCfg, "bgint_update_interrupt_label");
	vNode->push_back(pHB);

	pHB = RandomNextVM(reg);
	vNode->push_back(pHB);

	return vNode;

}
CHandlerBlock* CBlockManager::SaveRegisterEI(CHandlerBlock* pCB, std::string label) {
	IInstruction * ins = nullptr;
	char str[130] ;
	std::string context = label.substr(0, label.find("_") + 1);

	NewINS( pCB, MOVR(3, m_nHandlerReg));
	NewINS( pCB, ins = MOV32((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY),3) ) ;
	sprintf(str ,"r3 = (BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY)" ) ;
	ins->AppendComment((LPCTSTR)str) ;

	NewINS( pCB, PUSHSP(1,31)) ;

	//!▽リターン。<BR><BR>
	return pCB;
}

CHandlerBlock* CBlockManager::SaveRegisterFE(CHandlerBlock* pCB, std::string label) {
	IInstruction * ins = nullptr;
	char str[130] ;
	std::string context = label.substr(0, label.find("_") + 1);
	
	NewINS( pCB, MOVR(3, m_nHandlerReg));
	NewINS( pCB, ins = MOV32((g_wm.BASE_PE_HT + g_wm.OFS_SAVE_FE + g_wm.SIZ_SAVE_FE),3) ) ;
	sprintf(str ,"r3 = (BASE_PE_HT + OFS_SAVE_FE + SIZ_SAVE_FE)" ) ;
	ins->AppendComment((LPCTSTR)str) ;

	NewINS( pCB, PUSHSP(1,31)) ;

	return (pCB) ;
}

CCodeBlock* CBlockManager::SaveRegisterDB(CCodeBlock* pCB , std::string label) {
	IInstruction * ins = nullptr;
	char str[130] ;
	
	NewINS( pCB, MOVR(3, m_nHandlerReg));

	NewINS( pCB, ins = MOV32((g_wm.BASE_PE_VM + g_wm.OFS_SAVE_DB + g_wm.SIZ_SAVE_DB),3) ) ;
	sprintf(str ,"r3 = (BASE_PE_VM + OFS_SAVE_DB + SIZ_SAVE_DB)" ) ;
	ins->AppendComment((LPCTSTR)str) ;

	NewINS( pCB, PUSHSP(1,31) ) ;
	
	return pCB;
}


CHandlerBlock*	CBlockManager::RandomNextVM(UI32 reg) {
	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	
	CHandlerBlock* pHB = new CHandlerBlock("Random_next_GPID");
	pHB->SetOutputFlag(true);
	std::map<UI32, GM_Infor> mGMs = g_cfg->m_mGMs;
	NewINS( pHB, STSR (15, reg, 0) ); // READ PSWH
	NewINS( pHB, SHR5 (8, reg) );     //Get GPID value
    NewINS( pHB, ANDI (7, reg, reg)); //Get GPID value

	UI32 ranIndex = 0;
	while (mGMs.empty() == false) {
		ranIndex = g_rnd.GetRange(0U, (UI32)mGMs.size() - 1 );
		std::map<UI32, GM_Infor>::iterator itr = mGMs.begin();
		std::advance( itr, ranIndex);
		UI32 GPID =  itr->first;// Get GPID
		
		// Label for terminated GM
		std::string labelStr("");
		std::stringstream ss;
		ss <<"skip_switch_to_" << GPID ;
		ss >> labelStr;
		
		NewINS( pHB, CMP5 (GPID, reg) );
		NewINS( pHB, BZ9P (labelStr) );

		UI32 addr = g_wm.GM_TERMINATE_FLAG;		
		addr += 4 * GPID;
		// Check end flag of other GM
		NewINS( pHB, MOV32 (addr, reg1));
		NewINS( pHB, LDB16 (0, reg1, reg2) );
		NewINS( pHB, CMP5  (1, reg2) );
		NewINS( pHB, BZ9P  (labelStr) );

		// Using HVSB to store next GPID
		NewINS( pHB, STSR (20, reg1, 1) );
		NewINS( pHB, SHR5 (4, reg1) ); // Clear old GPID
		NewINS( pHB, SHL5 (4, reg1) );
		NewINS( pHB, ORI  (GPID | 0x10, reg1, reg1) );
		NewINS( pHB, LDSR (reg1, 20, 1) );
		NewINS( pHB, BR9P ("Return_to_callee_hanlder"));
		// Finish check VM
		NewINS( pHB, NOP ()->SetLabel(labelStr) );
		mGMs.erase(GPID);
	}
	
	// Return to callee
	NewINS( pHB, JMP32(reg + 3)->SetLabel("Return_to_callee_hanlder") );

	return pHB;
}


CCodeBlock* CBlockManager::LoadSregOfException(CCodeBlock* pCB, UI32 reg, std::string label, TBlockConfig* pCfg) {
	std::string contextStr = GetMContext(pCfg);
	SI32  MAX_CHANNEL= g_exp->GetNumOfChannels();
	UI32 channel_reg, dir1_reg, csl_reg;
	UI32 jump_reg = 28;
	UI32 ret_reg = 31;
	UI32 expLevel = pCB->GetExceptionLevel();
	do {
		channel_reg = g_rnd.GetRange(4, 27);
	} while(channel_reg <= reg && reg <= (channel_reg + 2));
	dir1_reg = channel_reg + 1;
	csl_reg = channel_reg + 2;
	
	NewINS( pCB, MOV32P("Handler_read_system_registers", jump_reg));

	if (expLevel == IExceptionConfig::EXP_LEVEL_EI)
		NewINS( pCB, STSR(0, reg, 0)  );		// EIPC
	else if (expLevel == IExceptionConfig::EXP_LEVEL_DB)
		NewINS( pCB,  STSR(18, reg,3)  );		// DBPC
	else
		NewINS( pCB,  STSR(2, reg, 0)  );		// FEPC

	NewINS( pCB, ANDI(0x7c, reg, reg)  );		//EIPC AND 0x1111100
	NewINS( pCB, ADD(reg, jump_reg)  );			//EIPC AND 0x1111100
	NewINS( pCB, JARL32(jump_reg, ret_reg));

	if (expLevel == IExceptionConfig::EXP_LEVEL_DB) {
		NewINS( pCB,  STSR(0, reg, 3)  );	// DBGEN
		NewINS( pCB,  STSR(15, reg,3)  );	// DBIC
		NewINS( pCB,  STSR(13, reg,3)  );	// DBPSWH
		NewINS( pCB,  STSR(19, reg,3)  );	// DBPSW
		NewINS( pCB,  STSR(20, reg,3)  );	// DIR0
        NewINS( pCB,  STSR(30, reg,3)  );	// DBWR

		const UI32 READ_CHANNEL = MAX_CHANNEL / 4;
        NewINS( pCB,  ORI(READ_CHANNEL, 0, channel_reg) );
        NewINS( pCB,  STSR(21, dir1_reg, 3)  );      // read from DIR1
        NewINS( pCB,  MOV32(0xFFFFFF0F, csl_reg) );  // CSL is Zero

		NewINS( pCB,  ANDI(0x30, jump_reg, jump_reg)  );		//jump register AND 0x110000
		NewINS( pCB,  OR(jump_reg, csl_reg));
        
		NewINS( pCB,  AND(csl_reg, dir1_reg));
        NewINS( pCB,  LDSR(dir1_reg, 21, 3)->SetLabel(label +  "_DIR1_CSL_") );        // DIR1
        NewINS( pCB,  STSR(22, reg, 3)  );      // BPC
        NewINS( pCB,  STSR(24, reg, 3)  );      // BPAV
        NewINS( pCB,  STSR(25, reg, 3)  );      // BPAM

        NewINS( pCB,  ADDI(0x40, dir1_reg, dir1_reg) );
        NewINS( pCB,  ADDI(-1, channel_reg, channel_reg) );
        NewINS( pCB,  BNZ9P(label + "_DIR1_CSL_"));
	}

	return pCB;
}

CHandlerBlock*	CBlockManager::GuestINTSwitchVM (CHandlerBlock* pHB, UI32 reg) {
	std::string label = pHB->GetLabel();
	const UI32 SP = 3;
	IInstruction* ins;
	// Return resource
	ins = (pHB->GetExceptionLevel() == IExceptionConfig::EXP_LEVEL_EI ? STSR (28, m_nHandlerReg, 0): STSR (29, m_nHandlerReg, 0));
	NewINS( pHB, MOVR( m_nHandlerReg, SP));
	NewINS( pHB, ins);
	// Read HVSB to get next GPID
	NewINS( pHB,  STSR(20, reg, 1));
	NewINS( pHB,  ANDI(0x7, reg, reg));
	// HVTRAP return VM
	NewINS( pHB,  CMP5(0x3, reg));
	NewINS( pHB,  BP9P(label + "_return_GPID_4_7")); //jmp mean GPID in 4:7
	NewINS( pHB,  BE9P(label + "_HVTRAP_0x3"));
	NewINS( pHB,  CMP5(0x1, reg));
	NewINS( pHB,  BN17P(label + "_HVTRAP_0x0"));
	NewINS( pHB,  BE9P(label + "_HVTRAP_0x1"));

	// HVTRAP 0x2
	NewINS( pHB,  ins= HVTRAP(0x2));
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	// HVTRAP 0x0
	NewINS( pHB,  ins= HVTRAP(0x0));
	ins->SetLabel(label + "_HVTRAP_0x0");
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	// HVTRAP 0x1
	NewINS( pHB,  ins= HVTRAP(0x1));
	ins->SetLabel(label + "_HVTRAP_0x1");
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	// HVTRAP 0x3
	NewINS( pHB,  ins= HVTRAP(0x3));
	ins->SetLabel(label + "_HVTRAP_0x3");
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	//HVTRAP 4-7
	NewINS( pHB,  ins= CMP5(0x6, reg));
	ins->SetLabel(label + "_return_GPID_4_7");
	NewINS( pHB,  BP9P(label + "_HVTRAP_0x7")); //jmp mean GPID in 4:7
	NewINS( pHB,  BE9P(label + "_HVTRAP_0x6"));
	NewINS( pHB,  CMP5(0x4, reg));
	NewINS( pHB,  BE9P(label + "_HVTRAP_0x4"));
	// HVTRAP 0x5
	NewINS( pHB,  ins= HVTRAP(0x5));
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	// HVTRAP 0x4
	NewINS( pHB,  ins= HVTRAP(0x4));
	ins->SetLabel(label + "_HVTRAP_0x4");
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	// HVTRAP 0x6
	NewINS( pHB,  ins= HVTRAP(0x6));
	ins->SetLabel(label + "_HVTRAP_0x6");
	NewINS( pHB,  ins= BR9P(label + "_restore_GR_VM" ));
	// HVTRAP 0x7
	NewINS( pHB,  ins= HVTRAP(0x7));
	ins->SetLabel(label + "_HVTRAP_0x7");

	// Calculate address for back up GRs. backupReg = current GPID
	NewINS( pHB, STSR (15, reg, 0)->SetLabel(label + "_restore_GR_VM" ));     // PSWH
	NewINS( pHB, SHR5 (0x8, reg));
	NewINS( pHB, ANDI (0x7, reg, reg));         // PSWH.GPID
	NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;
	NewINS( pHB, MULHI(660, reg, reg)); //backupReg = current GPID*660
	NewINS( pHB, ADD  (reg, SP));
	NewINS( pHB, ADDI (536, SP, SP));
	// Restore GRs
	NewINS( pHB,  POPSP(1, 31)) ;
	// Restore r3
	NewINS( pHB, MOVR(m_nHandlerReg, SP));
	ins = (pHB->GetExceptionLevel() == IExceptionConfig::EXP_LEVEL_EI ? STSR (28, m_nHandlerReg, 0): STSR (29, m_nHandlerReg, 0));
	NewINS( pHB, ins);
	if (pHB->GetExceptionLevel() == IExceptionConfig::EXP_LEVEL_EI) {
		ins = EIRET();
	} else {
		ins = FERET();
	}
	pHB->AddOpeCode(ins);

	return pHB;
}

CHandlerBlock*	CBlockManager::GenEIInterruptHandler(UI32 reg, std::string label, TBlockConfig* pCfg) {
	
	IInstruction * ins ;
	char str[120] ;
	std::string contextStr = GetMContext(pCfg);
	const UI32 SP = 3;
	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	UI32 reg3 = reg + 3;

	CHandlerBlock* pHB =  new CHandlerBlock(label);
	pHB->SetOutputFlag(true);
	pHB->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_EI);
	// Back up SP
	NewINS( pHB, MOVR(SP, m_nHandlerReg));
	
	// Back up SP + 1. This register use to calculate address
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY), SP) ) ;
	
	// Check EIINT switch VM
	if (g_cfg->m_mGMs.size() > 1) {
		NewINS( pHB, STW16(reg, 0x0, SP));
		if (pCfg->m_bNC == true){
			// If EIINT is requested in HM, FROG does not change to other VM
			NewINS( pHB, STSR (18, reg, 0));
			NewINS( pHB, SHR5 (0x1f, reg));
			NewINS( pHB, CMP5 (0, reg));
			NewINS( pHB, BZ9P (label + "_nomarl_sequence"));
			// Tranfer EIWR -> GMEIWR to store by stm.gsr
			NewINS( pHB, STSR (28, reg, 0));
			NewINS( pHB, LDSR (reg, 28, 9));
			// Tranfer EIPSW -> GMEIPSW to store by stm.gsr
			NewINS( pHB, STSR (1, reg, 0));
			NewINS( pHB, LDSR (reg, 1, 9));
			NewINS( pHB, BR9P (label + "_interrupt_switch_VM"));
		} else {
			// Get next GPID by HVSB (HVSB[3] = 1, HVSB[2:0] = GPID) for VM switching
			NewINS( pHB, STSR(20, reg, 1));
			NewINS( pHB, SHR5(0x4, reg));
			NewINS( pHB, BC9P(label + "_interrupt_switch_VM"));
		}
		// Restore backup reg
		NewINS( pHB, LDW16(0x0, SP, reg)->SetLabel(label + "_nomarl_sequence"));
	}

	NewINS( pHB, PUSHSP(1, 31));
	LoadSregOfException(pHB, reg, label, pCfg) ;
	NewINS( pHB, JR22P(label + "_not_BGINT"));

	// Calculate address for back up GRs. reg2 = current GPID
	// Get GPID via PSWH. Add check for 1 VM
	NewINS( pHB, STSR (15, reg, 0)->SetLabel(label + "_interrupt_switch_VM" ));
	NewINS( pHB, SHR5 (0x8, reg));
	NewINS( pHB, ANDI (0x7, reg, reg));
	NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;
	NewINS( pHB, MULHI(660, reg, reg)); //reg = current GPID*660
	NewINS( pHB, ADD  (reg, SP));
	NewINS( pHB, ADDI (660, SP, SP));
	// Restore reg. This register use to calculate address
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.OFS_STACK_EI_ENTRY), reg) ) ;
	NewINS( pHB, LDW16(0x0, reg, reg));
	NewINS( pHB, PUSHSP(1, 31));
	LoadSregOfException(pHB, reg, label + "switch_GM", pCfg) ;
	// Read HVSB to determine BGINT request in other VM 
	// VM accept as GMEIINT 
	// Need switching to original VM
	if (pCfg->m_bNC == false) { // GMEIINT
		pHB = GuestINTSwitchVM (pHB, reg);

	} else if (g_cfg->m_mGMs.size() > 1) { // EIINT

		// Jump to change machine block
		NewINS( pHB, MOV32P("Random_next_GPID", reg));
		NewINS( pHB, JARL32(reg, reg + 3));
		// Read HVSB to determine whether changing VM
		NewINS( pHB, STSR (20, reg, 1));
		NewINS( pHB, ANDI (0xf, reg, reg1));
		NewINS( pHB, SHR5 (0x5, reg));
		NewINS( pHB, BNC17P (label + "_not_BGINT"));
		// Clear HVSB[4]
		NewINS( pHB, LDSR (reg1, 20, 1));

		// Back up PC by memory
		UI32 addr = g_wm.EXP_INT_TO_HOST_BACKUP_PC;
		// Get current GPID
		NewINS( pHB, STSR (15, reg, 0));   // PSWH
		NewINS( pHB, SHR5 (0x8, reg));     // PSWH.GPID
        NewINS( pHB, ANDI(0x7, reg, reg));
	
		NewINS( pHB, MULHI(4, reg, reg)); //reg2 = current GPID*4
		NewINS( pHB, MOV32 (addr, reg1));
		NewINS( pHB, ADD  (reg, reg1));
		NewINS( pHB, STSR (0, reg, 0));
		NewINS( pHB, STW16 (reg, 0x0, reg1));

		// Get corresponding PC
		NewINS( pHB, MOV32P(label + "_to_get_PC", reg));
		// Update EIPC
		NewINS( pHB, LDSR (reg, 0, 0));
		// Interrupt bound to host mode
		// Switch to another VM
		// Jump to change machine block
		NewINS( pHB, MOV32P("Change_virtual_machine_EI", reg));
		NewINS( pHB, JMP32 (reg));

		// Get next GPID from PSWH 
		// Tranfer GMEIWR -> EIWR to store by stm.gsr
		NewINS( pHB, STSR (28, reg, 9)->SetLabel(label + "_to_get_PC") );
		NewINS( pHB, LDSR (reg, 28, 0));
		// Tranfer GMEIPSW -> EIPSW 
		NewINS( pHB, STSR (1, reg, 9));
		NewINS( pHB, LDSR (reg, 1, 0));
		NewINS( pHB, STSR (15, reg, 0));    // PSWH
		NewINS( pHB, SHR5 (0x8, reg));      // PSWH.GPID
		NewINS( pHB, ANDI (0x7, reg, reg1));

    	NewINS( pHB, MULHI(4, reg1, reg)); //reg = current GPID*4
		NewINS( pHB, MOV32 (addr, SP));
		NewINS( pHB, ADD  (reg, SP));
		NewINS( pHB, LDW16 (0x0, SP, reg));
		// Back up EIPC
		NewINS( pHB, LDSR (reg, 0, 0));
		// Update EIPSWH.GM bit
		NewINS( pHB, STSR(18, reg, 0) );
		NewINS( pHB, MOV32(0x80000000, SP) );
		NewINS( pHB, OR(SP, reg) );
		NewINS( pHB, LDSR(reg, 18, 0) );
		// Calculate address for back up GRs. reg2 = GPID *4
		NewINS( pHB, MULHI(660, reg1, reg1)); //reg2 = current GPID*660
		NewINS( pHB, MOV32(g_wm.BACKUP_RESTORE_GM_RESOURCE, SP) ) ;

		NewINS( pHB, ADD (reg1, SP));
		NewINS( pHB, ADDI (536, SP, SP));
	}	
	NewINS( pHB, NOP()->SetLabel(label + "_not_BGINT"));

	//!< Checking Is using Register Bank feature.
    // Conventional mode or Guest mode
    if (pCfg->m_bGM == false || pCfg->m_bNC == false) {

        NewINS(pHB, STSR(17, reg1, 2));                           // Load RBRN.
        NewINS(pHB, ANDI(0xff, reg1, reg1));                      // Checking whether == 0
        NewINS(pHB, BZ9P(contextStr + "None_Register_bank"));
        if (pCfg->m_bGM == false) {
            NewINS(pHB, STSR(15, reg3, 2));                       // Load RBCR0
        } else {
            NewINS(pHB, STSR(5, reg3, 0));                         // Load PSW
            NewINS(pHB, SHR5(20, reg3));
            NewINS(pHB, ANDI(0xff, reg3, reg3));                   // PSW.EIMASK
            NewINS(pHB, ANDI(0xf0, reg3, reg1));                   // Check priority greater than 15 or not
            NewINS(pHB, BZ9P(contextStr + "Correct_priority_done"));
            NewINS(pHB, MOV5(15, reg3));

            NewINS(pHB, MOV5(1, reg1)->SetLabel(contextStr + "Correct_priority_done"));
            NewINS(pHB, SHL(reg3, reg1));
            NewINS(pHB, STSR(15, reg3, 2));                         // Load RBCR0
            NewINS(pHB, AND(reg3, reg1));					        // Checking whether == 0.
            NewINS(pHB, BZ9P(contextStr + "None_Register_bank"));
        }

        NewINS(pHB, STSR(0, reg2, 5));		// Save MPM
        NewINS(pHB, LDSR(0, 0, 5));			// disable MPM
        NewINS(pHB, SYNCI());

        NewINS(pHB, MOV32(96, reg1));							// Load 0x60 to reg1
        NewINS(pHB, SHR5(16, reg3));							// Shirt right reg3 16 bit.
        NewINS(pHB, ANDI(0x0001, reg3, reg3));					// Check reg3 bit 1 == 0.
        NewINS(pHB, BZ9P(contextStr + "Restore_bank_start"));
        NewINS(pHB, ADDI(48, reg1, reg1));						// Add reg1 with 0x30 when RBCR0.MD = 1.
        NewINS(pHB, STSR(17, reg3, 2)->SetLabel(contextStr + "Restore_bank_start")); // Load RBRN to reg3.
        NewINS(pHB, ADD5(-1, reg3));							// Decrease RBNR 1.
        NewINS(pHB, MULU(reg1, reg3, reg1));					// reg3 = (RBRN*Bank_size)
        NewINS(pHB, ADD5(4, reg3));							// Add Reg3 with position of PC. 
        NewINS(pHB, STSR(18, reg1, 2));							// Load RBIP to reg1.
        NewINS(pHB, SUB(reg3, reg1));							// reg3 = RBIP - (Banksize*RBNR + 4). (This is position of  current PC)
        NewINS(pHB, LDW16(0, reg1, reg3));					// Load PC from Register Bank.
        NewINS(pHB, STSR(0, reg, 0));							// Store EIPC value to reg

        NewINS(pHB, LDSR(reg2, 0, 5));							// Recover MPM
        NewINS(pHB, SYNCI());

        NewINS(pHB, CMPR(reg, reg3));
        NewINS(pHB, BNZ9P(contextStr + "None_Register_bank"));

        NewINS(pHB, STSR(15, reg3, 2));							// Load RBCR0 to reg3.
        NewINS(pHB, SHR5(16, reg3));							// Shirt right reg3 16 bit.
        NewINS(pHB, ANDI(0x0001, reg3, reg3));					// Check reg3 bit 1 == 0.
        NewINS(pHB, BNZ9P(contextStr + "Restore_bank_end"));
        NewINS(pHB, POPSP(20, 31));							// Restore r20 - r31 in case save mode0
        NewINS(pHB, ins = STSR(28, m_nHandlerReg, 0));			// Restore case m_nHandlerReg = r20 ~ r31

        //__Resbank
        NewINS(pHB, RESBANK()->SetLabel(contextStr + "Restore_bank_end"));
        NewINS(pHB, EIRET());
    }
	//! Return with out register bank backup.
	NewINS( pHB,  POPSP(1, 31)->SetLabel(contextStr + "None_Register_bank")) ;
	// Restore r3
	NewINS( pHB,  ins= MOVR(m_nHandlerReg, SP));
	NewINS( pHB, ins= STSR(28, m_nHandlerReg , 0) ) ;
	sprintf(str ,"r3= EIWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	pHB->AddOpeCode(EIRET());
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	return pHB;
}

CHandlerBlock*	CBlockManager::GenFixSyserrHandler(TBlockConfig* pCfg, CHandlerBlock* pHB) {
	
	IInstruction * ins ;
	char str[120] ;
	UI32 reg = m_nWorkReg;
	UI32 reg1 = reg + 1;
	std::string contextStr = GetMContext(pCfg);
	std::string label = pHB->GetLabel();
	// Read FEIC to get cause code
	NewINS( pHB,  STSR( 14, reg, 0)  );		
    NewINS( pHB,  ANDI(0x1f, reg, reg));

	// Cause code 0x1d. Resbank instruction is execute when RBNR.BN = 0 
	NewINS( pHB,  SATSUBI(0x1d, reg , reg1));
	NewINS( pHB,  BZ9P(label + "_syserr_needto_calculate_return_PC"));
	// Check cause code 0x1c. EIINT with register bank function when RBNR.BN = 16/255
	NewINS( pHB,  SATSUBI(0x1c, reg , reg1));			
	NewINS( pHB,  BNZ9P(label + "_check_other_cause_code") );

	// Disable EIINT acceptance
    if (pCfg->m_bNC == true && pCfg->m_bGM == true) {
        NewINS(pHB, STSR(16, reg, 1));                      
        NewINS(pHB, ANDI(0x1, reg, reg));					// HVCFG.HVE
        NewINS(pHB, BZ9P(label + "_update_FEPSW"));
        NewINS(pHB, STSR(5, reg, 9));
        NewINS(pHB, ORI(0x20, reg, reg));				    // Set GMPSW.ID = 1
        NewINS(pHB, LDSR(reg, 5, 9));
        NewINS(pHB, BR9P(label + "_syserr_reexecute_type"));
    }
	NewINS( pHB,  STSR(3, reg, 0)->SetLabel(label + "_update_FEPSW"));
	NewINS( pHB,  ORI(0x20, reg, reg));						// Set FEPSW.ID = 1
	NewINS( pHB,  LDSR(reg, 3, 0));
	NewINS( pHB,  POPSP(1, 31)->SetLabel(label + "_syserr_reexecute_type")) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB,  ins= STSR(29, m_nHandlerReg, 0) ) ;sprintf(str ,"r3= FEWR ; recover" ) ;
    NewINS( pHB,  FERET() );          // feret
	NewINS( pHB,  NOP() );

	// SYSERR cause code 0x18 when READ/WRITE into error memory.
	// Ins 1: ld reg, [error mem]
	// Ins 2: Random instruction <= SYSERR
	NewINS( pHB,  SATSUBI(0x18, reg , reg1)->SetLabel(label + "_check_other_cause_code"));
	NewINS( pHB,  BZ9P(label + "_syserr_reexecute_type") );

	// Increase PC before returning
	NewINS( pHB,  MOV32P("Handler_calculate_PC_revert_GRs_fe", reg)->SetLabel(label + "_syserr_needto_calculate_return_PC"));
	NewINS( pHB,  JMP32(reg) );

	// Unsupported/Unexpected syserr
	//NewINS( pHB,  STSR(  0, reg, 2)->SetLabel(label + "_syserr_does_not_support"));		// HTCFG0
	//NewINS( pHB,  MOV32( 0xffff7ffc, 9) );
 //   
	//NewINS( pHB,  MOV32( 0x0000f0f0, 10) );
	//NewINS( pHB,  STH16(10, 0U, 9) );
	//NewINS( pHB,  MOVEA(0x0010, 0, 10) );
	//NewINS( pHB,  STH16(10, 2U, 9) );

	//NewINS( pHB,  HALT() );
	//NewINS( pHB,  NOP() );
	//NewINS( pHB,  NOP() );
	//NewINS( pHB,  JR22P(label + "_check_other_cause_code"));
	//NewINS( pHB,  NOP() );
	//NewINS( pHB,  NOP() );
	//NewINS( pHB,  NOP() );

	return pHB;
}

CHandlerBlock*	CBlockManager::GenFixMPHandler(UI32 reg, std::string label, TBlockConfig* pCfg) {

	std::string contextStr = GetMContext(pCfg);	
	CHandlerBlock* pHB = new CHandlerBlock (label);
	pHB->SetOutputFlag(true);
    const UI32 jump_reg = 28;
    // Overwrite mismatch PC before backup register in HVTRAP handler
    NewINS(pHB, MOV32(g_rnd.Get(), jump_reg));

	NewINS(pHB, STSR(14, reg, 0));				// FEIC
    NewINS(pHB, ANDI(0xffU, reg, reg));

    if (m_MmList.Size() != 0) {
        g_prf->m_is_mpu = true;
        UI32 reg1 = reg + 1;
        UI32 mpcfg_hbe = (g_srs->GetNcInit(2, 5) >> 8) & 0x3f;
        m_MmList.RandomReserveEntry(pCfg->m_bGM, mpcfg_hbe);

        NewINS(pHB, SATSUBI(0x96U, reg, reg1));     // if cause code less than 0x96, exception occur in guest management, otherwise host management
        NewINS(pHB, BN9P(contextStr + "check_mpu_exception_gm"));
        NewINS(pHB, JR22P(contextStr + "check_mpu_exception_hm"));

        GenMpuHandler(pCfg, pHB, 0); // Generate MPU handler for exception occur in guest management
        GenMpuHandler(pCfg, pHB, 1); // Generate MPU handler for exception occur in host management
    }
	if (g_hwInfo.m_tlbnum != 0) {
    	GenMmuHandler(pCfg, pHB, reg) ;
	}

	NewINS( pHB, HALT()->SetLabel( contextStr + "fix_mp_handler_99")) ;
	NewINS( pHB, BR9P( contextStr + "fix_mp_handler_99"));
	NewINS( pHB, NOP());
	NewINS( pHB, NOP());
	return pHB;

}
CHandlerBlock*		CBlockManager::GenEITBLHandler(TBlockConfig* pCfg){
	std::string contextStr = GetMContext(pCfg);
	UI32 jump_reg = m_nHandlerReg;
	// Reference table for EIINT
	CHandlerBlock* pHB = new CHandlerBlock(contextStr + "eitbl_handler");
	pHB->SetAlign(512);
	std::map< UI32,IExceptionConfig*>& vExp = g_exp->GetException();
	std::map<UI32, IExceptionConfig*>::iterator itrExp;
	UI32 max_channel = 0;
	for(itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
		IExceptionConfig* pExpConfig = itrExp->second;
		if(pExpConfig->m_name.find("EITBL") != std::string::npos || pExpConfig->m_name.find("RBINT") != std::string::npos) {
			UI32 uchannel = pExpConfig->m_uchannel + 1;
			max_channel = uchannel > max_channel ? uchannel : max_channel;
		}
	}
	
	for(UI32 i = 0; i < max_channel; i++) {
		std::stringstream ss;
		std::string label;
		ss << contextStr << "vector_eiint" << std::setw(3) << std::setfill('0') << (i & 0xf);
		ss >> label;
		NewINS(pHB, _WORDP(label));
	}

	NewINS(pHB, JMP32(jump_reg)->SetLabel(contextStr + "eitbl_handler_init"));
	pHB->SetUserAddress(true);

	return pHB;

}

CHandlerBlock*	CBlockManager::GenFixDeBugHandler(UI32 reg, std::string label, TBlockConfig* pCfg){

	IInstruction * ins ;
	char str[120] ;
	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	
	CHandlerBlock* pHB = new CHandlerBlock( label);
	pHB->SetOutputFlag(true);
	SaveRegisterDB(pHB , "fix_debug") ;
	pHB->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_DB);
    //! Initialize for debug dump SReg
    NewINS( pHB,  MOV32P("break_channel_init", reg )); // break_channel_init用DBTRAP命令ならば
    NewINS( pHB,  STSR( 18, reg1, 3));
	NewINS( pHB,  SATSUBI( 2, reg1, reg1));
    NewINS( pHB,  CMPR( reg1, reg ));
    NewINS( pHB,  BNE17P("fix_debug_handler_00" ));

    NewINS( pHB, STSR(21, reg1, 3));     // get DIR1(r11)
    NewINS( pHB, MOV32(0xFFFFFF0F, reg2)); // DIR1.CSL 0 clear
    NewINS( pHB, AND(reg2, reg1));
    NewINS( pHB, LDSR(reg1, 21, 3));

    for( UI32 i = 0; i < 0xC; i++ ) { // 12 channels
		UI32 bpc = (UI32)g_rnd.GetRange((UI32)0, (UI32)0xffffffff);
		UI32 addr_mask = (UI32)g_rnd.GetRange((UI32)0, (UI32)0xffffffff);
		UI32 data_mask = (UI32)g_rnd.GetRange((UI32)0, (UI32)0xffffffff);

		if( g_exp->GetBreakPointWeight())
			g_exp->SetChannel(&bpc, &addr_mask, &data_mask);
        
        NewINS( pHB, MOV32(bpc, reg2));
        NewINS( pHB, LDSR(reg2, 22, 3)); // BPC init
        NewINS( pHB, MOV32((UI32)g_rnd.GetRange((UI32)0, (UI32)0xffffffff), reg2));
        NewINS( pHB, LDSR(reg2, 24, 3)); // BPAV init
		NewINS( pHB, MOV32(addr_mask, reg2));
		NewINS( pHB, LDSR(reg2, 25, 3)); // BPAM init
		NewINS( pHB, ADDI(16U, reg1, reg1));
        NewINS( pHB, LDSR(reg1, 21, 3));
    }

	NewINS( pHB,  NOP()->SetLabel("fix_debug_handler_00" ) );
	NewINS( pHB,  MOV32(g_wm.BREAK_INFO_PRESET, reg1) );
	NewINS( pHB,  LDW16(0, reg1, reg2));
	NewINS( pHB,  STW16(0, 0, reg1) );
	NewINS( pHB,  CMP5(0, reg2) );
	//If it is break setup, skip read system registers
	NewINS( pHB,  BNE17P( "fix_debug_handler_after_read_sys"));

	LoadSregOfException(pHB ,reg , "fix_debug", pCfg) ;

	NewINS( pHB,  STSR( 15,reg, 3)->SetLabel("fix_debug_handler_after_read_sys"));		//DBIC
	NewINS( pHB,  ANDI(0x00ffU, reg, reg));
	NewINS( pHB,  SATSUBI(0x00B0U, reg, reg));

	NewINS( pHB,  CMP5(1U,reg)->SetLabel("fix_debug_handler_10"));
	NewINS( pHB,  BE17P("fix_debug_handler_20")); //DBTRAP命令による例外処理へ
	NewINS( pHB,  CMP5(5U, reg));
	NewINS( pHB,  BE17P("fix_debug_handler_15")); //LSAB (sync.), PCB, AE
	NewINS( pHB,  CMP5(6U, reg));
	NewINS( pHB,  BE17P("fix_debug_handler_15")); //LSAB (async.)
	NewINS( pHB,  JR22P( "fix_debug_handler_30")); //DBINT, DBNMI

    //DBIC=0xB5,0xB6
    //ブレーク例外処理
	NewINS( pHB, MOV32P("dbpcInc_break", reg)->SetLabel("fix_debug_handler_15"));
	NewINS( pHB, JMP32(reg) );
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

    //DBTRAP命令による例外処理
//__fix_debug_handler_20:
	NewINS( pHB,  STSR( 18, reg1, 3)->SetLabel( "fix_debug_handler_20") );	//DBPC
	NewINS( pHB,  SATSUBI(2, reg1, reg1) );
	// Update DBGEN.GEx and DBGEN.HE
	NewINS( pHB,  STSR(15, reg, 0)); // Read PSWH
	NewINS( pHB,  SHR5(0x8, reg));
    NewINS( pHB,  ANDI(0x7, reg, reg));   // PSWH.GPID
	NewINS( pHB,  MOV5(0x1, reg2));
	NewINS( pHB,  SHL(reg, reg2)); //1 << GPID
	NewINS( pHB,  ORI(0x100, reg2, reg2)); // Enable debug exception in HV
	NewINS( pHB,  LDSR(reg2, 0, 3));

	NewINS( pHB,  MOV32P("debug_breaksetup", reg));
	NewINS( pHB,  JARL32(reg, 31)); // コードブロック先頭のDBTRAP命令ならば、ブレーク設定処理へ

    //DBTRAP/RMTRAP/DBHVTRAP命令による例外処理
//__fix_debug_handler_30:
	NewINS( pHB,  POPSP(1, 31)->SetLabel("fix_debug_handler_30") ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg, 3) ) ;
	sprintf(str ,"r3= DBWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_debug_handler_40:
	//ハードウェアデバッグ例外処理（DBIC=0xBC,0xBD,0xBE,0xBF）
	NewINS( pHB,  POPSP(1, 31)->SetLabel("fix_debug_handler_40") ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg, 3) ) ;
	sprintf(str ,"r3= DBWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	//__fix_debug_handler_50:	
	NewINS( pHB, MOV32P( "dbpcInc", reg)->SetLabel("fix_debug_handler_50") );
	NewINS( pHB, JMP32(reg) );
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	return pHB;
}


CHandlerBlock*	CBlockManager::GenPCIncDeBugHandler(UI32 reg, std::string label, TBlockConfig* pCfg){
	
	IInstruction * ins ;
	char str[120] ;
	std::string contextStr = GetMContext(pCfg);	
	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	UI32 reg3 = reg + 3;
	UI32 reg4 = reg + 4;
	CHandlerBlock* pHB = new CHandlerBlock( label);

	pHB->SetOutputFlag(true);

	NewINS( pHB,  STSR(8, reg4, 1));		// Save SVLOCK
	NewINS( pHB,  LDSR(0, 8, 1));			// Disable SVLOCK

	NewINS( pHB,  STSR( 0 ,reg2, 5)  );		// Save MPM
	NewINS( pHB,  LDSR(0, 0, 5) );			// disable MPM
	NewINS( pHB,  SYNCI());
	NewINS( pHB,  STSR( 18, reg1, 3)  );		// DBPC
	NewINS( pHB,  LDB16(1, reg1, reg));
	NewINS( pHB,  ANDI(6U, reg, reg));
	NewINS( pHB,  CMP5(6U, reg));
	NewINS( pHB,  BE17P("dbpcInc_1"));

	//	FP-SIMD Check Instruction length for UCPOP
	NewINS( pHB,  LDH16(0, reg1, reg));
	NewINS( pHB,  ANDI(0xFFFFU, reg, reg));
	NewINS( pHB,  MOV32(0x8840, reg3) );
	NewINS( pHB,  CMPR(reg, reg3));
	NewINS( pHB,  BE17P("dbpcInc_8"));
	NewINS( pHB,  MOV32(0x8040, reg3) );
	NewINS( pHB,  CMPR(reg, reg3));
	NewINS( pHB,  BE17P("dbpcInc_6"));

	NewINS( pHB,  LDHU16(0, reg1, reg));
	NewINS( pHB,  ANDI(0xFFE0U, reg, reg));
	NewINS( pHB,  SATSUBI(0x02E0U, reg, reg));
	NewINS( pHB,  BE17P("dbpcInc_6"));
	NewINS( pHB,  ADD5(2U, reg1));
	NewINS( pHB,  LDSR(reg1, 18, 3) );			// DBPC <- r31
	NewINS( pHB,  JR22P("dbpcInc_ret"));

	//__dbpcInc_1:
	NewINS( pHB,  LDHU16(0, reg1, reg3)->SetLabel("dbpcInc_1"));
	NewINS( pHB,  ANDI(0x7C0U, reg3, reg));
	NewINS( pHB,  SATSUBI(0x0780U,reg,reg));
	NewINS( pHB,  BNE17P("dbpcInc_4"));

	NewINS( pHB,  ANDI(0xF800U, reg3, reg));
	NewINS( pHB,  BNE17P("dbpcInc_3"));	// LD.BU or JARL
	NewINS( pHB,  LDH16(2, reg1, reg3));
	NewINS( pHB,  ANDI(31U, reg3, reg));
	NewINS( pHB,  SATSUBI(27U, reg, reg));
	NewINS( pHB,  BNE17P("dbpcInc_2"));
	NewINS( pHB,  ADD5(8U, reg1)->SetLabel("dbpcInc_8"));
	NewINS( pHB,  LDSR(reg1, 18, 3) );			// DBPC <- r31
	NewINS( pHB,  JR22P("dbpcInc_ret"));

	//__dbpcInc_2:
	NewINS( pHB,  ANDI(31U, reg3, reg)->SetLabel("dbpcInc_2"));
	NewINS( pHB,  SATSUBI(1U, reg, reg));
	NewINS( pHB,  BE17P("dbpcInc_3"));	// PREPARE_NO_EPWB
	NewINS( pHB,  SATSUBI(2U, reg, reg));
	NewINS( pHB,  BE17P("dbpcInc_3"));	// PREPARE_SPWB_EP
	NewINS( pHB,  ANDI(1U, reg3, reg));
	NewINS( pHB,  BE17P("dbpcInc_3"));	// JR

	//_dbpcInc_6:
	NewINS( pHB,  ADD5(6U, reg1)->SetLabel("dbpcInc_6"));
	NewINS( pHB,  LDSR(reg1, 18, 3) );			// FEPC <- r31
	NewINS( pHB,  JR22P("dbpcInc_ret"));

	//__dbpcInc_4:
	NewINS( pHB,  ANDI(0xffe0U, reg3, reg)->SetLabel("dbpcInc_4"));
	NewINS( pHB,  SATSUBI(0x620U, reg, reg));
	NewINS( pHB,  BE17P("dbpcInc_6"));	// MOVW
	NewINS( pHB,  ANDI(0xffe0U, reg3, reg));
	NewINS( pHB,  SATSUBI(0x6E0U, reg, reg));			// JMPW or LOOP
	NewINS( pHB,  BNE17P("dbpcInc_3"));
	NewINS( pHB,  LDHU16(2, reg1, reg3));
	NewINS( pHB,  ANDI(0x1U, reg3, reg));
	NewINS( pHB,  BE17P("dbpcInc_6"));	// JMPW

	//__dbpcInc_3:
	NewINS( pHB,  ADD5(4U, reg1)->SetLabel("dbpcInc_3"));
	NewINS( pHB,  LDSR(reg1, 18, 3) );			// FEPC <- r31

	//__dbpcInc_ret:
	NewINS( pHB,  LDSR(reg2, 0, 5)->SetLabel("dbpcInc_ret"));	// Recover MPM
	NewINS( pHB,  SYNCI());

	NewINS( pHB,  LDSR(reg4, 8, 1));			// Recover SVLOCK

	NewINS( pHB,  POPSP(1, 31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30, m_nHandlerReg, 3) ) ;
	sprintf(str ,"r3= DBWR ; recover") ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	return pHB;
}


CHandlerBlock*	CBlockManager::GenPCIncBreakPointHandler(UI32 reg, std::string label, TBlockConfig* pCfg){
	
	IInstruction * ins ;
	char str[120] ;
	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	UI32 reg3 = reg + 3;
	UI32 reg4 = reg + 4;
	UI32 num_of_channels = g_exp->GetNumOfChannels();

	CHandlerBlock* pHB = new CHandlerBlock( label);
	pHB->SetOutputFlag(true);
	NewINS( pHB,  STSR(20, reg1, 3)); // get DIR0(reg1)
    NewINS( pHB,  ANDI(0x100, reg1, reg2));
    NewINS( pHB,  BE17P("dbpcInc_not_at"));
    NewINS( pHB,  XORI(0x300, reg1, reg1));
    NewINS( pHB,  LDSR(reg1, 20, 3)); // set DIR0.AT=0,AEE=0

    // DIR1.BT11-0をチェックして、チャネル設定をループ処理
//__dbpcInc_not_at
    NewINS( pHB,  MOV32( 0x0, reg1 )->SetLabel("dbpcInc_not_at"));       // CSL(reg1) = 0
    NewINS( pHB,  STSR(21, reg3 , 3)  );     // get DIR1(reg3)
    NewINS( pHB,  MOV32(0x00000100, reg4));  // BT_Mask(reg4)

//__dbpcInc_loop0:
    NewINS( pHB,  MOVR(reg3, reg2)->SetLabel("dbpcInc_loop0"));
    NewINS( pHB,  AND(reg4, reg2));
    NewINS( pHB,  BNE17P("dbpcInc_clear")); // チャネル設定クリア処理へ

//__dbpcInc_loop1:
    NewINS( pHB,  ADDI(16U,reg1,reg1)->SetLabel("dbpcInc_loop1")); // CSL + 1
	NewINS( pHB,  SATSUBI((num_of_channels << 4),reg1,reg));                                  // TODO：max channelを代入して、ループ回数を削減すること
	NewINS( pHB,  BE17P("dbpcInc_loopend")); //全てのチャネルのチェック完了

    NewINS( pHB,  SHL5(1U, reg4));           //次のBT
    NewINS( pHB,  JR22P("dbpcInc_loop0"));

    // チャネル設定クリア処理
    NewINS( pHB,  XOR(reg4, reg3)->SetLabel("dbpcInc_clear")); // BT clear
    NewINS( pHB,  MOV32(0xFFFFFF0F, reg));
    NewINS( pHB,  AND(reg, reg3));
    NewINS( pHB,  OR(reg1, reg3));
    NewINS( pHB,  LDSR(reg3, 21, 3) );                // set DIR1.CSL
    NewINS( pHB,  STSR(22, reg2, 3));                 // get BPC(reg2)

	NewINS( pHB,  ANDI(0xF3, reg3, reg));                         // Get DIR1.CSL, SQ0, BEN
	NewINS( pHB,  CMP5(0x03,reg)); 
	NewINS( pHB,  BE17P("dbpcInc_notclear_EO"));  // Not clear EO in Sequential Channel

	NewINS( pHB,  ANDI(0x25, reg3, reg));                         // Get DIR1.CSL, SQ1, BEN
	NewINS( pHB,  MOV32(0x25, reg3));
	NewINS( pHB,  CMPR(reg3, reg));
	NewINS( pHB,  BE17P("dbpcInc_notclear_EO"));  // Not clear EO in Sequential Channel

	NewINS( pHB,  MOV32(0xFFFFFFC0, reg));                     // clear BPC.EO,TE,BE,FE,WE,RE
	NewINS( pHB,  AND(reg, reg2));
	NewINS( pHB,  LDSR(reg2, 22, 3));                            // set BPC
	NewINS( pHB,  JR22P("dbpcInc_loop1"));

	NewINS( pHB,  MOV32(0xFFFFFFE0, reg)->SetLabel("dbpcInc_notclear_EO"));          // clear BPC.TE,BE,FE,WE,RE
	
	NewINS( pHB,  AND(reg, reg2));
	NewINS( pHB,  LDSR(reg2, 22, 3));                 // set BPC
	NewINS( pHB,  JR22P("dbpcInc_loop1"));

//__dbpcInc_loopend:
	NewINS( pHB,  POPSP(1,31)->SetLabel("dbpcInc_loopend")) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg,3) ) ;
	sprintf(str ,"r3= DBWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	return pHB;
}
/**
 * @brief	指定コードブロックにCUビットを書き換える命令を追加する。
 * @param	pCB     命令追加するコードブロック
 * @param	reg     CUビットを書き換える処理に使用するレジスタのインデックス値    
 * @param	cubits  CUビット値
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::SwitchCoProcessor(CCodeBlock* pCB, UI32 reg, UI32 cubits) {
	
	FROG_ASSERT(pCB);
	
	reg &=0x1e; // take even index
	reg = (reg & 0x1e) ? (reg & 0x1e) : 6;
	NewINS( pCB, STSR( 5, reg, 0) );
	NewINS( pCB, MOV32(0xFFF8FFFFU,(reg+1)) );
	NewINS( pCB, AND((reg+1), reg) );
	NewINS( pCB, MOV32((cubits<<16),(reg+1)) );
	NewINS( pCB, OR((reg+1), reg) );
	NewINS( pCB, LDSR( reg, 5, 0) );
	
	return pCB;
}


/**
 * @brief	指定コードブロックにユーザーモード遷移する命令を追加する。
 * @param	pCB     命令追加するコードブロック
 * @param	reg     CUビットを書き換える処理に使用するレジスタのインデックス値    
 * @param	cubits  CUビット値
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::TransUserMode(CCodeBlock* pCB, UI32 reg1, UI32 reg2, TBlockConfig* pCfg) {
	
	FROG_ASSERT(pCB);
	UI32 psw_regID = 1, psw_selID = 0, psw_val = 0;
	psw_val = g_srs->GetNcInit(5, 0);
	if(pCfg->m_bGM == true) {
		// GMPSW
		psw_regID = 5;
		psw_selID = 9;
		psw_val = g_srs->GetNcInit(5, 9);
	}
	psw_val |= 0x40000000;
	NewINS( pCB, MOV32(psw_val, reg2) );						// mov  0x80000000, reg2
	NewINS( pCB, LDSR(reg2, psw_regID, psw_selID) );			// ldsr reg2, EIPSW/GMPSW
	
	return pCB;
}

/**
* @brief    Transfer to corresponding Guest Mode with GPID
*/
CCodeBlock* CBlockManager::TransGuestMode(CCodeBlock* pCB, UI32 reg1, UI32 reg2, TBlockConfig * pCfg) {
    
    FROG_ASSERT(pCB);
	if(pCfg->m_bGM == true )
		pCfg->m_bNC = false;

    std::string label = GetTContext(pCfg) + "codeblock_00";
    pCfg->m_bNC = true;
    // MPM
    if (m_MmList.Size() != 0) {
        UI32 mpm = g_srs->GetNcInit(0, 5);
        NewINS(pCB, MOV5(mpm, reg1));
        NewINS(pCB, LDSR(reg1, 0, 5));
    }

    // Update register EIPSW by PSW
    UI32 psw_val = 0;
    psw_val = g_srs->GetNcInit(5, 0);
    NewINS(pCB, MOV32(psw_val, 29)->Note("-> Update EIPSW by PSW"));
    NewINS(pCB, LDSR(29, 1, 0)->Note("-> Update EIPSW by PSW"));

	// Start random code
    NewINS(pCB, MOV32P(label, reg1));
    NewINS(pCB, LDSR(reg1, 0, 0));			// ldsr reg2, EIPC
	if (pCfg->m_bGM == true) {
		UI32 pswh = g_srs->GetNcInit(15, 0) | 0x80000000;
		pswh |= (pCfg->m_GMID << 8);
		NewINS(pCB, MOV32(pswh, reg2));
		NewINS(pCB, LDSR(reg2, 18, 0));		// upate EIPSWH
        NewINS(pCB, LDSR(reg2, 19, 0));		// update FEPSWH
	}
    NewINS(pCB, EIRET());

    return pCB;
}


/**
 * @brief	MMU設定コードの生成
 * @param	pCB     命令追加するコードブロック
 * @param	reg     処理に使用するレジスタのインデックス値    
 * @param	pCfg    設定情報
 * @param	tlb_setting ＴＬＢエントリー情報リストへのポインタ。
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::MmuConfig(CCodeBlock* pCB , UI32 reg , TBlockConfig* pCfg ) {
	std::string contextStr = GetMContext(pCfg);
	
	NewINS(pCB, MOV32P("set_work_ptr", reg) );
	NewINS(pCB, JARL32(reg, 31) );
	UI32 memreg=    (reg != 16) ? 16 : 22 ;
	UI32 slot_reg=  (reg != 17) ? 17 : 22 ;
	UI32 count_reg= (reg != 18) ? 18 : 22 ;
	UI32 item_reg=  (reg != 19) ? 19 : 22 ;
	UI32 index_reg= (reg != 20) ? 20 : 22 ;
	UI32 table_reg= (reg != 21) ? 21 : 22 ;

	NewINS( pCB, MOVHI((SI32)(SI16)0x8000,0 ,reg) );
	NewINS( pCB, LDSR(reg, 15 ,1) );					// VCSEL.NC= 1 ;

	//!・Clear V-bit
	NewINS( pCB, LDVC_SR(0, 7 ,4) );					// TEHI1= 0 ;
	NewINS( pCB, MOVEA(64, 0 ,reg));
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_01" ));
	NewINS( pCB, LDVC_SR(reg, 0 ,4) );					// TEBIDX= *(memreg) ;
	NewINS( pCB, TLBW() );
	NewINS( pCB, ADD5(-1, reg) );
	NewINS( pCB, BC17P( contextStr + "mmu_setting_01" ));

	//!・Set TLB-Entry
	NewINS( pCB, MOVR(0, index_reg) );
	NewINS( pCB, MOV32P( contextStr + "tlb_setting_index" ,memreg) );
	NewINS( pCB, LDH16(0 ,memreg ,slot_reg) ) ;		// GR[slot_reg]= *(insigned short *)(GR[memreg]) ;
	NewINS( pCB, ADD5( 4, memreg) );				// GR[memreg] += 4 ;
	NewINS( pCB, CMP5(0 ,slot_reg) ) ;				// if (GR[slot_reg] == 0) then "HALT" ;
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_11"));
	NewINS( pCB, HALT()->SetLabel( contextStr + "mmu_setting_10") );
	NewINS( pCB, BR9P( contextStr + "_mmu_setting_10") );
	NewINS( pCB, NOP());
	NewINS( pCB, NOP());
	//!・DemandSlot情報を設定
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_11") );
	NewINS( pCB, LDH16(0 ,memreg ,count_reg) ) ;	// GR[count_reg]= *(insigned short *)(GR[memreg]) ;
	NewINS( pCB, LDH16(2 ,memreg ,item_reg) ) ;		// GR[item_reg]=  __tlb_setting_table + *(unsigned short *)(GR[memreg]+2) * 4 ;
	NewINS( pCB, SHL5(4 ,item_reg) ) ;
	NewINS( pCB, MOV32P( contextStr + "tlb_setting_table" ,reg) );
	NewINS( pCB, ADD(reg , item_reg) );
	NewINS( pCB, STH16(0 ,g_wm.OFS_DTLB_INFO ,27) ) ;
	NewINS( pCB, STH16(count_reg ,g_wm.OFS_DTLB_INFO+2 ,27) ) ;
	NewINS( pCB, ADDI(g_wm.OFS_DTLB_INFO+4 ,27 ,table_reg) );
	//TODO: index_regは、乱数で空いているTLBを探して決める。
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_12") );
	NewINS( pCB, LDVC_SR(index_reg, 0 ,4) );		// TLBIDX= index_reg ;
	NewINS( pCB, STH16(index_reg ,0 ,table_reg) ) ;
	NewINS( pCB, ADD5(1, index_reg) );
	//
	NewINS( pCB, LDW16(0 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 5 ,4) );				// TELO1= *(memreg) ;
	NewINS( pCB, LDW16(4 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 4 ,4) );				// TELO0= *(memreg +4) ;
	NewINS( pCB, LDW16(8 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 7 ,4) );				// TEHI1= *(memreg +8) ;
	NewINS( pCB, LDW16(12 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 6 ,4) );				// TEHI0= *(memreg +12) ;
	NewINS( pCB, TLBW() );
	NewINS( pCB, ADDI(0x0010, item_reg, item_reg) );
	NewINS( pCB, ADD5(2, table_reg) );
	NewINS( pCB, ADD5(-1, count_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_12"));
	NewINS( pCB, ADD5( 4, memreg) );
	NewINS( pCB, ADD5(-1, slot_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_21"));
	NewINS( pCB, HALT()->SetLabel( contextStr + "mmu_setting_13"));
	NewINS( pCB, BR9P( contextStr + "mmu_setting_13"));
	NewINS( pCB, NOP());
	NewINS( pCB, NOP());


	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_21") );
	NewINS( pCB, LDH16(0 ,memreg ,count_reg) ) ;	// GR[count_reg]= *(insigned short *)(GR[memreg]) ;
	//TODO: ＴＬＢエントリー数制限が必要
	NewINS( pCB, LDH16(2 ,memreg ,item_reg) ) ;		// GR[item_reg]=  __tlb_setting_table + *(unsigned short *)(GR[memreg]+2) * 4 ;
	NewINS( pCB, SHL5(4 ,item_reg) ) ;
	NewINS( pCB, MOV32P( contextStr + "tlb_setting_table" ,reg));
	NewINS( pCB, ADD(reg , item_reg) );
	
	NewINS( pCB, CMP5(0 ,count_reg) ) ;
	NewINS( pCB, BE17P( contextStr + "mmu_setting_90") );
	//TODO: index_regは、乱数で空いているTLBを探して決める。
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_22") );
	NewINS( pCB, LDVC_SR(index_reg, 0 ,4) );		// TLBIDX= index_reg ;
	NewINS( pCB, ADD5(1, index_reg) );
	//
	NewINS( pCB, LDW16(0 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 5 ,4) );				// TELO1= *(memreg) ;
	NewINS( pCB, LDW16(4 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 4 ,4) );				// TELO0= *(memreg +4) ;
	NewINS( pCB, LDW16(8 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 7 ,4) );				// TEHI1= *(memreg +8) ;
	NewINS( pCB, LDW16(12 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 6 ,4) );				// TEHI0= *(memreg +12) ;
	NewINS( pCB, TLBW() );
	NewINS( pCB, ADDI(0x0010, item_reg, item_reg) );
	NewINS( pCB, ADD5(-1, count_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_22"));
	NewINS( pCB, ADD5( 4, memreg) );
	NewINS( pCB, ADD5(-1, slot_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_21"));
	//!・ITLBE デマンド・エントリー情報をクリア
	NewINS( pCB, MOV5(-1 ,reg) ) ;
	NewINS( pCB, MOV32(g_wm.BASE_PE_HT,table_reg) ) ;
	NewINS( pCB, MOVEA(64, 0 ,count_reg) );
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_30") );
	NewINS( pCB, STW16(reg ,g_wm.OFS_ITLB_INFO ,table_reg ) );
	NewINS( pCB, ADDI(g_wm.SIZE_HT, table_reg ,table_reg) );
	NewINS( pCB, ADD5(-1 ,count_reg) ) ;
	NewINS( pCB, BNC17P( contextStr + "mmu_setting_30") );
	//
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_90") );
	NewINS( pCB, STSR(0 ,reg ,1) );					// MCFG0.MM= 1 ;
	NewINS( pCB, ORI(8,reg,reg) );	
	NewINS( pCB, LDSR(reg, 0 ,1) );


	//!▽リターン。<BR><BR>
	return (pCB) ;
}


std::vector<CPrologueBlock*>* CBlockManager::GeneratePrologue( TBlockConfig* pCfg ) {
	//!<BR>[処理細目]<BR>

	std::vector<CPrologueBlock*>* vNode = new std::vector<CPrologueBlock*>();
	std::string contextStr = GetMContext(pCfg);

	UI32 workReg;
	do {
		workReg = g_rnd.GetRange(4, 25);
	} while(workReg == m_nHandlerReg );

	CPrologueBlock* pPB = new CPrologueBlock( contextStr + "prologue" );
	UI32 reg = g_rnd.GetRange((UI32)7,(UI32)15);

	// Updated RBIP for Register bank feature.
		if (g_RegisterBankAddr.Count()) {
			MEMADDR RBIP = g_RegisterBankAddr.SelectValue();
			NewINS(pPB, MOV32(RBIP, workReg) );
		} else {
			const UI32 BankSizeMax = (0x90 << 6);	  // maximum each bank size 0x90  and there 64 banks.
			std::set<MEMRANGE> smr = g_StorableAddr.KeySet();
			std::set<MEMRANGE>::iterator sitr;
			std::vector<MEMADDR> vRBIP;

			for (sitr = smr.begin(); sitr != smr.end(); sitr++) {
				MEMADDR alignedAddr = ((sitr->first | 0x0000003f) + 1);	 // upper boundary alignment.
				if ((sitr->second - alignedAddr) >= BankSizeMax ){
					vRBIP.push_back( g_rnd.GetRange(alignedAddr + BankSizeMax, sitr->second) );
				}
			}
			if (vRBIP.size())  {
				MEMADDR  RBIP = vRBIP[g_rnd.GetRange((UI32)0, (UI32)vRBIP.size() - 1)];
				NewINS(pPB, MOV32(RBIP, workReg) );
			} else {
				MSG_WARN(0, "Can not find valid memory area for RBIP. RESBANK instruction will be omitted.\n");
				m_nrmSet.SetWeight(INS_ID_RESBANK, 0);
			}
		}
		NewINS(pPB, LDSR(workReg, 18, 2));							// RBIP
		NewINS(pPB, NOP()->Note("Preset_Register_Bank_Area_000"));	// NOP 

	// Prologue in NC
	if (pCfg->m_bNC == true) {

		if(g_srs->IsInit(4, 1, CSysRegSet::CONTEXT_NC) == false) {
			// EITBL reference table
			NewINS(pPB, MOV32P(contextStr + "eitbl_handler", workReg) );
			NewINS(pPB, LDSR(workReg, 4, 1)->Note("->INTBP"));	//INTBP
			NewINS(pPB, MOV32P( contextStr + "eitbl_handler_init", workReg) );
			NewINS(pPB, JARL32(workReg, m_nHandlerReg) );
			NewINS(pPB, NOP() );
		} else
			MSG_WARN(0, "Use user define EIINT reference table in NC context.\n");
		// Prologue for Convention mode
		if(pCfg->m_bGM == false ) {
			if (g_srs->IsInit(20, 0, CSysRegSet::CONTEXT_NC) == false) {
				// CTBP設定しておく
				NewINS(pPB, MOV32P(contextStr + "callt_init_entry", workReg) );
				NewINS(pPB, LDSR(workReg, 20, 0)->Note("HT0:CTBP"));	// CTBP
			} else {
				MSG_WARN(0, "Use user define CALLT codeblock in NC context.\n");
			}
			if (g_srs->IsInit(12, 1, CSysRegSet::CONTEXT_NC) == false) {
				NewINS(pPB, MOV32P(contextStr + "syscall_init_entry", workReg) );
				NewINS(pPB, LDSR(workReg, 12, 1)->Note("NC:SCBP"));	// SCBP
			} else {
				MSG_WARN(0, "Use user define SYSCALL codeblock in NC context.\n");
			}
			//!・When MPU is installed, generate prologue processing for MPU
			if (m_MmList.Size() != 0) {
                InitMPURegister(pPB, reg, pCfg);
			}
		}		
		
		// Break Channel INIT
		NewINS(pPB, DBTRAP()->SetLabel("break_channel_init"));

		// NATIVE
		//!・CUビットを書き換える命令を生成
		SwitchCoProcessor(pPB, workReg, 3);	// Enable Co-Processor

		//pCfg->m_bNC = true;
		//!・ prefix + "synchronized" にジャンプする命令を生成
		//NewINS( pPB, MOV32P( (GetTContext(pCfg) + "synchronized").c_str(), workReg) );
		//NewINS( pPB, JMP32(workReg) );
	// Prologue for Virtual machine
	} else {
		//GMEBASE
		if(g_srs->IsInit(19, 9, CSysRegSet::CONTEXT_NC) == false) {
			NewINS(pPB, MOV32P(contextStr + "vector_reset", workReg) );
			NewINS( pPB, LDSR(workReg, 19, 9)->Note("->GMEBASE") );
			NewINS( pPB, NOP() );
		} else {
			MSG_WARN(0, "Use user define GMEBASE for Guest Mode.\n");
		}	    
	    //GMINTBP
		if(g_srs->IsInit(20, 9, CSysRegSet::CONTEXT_NC) == false) {
			NewINS(pPB, MOV32P(contextStr + "eitbl_handler", workReg) );
			NewINS(pPB, LDSR(workReg, 20, 9)->Note("->GMINTBP") );
			NewINS(pPB, MOV32P(contextStr + "eitbl_handler_init", workReg) );
			NewINS(pPB, JARL32(workReg, m_nHandlerReg) );
			NewINS(pPB, NOP() );
		} else {
			MSG_WARN(0, "Use user define EIINT reference table in VC context for Guest Mode.\n");
		}

		// CTBP
		NewINS(pPB, MOV32P(contextStr + "callt_init_entry", workReg) );
		NewINS(pPB, LDSR(workReg, 20, 0)->Note("->CTBP"));

		//SCBP
		NewINS(pPB, MOV32P(contextStr + "syscall_init_entry", workReg) );
		NewINS(pPB, LDSR(workReg, 12, 1)->Note("->SCBP"));
		
		//!・When MPU is installed, generate prologue processing for MPU
		if (m_MmList.Size() != 0) {
            InitMPURegister(pPB, reg, pCfg);
		}
	}
		//!・ prefix + "synchronized" にジャンプする命令を生成
		NewINS( pPB, MOV32P( (GetTContext(pCfg) + "synchronized").c_str(), workReg) );
		NewINS( pPB, JARL32(workReg, 30) );

		// Jump return to preload next VM
		if (pCfg->m_bNC == false)		
			NewINS( pPB, JMP32(31) );

	
	vNode->push_back(pPB);
	return vNode;
}


std::vector<CSyncBlock*>* CBlockManager::GenerateSync( TBlockConfig* pCfg ) {
	std::vector<CSyncBlock*>* vNode = new std::vector<CSyncBlock*>();
	std::string contextStr = GetTContext(pCfg);
	const UI32 returnReg = 30;
	CSyncBlock* pSB = new CSyncBlock( contextStr + "synchronized");
	//!・ ＰＥ同期処理
	IInstruction* pIns = NOP();
	pIns->AppendComment("Wait other PE to start simulation.");
	NewINS ( pSB, pIns );

    if (pCfg->m_bNC == true) {

        // NM生成時
        AddPeNotifyStandby(pCfg, pSB);					// 自ＰＥ準備完了フラグをセット
        if (g_cfg->m_nSysPeNum != 0) {
            // マスターＰＥは他のＰＥの準備完了をチェックする。
            AddPeWaitStandby(pCfg, pSB);                // 全ＰＥ準備完了待ち
            AddSysNotifyStandby(pCfg, pSB);             // 全ＰＥ準備完了フラグをセット
        } else {
            // マスターＰＥ以外はマスターＰＥがチェック完了するのを待つ。
            AddWaitStandby(pCfg, pSB);                  // 全ＰＥ準備完了フラグのセット待ち
        }
		SyncStandbyGoNext(pCfg, pSB);                       //!・ "__codeblock_0" にジャンプする命令を生成
		//Init index value (using to trace the memory that store)
		ExpReturnPcInit();
        TransGuestMode(pSB, 29, 30, pCfg);

		vNode->push_back(pSB);

		pSB = new CSyncBlock("permit_exec_cur_PC");
		pSB->SetOutputFlag(true);
		{
			UI32 reg = m_nHandlerReg;
			UI32 pc_reg = reg + 1;
			UI32 mip_demand_gm = g_prf->m_mpdemand[0] >> 16;
			UI32 newMPIDx = g_hwInfo.m_mpnum - 1;
			while(g_prf->IsWorkMPURegionByIdx(newMPIDx)) {
				newMPIDx = g_rnd.GetRange((UI32)0, (UI32)g_hwInfo.m_mpnum - 1);
			}
			// Guest management
			NewINS( pSB, MOV32(mip_demand_gm, reg));
			NewINS( pSB, LDSR(reg, 16, 5));				// MPIDX
			NewINS( pSB, SATSUBI(0xBF4, pc_reg, reg));	// Calculate lower boundary
			NewINS( pSB, LDSR(reg, 20, 5));				// MPLA
			NewINS( pSB, ADDI(0xBF4, pc_reg, reg));		// [FROG]TODO: Fix me (0xBF4)
			NewINS( pSB, LDSR(reg, 21, 5));				// MPUA

			NewINS( pSB, MOV32(newMPIDx, reg));			// Randomize not constrainted MPIDX
			NewINS( pSB, LDSR(reg, 16 , 5));			// MPIDX
			NewINS( pSB, SYNCI());
			NewINS( pSB, JMP32(pc_reg) );				// return code
		}
		vNode->push_back(pSB);
	} else {

        //Backup GM here. Last GM does not backup because FROG run it at first
		if(pCfg->m_GMID != g_cfg->m_mGMs.rbegin()->first) {
			const UI32 regMem = 3;
			UI32 addr = g_wm.BACKUP_RESTORE_GM_RESOURCE + 660 * pCfg->m_GMID;
			NewINS( pSB, MOV32P(contextStr + "codeblock_00", regMem));
			NewINS( pSB, LDSR(regMem, 0, 0) ); //EIPC
			SyncStandbyGoNext(pCfg, pSB);
			NewINS( pSB, MOV32(addr, regMem));
			BackupMachineResource(pSB, regMem, IExceptionConfig::EXP_LEVEL_EI); // Backup level EI
		}
		// Return to GM prologue
		NewINS( pSB, JMP32(returnReg) );
		vNode->push_back(pSB);
		
	}
	if (g_cfg->m_bPrefAssist) {
    		//! Prefech
    	pSB = new CSyncBlock(contextStr + "PrefetchMode");
    	NewINS( pSB, JMP32(29) ); // return code
    	vNode->push_back(pSB);
	}

	return vNode;
}

CUserBlock* CBlockManager::GenerateUserBlock(LPCTSTR context_key, TBlockConfig* pCfg, std::string labelStr) {

	std::string label("");
	std::stringstream ss;
	ss << GetTContext(pCfg);
	ss << labelStr;
	ss >> label;

	CUserBlock* pUb = new CUserBlock(label);
	pUb->SetOutputFlag(true);
	pUb->EnableRegulation(false);
	pUb->SetKeyName(context_key, labelStr.c_str());

	if(labelStr != "uc_handler") {
		const UI32 ADDR = g_wm.BASE_PE + g_wm.SIZE_PE;
		UI32 reg = 5;

		NewINS(pUb, MOV32(ADDR, reg));
		NewINS(pUb, STW16(31, 0, reg)); // Backup r31

		// Insert User Code to simulate
		std::vector <std::string>	vUcBody;
		g_usf->GetUserCodeBody(labelStr, vUcBody);
		ParseUserCode(vUcBody, pUb);

		NewINS(pUb, MOV32(ADDR, reg));
		NewINS(pUb, LDW16(0, reg, 31)); // Restore r31
		NewINS( pUb, JMP32(31) );
	} else {
		// Generate Handler User code Area section.
		pUb->SetOutputFlag(false);
		GetUserHanlderBody(CLabel::m_prefix + "_usercode_area", pUb);
	}
	
	return pUb;
}
std::vector<CPreloadBlock*>* CBlockManager::GenerateSetupBlock(TBlockConfig* pCfg) {

	std::string contextStr = GetMContext(pCfg);
	std::vector<CPreloadBlock*>* vNode = new std::vector<CPreloadBlock*>();
	CPreloadBlock* pPB = nullptr;

	pPB = GenerateDebugBreakSetUpBlock(pCfg, 31);
	vNode->push_back(pPB);

	return vNode;

}

CCodeBlock* CBlockManager::GenerateRandomBlock(TBlockConfig* pCfg) {

	
	UI32 nFixedReg1 = 0, nFixedReg2 = 0;
	COprSR::m_pSrSource = pCfg->m_pSrSet;

	std::string labelStr("");
	std::stringstream ss;
	ss << GetTContext(pCfg);
	ss << "codeblock_";
	ss << std::dec << std::setw(2) << std::setfill('0') << (pCfg->N);
	ss >> labelStr;
 
	// UserMode && NO PIE
	if (g_prf->IsUserMode(pCfg->m_bGM , pCfg->m_GMID)) {
		// WeightSet 
		// User MODE - filter SV/HV INS
		BS_IPRV bsp(0);
		bsp[IInstruction::IPRIV_SV]	= 1;
		bsp[IInstruction::IPRIV_HV]	= 1;
		bsp[IInstruction::IPRIV_DB]	= 1;
		m_nrmSet.FilterPriviledge(bsp, 0);
		m_nrmSet.ReCalc();
		//pset->Dump();
	}

	CCodeBlock* pCB;
	switch (g_cfg->m_nBlockMix) {
	case 0:		// free
		pCB = GenerateGrBlock(pCfg->N, pCfg->InsNum, 0, pCfg->pInsSet);
		break;
		
	case 1:		// focus 1 reg
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCB = GenerateGrBlock(pCfg->N, pCfg->InsNum, nFixedReg1, pCfg->pInsSet);
		break;

	case 2:		// mix 2 reg interlaced
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCB = GenerateGrBlock(pCfg->N, pCfg->InsNum/2, nFixedReg1, pCfg->pInsSet);
		nFixedReg2 = g_rnd.GetRange(1U, 31U);
		pCB = this->MixBlock (GenerateGrBlock(pCfg->N, pCfg->InsNum/2, nFixedReg2, pCfg->pInsSet), pCB);
		break;
		
	default:	// free generation
		pCB = GenerateGrBlock(pCfg->N, pCfg->InsNum, 0, pCfg->pInsSet);
		break;
	}

    // Expand Sequential Instruction
	ExpandSequentialInstruction(pCB);

	// Support bias register to increase register dependance
	IncRegisterDependance(pCB, nFixedReg1, nFixedReg2);

	// 静的な解析からパタンの整合性をとる
	pCB->SetLabel(labelStr);
	// 複合命令を展開する
	ExpandComplexInstruction(pCB, pCfg);

	// Replace mismatched register that was used as src
    RemoveMismatchReg(pCB);

	// Check whether C2B1 is combined by random generation
	CombineC2B1(pCB);

	// Adjust system register
	UpdateAccessSysReg(pCB, pCfg);

	// 伝搬レジスタを切断する(#10198)
	RemoveRegDependance(pCB);
	
	// R-Type補正（汎用レジスタの重複（Base = {Step/Index}）を除外）
	RTypeVerify(pCB);
	
	// JARL補正（Jarlの飛び先を設定する=ラベル化）
	LabelingJarl(pCB, GetMContext(pCfg));

	MakeLoopSequence(pCB);

	// Switch補正（SWITCHテーブルの挿入）
	// テーブルとSwitchジャンプ先を結びつけるので
	// これ以後、命令を挿入する場合は注意する 
	SwitchPresetTable(pCB);
	
	pCB->SetStatistics(true);
	
	ChainBcondSequence(pCB);// Labelが付いた後

	return pCB;
}

void CBlockManager::IncRegisterDependance(CCodeBlock* pCb, UI32 reg1, UI32 reg2) {

	// Lambda expression to reduce number of register in register list 
	// to user setting value based on register frequence and register index.
	auto SelectRegister = [] (std::map<UI32, std::pair<UI32, bool>> &mUGrR, UI32 maxRegInBlock)
	{
		std::map<UI32,std::pair<UI32, bool>>::iterator mItr;
		std::vector<std::pair<UI32, std::pair<UI32, bool>>> vRegList; // <RegIdx, <RegFreq, fixedFlag>>
		std::vector<std::pair<UI32, std::pair<UI32, bool>>>::iterator vItr;
		UI32	nRmCond, nMaxFreq;
		bool	bFinished = false;

		// Find the maximum frequence
		nMaxFreq = 0;
		auto get_max = [&nMaxFreq] (std::pair<UI32,std::pair<UI32, bool>> itr) 
		{
			if(itr.second.second == false && itr.second.first > nMaxFreq )
				nMaxFreq = itr.second.first;
		};
		std::for_each(mUGrR.begin(), mUGrR.end(), get_max);

		// Remove the register that is used in the least until number of register is (maxRegInBlock - 1)
		nRmCond = 1; // The least frequence
		mItr = mUGrR.begin();
		while(!bFinished)
		{
			// In order to avoid increasing number of used register, GrReg 30 need to keep in list.
			if((mItr->first != 30)
				&& (mItr->second.second == false)
				&& (mItr->second.first == nRmCond))
			{
				// Insert removed register's information to the temporary vector,
				// Then, remove it from the register list.
				vRegList.push_back(std::pair<UI32, std::pair<UI32, bool>> 
					(mItr->first, std::pair<UI32, bool>(mItr->second.first, mItr->second.second)));
				mItr = mUGrR.erase(mItr);
			}
			else {
				mItr++;
			}

			// Stop removing if the remained register is maxRegInBlock - 1.
			if(mUGrR.size() == maxRegInBlock - 1)
				bFinished = true;

			// Finished removing all register with current frequence,
			// Continue with higher frequence.
			if(mItr == mUGrR.end())
			{
				nRmCond++;
				if(nRmCond > nMaxFreq)
					bFinished = true; // To avoid infinitive loop
				mItr = mUGrR.begin();
			}
		}

		// A additional register that is in priority of multi of 4, even, then normal.
		std::random_shuffle(vRegList.begin(), vRegList.end(), g_rnd);
		// Lambda expression for checking multi of 4 register index.
		auto IsMulti_4 = [](std::pair<UI32, std::pair<UI32, bool>> p)->bool {return ((p.first & 3) == 0);};
		// Search the first register whose index is multiple of 4.
		vItr = std::find_if(vRegList.begin(), vRegList.end(), IsMulti_4);
		if(vItr == vRegList.end())
		{
			// If there are no multiple of 4 register, FROG will continue searching even register.
			auto is_Even = [](std::pair<UI32, std::pair<UI32, bool>> p)->bool {return ((p.first & 1) == 0);};
			vItr = std::find_if(vRegList.begin(), vRegList.end(), is_Even);
			if(vItr == vRegList.end())
			{
				// If ther is not multiple of 4 and even register, a random register will be choose.
				vItr = vRegList.begin();
			}
		}
		// Insert register information into register list.
		mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
			(vItr->first, std::pair<UI32, bool>(vItr->second.first, vItr->second.second)));

		return;
	};

	// lambda expression, this function processes for custom instructions that have some constraint for operand.
	// return:
	//	- true: means that the operand is replaced.
	//	- false: the operand is not processed, it will be replace as a normal instruction.
	auto CheckReplaceCustomIns = [](IInstruction* pIns, std::map<UI32, std::pair<UI32, bool>> &mUGrR) -> bool
	{
		UI32 nReg1, nReg2;
		UI32 nRetry, nMembit;
		std::map<UI32, std::pair<UI32, bool>>::iterator mItr;
		UI32 InsId = pIns->GetId();
		if(InsId == INS_ID_CLR1 || InsId == INS_ID_NOT1 || InsId == INS_ID_SET1 || InsId == INS_ID_TST1)
		{
			nReg1 = pIns->opr(0)->Idx();
			nReg2 = pIns->opr(1)->Idx();
			// Incase of custom instruction, there is constraint for 2nd operand.
			if(pIns->opr(0)->GetConstraint() != NULL)
			{
				nMembit = pIns->opr(0)->GetConstraint()->m_nMin;
				if(mUGrR.find(nReg1) == mUGrR.end())
				{
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));
					nRetry = 0;
					// Try to get the register that is not fixed register
					// and it must be not 0 when nMembit is not 0 from register list.
					while(nRetry < mUGrR.size() 
						&& ((mItr->first == 0 && nMembit != 0)  
							|| mItr->second.second == true))
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}
					// If there is no suitable register, add current operand to register list.
					if(nRetry == mUGrR.size())
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
						(nReg1, std::pair<UI32, bool> (1, false)));
					else{
						nReg1 = mItr->first;
						pIns->opr(0)->Replace(nReg1);
					}
				}
				if(nReg2 == nReg1 || mUGrR.find(nReg2) == mUGrR.end())
				{
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));
					nRetry = 0;
					// Try to get a register that is not 0, not fixed register and different from 1st operand from register list.
					while(nRetry < mUGrR.size() && 
						(mItr->first == 0 || mItr->second.second == true || mItr->first == nReg1))
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}
					if(nRetry == mUGrR.size())
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
						(nReg2, std::pair<UI32, bool> (1, false)));
					else
					{
						nReg2 = mItr->first;
						pIns->opr(1)->Replace(nReg2);
					}
				}
				return true;
			}
		}
		return false;
	};

	auto ReplaceMacroArray = [] (IInstruction *pIns, std::map<UI32, std::pair<UI32, bool>> &mUGrR)
	{
		auto checkConstraint = [] (UI32 insid, UI32 reg) -> bool
		{
			if(reg == 0) // Macro array do not used Reg#0.
				return false;
            // If instruction is ld_array or st_array or ls_array
			if(( insid == INS_CID_LD_ARRAY || insid == INS_CID_ST_ARRAY || insid == INS_CID_LS_ARRAY) && ((reg & 1) != 0))
				return false;
           // If instruction is sld_array(Short)or sst_array(Short) or sls_array(Short) or caxi_array
			if((insid == INS_CID_SLD_ARRAY || insid == INS_CID_SST_ARRAY || insid == INS_CID_SLS_ARRAY || insid == INS_CID_CAXI_ARRAY) && (reg == 30))
				return false;
			return true;
		};

		auto Replace = [] (IOperand *pOpr, UI32 newReg) -> bool
		{
			if(pOpr == NULL)
				return false;

			// Update register range
			if(!pOpr->SetRange(newReg, newReg))
                return false;
			// Replace register
			if(!pOpr->Replace(newReg))
				return false;

			return true;
		};
		
		// Lamda function to adjust operand follow C2B1 constraint
		auto C2B1Constraint = [](IInstruction* pIns1, UI32 OprIns1, IInstruction* pIns2, UI32 OprIns2, UI32 newOpr){
			pIns1->opr(OprIns1)->Replace(newOpr);
			pIns2->opr(OprIns2)->Replace(newOpr);
		};

		// Lamda function to get general register
		auto GetGrReg = [&] ( std::map<UI32, std::pair<UI32, bool>> &mUGrR){
			std::map<UI32, std::pair<UI32, bool>>::iterator mItr;
			mItr = mUGrR.begin();
			std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));
			return mItr->first;
			
		};

		ComplexInstruction *pCompIns;
		IInstruction		*pSgleIns;
		IInstruction		*pC2B1Ins_1;
		IInstruction		*pC2B1Ins_2;
		UI32				nCompInsNum, nOpr;
		UI32				srcReg = 0;
		UI32				insid;
		const UI32			ElementPointer = 30;
		IOperand			*pOpr, *pBaseOpr = NULL, *pSecOpr1 = NULL, *pSecOpr2 = NULL;
		std::map<UI32, std::pair<UI32, bool>>::iterator mItr;
		UI32 nRetry;
		UI32 regA = 0, regC = 0;

		pCompIns = static_cast<ComplexInstruction*> (pIns);
		insid = pCompIns->GetId();
		switch(insid)
		{
		case INS_CID_PREF_I:
			// Generate 2 random register that is not 0.
			while(regA == 0){
				mItr = mUGrR.begin();
				std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));
				regA = mItr->first;
			}
			while(regC == 0 || regC == regA){
				mItr = mUGrR.begin();
				std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));
				regC = mItr->first;
			}

			pSgleIns = (*pCompIns)[0];
			Replace(pSgleIns->opr(0), regA);
			Replace(pSgleIns->opr(1), regA);

			pSgleIns = (*pCompIns)[1];
			Replace(pSgleIns->opr(1), regC);

			pSgleIns = (*pCompIns)[2];
			Replace(pSgleIns->opr(1), regA);

			pSgleIns = (*pCompIns)[3];
			Replace(pSgleIns->opr(1), regA);
			Replace(pSgleIns->opr(2), regA);

			pSgleIns = (*pCompIns)[4];
			Replace(pSgleIns->opr(0), regC);
			break;
		case INS_CID_LD_ARRAY:
		case INS_CID_ST_ARRAY:
		case INS_CID_LS_ARRAY:
		case INS_CID_SLD_ARRAY:
		case INS_CID_SST_ARRAY:
		case INS_CID_SLS_ARRAY:
		case INS_CID_CAXI_ARRAY:
			for(nCompInsNum = 0; nCompInsNum < pCompIns->size(); nCompInsNum ++)
			{
				pSgleIns = (*pCompIns)[nCompInsNum];
                pBaseOpr = nullptr;
                pSecOpr1 = nullptr;
                pSecOpr2 = nullptr;
				for(nOpr = 0; nOpr < pSgleIns->GetOpNum(); nOpr++)
				{
					pOpr = pSgleIns->opr(nOpr);
					if(pOpr->IsGR())
						pOpr->GetArrayInsOpr(&srcReg, &pBaseOpr, &pSecOpr1, &pSecOpr2);
				}
				// Generate random register for source operand.
				if(pBaseOpr != NULL && mUGrR.find(pBaseOpr->Idx()) == mUGrR.end())
				{
					if(srcReg == 0) // Source register is not generated.
					{
						// Generate random register from used list.
						mItr = mUGrR.begin();
						std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));

						nRetry = 0;
						// Try to replace register.
						while((nRetry < mUGrR.size()) // Retry until short of register
							&& ((checkConstraint(insid, mItr->first) == false) // Register must be even or other than 30.
								|| (Replace(pBaseOpr, mItr->first) == false))) // Replace failed.
						{
							mItr = next(mItr);
							if(mItr == mUGrR.end())
								mItr = mUGrR.begin();
							nRetry++;
						}

						/* No suitable register in used list to replace. Add register to list.*/
						if(nRetry == mUGrR.size())
						{
							mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
								(pBaseOpr->Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register. 
						}
						// srcReg = pBaseOpr->Idx();
					}
					else // If the source is already generated.
                    {
						// pBaseOpr->Replace(srcReg);
                        Replace(pBaseOpr, srcReg);
                    }
				}
                if(srcReg == 0)
                    srcReg = pBaseOpr->Idx();

				// if(pSecOpr1 != NULL && mUGrR.find(pSecOpr1->Idx()) == mUGrR.end())
                if(pSecOpr1 != NULL && (pSecOpr1->Idx() == srcReg || mUGrR.find(pSecOpr1->Idx()) == mUGrR.end()))
				{
					// Generate random register from used list.
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));

					nRetry = 0;
					// Try to replace register by another that is not fixed register.
					while((nRetry < mUGrR.size()) // Try until short of register
						&& ((mItr->first == srcReg)	// The dest reg must be other than source reg.
							|| (checkConstraint(insid, mItr->first) == false) // Register must be even or other than 30.
							|| (Replace(pSecOpr1, mItr->first) == false))) // Replace failed.
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}

					/* No suitable register in used list to replace. Add register to list.*/
					if(nRetry == mUGrR.size())
					{
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
							(pSecOpr1->Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register. 
					}
				} 
				// if(pSecOpr2 != NULL && mUGrR.find(pSecOpr2->Idx()) == mUGrR.end())
                if(pSecOpr2 != NULL && (pSecOpr2->Idx() == srcReg || pSecOpr2->Idx() == pSecOpr1->Idx() || mUGrR.find(pSecOpr2->Idx()) == mUGrR.end()))
				{ 
					// Generate random register from used list.
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUGrR.size() - 1));

					nRetry = 0;
					// Try to replace register by another that is not fixed register.
					while((nRetry < mUGrR.size()) // Try until short of register
						&& ((mItr->first == srcReg) || (mItr->first == pSecOpr1->Idx())	// The dest reg must be other than source reg/ dest1.
							|| (checkConstraint(insid, mItr->first) == false) // Register must be even or other than 30.
							|| (Replace(pSecOpr2, mItr->first) == false))) // Replace failed.
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}

					/* No suitable register in used list to replace. Add register to list.*/
					if(nRetry == mUGrR.size())
					{
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
							(pSecOpr2->Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register. 
					}
				}
			}
			break;
		

		case INS_CID_MOV_ALU:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];
			
			regA = GetGrReg(mUGrR);
			regC = GetGrReg(mUGrR);

			pC2B1Ins_1->opr(0)->Replace(regA);
			pC2B1Ins_2->opr(0)->Replace(regC);

			regA = GetGrReg(mUGrR);

			while( regA == regC || regA == 0)
				regA = GetGrReg(mUGrR);
			
			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 1, regA);
			
			break;

		case INS_CID_MOVR_SHIFT:
			regA = GetGrReg(mUGrR);
			regC = GetGrReg(mUGrR);

			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];

			pC2B1Ins_1->opr(0)->Replace(regA);
			while(regC == 0)
				regC = GetGrReg(mUGrR);
			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 1, regC);

			break;

		case INS_CID_MOV_SST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];
			// Replace operand does not relate to C2B1 instruction constraint.
			for(UI32 i = 0; i < pC2B1Ins_1->GetOpNum()-1; i++){
				regA = GetGrReg(mUGrR);
				pC2B1Ins_1->opr(i)->Replace(regA);
			}

			regA = pC2B1Ins_1->opr(1)->Idx();

			while( regA == ElementPointer || regA == 0){
				regA = GetGrReg(mUGrR);
			}
			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 0, regA);
			while(pC2B1Ins_1->opr(0)->Idx() == ElementPointer)
				pC2B1Ins_1->opr(0)->Replace(g_rnd.GetRange(0, 31));
			
			break;

		case INS_CID_MOV5_ST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];

			regA = GetGrReg(mUGrR);
			while(regA == 0)
				regA = GetGrReg(mUGrR);

			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 0, regA);
			regC = GetGrReg(mUGrR);
			while( regC == pC2B1Ins_2->opr(0)->Idx() || regC == 0){
				regC = GetGrReg(mUGrR);
			}
			pC2B1Ins_2->opr(1)->Replace(regC);

			break;

		case INS_CID_MOVEA_SST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];

			regA = GetGrReg(mUGrR);
			while(regA == ElementPointer || regA == 0)
				regA = GetGrReg(mUGrR);
			C2B1Constraint(pC2B1Ins_1, 2, pC2B1Ins_2, 0, regA);

			break;

		case INS_CID_MOVEA_ST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];
			// Replace operand does not relate to C2B1 instruction constraint.
			for(UI32 i = 0; i< pC2B1Ins_2->GetOpNum()-1;i++){
				regA = GetGrReg(mUGrR);
				pC2B1Ins_2->opr(i)->Replace(regA);
			}
			regC = GetGrReg(mUGrR);
			while( regC == pC2B1Ins_2->opr(1)->Idx() || regC == 0){
				regC = GetGrReg(mUGrR);
			}
			C2B1Constraint(pC2B1Ins_1, 2, pC2B1Ins_2, 0, regC);
			break;

		case INS_CID_CMP_BCC:
			pC2B1Ins_1 = (*pCompIns)[0];
			// Replace operand does not relate to C2B1 instruction constraint.
			for(UI32 i = 0; i < pC2B1Ins_1->GetOpNum()-1; i++){
				regA = GetGrReg(mUGrR);
				pC2B1Ins_1->opr(i)->Replace(regA);
			}
			break;

		default:
			break;
		}
	};

	UI32 nIns, nOpr;
	IInstruction	*pIns;
	IOperand		*pOpr;
	std::map<UI32, std::pair<UI32, bool>> mUsedGrReg;	// <RegIndex, <RegFreq, fixedFlag>>
	std::map<UI32, std::pair<UI32, bool>>::iterator mItr;

	// Do nothing if max register is 32 (maximum).
	if (32 <= g_cfg->m_nMaxRegInBlock)
		return;

	// Traversing all instructions in code block.
	for(UI32 nIns = 0; nIns < pCb->GetInstructionNum(); nIns++)
	{
		pIns = pCb->at(nIns);
		// Check whether current instruction is complex instruction (array)
		if(pIns->IsComplex())
		{
			ComplexInstruction	*pComplexIns;
			UI32				nCpInsCount;

			pComplexIns = static_cast<ComplexInstruction*> (pIns);
			// Traversing and collect register of all instructions in array.
			for( nCpInsCount = 0; nCpInsCount < pComplexIns->size(); nCpInsCount++ )
			{
				for(UI32 i = 0; i< (*pComplexIns)[nCpInsCount]->GetOpNum();i++)
					(*pComplexIns)[nCpInsCount]->opr(i)->GetGrRegister(&mUsedGrReg);
			}
		}
		else {
			// Get generated register of normal instruction.
			for(UI32 i = 0; i< pIns->GetOpNum();i++)
				pIns->opr(i)->GetGrRegister(&mUsedGrReg);
		}
	}

	// Do nothing if number of used register is smaller than user setting
	if( mUsedGrReg.size() <= g_cfg->m_nMaxRegInBlock)
		return;

	// Set fixedFlag for fixed register
	if(reg1 != 0) // Block-mix is 1 or 2.
	{
		mItr = mUsedGrReg.find(reg1);
		mItr->second.second = true;
	}
	if(reg2 != 0) // Block-mix is 2.
	{
		mItr = mUsedGrReg.find(reg2);
		mItr->second.second = true;
	}

	// Collect used register
	SelectRegister(mUsedGrReg, g_cfg->m_nMaxRegInBlock);

	 // Repeat traversing all instructions
	for(nIns = 0; nIns < pCb->GetInstructionNum(); nIns++) 
	{
		pIns = pCb->at(nIns);
		if(pIns->IsComplex()) // Process for macro array instruction
		{
			ReplaceMacroArray(pIns, mUsedGrReg);
		} else {
			// Process for custome instruction 457 -> 464
			if(pIns->GetMne() == "clr1" || pIns->GetMne() == "not1" || 
				pIns->GetMne() == "set1" || pIns->GetMne() == "tst1")
			{
				// CheckReplaceCustomIns return false means that this instruction will be 
				// processed as a normal instruction.
				if(CheckReplaceCustomIns(pIns, mUsedGrReg))
					continue;
			}
			// Repeat traversing all operands
			for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++)
			{
				pOpr = pIns->opr(nOpr);
				pOpr->ReplaceOprInList(&mUsedGrReg);
			}
		}
	}
#if	0 //DEBUG
	{
		std::cout << "Used reg: ";
		for(mItr = mUsedGrReg.begin(); mItr != mUsedGrReg.end(); mItr++)
		{
			std::cout << mItr->first << "\t";
		}
		std::cout << std::endl;
	}
#endif
}

std::vector<CTeSyncBlock*>* CBlockManager::GenerateTeSync( TBlockConfig* pCfg ) {

	const UI32 reg = 10;
    const UI32 reg_b = 31;
	std::vector<CTeSyncBlock*>* vNode = new std::vector<CTeSyncBlock*>();
	std::string cstrT = GetTContext(pCfg);
	std::string cstrM = GetMContext(pCfg);
	IInstruction *ins;
	CTeSyncBlock* pTS_trap = new CTeSyncBlock( cstrT + "th_end_sync" );
	CTeSyncBlock* pTS_sync = new CTeSyncBlock( cstrT + "th_end_sync_sub" );
	pTS_trap->EnableRegulation(true);
	pTS_trap->SetOutputFlag(true);
	pTS_sync->EnableRegulation(false);
	pTS_sync->SetOutputFlag(true);
    // UM -> SV
	NewINS( pTS_trap,  DBTAG());  //! Mark it as the end of random block #Redmine#65750
	NewINS( pTS_trap,  STSR( 5, reg, 0));  // PSW
	NewINS( pTS_trap,  MOV32(0x40000000, reg+1));
	NewINS( pTS_trap,  AND(reg, reg+1));
	NewINS( pTS_trap,  BZ9P( pTS_trap->GetLabel() + "_In_SV_mode") );
	NewINS( pTS_trap, ins=TRAP(0x1d) ); ins->AppendComment("Change_mode_to_SV");

    NewINS(pTS_trap, NOP()->SetLabel(pTS_trap->GetLabel() + "_In_SV_mode"));
    if (pCfg->m_bGM == true && m_MmList.Size() != 0) {
        NewINS(pTS_trap, HVTRAP(0x1e)); // change to HOST MODE in order to disable MPU      
        NewINS(pTS_trap, NOP());
    }
    NewINS(pTS_trap, ins = NOP()); ins->AppendComment(" Remove pending interrupt");
	// Clear all interrupt
	std::map< UI32,IExceptionConfig*>& vExp = g_exp->GetException();
	std::map<UI32, IExceptionConfig*>::iterator itrExp;
	UI32 index = 0xfff0;
	for(itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
		IExceptionConfig* pExpConfig = itrExp->second;
		if(pExpConfig->m_bIsInterrupt && pExpConfig->m_weight != 0) {
            std::string name = "";
            if (pExpConfig->m_name == "RBINT") {
                name = "EITBL";
            } else if (pExpConfig->m_name == "GMRBINT") {
                name = "GMEITBL";
            } else {
                name = pExpConfig->m_name;
            }
			std::transform(name.begin(), name.end(), name.begin(), [] (int ch) {return std::tolower(ch);});
			CAsyncLabel *pAsyncLabel = new CAsyncLabel(name, cstrT, index, false);
			pAsyncLabel->m_nEventId = pExpConfig->m_id;
			ins->SetDirective(pAsyncLabel);
		}
		index--;
	}

    // VM生成時
    AddHtNotifyComplete(pCfg, pTS_sync);				// 自ＨＴ準備完了フラグをセット

    if ((pCfg->m_VCID == 0) && (pCfg->m_HTID == g_prf->GetMasterThreadNo(0))) {
        // VMのマスタースレッド
        AddHtWaitComplete(pCfg, pTS_sync);			    // 自ＰＥ内全ＴＨ準備完了待ち

        if (m_MmList.Size() != 0) {
            // MPM off
			NewINS( pTS_trap, MOV32P("disable_mpu", reg));
			NewINS( pTS_trap, JARL32(reg, reg_b));
        }

        // jump
        NewINS(pTS_sync, MOV32P(cstrM + "epilogue", reg_b) );
        NewINS(pTS_sync, JMP32(reg_b) );
    }
    NewINS( pTS_sync, NOP() );
    NewINS( pTS_sync, NOP() );
	NewINS( pTS_sync, NOP() );
    NewINS( pTS_sync, NOP() );
    NewINS( pTS_sync, HALT() );
    NewINS( pTS_sync, BR9(-8) );

	vNode->push_back(pTS_trap);
	vNode->push_back(pTS_sync);
	return vNode;
}


/**
 * @brief  プリフェッチコードを生成します。
 * @param  ランダムブロック情報
 */
void CBlockManager::AppendPrefetchCode (std::string & context, CSyncBlock* pPF) {
	const UI32 reg1 = 10;
	const UI32 memreg = 11;
	const UI32 tblreg = 12;
	const UI32 returnReg = 29;
    NewINS( pPF, MOV32P(context + "_PrefetchMode" + "_data", tblreg) );
	NewINS( pPF, ADD5(2, tblreg) );
	NewINS( pPF, LDHU16(2, tblreg, reg1)->SetLabel(context + "_PrefetchMode_1"));
	NewINS( pPF, LDHU16(0, tblreg, memreg));

	NewINS( pPF, SHL5( 16, reg1) );
	NewINS( pPF, OR(reg1,memreg) );
	NewINS( pPF, LDHU16(4, tblreg, reg1));
	NewINS( pPF, CMPR(0, reg1));
	NewINS( pPF, BZ9P((context + "_PrefetchMode_3")));
    NewINS( pPF, PREF(0,memreg)->SetLabel(context + "_PrefetchMode_2"));
	NewINS( pPF, ADDI(0x0020, memreg, memreg) );

	NewINS( pPF, LOOPP(reg1 ,context + "_PrefetchMode_2") );
    NewINS( pPF, PREF(0,memreg));
	NewINS( pPF, ADD5(8, tblreg) );
	NewINS( pPF, BR9P(context + "_PrefetchMode_1"));
	NewINS( pPF, NOP());
	NewINS( pPF, JMP32(returnReg)->SetLabel(context + "_PrefetchMode_3"));
	NewINS( pPF, NOP());
	NewINS( pPF, NOP()->SetLabel(context + "_PrefetchMode" + "_data"));
}


void CBlockManager::AppendPrefetchData (UI32 pf_addr ,UI32 pf_size, CSyncBlock* pPF) {
	IInstruction * ins ;
	char str[80] ;
    if (pf_size == 0) {
        sprintf(str ,"[END OF PREFETCH]" ) ;
	    NewINS( pPF, ins = _WORD(0));
	    ins->AppendComment((LPCTSTR)str) ;
	    NewINS( pPF, _WORD(0));
    } else {
	    sprintf(str ,"[PF_ADR: 0x%08x  SIZE: %d]" ,pf_addr ,pf_size ) ;
        UI32 lines = 0;
		lines = (((pf_addr % 32) + pf_size - 1) / 32) + 1;
	    NewINS( pPF, ins = _WORD(pf_addr & 0xfffffff0));
	    ins->AppendComment((LPCTSTR)str) ;
	    NewINS( pPF, _WORD(lines));
    }
}

void CBlockManager::FetchLineZeroing_AddOpcodeDirectly (std::vector<INode*>& rCb) {
	UI32 nop_len = NOP()->GetLen();

	for (std::vector<INode*>::iterator node = rCb.begin(); node != rCb.end(); node++) {
		CCodeBlock* p = static_cast<CCodeBlock*>(*node);
		UI32 fetch_size = g_cfg->m_nFetchSize >> 3;
		UI32 gap = (fetch_size - (p->GetCodeSize() % fetch_size)) % fetch_size;
		UI32 nop_gap = (gap/nop_len) + ((gap % nop_len)? 1 : 0);
		for (UI32 i = 0; i < nop_gap; i++) {
			NewINS( p, NOP() );
		}
		p->WriteOpcodeDirectly();
	}
}


CSyncBlock* CBlockManager::SyncStandbyGoNext(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	bool bGrInit = pCfg->m_bNC;
	bool bWrInit = true;
	UI32 reg = 20;
	std::string contextStr = GetTContext(pCfg);

	std::string str = GetTContext(pCfg) + "sync_standby_next";
	NewINS( pSB, NOP()->SetLabel(str));

	if (g_cfg->m_bPrefAssist) {
    	NewINS(pSB, MOV32P( contextStr + "PrefetchMode", reg) );
    	NewINS(pSB, JARL32(reg, 29) );
		NewINS(pSB, STSR(5, reg, 0)->Note("Start clearing PSW flags after PrefetchMode") );
		NewINS(pSB, SHR5(4, reg) );
		NewINS(pSB, SHL5(4, reg) );
		NewINS(pSB, LDSR(reg, 5, 0)->Note("Finish clearing PSW flags after PrefetchMode") );
    	NewINS(pSB, NOP() );
    	NewINS(pSB, NOP() );
    }

    if (m_MmList.Size() != 0) {
        if (pCfg->m_bGM) {
            UI32 gmmpm = g_srs->GetNcInit(25, 9);
            NewINS(pSB, MOV5(gmmpm, reg));
            NewINS(pSB, LDSR(reg, 25, 9));
        }
    }
	// Run in hypervisor need to update GMPSW instead of PSW
	// 1. If current GM in user mode -> need to set GMPSW.UM = 1
	// 2. If current GM does not start with UM -> clear GMPSW.UM because before GMPSW.UM may be set to 1 by other GM
	if (g_prf->IsUserMode(pCfg->m_bGM, pCfg->m_GMID)) {
		UI32 psw_regID = 1, psw_selID = 0, psw_val = 0;	
		if (pCfg->m_bGM == false) {
			psw_val = g_srs->GetNcInit(5, 0);
			psw_val |= 0x40000000;
		} else {
			psw_regID = 5;
			psw_selID = 9;
			psw_val = g_srs->GetNcInit(5, 9);
			psw_val |= 0x40000000;
		}
		NewINS( pSB, MOV32(psw_val, 29) );		
		NewINS( pSB, LDSR(29, psw_regID, psw_selID) );		
	} else if (pCfg->m_bGM == true) {
		UI32 psw_val = g_srs->GetNcInit(5, 9);
		// Clear GMPSW
		psw_val &= 0xBFFFFFFF;
		NewINS( pSB, MOV32(psw_val, 29) );
		NewINS( pSB, LDSR(29, 5, 9) );
    }

	if(pCfg->m_bNC == true) {
		//! WR INIT
		if (bWrInit) {
			InitWR( pSB );
		}
		//! GR INIT
		if (bGrInit) {
			InitGR( pSB );
		}
	}
	return pSB;
}


CSyncBlock* CBlockManager::AddHtNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 1;
	const UI32 reg2 = 31;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_STANDBY + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT) + g_prf->GetWaitThreadNo(pCfg->m_HTID);
	
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, MOV5 (1, reg2) );
	NewINS( pSB, STB16 (reg2, 0, reg1) );
		
	return pSB;
}


CSyncBlock* CBlockManager::AddHtWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_STANDBY + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT);
	UI32 size = g_prf->GetWaitThreadNum(); // 同期するHT数
	NewINS( pSB, MOV5 (size, reg1) );
	NewINS( pSB, MOV32(addr, reg2) );
	
	NewINS( pSB, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pSB, BZ9P((str + "4").c_str()));
	
	NewINS( pSB, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pSB, CMP5(1, reg3));
	NewINS( pSB, BZ9P((str + "3").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "2").c_str()));

	NewINS( pSB, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pSB, ADD5(-1, reg1) );
	NewINS( pSB, BNZ9P((str + "2").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "4") );
	
	return pSB;
}


CSyncBlock* CBlockManager::AddHtWait2Standby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address

	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_STANDBY + g_cfg->m_nPeWorkIdx;
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, LDB16(0, reg1, reg2)->SetLabel(str + "5"));
	NewINS( pSB, CMP5(1, reg2));
	NewINS( pSB, BZ9P((str + "6").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "5").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "6") );

	return pSB;
}


CSyncBlock* CBlockManager::AddWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address

	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, LDB16(0, reg1, reg2)->SetLabel(str + "5"));
	NewINS( pSB, CMP5(1, reg2));
	NewINS( pSB, BZ9P((str + "6").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "5").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "6") );
	
	return pSB;
}


CSyncBlock* CBlockManager::AddPeNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_STANDBY + g_cfg->m_nPeWorkIdx;
	
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, MOV5 (1, reg2) );
	NewINS( pSB, STB16 (reg2, 0, reg1) );
		
	return pSB;
}


CSyncBlock* CBlockManager::AddPeWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	const UI32 reg4 = 8;	// psw temp
	std::string str;
    UI32 addr;

	str = GetTContext(pCfg) + "sync_standby_next";
    addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;

	NewINS( pSB, STSR (5, reg4, 0) );  // store PSW in R8

	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, LDB16(0, reg1, reg2));
	NewINS( pSB, CMP5(1, reg2));
	NewINS( pSB, BZ9P((str).c_str()));

	str = GetTContext(pCfg) + "sync_pe_standby_";
	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_STANDBY;
	UI32 size = g_cfg->m_nSysPeNum;
	NewINS( pSB, MOV5 (size, reg1) );
	NewINS( pSB, MOV32(addr, reg2) );
	
	NewINS( pSB, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pSB, BZ9P((str + "4").c_str()));
	
	NewINS( pSB, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pSB, CMP5(1, reg3));
	NewINS( pSB, BZ9P((str + "3").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "2").c_str()));

	NewINS( pSB, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pSB, ADD5(-1, reg1) );
	NewINS( pSB, BNZ9P((str + "2").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "4") );

	NewINS( pSB, LDSR (reg4, 5, 0) );  // restore PSW from R8
	
	return pSB;
}


CSyncBlock* CBlockManager::AddSysNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;
	
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, MOV5 (1, reg2) );
	NewINS( pSB, STB16 (reg2, 0, reg1) );
		
	return pSB;
}


CTeSyncBlock* CBlockManager::AddHtNotifyComplete(TBlockConfig* pCfg, CTeSyncBlock* pTS) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTS);
	
	std::string str = GetTContext(pCfg) + "sync_ht_complete_";
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_COMPLETE + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT) + g_prf->GetWaitThreadNo(pCfg->m_HTID);
	
	NewINS( pTS, MOV32(addr, reg1)->SetLabel(str + "0"));
	NewINS( pTS, MOV5 (1, reg2) );
	NewINS( pTS, STB16 (reg2, 0, reg1) );
		
	return pTS;
}


CTeSyncBlock* CBlockManager::AddHtWaitComplete(TBlockConfig* pCfg, CTeSyncBlock* pTS) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTS);

	std::string str = GetTContext(pCfg) + "sync_ht_complete_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_COMPLETE + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT);
	UI32 size = g_prf->GetWaitThreadNum(); // 同期するHT数
	NewINS( pTS, MOV5 (size, reg1) );
	NewINS( pTS, MOV32(addr, reg2) );
	
	NewINS( pTS, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pTS, BZ9P((str + "4").c_str()));
	
	NewINS( pTS, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pTS, CMP5(1, reg3));
	NewINS( pTS, BZ9P((str + "3").c_str()));
	NewINS( pTS, SNOOZE());
	NewINS( pTS, SNOOZE());
	NewINS( pTS, BR9P((str + "2").c_str()));

	NewINS( pTS, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pTS, ADD5(-1, reg1) );
	NewINS( pTS, BNZ9P((str + "2").c_str()));

	NewINS( pTS, NOP()->SetLabel(str + "4") );
	
	return pTS;
}


CTerminateBlock* CBlockManager::AddPeNotifyComplete(TBlockConfig* pCfg, CTerminateBlock* pTB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTB);
	
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_COMPLETE + g_cfg->m_nPeWorkIdx;
	
	NewINS( pTB, MOV32(addr, reg1) );
	NewINS( pTB, MOV5 (1, reg2) );
	NewINS( pTB, STB16 (reg2, 0, reg1) );
		
	return pTB;
}


CTerminateBlock* CBlockManager::AddPeWaitComplete(TBlockConfig* pCfg, CTerminateBlock* pTB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTB);

	std::string str = GetTContext(pCfg) + "sync_pe_complete_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	
    UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_SKIP_PE_COMPLETE;
	NewINS( pTB, MOV32(addr, reg1) );
	NewINS( pTB, LDB16(0, reg1, reg2));
	NewINS( pTB, CMP5(1, reg2));
	NewINS( pTB, BZ9P((str + "4").c_str()));

	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_COMPLETE;
	UI32 size = g_cfg->m_nSysPeNum;
	NewINS( pTB, MOV5 (size, reg1) );
	NewINS( pTB, MOV32(addr, reg2) );
	
	NewINS( pTB, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pTB, BZ9P((str + "4").c_str()));
	
	NewINS( pTB, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pTB, CMP5(1, reg3));
	NewINS( pTB, BZ9P((str + "3").c_str()));
	NewINS( pTB, SNOOZE());
	NewINS( pTB, SNOOZE());
	NewINS( pTB, BR9P((str + "2").c_str()));

	NewINS( pTB, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pTB, ADD5(-1, reg1) );
	NewINS( pTB, BNZ9P((str + "2").c_str()));

	NewINS( pTB, NOP()->SetLabel(str + "4") );
	
	return pTB;
}


std::vector<CEpilogueBlock*>* CBlockManager::GenerateEpilogue(TBlockConfig* pCfg) {
	
	std::vector<CEpilogueBlock*>* vNode = new std::vector<CEpilogueBlock*>();
	std::string contextStr = GetMContext(pCfg);
	
	const UI32 reg_a = 1;
	const UI32 reg_b = 31;
	if (pCfg->m_bNC) {
		// -----------------------------------------------------------------
		// NM:Epilogue - 1
		//  セルフチェックする為にレジスタr1,r31を使用する。
		//  r1,r31の値も比較対象にするためr3, r4に足し込む (完全なセルフチェックにはならない)
		//  r1, r31が使用可能な状態にしてEpilogue2へジャンプ
		CEpilogueBlock* pEB = new CEpilogueBlock(contextStr + "epilogue");
		NewINS( pEB, ADD(reg_a, 3) ); // reg1  --+--> reg3
		NewINS( pEB, ADD(reg_b, 4) ); // reg31 --+--> reg4
		NewINS( pEB, MOV32P(contextStr + "eplogue_verifier", reg_a) );
		NewINS( pEB, JMP32(reg_a)  );
		vNode->push_back(pEB);

		// -----------------------------------------------------------------
		// NM:Epilogue - 2
		//   このブロックがシミュレーションされる時点でスナップショット（期待値）がとられる。
		//   全シミュレーションが完了後にスナップショットから比較コードが生成される。
		pEB = new CEpilogueBlock(contextStr + "eplogue_verifier", true);
		NewINS( pEB, MOV32P(contextStr + "terminate", reg_b));
		NewINS( pEB, JMP32(reg_b) ); 		
		// 不一致の場合、ブランチ命令がセクションを跨げないため中継してジャンプする。
		NewINS( pEB, MOV32P(contextStr + "selfcheck_fail", reg_a)->SetLabel(contextStr + "verify_fail"));
		NewINS( pEB, JMP32(reg_a) );
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		vNode->push_back(pEB);

		// -----------------------------------------------------------------
		// NM:Epilogue - 3
		//   Nativeコンテキストのみエラーハンドルブロック追加
		//   ユーザー処理できるようにユーザーコードエントリも追加する
		pEB = new CEpilogueBlock(contextStr + "selfcheck_fail");
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		NewINS( pEB, MOV32(0xdead0000, 1));
		NewINS( pEB, HALT() );
		NewINS( pEB, BR9(-16) );
		NewINS( pEB, NOP() );
		vNode->push_back(pEB);
	} else {
		// -----------------------------------------------------------------
		// VM :: Epilogue - 1 terminateへつながる処理のみ
		CEpilogueBlock* pEB = new CEpilogueBlock(contextStr + "epilogue");
		UI32 addr = 0;
		UI32 GMNum = g_cfg->m_mGMs.size();
		std::string labelStr; 
		NewINS( pEB, MOVR(0, reg_b - 1));
		// Checking final GM for selfcheck 
		for (UI32 pos = 0; pos < GMNum; pos++) {
			//Get GPID
			std::map<UI32, GM_Infor>::iterator itr = g_cfg->m_mGMs.begin();
			std::advance( itr, pos);
			UI32 GMID = itr->first;
			addr = g_wm.GM_TERMINATE_FLAG;
			addr += 4 * GMID;
			std::stringstream ss;
			ss << contextStr <<  "epilogue_check_next_GM_" << pos ;
			ss >> labelStr;

			NewINS( pEB, MOV32(addr, reg_a));
			NewINS( pEB, LDB16 (0, reg_a, reg_b) );
			NewINS( pEB, CMP5 (1, reg_b) );
			NewINS( pEB, BNZ9P (labelStr) );
			NewINS( pEB, ADD5(1, reg_b - 1));
			NewINS( pEB, NOP()->SetLabel(labelStr));
		}
		labelStr = contextStr + "jump_to_terminate";
		NewINS( pEB, CMP5 (GMNum - 1, reg_b - 1) ); // Current GM is the last running
		NewINS( pEB, BNZ9P (labelStr) );
		// This is final GM, need to jump to NM_epilogue
		NewINS( pEB, MOV32P("NM_epilogue", reg_a));
		NewINS( pEB, JMP32 (reg_a));

		NewINS( pEB, MOV32P(contextStr + "terminate", reg_b)->SetLabel(labelStr));
		NewINS( pEB, JMP32(reg_b) );

		vNode->push_back(pEB);
	}
	return vNode;
}


void CBlockManager::GenVerifier(CCodeBlock* pCB, TBlockConfig* pCfg) {

	const UI32		GRNUM = 32;
	const UI32		TempR =  1;
	const UI32		TempS =  31;
	
	const UI32		TempX =  2;  // Memory DWORD LOAD
	const UI32		TempY =  4;  // Memory DWORD LOAD
	
	CSimResource*	res;
	const char* opt = g_cfg->m_strSelfCheck.c_str();
	bool bGr = std::strpbrk(opt, "Gg");
	bool bVr = std::strpbrk(opt, "Vv");
	bool bSr = std::strpbrk(opt, "Ss");
	bool bMm = std::strpbrk(opt, "Mm");
	
	if (pCB == nullptr || ((res = pCB->GetSnapShot()) == nullptr)) {
		return;
	}
	pCB->FreeAddress();
	std::string fail_handler = GetMContext(pCfg) + "verify_fail";
	UI32 inum = pCB->GetInstructionNum();

	// ¸å¤í¤ËÄÉ²Ã¤·¤Æ¤¤¤­ºÇ¸å¤Ë¥í¡¼¥Æ¡¼¥·¥ç¥ó
	//-------------- Must --------------------
	if (bSr) {
		// NC:SR(5,0)PSWは最初に比較する
		SRSET& ms = res->m_nc;
		auto sv = std::find_if (ms.begin(), ms.end(), [](const SRVAL& v){return v.first == (0<<5 | 5);});
		if (sv != ms.end()) {

			ms.erase(std::remove(ms.begin(), ms.end(), *sv), ms.end());
		}
	}

	//--------------- GR ---------------------
	if (bGr) {
		const GRLST& gs = res->m_gr;
		for (UI32 r = 0; r < GRNUM; r++) {
			if (r == TempR || r == TempS) {
				continue; // Temporary gr NOT to be compared 
			}
			if (gs[0][r] != 0) { 
				NewINS( pCB,  MOV32( gs[0][r], TempR) );
				NewINS( pCB,  CMPR( TempR, r) );
			}else{
				// r0で命令サイズ節約
				NewINS( pCB,  CMPR( 0, r) );
			}
			NewINS( pCB,  BNE17P(fail_handler.c_str()) );
		}
		for (UI32 t = 1; t < gs.size(); t++) {
			NewINS( pCB,  MOV5(t, TempR) );
			NewINS( pCB,  LDSR(TempR, 10, 1) ); //TCSEL
			const GRSET& ge = gs[t]; // gs[t]:スレッドID＝tのr0-31の期待値が配列になっている
			for (UI32 r = 0; r < GRNUM; r++) {
				if (ge[r] != 0) {
					NewINS( pCB,  MOV32( ge[r], TempR) );
					NewINS( pCB,  STTC_GR( r, TempS ) );
					NewINS( pCB,  CMPR(TempR, TempS) );
				}else{
					// r0で命令サイズ節約
					NewINS( pCB,  STTC_GR( r, TempS ) );
					NewINS( pCB,  CMPR(0, TempS) );
				}
				NewINS( pCB,  BNE17P(fail_handler.c_str()) );
			}
		}
	}
	
	if (bVr) {
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
	}
	
	//--------------- SR ---------------------
	// NC
	SwitchCoProcessor(pCB, 2, 3);

	// Set MCTL.MA = 1 to avoid MAE cause by selfcheck ld/st instructions
	// TODO: Define macro to specify this item that only support in G4KH
	NewINS( pCB,  MOV32(0x00000002, TempR) );
	NewINS( pCB,  LDSR(TempR, 5, 1) ); //MCTL <= 0x00000002


	if (bSr) {
		const SRSET& ns = res->m_nc;
		for (UI32 r = 0; r < ns.size(); r++) {
			UI32 selid = ns[r].first >> 5;
			UI32 regid = ns[r].first & 31;
			UI32 value = ns[r].second;
			NewINS( pCB,  MOV32(value, TempR) );
			NewINS( pCB,  STSR( regid, TempS, selid) );
			NewINS( pCB,  CMPR( TempR, TempS) );
			NewINS( pCB,  BNE17P(fail_handler.c_str()) );
		}
		// VC
		for (UI32 v = 0; v < res->m_vc.size(); v++) {
			NewINS( pCB,  MOV5(v, TempR) );
			NewINS( pCB,  LDSR(TempR, 15, 1) ); //VCSEL
			const SRSET& vs = (res->m_vc)[v];
			for (UI32 r = 0; r < vs.size(); r++) {
				UI32 selid = vs[r].first >> 5;
				UI32 regid = vs[r].first & 31;
				UI32 value = vs[r].second;
				NewINS( pCB, MOV32( value, TempR) );
				NewINS( pCB, STVC_SR( regid, TempS, selid ) );
				NewINS( pCB, CMPR(TempR, TempS) );
				NewINS( pCB, BNE17P(fail_handler.c_str()) );
			}
		}
		// TC
		for (UI32 t = 0; t < res->m_tc.size(); t++) {
			NewINS( pCB,  MOV5(t, TempR) );
			NewINS( pCB,  LDSR(TempR, 10, 1) ); //TCSEL
			const SRSET& ts = (res->m_tc)[t];
			for (UI32 r = 0; r < ts.size(); r++) {
				UI32 selid = ts[r].first >> 5;
				UI32 regid = ts[r].first & 31;
				UI32 value = ts[r].second;
				NewINS( pCB, MOV32( value, TempR) );
				NewINS( pCB, STTC_SR( regid, TempS, selid ) );
				NewINS( pCB, CMPR(TempR, TempS) );
				NewINS( pCB, BNE17P(fail_handler.c_str()) );
			}
		}
	}
	
	if (bMm) {
		//memory
		std::vector<T_MEMWRRECORD>& ml = res->m_logs;
		std::vector<T_MEMWRRECORD>::iterator i;

		std::set<MEMRANGE> sRegisterBank = g_RegisterBankAddr.KeySet();
		bool bIsRegBankAdd = false;
	
		UI32 len = 0;
		UI32 count = 0;
		std::string failed_selfcheck = fail_handler + "_0";
		const UI32 BR17_MAX_LEN = 65535 - 64;				// Diplacement 17bits - reserve sized for intermediate failed_selfcheck

		std::vector<T_MEMWRRECORD> vMl;
		std::vector<T_MEMWRRECORD>::iterator itr;
		for (i = ml.begin(); i != ml.end(); ++i) {
			UI32 ep   = 30;
			UI32 addr = i->first;
			UI32 size = i->second.first;
			UI64 data = i->second.second;
			// 部分重複は無いはず->addr一点で除外判断する
			if(g_prf->IsShareMem(addr) || g_prf->IsValidMem (addr) == false) {
				//fprintf (stderr, "Skip verify at address %08x, becase of system area...\n", addr);
				continue; // このエントリは除外
			}
			
			if (g_prf->IsTempMem(addr)) {
				continue; // このエントリは除外
			}

            if (g_sim->IsNotSelfCheckMemory(addr)) {
                continue;
            }

			if(g_LoadableAddr.GetMemError(addr) == true || g_StorableAddr.GetMemError(addr) == true || g_RmwAddr.GetMemError(addr) == true)
				continue;

			std::set<MEMRANGE>::iterator sitr;
			for (sitr = sRegisterBank.begin(); sitr != sRegisterBank.end(); sitr++) {
				if ((sitr->first <= addr) && (addr < sitr->second)) {
					bIsRegBankAdd   = true;
					break;
				}
			}
			//!< Checking is belong into Register bank area.
			if ( bIsRegBankAdd ) {
				continue;
			}
			if (size==1) {
				NewINS( pCB, MOV32( addr, ep) );
				NewINS( pCB, SLDBU (0, TempR) ); // ep
				NewINS( pCB, MOV32( (UI8)data, ep) );
				NewINS( pCB, CMPR(TempR, ep) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 20;
			}
			else
			if (size==2) {
				NewINS( pCB, MOV32( addr, ep) );
				NewINS( pCB, SLDHU (0, TempR) ); // ep
				NewINS( pCB, MOV32( (UI16)data, ep) );
				NewINS( pCB, CMPR(TempR, ep) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 20;
			}
			else
			if (size==4) {
				NewINS( pCB, MOV32( addr, TempS) );
				NewINS( pCB, LDW16 (0, TempS, TempR) );
				NewINS( pCB, MOV32( (UI32)data, TempS) );
				NewINS( pCB, CMPR(TempR, TempS) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 22;
			}
			else
			if (size==8) {
				UI32 lo = (UI32)(data & 0xffffffffU);
				UI32 hi = (UI32)(data >> 32);
				NewINS( pCB, MOV32( addr, TempS) );
				NewINS( pCB, LDDW23 (0, TempS, TempX) );
				NewINS( pCB, MOV32( lo, TempY) );
				NewINS( pCB, MOV32( hi, TempY+1) );
				NewINS( pCB, CMPR(TempX, TempY) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				NewINS( pCB, CMPR(TempX+1, TempY+1) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 36;
			}

			if(len > BR17_MAX_LEN) { // Generate intermedia target for failed self-checking
				std::stringstream ss;
				std::string label;

				count++;
				len = 0;
				ss << fail_handler << "_" << count << std::endl;
				ss >> label;

				NewINS( pCB, BR9(6));						// Jump over intermediate failed_selfcheck
				IInstruction *p = JR22P(label)->SetLabel(failed_selfcheck);	// Jump back to previous failed_selfcheck
				pCB->AddOpeCode(p);
				failed_selfcheck = label;
			}
		}
		NewINS( pCB, BR9(6));											// Jump over intermediate failed_selfcheck
		NewINS( pCB, JR22P(fail_handler)->SetLabel(failed_selfcheck));	// Jump back to previous failed_selfcheck
	}
	
	NewINS( pCB, NOP() );
	pCB->Rotate(inum);
}



//
// テストパタン終了処理を生成する
//
std::vector<CTerminateBlock*>* CBlockManager::GenerateTerminateBlock(TBlockConfig* pCfg) {
	
	std::vector<CTerminateBlock*>* vNode = new std::vector<CTerminateBlock*>();
	CTerminateBlock* pTB = NULL;
	std::string cstrM = GetMContext(pCfg);
	UI32 addr = g_wm.GM_TERMINATE_FLAG;
    pTB = new CTerminateBlock( cstrM + "terminate");
	pTB->SetOutputFlag(true);
	const UI32 reg1 = 9;
	const UI32 reg2 = reg1 + 1;
	if (pCfg->m_bNC) {
		//Check end flag of other GM
		for (UI32 pos = 0; pos < g_cfg->m_mGMs.size(); pos++) {
			//Get GPID
			std::map<UI32, GM_Infor>::iterator itr = g_cfg->m_mGMs.begin();
			std::advance( itr, pos);
			UI32 GMID = itr->first;
			addr = g_wm.GM_TERMINATE_FLAG;
			// Label for terminated GM
			std::string labelStr("");
			std::stringstream ss;
			ss << "GM" << GMID << "_terminated" ;
			ss >> labelStr;
			addr += 4 * GMID;
			// Clear SYSERR pending
			NewINS( pTB, LDSR(0, 17, 13));

			NewINS( pTB, MOV32(addr, reg1));
			NewINS( pTB, LDB16 (0, reg1, reg2) );
			NewINS( pTB, CMP5 (1, reg2) );
			NewINS( pTB, BZ9P (labelStr) );
			// If current GM is the last GM. Does not call HVTRAP
			NewINS( pTB, STSR (15, reg1, 0) );  // PSWH
            NewINS( pTB, SHR5 (8, reg1));
			NewINS( pTB, ANDI (0x7, reg1, reg1) );    //PSWH.GPID
			NewINS( pTB, CMP5 (GMID, reg1) );
			NewINS( pTB, BZ9P (labelStr) );
			// Start pending GM
			NewINS( pTB, HVTRAP (GMID) );
			NewINS( pTB, NOP ()->SetLabel(labelStr) );
			// Init 0x0 for terminate memory
			extern std::unique_ptr<ISimulatorControl>		g_sim;
			ISimulator* pSim = g_sim->GetSimulator();
			pSim->PresetMemory(true, 0, addr, 4, 0x0);
		}

        AddPeNotifyComplete(pCfg, pTB);
        if (g_cfg->m_nSysPeNum != 0) {
            AddPeWaitComplete(pCfg, pTB);
        }
		// Clear SYSERR pending
		NewINS( pTB,  LDSR(0, 17, 13));
	    NewINS( pTB,  MOV32( 0xffff7ffc, reg1) );
	    NewINS( pTB,  STH16(0 , 0U , reg1) );
	    NewINS( pTB,  MOVEA(0x0010 , 0 , reg2) );
	    NewINS( pTB,  STH16(10 , 2U , reg1) );
	    NewINS( pTB,  HALT() );
	    NewINS( pTB,  BR9(-8) );
	    NewINS( pTB,  NOP()  );
	    NewINS( pTB,  NOP()  );
	    NewINS( pTB,  NOP()  );
	} else {
		// Store flag into memory to terminate current GM
		NewINS( pTB, MOV32(addr + 4*pCfg->m_GMID, reg1) );
		NewINS( pTB, MOV5 (1, reg2) );
		NewINS( pTB, STB16 (reg2, 0, reg1) );
		// Jmp to main block
	    NewINS( pTB,  MOV32P("NM_terminate", reg1));
	    NewINS( pTB,  JMP32(reg1)  );
		NewINS( pTB,  NOP()  );
    }
    vNode->push_back(pTB);
	return vNode;
}

std::vector<CFunctionBlock*>* CBlockManager::GenerateFunction(TBlockConfig* pCfg) {
	FROG_ASSERT(pCfg);
	FROG_ASSERT(pCfg->InsNum);
	std::vector<CFunctionBlock*>* vNode = new std::vector<CFunctionBlock*>();

    // Generating function block for jarl labeling
    GenerateJarlFunction(pCfg, vNode);

	return vNode;

}

void CBlockManager::GenerateJarlFunction(TBlockConfig* pCfg, std::vector<CFunctionBlock*>* pVFB) {
	// JARL共通ルーチンとなるコードブロックを生成する
	// このコードブロックは補正しない
	//（何度も呼ばれるため、呼ばれるたびに補正されるとシミュレーションが矛盾する）
	// よって制約がつくメモリアクセス命令は出さない。
	// FPU命令にも制約がつくがここでは制約を外して出すようにする(暫定)
	
	auto IsInvalidLDSR = [] (UI32 sr)->bool {
		UI32 const NO_MASK = 0xffffffff;
		if((sr >> 5) == 0x5 /*MPU SRs*/ 
				|| (sr == (1*32) +  0)  /* SPID */ 
                || (sr == (1*32) + 16)  /* HVCFG */
				|| (sr == (0*32) +  5)  /* PSW */
				|| (sr == (0*32) +  16) /* CTPC */
				|| (sr == (0*32) +  0)  /* EIPC */
				|| (sr == (9*32) +  0)  /* GMEIPC */
			    || (sr == 32 * 0 + 13)  /* EIIC */
				|| (sr == 32 * 0 + 28)) /* EIWR */ {
			
			return true;
		}
		if(g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK) {
			return true;
		}
		return false;
	};
	
	// LP= GR[F]のファンクションコードを生成する。
	// このブロックの中の命令はGR[F]の値を保持するような命令で構成される。
	for (UI32 F = 1; F < 32; F++) {	
		UI32 nValidRegSet = ~(m_nMismatchRegSet | (1 << F));
		// label
		std::stringstream ss;
		ss << ("function_") << std::dec << F;

		CFunctionBlock* pCb = new CFunctionBlock();
		pCb->SetOutputFlag(true);			// 出力ON
		pCb->EnableRegulation(false);		// 補正不可
		pCb->SetLabel(ss.str().data());		// __function_NN
		pCb->SetStatistics(true);			// コード生成カバレッジ蓄積対象
			
		UI32 i;		// Index
		UI32 m; 	// Give up genearationg function call.
		UI32 g = pCfg->InsNum + 10; 	// Give up genearationg function call.
		IInstruction* pIns;

		// iが所定の命令数になるまでループする
		// mは生成トライ回数でg(必要命令数の10倍回数チャレンジした場合、Giveupする)
		for (i = m = 0; ((i < pCfg->InsNum) && (m < g)) ; m++) { 
			// LPにGR[i]を使うルーチンである為、GR[i]を別のレジスタにする
			pIns = m_nrmSet.CreateIns()->Fix();
			FROG_ASSERT(pIns);
			
			// 制約ありは除外
			if (pIns->HasConstraint() || pIns->IsComplex() || pIns->Behavior(IInstruction::LOAD_MEMORY) || 
				pIns->Behavior(IInstruction::STORE_MEMORY) || pIns->Behavior(IInstruction::JMP) || pIns->GetOprIdxMistmatch() != 0) {
				delete pIns;
				continue;
			}
			if(pIns->GetMne() == "ei" || pIns->GetMne() == "di" || pIns->GetMne() == "halt"){
				delete pIns;
				continue;
			}
			
			// 現状の制約(TODO:Modify)
			if (pIns->GetMne()=="sttc.pc" || pIns->GetMne()=="stsr" || pIns->GetMne()=="stvc.sr" || pIns->GetMne()=="sttc.sr") {
				delete pIns;
				continue;
			}
			
			//if(pIns->Behavior(IInstruction::LOAD_SR))
			if(pIns->GetMne() == "ldsr" || pIns->GetMne() == "ldtc.sr" || pIns->GetMne() == "ldvc.sr"){
				UI32 const RETRY_TIMES = 10; // Give up to generate system reg.
				UI32 nCount = 0;
				UI32 sr = (UI32)*(pIns->opr(1));
				while( IsInvalidLDSR(sr) && nCount < RETRY_TIMES){
					// Generate other system register.
					sr = (UI32)*(pIns->opr(1)->ReFix());
					nCount++;
				}
				if (nCount == RETRY_TIMES){
					delete pIns;
					continue;
				}
			}
			
			for (UI32 p = 0; p < pIns->GetOpNum(); p++) {
				IOperand* popr = pIns->opr(p);
				popr->ReplaceIdxFromList(nValidRegSet);

			}
			pCb->AddOpeCode(pIns);
			i++;
		}
		
		pIns = JMP32(F);
		pIns->AppendComment("--> Return");
		pCb->AddOpeCode(pIns);
	
		AddDeadCode(pCb);
		
		pVFB->push_back(pCb);
	}
	
	return;
}

/**
 * @brief	Generate code to update MPU configuration
 * @param	pCfg config information
*/
std::vector<CFunctionBlock*>* CBlockManager::GenerateMPUpdate(TBlockConfig* pCfg)
{
	std::string cstrM = GetMContext(pCfg);
	std::vector<CFunctionBlock*>* pVFB = new std::vector<CFunctionBlock*>();
    UI32 gap_size = 0xAA;

    for (UI32 idx = 0; idx < m_vMPUpdate.size(); idx++) {
		std::stringstream ss;
		ss << (cstrM + "mpu_function_") << std::dec << idx;

		CFunctionBlock* pCb = new CFunctionBlock();
		pCb->SetOutputFlag(true);
		pCb->EnableRegulation(true);
		pCb->SetLabel(ss.str().data());
        pCb->SetBlockGap(gap_size);

		IInstruction * pIns;
        UI32 reg = m_nWorkReg;

		pIns = MOV32P("disable_mpu", reg);
		pCb->AddOpeCode(pIns);
		pIns = JARL32(reg, 31);
		pCb->AddOpeCode(pIns);
        pVFB->push_back(pCb);
	}
	return pVFB;
}

/**
* @brief	Generate code to change privilege to UM
* @param	pCfg config information
* @param	pVFB output parameter of function codeblock
*/
void CBlockManager::GenerateChangePrivilegetoUM(TBlockConfig* pCfg, std::vector<CPreloadBlock*>* pVFB) {
	
	// label
	std::stringstream ss;
	ss << ("function_ChangePrivilegetoUM");

    CPreloadBlock* pCB = new CPreloadBlock();
	pCB->SetOutputFlag(true);			// Output to Assembly file
	pCB->EnableRegulation(false);		// Do not regulation
	pCB->SetLabel(ss.str().data());		// Name of funtion
	pCB->SetStatistics(true);			// Code generation coverage accumulation target
    pCB->SetFreeAlloc(false);			// Do not random allocate memory address of code block

	UI32 reg = 0, targetReg = 0, randomReg = 0;

    auto AddIns = [](CCodeBlock* pCb, IInstruction* pIns, std::string comment) {
        pCb->AddOpeCode(pIns);
        pIns->AppendComment(comment.c_str());
    };

    auto AddInsChange = [&](UI32 regID, UI32 selID) {
		ss << "_GM_mode";
		// Check HV mode to back up PSWH
		AddIns(pCB, STSR(15, targetReg, 0), " changing privilege ");     // PSWH
        AddIns(pCB, SHR5(0x1f, targetReg), " changing privilege ");     // PSWH.GM
		AddIns(pCB, BNZ9P(ss.str().data()), " changing privilege ");
		// Back up PSWH
		AddIns(pCB, STSR(15, targetReg, 0), " changing privilege ");
		if (regID == 1) {
			AddIns(pCB, LDSR(targetReg, 18, 0), " changing privilege ");
		} else {
			AddIns(pCB, LDSR(targetReg, 19, 0), " changing privilege ");
		}
        AddIns(pCB, STSR(5, targetReg, 0)->SetLabel(ss.str().data()), " changing privilege ");
        AddIns(pCB, MOV32(0x40000000, reg), " changing privilege ");
        AddIns(pCB, OR(reg, targetReg), " changing privilege ");
        AddIns(pCB, LDSR(targetReg, regID, selID), " UM_Mode ");
    };

    auto GetCauseCode = [](UI32 cause) -> UI32 {
        UI32 causeCode = 0;
        switch (cause) {
            case INS_ID_SYSCALL:
                causeCode = 0xff;
                break;
            case INS_ID_HVCALL:
            case INS_ID_TRAP:
                causeCode = 0x1e;
                break;

            case INS_ID_FETRAP:
                causeCode = 0xe;
                break;
        }
        return causeCode;
    };
			

	//Avoid handler register and jarl return register
	//Avoid mismatch register when enable MAU. reg and target reg are already overwritten
    do {
        reg = g_rnd.GetRange(1, 31);
    } while (reg + 2 > 31 || (reg <= m_nHandlerReg && m_nHandlerReg <= reg + 2) || ((m_nMismatchRegSet & (1 << (reg + 2))) != 0));

    targetReg = reg + 1;
    randomReg = reg + 2;

    // check status before changing privilege
    AddIns(pCB, STSR(5, targetReg, 0), " check status before changing privilege to UM ");
    AddIns(pCB, MOV32(0x40000000, reg), " check status before changing privilege to UM ");
    AddIns(pCB, AND(targetReg, reg), " check status before changing privilege to UM ");
    AddIns(pCB, BNZ9P("UM_Mode"), " check status before changing privilege to UM ");

	// Random instruction to change privilege base on general-register
    // get the last 3 bits
    AddIns(pCB, SHL5(29, randomReg), " random way to change privilege ");
    AddIns(pCB, SHR5(29, randomReg), " random way to change privilege ");

    AddIns(pCB, CMP5(0x1, randomReg), "");
    AddIns(pCB, BZ9P("ChangePrivilegetoUM_by_EIRET"), "");
    AddIns(pCB, CMP5(0x2, randomReg), "");
    AddIns(pCB, BZ9P("ChangePrivilegetoUM_by_FERET"), "");
    AddIns(pCB, CMP5(0x3, randomReg), "");
    AddIns(pCB, BZ9P("ChangePrivilegetoUM_by_SYSCALL"), "");
    AddIns(pCB, CMP5(0x4, randomReg), "");
    AddIns(pCB, BZ9P("ChangePrivilegetoUM_by_TRAP"), "");
    AddIns(pCB, CMP5(0x5, randomReg), "");
    AddIns(pCB, BZ9P("ChangePrivilegetoUM_by_FETRAP"), "");
    
	// default is LDSR
    AddInsChange(5, 0);
    AddIns(pCB, SYNCI(), "");
    AddIns(pCB, BR9P("UM_Mode"), "");
   
    // use EIRET
    AddIns(pCB, MOV32P("UM_Mode", reg)->SetLabel("ChangePrivilegetoUM_by_EIRET"), " changing privilege ");
    AddIns(pCB, LDSR(reg, 0, 0), " changing privilege ");
    AddInsChange(1, 0);
    AddIns(pCB, EIRET(), " UM_Mode ");

    // use FERET
    AddIns(pCB, MOV32P("UM_Mode", reg)->SetLabel("ChangePrivilegetoUM_by_FERET"), " changing privilege ");
    AddIns(pCB, LDSR(reg, 2, 0), " changing privilege ");
    AddInsChange(3, 0);
    AddIns(pCB, FERET(), " UM_Mode ");
	
    // use SYSCALL
    AddIns(pCB, LDSR(m_nHandlerReg, 28, 0)->SetLabel("ChangePrivilegetoUM_by_SYSCALL"), " changing privilege ");
    AddIns(pCB, SYSCALL(GetCauseCode(INS_ID_SYSCALL)), " UM_Mode ");
    AddIns(pCB, BR9P("UM_Mode"), "");

    // use TRAP
    AddIns(pCB, TRAP(GetCauseCode(INS_ID_TRAP))->SetLabel("ChangePrivilegetoUM_by_TRAP"), " UM_Mode ");
    AddIns(pCB, BR9P("UM_Mode"), "");

    // use FETRAP
    AddIns(pCB, FETRAP(GetCauseCode(INS_ID_FETRAP))->SetLabel("ChangePrivilegetoUM_by_FETRAP"), " UM_Mode ");

    AddIns(pCB, JMP32(m_nHandlerReg)->SetLabel("UM_Mode"), " --> Return ");

	AddDeadCode(pCB);
	pVFB->push_back(pCB);
    return;
}

/**
* @brief	Generate code to change privielege to SV(HV)
* @param	pCfg config information
* @param	pVFB output parameter of function codeblock
*/
void CBlockManager::GenerateChangePrivilegetoSV_HV(TBlockConfig* pCfg, std::vector<CPreloadBlock*>* pVFB) {
	// label
	std::stringstream ss;
	ss << ("function_ChangePrivilegetoSV_HV");

    CPreloadBlock* pCB = new CPreloadBlock();
	pCB->SetOutputFlag(true);			// Output to Assembly file
	pCB->EnableRegulation(false);		// Do not regulation
	pCB->SetLabel(ss.str().data());		// Name of funtion
	pCB->SetStatistics(true);			// Code generation coverage accumulation target
    pCB->SetFreeAlloc(false);			// Do not random allocate memory address of code block

	UI32 reg = 0, targetReg = 0, randomReg = 0;

	auto GetCauseCode = [](UI32 cause) -> UI32 {
		UI32 causeCode = 0;
		switch (cause) {
			case INS_ID_TRAP:
				causeCode = 0x1d;
				break;

			case INS_ID_FETRAP:
				causeCode = 0xd;
				break;
		}
		return causeCode;
	};

    auto AddIns = [](CCodeBlock* pCb, IInstruction* pIns, std::string comment) {
        pCb->AddOpeCode(pIns);
        pIns->AppendComment(comment.c_str());
    };
	//Avoid handler register and jarl return register
	//Avoid mismatch register when enable MAU. reg and target reg are already overwritten
	do {
        reg = g_rnd.GetRange(1, 31);
	} while (reg + 2 > 31 || (reg <= m_nHandlerReg && m_nHandlerReg <= reg + 2) || ((m_nMismatchRegSet & (1 << (reg + 2))) != 0));

    targetReg = reg + 1;
    randomReg = reg + 2;

	// check status before changing privilege
    AddIns(pCB, STSR(5, targetReg, 0), " check status before changing privilege to SV_HV ");
    AddIns(pCB, MOV32(0x40000000, reg), " check status before changing privilege to SV_HV ");
    AddIns(pCB, AND(targetReg, reg), " check status before changing privilege to SV_HV ");
    AddIns(pCB, BZ9P("SV_HV_Mode"), " check status before changing privilege to SV_HV ");

    // Random instruction to change privilege base on general-register
    // get the last bits
    AddIns(pCB, SHL5(31, randomReg), " random way to change privilege ");
    AddIns(pCB, SHR5(31, randomReg), " random way to change privilege ");
    AddIns(pCB, CMP5(0x0, randomReg), " random way to change privilege ");
    AddIns(pCB, BZ9P("ChangePrivilegetoSV_HV_by_FETRAP"), " changing privilege");

    // randomReg != 0, use TRAP
    AddIns(pCB, TRAP(GetCauseCode(INS_ID_TRAP)), " SV_HV_Mode ");
    AddIns(pCB, BR9P("SV_HV_Mode"), " changing privilege ");

    // use FETRAP
    AddIns(pCB, FETRAP(GetCauseCode(INS_ID_FETRAP))->SetLabel("ChangePrivilegetoSV_HV_by_FETRAP"), "SV_HV_Mode");

    AddIns(pCB, JMP32(m_nHandlerReg)->SetLabel("SV_HV_Mode"), " --> Return ");

	AddDeadCode(pCB);
	pVFB->push_back(pCB);
	return;
}

/**
* @brief	Generate code to change mode to GM
* @param	pCfg config information
* @param	pVFB output parameter of function codeblock
*/
void CBlockManager::GenerateChangeModetoGM(TBlockConfig* pCfg, std::vector<CPreloadBlock*>* pVFB) {
	// label
	std::stringstream ss;
	ss << ("function_ChangeModetoGM");

    CPreloadBlock* pCB = new CPreloadBlock();
	pCB->SetOutputFlag(true);			// Output to Assembly file
	pCB->EnableRegulation(false);		// Do not regulation
	pCB->SetLabel(ss.str().data());		// Name of funtion
	pCB->SetStatistics(true);			// Code generation coverage accumulation target
    pCB->SetFreeAlloc(false);			// Do not random allocate memory address of code block

    UI32 reg = 0, targetReg = 0, randomReg = 0;

    auto AddIns = [](CCodeBlock* pCb, IInstruction* pIns, std::string comment) {
        pCb->AddOpeCode(pIns);
        pIns->AppendComment(comment.c_str());
    };

    auto AddInsChange = [&](UI32 flag, UI32 regID, UI32 selID) {
        switch (flag) {
            case 0:
                AddIns(pCB, STSR(15, targetReg, 0), " Changing mode ");
                AddIns(pCB, MOV32(0x80000000, reg), " Changing mode ");
                AddIns(pCB, OR(reg, targetReg), " Changing mode ");
                AddIns(pCB, LDSR(targetReg, regID, selID), " Changing mode ");     // Set XXPSWH
                break;
            case 1:
                AddIns(pCB, STSR(5, reg, 0), " changing mode ");
                AddIns(pCB, LDSR(reg, regID, selID), " changing mode ");
                break;
        }
    };
	//Avoid handler register and jarl return register
	//Avoid mismatch register when enable MAU. reg and target reg are already overwritten
    do {
        reg = g_rnd.GetRange(1, 31);
    } while (reg + 2 > 31 || (reg <= m_nWorkReg && m_nWorkReg <= reg + 2) || (m_nMismatchRegSet & (1 << (reg + 2))) != 0);

    targetReg = reg + 1;
    randomReg = reg + 2;

	// check whether current mode is HM or not.
    AddIns( pCB, STSR(15, reg, 0), " check status before changing mode to GM ");    // PSWH.GM
    AddIns( pCB, SHR5(0x1f, reg), " check status before changing mode to HM ");
    AddIns( pCB, BNZ9P("GM_Mode"), " check status before changing mode to GM ");

	// check whether current privilege is HV or not.
    AddIns( pCB, STSR(5, targetReg, 0), " check status before changing mode to GM ");
    AddIns( pCB, MOV32(0x40000000, reg), " check status before changing mode to GM ");
    AddIns( pCB, AND(targetReg, reg), " check status before changing mode to GM ");
    AddIns( pCB, BNZ9P("GM_Mode"), " check status before changing mode to GM ");

    // Random instruction to change mode base on general-register
    // get the last bit
    AddIns( pCB, SHL5(31, randomReg), " random way to change mode ");
    AddIns( pCB, SHR5(31, randomReg), " random way to change mode ");
    AddIns( pCB, CMP5(0x0, randomReg), " random way to change mode ");
    AddIns( pCB, BZ9P("Changemode_by_EIRET"), " random way to change mode ");

    // If randomReg != 0, use FERET to change mode
    AddIns(pCB, MOV32P("GM_Mode", reg), " changing mode ");
    AddIns(pCB, LDSR(reg, 2, 0), " changing mode ");
    AddInsChange(0, 19, 0);
    AddInsChange(1, 3, 0);
    AddIns( pCB, FERET(), " GM_Mode ");

    // use EIRET
    AddIns( pCB, MOV32P("GM_Mode", reg)->SetLabel("Changemode_by_EIRET"), " changing mode ");
    AddIns( pCB, LDSR(reg, 0, 0), " changing mode ");
    AddInsChange(0, 18, 0);
    AddInsChange(1, 1, 0);
    AddIns( pCB, EIRET(), " GM_Mode ");

    AddIns(pCB, SYNCM()->SetLabel("GM_Mode"), " GM_Mode ");
    AddIns(pCB, JMP32(m_nWorkReg), " --> Return ");

	AddDeadCode(pCB);
	pVFB->push_back(pCB);
	return;
}

/**
* @brief	Generate code to change mode to HM
* @param	pCfg config information
* @param	pVFB output parameter of function codeblock
*/
void CBlockManager::GenerateChangeModetoHM(TBlockConfig* pCfg, std::vector<CPreloadBlock*>* pVFB) {

	// label
	std::stringstream ss;
	ss << ("function_ChangeModetoHM");

    CPreloadBlock* pCB = new CPreloadBlock();
	pCB->SetOutputFlag(true);			// Output to Assembly file
	pCB->EnableRegulation(false);		// Do not regulation
	pCB->SetLabel(ss.str().data());		// Name of funtion
	pCB->SetStatistics(true);			// Code generation coverage accumulation target
    pCB->SetFreeAlloc(false);			// Do not random allocate memory address of code block

	UI32 reg = 0, targetReg = 0;

    auto AddIns = [](CCodeBlock* pCb, IInstruction* pIns, std::string comment) {
        pCb->AddOpeCode(pIns);
        pIns->AppendComment(comment.c_str());
    };

	//Avoid handler register and jarl return register
	//Avoid mismatch register when enable MAU. reg and target reg are already overwritten
    do {
        reg = g_rnd.GetRange(1, 31);
    } while (reg + 1 > 31 || reg == m_nWorkReg || (reg + 1) == m_nWorkReg);

    targetReg = reg + 1;

	// check whether current mode is GM or not.
    AddIns(pCB, STSR(15, reg, 0), " check status before changing mode to HM ");    // PSWH
    AddIns(pCB, SHR5(0x1f, reg), " check status before changing mode to HM ");   // PSWH.GM
    AddIns(pCB, BZ9P("HM_Mode"), " check status before changing mode to HM ");

    // check whether current privilege is SV or not.
    AddIns(pCB, STSR(5, targetReg, 0), " check statussynchronized before changing mode to HM ");
    AddIns(pCB, MOV32(0x40000000, reg), " check status before changing mode to HM ");
    AddIns(pCB, AND(targetReg, reg), " check status before changing mode to HM ");
    AddIns(pCB, BNZ9P("HM_Mode"), " check status before changing mode to GM ");
    
    AddIns(pCB, HVTRAP(0x1e), " HM_Mode ");
    AddIns(pCB, SYNCM()->SetLabel("HM_Mode"), " GM_Mode ");
    AddIns(pCB, JMP32(m_nWorkReg), " --> Return ");

	AddDeadCode(pCB);
	pVFB->push_back(pCB);
	return;
}

void CBlockManager::BackupMachineResource(CCodeBlock * pCB, UI32 regMem, UI32 expLevel){
	IInstruction* pIns;
	UI32 reg = g_rnd.GetRange(1, 29);
	while (reg == regMem)
		reg = g_rnd.GetRange(1, 29);
	//  | PC | SRs | GRs |
	// PC is stored in XXPC by HVTRAP/XXINT change machine
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		pIns = STSR(0, reg, 0);
	} else {
		pIns = STSR(2, reg, 0);
	}
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Store PC into memory. 
	pIns = STW16(reg, 0x0, regMem);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Increase Memory address for next backup
	pIns = ADD5(4, regMem); // PC = 4 bytes
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Store system registers
	pIns = STM_GSR(regMem);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Increase Memory address for next backup
	pIns = ADDI(144, regMem, regMem); // SRs = 37*4
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Store MPU system registers
	pIns = STM_MP(0, 31, regMem);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Increase Memory address for next backup
	pIns = ADDI(384, regMem, regMem); // SRs = 32*4*3
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Get MPCFG system registers
	pIns = STSR(2, reg, 5);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Store MPCFG system registers to keep HBE bit
	pIns = STW16(reg, 0x0, regMem);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
}

void CBlockManager::RestoreMachineResource(TBlockConfig* pCfg, CCodeBlock * pCB, UI32 gpidReg, UI32 regMem, UI32 expLevel){
	IInstruction* pIns;
	UI32 reg = g_rnd.GetRange(1, 31);
	while (reg == regMem || reg == gpidReg)
		reg = g_rnd.GetRange(1, 31);
	//  | PC | SRs | GRs |
	// Restore PC
	pIns = LDW16(0x0, regMem, reg);
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	// Store into XXPC for HVTRAP return
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		pIns = LDSR(reg, 0, 0);
	} else {
		pIns = LDSR(reg, 2, 0);
	}
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	// Increase Memory address for next backup
	pIns = ADD5(4, regMem); // PC = 4 bytes
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	// Restore system registers
	pIns = LDM_GSR(regMem);
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	
	// Get XXPSWH.GPID
	pIns = SHL5 (0x8, gpidReg);
	pIns->SetLabel(pCB->GetLabel() + "_skip_update_to_GM");
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);

	//Update next GPID by XXPSWH
	pIns = LDSR (gpidReg, 18, 0);
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	pIns = LDSR(gpidReg, 19, 0);
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	// Determite PC is beginning of PE.
	// If Yes: change to GM
	// else: keep HM
	bool backupContext = pCfg->m_bNC;
	UI32 backupGMID = pCfg->m_GMID;
	for (UI32 pos = 0; pos < g_cfg->m_mGMs.size(); pos++) {
		// Virtual Context
		pCfg->m_bNC = false;
		std::map<UI32, GM_Infor>::iterator itr = g_cfg->m_mGMs.begin();
		std::advance( itr, pos);
		pCfg->m_GMID = itr->first;
		std::string contextStr = GetTContext(pCfg);

		pIns = MOV32P(contextStr + "codeblock_00", reg); // PC = 4 bytes
		pIns->AppendComment("Restore Machine Resource");
		pCB->AddOpeCode(pIns);

		if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
			pIns = STSR(0, gpidReg, 0);
		} else {
			pIns = STSR(2, gpidReg, 0);
		}
		pIns->AppendComment("Restore Machine Resource");
		pCB->AddOpeCode(pIns);
		NewINS(pCB, CMPR(reg, gpidReg));
		NewINS(pCB, BE9P(pCB->GetLabel() + "_update_GM"));
	}
	// Restore status
	pCfg->m_bNC = backupContext;
	pCfg->m_GMID = backupGMID;
	
	// Not update GM bit
	NewINS(pCB, BR9P(pCB->GetLabel() + "_skip_update_GM"));
	//Update GM bit
	NewINS(pCB, MOV32(0x80000000, reg)->SetLabel(pCB->GetLabel() + "_update_GM"));
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		pIns = STSR(18, gpidReg, 0);
	} else {
		pIns = STSR(19, gpidReg, 0);
	}
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);

	NewINS(pCB, OR(gpidReg, reg));
	if(expLevel == IExceptionConfig::EXP_LEVEL_EI){
		pIns = LDSR (reg, 18, 0);
	} else {
		pIns = LDSR(reg, 19, 0);
	}
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);

	// Increase Memory address for next backup
	pIns = ADDI(144, regMem, regMem); // SRs = 37*4
	pIns->SetLabel(pCB->GetLabel() + "_skip_update_GM");
	pIns->AppendComment("Restore Machine Resource");
	pCB->AddOpeCode(pIns);
	// Restore MPU system registers
	pIns = LDM_MP(regMem, 0, 31);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Increase Memory address for next backup
	pIns = ADDI(384, regMem, regMem); // SRs = 32*4*3
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Get MPCFG system registers
	pIns = LDW16(0x0, regMem, reg);
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
	// Store MPCFG system registers to keep HBE bit
	pIns = LDSR(reg, 2, 5); 
	pIns->AppendComment("Backup Machine Resource");
	pCB->AddOpeCode(pIns);
}

CPreloadBlock* CBlockManager::GenerateCalltBlock(TBlockConfig* pCfg) {
	std::string contextStr = GetMContext(pCfg);
	CPreloadBlock*		pCallt = new CPreloadBlock(contextStr + "callt");
    pCallt->SetFreeAlloc(true);
	const UI32		callt_entry		= 64; // imm6
	const UI32		callt_insnum	= std::max(16U, callt_entry);//
	IInstruction*	pIns;
	UI32 offset = 0;
	std::vector<std::pair<UI32, IInstruction*>> dst;
	UI32 POS = 0;

	auto CheckJarlSubBlk = [&](IInstruction *pMid)
	{
		if (pCallt->IsBrTarget(pMid)) return pMid;
		if (pMid->Behavior(IInstruction::JMP)) return pMid;
		IInstruction *pTail = pMid;
		UI32 idx = pCallt->GetIndex(pMid);

		//find the first jump after this instruction
		while (idx != pCallt->GetInstructionNum()) {
			std::string tmpLabel = pCallt->at(idx)->GetJumpTarget();
			if (tmpLabel.length() > 0 ) {
				pTail = pCallt->at(idx);
				break;
			}
			idx++;
		}
		if (pTail->GetMne() != "jarl") return pMid;
		idx = pCallt->GetIndex(pMid);
		IInstruction *pHead = pMid;
		//find the first jump after this instruction
		while (idx >= POS) {
			if (pCallt->IsBrTarget(pCallt->at(idx)) || idx == POS) {
				pHead = pCallt->at(idx);
				break;
			}
			idx--;
		}
		return pHead;
	};

	pCallt->SetOutputFlag(true);			// 出力ON
	pCallt->EnableRegulation(true);		// 補正不可

	GenerateRandomCode(pCallt, callt_insnum, pCfg, "callt");
	bool firstChange = false;
	UI32 i = POS;
	while(i < pCallt->GetInstructionNum()) {
		pIns = pCallt->at(i);
		const std::string &mne = pIns->GetMne();

		if(pIns->GetComment().find("Changing") != std::string::npos) {
			if(firstChange == false)
				firstChange = true;
			else{
				offset += pIns->GetLen();
				i++;
				continue;
			}
		} else
			firstChange = false;

		if(pIns->GetRegulationTarget() != NULL) {
			IInstruction *pRegIns = pIns->GetRegulationTarget();
			if(pRegIns->GetMne() == "ctret") {
				UI32 idx = pCallt->GetIndex(pIns);
				IInstruction *pNext = pCallt->at(idx+1);
				pIns->DirMoveTo(pNext);
				pCallt->Remove(pIns);
				continue;
			}
		} else if (mne != ".hword" && mne != ".dword" && pIns->GetComment() != "Overwrite precision error!") {
			dst.push_back(std::make_pair(offset, CheckJarlSubBlk(pIns)));
		}
		offset += pIns->GetLen();
		i++;
	}
	pIns = CTRET();
	pCallt->AddOpeCode( pIns );
	dst.push_back(std::make_pair(offset, pIns));

	AddDeadCode(pCallt);

	IInstruction *pTopEntry = nullptr;
	UI32 footId = pCallt->GetInstructionNum();

	//finding the first foot (top entry must be above first foot)
	for (UI32 j = 0; j < pCallt->GetInstructionNum(); j++) {
		if (pCallt->at(j)->GetLabel().find("first_foot") != std::string::npos) {
			footId = j;
			break;
		}
	}

	for (UI32 j = 0; j < callt_entry; j++) {
		UI32 r = 0;
		IInstruction *pIns;
		do {
			r = g_rnd.GetRange(0U, (UI32)dst.size() - 1);
			pIns = dst[r].second;
		} while(pIns->Behavior(IInstruction::JMP) || pIns->InLoop() || pIns->InSequence()); //[FROG]TODO: Fix JMP

		if (pCallt->GetIndex(pIns) < footId) {
			pTopEntry = pIns;
			footId = pCallt->GetIndex(pIns);
		// do not found suitable entry until last entry
		} else if (j == (callt_entry - 1)) {	
			// Atleast one entry was prepared when chain bcond
			if (pTopEntry == nullptr) {
				IInstruction *pEntr;
				for (UI32 m = 0; m < dst.size(); m++) {
					pEntr = dst[m].second;
					if (pEntr->Behavior(IInstruction::JMP) || pEntr->InLoop() || pEntr->InSequence()) {
						/*...*/
					} else if (pCallt->GetIndex(pEntr) < footId) {
						pTopEntry = pEntr;
						r = m;
						break;
					}
				}
			}
		}

		pCallt->AddOpeCode(new CIns_456__short(new COprImm(dst[r].first  + (callt_entry * 2))), POS + j);
		pCallt->SetEntry(dst[r].second);
	}

	std::string cstrM = pCallt->GetLabel() + "_init_entry";
	pCallt->at(POS)->SetLabel(cstrM);
	IInstruction* jmp = JMP32(31);
	jmp->AppendComment("Jump return");
	jmp->SetTaken(true);
	jmp->SetLabel(contextStr + "callt_init");
	NewINS( pCallt, jmp ); // Expand native-data and return!
	pCallt->SetUserAddress(true);
	return pCallt;
}


//
// HVCALLとほぼ同じだが個別に定義しておく
//
CPreloadBlock* CBlockManager::GenerateSysCallBlock(TBlockConfig* pCfg)
{
	std::string contextStr = GetMContext(pCfg);
	CPreloadBlock*		pSysCall = new CPreloadBlock(contextStr + "syscall");
    pSysCall->SetFreeAlloc(true);
	const UI32		sc_entry	= 256; // imm6
	const UI32		sc_insnum	= std::max(16U, sc_entry);//
	IInstruction	*pIns;
	std::vector<std::pair<UI32, IInstruction*>> dst;
	UI32 offset = 0;
	UI32 POS = 0;
	pSysCall->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_EI);
	auto CheckJarlSubBlk = [&](IInstruction *pMid)
	{
		if (pSysCall->IsBrTarget(pMid)) return pMid;
		if (pMid->Behavior(IInstruction::JMP)) return pMid;
		IInstruction *pTail = pMid;
		UI32 idx = pSysCall->GetIndex(pMid);

		//find the first jump after this instruction
		while (idx != pSysCall->GetInstructionNum()) {
			std::string tmpLabel = pSysCall->at(idx)->GetJumpTarget();
			if (tmpLabel.length() > 0 ) {
				pTail = pSysCall->at(idx);
				break;
			}
			idx++;
		}
		if (pTail->GetMne() != "jarl") return pMid;
		idx = pSysCall->GetIndex(pMid);
		IInstruction *pHead = pMid;
		//find the first jump after this instruction
		while (idx >= POS) {
			if (pSysCall->IsBrTarget(pSysCall->at(idx)) || idx == POS) {
				pHead = pSysCall->at(idx);
				break;
			}
			idx--;
		}
		return pHead;
	};

	UI32 reg = g_rnd.GetRange(4, 25);
	pSysCall->SetOutputFlag(true);			// 出力ON
	pSysCall->EnableRegulation(true);		// 補正不可
	GenerateRandomCode(pSysCall, sc_insnum, pCfg, "syscall");
    if (m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV) > 0) {
        ChangePrivilege(pSysCall, reg, pCfg);
    }
	bool firstChange = false;
	UI32 i = POS;
	while(i < pSysCall->GetInstructionNum()) {
		pIns = pSysCall->at(i);
		const std::string &mne = pIns->GetMne();

		if(pIns->GetComment().find("Changing") != std::string::npos) {
			if(firstChange == false)
				firstChange = true;
			else{
				offset += pIns->GetLen();
				i++;
				continue;
			}
		} else
			firstChange = false;

		if(pIns->GetRegulationTarget() != NULL) {
			IInstruction *pRegIns = pIns->GetRegulationTarget();
			if(pRegIns->GetMne() == "eiret") {
				UI32 idx = pSysCall->GetIndex(pIns);
				IInstruction *pNext = pSysCall->at(idx+1);
				pIns->DirMoveTo(pNext);
				pSysCall->Remove(pIns);
				continue;
			}
		} else if (mne != ".hword" && mne != ".dword" && pIns->GetComment() != "Overwrite precision error!" ) {
			dst.push_back(std::make_pair(offset, CheckJarlSubBlk(pIns)));
		}

		offset += pIns->GetLen();
		i++;
	}
	pIns = EIRET();
	pSysCall->AddOpeCode( pIns );
	dst.push_back(std::make_pair(offset, pIns));

	//Dummy
	 AddDeadCode(pSysCall);

	IInstruction *pTopEntry = nullptr;
	UI32 footId = pSysCall->GetInstructionNum();

	//finding the first foot (top entry must be above first foot)
	for (UI32 j = 0; j < pSysCall->GetInstructionNum(); j++) {
		if (pSysCall->at(j)->GetLabel().find("first_foot") != std::string::npos) {
			footId = j;
			break;
		}
	}

	for (UI32 j = 0; j < sc_entry; j++) {
		IInstruction *pIns;
		UI32 r = 0;
		do {
			r = g_rnd.GetRange(0U, (UI32)dst.size() - 1);
			pIns = dst[r].second;
		} while(pIns->Behavior(IInstruction::JMP) || pIns->InLoop() || pIns->InSequence()); //[FROG]TODO: Fix JMP

		if (pSysCall->GetIndex(pIns) < footId) {
			pTopEntry = pIns;
			footId = pSysCall->GetIndex(pIns);
		// do not found suitable entry until last entry
		} else if (j == (sc_entry - 1)) {	
			// Atleast one entry was prepared when chain bcond
			if (pTopEntry == nullptr) {
				IInstruction *pEntr;
				for (UI32 m = 0; m < dst.size(); m++) {
					pEntr = dst[m].second;
					if (pEntr->Behavior(IInstruction::JMP) || pEntr->InLoop() || pEntr->InSequence()) {
						/*...*/
					} else if (pSysCall->GetIndex(pEntr) < footId) {
						pTopEntry = pEntr;
						r = m;
						break;
					}
				}
			}
		}
		pSysCall->AddOpeCode( _WORD(dst[r].first + (sc_entry * 4)), POS + j);
		pSysCall->SetEntry(dst[r].second);
	}

	std::string cstrM = pSysCall->GetLabel() + "_init_entry";
	pSysCall->at(POS)->SetLabel(cstrM);
	pSysCall->SetAlign(4);
	IInstruction* jmp = JMP32(31);
	jmp->AppendComment("Jump return");
	jmp->SetTaken(true);
	jmp->SetLabel(contextStr + "syscall_init");
	NewINS(pSysCall, jmp ); // Expand native-data and return!
	pSysCall->SetUserAddress(true);
	pSysCall->m_orgsize = pSysCall->GetCodeSize();

	return pSysCall;
}


/**
 * 対象ブロック(pCB)にユーザーコードのエントリポイントを作成する。
 * 
 */
std::vector<CUserBlock*>* CBlockManager::InsertUserCode(LPCTSTR context_key , LPCTSTR user_key , TBlockConfig* pCfg, CCodeBlock* pCB) {
	
	const UI32	r5	= 5;	// jump destination
	bool		pos = true;
	
	std::string labelstr = pCB->GetName() + "_uc";
	std::string retstr	 = labelstr + "_ret";
    pCB->at(0)->SetLabel(retstr);
	
	IInstruction* mov	= MOV32P(labelstr.c_str(), r5);
	IInstruction* jmp	= JMP32(r5);

	if (pos) {
		// 対象ブロックの先頭にエントリ作成
		pCB->AddOpeCode( mov, 0);
		pCB->AddOpeCode( jmp, 1);
	}else{
		// 対象ブロックの最後にエントリ作成
		pCB->AddOpeCode( mov );
		pCB->AddOpeCode( jmp );
	}

	UserSet* 	pUs = new UserSet();		// Vector of CUserBlock
	CUserBlock*	pUb = new CUserBlock();		//
    pUb->SetKeyName(context_key, user_key);	// (%CONTEXT%の置換用, ユーザコードファイル内で対応するキー)

	pUb->SetOutputFlag(true);				// 出力ON
	pUb->EnableRegulation(false);			// 補正不可
	
	std::vector <std::string>			vUcBody;
	g_usf->GetUserCodeBody(user_key, vUcBody);
	ParseUserCode(vUcBody, pUb);

	NewINS( pUb, MOV32P(retstr.c_str(), r5));
	NewINS( pUb, JMP32(r5));				// ユーザーコードからのリターン処理
	NewINS( pUb, NOP());
	 
	pUb->SetLabel(labelstr.c_str());		// __function_NN	
	
	pUs->push_back(pUb);
	
	return pUs;
}


CCodeBlock* CBlockManager::GenerateGrBlock(UI32 N, UI32 num, UI32 reg, LIST_INSSET* WeightSet) {

//#define	ADD_OPECODE_COMMENT
	auto GenerateSequentialIns = [=](IInstruction* pParentIns, IInstructionSet* pset, UI32 nInsId, UI32 nInsNum)
	{
		IInstruction *pIns;
		char memo[256];
		for(UI32 i = 0; i< nInsNum; i++){
			pIns = pset->CreateIns(nInsId)->Fix();
			if (pIns->GetMne()=="loop")  {
				// ループ命令に依存を作るとループの繰り返し範囲が狭くなる
				// 自然な生成に任せる（狭い範囲も広い範囲もカバー）
			}
			else if (reg != 0) {
				if (pIns->GetMne()=="dispose") {
					// If the list12 does not contain register reg, replace dispose's source register
					if (((pIns->GetGrDst()) & (1 << reg)) == 0) pIns->SetGrAnyOpr(reg);    
				}
				else pIns->SetGrAnyOpr(reg);
			}

			if (reg) {
				sprintf(memo, "Block[%03d] r%d (%04d)", N, reg, i);
			}else{
				sprintf(memo, "Block[%03d]     (%04d)", N, i);
			}
			pIns->AppendComment(memo);
#ifdef	ADD_OPECODE_COMMENT	// Test assemble
			UI64	bits;
			if (pIns->Assemble(&bits)) {
				sprintf (memo, "OpeCode(%llX)", bits);
			} else {
				sprintf (memo, "Asm Error !!");
			}
			pIns->AppendComment(memo);
#endif	// Test assemble
			//pCodeBlock->AddOpeCode(pIns);
			pParentIns->SetSequentialIns(pIns);
		}
	};
	LIST_INSSET::iterator itr ;
	IInstructionSet* pset= &m_nrmSet ;
	static bool init_callt = false;
	static bool init_syscall = false;
	std::pair<UI32, UI32> seqRange;
#ifdef	ADD_OPECODE_COMMENT
	UI64	bits;
#endif
	CCodeBlock* pBlock = new CCodeBlock();
	pBlock->EnableRegulation(true);
	pBlock->SetOutputFlag(true);
	
	
	for (UI32 i = 0; i < num; i++) {
		IInstruction* pIns = pset->CreateIns()->Fix();
		pIns->SetRandomIns(true);

		if (pIns->GetMne()=="loop" || pIns->GetMne()=="dispose") {
			// ループ命令に依存を作るとループの繰り返し範囲が狭くなる
			// 自然な生成に任せる（狭い範囲も広い範囲もカバー）
		} else if ((pIns->GetMne()=="callt" && init_callt == false) || (pIns->GetMne()=="syscall" && init_syscall == false)) { // First call to callt/syscall to initialize
			// Only set up for random code block
			//if (pBlock->GetName().find("_codeblock_") == std::string::npos) continue;
			std::string sCallName = pIns->GetMne();
			// finding the first entry in syscall/callt
			std::vector<INode*>& rPcb = g_asf->GetPreloadBlock();
			for (std::vector<INode*>::iterator itr_s = rPcb.begin(); itr_s != rPcb.end(); itr_s++) {
				CCodeBlock* p = static_cast<CCodeBlock*>(*itr_s);
				if (p->GetName().find(sCallName) != std::string::npos) {
					UI32 footIdx = p->GetInstructionNum();
					for (UI32 i = 0; i < p->GetInstructionNum(); i++) {
						//first entry must be in the first sub code block (so it will jump to other sub_code_block)
						//the first entry was prepared when generate syscall/callt block
						if (p->at(i)->GetLabel().find("first_foot") != std::string::npos) {
							footIdx = i;
							break;
						}
					}
					UI32 entry = footIdx;
					for (UI32 i = 0; i < footIdx; i++) {
						if (p->IsEntry(p->at(i))) {
							entry = i;
							break;
						}
					}
					// There are no entry in the code first sub codeblock
					if (entry >= footIdx) break;

					UI32 offset = 0;
					UI32 startPos = 0;

					// Search start instruction of TBL
					for (UI32 i = 0; i < p->GetInstructionNum(); i++) {
						if(p->at(i)->GetMne() == ".hword" || p->at(i)->GetMne() == ".word") {
							startPos = i;
							break;
						}
					}

					// Re-calculate offset
					for(UI32 i = startPos; i < p->GetInstructionNum(); i++) {
						//pIns = m_vcode[idx];
						//mDst.insert(std::make_pair(pIns, offset));
						//found the offset of entry point
						if (i == entry) {
							break;
						}
						offset += p->at(i)->GetLen();
					}

					IInstruction* pWord;
					for(UI32 i = startPos; i < p->GetInstructionNum(); i++) {
						if(p->at(i)->GetMne() == ".hword" || p->at(i)->GetMne() == ".word") {
							pWord = p->at(i);
							if ((UI32) *(pWord->opr(0)) == offset) {
								UI32 first_vect = p->GetIndex(pWord);
								pIns->opr(0)->SetRange(first_vect, first_vect);
								pIns->opr(0)->Replace(first_vect);
							}
						}
					}
					if (sCallName == "callt") init_callt = true;
					if (sCallName == "syscall") init_syscall = true;
					break;
				}
			}

            }else {
			if (reg != 0){
				if (pIns->GetMne()=="dispose") {
					// If the list12 does not contain register reg, replace dispose's source register
					if (((pIns->GetGrDst()) & (1 << reg)) == 0) pIns->SetGrAnyOpr(reg);    
				}
				else pIns->SetGrAnyOpr(reg);
			}
		}

		char memo[256];
		if (reg) {
			sprintf(memo, "Block[%03d] r%d (%04d)", N, reg, i);
		}else{
			sprintf(memo, "Block[%03d]     (%04d)", N, i);
		}
		pIns->AppendComment(memo);

#ifdef	ADD_OPECODE_COMMENT	// Test assemble
		if (pIns->Assemble(&bits)) {
			sprintf (memo, ", OpeCode(%llX)", bits);
		} else {
			sprintf (memo, ", Asm Error !!");
		}
		pIns->AppendComment(memo);
#endif	// Test assemble

		pBlock->AddOpeCode(pIns);
		if(pIns->GetId()<= MAX_INS_ID ){
			// Generate sequential instruction
			seqRange = (static_cast<CInstructionSet*> (pset))->m_seqInsNum.at(pIns->GetId());
			GenerateSequentialIns(pIns, pset, pIns->GetId(), g_rnd.GetRange(seqRange.first, seqRange.second) - 1);
		}
	}
	
	return pBlock;
}

/**
 * @brief   Expand sequential instruction
 * @param	pCb: Pointer to code block
 */
void CBlockManager::ExpandSequentialInstruction(CCodeBlock* pCb)
{
	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		std::vector<IInstruction*> &pSeqIns = pCb->at(i)->GetSequentialIns();
		while (pSeqIns.size()) {
			pCb->AddOpeCode(pSeqIns.back(), i);
			pSeqIns.pop_back();
		}
	}
	return;
}


/**
 * @brief   Support Indirect Access regiter of MPU in G4MH
 * @param	pCb: Pointer to code block
 */

void CBlockManager::UpdateAccessSysReg(CCodeBlock* pCb, TBlockConfig* pCfg){
	IInstruction* pIns;
	const UI32 NO_MASK = 0xffffffff;
	const UI32 MAX_TRY = 10;

    auto HasInterruptSetting = []() -> bool {
        std::map<UI32, IExceptionConfig*>& vExp = g_exp->GetException();
        std::map<UI32, IExceptionConfig*>::iterator itrExp;

        for (itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
            IExceptionConfig* pExpConfig = itrExp->second;
            if (pExpConfig->m_bIsInterrupt && pExpConfig->m_weight != 0) return true;
        }

        return false;
    };

	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		pIns = pCb->at(i);
		UI32 InsId = pIns->GetId();

		// Adjust LDSR for update specified bit
		if(InsId == INS_ID_LDSR || InsId == INS_ID_LDTC_SR || InsId == INS_ID_LDVC_SR) {
			UI32 sr = (UI32) *(pIns->opr(1));
			UI32 triedCounter = 0;

			if(g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK){
				// r0 can not be updated.
				if(pIns->opr(0)->Idx() == 0){
					pIns->opr(0)->Replace(g_rnd.GetRange(1,31));
				}
				// Set dummy constraint to 
				pIns->opr(0)->SetConstraint(new IDummyConstraint()); //Dummy constraint
			}

			if(g_srs->IsHazardedSR(sr)) {
				if(pCb->GetHandlerAddress() != 0) {

                    std::set<UI32> banlist = {};
                    if (pCb->GetLabel().find("syscall") != std::string::npos) {
                        banlist = {(32 * 0 + 0) /*EIPC*/, (32 * 0 + 1) /*EIPSW*/, (32 * 0 + 13) /*EIIC*/, (32 * 0 + 28) /*EIWR*/,(sr == 32 * 0 + 5) /*PSW*/};
                    } else if (pCb->GetLabel().find("callt") != std::string::npos) {
                        banlist = {(32 * 0 + 16) /*CTPC*/};
                    }

					triedCounter = 0;
                    while ((g_srs->IsHazardedSR(sr) || banlist.find(sr) != banlist.end()) && triedCounter < MAX_TRY) {
						pIns->opr(1)->ReFix();
						sr = (UI32) *(pIns->opr(1));
						triedCounter++;
					}
					if(triedCounter == MAX_TRY) {
						pCb->Remove(pIns);
						i--;
						continue;
					} else if(g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK) {				
						if(pIns->opr(0)->Idx() == 0){
							pIns->opr(0)->Replace(g_rnd.GetRange(1,31));
						}
						// Set dummy constraint to 
						pIns->opr(0)->SetConstraint(new IDummyConstraint()); //Dummy constraint
					}
				} else {
					UI32 idx = pCb->GetIndex(pIns);
					IInstruction* pNewIns = SYNCI();
					pNewIns->SetSequence();
					pCb->AddOpeCode(pNewIns, idx + 1);
				}
			}

			if(((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12 ))/*MPU SRs*/ 
				|| (sr == (1*32) +  0)  /* SPID */ 
				|| (sr == (0*32) +  5)  /* PSW */) {
				IInstruction *p = NULL;
				UI32 idx = pCb->GetIndex(pIns);
				UI32 reg = g_mgr->GetHandlerReg();
				UI32 ret_reg = reg + 1;
				std::string context = GetMContext(pCfg);
				pCb->AddOpeCode((p = JARL32(reg, ret_reg)), idx);
				p->SetValid(true);
				p->SetRegulationTarget(pIns);
				p->SetSequence();

				pCb->AddOpeCode((p = MOV32P("permit_exec_cur_PC", reg)), idx);
				p->SetRegulationTarget(pIns);
				p->SetSequence();
                pIns->AsyncMoveTo(p);

                p = MOV32(g_rnd.Get(), ret_reg);
                pCb->AddOpeCode(p, idx + 2);
                p->SetRegulationTarget(pIns);
                p->SetSequence();

				i += 3;
				pIns->SetSequence();
			}

			//Insert SYNCM before writing these registers: DECFG, DECTRL, DEVDS; DBGEN
			if ((sr == (13*32) + 16) /*DECFG*/
				|| (sr == (13*32) + 17) /*DECTRL*/
				|| (sr == (13*32) + 18) /*DEVDS*/
				|| (sr == (3*32) + 0) /*DBGEN*/) {
				UI32 idx = pCb->GetIndex(pIns);
				IInstruction* pNewIns = SYNCM();
				
				pCb->AddOpeCode(pNewIns, idx);
				pNewIns->SetRegulationTarget(pIns);
				pNewIns->SetSequence();

				i += 1;
				pIns->SetSequence();
			}
        } else  if (InsId == INS_ID_LDM_MP) {
            UI32 idx = pCb->GetIndex(pIns);
            IInstruction* pNewIns = SYNCI();
            pNewIns->SetSequence();
            pCb->AddOpeCode(pNewIns, idx + 1);
		} else if (InsId == INS_ID_STSR) {
			UI32 sr = (UI32) *(pIns->opr(0));
			//Insert SYNCM before reading these registers: DECFG, DECTRL, DEVDS; DBGEN
			if ((sr == (13 * 32) + 16) /*DECFG*/
				|| (sr == (13 * 32) + 17) /*DECTRL*/
				|| (sr == (13 * 32) + 18) /*DEVDS*/
				|| (sr == (3 * 32) + 0) /*DBGEN*/) {
				UI32 idx = pCb->GetIndex(pIns);
				IInstruction* pNewIns = SYNCM();

				pCb->AddOpeCode(pNewIns, idx);
				pNewIns->SetRegulationTarget(pIns);
				pNewIns->SetSequence();

				i += 1;
				pIns->SetSequence();
			}

            if (((sr == (2 * 32) + 11)/*IMSR*/ || (sr == (2 * 32) + 12)) /*ICSR*/
                && HasInterruptSetting()) {
                UI32 idx = pCb->GetIndex(pIns);
                IInstruction* pNewIns = SYNCP();

                pCb->AddOpeCode(pNewIns, idx);
                pNewIns->SetRegulationTarget(pIns);
                pNewIns->SetSequence();

                i += 1;
                pIns->SetSequence();
            }
		}
	}
}


/**
 * @brief   Expand complex instruction
 * 
 * 			convert pseudo instruction to special sequence.
 */
void CBlockManager::ExpandComplexInstruction(CCodeBlock* pCb, TBlockConfig* pCfg)
{
	std::string context = GetMContext(pCfg);

    // Random GPID for BGINT interrupt
    auto RandomGPID = [=](UI32 curGPID) -> UI32 {
        UI32 ranIndex = g_rnd.GetRange((UI32)0, g_cfg->m_mGMs.size() - 1);
        std::map<UI32, GM_Infor>::iterator itr = g_cfg->m_mGMs.begin();
        std::advance(itr, ranIndex);
        UI32 gpid = itr->first;
        while (g_cfg->m_mGMs.size() > 1 && gpid == curGPID) {
            itr = g_cfg->m_mGMs.begin();
            ranIndex = g_rnd.GetRange((UI32)0, g_cfg->m_mGMs.size() - 1);
            std::advance(itr, ranIndex);
            gpid = itr->first;

        }
        return gpid;
    };


	UI32 i = 0;
	while(i < pCb->GetInstructionNum()) {
		IInstruction* pIns = pCb->at(i);

		if (pIns->IsComplex() != true) {
			i++;
			continue; // Nop for NORMAL INS
		}

		UI32 insid = pIns->GetId();
		IInstruction *pMovIns, *pJarl;
		UI32 reg, targetReg, nNumOfMPUpdate;
		switch (insid) {

		case INS_CID_CLR1_B ... INS_CID_CAXI_ARRAY:
		case INS_CID_MOV_ALU ... INS_CID_C2B1_C2B1:
		case INS_CID_CMPFS_TRFSR ... INS_CID_MPU_CHECK:
			{
			ComplexInstruction* pCi = static_cast<ComplexInstruction*>(pIns);
			std::vector<std::pair<IDirective*, UI32>> vAsyncList;
			UI32 size = pCi->size();

			if(size == 0){
				pCb->Remove(pIns);
				pCb->Update();
				continue;
			}
			IDirective *pDir = NULL;
			UI32 n = 0;
			// Gather async labels, and generate randomized position in custom sequence.
			while((pDir = pIns->GetDirective(n)) != NULL) {
				CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				if(pAL != NULL) {
					vAsyncList.push_back(std::make_pair(pDir, g_rnd.GetRange((UI32)1, (UI32)size)));
					pIns->RemoveDirective(pDir);
					continue;
				}
				n++;
			}

            // lambda expression: Check ability to set async. event for sub-instruction in complex
            auto CanRequestAsync = [] (UI32 id, IInstruction *p) {
                if(id >= INS_CID_MOV_ALU && id <= INS_CID_ALU_BCC
                    && p->GetC2B1Ins() == NULL) { // 2nd instruction of C2B1 couple
                    return false;
                }
                if(id >= INS_CID_RIE_FXU64 && id <= INS_CID_RIE_INT64
                    && p->GetId() == INS_ID_SHORT) { // 2nd instruction of RIE
                    return false;
                }
                return true;
            };
			IInstruction *p = NULL;
            std::vector<IInstruction*> vIns;    // List of instruction that can be set async. event
			// Expand complex instruction
			while (pCi->size()) {
				p = pCi->back();
                if (pCi->GetId() >= INS_CID_RIE_FPU32 && pCi->GetId() <= INS_CID_RIE_INT64) {
                    p->SetId(pCi->GetId());
                }

				pCb->AddOpeCode(p, i);
				pCi->pop_back();
                if(CanRequestAsync(pCi->GetId(), p)) {
                    vIns.push_back(p);
                }
			}

            // Distribute async. event to sub-instruction randomly
			std::vector<std::pair<IDirective*, UI32>>::iterator itr;            
			for(itr = vAsyncList.begin(); itr != vAsyncList.end(); itr++) {
                UI32 pos = g_rnd.GetRange((UI32) 0, (UI32) (vIns.size() - 1));
				vIns[pos]->SetDirective(itr->first);
			}
			pIns->DirMoveTo(p);
			pCi->clear();
			pCb->Remove(pCi);
			break;
		}
		case INS_CID_MPU_UPDATE:
			// Dynamic MPU Update
			{
            std::stringstream ss;
            nNumOfMPUpdate = m_vMPUpdate.size();
            ss << (context + "mpu_function_") << nNumOfMPUpdate;

            pJarl = JARL32(m_nHandlerReg + 1, m_nHandlerReg);
            pJarl->AppendComment("Update MPU Config");
            pJarl->SetValid(true);
            pJarl->SetSequence();
            pJarl->SetJumpTargetLabel(ss.str().data());
            pCb->AddOpeCode(pJarl, i);

            pMovIns = MOV32P(ss.str().data(), m_nHandlerReg + 1);
            pMovIns->SetRegulationTarget(pJarl);
            pMovIns->SetSequence();
            pCb->AddOpeCode(pMovIns, i);

            // Overwrite returned register
            pMovIns = MOV32(g_rnd.Get(), m_nHandlerReg);
            pCb->AddOpeCode(pMovIns, i + 2);

            pCb->Remove(pIns);
            m_vMPUpdate.push_back(nNumOfMPUpdate);
            i++;
            break;
			}

		case INS_CID_CHANGE_PRIV:
			{
            UI32 um = g_rnd.GetRange(0, 1);
            if (pCb->GetHandlerAddress() == 0) {
                std::string ss;
                if (um) {
                    ss = "function_ChangePrivilegetoUM";
                } else {
                    ss = "function_ChangePrivilegetoSV_HV";
                }

                pJarl = JARL32(m_nHandlerReg + 1, m_nHandlerReg);
                pJarl->SetSequence();
                pJarl->AppendComment("Jump to Change privilege");
                pJarl->SetValid(true);
                pCb->AddOpeCode(pJarl, i);

                pMovIns = MOV32P(ss, m_nHandlerReg + 1);
                pMovIns->SetSequence();
                pMovIns->SetRegulationTarget(pJarl);
                pCb->AddOpeCode(pMovIns, i);

                // Overwrite returned register
                pMovIns = MOV32(g_rnd.Get(), m_nHandlerReg);
                pCb->AddOpeCode(pMovIns, i + 2);
            }
            pCb->Remove(pIns);
            i++;
			break;
			}
		case INS_CID_CHANGE_MODE:
			{
			    UI32 gm = g_rnd.GetRange(0, 1);
			    if (pCb->GetHandlerAddress() == 0) {
			        std::string ss;
			        if (gm) {
			            ss =  "function_ChangeModetoGM";
			        } else {
			            ss = "function_ChangeModetoHM";
			        }

			        pJarl = JARL32(m_nWorkReg + 1, m_nWorkReg);
			        pJarl->SetSequence();
			        pJarl->AppendComment("Jump to Change mode");
			        pJarl->SetValid(true);
					pJarl->SetJumpTargetLabel(ss.data());
                    pCb->AddOpeCode(pJarl, i);

			        pMovIns = MOV32P(ss, m_nWorkReg + 1);
			        pMovIns->SetSequence();
			        pMovIns->SetRegulationTarget(pJarl);
                    pCb->AddOpeCode(pMovIns, i);

                    // Overwrite returned register
                    pMovIns = MOV32(g_rnd.Get(), m_nWorkReg);
                    pCb->AddOpeCode(pMovIns, i + 2);
			    }
			    pCb->Remove(pIns);
			    i++;
				break;
			}

		case INS_CID_CHANGE_VMACHINE:
			{
                UI32 gpid = RandomGPID(pCfg->m_GMID);

			    IInstruction *pHVTRAP = HVTRAP(gpid);
				pHVTRAP->AppendComment("Change virtual machine");
				pCb->AddOpeCode(pHVTRAP, pCb->GetIndex(pIns));
			    pCb->Remove(pIns);
			    i++;
				break;
			}

	    default:
			{
			std::string label;
			g_usf->GetUserCodeKey(insid - (MAX_INS_ID + 1), &label);
			if(label.size() != 0) { // User Code
				reg = 31;
				targetReg = g_rnd.GetRange(1, 30);

				// Label of user code block
				std::string labelUserBlock("");
				std::stringstream ss;
				ss << GetTContext(pCfg);
				ss << label;
				ss >> labelUserBlock;

				// Jump to user code
				IInstruction* pJarl = JARL32(targetReg, reg);
				pJarl-> SetValid(true);
				pJarl-> SetSequence();
				pJarl->AppendComment("Jump to user code");
				pCb->AddOpeCode(pJarl, i);

				pMovIns = MOV32P(labelUserBlock, targetReg);
				pMovIns->SetRegulationTarget(pJarl);
				pMovIns->SetSequence();
				pCb->AddOpeCode(pMovIns, i);

				// Overwrite returned register due to mismatch PC
				pMovIns = MOV32(g_rnd.Get(), targetReg);
				pCb->AddOpeCode(pMovIns, i + 2);

				// Overwrite target register due to mismatch PC
				pMovIns = MOV32(g_rnd.Get(), reg);
				pCb->AddOpeCode(pMovIns, i + 2);

				pCb->Remove(pIns);
				i++;
			} else { // Asynchronous Event
				UI32 UC_NUM = g_usf->GetUserCodeNum();

				IExceptionConfig* pExpCfg = NULL;
				UI32 id = insid - (MAX_INS_ID + 1) - UC_NUM;

				// Acquire exception information
				pExpCfg = g_exp->GetExpConfig(id);

				if (pExpCfg->m_id == IException::EXP_RESET) {
					IInstruction *pHVTRAP = HVTRAP(0x1f);
					pHVTRAP->AppendComment("SW reset exception");
					pCb->AddOpeCode(pHVTRAP, pCb->GetIndex(pIns));
					pCb->Remove(pIns);
					i++;
					break;
				}
				

				if(pExpCfg != NULL) {
					std::stringstream ss;
					std::string strAsyncLabel;
					std::string strExpName = pExpCfg->m_name;
					CAsyncLabel *pAsyncLabel;

					// Convert to lower cases
					std::transform(strExpName.begin(), strExpName.end(), strExpName.begin(), [] (int ch) {return std::tolower(ch);});

					pAsyncLabel = new CAsyncLabel(strExpName, GetTContext(pCfg), m_nAsyncCount, true);
					pAsyncLabel->m_nEventId = pExpCfg->m_id;

					if(pExpCfg->m_uchannel != 0){
						// Randomizing interrupt channel
						UI32 channel = g_rnd.GetRange(pExpCfg->m_lchannel, pExpCfg->m_uchannel);
						pAsyncLabel->m_channel = channel;

						// Convert from channel -> interrupt cause code
						UI32 causecode = pExpCfg->m_lcode + channel;
						if(causecode > pExpCfg->m_ucode)
							causecode = pExpCfg->m_ucode;
						pAsyncLabel->m_causecode = causecode;
					} else {
						pAsyncLabel->m_causecode = pExpCfg->m_lcode;
					}
					
					switch (pExpCfg->m_id) {
					case IException::EXP_SYSERR:
						// SYSERR support both sync. and async events depends on HW.
						// It is agreed that causecode 0x010 is for async. type.
						pAsyncLabel->m_causecode = 0x0010;
						break;

					case IException::EXP_EIINT:
					case IException::EXP_EITBL:
					case IException::EXP_RBINT:
						pAsyncLabel->m_priority = g_rnd.GetRange(0, 63);
						break;

					case IException::EXP_GMEIINT:
					case IException::EXP_GMEITBL:
					case IException::EXP_GMRBINT:
						pAsyncLabel->m_priority = g_rnd.GetRange(0, 63);
						pAsyncLabel->m_gpid = pCfg->m_GMID; // Guest ID
						break;
					
					case IException::EXP_GMFEINT:
						pAsyncLabel->m_gpid = pCfg->m_GMID; // Guest ID
						break;

					case IException::EXP_BGEIINT:
						{
							pAsyncLabel->m_priority = g_rnd.GetRange(0, 63);
							UI32 gpid = RandomGPID (pCfg->m_GMID);
							pAsyncLabel->m_gpid = gpid; // Guest ID
						}
						break;

					case IException::EXP_BGFEINT:
						{
							UI32 gpid = RandomGPID (pCfg->m_GMID);
							pAsyncLabel->m_gpid = gpid; // Guest ID
						}
						break;

					default:
						break;
					}

					if(i < pCb->GetInstructionNum() - 1) {
						IInstruction *pNextIns = pCb->at(i + 1);
						pIns->DirMoveTo(pNextIns);
						UI32 n = 0;
						IDirective *pDir = NULL;
						while((pDir = pNextIns->GetDirective(n)) != NULL) {
							CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
							if(pAL != NULL) {
								if(g_sim->CheckSameInterruptType(pAL->m_name, pAsyncLabel->m_name))	// INCT1 can keep only 1 request of a async. event
									break;
							}
							n++;
						}

						UI32 nHandlerAddr = pCb->GetHandlerAddress();
						UI32 asyncIdx = (pExpCfg->m_addr >> 4);
						if(pDir == NULL) {													// The cause code is not exists
							if (pExpCfg->m_name == "RBINT" || pExpCfg->m_name == "GMRBINT") {
								if(nHandlerAddr >= ADR_VECTOR_EIINT000 || (m_arrHandlerOrder[(nHandlerAddr >> 4)] < m_arrHandlerOrder[asyncIdx])) {
									UI32 Max_Order = *(std::max_element (m_arrHandlerOrder,m_arrHandlerOrder+(ADR_VECTOR_NUM >> 4)));
									if (m_arrHandlerOrder[(nHandlerAddr >> 4)] < Max_Order) {
										//!< Find All handler Address of next level.
										UI32 NextOrder = m_arrHandlerOrder[(nHandlerAddr >> 4)] + 1;
										std::vector<UI32> vHandleAddNextOrder;
										for (UI32 i = (ADR_VECTOR_EIINT000 >> 4); i <= (ADR_VECTOR_EIINT015 >> 4); i++) {
											if (NextOrder == m_arrHandlerOrder[i]) {
												vHandleAddNextOrder.push_back(i);
											}
										}
										if (vHandleAddNextOrder.size()) {
											UI32 index = g_rnd.GetRange((UI32)0,(UI32)vHandleAddNextOrder.size()-1);
											UI32 nHandleAddNextOrder = vHandleAddNextOrder[index];
											UI32 channel = (g_rnd.GetRange(pExpCfg->m_lchannel, pExpCfg->m_uchannel) & 0xfff0) | (nHandleAddNextOrder & 0xf);
											pAsyncLabel->m_channel = channel;
											pAsyncLabel->m_nEventId = (pExpCfg->m_name == "RBINT")? IException::EXP_EITBL : IException::EXP_GMEITBL;
                                            pAsyncLabel->m_name = (pExpCfg->m_name == "RBINT")? "eitbl" : "gmeitbl";
											pNextIns->SetDirective(pAsyncLabel);
										}
									}
								} else if (nHandlerAddr == 0) {
									pAsyncLabel->m_nEventId = (pExpCfg->m_name == "RBINT")? IException::EXP_EITBL : IException::EXP_GMEITBL;
									pAsyncLabel->m_name = (pExpCfg->m_name == "RBINT")? "eitbl" : "gmeitbl";
									pNextIns->SetDirective(pAsyncLabel);
								}
							} else if ( nHandlerAddr == 0													// Codeblock is random block
								|| (m_arrHandlerOrder[(nHandlerAddr >> 4)] < m_arrHandlerOrder[asyncIdx])) { // The event is lower level.
								pNextIns->SetDirective(pAsyncLabel);
								}
							}
						}
					pCb->Remove(pIns);
					m_nAsyncCount++;
					} else { // Invalid event.
						pCb->Remove(pIns);
					}
			   }
		   }
		}	
	}
}

/**
 * @brief	Bcond control
 * 
 * 	1. Search all branch(and some of jump) operation.
 * 	2. Set a flag to all branch , TAKEN or NOT. 
 * 	3. Divide block to small block that has TAKEN brancn at the end.
 * 	4. Shuffle small blocks and connect a block end with next head.
 */
void CBlockManager::ChainBcondSequence(CCodeBlock* pCb)
{
	FROG_ASSERT(pCb && pCb->GetInstructionNum());
	bool bRecCode = g_cfg->m_bRecCode;
    UI32 const BCOND_LIMIT = 200;
	// BChainはジャンプ命令と着地命令の組み合わせで保持するペアクラス
	// BChainVecはジャンプ＆着地のペアを配列で保持する
	typedef std::pair<IInstruction*, IInstruction*>	BChain; /* Pair of (Group-of-top, Bcond) */
	typedef std::vector<BChain>	BChainVec;
	BChainVec bcv;
	UI32 JmpReg = 0;
	// Vector of pair of a take instruction and list of not taken instruction in a chain.
	std::vector<std::pair<IInstruction*, std::vector<IInstruction*>>> vRecovery;
	std::vector<IInstruction*> vNotTakenBCond;

	// ブロック内の各命令について先頭からのオフセット位置を得る
	std::unique_ptr<std::map<IInstruction*,UI32>> pOffsMap(pCb->GetOffsetMap());
	
    auto UpdateHeadBCond = [&](IInstruction *pOldHead, IInstruction *pNewHead)
    {
        BChainVec::iterator itr;
        itr = std::find_if(bcv.begin(), bcv.end(), [&](BChain bchain) {return (bchain.first == pOldHead);});
        if(itr != bcv.end())
            itr->first = pNewHead;
    };

	// Remove instruction that has adjustment code
	auto CalcAdjustment = [&](IInstruction * pRndIns)
	{
		if ( pRndIns->Category(IInstruction::ICAT_FPU_S) || pRndIns->Category(IInstruction::ICAT_FPU_D) ||  pRndIns->Category(IInstruction::ICAT_SIMD) ) {
			//delete  pRndIns;
			return 24;
		}

		if ( pRndIns->IsComplex() || pRndIns->HasConstraint() ||  pRndIns->Behavior(IInstruction::LOAD_MEMORY) || 
			 pRndIns->Behavior(IInstruction::STORE_MEMORY) ||  pRndIns->Behavior(IInstruction::JMP) ) {
				//delete  pRndIns;
				return 8;
		}

		if( pRndIns->GetMne() == "ei" ||  pRndIns->GetMne() == "di" ||  pRndIns->GetMne() == "halt"){
			//delete  pRndIns;
			return 8;
		}
			
		// 現状の制約(TODO:Modify)
		if ( pRndIns->GetMne()=="sttc.pc" ||  pRndIns->GetMne()=="stsr" ||  pRndIns->GetMne()=="stvc.sr" ||  pRndIns->GetMne()=="sttc.sr") {
			//delete  pRndIns;
			return 8;
		}
			
		//if( pRndIns->Behavior(IInstruction::LOAD_SR))
		if( pRndIns->GetMne() == "ldsr" ||  pRndIns->GetMne() == "ldtc.sr" ||  pRndIns->GetMne() == "ldvc.sr"){
			//delete  pRndIns;
			return 8;
		}

		return 0;
	};

    // Check constraint to choose footer and jump foot in gap sequence.
    // Return true if pIns does not satisfy
    //auto IsConstraintInGap = [](IInstruction* pIns) -> bool {
    //    UI32 insID = pIns->GetId();
    //    bool isCnstrain = (insID == INS_ID_LDSR  || insID == INS_ID_LDTC_SR || insID == INS_ID_LDVC_SR ||
    //                       insID == INS_ID_CALLT || insID == INS_ID_SYSCALL ||
    //                       insID == INS_ID_CTRET || insID == INS_ID_EIRET   ||
    //                       pIns->IsComplex()); 
    //    return isCnstrain;
    //};

	//Add the .hword instruction to synchronize PC between CForest internal and standalone 
	auto AddGap = [&] (IInstruction* headIns, IInstruction* tailIns) {
		SI32 totalGap = 0;

		//The instruction which is used to store PC while simulating
		IInstruction* gapCode1;
		IInstruction* gapCode2;
        IInstruction* footer = nullptr;
        IInstruction* jmp_foot = nullptr;

        do {
            delete footer;
            footer = m_nrmSet.CreateIns()->Fix();
        } while (footer->IsComplex());

        do {
            delete jmp_foot;
            jmp_foot = m_nrmSet.CreateIns()->Fix();
        } while (jmp_foot->IsComplex());


        if (headIns->GetLabel().size() != 0) {
            footer->SetLabel(headIns->GetLabel() + "_foot");
            jmp_foot->SetLabel(headIns->GetLabel() + "_jmp_gap");
        } else {
			footer->SetLabel(pCb->GetLabel() + "first_foot");
            jmp_foot->SetLabel(pCb->GetLabel() + "first_jmp_gap");
		}
		
		footer->SetSequence(IInstruction::IF_SEQ_GAP, true);
		jmp_foot->SetSequence(IInstruction::IF_SEQ_GAP, true);

        pOffsMap.reset(pCb->GetOffsetMapForAdjustCode());
        totalGap = (std::abs((int)((*pOffsMap)[tailIns] - (*pOffsMap)[headIns])));

		//Insert stall instruction which is used to store PC				
		pCb->Insert(footer, tailIns);
		pCb->Insert(jmp_foot, footer);
		//Insert the gap codes to synchronize PC
		gapCode2 = tailIns;
		while (totalGap > 0) {
			gapCode1 = m_nrmSet.CreateIns()->Fix();
			while(gapCode1->IsComplex()) {
				delete gapCode1;
				gapCode1 = m_nrmSet.CreateIns()->Fix();
			}
			gapCode1->AppendComment("Gap code for synchronize PC ");
			gapCode1->SetSequence(IInstruction::IF_SEQ_GAP, true);
			pCb->Insert(gapCode1, gapCode2);
			gapCode2 = gapCode1;
            totalGap -= gapCode1->GetLen();
		}

		pCb->Update();
	};

	//Judge the 2 instructions can be sequential jump or not
	auto IsSequentialAdjust = [&] (IInstruction* src, IInstruction* dst, IInstruction* postDst) {
		if (dst->InSequence(IInstruction::IF_SEQ_FWD)) return false;

		if (src->GetLabel().length() > 0) {
			return false; // Label付き命令（Jmpの着地点になる）
		}

		if (src->GetMne() == "eiret" || src->GetMne() == "feret" || src->GetMne() == "ctret") {
			return false;
		}

		//Limitation: not support sequential jmp if there are no gap code between 2 jmp instructions  
		if (pCb->GetIndex(src) < pCb->GetIndex(postDst)) {
			UI32 dstId = pCb->GetIndex(postDst);
			bool isLimit = true;
			for (UI32 n = pCb->GetIndex(src); n < dstId; n++) {
				std::string sfoot = pCb->at(n)->GetLabel();
				if (sfoot.find("foot") != std::string::npos) {
					isLimit = false;
					break;
				}
			}
			if (isLimit) return false;
		}

		auto dst_r = (dst)->GetGrSrc();
		auto dst_w = (dst)->GetGrDst();
		auto src_r = (src)->GetGrSrc();
		auto src_w = (src)->GetGrDst();
		if (((dst_r | dst_w) & (src_r | src_w)) != 0 ) return false;

		std::vector<IInstruction*>::iterator itr;
		// Checking the constrain of forwarding jump 
		if (src->InSequence(IInstruction::IF_SEQ_FWD)) {
			std::vector<IInstruction*> &pNeedIns = src->GetInsNeed();
			for (itr = pNeedIns.begin(); itr != pNeedIns.end(); itr++) {
				src_r = (*itr)->GetGrSrc();
				src_w = (*itr)->GetGrDst();
				if (((dst_r | dst_w) & (src_r | src_w)) != 0 ) return false;
			}
		}
        src->AppendComment(" In Sequential Jump");
		src->SetSequentialIns(dst);
        dst->AppendComment(" In Sequential Jump");
		return true;
	};

	//Chain for increase the sequential jump rate
	auto PreSequentialChain = [&] (IInstruction* src, IInstruction* dst, std::string targetLabel) {
		if(dst->GetId() == INS_ID_JMP || dst->GetId() == INS_ID_JARL){
			dst->SetJumpTargetLabel(targetLabel);
			IInstruction* mov = MOV32P(targetLabel, dst->opr(0)->Idx());
			pCb->Insert(mov, src);
			UpdateHeadBCond(src, mov);
			src->DirMoveTo(mov);
			mov->SetRegulationTarget(dst);
			pCb->Update();
			return;
		}
	};

	//  -----------------------------------------------------------------------------------
	//  CTRETでジャンプ先につなぐ 
	//	   ・src -> dstへ処理がつながるように追加命令を挿入する。
	//     ・ctpswを書き換えているのは累積のSAビットをランダムにクリアすることを期待している
	//     ・PSW.VM/UMを破壊することが無いのでそのままMOVして良い
	//     ・PCが後段処理に依存しないようにreg+1で潰す
	//  -----------------------------------------------------------------------------------
	auto Chain_ctret = [&] (IInstruction* src, IInstruction* dst) {
		IInstruction *sp, *mv, *sr, *mr;
		UI32 reg = g_rnd.GetRange(1U, 31U);	// Random select GR
		
		sp = LDSR  (reg, 17, 0);			// ldsr   reg, CTPSW
		mv = MOV32P(dst->GetLabel(),reg);	// mov  __dst, reg
        mv->m_bBreakNotSS = true;
		sr = LDSR  (reg, 16, 0);			// ldsr   reg, CTPC
        sr->m_bBreakNotSS = true;
		mr = MOVR (((reg+1)&0x1f), reg);	// mov  reg+1, reg
        mr->m_bBreakNotSS = true;

        src->m_bBreakNotSS = true;
		
		sp->SetRegulationTarget(src);		// 補正元命令の情報を設定
		mv->SetRegulationTarget(src);		// 補正元命令の情報を設定 
		sr->SetRegulationTarget(src);		// 補正元命令の情報を設定
		mr->SetRegulationTarget(src);		// 補正元命令の情報を設定
		
		sp->SetSequence();					// Set normal sequence for regulation code
		mv->SetSequence();					// Set normal sequence for regulation code
		sr->SetSequence();					// Set normal sequence for regulation code
		mr->SetSequence();					// Set normal sequence for regulation code

		pCb->Insert(mr, src);				// ctretの前に MOVRを挿入
		pCb->Insert(sr, mr);				// MOVRの前に LDSRを挿入 
		pCb->Insert(mv, sr);				// LDSRの前に MOV32Pを挿入
		pCb->Insert(sp, mv);				// MOV32Pの前に LDSRを挿入
		
		src->DirMoveTo(sp);					// Labelがある(Jmpの着地点)は挿入した一番上の命令に設定
		src->SetJumpTargetLabel(dst->GetLabel());
        UpdateHeadBCond(src, sp);
	};

	//  -----------------------------------------------------------------------------------
	//  EIRETでジャンプ先につなぐ 
	//	   ・src -> dstへ処理がつながるように追加命令を挿入する(EIPC書き換え)。
	//     ・eiretによるPSWの破壊が起きないように、事前にPSWからEIPSWへの転送を行う
	//  -----------------------------------------------------------------------------------
	auto Chain_eiret = [&] (IInstruction* src, IInstruction* dst) {
        if (pCb->GetLabel().find("syscall") == std::string::npos) {
            UI32 reg = g_rnd.GetRange(1U, 31U);

            IInstruction* sr = STSR(5, reg, 0); // psw->R // Rの値を潰してPC依存を切断
            IInstruction* lr2 = LDSR(reg, 1, 0); // R->eipsw
            lr2->m_bBreakNotSS = true;
            IInstruction* mv = MOV32P(dst->GetLabel(), reg);
            mv->m_bBreakNotSS = true;
            IInstruction* lr1 = LDSR(reg, 0, 0); // R->eipc
            lr1->m_bBreakNotSS = true;
            IInstruction* overwrite = MOV32(g_rnd.Get(), reg);
            overwrite->m_bBreakNotSS = true;
            IInstruction *Jr = JR22P(dst->GetLabel());
            Jr->AppendComment("Recovery code for EIRET");

            src->m_bBreakNotSS = true;

            lr1->SetSequence();					// Set normal sequence for regulation code
            lr2->SetSequence();					// Set normal sequence for regulation code
            sr->SetSequence();					// Set normal sequence for regulation code
            mv->SetSequence();					// Set normal sequence for regulation code
            overwrite->SetSequence();			// Set normal sequence for regulation code
            Jr->SetSequence();

            mv->SetRegulationTarget(src);
            lr1->SetRegulationTarget(src);
            sr->SetRegulationTarget(src);
            lr2->SetRegulationTarget(src);
            overwrite->SetRegulationTarget(src);

            pCb->Insert(overwrite, src);
            pCb->Insert(lr1, overwrite);
            pCb->Insert(mv, lr1);
			pCb->Insert(lr2, mv);
			pCb->Insert(sr, lr2);

            src->DirMoveTo(sr);
            src->AsyncMoveTo(sr);
            src->SetJumpTargetLabel(dst->GetLabel());
            UpdateHeadBCond(src, sr);

            // In case of PIE exception occur at EIRET, It still jump to destination
            pCb->AddOpeCode(Jr, pCb->GetIndex(src) + 1);

        } else if (m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV) > 0) {
            IInstruction *restore = STSR(28, m_nHandlerReg, 0);
            pCb->Insert(restore, src);
            src->DirMoveTo(restore);
            src->AsyncMoveTo(restore);
            UpdateHeadBCond(src, restore);
        } else {
            // Do nothing
        }
	};

	//  -----------------------------------------------------------------------------------
	//  FERETでジャンプ先につなぐ 
	//	   ・src -> dstへ処理がつながるように追加命令を挿入する(FEPC書き換え)。
	//     ・feretによるPSWの破壊が起きないように、事前にPSWからEIPSWへの転送を行う
	//  -----------------------------------------------------------------------------------
	auto Chain_feret = [&] (IInstruction* src, IInstruction* dst) {
		UI32 reg = g_rnd.GetRange(1U, 31U);
		IInstruction* sr  = STSR (5, reg, 0); // psw->R // Rの値を潰してPC依存を切断
		IInstruction* lr2 = LDSR (reg, 3, 0); // R->fepsw
        lr2->m_bBreakNotSS = true;
        IInstruction* mv = MOV32P(dst->GetLabel(), reg);
        mv->m_bBreakNotSS = true;
        IInstruction* lr1 = LDSR(reg, 2, 0); // R->fepc
        lr1->m_bBreakNotSS = true;	
		IInstruction* overwrite = MOV32 (g_rnd.Get(), reg);
		overwrite->AppendComment("overwrite in FERET");
		overwrite->m_bBreakNotSS = true;
        IInstruction *Jr = JR22P(dst->GetLabel());
        Jr->AppendComment("Recovery code for FERET");

        src->m_bBreakNotSS = true;
		
		lr1->SetSequence();					// Set normal sequence for regulation code
		lr2->SetSequence();					// Set normal sequence for regulation code
		sr->SetSequence();					// Set normal sequence for regulation code
		mv->SetSequence();					// Set normal sequence for regulation code
		overwrite->SetSequence();			// Set normal sequence for regulation code
        Jr->SetSequence();

        mv->SetRegulationTarget(src);
        lr1->SetRegulationTarget(src);
        sr->SetRegulationTarget(src);
        lr2->SetRegulationTarget(src);
        overwrite->SetRegulationTarget(src);

		// In case of PIE exception occur at FERET, It can jump to destination
        pCb->AddOpeCode(Jr, pCb->GetIndex(src) + 1);

		pCb->Insert(overwrite, src);
        pCb->Insert(lr1, overwrite);
        pCb->Insert(mv, lr1);
		pCb->Insert(lr2, mv);
		pCb->Insert(sr, lr2);
		
		src->DirMoveTo(sr);
        src->AsyncMoveTo(sr);
		src->SetJumpTargetLabel(dst->GetLabel());
        UpdateHeadBCond(src, sr);
	};

	//  -----------------------------------------------------------------------------------
	//  DISPOSEでジャンプ先につなぐ 
	//	   ・src -> dstへ処理がつながるように追加命令を挿入する(FEPC書き換え)。
	//     ・feretによるPSWの破壊が起きないように、事前にPSWからEIPSWへの転送を行う
	//  -----------------------------------------------------------------------------------
	auto Chain_dispose = [&] (IInstruction* src, IInstruction* dst) {
		UI32 reg = src->opr(2)->Idx();
		UI32 nWord = 0;
		
		//Data code1,2,3: Instruction that is stored to memory to be load by Dispose as data value
		IInstruction* datCode1 ;
		IInstruction* datCode2 ;
		IInstruction* datCode3 ; 

		//Instruction to be insert to gap range
		IInstruction* mvd = MOVR (((reg+1)&0x1f), reg);		// 飛び先準備(reg値依存を切る)
		if (reg == 3){	//Store data to Instruction memory for dispose instruction to load
			
			//Using hword for overwriting PC to avoid stc insert
			UI32 mvd_code = mvd->Fetch();
			mvd = new CIns_456__short(new COprImm(mvd_code));

			//Do not generate dispose with r3 in syscall or callt
			if ( (pCb)->GetName().find("syscall") != std::string::npos || (pCb)->GetName().find("callt") != std::string::npos ) {
				reg = reg + 1;	// Replace r3 by r4
				delete mvd;
				mvd = MOVR (((reg+1)&0x1f), reg); // Replace overwrite PC
				src->opr(2)->Replace(reg); 
				
				// Insert overwrite PC code
				mvd->AppendComment("Overwrite PC");
				dst->DirMoveTo(mvd);
				UpdateHeadBCond(dst, mvd);
				src->SetJumpTargetLabel(mvd->GetLabel());
				pCb->Insert(mvd, dst);	
				return;
			}
			//Calculate the number of word that need to be insert to instruction memory
			for (UI32 i = 0; i < 12; i++) { //The loop to calculate the number of register in list12
				nWord += ((src->GetGrDst() & (1 << (i + 20))) != 0);	
			}
			nWord += UI32(*(src->opr(0))) ;	// add the value of imm (this value is shift left 2 bit and add to r3)

			datCode3 = dst;

			for (; nWord > 0; nWord-- ) {
				datCode1 = m_nrmSet.CreateIns()->Fix();
				//Loop until create an Instruction that do not have Adjustment code or do not make UCPOP
				while ( CalcAdjustment(datCode1) != 0){
					delete  datCode1;
					datCode1 = m_nrmSet.CreateIns()->Fix();
				}
				// Check and replace mismatch register
                if (m_nMismatchRegSet) {
                    for(UI32 op = 0; op < datCode1->GetOpNum(); op++) {
                        IOperand *pOpr = datCode1->opr(op);
                        if(pOpr->Attr(IOperand::OPR_ATTR_GR) == false || pOpr->Attr(IOperand::OPR_ATTR_SRC) == false)
                            continue;

                        pOpr->ReplaceIdxFromList(~m_nMismatchRegSet);
                    }
                }
				if ( datCode1->GetLen() <= 2 ){	// Insert 2 opcode with 16 bit length

					//Insert first opcode
					datCode2 = new CIns_456__short(new COprImm(datCode1->Fetch()));
					datCode2->AppendComment("This opcode will be load by dispose: ");
					datCode2->AppendComment(datCode1->GetCode().c_str());
					datCode2->SetSequence();
					pCb->Insert(datCode2, datCode3);

					//Insert second opcode
					datCode3 =  new CIns_456__short(new COprImm(datCode1->Fetch()));
					datCode3->AppendComment("This opcode will be load by dispose: ");
					datCode3->AppendComment(datCode1->GetCode().c_str());
					datCode3->SetSequence();
					pCb->Insert(datCode3, datCode2);
				}
				else if ( datCode1->GetLen() <= 4 ){ // Insert 1 opcode with 32 bit length
					
					// Insert 32 bit opcode
					datCode2 = _WORD(datCode1->Fetch());
					datCode2->AppendComment("This opcode will be load by dispose: ");
					datCode2->AppendComment(datCode1->GetCode().c_str());
					datCode2->SetSequence();
					pCb->Insert(datCode2, datCode3);
					datCode3 = datCode2;
				}
				else {	//Remove opcode which has more than 32 bit
					delete datCode1;
					nWord ++;
				}
			}
			dst->DirMoveTo(datCode3);
			UpdateHeadBCond(dst, datCode3);
			src->SetJumpTargetLabel(datCode3->GetLabel());

			pCb->Update();
			return;
		}
		else if (((src->GetGrSrc() & src->GetGrDst()) & 0xfffffff7)  != 0) {	
			if (((pCb)->GetName().find("syscall") != std::string::npos) || ((pCb)->GetName().find("callt") != std::string::npos)) {
				reg = 18U;	// Replace r in list12 by r18
				src->opr(2)->Replace(reg); 
				src->SetJumpTargetLabel(dst->GetLabel());
				return;
			} else {
				src->SetJumpTargetLabel(dst->GetLabel());
				return;
			}
		} else {
			src->SetJumpTargetLabel(dst->GetLabel());
			return;
		}		
	};
	
    auto DelC2B1Att = [&pCb](IInstruction* src) {
        UI32 SrcIdx = pCb->GetIndex(src);
        src->SetSequence(IInstruction::IF_SEQ_C2B1, false);
        src->DelComment();
        if (SrcIdx > 0) {
            IInstruction* pPrevSrc;
            UI32 idx = SrcIdx;
            while (idx > 0) {
                pPrevSrc = pCb->at(idx - 1);
                if (pPrevSrc->InSequence(IInstruction::IF_SEQ_C2B1) && pPrevSrc->GetC2B1Ins() == src) {
                   // pPrevSrc->SetSequence(IInstruction::IF_SEQ_C2B1, false);
                    pPrevSrc->DelComment();
                    pPrevSrc->SetC2B1Ins(nullptr);
                    break;
                }
                idx--;
            }
        }
    };
	//  -----------------------------------------------------------------------------------
	//  汎用シーケンス ジャンプ接続 
	//	   ・src -> dstへ処理がつながるように追加命令を挿入する。
	//     ！ pOffsMapを毎回更新しないと正確な距離はわからない（命令がどんどん挿入されるため）
	//        実際は毎回更新しないでマージンを持たせている。
	//  -----------------------------------------------------------------------------------
	auto Chain_default = [&] (IInstruction* src, IInstruction* dst) {

		pOffsMap.reset(pCb->GetOffsetMap());
		UI32 distance = std::abs((int)((*pOffsMap)[dst] - (*pOffsMap)[src]));
		if (distance > 0xffff) {
			// 9ビットで相対アドレス±255より幅が大きいジャンプは出来ない（JRにする）
			IInstruction* Jr  = JR32P(dst->GetLabel());
			Jr->SetJumpTargetLabel(dst->GetLabel());
			src->DirMoveTo(Jr);
			DelC2B1Att(src);
			
			std::vector<std::pair<IInstruction *, std::vector<IInstruction *>>>::iterator itr;
			for(itr = vRecovery.begin(); itr != vRecovery.end(); itr++)	{
				IInstruction *takenBCond = itr->first;
				if (takenBCond == src)  
					itr->first = Jr;
				std::vector<IInstruction*> &vNotTaken = itr->second;
				std::vector<IInstruction*>::iterator ntItr;
				for(ntItr = vNotTaken.begin(); ntItr != vNotTaken.end(); ntItr++) {
					IInstruction* notTakenBCond = *ntItr;
					if (notTakenBCond == src)  *ntItr = Jr;
				}
			}
			IInstruction* old = pCb->Replace(src, Jr);
			FROG_ASSERT(old == src);
			delete old;
		}else
		if ((src->GetLen() < 4) && (distance > BCOND_LIMIT)) {
			// 9ビットで相対アドレス±255より幅が大きいジャンプは出来ない（JRにする）
			IInstruction* Jr  = JR22P(dst->GetLabel());
			Jr->SetJumpTargetLabel(dst->GetLabel());
			src->DirMoveTo(Jr);
			DelC2B1Att(src);
			std::vector<std::pair<IInstruction *, std::vector<IInstruction *>>>::iterator itr;
			for(itr = vRecovery.begin(); itr != vRecovery.end(); itr++)	{
				IInstruction *takenBCond = itr->first;
				if (takenBCond == src)  
					itr->first = Jr;
				std::vector<IInstruction*> &vNotTaken = itr->second;
				std::vector<IInstruction*>::iterator ntItr;
				for(ntItr = vNotTaken.begin(); ntItr != vNotTaken.end(); ntItr++) {
					IInstruction* notTakenBCond = *ntItr;
					if (notTakenBCond == src)  *ntItr = Jr;
				}
			}
			IInstruction* old = pCb->Replace(src, Jr);
			FROG_ASSERT(old == src);
			delete old;
		}else{
			src->opr(0)->SetLabel( dst->GetLabel() );
            src->SetJumpTargetLabel(dst->GetLabel());
		}
	};

	//  -----------------------------------------------------------------------------------
	//  汎用シーケンス ジャンプ接続 
	//	   ・src -> dstへ処理がつながるように追加命令を挿入する。
	//     ！ pOffsMapを毎回更新しないと正確な距離はわからない（命令がどんどん挿入されるため）
	//        実際は毎回更新しないでマージンを持たせている。
	//  -----------------------------------------------------------------------------------
	auto Chain_jmp = [&] (IInstruction* src, IInstruction* dst) {
        pOffsMap.reset(pCb->GetOffsetMap());

		UI32 distance = std::abs((int)((*pOffsMap)[dst] - (*pOffsMap)[src]));
		if (distance < 0x13FFFF6 || src->GetId() == INS_ID_JARLD22 || src->GetId() == INS_ID_JARL || src->GetId() == INS_ID_JRD32 || src->GetId() == INS_ID_JMP || src->GetId() == INS_ID_JMPD32) {
			if(src->GetId() == INS_ID_JMP || src->GetId() == INS_ID_JARL){
				src->SetJumpTargetLabel(dst->GetLabel());
				IInstruction* mov = MOV32P(dst->GetLabel(), src->opr(0)->Idx());
				pCb->Insert(mov, src);
				UpdateHeadBCond(src, mov);
				src->DirMoveTo(mov);
				mov->SetRegulationTarget(src);
				pCb->Update();
				return;
			}
            if (src->GetId() == INS_ID_JMPD32) {
                if (pCb->GetName().find("init") != std::string::npos ||
                    pCb->GetName().find("syscall") != std::string::npos ||
                    pCb->GetName().find("callt") != std::string::npos) {

                    IInstruction* mov = MOV32(g_rnd.Get(), src->opr(0)->Idx());
                    pCb->Insert(mov, src);
                    UpdateHeadBCond(src, mov);
                    src->DirMoveTo(mov);
                    mov->SetRegulationTarget(src);
                }
            }
			src->opr(0)->SetLabel(dst->GetLabel());
			src->SetJumpTargetLabel(dst->GetLabel());
		} else{
			IInstruction* Jr  = JR32P(dst->GetLabel());
			src->DirMoveTo(Jr);
			Jr->SetJumpTargetLabel(dst->GetLabel());
			IInstruction* old = pCb->Replace(src, Jr);
			FROG_ASSERT(old == src);
			delete old;	
		}
	};
	//  -----------------------------------------------------------------------------------
	//  常にTakenとなるブランチ命令（として扱うもの）であるかを判定する。
    //  TODO: ニモニックで判断するのはよろしくないので課題とする
	//  -----------------------------------------------------------------------------------
	auto IsAlwaysJump = [&] (IInstruction* p) {
		const std::string& mne = p->GetMne();
		return (mne=="ctret"||mne=="eiret"||mne=="feret"|| mne=="br" || mne =="jarl" || mne =="jr" || mne =="jmp" || ((mne=="dispose") && (p->GetOpNum()==3)) );
	};

	//  -----------------------------------------------------------------------------------
	//  lambda function generating recovery code for not taken BCond instruction
	//  @param Code block
	//  @param vecto pair one taken BCond and vecto BCond not taken.
	//-------------------------------------------------------------------------------------
	auto GenerateRecovery = [&](CCodeBlock *pCb, std::vector<std::pair<IInstruction *, std::vector<IInstruction *>>> &vRec)
	{
		UI32 const FP_LEN = ADD(0,0)->GetLen();
		UI32 const RET_LEN = JR22P("")->GetLen();
		UI32 const BR9_LEN = BR9(0)->GetLen();

		auto FootPrint = [](std::string &label){
			IInstruction *fp = ADD(0, 0);
			fp->SetLabel(label);
			fp->SetSequence(IInstruction::IF_SEQ_RECOVERY);
			fp->AppendComment("FootPrint");
			return fp;
		};
		auto RetIns = [](std::string& label){
			IInstruction *Jr = JR22P(label + "_ret");
			Jr->SetSequence(IInstruction::IF_SEQ_RECOVERY);
			Jr->AppendComment("Recovery code");
			return Jr;
		};
		auto JumpOverRec = [&](UI32 codesize){
			IInstruction *br = BR9(codesize + BR9_LEN);
			br->SetSequence(IInstruction::IF_SEQ_RECOVERY);
			br->AppendComment("Recovery code");
			return br;
		};

		std::vector<std::pair<IInstruction *, std::vector<IInstruction *>>>::iterator itr;
		for(itr = vRec.begin(); itr != vRec.end(); itr++)
		{
			IInstruction *takenBCond = itr->first;
			std::vector<IInstruction*> &vNotTakenBCond = itr->second;
			std::vector<IInstruction*>::iterator ntItr;
			UI32 nRecPos = pCb->GetIndex(takenBCond);
			UI32 nRecSize = 0;
			UI32 nPos = nRecPos + 1;
			bool bRecPos = true;
			bool bInSequence = false;
			while(vNotTakenBCond.size() > 0){
				IInstruction *pTemp = pCb->at(nRecPos);
				// Insert recovery code for all Not Taken BCond
				ntItr = vNotTakenBCond.begin();
				while(ntItr != vNotTakenBCond.end()){
					IInstruction* notTakenBCond = *ntItr;
					std::string label(notTakenBCond->opr(0)->GetLabel());
					pOffsMap.reset(pCb->GetOffsetMap());
					UI32 distance = std::abs((int)((*pOffsMap)[pTemp] - (*pOffsMap)[notTakenBCond]));

					if(bInSequence)
						nPos--;

					if(bRecPos == false){

						IInstruction *Jr = JR22P(label);
						notTakenBCond->DirMoveTo(Jr);
                        DelC2B1Att(notTakenBCond);
						IInstruction* old = pCb->Replace(notTakenBCond, Jr);
						delete old;
						distance = distance % BCOND_LIMIT;
						bRecPos = true;
					}
					if(distance < BCOND_LIMIT)
					{
						pCb->AddOpeCode(FootPrint(label), nPos++);
						nRecSize += FP_LEN;

						if(*ntItr != takenBCond){ // The last chain is end by a not taken instruction.
							pCb->AddOpeCode(RetIns(label), nPos++);
							nRecSize += RET_LEN;
						}
						ntItr = vNotTakenBCond.erase(ntItr);
					}
					else
						ntItr++;
				}

				// Last chain block
				if (nRecSize > 0){
					if(bInSequence){
						nRecPos =(SI32) nRecPos;
						nRecPos--;
						bInSequence = false;
					}
					pCb->AddOpeCode(JumpOverRec(nRecSize), nRecPos + 1);	// Insert br instruction to jump over recovery area.
				}

				if(vNotTakenBCond.size() != 0){
					IInstruction *pSrc = *(vNotTakenBCond.begin());
					IInstruction *pIns;
					UI32 nSrcIdx = 0;
					UI32 dis;
					// Search the suitable position for recovery
					for(UI32 idx = pCb->GetIndex(takenBCond); idx >= nSrcIdx; idx--)
					{
						pIns = pCb->at(idx);
						std::string mne = pIns->GetMne();
						if(pIns->InSequence() || pIns->InLoop() || (mne == "jarl") || (mne == ".hword") || (mne == ".word")|| (mne == "switch")){
							if(idx == 0){
								dis = std::abs((int)((*pOffsMap)[pIns] - (*pOffsMap)[pSrc]));
								if(dis >= BCOND_LIMIT)
									bRecPos = false;
								//nRecPos = (SI32)nRecPos;
								nRecPos = idx;
								nPos = nRecPos + 1;
								nRecSize = 0;
								bInSequence = true;
								break;
							}
							continue;
						}
						bInSequence = false;
						dis = std::abs((int)((*pOffsMap)[pIns] - (*pOffsMap)[pSrc]));
						if(dis < BCOND_LIMIT){
							// Start new recovery block
							nRecPos = idx;
							nPos = nRecPos + 1;
							nRecSize = 0;
							break;
						}

						if(idx == 0){
							bRecPos = false;
							nRecPos = idx;
							nPos = nRecPos + 1;
							nRecSize = 0;
							break;
						}
					

					}
				}
			}
		}
	};
	//lamda function to generate recovery code for taken instruction
	auto GenerateRecoveryTaken = [&] (CCodeBlock* pCB)
	{
		for(UI32 i = 0; i < pCB->GetInstructionNum()-1; i++)
		{
			IInstruction*		pIns = pCB->at(i);
			if (pIns != nullptr && pIns->GetConstraint()&&(!IsAlwaysJump(pIns) )&& pIns->GetMne()!= "jr" )
			{
				IInstruction * Footprint = ADD(0, 0);
				Footprint->AppendComment("FootPrint");
                Footprint->SetSequence(IInstruction::IF_SEQ_RECOVERY);
				pCB->AddOpeCode(Footprint,i+1);
				IInstruction * targetLabel = JR22P(pIns->opr(0)->GetLabel());
				pCB->AddOpeCode(targetLabel,i+2);
			}

		}
	};

	// Lamda function to set target label for instruction or generate additional instruction
	auto SetTargetLabel = [&JmpReg](IInstruction* p, std::string label){
		UI32 pId = p->GetId();
		IInstruction* adjust = nullptr;
		if(pId == INS_ID_JARL || pId == INS_ID_JMP || pId == INS_ID_DISPOSE_R3) {
			adjust = MOV32P (label, p->opr(JmpReg)->Idx());
			adjust->SetRegulationTarget(p);
            p->SetJumpTargetLabel(label);
        } else if (pId == INS_ID_JMPD32) {
            p->SetJumpTargetLabel(label);
        }

		p->opr(JmpReg)->SetLabel(label);

		return adjust;
	};

	//  -----------------------------------------------------------------------------------
	//  メイン処理ここから開始
	//  -----------------------------------------------------------------------------------
	if (IsAlwaysJump(pCb->at(pCb->GetInstructionNum()-1))) {
		NewINS (pCb, NOP()); // NOPを追加することで最後を分岐命令にしない
	}

	UI32 iNum = pCb->GetInstructionNum();
	std::string cbn = pCb->GetName();
	char buff[1024];
	
	IInstruction* head = pCb->at(0);
	

	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		IInstruction*		pIns = pCb->at(i);
		IInstruction* adjust = nullptr;
		if(pIns->HasBranchConstraint() )
		{
			if(0){
				if(pIns->GetConstraint() == false && (!IsAlwaysJump(pIns) )){
					std::sprintf(buff, "%s_br%d_rec", cbn.c_str(), i + 1);
					std::string label(buff);
					// Set label to recovery code
					pIns->opr(0)->SetLabel(label);
					if (i < (iNum-1)) {
						pCb->at(i + 1)->SetLabel(label + "_ret");
					}
					vNotTakenBCond.push_back(pIns);
				}
			}
			continue;
		}

		if(pIns->GetReverse() == nullptr )
			continue;

		if(pIns->InLoop() == true)	{
			std::sprintf(buff, "%s_br%d", cbn.c_str(), i + 1);
			std::string label(buff);
			if(pIns->GetId() == INS_ID_DISPOSE_R3)
				JmpReg = 2;
			else
				JmpReg = 0;
			// Set target label		
			adjust = SetTargetLabel(pIns, label);
			UI32 jmpRange = 0; // Maximum jmp range

			// Random dest instruction in loop sequence only
			for(UI32 pos = i + 1; pos < pCb->GetInstructionNum() - 1; pos++){
				if(pCb->at(pos)->GetId() == INS_ID_LOOP){
					jmpRange = pos;
					break;
				}
			}
			// 
			UI32 pos = g_rnd.GetRange(i+1, jmpRange);
			IInstruction* dst =  pCb->at(pos);
			UI32 try_time = 10;
			// Main operation
			while(pIns->InLoop() == false && pCb->at(pos)->InSequence() == true){
				try_time--;
				if(try_time == 0){
					pIns->opr(JmpReg)->RemoveLabel();
					if(adjust != nullptr || pIns->GetId() == INS_ID_JMPD32){
						dst = pCb->at(i+1);
					} else {
						pIns->opr(JmpReg)->Replace(pIns->GetLen());
						label = "";
					}
					break;
				}
				pos = g_rnd.GetRange(i+1, jmpRange);
				dst =  pCb->at(pos);
			}

			if(label.size())
				dst->SetLabel(label);

			if(adjust != nullptr){
				if(pIns->GetId() == INS_ID_DISPOSE_R3){
					pIns->SetInsNeed (adjust);
					continue;
				}
				
				pIns->DirMoveTo(adjust);
				adjust->SetSequence();
				adjust->SetInLoop(pIns->InLoop());
				pCb->AddOpeCode(adjust, i);
				pCb->Update();
				i = pCb->GetIndex(pIns);
			}
			continue;
		}
		if (i >= (pCb->GetInstructionNum()-1)) {
			pIns->SetTaken(false);
			if(bRecCode){

				std::sprintf(buff, "%s_br%d_rec", cbn.c_str(), i + 1);
				std::string label(buff);
				// Set label to recovery code
				pIns->opr(0)->SetLabel(label);
				vNotTakenBCond.push_back(pIns);
			}
		}else{
			if (((g_rnd.Get() & 1) != 0) || IsAlwaysJump(pIns) ) {   // Taken or NOT
				pIns->SetTaken(true);

				std::sprintf(buff, "%s_br%d", cbn.c_str(), i + 1);
				
				bcv.push_back( BChain(head, pIns) );
				head = pCb->at(i + 1);
				head->SetLabel(buff);
				if(bRecCode){
					// Commit list of not taken BCond in a chain block.
					vRecovery.push_back(std::pair<IInstruction*, std::vector<IInstruction *>>(pIns, vNotTakenBCond));
					vNotTakenBCond.clear();
				}

			}
			else{
				pIns->SetTaken(false);
				if(bRecCode){
					std::sprintf(buff, "%s_br%d_rec", cbn.c_str(), i + 1);

					std::string label(buff);
					// Set label to recovery code
					pIns->opr(0)->SetLabel(label);
					// Create label for return code in recovery.
					pCb->at(i + 1)->SetLabel(label + "_ret");
					vNotTakenBCond.push_back(pIns);
				}
			}
		}
	}

	if (head == nullptr) {
		// 最後の命令がブランチ(taken)
	}else{
		bcv.push_back( BChain(head, pCb->at(pCb->GetInstructionNum() - 1)) );
		if(bRecCode){
			// Commit list of not taken BCond in the last chain block
			vRecovery.push_back(std::pair<IInstruction*, std::vector<IInstruction *>>(pCb->at(pCb->GetInstructionNum() - 1), vNotTakenBCond));
			vNotTakenBCond.clear();
		}
	}

	if (bcv.size() < 1) {
		return; // コードブロック内にブランチ命令が無かった
	}

	#if 0 //def BRANCH_DEBUG
	std::cout << "-------Before shuffle ---------------------------" << std::endl;
	std::for_each (bcv.begin(), bcv.end(), [](const BChain& bc) {
		std::cout << "Head is " << bc.first->GetMne() << " Tail(jump) is  " << bc.second->GetMne() << std::endl;
	});
	#endif	
	
	if (bcv.size() > 3) {
		BChainVec::iterator b = bcv.begin();
		BChainVec::iterator e = bcv.end();
		std::advance(b,  1);	// 先頭は対象外
		std::advance(e, -2);	// 最後は対象外
		std::random_shuffle(b, e, g_rnd); // 順番をランダムに決める
	}
	

	#if 0 //def BRANCH_DEBUG
	std::cout << "-------after shuffle ---------------------------" << std::endl;
	std::for_each (bcv.begin(), bcv.end(), [](const BChain& bc) {
		std::cout << bc.first->GetMne() << " - " << bc.second->GetMne() << std::endl;
	});
	std::cout << "-------------------------------------------------" << std::endl;
	#endif

	for (UI32 n = 1; n < bcv.size(); n++) {
		IInstruction* src = bcv[n - 1].second;
		IInstruction* dst = bcv[n].first;
        const std::string& mne = src->GetMne();
		if (mne == "ctret")	Chain_ctret(src, dst);
		else if (mne == "eiret")	Chain_eiret(src, dst);
		else if (mne == "feret")	Chain_feret(src, dst);
		else if (mne == "dispose")	Chain_dispose(src, dst);
	}

	//Get the jump and destination follow the codeblock order and jump sequence order to compare
	//Get jump and dest follow sequence order first execute instruction -> last execute instruction
	std::vector<IInstruction*> v_orderSrcIns;
	std::vector<IInstruction*> v_orderDstIns;
	for (UI32 n = 1; n < bcv.size(); n++) {
		IInstruction* dst = bcv[n].first;
		IInstruction* src = bcv[n - 1].second;
		pCb->RecordBrTarget(dst->GetLabel());
		v_orderDstIns.push_back(dst);
		v_orderSrcIns.push_back(src);
	}

	//Get jump and dest follow palce in code block first appear instrcution -> last appear instrcution
	std::vector<IInstruction*> v_localSrcIns;
	std::vector<IInstruction*> v_localDstIns;
	for (UI32 m = 0; m < pCb->GetInstructionNum(); m++) {
		if(std::find(v_orderSrcIns.begin(), v_orderSrcIns.end(), pCb->at(m)) != v_orderSrcIns.end()) v_localSrcIns.push_back(pCb->at(m));
		if(pCb->IsBrTarget(pCb->at(m)))
			v_localDstIns.push_back(pCb->at(m));
	}

	IInstruction *pChainHead = pCb->at(0);
	//The first jump is forwarding jump, prepare gap for its adjustment code
	if ( !v_localSrcIns.empty() && (v_localSrcIns[0]->InSequence(IInstruction::IF_SEQ_FWD)
		|| (pCb)->GetName().find("syscall") != std::string::npos || (pCb)->GetName().find("callt") != std::string::npos)) {
		AddGap(pChainHead, v_localDstIns[0]);
		pChainHead = v_localDstIns[0];
	}
	//Insert the gap code for synchronize PC
	for (UI32 n = 1; n < v_localDstIns.size(); n++) {
		//Insert to Label2 when Label1 -> Label2 in Code Block and Label1 was executed after label2 
		std::vector<IInstruction*>::iterator iter1 = std::find(v_orderDstIns.begin(), v_orderDstIns.end(), v_localDstIns[n]);
		std::vector<IInstruction*>::iterator iter0 = std::find(v_orderDstIns.begin(), v_orderDstIns.end(), v_localDstIns[n - 1]);
		//The jump before this label is forwarding jump instruction
		IInstruction* preJump = v_localSrcIns[n];
		if (std::distance(iter0, iter1) < 0 || preJump->InSequence(IInstruction::IF_SEQ_FWD) 
			|| (pCb)->GetName().find("syscall") != std::string::npos || (pCb)->GetName().find("callt") != std::string::npos ) {
			//Insert the gap code: gap code will be remove in simulation when there are new instruction insert to codeblock
			AddGap(pChainHead, v_localDstIns[n]);
			pChainHead = v_localDstIns[n];
		}
	}

	std::vector<IInstruction*> v_chained;
    pOffsMap.reset(pCb->GetOffsetMap());
    for (UI32 n = 1; n < bcv.size(); n++) {
		IInstruction* src = bcv[n - 1].second;
		IInstruction* dst = bcv[n].first;
		UI32 InsID = src->GetId();
		UI32 dstID = dst->GetId();

		//Chain for sequential jmp and jarl
		if (dstID == INS_ID_JMP && (n + 1 < bcv.size())) {
			IInstruction * postDst = bcv[n+1].first;
			if (IsSequentialAdjust (src, dst, postDst)) {
				//Special handle for callt/syscall later
				if(pCb->GetName().find("init") == std::string::npos)
					PreSequentialChain(src, dst, postDst->GetLabel());
				else dst->SetJumpTargetLabel(postDst->GetLabel());
				//mark destination as adjusted, not need to adjust anymore
				v_chained.push_back(dst);
			}
		}

		// The normal BCond Ins (Id: 7->49) exclude ctret, feret, eiret, dispose
		if( InsID >= INS_ID_BC_SD9 && InsID <= INS_ID_BZ_SD17)
			Chain_default(src, dst);
		if(InsID == INS_ID_JARLSD22 || InsID == INS_ID_JARLD22 || InsID == INS_ID_JARL || InsID == INS_ID_JRSD22 || InsID == INS_ID_JRD32 || InsID == INS_ID_JMP || InsID == INS_ID_JMPD32) {
			if (std::find(v_chained.begin(), v_chained.end(), src) == v_chained.end())
				Chain_jmp(src, dst);
		}
	}
	if(bRecCode){
		GenerateRecovery(pCb, vRecovery);
		GenerateRecoveryTaken(pCb);
		
	}
	//Special sequential jump handle for callt/syscall
	if(pCb->GetName().find("init") != std::string::npos) {
		pCb->Update();
		for (UI32 n = 0; n < v_chained.size(); n++) {
			if (v_chained[n]->GetLabel().size() == 0) {
				continue;
			}
			for (UI32 m = 0; m < pCb->GetInstructionNum(); m++) {
				IInstruction *src = pCb->at(m);
				if ( !src->Behavior(IInstruction::JMP)) continue;

				if (src->GetJumpTarget() == v_chained[n]->GetLabel()) {
					PreSequentialChain(src, v_chained[n], v_chained[n]->GetJumpTarget());
					m = pCb->GetIndex(src);
				} else {
					IOperand*	pOpr;
					for (UI32 k = 0; (pOpr = src->opr(k)) != NULL; k++) {
						// Operand is label to replace effective value.
						if (pOpr->GetLabel() != nullptr && pOpr->GetLabel() == v_chained[n]->GetLabel()){
							PreSequentialChain(src, v_chained[n], v_chained[n]->GetJumpTarget());
							m = pCb->GetIndex(src);
							break;
						}
					}
				}
			}
		}
	}

	pCb->Update();
}


/**
 * @brief  指定ブロック内のloop命令を安定的なループに再構成する。
 * @param  pCb 処理対象のブロック
 */
void CBlockManager::MakeLoopSequence(CCodeBlock* pCb) {

#if DBGMODE
	bool debug1 = !true;
	bool debugL = false;
#endif

	// Improving number instruction in loop sequence
	// Lamda function to change register of instruction p
	// Try to keep instruction in loop sequence
	auto ChangingRegister = [] (IInstruction* p, UI32 notUseId, UI32 misRegSet){
		UI32 s = p->GetConstraintBit(); // 補正ソースは値が変更される
		UI32 d = p->GetGrDst();
		std::vector <UI32> vfreeIdx;

		// This function was used to replace operand index
		auto ReplaceOperand = [&p, notUseId] (IOperand* opr, UI32 OprIdx){
			// Adjust list12
			UI32 s = p->GetConstraintBit(); // 補正ソースは値が変更される
			UI32 d = p->GetGrDst();
			UI32 clearbit = s & d;
			UI32 updatebit = 0;
			std::vector<UI32> vFreeBit = {};
			for(UI32 i = 20; i < 32; i++)
				if ( (((notUseId >> i) & 0x1) == 0) && (((clearbit >> i) & 0x1) == 0))
					vFreeBit.push_back(i);

			if(vFreeBit.size() != 0){
				std::random_shuffle(vFreeBit.begin(), vFreeBit.end(), g_rnd);
				updatebit = (vFreeBit.back() == 30 ) ? 0 : ((vFreeBit.back() > 27) ? (24 + 31 - vFreeBit.back()) : (20 + 27 - vFreeBit.back()));
			}
			if(clearbit == 0 || clearbit == 0x8)// SP is rw
				return;
			else{
				UI32 val = ((((UI32) * opr) | (1 << updatebit) ) & (~clearbit)) ;
				opr->Replace(val);
			}
			s = p->GetConstraintBit();
			d = p->GetGrDst();
			clearbit = (notUseId & (s | d));

			if(clearbit == 0 || clearbit == 0x8)// SP is rw
				return;
			else{
				UI32 val = ((((UI32) * opr) | (1 << updatebit) ) & (~clearbit)) ;
				opr->Replace(val);
			}		
		};

        // Mismatch reg dependance iinstructions
		std::string mne = p->GetMne();
		if ((mne.find("stsr", 0) != std::string::npos) || (mne.find("sttc", 0) != std::string::npos)
			|| (mne.find("rsqrtf", 0) != std::string::npos) || (mne.find("stvc", 0) != std::string::npos))
			return;
		
        if(misRegSet && (mne == "caxi" || mne.find("stc") != std::string::npos))
            return;

		// Collect all free operand index
		for(UI32 i = 0; i < 32; i++)
			if(((notUseId >> i) & 0x1) == 0 && ((s >> i) & 0x1) == 0 && ((d >> i) & 0x1) == 0)
				vfreeIdx.push_back(i);

		std::random_shuffle(vfreeIdx.begin(), vfreeIdx.end(), g_rnd);
		for(UI32 op = 0; op < p->GetOpNum(); op++){
			IOperand* opr = p->opr(op);
			UI32 idx = p->opr(op)->Idx();
            if((opr->GetGrSrc() | opr->GetGrDst()) & misRegSet)
                continue;

			if((p->GetId() == INS_ID_DISPOSE_R3 || p->GetId() == INS_ID_DISPOSE) && op == 1 ){
				ReplaceOperand (opr, vfreeIdx.back());
				p->SetForcedAdjust(true);
				continue;
			}
			// Can not improve case idx = 0
			// Can not change r0 in case operand type in: Imm, SImm ...
			// It will be check after this function 
			if(idx == 0)
				continue;

			// Conflict inside instruction and operand
			// 1. divf.d r18, r16, r16
			while ((((s & d) >> idx) & 0x1) && vfreeIdx.size() > 0){
				if(p->opr(op)->Replace(vfreeIdx.back()) == true){
					idx = p->opr(op)->Idx();
					s = p->GetConstraintBit();
					d = p->GetGrDst();
				}
				vfreeIdx.pop_back();
			}

			// divf.d r18, r16, r20;
			// addf.d r18 ,r6, r8;
			while ( (((notUseId & (s | d)) >> idx) & 0x1) && vfreeIdx.size() > 0 ) {
				if(p->opr(op)->Replace(vfreeIdx.back()) == true){
					idx = p->opr(op)->Idx();
					s = p->GetConstraintBit();
					d = p->GetGrDst();
				}
				vfreeIdx.pop_back();
			}
			// It is same with don't use register
			while((notUseId & (1 << idx)) && vfreeIdx.size() > 0){
				if(p->opr(op)->Replace(vfreeIdx.back()) == true){
					idx = p->opr(op)->Idx();
					s = p->GetConstraintBit();
					d = p->GetGrDst();
				}
				vfreeIdx.pop_back();
			}
		}
		
		return;
	};

	// Loop命令を検出する(下から上)
	// ループカウンタ設定命令を生成しループ範囲を広げれるところまで拡大していく(↑方向)
	UI32 i;
	for (UI32 iNum = pCb->GetInstructionNum(); iNum > 0; iNum--) {
		i = iNum - 1;
		IInstruction* pIns = pCb->at(i);
		std::string   mne  = pIns->GetMne();
		
		if (pIns->InSequence(IInstruction::IF_SEQ_NORM)) {
            // Regulate for custom instruction INS_CID_PREF_I
            if (mne == "loop") {
                std::stringstream ss;
                ss << pCb->GetName() << "_Lp_" << i;
                pIns->opr(1)->SetLabel(ss.str().c_str());
                pCb->at(i - 2)->SetLabel(ss.str().c_str());
            }
			continue; // It does not process immutable instructions generated as part of a series of procedures (eg instructions related to switch)
		}
		
		if (mne == "loop") {
			UI32 nIdx = i > 10 ? (i - 10) : 0;
			for (nIdx = i - 10; nIdx < i; nIdx++) {	// Search in 10 preceding instruction
				IInstruction* p = pCb->at(nIdx);	// j::loopのすぐ上の命令
				if(p->GetMne() == "switch" && g_rnd.GetRange(0, 1)) {
					IInstruction* terminateIns = MOV5(1, pIns->opr(0)->Idx());
					pIns->DirMoveTo(terminateIns);
					terminateIns->SetRegulationTarget(pIns);
					pCb->AddOpeCode(terminateIns, i);
					pIns->opr(0)->SetConstraint(new IValConstraint(1,1,0,0) );
					// set sequence so that switch instruction will jump to mov instruction
					pIns->SetSequence();
					break;
				}
			}
			if(nIdx < i) {
				continue;
			}
			
#if DBGMODE
			if (debug1) {
				std::cout<< std::endl << "=============================" << std::endl;
				pCb->Update();
				pCb->Dump(std::cout);
				debug1 = false;
				debugL = true;
			}
#endif
			// ループ構成準備、ループカウンタのレジスタを取得、ラベルを生成。
			std::stringstream ss;
			ss << pCb->GetName() << "_Lp_" << i;
			REGFLG idx  = pIns->opr(0)->Idx();
			pIns->opr(1)->SetLabel(ss.str().c_str());
			pIns->SetSequence();
			UI32 looptime = g_rnd.GetRange(1U, g_cfg->m_nMaxLoop+1);
			IInstruction* terminateIns = NULL;

			// MOVカウントセット（A）
			terminateIns = MOV5(looptime, idx);

			// loopにラベルが付いている（jmpの着地点など）場合、
			// そのままloopの直前にMOVカウントセットしても、実行されない。
			// 着地点をMOVカウントセット位置に再設定する。
			pIns->DirMoveTo(terminateIns);
			terminateIns->SetRegulationTarget(pIns);

			// Do not generate contents for loop in FWD
			if(pIns->InSequence(IInstruction::IF_SEQ_FWD)) {
				pCb->at(i)->SetLabel(ss.str());
				pCb->AddOpeCode(terminateIns, i);
				pIns->opr(0)->SetConstraint(new IValConstraint(looptime,looptime,0,0) );
				continue;
			}

			// ループの範囲を広げていく、範囲が決まったらカウンタ設定命令（A）を挿入する
			// 範囲はループ命令から上に遡りながら命令を走査し調べる。
			// レジスタの依存関係がないことが条件 
			//
			// SetInLoopフラグについて・・・
			//      mov      3,  r9          ; 3周実行
			//__for:                         ;
			//		addi     5,  r4,    r8   ; r8を補正(x)
			//      addf.s  r8,  r5          ; 補正されたオペランドr8で実行
			//      sub     r7,  r4          ; 補正命令(x)に影響するレジスタが書き換えられると
			//		loop    r9,  __for       ; ループで戻ったときにおかしくなる
			//                               ; よってループ内の補正命令は "mov imm, reg"で補正する
			UI32 lp = i;
			REGFLG regX = 0;
            std::set<UI32> regJumpMismatch;

			for (; lp > 0; lp--) {
				IInstruction* pJns = pCb->at(lp - 1);	// j::loopのすぐ上の命令
                std::string mne = pJns->GetMne();
                UI32 insid = pJns->GetId();

				if (pJns->InSequence()) {
					break; // 立入禁止で打ち切り
				}
				
				if (pJns->Behavior(IInstruction::JMP) ){
					if((insid >= INS_ID_JARLSD22 && insid <= INS_ID_JRD32) ||insid == INS_ID_DISPOSE_R3){
						pJns->SetReverse(NOP());
					} else
						break; // ジャンプ命令で打ち切り
				}
				if (pJns->HasAsyncLabel() && pCb->GetHandlerAddress() == 0) {
					break;
				}

				//[FROG]TODO: Limitation - don't support resbank in loop sequence.
				if (insid == INS_ID_RESBANK || insid == INS_ID_SWITCH) {
					break;
				}

				if (pJns->GetLabel().length() > 0) {
					break; // ジャンプ命令の着地で打ち切り
				}

                if (insid == INS_ID_HALT) {
                    bool isEI = false;   
                    UI32 count = lp;
                    UI32 InsIdtemp = pCb->at(count)->GetId();
                    while (InsIdtemp != INS_ID_LOOP) {
                        if (InsIdtemp == INS_ID_EI) {
                            isEI = true;
                            break;
                        }
                        count++;
                        InsIdtemp = pCb->at(count)->GetId();
                    }

                    if (isEI) break;
                }

				UI32 s = pJns->GetConstraintBit(); //pJns->GetGrSrc(); // 補正ソースは値が変更される
				UI32 d = pJns->GetGrDst();
				
				// Mismatch reg dependance iinstructions
				if ((mne.find("stsr", 0) != std::string::npos) ||
					(mne.find("sttc", 0) != std::string::npos) ||
					(mne.find("rsqrtf", 0) != std::string::npos) ||
					(mne.find("recipf", 0) != std::string::npos) ||
					(mne.find("stvc", 0) != std::string::npos) )
					break;

				// Ignore instructions that overwrite precision error
				if (pJns->GetComment().find("Overwrite precision error!") != std::string::npos)
					break;

				// Improving number instruction in loop sequence
				ChangingRegister(pJns, (regX | m_nMismatchRegSet), m_nMismatchRegSet);
				if(insid == INS_ID_JARL && lp >= 2 && pCb->at(lp - 2)->GetRegulationTarget() == pJns){
					pJns->SetConstraint(false);
					pCb->at(lp - 2)->SetRegulationTarget(nullptr);
				}
				
				s = pJns->GetConstraintBit();
				d = pJns->GetGrDst();
				if(pJns->GetMne() == "dispose")
					s &= ~(1 << 3);

				if (s & d) {
					break; // divf.d r18, r16, r16
				}
				if (regX & (s | d)) {
					break; // divf.d r18, r16, r20; addf.d r18 ,r6, r8
				}else{
					regX |= (s | d);
				}
				if (regX & (1 << idx)) {
					break; // loop インデックスに影響する
				}

                // Overwrite register mismatch of jump instruction           
                if (pCb->GetName().find("syscall") != std::string::npos || pCb->GetName().find("callt") != std::string::npos) {                 
                    switch (insid) {
                        case INS_ID_DISPOSE_R3:
                            regJumpMismatch.insert(pJns->opr(2)->Idx());
                            break;
                        case INS_ID_JARLSD22:
                        case INS_ID_JARLD22:
                            regJumpMismatch.insert(pJns->opr(1)->Idx());
                            break;
                        case INS_ID_JARL:
                            regJumpMismatch.insert(pJns->opr(0)->Idx());
                            regJumpMismatch.insert(pJns->opr(1)->Idx());
                            break;
                        case INS_ID_JMP:
                        case INS_ID_JMPD32:
                            regJumpMismatch.insert(pJns->opr(0)->Idx());
                            break;
                    }
                }

				pJns->SetInLoop();
				pJns->SetSequence();			
			}

			//--------------------------------------------------------------
			// 繰り返しが自分自身の空ループを間引く、ここから
			if (lp == i) {
				// ラベルが付いていないもの
				if (terminateIns->GetLabel() == "") {
					// 7/8を間引くぐらいが自然になる
					if ((g_rnd.Get() & 3) == 0) {
						delete terminateIns;
						pCb->Remove(pIns);
						pCb->Update();
					}else{
						pCb->at(lp)->SetLabel(ss.str());
						pCb->AddOpeCode(terminateIns, lp);
					}
				}else{
					pCb->at(lp)->SetLabel(ss.str());
					pCb->AddOpeCode(terminateIns, lp);
				}
			} else
			// 繰り返しが自分自身の空ループの処理、ここまで
			//--------------------------------------------------------------
			// 必要ないなら下記ブロックだけ
			{
				pCb->at(lp)->SetLabel(ss.str());
				pCb->AddOpeCode(terminateIns, lp);
			}

            for (UI32 reg : regJumpMismatch) {
                pCb->AddOpeCode(MOV32(g_rnd.Get(), reg), pCb->GetIndex(pIns) + 1);
            }

		}
	}
#if DBGMODE
	if (debugL) {
		std::cout << "----------------------------------------------------" << std::endl;
		pCb->Update();
		pCb->Dump(std::cout);
	}
#endif
}


/**
 * @brief RType制御(SIMDのアドレッシングについての除外項目)
 * 
 * Base = {Step/Index}となる命令は正常に補正できないため、使用する汎用レジスタを差し替える
 */
void CBlockManager::RTypeVerify(CCodeBlock* pCb) {
	FROG_ASSERT(pCb);
	
	// 
	UI32 iNum = pCb->GetInstructionNum();
	for (UI32 i = 0; i < iNum; i++) {
		pCb->at(i)->RTypeVerify();
	}
}

/**
 * @brief 誤差依存の伝搬切断処理
 * 
 * この関数は3つのラムダ式とメイン処理で構成される。
 * ハードウェアと吸収しきれない差分（FPU演算の誤差など）が
 * シミュレーション制御に影響しないよう、参照される前に上書きされる制御をつくり出す。
 * この問題の最もシンプルな解決方法は誤差命令実行後、すぐにMOV命令で上書きすることである。
 * しかしランダム検証という性質上、生成されるパタンは「自然にでたらめな命令列、かつ無難に終了すること」が期待される本質部分である。
 * 固定コードはとことん避けたいのでつぶす命令位置を後ろにずらしている。
 */
void CBlockManager::RemoveRegDependance(CCodeBlock* pCb) {

		
	auto GenDestIns = [&](IInstruction* pInsMismatch, UI32 reg) -> IInstruction* {
		const UI32 max_challenge = 30;
        UI32 nMismatchRegs = m_nMismatchRegSet;
         nMismatchRegs |= (1 << reg);

		UI32 InsId = pInsMismatch->GetId();
		if(InsId == INS_ID_RECIPF_S4 || InsId == INS_ID_RSQRTF_S4) {
			UI32 wr;
			do {
				wr = g_rnd.GetRange(0, 31);
				} while (wr == reg);
			return MOVVW4(wr, reg);
		}
		for (UI32 n = 0; n < max_challenge; n++) {
			IInstruction* pInsNew = m_nrmSet.CreateIns();
			//
			std::string mne = pInsNew->GetMne();
			if (pInsNew->Category(IInstruction::ICAT_FPU_S) || pInsNew->Category(IInstruction::ICAT_FPU_D) || (pInsNew->Category(IInstruction::ICAT_SIMD))) {
				delete pInsNew;
				continue;
			}
			if (/*mne == "rsqrtf.s" || mne == "rsqrtf.d" || mne == "recipf.s" || mne == "recipf.d" ||*/ 
				mne == "stsr" || mne == "sttc.sr"|| mne == "stvc.sr" || mne == "sttc.pc" ||			// 
				mne == "jarl" || mne == "setf")
			{
				delete pInsNew;
				continue;
			}

            // These instruction may cause mismatch in multicore pattern
			if(nMismatchRegs) {
           		// These instruction may cause next mismatched
				if (mne == "clr1" || mne == "not1"|| mne == "set1" || mne == "tst1" || mne == "caxi") {
					delete pInsNew;
					continue;
				}
                UI32		pInsNewId 	= pInsNew->GetId();
				// These instruction may used mismatched flag
				if(pInsNewId == INS_ID_ADF || pInsNewId == INS_ID_CMOV || pInsNewId == INS_ID_CMOV_SI5 || pInsNewId == INS_ID_SASF || pInsNewId == INS_ID_SBF || pInsNewId == INS_ID_SETF) {
		            delete pInsNew;
					continue;
		        }
		    }

			if (pInsNew->Behavior(IInstruction::LOAD_MEMORY)) {
				delete pInsNew;
				continue;
			}
			
			// G3M DIV does not write back gr on dividing ZERO.
			if (mne.find("div", 0) == 0) {
				delete pInsNew;
				continue;
			}

            if(nMismatchRegs) {
                if(pInsNew->Behavior(IInstruction::STORE_MEMORY)) {
                    delete pInsNew;
                    continue;
                }
                for (UI32 p = 0; p < pInsNew->GetOpNum(); p++) {
                    IOperand *pOpr = pInsNew->opr(p);
                    while ((pOpr->GetGrSrc() | pOpr->GetGrDst()) & nMismatchRegs) {
                        pOpr->Replace(g_rnd.GetRange(1, 31));
                    }
                }
            }

			UI32 bitreg = ((1 << reg) | (1 << (reg ^ 1)));
            if ((pInsNew->GetGrSrc() & bitreg) != 0) { 
                delete pInsNew;
                continue; 
            }
            for (UI32 p = 0; p < pInsNew->GetOpNum(); p++) {
                if (pInsNew->opr(p)->Attr(IOperand::OPR_ATTR_GR)  == true  &&
                	pInsNew->opr(p)->Attr(IOperand::OPR_ATTR_DST) == true  &&
                    pInsNew->opr(p)->Attr(IOperand::OPR_ATTR_SRC) == false &&
                    pInsNew->opr(p)->Replace(reg) == true )
                {
                    return pInsNew;
                }
            }
			delete pInsNew;
		}
        UI32 gr;
		do {
			gr = g_rnd.GetRange(0, 31);
		} while ((nMismatchRegs >> gr) & 1);
		return MOV32(gr, reg);
	};

	
	auto CheckDepend = [&](IInstruction* p, UI32 reg, bool isWR=false) -> SI32 {
		UI32 opNum = p->GetOpNum();
		std::string mne = p->GetMne();
        const UI32 SP = 3;

		if (p->Behavior(IInstruction::JMP)) {
			return 1;
		}

		if (p->HasAsyncLabel())
			return 1;

		if(isWR) {
			for (UI32 j = 0; j < opNum; j++) {
				IOperand* jopr = p->opr(j);
				if (jopr->Attr(IOperand::OPR_ATTR_WR) != true) {
					continue;
				}

				UI32 regN = jopr->Idx(); 
				if (jopr->Attr(IOperand::OPR_ATTR_SRC) != true) {
					if ((regN == reg) && (jopr->Attr(IOperand::OPR_ATTR_DST)) && (mne.find("div", 0) != 0)) {
						return -1;
					}
					continue;
				}
				if (regN == reg) {
					return 1;
				}
			}
		} else {
			if ((mne == "prepare" || mne == "pushsp"))
				return 1;

            if (reg == SP && (mne == "dispose" || mne == "popsp")) {
                return 1;
            }

			for (UI32 j = 0; j < opNum; j++) {
				IOperand* jopr = p->opr(j);
				if (jopr->Attr(IOperand::OPR_ATTR_GR) != true) {
					continue;
				}
				
				if (p->HasConstraint()) {
					return 1;
				}

				UI32 regN = jopr->Idx(); 
				if (jopr->Attr(IOperand::OPR_ATTR_SRC) != true) {
					if ((regN == reg) && (jopr->Attr(IOperand::OPR_ATTR_DST)) && (mne.find("div", 0) != 0)) {
						return -1;
					}
					continue;
				}
				if (jopr->Attr(IOperand::OPR_ATTR_PAIR)) {
					if (regN == (reg & ~1U)) {
						return 1;
					}
				}else if (regN == reg) {
					return 1;
				}
			}
		}
		return 0;
	};

	auto GenOverwriteFlagIns = [=] (UI32 nFlag,  std::vector<UI32> vReg) -> IInstruction* {
        const UI32 max_challenge = 30;
        UI32 nMismatchRegs = m_nMismatchRegSet;
        for(UI32 n = 0; n < vReg.size(); n++) {
            nMismatchRegs |= (1 << vReg[n]);
        }

        for (UI32 n = 0; n < max_challenge; n++) {
			IInstruction* pIns = m_nrmSet.CreateIns();
			//
			std::string mne = pIns->GetMne();
			UI32 id = pIns->GetId();
            if((pIns->UpdateFlag() & nFlag) == 0) {
                delete pIns;
				continue;
            }

           	// These instruction may cause next mismatched
			if (mne == "clr1" || mne == "not1"|| mne == "set1" || mne == "tst1" || mne == "caxi") {
				delete pIns;
				continue;
			}

			// These instruction may used mismatched flag
			if(id == INS_ID_ADF || id == INS_ID_CMOV || id == INS_ID_CMOV_SI5 || id == INS_ID_SASF || id == INS_ID_SBF || id == INS_ID_SETF) {
	            delete pIns;
				continue;
	        }
			
			// G3M DIV does not write back gr on dividing ZERO.
			if (mne.find("div", 0) == 0) {
				delete pIns;
				continue;
			}
            // Exclude multi-core mismatched register set
            if(nMismatchRegs) {
                for (UI32 p = 0; p < pIns->GetOpNum(); p++) {
                    IOperand *pOpr = pIns->opr(p);
                    while ((pOpr->GetGrSrc() | pOpr->GetGrDst()) & nMismatchRegs) {
                        pOpr->Replace(g_rnd.GetRange(1, 31));
                    }
                }
            }
            return pIns;
        }

        return ADD(0,0);
    };

    auto GetDepFlag = [] (IInstruction *p) -> UI32 {
        if (g_cfg->IsEnableDCU() == false) {
            return 0;
        }
        const std::string &mne = p->GetMne();
        if(mne == "clr1" || mne == "not1" || mne == "set1" || mne == "tst1") {
            return IInstruction::INS_FLG_Z;
        }

        if(mne == "caxi")
            return (IInstruction::INS_FLG_Z | IInstruction::INS_FLG_S | IInstruction::INS_FLG_OV | IInstruction::INS_FLG_CY);

        return 0;
    };

    auto CheckDependFlag = [] (IInstruction *p, UI32 nFlag) -> SI32{
        if(p->Behavior(IInstruction::JMP)) /* Including BCond */
            return 1;

        UI32 id = p->GetId();
        if(id == INS_ID_ADF || id == INS_ID_CMOV || id == INS_ID_CMOV_SI5 || id == INS_ID_SASF || id == INS_ID_SBF || id == INS_ID_SETF || id == INS_ID_STSR) {
            return 1;
        }

        if(p->UpdateFlag() & nFlag)
            return -1;

        return 0;
    };

	bool bdebug = false;

	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		IInstruction* pIns = pCb->at(i);
		UI64 depreg = pIns->GetOprIdxMistmatch();
		UI32 nDependFlag = GetDepFlag(pIns);

		if ((depreg == 0 && nDependFlag == 0 ) || pIns->GetLabel().find("Change_to") != std::string::npos) {
			if (bdebug) std::cout << " Non depend ins : " << pIns->GetCode() << std::endl;
			continue; // 依存関係でのエラーを発生させない、次の命令へ
		}
		UI32 InsId = pIns->GetId();
		bool IsWReg = false;
		if(InsId == INS_ID_RECIPF_S4 || InsId == INS_ID_RSQRTF_S4) 
			IsWReg = true;
	
		// 誤差発生を検出。
		UI32 holdPos = i + 1; // 誤差発生命令の次の命令を指す。
		UI32 h;
		// Detect Depend!! -> search soruce
		if (bdebug) std::cout << "Dependent OPECODE : " << pIns->GetCode() << std::endl;

		 // Only for mismatch of LD memory behavior ins in LD/ST array
        if(m_nMismatchRegSet != 0) { /* Only apply in generating multicore pattern*/
            while(holdPos < pCb->GetInstructionNum() && pCb->at(holdPos)->InSequence(IInstruction::IF_SEQ_ARRAY) && pCb->at(i)->InSequence(IInstruction::IF_SEQ_ARRAY)) {
                i = holdPos;
                holdPos++;
            }
        }
		// 潰すべき汎用レジスタ分処理
		for (UI32 r = 0; r < (IsWReg ? 64 : 32 ); r++) {
			if ((depreg & ((UI64)1 << r)) == 0) continue;
			if (bdebug) std::cout << "r" << r <<" - Start Check depend" << std::endl;
			
			IInstruction* dlnk;
			UI32 dReg = IsWReg ? (r - 32) : r;
			dlnk = GenDestIns(pIns, dReg);

			dlnk->AppendComment("Overwrite precision error!");
			for (h = holdPos; h < pCb->GetInstructionNum(); h++) {
				
				if ((pIns->GetForwardIns() != nullptr && pIns->GetForwardIns() == pCb->at(h)) ||
					(pIns->GetC2B1Ins() != nullptr && pIns->GetC2B1Ins() == pCb->at(h))) {
					pCb->AddOpeCode(dlnk, h);
					break;
				}
				if(pCb->at(h)->InSequence()){
					pCb->AddOpeCode(dlnk, h);
					break;
				}

				if (pCb->at(h)->GetOprIdxMistmatch() != 0){
					if (bdebug) std::cout << " Insert DeLINK : " << dlnk->GetCode() << std::endl;
					if (bdebug) std::cout << "\t\tHAVE DEPEND: " << pCb->at(h)->GetCode() << std::endl;
					pCb->AddOpeCode(dlnk, h);
					break;
				}
				SI32 retDepend = CheckDepend (pCb->at(h), dReg, IsWReg); 
				if (retDepend > 0) {
					if (bdebug) std::cout << " Insert DeLINK : " << dlnk->GetCode() << std::endl;
					if (bdebug) std::cout << "\t\tHAVE DEPEND: " << pCb->at(h)->GetCode() << std::endl;
					pCb->AddOpeCode(dlnk, h);
					break;
				} else 
				if (retDepend < 0) {
					// 自然に依存レジスタが潰された、よって何もしない
					if (bdebug) std::cout << "\t\tNEED TO DeLINK: " << pCb->at(h)->GetCode() << std::endl;
					if (pCb->at(h)->GetCoupleIns() == nullptr) {	// this instruction is not LDL
						pCb->at(h)->SetCoupleIns(dlnk);
					}
					pCb->AddOpeCode(dlnk, h+1);
					//delete dlnk;
					break;
				} else {
					if (bdebug) std::cout << "\t\tNO CARE : " << pCb->at(h)->GetCode() << std::endl;
				}
			}
			if (h >= pCb->GetInstructionNum()) {
				if (bdebug) std::cout << "Last Append" << std::endl;
				pCb->AddOpeCode(dlnk);
			}
        }
        while(nDependFlag) {
            std::vector<UI32> vReg;
            for (UI32 r = 0; r < (IsWReg ? 64 : 32 ); r++) {
		        if ((depreg & ((UI64)1 << r)) == 0) continue;
                vReg.push_back(r);
            }		        
            // Generate random instruction to overwrite PSW
		    IInstruction* dlnk = GenOverwriteFlagIns(nDependFlag, vReg);
		    dlnk->AppendComment("Overwrite precision error!");
            UI32 nFlag = 0;
		    for (h = holdPos; h < pCb->GetInstructionNum(); h++) {
		   	    if ((pIns->GetForwardIns() != nullptr && pIns->GetForwardIns() == pCb->at(h)) ||
		   			(pIns->GetC2B1Ins() != nullptr && pIns->GetC2B1Ins() == pCb->at(h))) {
		   		    pCb->AddOpeCode(dlnk, h-1);
                    nDependFlag &= ~(dlnk->UpdateFlag());
		   		    break;
		   	    }
		   	    if(pCb->at(h)->InSequence()){
		   		    pCb->AddOpeCode(dlnk, h);
                    nDependFlag &= ~(dlnk->UpdateFlag());
		   		    break;
		   	    }

		   	    if ((nFlag = GetDepFlag (pCb->at(h))) & nDependFlag){
                    nDependFlag &= ~nFlag;
		   		    break;
		   	    }

		   	    SI32 retDepend = CheckDependFlag (pCb->at(h), nDependFlag); 
		   	    if (retDepend > 0) {
		   		    pCb->AddOpeCode(dlnk, h);
                    nDependFlag &= ~(dlnk->UpdateFlag());
		   		    break;
		   	    } else 
		   	    if (retDepend < 0) {
		   		    if (bdebug) std::cout << "\t\tNEED TO DeLINK: " << pCb->at(h)->GetCode() << std::endl;
		   		    //if (pCb->at(h)->GetCoupleIns() == nullptr) {	// this instruction is not LDL
		   			   // pCb->at(h)->SetCoupleIns(dlnk);
		   		    //}
		   		    //pCb->AddOpeCode(dlnk, h+1);
                    nDependFlag &= ~(pCb->at(h)->UpdateFlag());
		   		    break;
		   	    } else {
		   		    if (bdebug) std::cout << "\t\tNO CARE : " << pCb->at(h)->GetCode() << std::endl;
		   	    }
		    }
		    if (h >= pCb->GetInstructionNum()) {
		   	    if (bdebug) std::cout << "Last Append" << std::endl;
		   	    pCb->AddOpeCode(dlnk);
                nDependFlag &= ~(dlnk->UpdateFlag());
		    }
        }
	}	
}

void CBlockManager::RemoveMismatchReg(CCodeBlock *pCB) {
    UI32 nInsNum = pCB->GetInstructionNum();
    UI32 nValidRegList = ~m_nMismatchRegSet & 0xfffffffe; // Exclude r0
    UI32 nInValidRegList = m_nMismatchRegSet;

    UI32 msk_list12 = 0;
    bool bResult = true;

    // Generate valid register set that can replace mismatch register
#if 0
    for(UI32 r = 1; r < 32; r++) {
        if((1<<r) & m_nMismatchRegSet) {
            std::cout << "r" << r << "\t";
        }
    }
    std::cout << std::endl;
#endif

    if (m_nMismatchRegSet == 0) 
    	return;
 
    // Calculate msk for list12 operand
    msk_list12 = ConvertRegListToList12(m_nMismatchRegSet);
    msk_list12 = ~msk_list12;
    for(UI32 idx = 0; idx < nInsNum; idx++) {
        IInstruction *pIns = pCB->at(idx);
        bResult = true;
        // Replace general registers
        if(pIns->GetGrSrc() & m_nMismatchRegSet) {
          
            IOperand *pOpr;
            if(pIns->GetId() == INS_ID_PUSHSP) {
                std::vector<std::vector<UI32>> vReglist;
                std::vector<UI32> vReg;
                 for (UI32 i = 1; i < 32; i++) {
                    if((nValidRegList >> i) & 1) {
                        if (vReg.size() > 0 ) {
                            if (vReg.back() == i - 1) {
                                vReg.push_back(i);
                            } else {
                                vReglist.push_back(vReg);
                                vReg.clear();
                                vReg.push_back(i);
                            }
                        } else {
                            vReg.push_back(i);
                        }
                    }
                }
                UI32 pos = g_rnd.GetRange(0U, (UI32)vReglist.size()-1);
                vReg = vReglist[pos];
                UI32 rh = g_rnd.GetRange(0U, (UI32)vReg.size()-1);
                UI32 rt = g_rnd.GetRange(rh, (UI32)vReg.size()-1);
                bResult &= pIns->opr(0)->Replace(vReg[rh]);
                bResult &= pIns->opr(1)->Replace(vReg[rt]);
            } else {
                for(UI32 op = 0; op < pIns->GetOpNum(); op++) {
                    pOpr = pIns->opr(op);
                    if(pIns->GetMne() == "prepare" && pIns->opr(0) == pOpr){
                        // 1st operand of prepare is List12
                        UI32 list12 = (UI32)*pOpr;
                        // Remove all violated bits
                        list12 &= msk_list12;
                        if(pOpr->Replace(list12) == false) {
                            bResult &= false;
                        }
                    }

                    if(pOpr->Attr(IOperand::OPR_ATTR_GR) == false || pOpr->Attr(IOperand::OPR_ATTR_SRC) == false)
                        continue;

                    if((pOpr->GetGrSrc() & m_nMismatchRegSet) == 0) {
                        continue;
                    }
                    bResult &= pOpr->ReplaceIdxFromList(nValidRegList);
                }
            }
        }
        
        // Destination of LD instruction can be mismatch. In case this instruction belong to loop sequence, let replace it
        if(/*pIns->InLoop() && */pIns->Behavior(IInstruction::LOAD_MEMORY) && (pIns->GetGrDst() & ~m_nMismatchRegSet)) {
            IOperand *pOpr;
            if(pIns->GetId() == INS_ID_POPSP) {
                std::vector<UI32> vReg;
                for (UI32 i = 1; i < 32; i++) {
                    if((m_nMismatchRegSet >> i & 1)) {
                        vReg.push_back(i); 
                    }
                }
                
                UI32 rt = g_rnd.GetRange(0U, (UI32)vReg.size()-1);
                bResult &= pIns->opr(0)->Replace(vReg[0]);
                bResult &= pIns->opr(1)->Replace(vReg[rt]);
            }
            for(UI32 op = 0; op < pIns->GetOpNum(); op++) {
                pOpr = pIns->opr(op);
                if(pIns->GetMne() == "dispose" && pIns->opr(1) == pOpr){
                    // 2nd operand of dipose is List12
                    UI32 list12 = (UI32)*pOpr;
                    // Remove all violated bits
                    list12 &= ~msk_list12;
                    if(pOpr->Replace(list12) == false) {
                        bResult &= false;
                    }
                }
                /* Checked: RW operand of CAXI and STC.X should be matched register. Don't replace by this condition */
                if(pOpr->Attr(IOperand::OPR_ATTR_GR) && pOpr->Attr(IOperand::OPR_ATTR_SRC) == false && (pOpr->GetGrDst() & ~m_nMismatchRegSet)) {
                    bResult &= pOpr->ReplaceIdxFromList(nInValidRegList);
                }
            }
        }

		// Limitation. Does not generate disposej imm, list12, [reg]. reg belong to list12
		if(pIns->GetId() == INS_ID_DISPOSE_R3){
			IOperand *pOpr = pIns->opr(1);
			// 2nd operand of dipose is List12
            UI32 list12 = (UI32)*pOpr;
			list12 &= ~(1 << pIns->opr(2)->Idx());
			if(pOpr->Replace(list12) == false)
				pIns->opr(2)->Replace(g_rnd.GetRange(4, 19));

			pIns->AppendComment("Remove disposej reg in list12 ");
		}

        // Replace wide-register of FP-SIMD instruction
        if((pIns->Category(IInstruction::ICAT_FPU_S) && pIns->Category(IInstruction::ICAT_SIMD))) {
            IOperand *pOpr;
            for(UI32 op = 0; op < pIns->GetOpNum(); op++) {
                pOpr = pIns->opr(op);
                if(pIns->Behavior(IInstruction::LOAD_MEMORY) && pOpr->Attr(IOperand::OPR_ATTR_WR) && pOpr->Attr(IOperand::OPR_ATTR_DST)) {
                    if(((1 << pOpr->Idx()) & m_nMismatchRegSet) == 0){
                        bResult &= pOpr->ReplaceIdxFromList(nInValidRegList);
                    }
                }

                if(pOpr->Attr(IOperand::OPR_ATTR_WR) && pOpr->Attr(IOperand::OPR_ATTR_SRC)) {
                    if(pOpr->GetWrSrc() & m_nMismatchRegSet) {
                        bResult &= pOpr->ReplaceIdxFromList(nValidRegList);
                    }
                }
            }
        }
		// Replace same GRs/WRs in sourc and dest of STORE instruction
		if(pIns->Behavior(IInstruction::STORE_MEMORY) && pIns->GetId() != INS_ID_PUSHSP) {					
			IOperand *pOpr;
			UI32 regValBit = 0;
            for(UI32 op = 0; op < pIns->GetOpNum(); op++) {
                pOpr = pIns->opr(op);
				UI32 oldIdx = ((pOpr->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << pOpr->Idx());
				 if(pOpr->GetConstraint() == nullptr && oldIdx != 1) // bit 0
					 regValBit  |= oldIdx;
                // Checked same register: st.b r14,0x1180[r14]
                while(regValBit & pIns->GetConstraintBit()) {
					pOpr->ReplaceIdxFromList(nValidRegList);
					regValBit &= ~(oldIdx); // Clear old idx
					regValBit |= ((pOpr->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << pOpr->Idx()); // Set new idx
				}
            }
		}
        if(bResult == false)
            MSG_ERROR(0, "Can not replace resource of \"%s\"   \"%s\" \n", pIns->GetCode().c_str(), pIns->GetComment().c_str());
    }
}
// ■ 強制例外発生制御
// -------------------------------------------------------------
// ここでは指定された確率に基づいて、例外を起こすか起こさないかを決定する。
// また強制発生ための設定をしておく（方法は要因によって異なる）。
// 
// 命令実行時に例外を発生させるかどうかをランダムに選択させると、
// ロールバックなどにより１つの命令が複数回シミュレーションされた場合、その度に例外発生が分岐する。
// 前回のシミュレーション結果と異ならないような制御も必要になる（補正命令が積み重なる）。
// よって例外の発生判定はここで決定しておく。
//
void CBlockManager::PresetException(CCodeBlock* pCb, IException* pEx) {

	FROG_ASSERT(pCb);
	
	if (pEx == NULL) { // 例外が設定されていない場合
		return;
	}
	
	// Raise Exception
	UI32 jNum = pCb->GetInstructionNum();
	for (UI32 i = 0; i < jNum; i++) {
		IInstruction* pIns = pCb->at(i);
		std::string mne = pIns->GetMne();

        if (pIns->InSequence(IInstruction::IF_SEQ_DCU)) continue;

		if ((pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) && (pIns->GetRegulationTarget() == nullptr)) {
			
			IValConstraint* pVc = NULL;
	
			// MAE
			pVc = NULL;
			for (UI32 N=0; N< pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					break;
				}
				if (popr->Attr(IOperand::OPR_ATTR_SMEM) || popr->Attr(IOperand::OPR_ATTR_LMEM)) {
					if (((pVc = popr->GetConstraint()) != NULL) && pVc->m_nMsk /* バイトアクセスは対象外 */) {
						break;
					}
				}
				pVc = NULL;
			}
			if ((pVc != NULL) && pEx->RaiseException(IException::EXP_MAE) && mne != "switch") {
				#if !defined(NDEBUG)
				std::cout << "@MAE ---> " << pIns->GetCode() << std::endl;
				#endif
				pVc->Unalign();
				continue;
			}

			// MDP
			pVc = NULL;
			for (UI32 N=0; N < pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					break;
				}
				if ((pVc = popr->GetConstraint()) == NULL) {
					continue;
				}
				if (pVc->GetType(IValConstraint::STORE_MEMORY) || pVc->GetType(IValConstraint::LOAD_MEMORY)) {
					break;
				}
				pVc = NULL;	
			}
			// tableロードは除外(MDP発生する可能性大だけど救出される)
			if (pEx->RaiseException(IException::EXP_MDP) && pVc != NULL && 
				mne != "switch" && mne != "callt" && mne != "hvcall" && mne != "syscall" && mne != "pref") { // "switch"命令はとりあえず除外する, pref=例外非発生
				#if !defined(NDEBUG)
				std::cout << "@MDP ---> " << pIns->GetCode() << std::endl;
				#endif
				pVc->SetType(IValConstraint::RAISE_MERROR);
			}
		} 
	}
}


// ■ Jarl制御（E3V5 Internal function)
// -------------------------------------------------------------
// Jarl命令において、ジャンプ先を示すオペランドにラベルを付加しておく
// PC相対ジャンプ、絶対アドレスジャンプの判断はオペランド属性を判定し
// リンク時にアドレスが解決され、オペランドは即値にリプレイスされる。
void CBlockManager::LabelingJarl(CCodeBlock* pCb, std::string contextStr) {
	// JARL補正
	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		IInstruction* pIns = pCb->at(i);
		if (pIns->GetMne() == std::string("jarl") && pIns->GetValid() == false) {
			pIns->Fix();
			UI32 lp = pIns->opr(1)->Idx(); // リンクレジスタに使うインデックス取得
			std::stringstream ss;
			ss << ("function_") << lp;
			//Limitation JARL32 can not jump across section
			/*if (pIns->GetId() == INS_ID_JARLSD22) {
				pIns->opr(0)->SetLabel(ss.str().data());
				// PCズレの依存関係を切る
				IInstruction* shift  = MOV32(g_rnd.Get(), lp);
				shift->opr(1)->SetAttr(IOperand::OPR_ATTR_DST);
				pCb->AddOpeCode(shift, i+1);
			}else*/
			if (pIns->opr(0)->Attr(IOperand::OPR_ATTR_GR)) {
				pIns->SetTaken(true);
				// Insert (MOVL)
				UI32 r = pIns->opr(0)->Idx();
				if (r == 0) {
					pIns->opr(0)->Replace(31);
					r = 31;
				}
				// PCズレの依存関係を切る
				IInstruction* shift  = MOV32(g_rnd.Get(), lp);
				shift->opr(1)->SetAttr(IOperand::OPR_ATTR_DST);
				pCb->AddOpeCode(shift, i+1);
				
				IInstruction* insert = MOV32P(ss.str().data(), r);
				insert->opr(1)->SetAttr(IOperand::OPR_ATTR_DST);
				pIns->DirMoveTo(insert);
				pIns->SetJumpTargetLabel(ss.str().data());
				insert->SetRegulationTarget(pIns);
				pIns->SetJumpTargetLabel(ss.str().data());
				pCb->AddOpeCode(insert, i);
				i++; // 追加分進める
			}
		}
	}
}


/**
 * @brief  指定ブロックの指定SWITCH命令にテーブルを準備する。
 * @param  pCb  
 * @param  i    
 * @return bool 
 */
bool CBlockManager::MakeSwitchTable(CCodeBlock* pCb, UI32 i) {

	UI32 num = pCb->GetInstructionNum();
	if (num <= i) {
		return false;
	}
	
	IInstruction* pIns = pCb->at(i);
	UI32 next = i + 1;
	
	// filter MNE is Switch
	if (pIns->GetMne() != std::string("switch")) {
		return false;
	}
	pIns->SetSequence();
	
	// SWITCH以後の命令数を取得（ジャンプ先の候補となる）
	UI32 remain = pCb->GetInstructionNum() - next;
	
	// テーブル数の定義
	const UI32 tableMin = 1;		// 最小テーブルエントリ(1〜)
	const UI32 tableMax = 5;		// 最大テーブルエントリ 
		
	FROG_ASSERT((tableMin != 0) && (tableMin <= tableMax));
	
	// テーブル数を決定（tableMin - tableMaxのランダム）	
	UI32 tableEntry = g_rnd.GetRange((UI32)tableMin, (UI32)tableMax);
	
	// 飛び先アドレスを計算する（テーブルデータに使用）
	std::vector< std::pair<UI32,std::string> > dstInsOffset;
	UI32 skipIns = 0;
	for (UI32 j = 0; j < remain; j++) {
		IInstruction* nextJ = pCb->at(next + j);
		UI32 len = nextJ->GetLen();			// 補正前状態でのswitchの次の命令の長さ
		std::string mne = nextJ->GetMne();
		UI32 InsID = nextJ->GetId();
		if ((mne == ".hword") || (mne == ".word") || (mne == "switch")) {
			nextJ->SetSequence();
			skipIns += len;
			continue;
		}

		if(InsID == INS_ID_JARLSD22 || InsID == INS_ID_JARL || InsID == INS_ID_JARLD22 || InsID == INS_ID_JRSD22 || InsID == INS_ID_JRD32 || InsID == INS_ID_JMP || InsID == INS_ID_JMPD32 || InsID == INS_ID_DISPOSE_R3)
			break;

		// SWITCHテーブルの飛び先にブランチがあるとき全てNOT-TAKEN制御とする
		// テーブルの飛び先列が分断されるのを防ぐ		
		nextJ->SetTaken(false);

		if(nextJ->InSequence() || nextJ->InLoop() || nextJ->GetComment() == "Overwrite precision error!"){
			nextJ->SetSequence();
			skipIns += len;
			continue;
		}

		if (mne == "loop") {
			if(nextJ->InSequence()){
				nextJ->SetSequence();
				skipIns += len;
				continue;
			}
		}

		nextJ->SetSequence();				// 一連の命令列にする

		dstInsOffset.push_back (std::pair<UI32,std::string>(skipIns,mne));
		if (tableEntry <= dstInsOffset.size()) {
			break; // エントリ分飛び先が確保できた。
		}
		skipIns += len;
	}

	// SWITCH以後の命令（ジャンプ先の候補）がないときNOPを追加しておく
	if (dstInsOffset.size() == 0) {
		pCb->AddOpeCode (new CIns_115_nop(), next); // switch直後にnop挿入
		dstInsOffset.push_back(std::pair<UI32,std::string>(0,"nop"));
	}
	
	// 飛び先が残りの命令に満たない場合（飛び先重複）
	for (UI32 j = dstInsOffset.size(); j < tableEntry; j++) {
		// Destination shuffle
		std::random_shuffle(dstInsOffset.begin(), dstInsOffset.end(), g_rnd);
		dstInsOffset.push_back (dstInsOffset.back());
	}
	
	// Destination shuffle
	std::random_shuffle(dstInsOffset.begin(), dstInsOffset.end(), g_rnd);
	
	// GRの値制約（ロードアドレス制約ではない）！
	// オペランドの汎用レジスタの値がテーブルエントリ数内にあること
	pIns->opr(0)->SetConstraint(new IValConstraint(tableMin-1, tableEntry-1, 0, 2, 0));
	pIns->Fix();
	
	for (UI32 j = 0; j < tableEntry; j++) {
		// テーブル埋め込み
		IInstruction* pHword = new CIns_456__short(new COprImm(tableEntry + ((dstInsOffset.at(j).first)/2) ));
		pHword->SetSequence(true);
		std::stringstream ss;
		ss << " [" << std::setw(2) << std::setfill('0') << std::dec << j << "] Jump to  ";
		std::string comment = ss.str();
		comment += dstInsOffset.at(j).second;
		pHword->AppendComment(comment.data());
		pCb->AddOpeCode (pHword, ++i);
	}
	return true;
}

// ■ Switch制御（E3V5 Internal function)
// -------------------------------------------------------------
// Switch命令でロードされるテーブルを準備する
// ・処理順序から遡って処理しなければならない、飛び先にswitchがあると意図外のアドレスなる。
// ・1switchを処理する毎に命令(テーブルデータ）が挿入されるため全体の命令数が増加する。 
// 
bool CBlockManager::SwitchPresetTable(CCodeBlock* pCb) {

	std::set<IInstruction*> ipSet; // 処理済みswitchを記憶する
	
	for (UI32 i = pCb->GetInstructionNum(); i > 0 ; i--) {
		
		UI32 f = i - 1;
		
		// filter MNE is Switch
		if (pCb->at(f)->GetMne() != std::string("switch")) {
			continue; // 対象外
		}

		if (ipSet.find(pCb->at(f)) != ipSet.end()) {
			continue; // 処理済み
		}

		if (MakeSwitchTable(pCb, f) != true) {
			return false;
		}
		ipSet.insert(pCb->at(f));
		// 命令は増加するが＋側に追加していくためGetInstructionNumしなおす必要はない。
	}
	
	return true;
}


// ■ ブロックチェーン
// -------------------------------------------------------------
// コードブロック間の処理を繋ぐ命令を追加する。
// いくつかのジャンプシーケンスをランダムで選択し、Taken/NotTakenをケアしないブランチ命令も挿入。
CCodeBlock* CBlockManager::ChainBlock(CCodeBlock* src, CCodeBlock* dst) {

	UI32 reg1 = g_rnd.GetRange(4U,19U);
	
	IInstruction *pMov = MOV32P(dst->GetLabel().c_str(), reg1);
	IInstruction* p;	
	if (reg1 >=4 && reg1 <= 19 && m_nrmSet.GetWeight(65) && src->IsRegulation() && ((g_rnd.Get() & 1) != 0)) {
		NewINS( src,  pMov);
		p = new CIns_65_dispose();
		p->opr(1)->SetConstraint(new CLoadAddressSelector(0xFEE00000, 0xFEEFFFFF/*<-Load領域が無いときにしかたなくアクセスする*/, 0x00, 4));
		if (p->opr(2)->Replace(reg1) != true) {
			FROG_ASSERT(0);
		}

        if(p->GetGrDst() & ~m_nMismatchRegSet) {
            IOperand *pOpr = p->opr(1);
            // 2nd operand of dipose is List12
            UI32 list12 = (UI32)*pOpr;
            // Remove all violated bits
            list12 &= ConvertRegListToList12(m_nMismatchRegSet);
            pOpr->Replace(list12);
        }

		p->Note("-> Jump Next Block");
		p->SetChain();
		p->SetJumpTargetLabel(dst->GetLabel().c_str());
		pMov->SetRegulationTarget(p);
		NewINS( src,  p );
	} else if ((g_rnd.Get() & 1) != 0){
		NewINS( src,  pMov);
		p = JMP32(reg1);
		p->SetJumpTargetLabel(dst->GetLabel().c_str());
		p->Note("-> Jump Next Block");
		p->SetChain();
		pMov->SetRegulationTarget(p);
		NewINS( src, p );
	} else{
		p = m_nrmSet.CreateIns(INS_ID_JMPD32)->Fix();
		while (((m_nMismatchRegSet >> p->opr(0)->Idx()) & 1) || p->opr(0)->Idx() == 0){
			p->opr(0)->Replace(g_rnd.GetRange(1, 31));
        }
		p->opr(0)->SetConstraint(new ILoadConstraint(0x00000000, 0x07FFFFFF, 0x01, 2, (1<<IValConstraint::FETCH) ));
		p->SetJumpTargetLabel(dst->GetLabel().c_str());
		p->opr(0)->SetLabel(dst->GetLabel().c_str());
		p->SetTaken(true);
		p->Note("-> Jump Next Block");
		p->SetChain();
		NewINS( src, p );
	}
	
	// Dead code insert
	 AddDeadCode(src);
	return dst;
}


CCodeBlock* CBlockManager::MixBlock(CCodeBlock* src, CCodeBlock* dst) {
	
	/* src CodeBlockコンテナは削除され、中身のInsはdstに移る */
	dst->Interlace(src);
	
	return dst;
}

void CBlockManager::ParseUserCode(std::vector<std::string> &vUcBody, CCodeBlock* pCB) {
	static const char* cond[] = {
					"V",	"C/L",	"Z",	"NH",	"S/N",	"T",	"LT",	"LE",
					"NV",	"NC/NL","NZ",	"H",	"NS/P",	"SA",	"GE",	"GT"
				};
	static const char* fcond[] = {
					"F",	"UN",	"EQ",	"UEQ",	"OLT",	"ULT",	"OLE",	"ULE",
					"SF",	"NGLE",	"SEQ",	"NGL",	"LT",	"NGE",	"LE",	"NGT"
				};
	auto ParseBCondIns = [&] (std::string &mne) {
		UI16 cond = 0x0;
		if (mne == "bge") cond = 0x1110;
		else if (mne.find("bgt") == 0) cond = 0x1111;
		else if (mne.find("ble") == 0) cond = 0x0111;
		else if (mne.find("blt") == 0) cond = 0x0110;
		else if (mne.find("bh") == 0) cond = 0x1011;
		else if (mne.find("bl") == 0) cond = 0x0001;
		else if (mne.find("bnh") == 0) cond = 0x0011;
		else if (mne.find("bnl") == 0) cond = 0x1001;
		else if (mne.find("be") == 0) cond = 0x0010;
		else if (mne.find("bne") == 0) cond = 0x1010;
		else if (mne.find("bc") == 0) cond = 0x0001;
		else if (mne.find("bf") == 0) cond = 0x1010;
		else if (mne.find("bn") == 0) cond = 0x0100;
		else if (mne.find("bnc") == 0)cond = 0x1001;
		else if (mne.find("bnv") == 0)cond = 0x1000;
		else if (mne.find("bnz") == 0)cond = 0x1010;
		else if (mne.find("bp") == 0) cond = 0x1100;
		else if (mne.find("br") == 0) cond = 0x0101;
		else if (mne.find("bsa") == 0) cond = 0x1101;
		else if (mne.find("bt") == 0) cond = 0x0010;
		else if (mne.find("bv") == 0) cond = 0x0000;
		else if (mne.find("bz") == 0) cond = 0x0010;
		else	cond = 0x0;
		 
		return cond;
	};

	auto Split = [] (const std::string &src, const std::string &key) {
		std::vector <std::string> v;
		std::string str = src;
		std::string::size_type index = 0;
		while(index < str.length()){
			std::string::size_type oldindex = index;
			index = str.find( key, index);
			if(index != std::string::npos){
				std::string item = str.substr(oldindex, index - oldindex);
				v.push_back(CToolFnc::Trim(item));
			}else{
				std::string item = str.substr(oldindex);
				v.push_back(CToolFnc::Trim(item));
				break;
			}
			index += key.length();
		}
		return v;
    };

	auto ConvertCondition = [] (std::string cond, const char** condList) -> std::string {
		std::string strCond;
		UI32 i;
		// Check whether 1st operand is condition name of condition index
		for(i = 0; i < 16; i++) {
			if(condList[i] == cond) {
				strCond = cond;
				break;
			}
		}
		// Convert from condition index to name
		if(i == 16){
			UI32 cc = CToolFnc::AtoI(cond.c_str());
			strCond = condList[cc];
		}
		return strCond;
	};

	std::vector <std::string>::iterator itrUcBody;
	std::string::size_type				nMatchPos;
	std::string							code, label;
	IInstruction*						pUserIns;
	for(itrUcBody = vUcBody.begin(); itrUcBody < vUcBody.end(); itrUcBody++) {
		std::string &code = *itrUcBody;

		// Check whether instruction is a label
		if((nMatchPos = code.rfind(":")) != std::string::npos) {
			label = CToolFnc::Trim(code.substr(0, nMatchPos));
			continue;
		}
		
		// Find the first space or tab character
		std::string::size_type pos;
		if((pos = code.find(" ")) == std::string::npos){
			if((pos = code.find("\t")) == std::string::npos)
				pos = code.size();
		} else {
			std::string::size_type tab_pos = code.find("\t");
			if(tab_pos != std::string::npos && tab_pos < pos)
				pos = tab_pos;
		}
		std::string mne = CToolFnc::Trim(code.substr(0, pos));
		std::string oprs = CToolFnc::Trim(code.substr(pos));
		UI32 ret;

		//[FROG]TODO: Support jump with absolute address and loop with label
		// Create UserInstruction, then insert to code block.
		if(mne == "movl"){
			std::string::size_type comma = oprs.find(",");
			std::string label = CToolFnc::Trim(oprs.substr(0, comma));
			UI32 reg = CToolFnc::AtoI(oprs.substr(oprs.find("r", comma) + 1).c_str());
			pUserIns = (IInstruction*) new UserMovlIns(label, reg);
		} else if(mne.find("jarl22") == 0) {
			std::string::size_type comma = oprs.find(",");
			std::string label = CToolFnc::Trim(oprs.substr(0, comma));
			UI32 reg = CToolFnc::AtoI(oprs.substr(oprs.find("r", comma) + 1).c_str());
			pUserIns = (IInstruction*) new UserJarl22Ins(label, reg);
		} else if (mne.find("jarl32") == 0) {
			std::string::size_type comma = oprs.find(",");
			std::string label = CToolFnc::Trim(oprs.substr(0, comma));
			UI32 reg = CToolFnc::AtoI(oprs.substr(oprs.find("r", comma) + 1).c_str());
			pUserIns = (IInstruction*) new UserJarl32Ins(label, reg);
		} else if (mne.find("jr22") == 0) {
			pUserIns = (IInstruction*) new UserJr22Ins(oprs);
		} else if (mne.find("jr32") == 0) {
			pUserIns = (IInstruction*) new UserJr32Ins(oprs);
		} else if((ret = ParseBCondIns(mne)) != 0x0){
			UI16 cond = ret;
			std::string::size_type pos17;
			if((pos17 = mne.find("17")) == std::string::npos) { //Disp9
				pUserIns = (IInstruction*) new UserBCond9Ins(mne, oprs, cond);
			} else { // Disp17
				pUserIns = (IInstruction*) new UserBCond17Ins(mne.substr(0, pos17), oprs, cond);
			}
		} else {
			if(mne.find("ldsr") == 0 || mne.find("ldtc.sr") == 0 || mne.find("ldvc.sr") == 0) {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = vOpr[0] + ", sr" + vOpr[1] + ", sel" + (vOpr.size() == 3 ? vOpr[2] : "0");
			} else
			if(mne.find("stsr") == 0 || mne.find("sttc.sr") == 0 || mne.find("stvc.sr") == 0) {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = "sr" + vOpr[0] + "," + vOpr[1] + ", sel" + (vOpr.size() == 3 ? vOpr[2] : "0");
			} else
			if(mne == "pushsp" || mne == "popsp" || mne == "dbpush") { // Replace separator among 2 registers "," (GNU format) to "-" (FROG Asm format)
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = vOpr[0] + "-" + vOpr[1];
			} else
			if(mne == "adf" || mne == "cmov" || mne == "sasf" || mne == "sbf" || mne == "setf") {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
			
				oprs = ConvertCondition(vOpr[0], &cond[0]) + ", " + vOpr[1];
				if(vOpr.size() == 4)
					oprs += ", " + vOpr[2] + ", " + vOpr[3];
			} else 
			if (mne.find("cmpf") == 0) {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = ConvertCondition(vOpr[0], &fcond[0]) + ", " + vOpr[1] + ", " + vOpr[2] + ", " + vOpr[3];
			}

			pUserIns = (IInstruction*) new UserInstruction(mne + " " + oprs);
			if(label.empty() == false){
				pUserIns->SetLabel(label);
				label = "";
			}
		}
		pCB->AddOpeCode(pUserIns);
	}
}

void CBlockManager::GetUserHanlderBody(const std::string &strHandler, CCodeBlock *pCB) {
	std::vector <std::string>			vUcBody;
	std::vector <std::string>::iterator itrUcBody;
	bool								bFound = false;
	const std::string key(".section");

	g_usf->GetUserCodeBody("uc_handler", vUcBody);
	itrUcBody = vUcBody.begin();
	while(itrUcBody < vUcBody.end()) {
		std::string &code = *itrUcBody;
		std::string::size_type pos;

		if((pos = code.find(key)) != std::string::npos){
			std::string::size_type next_dot = code.find(".", pos + key.size());
			pos = code.find(",");
			code = CToolFnc::Trim(code.substr(next_dot + 1, pos - (next_dot + 1)));
			if(code == strHandler)
				bFound = true;
			else
				bFound = false;
			itrUcBody = vUcBody.erase(itrUcBody);
			continue;
		}
		
		if(!bFound)
			itrUcBody = vUcBody.erase(itrUcBody);
		else
			itrUcBody++;
	}
	ParseUserCode(vUcBody, pCB); // [FROG]TODO: Infinite loop when no code in user handler
}

void CBlockManager::GetUserHandler(const std::string &strContext, std::bitset<BSV_VECTOR_NUM> *pBs) {
	std::vector<std::string> vHandler = g_usf->GetUserHandler(strContext);
	const char* handlerArr[] = {"reset", "syserr", "hvtrap", "fetrap", "trap0", "trap1", "rie", "fpe", "ucpop", "mp",
							"pie", "debug", "mae", "dummy", "fenmi", "feint", "eiint", "eiint000", "eiint001", "eiint002",
							"eiint003", "eiint004", "eiint005", "eiint006", "eiint007", "eiint008", "eiint009",
							"eiint010", "eiint011", "eiint012", "eiint013", "eiint014", "eiint015", NULL
	};

	std::vector<std::string>::iterator itr;
	for(itr = vHandler.begin(); itr < vHandler.end(); itr++){
		std::string &strHandler = *itr;
		UI32 idx = 0;
		while(handlerArr[idx] != NULL){
			if(strcmp(handlerArr[idx], strHandler.c_str()) == 0)
				pBs->set(idx);
			idx++;
		}
	}
}

void CBlockManager::PresetFixedMPU(CCodeBlock *pCB) {
	auto SetFixedMPU = [] (IInstruction *pIns) {
		if (pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) {
			IValConstraint* pVc = NULL;
			for (UI32 N=0; N < pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					break;
				}
				if ((pVc = popr->GetConstraint()) == NULL) {
					continue;
				}
				if (pVc->GetType(IValConstraint::STORE_MEMORY) || pVc->GetType(IValConstraint::LOAD_MEMORY)) {
					pVc->SetType(IValConstraint::FIXED_MPU);
				}
			}
		}
	};

	for (UI32 nIdx = 0; nIdx < pCB->GetInstructionNum(); nIdx++) {
		IInstruction *pIns = pCB->at(nIdx);
		UI32 insid = pIns->GetId();
		if(insid == INS_CID_MPU_UPDATE)
			break;
		if(pIns->IsComplex()) {
			ComplexInstruction* pCi = static_cast<ComplexInstruction*>(pIns);
			IInstruction *p = NULL;
			for(UI32 n = 0; n < pCi->size(); n++) {
				p = (*pCi)[n];
				SetFixedMPU(p);
			}
		} else {
			SetFixedMPU(pIns);
		}
	}
}

/**
* @brief  Add code to change privilege inside code block pCB
* @param	pCB	pointer to code block
*/
void CBlockManager::ChangePrivilege(CCodeBlock* pCB, UI32 reg, TBlockConfig* pCfg) {
	// TRAP: vector5 - EI exception level
	// FETRAP : vector 4 - FE exception level
	// SYSCALL : vector 8 - EI exception level

	UI32 chSVToUM = 0x1e;
	UI32 chUMToSV = 0x1d;
	UI32 mask = 0x1f;   //vector5 
	UI32 icReg = 13;	//EIIC
	UI32 pswReg = 1;	//EIPSW

	std::string label = pCB->GetLabel();

	if (label.find("syscall") != std::string::npos) {
		mask = 0x00ff;   //vector8
        chSVToUM = 0xff;
	} else if (label.find("fe") != std::string::npos) {
		icReg = 14;    //FEIC
		pswReg = 3;    //FEPSW
		chSVToUM = 0xe;
		chUMToSV = 0xd;
		mask = 0xf;   //vector4 
	}

	auto AddIns = [](CCodeBlock* pCb, IInstruction* pIns){
		pCb->AddOpeCode(pIns);
		pIns->AppendComment("Changing privilege");
	};

	// Check XXIC cause code to change privilege UM->SV
	// _change_UM_to_SV:
	AddIns (pCB, STSR( icReg, reg, 0) );
	AddIns (pCB, ANDI(mask, reg, reg) );
	AddIns (pCB, SATSUBI(chUMToSV,reg,reg) );
	AddIns (pCB, BNZ9P( pCB->GetLabel() + "_change_SV_to_UM") );
	AddIns (pCB, STSR( pswReg, reg, 0) );
	AddIns (pCB, HSW(reg, reg));
	AddIns (pCB, ORI(0x4000, reg, reg));		// Make sure bit#15 (swap<PSW>.UM) is 1.
	AddIns (pCB, SATSUBI(0x4000, reg, reg));
	AddIns (pCB, HSW(reg, reg));
	AddIns (pCB, LDSR(reg , pswReg, 0) );
	AddIns (pCB, JR22P( pCB->GetLabel() + "_change_privelge_end") );

	// Check XXIC cause code to change privilege SV->UM
	// _change_SV_to_UM:
	AddIns (pCB, STSR( icReg, reg, 0)->SetLabel(pCB->GetLabel() + "_change_SV_to_UM") );
	AddIns (pCB, ANDI(mask, reg, reg) );
	AddIns (pCB, SATSUBI(chSVToUM,reg,reg) );
	AddIns (pCB, BNZ9P( pCB->GetLabel() + "_change_privelge_end") );
	// Update PSW to change SV->UM
	AddIns (pCB, STSR( pswReg, reg, 0) );
	AddIns (pCB, HSW(reg, reg));
	AddIns (pCB, ORI(0x4000, reg, reg));
	AddIns (pCB, HSW(reg, reg));
	AddIns (pCB, LDSR(reg , pswReg, 0) );
	
	// _change_privelge_end:
    if (label.find("syscall") != std::string::npos) {
        AddIns(pCB, STSR(28, m_nHandlerReg, 0));
    }
	AddIns (pCB, NOP()->SetLabel(pCB->GetLabel() + "_change_privelge_end"));
}

void CBlockManager::GenerateRandomCode(CCodeBlock* pCB, UI32 num, TBlockConfig* pCfg, const std::string &name) {
	CCodeBlock* pCodeBlock;
	UI32 nFixedReg1 = 0, nFixedReg2 = 0;
	
	// Do not support generate random instruction in handler.
	if(name != "callt" && name != "syscall") {
		pCB->EnableRegulation(false);
		return;
	}

	switch (g_cfg->m_nBlockMix) {
	case 0:		// free
		pCodeBlock = GenerateGrBlock(0, num, 0, pCfg->pInsSet);
		break;
		
	case 1:		// focus 1 reg
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCodeBlock = GenerateGrBlock(0, num, nFixedReg1, pCfg->pInsSet);
		break;

	case 2:		// mix 2 reg interlaced
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCodeBlock = GenerateGrBlock(0, num/2, nFixedReg1, pCfg->pInsSet);
		nFixedReg2 = g_rnd.GetRange(1U, 31U);
		pCodeBlock = this->MixBlock (GenerateGrBlock(0, num/2, nFixedReg2, pCfg->pInsSet), pCodeBlock);
		break;
		
	default:	// free generation
		pCodeBlock = GenerateGrBlock(pCfg->N, pCfg->InsNum, 0, pCfg->pInsSet);
		break;
	}

	for(UI32 i = 0; i < pCodeBlock->GetInstructionNum(); i++) {
		IInstruction *pIns = pCodeBlock->at(i);
		const std::string &mne = pIns->GetMne();
		if(pIns->IsComplex() && (name == "callt" || name == "syscall")){
				continue;
		}

		// Limitation 2: Did not created a pure callt, syscall function
		if(mne == "callt" || mne == "syscall" || mne == "ei" || mne == "di" || mne == "halt") {
			continue;
		}

                // Limitation: Did not create ldm.gsr, ldm.mp in callt and syscall function
                // ldm.gsr override SCBP, CTBP. the value is different when syscall/callt is executed
                // ldm.mp: other insturction can overwrite memory of ldm.mp which It is preset for common area.
                // However this case has already been supported in New Frog
		if(mne == "ldm.gsr" || mne == "ldm.mp") {
			continue;
		}

		if(mne == "ctret" && (name == "callt" || name == "syscall")) {
			continue;
		}

        if (mne == "feret" && name == "syscall") {
            continue;
        }

        if (mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr") {
            UI32 sr = (UI32)*(pIns->opr(1));
            if (name == "syscall" && ((sr == 32 * 0 + 0) /*EIPC*/|| (sr == 32 * 0 + 1) /*EIPSW*/ || (sr == 32 * 0 + 13) /*EIIC*/ || (sr == 32 * 0 + 28) /*EIWR*/ || (sr == 32 * 0 + 5) /*PSW*/)) {
                continue;
            }
            if (name == "callt" && (sr == 32 * 0 + 16) /*CTPC*/) {           
                continue;
            }
        }

		// Remove FXU instruction.
		if(pIns->Category(IInstruction::ICAT_SIMD)) {
			continue;
		}

		// Remove FPU instruction.
		if(pIns->Category(IInstruction::ICAT_FPU_S) || pIns->Category(IInstruction::ICAT_FPU_D)) {
			continue;
		}

		// Limitation 3: Did not back up FE resource for SYSCALL, CALLT
		if((name == "syscall" || name == "callt") && (mne.find("trap") != std::string::npos)) {
			continue;
		}

		if(mne == "resbank")
			continue;

		if(name.find("hvtrap") != std::string::npos) {
			// CU0-2 will be 0 in HVTRAP handler.
			if(pIns->Category(IInstruction::ICAT_FPU_S) || pIns->Category(IInstruction::ICAT_FPU_D) || pIns->Category(IInstruction::ICAT_SIMD)) {
				continue;
			} else if (mne == "jarl" || mne.find("trap") != std::string::npos || mne == "syscall" || mne == "callt") {
				continue;
			} else if (mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr") {
				continue;
			} else if (mne == "stsr" || mne == "sttc.sr" || mne == "stvc.sr") {
				continue;
			}
		}
		pCodeBlock->Erase(pIns);
		pCB->AddOpeCode(pIns);
	}

	delete pCodeBlock;
	// Expand Sequential Instruction
	ExpandSequentialInstruction(pCB);

	// Support bias register to increase register dependance
	IncRegisterDependance(pCB, nFixedReg1, nFixedReg2);

	// 静的な解析からパタンの整合性をとる
	// Add constraint attribute to generate fixed MPU memories
	//PresetFixedMPU(pCB);

	// 複合命令を展開する
	ExpandComplexInstruction(pCB, pCfg);

	// Replace mismatched register that was used as src
    RemoveMismatchReg(pCB);

	// Check whether C2B1 is combined by random generation
	CombineC2B1(pCB);

	// Adjust LDSR for update specified bit
	UpdateAccessSysReg(pCB, pCfg);

	// 伝搬レジスタを切断する(#10198)
	RemoveRegDependance(pCB);
	
	// R-Type補正（汎用レジスタの重複（Base = {Step/Index}）を除外）
	RTypeVerify(pCB);
	
	// JARL補正（Jarlの飛び先を設定する=ラベル化）
	LabelingJarl(pCB, GetMContext(pCfg));

	MakeLoopSequence(pCB);

	// Switch補正（SWITCHテーブルの挿入）
	// テーブルとSwitchジャンプ先を結びつけるので
	// これ以後、命令を挿入する場合は注意する 
	SwitchPresetTable(pCB);
	
	pCB->SetStatistics(true);
	
	ChainBcondSequence(pCB);// Labelが付いた後

	// Limitation 3: Did not back up FE resource for SYSCALL, CALLT
	if(name != "callt" && name != "syscall")
		PresetException(pCB, g_exp.get());

	// Adjust 1st instruction.
	std::vector<UI32> vConstraintReg;
	IInstruction *pIns = pCB->at(0);
	UI32 constReg = pIns->GetConstraintBit();
	for(UI32 n = 0; n < 32; n++) {
		if(((1 << n) & constReg) != 0x0)
			vConstraintReg.push_back(n);
	}
	m_vHandlerConstraintReg.push_back(std::make_pair(pCB->GetHandlerAddress(), vConstraintReg));

	for(SI32 n = pCB->GetInstructionNum() - 1; n >= 0; n--) {
		IInstruction *pIns = pCB->at(n);
		IInstruction *pTarget = pIns->GetRegulationTarget();
		if(pTarget == NULL)
			pIns->SetForcedAdjust(true);
		else
			pTarget->SetForcedAdjust(false); // The target was already adjusted.
	}

	// Reserve deassert label for MP handler in case of MDP at reference table access. There are two cases:
	//	1. There is no EIINT request (including EITBL) at 1st instruction.
	//		1.1 If level(MDP) >= level(EIINT): EIINT will not be requested in MDP or exception that occur on MDP handler.
	//		-> Do not need to reserve
	//		1.2 level(MDP) < level(EIINT): Need to reserve. Because there is no pending EIINT at this instruction, so there is no impact to randomization.
	//	2. EIINT was requested at 1st instruction.
	//		2.1 If MDP at EIINT table, this requested will be deleted.
	//		2.2 If no MDP at EIINT table, it is need to clear after that.
	//if(name.find("mp") != std::string::npos) {
	//	UI32 MDPIdx = ADR_VECTOR_MPUMMU >> 4;
	//	UI32 EIINTIdx = ADR_VECTOR_EIINT000 >> 4;
	//	if(m_arrHandlerOrder[MDPIdx] < m_arrHandlerOrder[EIINTIdx]) {
	//		IInstruction *pIns = pCB->at(0);
	//		IDirective	*pDir;
	//		UI32 n = 0;
	//		while((pDir = pIns->GetDirective(n)) != nullptr) {
	//			CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
	//			if(pAs->m_name == "eiint" || pAs->m_name == "eitbl" || pAs->m_name == "gmeiint" || pAs->m_name == "gmeitbl") {
	//				break;
	//			}
	//			n++;
	//		}
	//		if(pDir == NULL) {
	//			CAsyncLabel *pAsyncLabel = new CAsyncLabel("eitbl", GetTContext(pCfg), 0xfffd, false);
	//			pAsyncLabel->m_nEventId = IException::EXP_EITBL;
	//			pIns->SetDirective(pAsyncLabel);
	//		}
	//		pIns = NOP();
	//		CAsyncLabel *pAsyncLabel = new CAsyncLabel("eiint", GetTContext(pCfg), 0xfffe, false);
	//		pAsyncLabel->m_nEventId = IException::EXP_EIINT;
	//		pIns->SetDirective(pAsyncLabel);
	//		pAsyncLabel = new CAsyncLabel("eitbl", GetTContext(pCfg), 0xffff, false);
	//		pAsyncLabel->m_nEventId = IException::EXP_EITBL;
	//		pIns->SetDirective(pAsyncLabel);
	//		pCB->AddOpeCode(pIns);
	//	}
	//}

	// Add position for restoring resources
	pCB->AddOpeCode(NOP()->SetLabel(std::string(pCB->GetLabel()) + "_recovery_resource"));
	
	return;
}

/**
 * @brief	Move regulation at the beginning of handler to random code block
 */
void CBlockManager::FrontRegulationHandler() {
	// Adjust handler
	std::vector<INode*> &vHB = g_asf->GetHandlerBlock();
	std::vector<INode*>::iterator itr;
	std::vector<std::pair<UI32, std::vector<std::pair<UI32, UI32>>>> vRegulationIns;

	// Register is updated in vector block
	UI32 reg = m_nHandlerReg;

	// Collect all adjustment code in handler
	for(itr = vHB.begin(); itr != vHB.end(); itr++) {
		std::vector<std::pair<UI32, UI32>> vRegIns;
		CCodeBlock* pHB = static_cast<CCodeBlock*> (*itr);

		// Get regulation code at the beginning of handler
		for(UI32 i = 0; i < pHB->GetInstructionNum(); i++) {
			IInstruction *pIns = pHB->at(i);
			// Do not adjust hvtrap handler, it is called is fixed block
			if(pHB->GetLabel().find("hvtrap") != std::string::npos)
				continue;

			// End of regulation code of 1st instruction.
			if(pIns->GetRegulationTarget() == NULL)
				break;

			// Adjustment code is always MOV32 instruction
			if(pIns->opr(1)->Idx() != reg){
				if(i < pHB->GetInstructionNum() - 1){
					IInstruction *pNext = pHB->at(i + 1);
					pIns->DirMoveTo(pNext);
				}
				UI32 reg = pIns->opr(1)->Idx();
				UI32 val = (UI32) *(pIns->opr(0));
				vRegIns.push_back(std::make_pair(reg, val));
				pHB->Remove(pIns);
				i--;
			}
		}

		if(vRegIns.size() > 0) {
			vRegulationIns.push_back(std::pair<UI32, std::vector<std::pair<UI32, UI32>>> (pHB->GetHandlerAddress(), vRegIns));
		}
	}

	auto InsertHandlerAdjustment = [&](std::vector<INode*>& vCB) {
		for(itr = vCB.begin(); itr != vCB.end(); itr++) {
			CCodeBlock* pCB = static_cast<CCodeBlock*> (*itr);
			// Insert adjustment code of handler to random block
			for(UI32 i = 0; i < pCB->GetInstructionNum(); i++) {
				IInstruction *pIns = pCB->at(i);
				std::pair<UI32, UI32> exp = pIns->GetException();
				UI32 cause_code = exp.first;
				UI32 handler_addr = exp.second;

				// No exception at this instruction
				if(cause_code == 0) {		
					continue;
				}

				// Find the handler that caused by this instruction
				std::vector<std::pair<UI32, std::vector<std::pair<UI32, UI32>>>>::iterator it;
				it = std::find_if(vRegulationIns.begin(), vRegulationIns.end(), [&] (std::pair<UI32, std::vector<std::pair<UI32, UI32>>> p) {return (p.first == handler_addr);});
				std::vector<std::pair<UI32, UI32>> vRegIns = it->second;
				
				// Check whether adjustment code among handler are conflicted
				std::vector<std::pair<UI32, UI32>>::iterator itrRegIns;
				for(itrRegIns = vRegIns.begin(); itrRegIns < vRegIns.end(); itrRegIns++) {
					UI32 reg = itrRegIns->first;
					UI32 val = itrRegIns->second;
					IInstruction *pRegIns = MOV32(val, reg);
					//pRegIns->AppendComment(comment.c_str());

					pIns->DirMoveTo(pRegIns);
					pCB->AddOpeCode(pRegIns, i);

					// Increase count number due to inserted instruction.
					i++;
				}
			}
		}
	};

	// Move handler adjustment to random code
	InsertHandlerAdjustment(g_asf->GetCodeBlock());
	InsertHandlerAdjustment(g_asf->GetHandlerBlock());
	InsertHandlerAdjustment(g_asf->GetTerminateBlock());
	InsertHandlerAdjustment(g_asf->GetPrologueBlock());
}

void CBlockManager::CombineC2B1(CCodeBlock *pCB) {

	for(UI32 n = 0; n < pCB->GetInstructionNum() - 1; n++) {
		IInstruction *pIns = pCB->at(n);
		IInstruction *pNext = pCB->at(n+1);
		if(pIns->InSequence(IInstruction::IF_SEQ_C2B1) && pIns->GetC2B1Ins() != nullptr)
			continue;

		if(CheckC2B1Couple(pIns, pNext)) {
			UI32 i = 0;
			IDirective *pDir = nullptr;

			while((pDir = pNext->GetDirective(i)) != nullptr) {
				CAsyncLabel* pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				if(pAsyncLabel != NULL) {

					UI32 j = 0;
					IDirective *pDir1 = nullptr;
					while((pDir1 = pIns->GetDirective(j)) != nullptr) {
						CAsyncLabel* pAs = static_cast<CAsyncLabel*> (pDir1->GetAsyncLabel());
						if(pAs != NULL && !g_sim->CheckSameInterruptType(pAs->m_name, pAsyncLabel->m_name)) { // This request is not existed in pIns
							pIns->SetDirective(pDir);
                            break;
						}
						j++;
					}

					pNext->RemoveDirective(pDir);
				}
				i++;
			}

			pIns->SetSequence(IInstruction::IF_SEQ_C2B1);
			pNext->SetSequence(IInstruction::IF_SEQ_C2B1);
			pIns->SetC2B1Ins(pNext);
			pIns->AppendComment("first C2B1 instruction");
			pNext->AppendComment("second C2B1 instruction");
			n++;	// Bypass pNext
		}
	}
}

void CBlockManager::AddDeadCode(CCodeBlock *pCB) {
    UI32 followInsNum = 2;
    while(followInsNum > 0) {
        IInstruction* pIns = m_nrmSet.CreateIns();
        if (pIns->IsComplex() || pIns->GetId() > INS_ID_RESBANK){
            delete pIns;
        }else{
            pIns->AppendComment("Dead Code");
            pCB->AddOpeCode (pIns);
            followInsNum --;
        }
    }
}

bool CBlockManager::CheckC2B1Couple(IInstruction* pIns1, IInstruction* pIns2){

	UI32 InsC2B1Id = 0;

	// Check valid operand in second instruction 
	auto CheckValidOperand = [](IInstruction *pIns, UI32 OprCons, UI32 OprChange){

		if(pIns->opr(OprCons)->Idx() == 0) // Not use r0
			return false;
			
		if (pIns->opr(OprCons)->Idx() == pIns->opr(OprChange)->Idx())
			return false;
			
		return true;
	};

	// Lamda function check operand follow C2B1 constraint
	auto C2B1Constraint = [](IInstruction* pIns1, UI32 OprIns1, IInstruction* pIns2, UI32 OprIns2){
		UI32 regIns1 = pIns1->opr(OprIns1)->Idx();
		UI32 regIns2 = pIns2->opr(OprIns2)->Idx();
		
		if((pIns1->GetId() == INS_ID_MOVI5 && pIns2->GetId() == INS_ID_ADD_I5) || pIns1->GetId() == INS_ID_BR_SD9)
			return false;
			
		if(pIns1->GetId() == INS_ID_MOVEA && pIns1->opr(1)->Idx() != 0)
			return false;
			
		if (regIns1 != regIns2)
			return false;
			
		return true;
	};
	
	auto CheckC2B1InsId = [&InsC2B1Id](UI32 InsId1, UI32 InsId2){
		std::vector<UI32> SHIFT = {INS_ID_SHL_I5, INS_ID_SHR_I5};
		std::vector<UI32> SHORT_STORE = {INS_ID_SST_B, INS_ID_SST_H, INS_ID_SST_W};
		std::vector<UI32> STORE_C2B1 = {INS_ID_ST_B_SD16, INS_ID_ST_H_SD16, INS_ID_ST_W_SD16};
		std::vector<UI32> ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_SUB, INS_ID_SUBR};
		ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_SUB, INS_ID_SUBR, INS_ID_TST, INS_ID_AND, INS_ID_OR, INS_ID_XOR, INS_ID_SHL_I5, INS_ID_SHR_I5, INS_ID_SAR_I5};

		if( InsId1 == INS_ID_MOV || InsId1 == INS_ID_MOVI5){
			for(UI32 i = 0; i < ALU.size(); i++)
				if(InsId2 == ALU.at(i) && InsId2 != INS_ID_TST)
					InsC2B1Id = INS_CID_MOV_ALU;
					
			for(UI32 i = 0; i < SHORT_STORE.size(); i++)
				if(InsId2 == SHORT_STORE.at(i))
					InsC2B1Id = INS_CID_MOV_SST;		
			}
			
		if( InsId1 == INS_ID_MOV){	
			for(UI32 i = 0; i < SHIFT.size(); i++)
				if(InsId2 == SHIFT.at(i))
					InsC2B1Id = INS_CID_MOVR_SHIFT;
		
		}
		
		if( InsId1 == INS_ID_MOVI5){	
			for(UI32 i = 0; i < STORE_C2B1.size(); i++)
				if(InsId2 == STORE_C2B1.at(i))
					InsC2B1Id = INS_CID_MOV5_ST;
		
		}
		
		if( InsId1 == INS_ID_MOVEA){	
			for(UI32 i = 0; i < SHORT_STORE.size(); i++)
				if(InsId2 == SHORT_STORE.at(i))
					InsC2B1Id = INS_CID_MOVEA_SST;
					
			for(UI32 i = 0; i < STORE_C2B1.size(); i++)
				if(InsId2 == STORE_C2B1.at(i))
					InsC2B1Id = INS_CID_MOVEA_ST;		
		
		}
		
		if(InsId1 == INS_ID_CMP || InsId1 == INS_ID_CMP_SI5) {
			if( InsId2 >= INS_ID_BC_SD9 && InsId2 <= INS_ID_BZ_SD17)
				InsC2B1Id = INS_CID_CMP_BCC;
		}
	
		if(InsId2 >= INS_ID_BC_SD9 && InsId2 <= INS_ID_BZ_SD17) {
			for(UI32 i = 0; i < ALU.size(); i++)
				if(InsId1 == ALU.at(i))
					InsC2B1Id = INS_CID_ALU_BCC;	
		}
	};
	
	CheckC2B1InsId(pIns1->GetId(), pIns2->GetId());
	
	if(InsC2B1Id == 0)
		return false;
	
	switch (InsC2B1Id){
	
		case INS_CID_MOV_ALU:
			if(CheckValidOperand(pIns2, 1, 0) == false || C2B1Constraint(pIns1, 1, pIns2, 1) == false)
				return false;
			break;
				
		case INS_CID_MOVR_SHIFT:
			if(C2B1Constraint(pIns1, 1, pIns2, 1) == false)
				return false;
			break;
				
		case INS_CID_MOV_SST:
			if(CheckValidOperand(pIns2, 1, 0) == false || C2B1Constraint(pIns1, 1, pIns2, 0) == false)
				return false;
			break;
				
		case INS_CID_MOV5_ST:
			if(CheckValidOperand(pIns2, 0, 1) == false || C2B1Constraint(pIns1, 1, pIns2, 0) == false)
				return false;
			break;

		case INS_CID_MOVEA_SST:
			if(CheckValidOperand(pIns2, 1, 0) == false || C2B1Constraint(pIns1, 2, pIns2, 0) == false)
				return false;
			break;
		
		
		case INS_CID_MOVEA_ST:
			if(CheckValidOperand(pIns2, 0, 1) == false || C2B1Constraint(pIns1, 2, pIns2, 0) == false)
				return false;
			break;
		
		
		case INS_CID_CMP_BCC:
		case INS_CID_ALU_BCC:
			return true;
		
		default:
			return false;
	}
	return true;

}

void CBlockManager::FrontLoadC2B1(std::map<std::string, GRVALSET> *pGrList) {
	UI32 count = 0;
	std::stringstream ss;
	std::string label;

	// Move handler adjustment to random code
	std::vector<INode*>& vCB = g_asf->GetCodeBlock();

	std::vector<INode*>::iterator cbItr;
	for(cbItr = vCB.begin(); cbItr != vCB.end(); cbItr++) {
		CCodeBlock* pCB = static_cast<CCodeBlock*> (*cbItr);
		for (UI32 n = 0; n < pCB->GetInstructionNum(); n++) {
			IInstruction *pIns = pCB->at(n);
			// Not in C2B1 couple or 2nd instruction of C2B1
			if (pIns->InSequence(IInstruction::IF_SEQ_C2B1) == false || pIns->GetForwardIns() == nullptr) {
				continue;
			}
			// Exception did not occur at 1st ins.
			if(pIns->GetException().first == 0) {
				continue;
			}

			//Do not move adjusment code in case first instruction cause SYSERR
			if(pIns->HasAsyncLabel() && (pCB->GetIndex(pIns) > 0) && (pCB->at(pCB->GetIndex(pIns) -1)->GetComment().find("Mirror") != std::string::npos))
				continue;

			// 1st instruction has no label
			if(pIns->GetLabel().size() == 0) {
				ss << pCB->GetLabel() << "_exp_" << count;
				ss >> label;
				ss.str(""); ss.clear(std::stringstream::goodbit);
				pIns->SetLabel(label.c_str());
				count++;
			}

			IInstruction *pTarget = pIns->GetForwardIns();
			std::string label = pIns->GetLabel();
			GRVALSET grvalset;
			UI32 reglist = pIns->GetConstraintBit();
			if(pIns->GetException().first != 0x90 /* MIP */ && pIns->GetException().first != 0x91 /* MDP */)
				reglist = 0x0;

			// Get next instruction
			n++;
			pIns = pCB->at(n);
			while(pIns != pTarget) {
				if(pIns->GetRegulationTarget() != nullptr && pIns->HasDeassertAsyncLabel() == false) {
					if(pIns->GetId() == INS_ID_MOVI32) {
						// The adjustment code is always MOV32 here, the operand was valid
						UI32 adjustedReg = pIns->opr(1)->Idx();
						UI32 val = (UI32)*(pIns->opr(0));
						if(adjustedReg != m_nHandlerReg && (reglist & (1 << adjustedReg)) == 0) {
							grvalset.push_back(std::make_pair(adjustedReg, val));
							pCB->Remove(pIns);
							pCB->Update();
							pIns = pCB->at(n);
							continue;
						}
					}
				}
				n++;
				pIns = pCB->at(n);
			}

			if(grvalset.size() != 0) {
				std::pair<std::map<std::string, GRVALSET>::iterator, bool> mir;
				mir = pGrList->insert(std::make_pair(label, grvalset));
				if(!mir.second) {
					std::map<std::string, GRVALSET>::iterator itr = mir.first;
					while(grvalset.size()) {
						itr->second.push_back(grvalset.back());
						grvalset.pop_back();
					}
				}
			}
		}
	}
}


/**
* @brief Initialize MPU register
* @param pCB pointer to current code block
* @param reg store value in order to set for SR
* @param pCfg config information
*/
void CBlockManager::InitMPURegister(CCodeBlock *pCB, UI32 reg, TBlockConfig* pCfg) {
    UI32 init_svlock = g_srs->GetNcInit(8, 1) & 0x1;
    UI32 mpnum = g_hwInfo.m_mpnum;
    // Calculate memory to store MPU infor
    UI32 start_mem_addr = g_wm.STORE_MPU_INFO + (mpnum * 3 * 4) * pCfg->m_GMID;

    NewINS(pCB, LDSR(0, 8, 1)); // Disable SVLOCK
   
    if (pCfg->m_bGM != false) {
        UI32 hbe = m_MmList.GetHBE();
        NewINS(pCB, MOV32((hbe << 8), 8));
        NewINS(pCB, LDSR(8, 2, 5));         //MPCFG
    }

    NewINS(pCB, MOV32(start_mem_addr, reg));
    NewINS(pCB, LDM_MP(reg, 0, mpnum - 1));

    RandomAndPresetMPU(start_mem_addr, pCfg);

    // set new value for MPIDX if it is same as reserve entry 
    UI32 curMPIDx = mpnum - 1;  // default is value of convention mode
    if (pCfg->m_bGM) curMPIDx = g_srs->GetNcInit(16, 5);
    UI32 newMPIDX = curMPIDx;

    while (g_prf->IsWorkMPURegionByIdx(newMPIDX)) {
        newMPIDX = g_rnd.GetRange(0U, mpnum - 1);
    }
    if (newMPIDX != curMPIDx) {
        NewINS(pCB, MOV32(newMPIDX, reg));
        NewINS(pCB, LDSR(reg, 16, 5));     // MPIDX
    }

    NewINS(pCB, MOV5(init_svlock, reg));
    NewINS(pCB, LDSR(reg, 8, 1));       // SVLOCK

}

/**
* @brief Random and Preset MPU information to memory
* @param start_address start address to prest MPU information
* @param pCfg config information
*/
void CBlockManager::RandomAndPresetMPU(UI32 start_address, TBlockConfig* pCfg) {
    if (pCfg->m_bGM != false) {
        // Virtualization
        m_MmList.Fix(pCfg->m_GMID);  // Guest management
        m_MmList.Fix(HOST_ENTRY); // Host management
        UI32 hbe = m_MmList.GetHBE();
        m_MmList.OutMpuSetting(&m_mp_table, pCfg->m_GMID, 0, hbe);                     // Guest management
        m_MmList.OutMpuSetting(&m_mp_table, HOST_ENTRY, hbe, g_hwInfo.m_mpnum);        // Host management
        //m_MmList.MpuDump(&m_mp_table);
    } else {
        // Convention mode
        m_MmList.Fix(CONVENTION_ENTRY);
        m_MmList.OutMpuSetting(&m_mp_table, CONVENTION_ENTRY, 0, g_hwInfo.m_mpnum);
    }

    UI32 val = 0;
    UI32 mpnum = g_hwInfo.m_mpnum;
    ISimulator* pSim = g_sim->GetSimulator();
    // each entry has 3 regester (MPLA, MPUA, MPAT) which need to initialize
    // we use 4 byte to store value of each register
    for (UI32 entry = 0; entry < mpnum; ++entry) {
        for (UI32 idx = 0; idx < 3; ++idx) {
            val = m_mp_table[entry][idx];
            pSim->PresetMemory(true, 0, start_address, 4, val);
            start_address = start_address + 4;
        }
    }
}

/*
* @Brief generate self check code that MAU accessed
* @param pCB pointer to current code block
*/
void CBlockManager::GenerateDCUSelfCheckCode(CCodeBlock *pCB) {
    const UI32		TempR = 10;
    const UI32		TempS = 20;
    const UI32      ep    = 30;

    if (m_mSelfCheckMemRange.empty() || pCB == nullptr || pCB->GetSnapShot() == nullptr) {
        return;
    }

    UI32 inum = pCB->GetInstructionNum();
    const UI64 PSIZE = 4ULL;
    const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;
    const UI64 ALIGN = ~(PFETCHSIZE - 1);

    for (std::pair<MEMADDR, UI32> mem : m_mSelfCheckMemRange) {
        UI32 addr = mem.first;
        UI32 size = mem.second;
        // Initialize memory that MAU accessed
        UI64 start_a = addr & ALIGN;
        g_sim->GetSimulator()->PresetMemory(true, 0, start_a, PSIZE, g_rnd.Get());
        if (PFETCHSIZE == 8 || size == 8) {
            g_sim->GetSimulator()->PresetMemory(true, 0, start_a + PSIZE, PSIZE, g_rnd.Get());
        }

        switch (size) {
            case 1:
                NewINS(pCB, MOV32(addr, ep));
                NewINS(pCB, SLDBU(0, TempR)); // ep
                break;
            case 2:
                NewINS(pCB, MOV32(addr, ep));
                NewINS(pCB, SLDHU(0, TempR)); // ep
                break;
            case 4:
                NewINS(pCB, MOV32(addr, TempS));
                NewINS(pCB, LDW16(0, TempS, TempR));
                break;
            case 8:
                NewINS(pCB, MOV32(addr, TempS));
                NewINS(pCB, LDDW23(0, TempS, TempR));
                break;
            default:
                break;
        }
    }

    NewINS(pCB, NOP());
    pCB->Rotate(inum);
}

/*
* @Brief Generate handshake code between DCU and CPU
* @param pCB pointer to current code block
*/
void CBlockManager::GenerateDCUHandShakeCode(CCodeBlock *pCB) {
    UI32 reg = 2;
    UI32 ep = 30;
    UI32 reg1 = 1;
    static UI32 orderBlock = 0;

    if (m_mHandShakeRecord.empty() || m_mHandShakeRecord.size() <= orderBlock) return;

    const UI32 ADDR_DBG_MBOUT = 0xf901206c;
    UI32 inum = pCB->GetInstructionNum();

    auto CreateINS = [=](CCodeBlock *pCB, IInstruction* pIns) {
        std::string comment = "HandShake_MBOUT_" + std::to_string(m_mHandShakeRecord[orderBlock].first);
        pIns->SetSequence(IInstruction::IF_SEQ_DCU);
        pIns->AppendComment(comment.c_str());
        NewINS(pCB, pIns);
    };

    auto GenHandShakeCode = [=](CCodeBlock *pCB) {
        std::string label = "_HandShakeLabel_" + std::to_string(orderBlock) + "_MBOUT_" + std::to_string(m_mHandShakeRecord[orderBlock].first);
        UI32 DBG_MBINT = m_mHandShakeRecord[orderBlock].first;

        CreateINS(pCB, MOV5(m_mHandShakeRecord[orderBlock].first, reg1));

        CreateINS(pCB, STSR(5, reg, 0));

        CreateINS(pCB, MOV32(ADDR_DBG_MBOUT, ep)->SetValid(true));

        CreateINS(pCB, STWI(reg1, ep)->SetValid(true));

        CreateINS(pCB, SLDB(0, ep)->SetValid(true));

        CreateINS(pCB, CMP5(DBG_MBINT, ep)->SetValid(true));

        CreateINS(pCB, BNZ9P(label)->SetValid(true));

        CreateINS(pCB, LDSR(reg, 5, 0)->SetLabel(label));

        CreateINS(pCB, SYNCI());

        CreateINS(pCB, MOV32(g_rnd.Get(), ep));

        CreateINS(pCB, MOV32(g_rnd.Get(), reg1));
    };

    GenHandShakeCode(pCB);
    orderBlock++;

    pCB->Rotate(inum);

    if (orderBlock == g_cfg->m_nBlockNum) {
        GenHandShakeCode(pCB);
        orderBlock++;
    }   
}