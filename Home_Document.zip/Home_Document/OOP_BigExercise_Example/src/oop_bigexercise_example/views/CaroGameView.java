package oop_bigexercise_example.views;


import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.*;

import org.eclipse.jface.action.*;
import org.eclipse.ui.*;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;


/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class CaroGameView extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "oop_bigexercise_example.views.CaroGameView";

	private Action action1;
	private Action action2;	
	private Label playerLabel;
	private Cursor currentCursor;
	private Board board;

	
	private static CaroGameView instance;
	
	public static CaroGameView getIntance()
	{
		return instance;
	}
	
	/**
	 * The constructor.
	 */
	public CaroGameView() {
		instance = this;
	}

	/**
	 * This is a callback that will allow us
	 * to create the viewer and initialize it.
	 */
	public void createPartControl(final Composite parent) {
		
		SashForm sashForm = new SashForm(parent, SWT.NONE);
		
		final Composite leftComposite = new Composite(sashForm, SWT.NONE);
		leftComposite.setLayout(new FillLayout(SWT.HORIZONTAL));
		board = new Board(leftComposite, SWT.NONE,6);
		

		
		Composite rightComposite = new Composite(sashForm, SWT.NONE);
		
		Label lblPlayerStatus = new Label(rightComposite, SWT.NONE);
		lblPlayerStatus.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblPlayerStatus.setBounds(10, 22, 178, 30);
		lblPlayerStatus.setText("Player status:");
		
		
		String[] list = { "10x10", "20x20", "30x30", "40x40", "50x50" };
		final CCombo combo = new CCombo(rightComposite, SWT.BORDER);
		combo.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int i = combo.getSelectionIndex();
				if (i == 0) {
					
					board.setBoardSize(10);
					board.canvasRedraw();
					board.initBoardGame(10);
					playerLabel.setText("Player 1");
					board.setTurn(1);
				}
				if (i == 1) {
					board.setBoardSize(20);
					board.canvasRedraw();
					board.initBoardGame(20);
					playerLabel.setText("Player 1");
					board.setTurn(1);
				}
				if (i == 2) {
					board.setBoardSize(30);
					board.canvasRedraw();
					board.initBoardGame(30);
					playerLabel.setText("Player 1");
					board.setTurn(1);
				}
				if (i == 3) {
					board.setBoardSize(40);
					board.canvasRedraw();
					board.initBoardGame(40);
					playerLabel.setText("Player 1");
					board.setTurn(1);
				}
				if (i == 4) {
					board.setBoardSize(50);
					board.canvasRedraw();
					board.initBoardGame(50);
					playerLabel.setText("Player 1");
					board.setTurn(1);
				}
			}
		});
		combo.add(list[0], 0);
		combo.add(list[1], 1);
		combo.add(list[2], 2);
		combo.add(list[3], 3);
		combo.add(list[4], 4);
		
		combo.setBounds(38, 126, 110, 25);
		
		playerLabel = new Label(rightComposite, SWT.NONE);
		playerLabel.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_RED));
		playerLabel.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		playerLabel.setBounds(20, 58, 168, 25);
		playerLabel.setText("Player 1");
		
		
		// Label of setting boundary
		Label boundaryLabel = new Label(rightComposite, SWT.NONE);
		boundaryLabel.setBounds(22, 175, 126, 15);
		boundaryLabel.setText("Check boundary or not?");
		sashForm.setWeights(new int[] {429, 162});
		
		// Select setting boundary or not
		// Boundary
		final Button btnRadioButton = new Button(rightComposite, SWT.RADIO);
		btnRadioButton.setBounds(38, 196, 90, 16);
		btnRadioButton.setText("Yes");
		btnRadioButton.setSelection(true);
		
		// No boundary
		final Button btnRadioButton_1 = new Button(rightComposite, SWT.RADIO);
		btnRadioButton_1.setBounds(38, 218, 90, 16);
		btnRadioButton_1.setText("No");
		
		if(board.startGame()){
			btnRadioButton.setEnabled(true);
			btnRadioButton_1.setEnabled(true);
		}
		else{
			btnRadioButton.setEnabled(false);
			btnRadioButton_1.setEnabled(false);
		}
		btnRadioButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnRadioButton.setSelection(true);
				btnRadioButton_1.setSelection(false);
				board.setBoundary(1);
			}
		});

				
		btnRadioButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				btnRadioButton_1.setSelection(true);
				btnRadioButton.setSelection(false);
				board.setBoundary(0);
			}
		});

		
		//New game button click
		Button btnNewGame = new Button(rightComposite, SWT.NONE);
		btnNewGame.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				board.setBoardSize(20);
				board.canvasRedraw();
				board.initBoardGame(20);
				playerLabel.setText("Player 1");
				board.setTurn(1);
				combo.setText("");
			}
		});
		btnNewGame.setBounds(73, 267, 75, 25);
		btnNewGame.setText("New Game");
		
//		makeActions();
//		hookContextMenu();
//		contributeToActionBars();
	}

	private void hookContextMenu() {
		MenuManager menuMgr = new MenuManager("#PopupMenu");
		menuMgr.setRemoveAllWhenShown(true);
		menuMgr.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager manager) {
				CaroGameView.this.fillContextMenu(manager);
			}
		});
		//Menu menu = menuMgr.createContextMenu(viewer.getControl());
		//viewer.getControl().setMenu(menu);
		//getSite().registerContextMenu(menuMgr, viewer);
	}

	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
		fillLocalToolBar(bars.getToolBarManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
		manager.add(action1);
		manager.add(new Separator());
		manager.add(action2);
	}

	private void fillContextMenu(IMenuManager manager) {
		manager.add(action1);
		manager.add(action2);
		// Other plug-ins can contribute there actions here
		manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}
	
	private void fillLocalToolBar(IToolBarManager manager) {
		manager.add(action1);
		manager.add(action2);
	}

	private void makeActions() {
		action1 = new Action() {
			public void run() {
				showMessage("Action 1 executed");
			}
		};
		action1.setText("Action 1");
		action1.setToolTipText("Action 1 tooltip");
		action1.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		action2 = new Action() {
			public void run() {
				showMessage("Action 2 executed");
			}
		};
		action2.setText("Action 2");
		action2.setToolTipText("Action 2 tooltip");
		action2.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
	}

	private void showMessage(String message) {
			
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	}
	
	/**
	 * Update the current player information
	 * @param turn Turn of current player
	 */
	public void setTurnPlayer(int turn)
	{
		String text = turn == 1? "Player 1": "Player 2";
		playerLabel.setText(text);
		if (turn == 1)
			currentCursor = new Cursor(board.getDisplay(), SWT.CURSOR_ARROW);
		else 
			currentCursor = new Cursor(board.getDisplay(), SWT.CURSOR_HAND);
		board.setCursor(currentCursor);
	}
	
	/**
	 * Update the current player information
	 * @param turn Turn of current player
	 */
	public void setWiner(int turn, boolean draw)
	{
		String text = draw == true ? "draw" : turn == 1? "Player 1 won": "Player 2 won";
		playerLabel.setText(text);
	}
}
