Note for users to write G4MH20's configuration by referring to this default configuration:

1) Frog.run:
	+ Don't set random_handler option because it is removed from FROG's source code
	+ Use weight.profile file instead of sample.profile
	+ Reduce value of --block_num or --inum_in_block (from 64 to 32) if the number of Virtual machines is greater than 4. Another solution is expand I area in ::ROM_ADDESS, ::RAM_ADDRESS (weight.profile)
	
2) weight.profile:
	+ Don't delete or comment out any instructions (set weight to zero in this case) except ::BREAK_GLOBAL (if neccessary)
	+ Do not set ratio to interrupt BGxxINT when only run 1 Virtual machine 
	
3) sreg.profile: Please be careful when setting these system register:
	+ RBIP: 
		Set "NO" to Write permission because FROG doesn't support write permission to this register
	+ EBASE, GMEBASE: 
		Do not set user initial value to this register (field 8 should be blank) 
	+ HVCFG: 
		Setting this register depend on initial mode in weight.profile (CV or GM#x)
		- If initial mode is CV:
			. Set 0x00000000 to initial value (field 8 = 0x00000000)
			. Set 0x00000000 to randomize value (field 14 = 0x00000000)
		- If initial mode set 1 GM only:
			. Set 0x00000001 to initial value (field 8 = 0x00000001)
			. Do not randomize value of bit HVCFG.HVE (field 14 should be blank)
		- If initial mode set many GM:
			. Set 0x00000001 to initial value (field 8 = 0x00000001)
			. Set "NO" to Write permission
			. Do not randomize value of bit HVCFG.HVE (field 14 should be blank)
	+ GMMPCFG: 
		Set "NO" to Write permission because FROG doesn't support update bit GMMPCFG.HBE by LDSR.
	+ EIPC, FEPC, FPEPC, CTPC, DBPC, GMEIPC, GMFEPC: 
		User can set "YES" to Read permission.
		But, when testing by Legacy FROG, Read permission of these register will be disabled.
	+ CTBP, EBASE, INTBP, SCBP, GMEBASE, GMINTBP:
		User can set "YES" to Write permission.
		But, when testing by Legacy FROG, Write permission of these register will be disabled.
	+ MPM, GMMPM:
		Do not set user initial value (field 8 should be blank) of these register.
		Because if MPU function is enabled before setting MPU register (MPUA, MPLA, MPAT), MIP will be loop.
	+ HVSB:
		Set "NO" to Write permission in case of running many Virtual machine (there are more than 1 GM); because in this case, FROG need to use HVSB register to record information.
	+ ICTAGL, ICTAGH, ICDATL, ICDATH:
		Set "NO" to Read permission, because there is mismatch when cache instruction is executed (limitation)
	+ EIPSWH, FEPSWH:
		Set randomize bit GPID doesn't affect. In these register, bit GPID can not be updated directly by random LDSR instruction. 
	
4) Please inform FROG team if there are any registers need adding/removing