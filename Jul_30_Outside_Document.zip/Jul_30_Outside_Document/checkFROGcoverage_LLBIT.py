# -------------------------------- HOW TO USE -------------------------------------
# 		python checkingFROGcoverage <Cforest log>
# ---------------------------------------------------------------------------------

import sys
import database
import copy
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import datetime # support time stamp

		
# -------------------------------- DEFINE VARIABLE -------------------------------------
InputFileName = sys.argv[1:]		
AccumulationFile = 'Data_Accumulation.bk'

ClearLLbitCond = {'ldl.bu': 0, 'ldl.hu': 0, 'ldl.w': 0, 
					'stc.b': 0, 'stc.h': 0, 'stc.w': 0,
					'st.b': 0, 'st.b23': 0, 'st.b+': 0, 'st.b-': 0, 
					'st.h': 0, 'st.h23': 0, 'st.h+': 0, 'st.h-': 0, 
					'st.w': 0, 'st.w23': 0, 'st.w+': 0, 'st.w-': 0, 'st.dw': 0,
					'sst.b': 0, 'sst.h': 0, 'sst.w': 0, 
					'stv.w': 0, 'stv.dw': 0, 'stv.qw': 0, 'stvz.h4': 0, 
					'not1': 0, 'not1r': 0, 'clr1': 0, 'clr1r': 0, 'set1': 0, 'set1r': 0, 'caxi': 0,
					'prepare': 0, 'prepare16': 0, 'prepare16hi': 0, 'prepare32': 0, 'preparesp': 0, 
					'pushsp': 0, 'stm.mp': 0, 'stm.gsr': 0, 'cll': 0, 'eiret': 0, 'feret': 0, 'eiret.cm': 0, 'feret.cm': 0,
					'HVTRAP': 0, 'SYSCALL': 0, 'TRAP0': 0, 'TRAP1': 0, 'FETRAP': 0,
					'RIE': 0, 'FEINT': 0, 'FENMI': 0, 'EIINT': 0, 'EIINT.TBL': 0, 'EIINT.RB': 0, 
					'GMFEINT': 0, 'GMEIINT': 0, 'GMEIINT.TBL': 0, 'GMEIINT.RB': 0, 'BGEIINT': 0, 'BGFEINT': 0,
					'MIP': 0, 'MDP': 0, 'MDP(EIINT)': 0, 'MDP(GMEIINT)': 0, 
					'MAE': 0, 'UCPOP0': 0, 'UCPOP1': 0, 'UCPOP2': 0, 'PIE': 0, 'SYSERR_REEXEC': 0, 'SYSERR_RB': 0, 'FPE': 0, 'FXE': 0}
					
NotClearLLbitCond = {'st.b': 0, 'st.b23': 0, 'st.b+': 0, 'st.b-': 0, 
					'st.h': 0, 'st.h23': 0, 'st.h+': 0, 'st.h-': 0, 
					'st.w': 0, 'st.w23': 0, 'st.w+': 0, 'st.w-': 0, 'st.dw': 0,
					'sst.b': 0, 'sst.h': 0, 'sst.w': 0, 
					'stv.w': 0, 'stv.dw': 0, 'stv.qw': 0, 'stvz.h4': 0, 
					'not1': 0, 'clr1': 0, 'set1': 0, 'caxi': 0,
					'prepare': 0, 'prepare16': 0, 'prepare32': 0, 'prepare16hi': 0, 'preparesp': 0, 
					'pushsp': 0, 'stm.mp': 0, 'stm.gsr': 0, 'ctret': 0, 'dbret': 0,
					'DBNMI': 0, 'DBINT': 0, 'DBTRAP': 0, 'AE': 0, 'LSAB': 0, 'PCB': 0}
					

					
InsClearLLbitHost = copy.deepcopy(ClearLLbitCond)
InsClearLLbitGuest = copy.deepcopy(ClearLLbitCond)

InsNotClearLLbitHost = copy.deepcopy(NotClearLLbitCond)
InsNotClearLLbitGuest = copy.deepcopy(NotClearLLbitCond)

InsAccessManyMem = {'st.dw', 'stv.dw', 'stv.qw', 'stvz.h4', 'prepare', 'prepare16', 'prepare16hi', 'prepare32', 'preparesp', 'pushsp', 'stm.mp', 'stm.gsr'}
					
#Load back data from backup file(if exists) before executing script
if os.path.isfile(AccumulationFile):
	with open(AccumulationFile, 'rb') as file_bk:
		InsClearLLbitHost = pickle.load(file_bk)
		InsClearLLbitGuest = pickle.load(file_bk)
		
		InsNotClearLLbitHost = pickle.load(file_bk)
		InsNotClearLLbitGuest = pickle.load(file_bk)
		
		
# ---------------------------------- FUNCTION ----------------------------------------

def CheckingLLBITcoverage(raw_data, prev_raw_data):
	""" Collect instrucion clear and not clear LLBIT """
	raw_data.InsName, raw_data.Opr = database.ConvertInsHasSpecialOpr(raw_data.InsName, raw_data.Opr)
	# Checking clear LLBIT
	if raw_data.LLBIT == 0:
		if prev_raw_data.LLBIT != 0:
			if len(raw_data.Exp) != 0:
				key = raw_data.Exp.keys()[0]
			else:
				key = raw_data.InsName
			# Define new name for each interrupt type
			if 'EIINT' in key[:7]:
				if raw_data.Behavior == database.InsBehavior.LD: # Table reference
					key += '.TBL'
				elif raw_data.Behavior == database.InsBehavior.ST: # Auto save
					key += '.RB'
			# For special case: pushsp clear LLBIT and occur LSAB exception. Because it access many memory	
			if key == 'LSAB' and raw_data.InsName in InsAccessManyMem:
				key = raw_data.InsName
			if key not in ClearLLbitCond:
				print "ERROR at key ", key, " line ",  raw_data.Line
				
			mode = database.GetMode(prev_raw_data.SR)
			# Define new name for changing from host mode to guest mode by EIRET/FERET
			if key == 'eiret' or key == 'feret':
				cur_mode = database.GetMode(raw_data.SR)
				if mode == database.Mode.HM and cur_mode == database.Mode.GM:
					key += '.cm'
			
			if mode != database.Mode.GM:
				InsClearLLbitHost[key] = 1
			else:
				InsClearLLbitGuest[key] = 1
	# Checking not clear LLBIT
	else:
		if len(raw_data.Exp) != 0:
			key = raw_data.Exp.keys()[0]
		else:
			key = raw_data.InsName
			
		if key in NotClearLLbitCond:
			mode = database.GetMode(prev_raw_data.SR)
			if mode != database.Mode.GM:
				InsNotClearLLbitHost[key] = 1
			else:
				InsNotClearLLbitGuest[key] = 1
		# Special case: create new LLBIT and delete old one		
		elif 'ldl.' in raw_data.InsName and prev_raw_data.LLBIT != 0:
			mode = database.GetMode(prev_raw_data.SR)
			if mode != database.Mode.GM:
				InsClearLLbitHost[raw_data.InsName] = 1
			else:
				InsClearLLbitGuest[raw_data.InsName] = 1
			
			
def PrintDictToFile(file_control, dict_data, msg):
	""" Print data that has structure is dictionaty to file """
	file_control.write("\n ** " + msg + " **\n")
	for key, value in dict_data.items():
		output = key.rjust(15) + ',' + str(value).rjust(10) + '\n'
		file_control.write(output)
					

# -------------------------------- MAIN PROCESS -------------------------------------

# Scan all cforest log files in current Working directory to make data-base-files
for cforest_log in InputFileName:
	print "File: ", cforest_log, " Time: ", datetime.datetime.now()
	raw_data_list = database.CollectData(cforest_log)
	#database.PrintData(raw_data_list)
	for n in range(1, len(raw_data_list)):
		CheckingLLBITcoverage(raw_data_list[n], raw_data_list[n-1])

		
f = open('output.log', 'w')	
PrintDictToFile(f, InsClearLLbitHost, "Status of Instruction clear LLBIT in Host or Conventional mode")
PrintDictToFile(f, InsNotClearLLbitHost, "Status of Instruction not clear LLBIT in Host or Conventional mode")

PrintDictToFile(f, InsClearLLbitGuest, "Status of Instruction clear LLBIT in Guest mode")	
PrintDictToFile(f, InsNotClearLLbitGuest, "Status of Instruction not clear LLBIT in Guest mode")	
f.close()	

#Backup data to a new file between script-executions
with open(AccumulationFile, 'wb') as file_bk:
	pickle.dump(InsClearLLbitHost, file_bk)
	pickle.dump(InsClearLLbitGuest, file_bk)
	
	pickle.dump(InsNotClearLLbitHost, file_bk)
	pickle.dump(InsNotClearLLbitGuest, file_bk)
	
		
	
	
	
			