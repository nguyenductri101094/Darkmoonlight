# ----------------------------------------------- HOW TO EXECUTE SCRIPT -----------------------------------------
#					 			python checkingFROGcoverage.py "log_files saving path"
# 					EXAMPLE1: python checkingFROGcoverage.py *.log ==> scan all log_files in dir
#
# 	EXAMPLE2: python checkingFROGcoverage.py ../dir1/dir2/cf_ff_RSEED=0x00ba3fc7.log ==> scan exact log_file
# ---------------------------------------------------------------------------------------------------------------


import sys
import csv
import re
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import database
import copy

cf_log_s = sys.argv[1:]

Accumulation_file = 'FROG_CC_Data_Accumulation.pk'
cache_result_file1 = "FROG_CC_cache_result_file1.csv"
cache_result_file2 = "FROG_CC_cache_result_file2.csv"


# -------------------------------- CACHE SUPPORT FUNCTION VERIFICATION -------------------------------------
# cache ins opcode array
cacheOP = ["CHBII","CIBII","CFALI","CISTI","CILDI","PREFI","PREFD"]
# Bit-combination bit trace position
cacheERRbitmap = ['ICCTRL', 1, 'ICERR', 21, 'ICERR', 20, 'ICERR', 19, 'ICERR', 18, 'ICERR', 17, 'ICERR', 16]
# Name of registers bit to be printed out
cacheERRbit = ['icctrl_ichemk', 'icerr_ermmh', 'icerr_ermpbse', 'icerr_ermte1', 'icerr_ermte2', 'icerr_ermdc', 'icerr_ermde']

# Cache function support verification function
def CacheFunctionVerification(_pre_line, _line):
	global cache_result_1, cache_result_2

	if "cache" == _line.InsName and not "0x" in _line.Opr[0]:
		cache_result_1.Update_result(_line.Opr[0], database.GetModeAndPrivilege(_pre_line.SR))
		#Scan and update bit combinations result
		cache_result_2 = database.GetSRbitCombination(cacheERRbitmap, _line.SR, cache_result_2)
		
	if "pref" == _line.InsName:
		_line.Opr[0] = "PREFD" if _line.Opr[0] == "0x4" else _line.Opr[0]
		cache_result_1.Update_result(_line.Opr[0], database.GetModeAndPrivilege(_pre_line.SR))
		
	
# -------------------------------- CACHE SUPPORT FUNCTION VERIFICATION -------------------------------------

	

	
	
# -------------------------------- MAIN PROCESS -------------------------------------

# Overwrite SR, GR and WR for Cache support function checklist
database.SR = { 'HVCFG' : 0, 'PSWH' : 0, 'PSW' : 0, 'GMPSW' : 0, 'ICCTRL' : 0, 'ICERR' : 0, 'DIR0' : 0 }
database.GR = {}
database.WR = {}

# Init result holders or load from pk file
cache_result_1 = database.InssExeInMode(cacheOP)
cache_result_2 = database.CreateBinMatrix(cacheERRbit)

if os.path.isfile(Accumulation_file):
	with open(Accumulation_file, 'rb') as file_in:
		cache_result_1 = pickle.load(file_in)
		cache_result_2 = pickle.load(file_in)
	
	
# ------------------------------------SCANNING LOG_FILES------------------------------------#
# --------------------------------MAKING DATABASE - VERFYING--------------------------------#
for cf_log in cf_log_s:
	log_VAR = database.CollectData(cf_log)
	getModeDone = False
	
	for i in range(1, len((log_VAR))):
		line = log_VAR[i]
		pre_line = log_VAR[i-1]
		
		CacheFunctionVerification(pre_line, line)
		
	del log_VAR
# ------------------------------------------------------------------------------------------#
# ------------------------------------------------------------------------------------------#
		
	
# Backup to pk file
with open(Accumulation_file, 'wb') as file_pk:
	pickle.dump(cache_result_1, file_pk)
	pickle.dump(cache_result_2, file_pk)
	
# Export data to CSV file
cache_result_1.ExportCSV(cache_result_file1, 'wb')

# Write result of bit-combination to new file
bit_comb_file_VAR = open(cache_result_file2, 'wb')
database.PrintSRbitCombination(bit_comb_file_VAR, cache_result_2, cacheERRbit)
bit_comb_file_VAR.close()
