#!/usr/bin/env bash
LD_LIBRARY_PATH=../cpu_e3v5/sim:${LD_LIBRARY_PATH}
export LD_LIBRARY_PATH

if [ $# -ne 1 ]
then
	exit
fi

testset=$1

echo -n "Run Frog..."
${testset}/Frog.run
if [ $? -ne 0 ]; then
    echo "Frog fail to generate pattern."
	exit 1
fi
echo "ok!"

echo -n "Run Asm..."
mkdir -p ${testset}/out
LATESTFILE="`ls -lt ${testset}/out/*.S | head -n 1 | awk '{print $9}'`"
NAMES=${LATESTFILE%.*}
./asm.sh ${NAMES} > ${testset}/asm.log 2>&1
if [ $? -ne 0 ]; then
    echo "Asm fail to generate hex."
	exit 1
fi
echo "ok!"

