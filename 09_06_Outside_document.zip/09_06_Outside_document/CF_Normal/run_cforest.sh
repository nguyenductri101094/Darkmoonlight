#!/usr/bin/env bash
CFDIR=../eva/cforest_standalone/g4x/
CFBIN=cforestg4x

if [ $# -ne 1 ]
then
	exit 1
fi

testset=$1
HEXFILE="`ls -lt ${testset}/out/*.hex | head -n 1 | gawk '{print $9}'`"
PYFILE="`ls -lt ${testset}/out/*.py | head -n 1 | gawk '{print $9}'`"

echo -n "Run CForest..."
${CFDIR}/${CFBIN} --scr ${PYFILE} --hex ${HEXFILE} --debug --max 320000 --msglvl INF --memini FF > ${testset}/cf_ff.log
${CFDIR}/${CFBIN} --scr ${PYFILE} --hex ${HEXFILE} --debug --max 320000 --msglvl INF --memini 00 > ${testset}/cf_00.log

if [ $? -ne 0 ]
then
    echo "error! @ CForest(${HEXFILE:%.hex})"
    exit 1
fi
echo "ok!"
