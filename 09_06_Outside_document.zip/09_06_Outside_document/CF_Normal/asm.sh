#!/bin/bash

FROG_TOOLDIR=/shsv/SoftIP/13_frog/02_projects/06_environment/GNU/v850_gnu_Dec_11_2015/v850-renesas-elf/bin
cpp $1.S | ${FROG_TOOLDIR}/as -mv850e3v5 -v -mg4mh -mfpsimd -mextension -o $1.o
${FROG_TOOLDIR}/ld -T./$1.x -Map $1.map --section-start .vector=0x00000000 -Ttext 0x00000000 -Tdata 0xfec00000 -o $1.elf  ./$1.o
${FROG_TOOLDIR}/objcopy -Osrec --srec-forceS3 $1.elf $1.hex
${FROG_TOOLDIR}/objdump -D -t $1.elf > $1.lst

if [ $? -ne 0 ]; then
    echo "Asm fail to generate hex."
	exit 1
fi

cat init_CForest_g4mh_1pe_head.py > $1.py
grep "_async_" $1.lst > $1.temp1
awk -F " " '{print $1 "_" $5;}' $1.temp1 > $1.temp2
awk -F "_" '{
	if($5 == "assert") {
		if($6 == "eiint" || $6=="eitbl") {
			print "set_event(0x" $1 ",\"" $6 "\"" ",0x" $7 ",0x" $9 ",\"P0NC\", " $10 ")";
		} else if ($6 == "feint") {
			print "set_event(0x" $1 ",\"" $6 "\",0x" $7 ",\"P0NC\", " $9 ")";
		} else if ($6 == "fenmi") {
			print "set_event(0x" $1 ",\"" $6 "\",\"P0NC\", " $8 ")";
		} else if ($6 == "dbint") {
			print "set_event(0x" $1 ",\"" $6 "\",0x" $7 ", " $9 ")";
		} else if ($6 == "dbnmi") {
			print "set_event(0x" $1 ",\"" $6 "\",\"P0NC\", " $8 ")";
		} else if ($6 == "syserr") {
			print "set_event(0x" $1 ",\"" $6 "\",0x0010, " $8 ")";
		} else if ($6 == "rmint") {
			print "set_event(0x" $1 ",\"" $6 "\", " $8 ")";
		}
	} else if ($5 == "deassert") {
		print "set_clear_event(0x" $1 ",\"" $6 "\",\"P0NC\", " $8 ")";
	}
}' $1.temp2 >> $1.py
cat init_CForest_g4mh_1pe_tail.py >> $1.py
rm $1.o
rm $1.elf
rm $1.map
rm $1.temp*

