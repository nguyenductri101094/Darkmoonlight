# -*- coding: utf-8 -*-
set_has_mpu ("on");
set_has_fxu ("on");
set_peripherals ("no_ipir_mecnt_barrier");

set_peinfo(0, 'g4mh')
set_mpunum (24);

# set external pins
#set_peid (0, "P0NC")
#set_bmid (0, "P0NC")
#set_spidlist (0xFFFFFFFF, "P0NC")
#set_spid (0, "P0NC")
#set_mpudmdp (1, "P0NC")


#error_area_set (0x20000000, 0x2000FFFF)
#error_area_clear (0x20000000)

setreg("RBASE", 0)

rom_fetch_latency (12)
ms (0x00000000, 0x01ffffff, "RX",  8,  8, CFDEF_GLOBAL, 4, 4) #FlashROM
ms (0xfe000000, 0xfeffffff,        5,  8, CFDEF_GLOBAL, 4, 2) #L2RAM
ms (0xfdc00000, 0xfddfffff,        2,  5, 0, 4, 1) #L1RAM PE0

self_set (0xfde00000, 0xfdffffff, -0x00200000) #L1RAM self
self_set (0xfffc0000, 0xfffc3fff,  0x00004000) #Local Peripheral self (INTC1)
self_set (0xfffe0000, 0xffffffff, -0x00002000) #self area for perfcnt and result_register
#reset()
#max(0x00FFFFFF)
#load("")
#run()
#q()
