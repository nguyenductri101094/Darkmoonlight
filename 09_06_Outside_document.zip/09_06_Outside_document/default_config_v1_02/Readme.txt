Note for users to write G4MH20's configuration by referring to this default configuration:

1) Frog.run:
	+ Don't set random_handler option because it is removed from FROG's source code
	+ Use weight.profile file instead of sample.profile
	
2) weight.profile:
	+ Don't delete or comment out any instructions (set weight to zero in this case)
	
3) sreg.profile: Please be careful when setting these system register:
	+ RBIP: Set "NO" to Write permission because FROG doesn't support write permission to this register
	+ EBASE, GMEBASE: Do not set user initial value to this register (field 8 should be blank) 
	+ HVCFG: 
		Do not randomize initial value of bit HVCFG.HVE (field 14 should be blank).
		Value of this bit depend on initial mode in weight.profile (CV or GM#x)
	+ GMMPCFG: Set "NO" to Write permission because FROG doesn't support update bit GMMPCFG.HBE by LDSR.
	+ EIWR, FEWR, GMEIWR, GMFEWR: Set "NO" to Read/Write permission because these registers is used for back up resource.
	+ EIPC, FEPC, FPEPC, CTPC, DBPC, GMEIPC, GMFEPC: 
		User can set "YES" to Read permission.
		But, when testing by Legacy FROG, Read permission of these register will be disabled.
	+ CTBP, EBASE, INTBP, SCBP, GMEBASE, GMINTBP:
		User can set "YES" to Write permission.
		But, when testing by Legacy FROG, Write permission of these register will be disabled.
	
4) Please inform FROG team if there are any registers need adding/removing