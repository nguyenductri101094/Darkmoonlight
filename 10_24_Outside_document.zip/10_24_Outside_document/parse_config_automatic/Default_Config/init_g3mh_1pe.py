force_l1mirr = 0
pe1_peid = 1
pe2_peid = 2
set_has_simd ("on");
set_has_mpu ("on");
set_has_mmu ("off");
# set_peripherals ("on");
set_peripherals ("no_ipir_mecnt");
#set_misr_log ("on");

set_peinfo(pe1_peid, 1, 1, 'g3mh')
#set_peinfo(pe2_peid, 1, 1, 'g3mh')  # if Dual-PE environment, please comment out this line
set_mcfg0 (0x00010000)
set_mpunum (16);

rom_fetch_latency (11)
ms (0x00000000, 0x01ffffff, "RX",  8,  8, 0, 3, 3) #FlashROM
ms (0xfee00000, 0xfeffffff,        5,  8, 0, 4, 2) #GRAM
ms (0xfc000000, 0xfddfffff,        5,  8, 0, 4, 2) #EMU

if force_l1mirr == 1:
    if pe1_peid==1 or pe2_peid==1 :
        ms (0xfea00000, 0xfebfffff,        2,  5, 1, 4, 1) #LRAM/TCM PE1 (SlaveErr)
    if pe1_peid==2 or pe2_peid==2 :
        ms (0xfe800000, 0xfe9fffff,        2,  5, 2, 4, 1) #LRAM/TCM PE2 (SlaveErr)
    if pe1_peid==3 or pe2_peid==3 :
        ms (0xfe600000, 0xfe7fffff,        2,  5, 3, 4, 1) #LRAM/TCM PE3 (SlaveErr)
    if pe1_peid==4 or pe2_peid==4 :
        ms (0xfe400000, 0xfe5fffff,        2,  5, 4, 4, 1) #LRAM/TCM PE4 (SlaveErr)
    if pe1_peid==5 or pe2_peid==5 :
        ms (0xfe200000, 0xfe3fffff,        2,  5, 5, 4, 1) #LRAM/TCM PE5 (SlaveErr)
    if pe1_peid==6 or pe2_peid==6 :
        ms (0xfe000000, 0xfe1fffff,        2,  5, 6, 4, 1) #LRAM/TCM PE6 (SlaveErr)
    if pe1_peid==7 or pe2_peid==7 :
        ms (0xfde00000, 0xfdffffff,        2,  5, 7, 4, 1) #LRAM/TCM PE7 (SlaveErr)
else:
    if pe1_peid==1 or pe2_peid==1 :
        ms (0xfea00000, 0xfeb7ffff, "RX",  2,  5, 1, 4, 1) #LRAM/TCM PE1 (SlaveErr)
        ms (0xfeb80000, 0xfebfffff,        2,  5, 1, 4, 1) #LRAM/TCM PE1
    if pe1_peid==2 or pe2_peid==2 :
        ms (0xfe800000, 0xfe97ffff, "RX",  2,  5, 2, 4, 1) #LRAM/TCM PE2 (SlaveErr)
        ms (0xfe980000, 0xfe9fffff,        2,  5, 2, 4, 1) #LRAM/TCM PE2
    if pe1_peid==3 or pe2_peid==3 :
        ms (0xfe600000, 0xfe77ffff, "RX",  2,  5, 3, 4, 1) #LRAM/TCM PE3 (SlaveErr)
        ms (0xfe780000, 0xfe7fffff,        2,  5, 3, 4, 1) #LRAM/TCM PE3
    if pe1_peid==4 or pe2_peid==4 :
        ms (0xfe400000, 0xfe57ffff, "RX",  2,  5, 4, 4, 1) #LRAM/TCM PE4 (SlaveErr)
        ms (0xfe580000, 0xfe5fffff,        2,  5, 4, 4, 1) #LRAM/TCM PE4
    if pe1_peid==5 or pe2_peid==5 :
        ms (0xfe200000, 0xfe37ffff, "RX",  2,  5, 5, 4, 1) #LRAM/TCM PE5 (SlaveErr)
        ms (0xfe380000, 0xfe3fffff,        2,  5, 5, 4, 1) #LRAM/TCM PE5
    if pe1_peid==6 or pe2_peid==6 :
        ms (0xfe000000, 0xfe17ffff, "RX",  2,  5, 6, 4, 1) #LRAM/TCM PE6 (SlaveErr)
        ms (0xfe180000, 0xfe1fffff,        2,  5, 6, 4, 1) #LRAM/TCM PE6
    if pe1_peid==7 or pe2_peid==7 :
        ms (0xfde00000, 0xfdf7ffff, "RX",  2,  5, 7, 4, 1) #LRAM/TCM PE7 (SlaveErr)
        ms (0xfdf80000, 0xfdffffff,        2,  5, 7, 4, 1) #LRAM/TCM PE7

#xdump_data (0xffff7ff0, 0xffff7fff, 0xffffffff)
#xdump_data (0xfffeedf0, 0xfffeedff, 0xffffffff)
#xdump_fpu  (247, 0x01)   # 244=rsqrtf.s
#xdump_fpu  (248, 0x01)   # 243=rsqrtf.d

# set_misr_log ("on")

# Set Reference memory
#         [cl,pe]  [logical] => [physical]   [size]
self_set (0xfec00000, 0xfedfffff, -0x200000)

#             [BlkSiz][LimitLines]
#set_comprunner(   100,   10)

#load ("")

reset()
