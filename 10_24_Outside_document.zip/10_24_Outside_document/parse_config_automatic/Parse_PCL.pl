#!/usr/bin/perl -w

use strict;
use warnings;
use Spreadsheet::ParseExcel;

#init input default
#my $default_dir = "Default_Config";
my $default_dir = shift @ARGV;
my $Sample_default = $default_dir.'/sample.profile';
my $Sreg_default = $default_dir.'/sreg.profile';
my $Sim_default;
my $Usercode_default = $default_dir.'/usercode.S';
my $Option_default = $default_dir.'/Frog.run';
my $Sim_init_file ='simulator.py';

my @Sample_input =read_input($Sample_default);
my @Sreg_input =read_input($Sreg_default);
my @Sim_input;
my @Usercode_input =read_input($Usercode_default);
my @Option_input =read_input($Option_default);


# init Reading Excel file
#my $Excel_path = 'PCL_Template2.xls';					# for ex: "PCL_templete.xls"
my $Excel_path = shift @ARGV;

my $parser   = Spreadsheet::ParseExcel->new();
my $workbook = $parser->parse($Excel_path);

if (!defined $workbook) {
   die $parser->error(), ".\n";
}
my $worksheet1 = $workbook->worksheet('PCL');					# Get worksheet 'PCL'
my $worksheet2 = $workbook->worksheet('Instruction_Set');		# Get worksheet 'Instruction_Set'
my $worksheet3 = $workbook->worksheet('UserCode');				# Get worksheet 'UserCode'

my ($row_min, $row_max) = $worksheet1->row_range();
my ($col_min, $col_max) = $worksheet1->col_range();

my $row;
my $col;

# Get number of BR
my $num_BR =0;
$col = 13;					# Column 'N'
$row = 3;						# Row 4
my $cell = $worksheet1->get_cell($row, $col);
my $text = $cell->unformatted();
my $pattern_name = $text;

while ($text eq $pattern_name) {
#while ($text ne "") {
	$col ++;
	$cell = $worksheet1->get_cell($row, $col);
	next unless $cell;
	$text = $cell->unformatted();
	$num_BR ++;
}

# input file flags
my $weigh_file =0;
my $sreg =0;
my $simulator =0;
my $user_code =0;
my $option =0;

# weigh_file flags
my $instruction_global =0;
my $machine_setting =0;
my $rom_address =0;
my $ram_address =0;
my $exception_global =0;
my $fpu_single =0;
my $fpu_double =0;
my $mxu =0;
my $mpu =0;
my $current_simulator;
my @simulator_list;
my $current_option;
my @option_list;


# get each cell and store each row to @Data_table
my @Data_table;	
for $row ($row_min .. $row_max) {
	for $col ($col_min .. $col_max) {
        $cell = $worksheet1->get_cell($row, $col);
        next unless $cell;
		my $unformatted = $cell->unformatted();
		$Data_table[$row][$col] =  $unformatted;
    }
}
###########################################################################################
# get instruction_id, instruction_label from Instruction_Set
($row_min, $row_max) = $worksheet2->row_range();
($col_min, $col_max) = $worksheet2->col_range();
my %Ins_id;													#**************************For next*******************
my %Ins_label;												#**************************For next*******************
my %Ins_weight;												#**************************For next*******************
my %Exp_weight;												#**************************For next*******************
my %FPU_single_weight;										#**************************For next*******************
my %FPU_double_weight;										#**************************For next*******************

for ($row =3; $row < ($row_max+1); $row++) {	
	$cell = $worksheet2->get_cell($row, 9);			# Get cell of instruction id
	next unless $cell;
	my $id = remove_all_space($cell->unformatted());
	$cell = $worksheet2->get_cell($row, 10);			# Get cell of instruction name
	my $name = $cell->unformatted();
	$Ins_id{$id} = $name;
}

for ($row =3; $row < ($row_max+1); $row++) {	
	$cell = $worksheet2->get_cell($row, 1);			# Get cell of instruction id
	next unless $cell;
	my $id = remove_all_space($cell->unformatted());
	$cell = $worksheet2->get_cell($row, 2);			# Get cell of instruction name
	my $label = $cell->unformatted();
	push @{$Ins_label{$Ins_id{$id}}}, remove_all_space($label);
}



########################################################################################
# Get User functions from usercode
($row_min, $row_max) = $worksheet3->row_range();
($col_min, $col_max) = $worksheet3->col_range();
my $function_flag =0;
my %function_table;											#**************************For next*******************
my $function_label;
my %function_weight;										#**************************For next*******************	

for $row ($row_min .. $row_max) {
	if ($function_flag ==0) {															# Get the row has function_label
		$cell = $worksheet3->get_cell($row, 0);
		next unless $cell;
		
		$function_label = $cell->unformatted();
		if ($function_label ne "") {
			if (substr($function_label, 0, length("-- ::")) eq "-- ::") {
				my @split_arr =split(',', $function_label);
				$function_label = $split_arr[0];
				$split_arr[1] =substr($split_arr[1], 1, length($split_arr[1])-1);
				push @{$function_weight{$function_label}}, $split_arr[1];
				$function_flag =1;
				next;
			}
		}
	} else {
		$cell = $worksheet3->get_cell($row, 1);											
		unless ($cell) {
			$function_flag =0;
			next;
		}
		if ($cell->unformatted() ne "") {
			push @{$function_table{$function_label}}, $cell->unformatted();
		} else {
			$function_flag =0;
		}		
	}
}

#### check something
my $check_path = "check.txt";
my $Outcheck_file;
open ($Outcheck_file, ">", "$check_path");
for my $component(keys %function_weight) {
	print $Outcheck_file "$component";
	print $Outcheck_file ", ${$function_weight{$component}}[0]\n";
	my @array = @{$function_table{$component}};
	#my @array = @{$function_weight{$component}};
	foreach (@array) {
		print $Outcheck_file "$_\n";
	}
}
close($Outcheck_file);
####

#######################################################################################
($row_min, $row_max) = $worksheet1->row_range();
($col_min, $col_max) = $worksheet1->col_range();

for (my $i=0; $i < $num_BR; $i++) {

# Sequence process
my @sample_table;						#**************************For next*******************
my @ins_global_table;					#**************************For next*******************
my @machine_setting_table;				#**************************For next*******************
my @rom_add_table;						#**************************For next*******************
my @ram_add_table;						#**************************For next*******************
my @exp_global_table;					#**************************For next*******************
my @fpu_single_table;					#**************************For next*******************
my @fpu_dbl_table;						#**************************For next*******************
my @mxu_table;							#**************************For next*******************
my @mpu_table;							#**************************For next*******************
my @sreg_table;							#**************************For next*******************
my @simulator_table;					#**************************For next*******************
my @usr_code_table;						#**************************For next*******************
my @option_table;						#**************************For next*******************

for $row ($row_min .. $row_max) {
	if ($Data_table[$row][2] eq "WEIGHT FILE") {
		$weigh_file = 1;
	} elsif ($Data_table[$row][2] eq "SREG CONFIG") {
		$mpu =0;
		$weigh_file = 0;
		$sreg =1;
		next;
	} elsif ($Data_table[$row][2] eq "SIMULATOR") {
		$sreg =0;
		$simulator =1;
	} elsif ($Data_table[$row][2] eq "USER CODE") {
		$simulator =0;
		$user_code =1;
	} elsif ($Data_table[$row][2] eq "OPTION") {
		$user_code =0;
		$option =1;
	} elsif ($Data_table[$row][1] eq "OUTPUT" && $Data_table[$row][2] ne "") {
		$option =0;
	}
	if ($weigh_file) {
		if ($Data_table[$row][3] eq "::INSTRUCTION_GLOBAL") {
			$instruction_global =1;
			push @ins_global_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::MACHINE_SETTING") {
			$instruction_global = 0;
			$machine_setting =1;
			push @machine_setting_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::ROM_ADDRESS") {
			$machine_setting =0;
			$rom_address =1;
			push @rom_add_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::RAM_ADDRESS") {
			$rom_address =0;
			$ram_address =1;
			push @ram_add_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::EXCEPTION_GLOBAL") {
			$ram_address =0;
			$exception_global =1;
			push @exp_global_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::FPU_SINGLE_DATA_TYPE") {
			$exception_global = 0;
			$fpu_single =1;
			push @fpu_single_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::FPU_DOUBLE_DATA_TYPE") {
			$fpu_single =0;
			$fpu_double =1;
			push @fpu_dbl_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::MXU_COMMON_AREA") {
			$fpu_double =0;
			$mxu =1;
			push @mxu_table, $Data_table[$row][3];
			next;
		} elsif ($Data_table[$row][3] eq "::MPU_SETTING") {
			$mxu =0;
			$mpu =1;
			push @mpu_table, $Data_table[$row][3];
			next;
		}
	}
	my $line;
	if ($weigh_file) {
		if ($instruction_global) {
			$line = $Data_table[$row][3].",".remove_all_space($Data_table[$row][10]).",".remove_all_space($Data_table[$row][11]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
			my @list_ins_label = @{$Ins_label{$Data_table[$row][3]}};					# Get Ins name
			
			foreach (@list_ins_label) {
				push @{$Ins_weight{$_}}, remove_all_space($Data_table[$row][10]);
				push @{$Ins_weight{$_}}, remove_all_space($Data_table[$row][11]);
				push @{$Ins_weight{$_}}, remove_all_space($Data_table[$row][12]);
				push @{$Ins_weight{$_}}, remove_all_space($Data_table[$row][13+$i]);
				my @list =@{$Ins_weight{$_}};
				if (scalar @list > 4) {
					shift @{$Ins_weight{$_}};
					shift @{$Ins_weight{$_}};
					shift @{$Ins_weight{$_}};
					shift @{$Ins_weight{$_}};
				}
			}
			push @ins_global_table, $line;
		} elsif ($machine_setting) {
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][5]).",".remove_all_space($Data_table[$row][7]).",".remove_all_space($Data_table[$row][9]).",".remove_all_space($Data_table[$row][11]).','.$Data_table[$row][13+$i];
			push @machine_setting_table, $line;
		} elsif ($rom_address) {
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][5]).",".remove_all_space($Data_table[$row][7]).",".remove_all_space($Data_table[$row][9]).",".remove_all_space($Data_table[$row][11]).','.$Data_table[$row][13+$i];
			push @rom_add_table, $line;
		} elsif ($ram_address) {
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][5]).",".remove_all_space($Data_table[$row][7]).",".remove_all_space($Data_table[$row][9]).",".remove_all_space($Data_table[$row][11]).','.$Data_table[$row][13+$i];
			push @ram_add_table, $line;
		} elsif ($exception_global) {
			push @{$Exp_weight{remove_all_space($Data_table[$row][3])}}, remove_all_space($Data_table[$row][12]);
			push @{$Exp_weight{remove_all_space($Data_table[$row][3])}}, remove_all_space($Data_table[$row][13+$i]);
			if (scalar @{$Exp_weight{remove_all_space($Data_table[$row][3])}} > 2) {
				shift @{$Exp_weight{remove_all_space($Data_table[$row][3])}};
				shift @{$Exp_weight{remove_all_space($Data_table[$row][3])}};
			}
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
			push @exp_global_table, $line;
		} elsif ($fpu_single) {
			push @{$FPU_single_weight{remove_all_space($Data_table[$row][3])}}, remove_all_space($Data_table[$row][12]);
			push @{$FPU_single_weight{remove_all_space($Data_table[$row][3])}}, remove_all_space($Data_table[$row][13+$i]);
			if (scalar @{$FPU_single_weight{remove_all_space($Data_table[$row][3])}} > 2) {
				shift @{$FPU_single_weight{remove_all_space($Data_table[$row][3])}};
				shift @{$FPU_single_weight{remove_all_space($Data_table[$row][3])}};
			}
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
			push @fpu_single_table, $line;
		} elsif ($fpu_double) {
			push @{$FPU_double_weight{remove_all_space($Data_table[$row][3])}}, remove_all_space($Data_table[$row][12]);
			push @{$FPU_double_weight{remove_all_space($Data_table[$row][3])}}, remove_all_space($Data_table[$row][13+$i]);
			if (scalar @{$FPU_double_weight{remove_all_space($Data_table[$row][3])}} > 2) {
				shift @{$FPU_double_weight{remove_all_space($Data_table[$row][3])}};
				shift @{$FPU_double_weight{remove_all_space($Data_table[$row][3])}};
			}
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
			push @fpu_dbl_table, $line;
		} elsif ($mxu) {
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][6]).",".remove_all_space($Data_table[$row][8]).",".remove_all_space($Data_table[$row][11]).','.$Data_table[$row][13+$i];
			push @mxu_table, $line;
		} elsif ($mpu) {
			$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][4]).",".remove_all_space($Data_table[$row][5]).",".remove_all_space($Data_table[$row][6]).",".remove_all_space($Data_table[$row][8]).",".remove_all_space($Data_table[$row][9]).",".remove_all_space($Data_table[$row][10]).",".remove_all_space($Data_table[$row][11]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
			push @mpu_table, $line;
		} 
	} elsif ($sreg) {
		$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][4]).",".remove_all_space($Data_table[$row][5]).",".remove_all_space($Data_table[$row][6]).",".remove_all_space($Data_table[$row][7]).",".remove_all_space($Data_table[$row][8]).",".remove_all_space($Data_table[$row][9]).",".remove_all_space($Data_table[$row][10]).",".remove_all_space($Data_table[$row][11]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
		push @sreg_table, $line;
	} elsif ($simulator) {
		if ($Data_table[$row][3] ne "") {
			push @simulator_list, $Data_table[$row][3];
			$current_simulator = remove_all_space($Data_table[$row][3]);
		}	
		#$line = $Data_table[$row][3].",".$Data_table[$row][12].','.$Data_table[$row][13+$i];
		$line = $current_simulator.",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
		push @simulator_table, $line;
	} elsif ($user_code) {
		$line = remove_all_space($Data_table[$row][3]).",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
		push @usr_code_table, $line;
	} elsif ($option) {
		if ($Data_table[$row][3] ne "") {
			push @option_list, remove_all_space($Data_table[$row][3]);
			$current_option = remove_all_space($Data_table[$row][3]);
		}		
		#$line = $Data_table[$row][3].",".$Data_table[$row][12].','.$Data_table[$row][13+$i];
		$line = $current_option.",".remove_all_space($Data_table[$row][12]).','.$Data_table[$row][13+$i];
		if (($current_option eq "sim_ini_file") && ($Data_table[$row][13+$i] eq 'O')) {
			$Sim_init_file = remove_all_space($Data_table[$row][12]);
			#print "$Sim_init_file\n";
			$Sim_default = $default_dir.'/'.$Sim_init_file;
			@Sim_input = read_input($Sim_default);
		}
		push @option_table, $line;
	} 
	
}

# Output

my $Output_file;
my $index = $i+1;
#my $dir ="BR"."$index";
my $dir = $pattern_name."$index";
mkdir $dir, 0777;
# Sample
my $Sample_path;

$Sample_path = "$dir/"."sample.profile";
open ($Output_file, ">", "$Sample_path");
my $count=0;
=break
foreach (@ins_global_table) {
	print $Output_file "$_\n";
	$count++;
}
=cut
=break
print $Output_file "$ins_global_table[0]\n";
for my $component(keys %Ins_weight) {
	print $Output_file "   $component,";
	my @array = @{$Ins_weight{$component}};
	foreach (@array) {
		print $Output_file "$_,";
	}
	print $Output_file "\n";
}
=cut
my $machine_sec =0;
my $rom_sec =0;
my $ram_sec =0;
my $fpu_sig_sec =0;
my $fpu_dbl_sec =0;
my $mxu_sec =0;
my $mpu_sec =0;
my $insert =0;

foreach (@Sample_input) {
	if (find_num_of_substr($_,"::FPU_SINGLE_DATA_TYPE") >0) {
		#$ram_sec =0;
		$fpu_sig_sec =1;
	} elsif (find_num_of_substr($_, "::FPU_DOUBLE_DATA_TYPE") > 0) {
		$fpu_sig_sec =0;
		$fpu_dbl_sec =1;
	} elsif (find_num_of_substr($_, "::MXU_COMMON_AREA") > 0) {
		$fpu_dbl_sec =0;
		$mxu_sec=1;
		#print "$_\n";
	} elsif (find_num_of_substr($_, "::MACHINE_SETTING") > 0) {
		$machine_sec =1;
	} elsif (find_num_of_substr($_, "::ROM_ADDRESS") > 0) {
		$machine_sec =0;
		$rom_sec =1;
	} elsif (find_num_of_substr($_, "::RAM_ADDRESS") > 0) {
		$rom_sec =0;
		$ram_sec =1;
	} elsif (find_num_of_substr($_, "::MPU_SETTING") > 0) {
		#$mxu_sec =0;
		$mpu_sec =1; 
		#print "$_\n";
	} 
	my $print =$_;
	if (find_num_of_substr($_, "Ins_") > 0) {							# Instruction
		my $line_change;
		my @pos =find_position($_, "Ins_");
		my @pos2;
		my $have_comment =0;		
		my $line_last = substr($_, $pos[0], length($_)-$pos[0]);		# Read line from "Ins_" to the end of line
		if (find_num_of_substr($line_last, "//") > 0) {
			@pos2 = find_position($line_last, "//");					# Find "//" if there
			$line_last= substr($line_last, 0, $pos2[0]);				# Get string from "Ins_" to before "//"
			$have_comment =1;			
		}
		my @split_ins_line = split(",", $line_last);
		my $Ins_found = remove_all_space($split_ins_line[0]);
		if (check_key_appear($Ins_found, %Ins_weight)) {
			my @weight_array = @{$Ins_weight{$Ins_found}};					# Get weight and some info of Ins found
			if (scalar @weight_array >3) {
				if ($weight_array[3] eq 'O') {
					$line_change = "$Ins_found       ";
					$line_change .=" , $weight_array[0]";
					$line_change .=" , $weight_array[1]";
					$line_change .=" , $weight_array[2]  ";
					if ($have_comment) {
						$print = substr($print, 0, $pos[0])."$line_change   ".substr($print, $pos2[0]+$pos[0], length($print)-$pos2[0]-$pos[0]);
					} else {
						$print = substr($print, 0, $pos[0])."$line_change";
					}
				} 
			}
		}
	} elsif (find_num_of_substr($_, "Exp_") > 0) {						# Exception
		my $line_change;
		my @pos =find_position($_, "Exp_");
		my @pos2;
		my $have_comment =0;
		my $line_last = substr($_, $pos[0], length($_)-$pos[0]);		# Read line from "Exp_" to the end of line
		if (find_num_of_substr($line_last, "//") > 0) {
			@pos2 = find_position($line_last, "//");					# Find "//" if there
			$line_last= substr($line_last, 0, $pos2[0]);				# Get string from "Exp_" to before "//"
			$have_comment =1;
		}
		my @split_ins_line = split(",", $line_last);
		my $Exp_found = remove_all_space($split_ins_line[0]);
		
		if (scalar @{$Exp_weight{$Exp_found}} >1) {
			if ($Exp_weight{$Exp_found}[1] eq 'O') {
				$line_change = "$Exp_found       ";
				$line_change .="    ,  $Exp_weight{$Exp_found}[0]  ";
				if ($have_comment) {
					$print = substr($print, 0, $pos[0])."$line_change".substr($print, $pos2[0]+$pos[0], length($print)-$pos2[0]-$pos[0]);
				} else {
					$print = substr($print, 0, $pos[0])."$line_change";
				}
			}
		}
	} elsif ($fpu_sig_sec) {								# FPU single data
		my $line_change;
		if (find_num_of_substr($_, ',') > 0) {
			my @pos =find_position($_, ",");
			my @pos2;
			my $have_comment =0;
			my $left = substr($_, 0, $pos[0]);
			if (find_num_of_substr($_, "//") > 0) {
				@pos2 = find_position($_, "//");					# Find "//" if there
				$have_comment =1;
			}
			$left =remove_all_space($left);
			my @fpu_list=@{$FPU_single_weight{$left}};
			if (scalar @fpu_list > 1) {
				if ($fpu_list[1] eq "O") {
					$line_change = "$left       ";
					$line_change .=",  $FPU_single_weight{$left}[0]  ";
					if ($have_comment) {
						$print = "        $line_change".substr($print, $pos2[0], length($print)-$pos2[0]);
					} else {
						$print = "        $line_change";
					}
				}
			}
		}
	} elsif ($fpu_dbl_sec) {
		my $line_change;
		if (find_num_of_substr($_, ',') > 0) {
			my @pos =find_position($_, ",");
			my @pos2;
			my $have_comment =0;
			my $left = substr($_, 0, $pos[0]);
			if (find_num_of_substr($_, "//") > 0) {
				@pos2 = find_position($_, "//");					# Find "//" if there
				$have_comment =1;
			}
			$left =remove_all_space($left);
			my @fpu_list=@{$FPU_double_weight{$left}};
			if (scalar @fpu_list > 1) {
				if ($fpu_list[1] eq "O") {
					$line_change = "$left       ";
					$line_change .=",  $FPU_double_weight{$left}[0]  ";
					if ($have_comment) {
						$print = "        $line_change".substr($print, $pos2[0], length($print)-$pos2[0]);
					} else {
						$print = "        $line_change";
					}
				}
			}
		}
	} elsif ($machine_sec) {
		if($_ eq "//-----------------------------------------------" && $insert == 0) {
			$insert =1;
		} elsif ($insert==1) {
			$count =0;
			foreach (@machine_setting_table) {
				my @current_split = split(",", $_);
				if ($count >1 && (scalar @current_split > 5)) {
					pop @current_split;
					print $Output_file "    "; 
					print $Output_file join ',              ', @current_split; 
					print $Output_file "\n"; 
				}				
				$count++;
			}
			$insert =2;
		} elsif ($_ eq "//-----------------------------------------------" && $insert == 2) {
			$insert =0;
			$machine_sec =0;
		}
	} elsif ($rom_sec) {
		if($_ eq "//-----------------------------------------------" && $insert == 0) {
			$insert =1;
		} elsif ($insert==1) {
			$count =0;
			foreach (@rom_add_table) {
				my @current_split = split(",", $_);
				if ($count >1 && (scalar @current_split > 5)) {
					pop @current_split;
					print $Output_file "    "; 
					print $Output_file join ',   ', @current_split; 
					print $Output_file "\n"; 
				}				
				$count++;
			}
			$insert =2;
		} elsif ($_ eq "//-----------------------------------------------" && $insert == 2) {
			$insert =0;
			$rom_sec=0;
		}
	} elsif ($ram_sec) {
		if($_ eq "//-----------------------------------------------" && $insert == 0) {
			$insert =1;
		} elsif ($insert==1) {
			$count =0;
			foreach (@ram_add_table) {
				my @current_split = split(",", $_);
				if ($count >1 && (scalar @current_split > 5)) {
					pop @current_split;
					print $Output_file "    "; 
					print $Output_file join ',   ', @current_split; 
					print $Output_file "\n"; 
				}				
				$count++;
			}
			$insert =2;
		} elsif ($_ eq "//-----------------------------------------------" && $insert == 2) {
			$ram_sec =0;
			$insert =0;
		}
	} elsif ($mxu_sec) {
		if($_ eq "//-----------------------------------------------" && $insert == 0) {
			$insert =1;
		} elsif ($insert==1) {
			$count =0;
			foreach (@mxu_table) {
				my @current_split = split(",", $_);
				if ($count >1 && (scalar @current_split > 4)) {
					pop @current_split;
					print $Output_file "    "; 
					print $Output_file join ',   ', @current_split; 
					print $Output_file "\n"; 
				}				
				$count++;
			}
			$insert =2;
		} elsif ($_ eq "//-----------------------------------------------" && $insert == 2) {
			$mxu_sec=0;
			$insert =0;
		}
		
	} elsif ($mpu_sec) {	
		if($_ eq "//-------------------------------------------------------------------------------------------------" && $insert == 0) {
			$insert =1;
		} elsif ($insert==1) {
			$count =0;
			foreach (@mpu_table) {
				my @current_split = split(",", $_);
				if ($count >1 && (scalar @current_split > 9)) {
					pop @current_split;
					print $Output_file "     "; 
					print $Output_file join ',       ', @current_split; 
					print $Output_file "\n"; 
				}				
				$count++;
			}
			$insert =2;
		} elsif ($_ eq "//-------------------------------------------------------------------------------------------------" && $insert == 2) {
			$mpu_sec=0;
			$insert =0;
		}
	}	
	print $Output_file "$print" unless ($insert == 2);
	print $Output_file "\n" unless ($insert == 2);
}
=break
$count=0;
foreach (@machine_setting_table) {
	print $Output_file "$_\n" if $count != 1;
	$count++;
}
$count=0;
foreach (@rom_add_table) {
	print $Output_file "$_\n" if $count != 1;
	$count++;
}
$count=0;
foreach (@ram_add_table) {
	print $Output_file "$_\n" if $count != 1;
	$count++;
}
$count=0;
foreach (@exp_global_table) {
	print $Output_file "$_\n";
	$count++;
}
$count=0;
foreach (@fpu_single_table) {
	print $Output_file "$_\n";
	$count++;
}
$count=0;
foreach (@fpu_dbl_table) {
	print $Output_file "$_\n";
	$count++;
}
$count=0;
foreach (@mxu_table) {
	print $Output_file "$_\n" if $count != 1;
	$count++;
}
$count=0;
foreach (@mpu_table) {
	print $Output_file "$_\n" if $count != 1;
	$count++;
}
=cut
close($Output_file);

# Sreg
my $Sreg_path = "$dir/"."sreg.profile";
open ($Output_file, ">", "$Sreg_path");
$count=0;
my @Sreg_output;
### Parse Sreg Input, use @Sreg_input
foreach (@Sreg_input) {
	my $current_line = $_;
	my @array_split = split(',', $current_line);
	my $Register_name = $array_split[2];			# register name, for ex: EIPC
	my $insert_line;
	my $fix_line ='0';
	my $break_flag =0;
	foreach (@sreg_table) {	
		my @split = split(',', $_);
		if (scalar @split > 10) {
			if (($split[0] eq $Register_name) && ($split[10] eq 'O')) {
				$array_split[4] = $split[1];
				$array_split[5] = $split[2];
				$array_split[6] = $split[3];
				$array_split[7] = $split[4];
				$array_split[8] = $split[5];
				$array_split[9] = $split[6];
				$array_split[10] = $split[7];
				$array_split[11] = $split[8];
				$array_split[13] = $split[9];
				$fix_line ='';
				my $array_count=0;
				foreach (@array_split) {
					if (defined $_) {
						$fix_line .= $_;
					}
					if ($array_count != (scalar @array_split -1)) {
						$fix_line .=',';
					}
					$array_count ++;
				}
				
				push @Sreg_output, $fix_line;
				last;
			}
		}
	}
	if ($fix_line eq '0') {
		push @Sreg_output, $current_line;
	}
}
###
=break
foreach (@sreg_table) {	
	print $Output_file "$_\n";
	$count++;
}
=cut
foreach (@Sreg_output) {	
	print $Output_file "$_\n";
	$count++;
}
close($Output_file);

# Simulator
my $Sim_path = "$dir/"."$Sim_init_file";
open ($Output_file, ">", "$Sim_path");
$count=0;
=break
foreach (@simulator_table) {
	print $Output_file "$_\n";
	$count++;
}
=cut
foreach (@Sim_input) {
	if (find_num_of_substr($_,"set_has_simd") > 0) {
		foreach (@simulator_table) {
		my @sim_split =split(',', $_);
		#if ($Sim_init_file eq "init_g3mh_1pe.py") {
			if (scalar @sim_split > 2) {
				if (($sim_split[2] eq "O") && ($sim_split[1] eq "ON")) {
					print $Output_file "set_has_simd (\"on\");\n";
					last;
				} elsif (($sim_split[2] eq "O") && ($sim_split[1] eq "OFF")) {
					print $Output_file "set_has_simd (\"off\");\n";
					last;
				}
			}
		#}
		}
	} else {
			print $Output_file "$_\n";
	}
}
=break
foreach (@simulator_table) {
	my @sim_split =split(',', $_);
	if ($Sim_init_file eq "init_g3mh_1pe.py") {
		if (scalar @sim_split > 2) {
			if (($sim_split[2] eq "O") && ($sim_split[1] eq "ON")) {
				print $Output_file "set_has_simd (\"on\");\n";
				last;
			} elsif (($sim_split[2] eq "O") && ($sim_split[1] eq "OFF")) {
				print $Output_file "set_has_simd (\"off\");\n";
				last;
			}
		}
	} else {
		print $Output_file "# Not G3MH\n";
		last;
	}
}
=cut
close($Output_file);

# User code
my $usr_path = "$dir/"."usercode.S";
open ($Output_file, ">", "$usr_path");
$count=0;

foreach (@Usercode_input) {
	print $Output_file "$_\n";
} 
print $Output_file "\n";
	
foreach (@usr_code_table) {
	my @user_split =split(',', $_);
	if (scalar @user_split > 2) {
		print $Output_file "// ----------------------------------------------------------------\n";
		my $func_name = "-- ::".$user_split[0];
		print $Output_file "$func_name";
		print $Output_file ", ${$function_weight{$func_name}}[0]";
		#print $Output_file "$user_split[2]\n";
		print $Output_file "\n";
		print $Output_file "// ----------------------------------------------------------------\n";
		my @array = @{$function_table{$func_name}};
		foreach (@array) {
			if (scalar @user_split > 2) {
				print $Output_file "$_\n";
			}
		}
		print $Output_file "\n";
	}
	$count++;
}

close($Output_file);

# Option
my %Option_Out;
my $Opt_path = "$dir/"."Frog.run";
open ($Output_file, ">", "$Opt_path");
$count=0;


foreach (@option_table) {
	my @option_split =split(',', $_);
	my $Option_name = "--".$option_split[0];
	if (scalar @option_split > 2) {
		if (($option_split[2] eq 'O') && ($option_split[0] ne 'NumberofPattern')) {
			$Option_Out{$Option_name} = $option_split[1];
			#print $Output_file "$Option_name   $Option_Out{$Option_name}  \\";
			#print $Output_file "\n";
		}
	}	
	#print $Output_file "$_\n";
	#$count++;
}
my @have_insert;
foreach (@Option_input) {
	my $current_line = $_;
	my $Option = $current_line;
	my $fix = $current_line;
	my $key;
	
	foreach $key (keys %Option_Out) {
		if (substr($Option, 0, length($key)) eq $key) {
			push @have_insert, $key;		
			if ($key eq "--sim_ini_file") {
				$fix = "$key     ./$Option_Out{$key}  \\";
			} else {
				$fix = "$key     $Option_Out{$key}  \\";
			}
			last;
		}
	}
	if (substr($Option, 0, length("--usercode")) eq "--usercode") {
		foreach $key (keys %Option_Out) {
			my $found =0;
			my $current_option = $key;
			foreach (@have_insert) {
				if ($_ eq $current_option) {
					$found =1;
					last;
				}
			}
			if (!$found) {
				print $Output_file "$current_option     $Option_Out{$current_option}  \\";
				print $Output_file "\n";
			}
		}
	}
	print $Output_file "$fix\n";		
}

close($Output_file);

}

 #----------------------------
# Some basic functions
# Designed by: Nguyen Quoc Huy
# #----------------------------
# #
# Find all starting index of the $substr in $str
# for ex: $str="abcdeaafaabca", $substr="ab" -> $pos=0;9
sub find_position{
	my ($str, $substr)=@_;
	my @position_list;
	my $pos = -1;
	while (1) {
		$pos = index($str, $substr, $pos + 1);
		last if $pos < 0;
		push @position_list, $pos;
	}
	return @position_list;
}
# #----------------------------
# Find the number of $substr in $str
# for ex: $str="abcdeaafaabca", $substr="ab" -> $num=2
sub find_num_of_substr{
	my ($str, $substr)=@_;
	my $num = 0;
	my @out_list=find_position($str,$substr);
	foreach (@out_list){
		$num++;
	}
	return $num;
}

# #----------------------------
# Remove all whitespace in $str
sub remove_all_space {
	my ($str) =@_;
	my $str_out;
	#$str =~ s/(?<!\w) //g;
	if ($str ne "") {
		my @split = split("", $str);
		foreach (@split) {
			if ($_ ne " ") {
				$str_out .= $_;
			}
		}
	} else {
		$str_out =$str;
	}
	return $str_out;
}

sub read_input {
	my ($Input) = @_;
	my @Out;
	open (my $Input_file, "<", "$Input");
	while(my $line = <$Input_file>) {
		chomp ($line);
		push @Out, $line;
	}
	close ($Input_file);
	return @Out;
}

sub check_key_appear {
	my ($Key_check, %In_hash)= @_;
	for my $key (keys %In_hash) {
		if ($key eq $Key_check) {
			return 1;
		}
	}
	return 0;
}