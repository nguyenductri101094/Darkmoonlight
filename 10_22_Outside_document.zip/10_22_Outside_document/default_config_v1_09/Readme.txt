Note for users to write G4MH20's configuration by referring to this default configuration:

1) Frog.run:
	+ Don't set random_handler option because it is removed from FROG's source code
	+ Use weight.profile file instead of sample.profile
	+ Reduce value of --block_num or --inum_in_block (from 64 to 32) if the number of Virtual machines is greater than 4. Another solution is expand I area in ::ROM_ADDESS, ::RAM_ADDRESS (weight.profile)
	
2) weight.profile:
	+ Don't delete or comment out any instructions (set weight to zero in this case) except ::BREAK_GLOBAL (if neccessary)
	+ Do not set ratio to interrupt BGxxINT when only run 1 Virtual machine 
	
3) sreg.profile: Please be careful when setting these system register:
	+ RBIP: 
		Set "NO" to Write permission because FROG doesn't support write permission to this register
	+ EBASE, GMEBASE: 
		Do not set user initial value to this register (field 8 should be blank) 
	+ HVCFG: 
		Do not randomize initial value of bit HVCFG.HVE (field 14 should be blank).
		Value of this bit depend on initial mode in weight.profile (CV or GM#x) and option set_has_hv("xxx") in file .py (2 files)
	+ GMMPCFG: 
		Set "NO" to Write permission because FROG doesn't support update bit GMMPCFG.HBE by LDSR.
	+ EIPC, FEPC, FPEPC, CTPC, DBPC, GMEIPC, GMFEPC: 
		User can set "YES" to Read permission.
		But, when testing by Legacy FROG, Read permission of these register will be disabled.
	+ CTBP, EBASE, INTBP, SCBP, GMEBASE, GMINTBP:
		User can set "YES" to Write permission.
		But, when testing by Legacy FROG, Write permission of these register will be disabled.
	+ MPM, GMMPM:
		Do not set user initial value (field 8 should be blank) of these register.
		Because if MPU function is enabled before setting MPU register (MPUA, MPLA, MPAT), MIP will be loop.
	+ HVSB:
		Set "NO" to Write permission in case of running many Virtual machine (there are more than 1 GM); because in this case, FROG need to use HVSB register to record information.
	+ ICTAGL, ICTAGH, ICDATL, ICDATH:
		Set "NO" to Read permission, because there is mismatch when cache instruction is executed (limitation)
	
4) Please inform FROG team if there are any registers need adding/removing