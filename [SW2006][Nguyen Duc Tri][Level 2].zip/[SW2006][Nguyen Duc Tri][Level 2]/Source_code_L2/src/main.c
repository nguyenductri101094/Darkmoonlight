/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "timer.h"


/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define switch_button (unsigned char *) 0xFFF07
#define COUNTING (unsigned int) 0
#define PAUSING  (unsigned int) 1
#define LAST_PAGE (uint8_t) 16
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern unsigned int time_flag;
extern unsigned int centisec;
time_t display_time;
memory_t memory_lcd[20];
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void reset_time_display(void);
int eliminate_chattering();
void init_switch(void);
int check_start_condition (void);
void counting_up(time_t *display_time_p);
void save_record(time_t *display_time_p);
void display_record();

unsigned char sw = 0xF7;
unsigned char sw_previous = 0xF7;
unsigned char sw1_confirm = 0xFF;
unsigned char sw2_confirm = 0xFF;
unsigned char sw3_confirm = 0xFF;

unsigned char time_display[7];//Display the watch
unsigned int match_time;//match time to eliminate chattering SW1, SW2
volatile unsigned int sw_flag = 0;//Inform that sw update
unsigned int record = 0;
unsigned int index = 1;
uint8_t page = 0;
unsigned int last_record_flag = 1;
unsigned int first_record_flag = 1;

volatile unsigned int check = 0;//Counting for timer
unsigned int mode = 1;
unsigned int mode_pre = 1;
char string_record[13];

unsigned int temp_centisec;
/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Initialize user system */
	r_main_userinit();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Initialize switch */
	init_switch();

	/* Print message to the first line of LCD */
	DisplayLCD(LCD_LINE1, (uint8_t *)"Exercise L2!");
	
	/*init timer*/
	timer_init();
	timer_start();
	
	temp_centisec = 0;
	
	/* Main loop - Infinite loop */
	while (1) 
	{
		/* Eliminate chattering of 3 switches */
		if (time_flag == 1){
		if (1 == eliminate_chattering()){
			
		/* counting mode */
		if ((0 == sw3_confirm) && (mode == COUNTING)){
			save_record(&display_time);
			if (record <=6){
				page = 1;
				display_record();
			}
			else if (last_record_flag == 1){
				display_record();
				if (page != LAST_PAGE) page++;
			}
		}
		if ((0 == sw3_confirm) && (mode == PAUSING)){
			DisplayLCD(LCD_LINE1, (uint8_t *)"Running...");
			mode = COUNTING;
			if (mode_pre == PAUSING) centisec = temp_centisec;
		}
		if ((0 == sw1_confirm) && (0 == sw2_confirm) && (mode == COUNTING)){
			DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing...");
			mode = PAUSING;
			mode_pre = PAUSING;
			temp_centisec = centisec;
		}
		if ((0 == sw1_confirm) && (0 == sw2_confirm) && (mode == PAUSING)){
			DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing...");
			mode = PAUSING;
		}
		
		}
		time_flag = 0;
		}
		if (0 == (centisec%10)){
			if (mode == COUNTING) counting_up(&display_time);
		}
	}

}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;
	
	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}

/******************************************************************************
* Function Name: reset_time_display
* Description  : Set LCD-> 00:00
* Arguments    : none
* Return Value : none
******************************************************************************/
void reset_time_display(void){
	time_display[0] = 0x30;
	time_display[1] = 0x30;
	time_display[2] = 0x3A;
	time_display[3] = 0x30;
	time_display[4] = 0x30;
	time_display[5] = ' ';
	time_display[6] = 0x00;
	DisplayLCD(LCD_LINE2, (const uint8_t*)time_display);
}

/******************************************************************************
* Function Name: check_start_condition
* Description  : Check if LCD show 00:00; return 0 for 00:00; 1 for the rest -> enable counter
* Arguments    : none
* Return Value : 0; 1
******************************************************************************/
int check_start_condition (void){
	if ((0x30 == time_display[0]) && (0x30 == time_display[1]) && (0x30 == time_display[3]) && (0x30 == time_display[4])){
		return 0;
	}
	else {
		return 1;
	}
}

/******************************************************************************
* Function Name: init_switch
* Description  : init switch: SW1, SW2, SW3
* Arguments    : none
* Return Value : none
******************************************************************************/
void init_switch(void){
	PM7_bit.no4 = 1;
	PM7_bit.no5 = 1;
	PM7_bit.no6 = 1;
}

/******************************************************************************
* Function Name: eliminate_chattering
* Description  : eliminate chattering of switch
* Arguments    : none
* Return Value : none
******************************************************************************/
int eliminate_chattering(){
	if (match_time >= 3){
		match_time = 0;		
		sw1_confirm = (sw & 0x40)>>6;// get the value of sw1
		sw2_confirm = (sw & 0x10)>>4;// get the value of sw2			
		sw3_confirm = (sw & 0x20)>>5;// get the value of sw3
		sw_previous = sw;
		return 1;
	}
	sw = *switch_button;
	if (sw != sw_previous){
		match_time++;	
	}
	else {
		match_time = 0;
	}
	return 0;
}


/******************************************************************************
* Function Name: counting_up
* Description  : 
* Arguments    : 
* Return Value : none
******************************************************************************/
void counting_up(time_t *display_time_p){
	char display_string[8];
	display_time_p->centisecond = (uint8_t)(centisec%100U);
	display_time_p->second = (uint8_t)((centisec/100U)%60);
	display_time_p->minute = (uint8_t)((centisec/100U)/60);
	sprintf(display_string, "%0.2d:%0.2d:%0.2d",display_time_p->minute,display_time_p->second,display_time_p->centisecond);
	DisplayLCD(LCD_LINE2,(uint8_t*)display_string);
}

/******************************************************************************
* Function Name: save_record
* Description  : 
* Arguments    : 
* Return Value : none
******************************************************************************/
void save_record(time_t *display_time_p){
	unsigned int i;
	if (20 == record){
		for (i=0;i<19;i++){
			memory_lcd[i].centisecond = memory_lcd[i+1].centisecond;
			memory_lcd[i].second = memory_lcd[i+1].second;
			memory_lcd[i].minute = memory_lcd[i+1].minute;
		}
		record = 19;
	}
	memory_lcd[record].centisecond = display_time_p->centisecond;
	memory_lcd[record].second = display_time_p->second;
	memory_lcd[record].minute = display_time_p->minute;
	memory_lcd[record].index = index;
	record++;
	index++;	
}

/******************************************************************************
* Function Name: display_record
* Description  : 
* Arguments    : 
* Return Value : none
******************************************************************************/
void display_record(){
	uint8_t i;
	uint8_t pos = 0;
	if (record<=6){
		for (i=0;i<record;i++){
			sprintf(string_record, "#%0.2d:%0.2d:%0.2d:%0.2d",memory_lcd[i].index,memory_lcd[i].minute,memory_lcd[i].second,memory_lcd[i].centisecond);
			DisplayLCD((pos+2)*8,(uint8_t*)string_record);
			pos++;
		}
	}
	else{
		for (i=page;i<=(page+5);i++){
			sprintf(string_record, "#%0.2d:%0.2d:%0.2d:%0.2d",memory_lcd[i].index,memory_lcd[i].minute,memory_lcd[i].second,memory_lcd[i].centisecond);
			DisplayLCD((pos+2)*8,(uint8_t*)string_record);
			pos++;
		}
	}
}

/******************************************************************************
End of file
******************************************************************************/

