/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "timer.h"


/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define switch_button (unsigned char *) 0xFFF07
#define COUNTING (unsigned int) 0
#define PAUSING  (unsigned int) 1
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern unsigned int time_flag;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void reset_time_display(void);
int eliminate_chattering();
void init_switch(void);
int check_start_condition (void);
void increase_setting(unsigned char* time_display_count_first,unsigned char* time_display_count_second);
void increase_index();

unsigned char sw = 0xF7;
unsigned char sw_previous = 0xF7;
unsigned char sw1_confirm = 0xFF;
unsigned char sw2_confirm = 0xFF;
unsigned char sw3_confirm = 0xFF;
volatile unsigned char sw3_confirm_pre = 0xFF;

unsigned char time_display[7];//Display the watch
static uint8_t lcd_buffer[] = "#\W    ";
unsigned int match_time;//match time to eliminate chattering SW1, SW2
volatile unsigned int sw_flag = 0;//Inform that sw update
volatile unsigned int record = 0; //

volatile unsigned int current = 1;
volatile unsigned int previous = 1;

volatile unsigned int check = 0;//Counting for timer
unsigned int mode = 1;
uint8_t index_number = 0;
uint8_t line_lcd = 0;
//char display_lcd[];
uint8_t memory_list[20];

int check_start;//Return value to check the situation 00:00 

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Initialize user system */
	r_main_userinit();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Initialize switch */
	init_switch();

	/* Print message to the first line of LCD */
	DisplayLCD(LCD_LINE1, (uint8_t *)"Exercise L2!");
	reset_time_display();
	
	/*init timer*/
	timer_init();
	timer_start();
	
	/* Main loop - Infinite loop */
	while (1) 
	{
		/* Eliminate chattering of 3 switches */
		if (time_flag == 1){
		if (1 == eliminate_chattering()){
			
		/* counting mode */
		if ((0 == sw3_confirm) && (mode == PAUSING)){
			DisplayLCD(LCD_LINE1, (uint8_t *)"Running...");
			sw_flag = 0;
			//DisplayLCD(LCD_LINE2, );
			mode = COUNTING;
		}
		if ((0 == sw3_confirm) && (mode == COUNTING)){
			increase_index();
			DisplayLCD(line_lcd, (const uint8_t*)lcd_buffer);
			sw_flag = 0;
		}
		if ((0 == sw1_confirm) && (0 == sw2_confirm) && (mode == COUNTING)){
			DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing...");
			sw_flag = 0;
			mode = PAUSING;
		}
		if ((0 == sw1_confirm) && (0 == sw2_confirm) && (mode == PAUSING)){
			ClearLCD();
			DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing...");
			reset_time_display();
			sw_flag = 0;
			mode = PAUSING;
		}
		
		}
		time_flag = 0;
		}
	}

}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;
	
	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}

/******************************************************************************
* Function Name: reset_time_display
* Description  : Set LCD-> 00:00
* Arguments    : none
* Return Value : none
******************************************************************************/
void reset_time_display(void){
	time_display[0] = 0x30;
	time_display[1] = 0x30;
	time_display[2] = 0x3A;
	time_display[3] = 0x30;
	time_display[4] = 0x30;
	time_display[5] = ' ';
	time_display[6] = 0x00;
	DisplayLCD(LCD_LINE2, (const uint8_t*)time_display);
}

/******************************************************************************
* Function Name: check_start_condition
* Description  : Check if LCD show 00:00; return 0 for 00:00; 1 for the rest -> enable counter
* Arguments    : none
* Return Value : 0; 1
******************************************************************************/
int check_start_condition (void){
	if ((0x30 == time_display[0]) && (0x30 == time_display[1]) && (0x30 == time_display[3]) && (0x30 == time_display[4])){
		return 0;
	}
	else {
		return 1;
	}
}

/******************************************************************************
* Function Name: init_switch
* Description  : init switch: SW1, SW2, SW3
* Arguments    : none
* Return Value : none
******************************************************************************/
void init_switch(void){
	PM7_bit.no4 = 1;
	PM7_bit.no5 = 1;
	PM7_bit.no6 = 1;
}

/******************************************************************************
* Function Name: eliminate_chattering
* Description  : eliminate chattering of switch
* Arguments    : none
* Return Value : none
******************************************************************************/
int eliminate_chattering(){
	if (match_time >= 3){
		match_time = 0;		
		sw1_confirm = (sw & 0x40)>>6;// get the value of sw1
		sw2_confirm = (sw & 0x10)>>4;// get the value of sw2			
		sw3_confirm = (sw & 0x20)>>5;// get the value of sw3
		sw_previous = sw;
		return 1;
	}
	sw = *switch_button;
	if (sw != sw_previous){
		match_time++;	
	}
	else {
		match_time = 0;
	}
	return 0;
}


/******************************************************************************
* Function Name: increase_setting
* Description  : increase 00 -> 59 and 59 + 1 = 00
* Arguments    : unsigned char* time_display_count_first, unsigned char* time_display_count_second
* Return Value : none
******************************************************************************/
void increase_setting(unsigned char* time_display_count_first, unsigned char* time_display_count_second){
	if ((*time_display_count_second < 0x39) && (*time_display_count_first <= 0x35)){
		*time_display_count_second = *time_display_count_second + 0x01;	
	}
	else if ((0x39 == *time_display_count_second) && (0x35 == *time_display_count_first)){
		*time_display_count_second = 0x30;
		*time_display_count_first = 0x30;
	}
	else {
		*time_display_count_first = *time_display_count_first + 0x01;
		*time_display_count_second = 0x30;
	}	
}

/******************************************************************************
* Function Name: increase_index
* Description  : 
* Arguments    : 
* Return Value : none
******************************************************************************/
void increase_index(){
	index_number++;
	if (index_number < 10){
		lcd_buffer[1] = index_number + 0x30;
	}
	else{
		lcd_buffer[1] = index_number/10;
		lcd_buffer[2] = index_number%10;
	}
	if (index_number < 9){
		line_lcd = (index_number-1)*8+16;
	}
	else {
			
	}
}

/******************************************************************************
End of file
******************************************************************************/

