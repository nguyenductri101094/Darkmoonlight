#ifndef		RTG_TYPES_H_
#define		RTG_TYPES_H_

typedef		__uint128_t				UI128;
typedef		unsigned long long int	UI64;
typedef		unsigned int			UI32;
typedef		unsigned short			UI16;
typedef		unsigned char			UI8;

typedef		signed long long int	SI64;
typedef		signed int				SI32;
typedef		signed short			SI16;
typedef		signed char				SI8;
typedef		char*					LPSTR;
typedef		const char*				LPCTSTR;
typedef		const char* const		LPCTCSTR;
typedef		unsigned int			INS_ID;
typedef     unsigned long long int  MEMADDR;
typedef     uint32_t				LADDR;
typedef		uint32_t				REGFLG; // 汎用レジスタ３２本を1ビットのフラグ集合
typedef     std::pair<MEMADDR, MEMADDR>	MEMRANGE;
typedef     std::pair<MEMADDR, UI32>	MEMDATA32;
typedef     std::pair<MEMADDR, UI16>	MEMDATA16;
typedef     std::pair<MEMADDR, UI8>		MMDATA8;
typedef     std::pair<MEMADDR, UI8>	    MEMBITS;
typedef		std::pair<UI32,UI32>        SYSREG;		/* Pair of <SelID, RegID> */
typedef		std::pair<UI32,std::pair<UI32,UI64>> T_MEMWRRECORD;
typedef		struct {
					UI32	m_type ;
					UI64	m_address ;
					UI32	m_size;
					bool	m_isNt ;
					UI32	m_tcid ;
					UI32 	m_status ;
			}	T_LLBITRECORD;

typedef		UI32 T_MP_SETTING[32][3];

enum {
    NO_ERROR = 0,
    VIOLATE_HOST_ENTRY,
    VIOLATE_GUEST_ENTRY,
    VIOLATE_CONVENTION_ENTRY,
};


// Epilogue
typedef		std::vector<UI32>			GRSET;
typedef		std::vector<GRSET>			GRLST;
typedef		std::vector<UI64>			VRSET;
typedef		std::vector<VRSET>			VRLST;
typedef		UI32						BKREG; // 31-16:Bank, 15-0:RegID
typedef		std::pair<BKREG, UI32>		SRVAL;
typedef		std::vector<SRVAL>			SRSET;
typedef		std::vector<SRSET>			SRLST;
typedef		std::pair<UI32, UI32>		GRVAL;
typedef		std::vector<GRVAL>			GRVALSET;

// template <typename T_container, typename T_function>
// T_function for_each(T_container& rcontainer, T_function function) {
//     return std::for_each(rcontainer.begin(), rcontainer.end(), function);
// }
namespace frog {
	template <typename T_container, typename T_function>
	T_function for_each(std::unique_ptr<T_container>& pcontainer, T_function function) {
	    return std::for_each(pcontainer->begin(), pcontainer->end(), function);
	}
};

#endif	// RTG_TYPES_H_
