#ifndef RTG_CFG_H_
#define RTG_CFG_H_

#include	"rtg_common.h"

#define         TIMEOUT     200

/**
 * @brief	クオート文字の定義構造体
 */
struct CQuote{
    char    start;  // 開始文字
    char    end;    // 終了文字
    char    escape; // エスケープ文字
    CQuote( char start_, char end_, char escape_) :
         start(start_), end(end_), escape(escape_) {}
};


struct CCmpStartQuote : public std::binary_function<CQuote,char,bool> {
    bool operator()(const CQuote &l_s1, const char &l_s2) const {
        return l_s1.start == l_s2;
    }
};

/**
* @brief	Input information of each virtual machine
*/
struct GM_Infor {
	UI32 GMID;
	std::string machine_mode;
	std::string thread_context;
	std::string thread_mode;
	bool master_thread;
};
/**
 * @brief	静的な汎用関数をメンバに持つツールクラスです。
 */
class CToolFnc {
	
private:
	CToolFnc(){}
	
public:

	/**
	 * @brief  文字列を数値に変換します。失敗時は0を返します。
	 * @param  lpctstr 文字列ポインタ
	 * @return 変換された数値
	 */
	template <typename TYPE>
	static TYPE Convert(LPCTSTR lpctstr) throw (std::invalid_argument) {   
		std::string str(lpctstr);
		std::istringstream	is(str);   
 		TYPE type = 0;   
 		if (!str.empty()) {   
			is >> type;
		}
		return type;
	}   

	/**
	 * @brief  文字列を数値に変換します。失敗時は例外をスローします。
	 * @param  s 文字列ポインタ
	 * @return 変換された数値
	 */
	static unsigned int AtoI (LPCTSTR s) throw (std::invalid_argument) {
		std::stringstream	ss;
		std::string			str(s);
		UI32				val;
		int					len = str.length();
		
		if (len < 1) {
			throw std::invalid_argument(s);
		}
		transform (str.begin (), str.end (), str.begin (), tolower);
		if(str.compare(0, 2, "0x") == 0) {
			for (int p = 2; p < len; p++) {
				if ((str.at(p) < '0' || str.at(p) > '9') && (str.at(p) < 'a' || str.at(p) > 'f')) {
					throw std::invalid_argument(s);
				}
			}
			ss << std::hex << str.substr(2, str.length() - 2);
		} else {
			for (int p = 0; p < len; p++) {
				if (str.at(p) < '0' || str.at(p) > '9') {
					throw std::invalid_argument(s);
				}
			}
			ss << std::dec << str;
		}
		ss >> val;
		return (unsigned int)val;
	}

	/**
	 * @brief  ストリングトークンナイザです。
	 *         区切り文字により入力文字列を分割しトークンをベクターへ格納します。
	 * @param  result    結果が格納されるベクター
	 * @param  i         入力走査する文字列
	 * @param  separator 区切り文字列 
	 * @param  quotes    トークンのクオート指定
	 * @return 失敗した場合、偽を返す
	 */
	static bool ReadCSV(
	    std::vector< std::string > &result, // 結果格納ベクター
	    std::istreambuf_iterator<char> &i,  // 入力文字イテレータ
	    std::string &separator,             // 区切り文字
	    std::vector<CQuote> &quotes)        // クオート文字ベクター
	{
	    bool retval = false;
	    result.clear();
	    std::string item;
	    char    bc = '\0';
	    bool    first = true;
	    std::istreambuf_iterator<char> eos;
	    std::vector<CQuote>::iterator    ff = quotes.end();
	
	    while ( (i != eos) && (ff != quotes.end() || *i != '\n') ) {

	        if ( ff == quotes.end() && strchr( separator.c_str(), *i) != 0 ) {
	            // on separator char
	            result.push_back(item);
	            item.clear();
	            first = true;
	            retval = true;
	        } else {
	        	if ( first && (ff = find_if( quotes.begin(), quotes.end(), bind2nd( CCmpStartQuote(), *i))) != quotes.end() ) {
	            	// Quote hit
	                first = false;
	            } else if ( ff != quotes.end() && ff->end == *i ) {
	                if ( ff->end == ff->escape ) {
	                    bc = *i++;
	                    if ( i == eos )
	                        break;
	                    if ( *i == ff->end ) {
	                        item.push_back(*i);
	                    } else {
	                        ff = quotes.end();
	                        continue;
	                    }
	                } else {
	                    if ( bc == ff->escape ) {
	                        item.push_back(*i);
	                    } else {
	                        ff = quotes.end();
	                    }
	                }
	            } else {
	                item.push_back(*i);
	                first = false;
	            }
	        }
	        bc = *i++;
	    }
	    result.push_back(item);
	    if ( i != eos ) {
	        retval = true;
	        i++;
	    }
	    return retval;
	}

	/**
	 * @brief 文字列の先頭と最後のスペースを除去
	 */
	static std::string Trim(const std::string& str)
	{
	    std::string::const_iterator head, tail;
	
	    if (str.length() < 1)
	    {   
	        return std::string("");
	    }   
	    head = str.begin();
	    tail = str.end();
	
	    while (isspace(*head))
	    {   
	        head++;
	    }   
	    if (head != tail)
	    {   
	        do
	        {
	            tail--;
	        }
	        while (isspace(*tail));
	        tail++;
	    }   
	
	    return std::string(head, tail);
	}
};


/**
 * @brief	ジェネレータの設定を管理するクラスです。
 *          コマンドラインオプションの解析を行い、設定値を保持します。
 */
class CGeneratorConfig
{
public:

	/**
	 * @brief  このオブジェクトを構築します。
	 */
	CGeneratorConfig() :
		m_nSeed(0),
		m_nPeId(0),
		m_nSysPeNum(0),
		m_nPeWorkIdx(0),
		m_strSelfCheck(),
		m_strSimIni(),
		m_strProfile(),
		m_strUserProfile(),
		m_strOutputAsm("out_%seed%.S"),
		m_strSrProfile(),
		m_strUsercode(),
		m_bRecCode(true),
		m_nBlockNum(16),
		m_nBlockMix(2),
		m_nFetchSize(64),
		m_bPrefAssist(false),
		m_nINumInBlock(40),
		m_nMaxLoop(3),
		m_nMaxRegInBlock(32),
		m_nRanHandler(0),
		m_nTimeout(TIMEOUT),
		m_bFrontRegs(true),
		m_bVerbose(false),
		m_bStatistics(false),
		m_bOutputEnFlag(true),
        m_mGMs()
	{}

	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual ~CGeneratorConfig() {}
	
	/**
	 * @brief  コマンドラインを解析します。
	 * @param  argc パラメータカウント
	 * @param  argv パラメータ配列
	 * @param  env  環境変数配列
	 * @return 成功した場合、真を返します。
	 */
	 bool Parse(int argc, char** argv, char** env = NULL);

	/**
	 * @brief  設定パラメータを出力します。
	 * @param  str パラメータカウント
	 * @param  o   出力先
	 * @return 成功した場合、真を返します。
	 */	 
	std::ostream& Print(std::string* str = NULL, std::ostream& o = std::cout);

	void RenameOutfile();
	
	/**
	 * @brief  設定パラメータを出力します。
	 * @param  str パラメータカウント
	 * @param  o   出力先
	 * @retrun 成功した場合、真を返します。
	 */	 
	 //UI32 Print(std::ostream& o);

	/**
	 * @brief  使用方法を出力します。
	 * @param  o   出力先
	 * @return 成功した場合、真を返します。
	 */	 
	void Usage(std::ostream& o);

	/**
	 * @brief  設定パラメータを出力します。
	 */	 
	std::map<std::string,std::string>*	CreateHash(void);

	/**
	 * @brief Print RTG version
	 */
	void PrintVersion(std::ostream& o);
	
	
	UI32 GetBLockNum(){
		return m_nBlockNum;
	}

public:
	UI32			m_nSeed;				//<! @brief 乱数のシード
	UI32			m_nPeId;				//<! @brief プロセッサＩＤ(値)
	UI32			m_nSysPeNum;			//<! @brief 同期をとるプロセッサ数（マスタとなる）
	UI32			m_nPeWorkIdx;			//<! @brief PEの作業インデックス

	std::string		m_strSelfCheck;			//<! @brief セルフチェックコードの生成
	std::string		m_strSimIni;			//<! @brief シミュレータ用の初期設定ファイルパス
	std::string		m_strProfile;			//<! @brief 命令重み設定ファイル
	std::string		m_strUserProfile;
	std::string		m_strOutputAsm;			//<! @brief 出力ソースパス
	std::string		m_strOutputMap;			//<! @brief 出力マップファイル
	std::string		m_strSrProfile;			//<! @brief システムレジスタ設定
	std::string		m_strUsercode;			// path to user code (for attached only)
	bool			m_bRecCode;
	UI32			m_nBlockNum;			//<! @brief ブロック数
	UI32			m_nBlockMix;			//<! @brief MIXタイプ
	UI32			m_nFetchSize;
	bool			m_bPrefAssist;			//<! @brief ランダム部を実行前に命令キャッシュにまとめて取り込む
	UI32			m_nINumInBlock;			//<! @brief ブロックあたりの命令数
	UI32			m_nMaxLoop;				//<! @brief 最大ループカウンタ
	UI32			m_nMaxRegInBlock;		//<! @brief Specify maximum of register used in each random code block
	UI32			m_nRanHandler;			//<! @brief Option for generating random instruction in handler
	UI32			m_nTimeout;             //<! @brief Time of of execution
	bool			m_bFrontRegs;			//<! @brief 補正命令を前倒しに調整する
	bool			m_bVerbose;				//<! @brief 生成ログの出力
	bool			m_bStatistics;			//<! @brief 出力コードカバレッジファイルパス
	bool			m_bOutputEnFlag;
	std::map<UI32, GM_Infor> m_mGMs;		//<! @brief list information of each guest machine, key is GM id

private:
	static const std::string	optstr;
	static const struct option	opts[];
};


/**
 * @brief	ジェネレータの設定を管理するクラスです。
 *          重み設定ファイルの解析を行います。
 */
class CGeneratorProfile
{
public:
	typedef std::vector<std::string> CsvRow;					// １行のデータ（文字列の配列）
	typedef std::vector<CsvRow> SectionData;					// 行のデータの配列
	typedef std::string SectionName;
	typedef std::string SectionKey;
	typedef	std::pair<SectionName, SectionData> Section;		// 名前と行データのペア
	typedef	std::map<SectionName, SectionData>	SectionMap;		// <名前,行データ>のMAP
	
    CGeneratorProfile(): m_is_mpu(false) {}
	virtual	~CGeneratorProfile();
	
	// file
	bool	LoadProfile(std::string& filepath);
	bool	LoadMasterFile();
	CsvRow	Split(std::string& str, const std::string& key);
	bool	IsSectionKey(std::string& str);
	static bool	FindCh(const std::string& str, const char* ch); 
	static std::string Trim(const std::string& s);
	
	//
	SectionData& GetSectionData(const std::string& s);
    void InsSection(const SectionName& s, const SectionData& sd);
	

    // ＰＥにＶＭ試験が指定されていたら true を返す。
	bool	IsVmSimulation ();
    // 指定したＶＭにマルチスレッド試験が指定されていたら true を返す。
    bool    IsMtSimulation (UI32 vcid);
	// 指定したスレッドにユーザモード試験が指定されていたら true を返す。
	bool	IsUserMode(bool isGm , UI32 gmid);

    // 指定したＶＭのマスタースレッドの同期待ちおよび終了待ち番号を返す
    UI32    GetMasterThreadNo (UI32 vcid) ;
    // 指定したスレッドの同期待ちおよび終了待ち番号を返す
    UI32    GetWaitThreadNo (UI32 htid) ;
    // 指定したPE中で同期待ち、終了待ちを行なうスレッド数
    UI32    GetWaitThreadNum () ;

    // MachineSetting設定に誤りが無いことをチェックする。誤りが無ければ true を返す。
    bool    ParseMachineSetting (std::map<UI32, GM_Infor>* GMs);
    // MachineSetting設定を表示する。
    void    PrintMachineSetting ();

	// FPU_S data type
	bool	ConfigFpuSingletype();

	// FPU_D data type
	bool	ConfigFpuDoubletype();
	
	//

    /**
    *  @brief check memory range from addr to (addr + size) have belong to load memory or not.
    *  @return true if it belong to load memory
    */
    bool    IsLoadMem(MEMADDR addr, UI32 size);

	bool	IsInSconst(MEMADDR addr);

	bool	IsValidMem(MEMADDR addr);
	
	// Check whether memory address belongs to PE sharing area.
	bool	IsShareMem(MEMADDR addr);

	bool	IsTempMem(MEMADDR addr);
	
	void	dump(std::ostream& os);

	// Check whether MPU region is worked for MIP/MDP config by region index
	bool	IsWorkMPURegionByIdx(UI32 region);
	
    // m_mpdemand[0], m_mpcommon[0] : manage guest entries or entries of convention mode
    // m_mpdemand[1], m_mpcommon[1] : manage host entries
	UI32	m_mpdemand[2];  //<! @brief reserve some channel to temporally protection when exception occur
                            // 16 bits high: MIP exception; bit 10 - 15: MDP auto save ; bit 5 - 9: MDP reference table; bit 0 - 4: MDP operand access 
	UI32	m_btid[9];		//<! @brief ブロックあたりの命令数
	UI32	m_mpcommon[2];	//<! @brief 16 bits high: Rom area; 16 bits low: Ram area
    bool    m_is_mpu;       //fail if mpu isn't reserved
protected:
	SectionMap	m_sec;
};

#endif /*RTG_CFG_H_*/
