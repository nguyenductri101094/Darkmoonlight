#include "ifsim_ctrl.h"
#include "sim_ctrl.h"
#include "sim_ctrl_stat.h"
#include "asm_src.h"

extern std::shared_ptr<CGeneratorConfig>		g_cfg;		 
extern std::shared_ptr<CAssemblerSourceFile>    g_asf;

ISimulatorControl* ISimulatorControl::New() {

    if (g_cfg->m_bStatistics) {
		return new CSimulatorControl_stat();
    } else {
	    return new CSimulatorControl();
    }

}


std::string ISimulatorControl::GetVersion() {
	return (m_pSim != NULL) ? m_pSim->GetSimulatorVersion() : std::string("");
}


std::string ISimulatorControl::GetName() {
	return (m_pSim != NULL) ? m_pSim->GetName() : std::string("");
}

UI32 ISimulatorControl::GenerateBreakPointBeforeSetup(IBlockSimParam* p, IInstruction* pIns,CCodeBlock* pBlk) { return 0;}
void ISimulatorControl::GenerateBreakPointSetup(IBlockSimParam* p, IInstruction* pIns,CCodeBlock* pBlk) {}
void ISimulatorControl::GenerateBreakPointSetupBlock(IBlockSimParam* bsp) {}
#if 0
void ISimulatorControl::GenerateBreakPointSetupBlock(IBlockSimParam* bsp) {
	std::vector<INode*>&    vHB = g_asf->GetHandlerBlock();

	std::for_each (vHB.begin(), vHB.end(), [](INode* node) {
                                           CCodeBlock* p = static_cast<CCodeBlock*>(node);
					   if( p->GetName().find("breaksetup") != std::string::npos ) {
						   std::fprintf(stdout,"Found debug_breaksetup handler!!\n");
					   }
				   }); 

        CCodeBlock* pHB = nullptr;
        for( std::vector<INode*>::iterator itr = vHB.begin(); itr != vHB.end(); itr++ ) {
                pHB = static_cast<CCodeBlock*>(*itr);
                if( pHB->GetName().find("breaksetup") != std::string::npos ) {
		   std::fprintf(stdout,"Found debug_breaksetup handler!!\n");
		}

        }

	for( std::vector<IBreakParam >::iterator itr = bsp->pBreakParam.begin(); itr != bsp->pBreakParam.end(); itr++ ) {
		std::fprintf(stdout,"type:%d addr:%08x mask:%08x block:%08x\n",(*itr).m_type,(*itr).m_addr,(*itr).m_addr_mask,(*itr).m_block_addr);
	}
	bsp->pBreakParam.clear();
}
#endif

bool ISimulatorControl::Simulation(ISimulationParam* p) {
	
	std::string check_point;
	
	_ASSERT(p);
	_ASSERT(m_pSim);
	_ASSERT(p->pAsmSrcObj);
	
	CAssemblerSourceFile*	pAf	= p->pAsmSrcObj;
	IBlockSimParam			bsp;
	bsp.pException = p->pException;
	
	while (true) {
		
		// PC update and Search target block (implement for each core).
		if (ReadySimulation(p, &bsp) != true) {
			return false;
		}

		// New checkpoint name and Block needed to regulate. 
		if (check_point != bsp.pCodeBlock->GetLabel() && bsp.pCodeBlock->IsRegulation()) {
			check_point = bsp.pCodeBlock->GetLabel();
			_ASSERT(check_point.length());
			if (m_pSim->CreateChkPoint(check_point) != true) {
				MSG_ERROR(0, "Fail to check point \"%s\"on simulator.\n", check_point.c_str());
				return false;
			}
			#if DBGMODE
			std::fprintf(stdout, "-----------------------------------------------------------------------------\n");
			#endif
			std::fprintf(stdout, " --> Now simulation \"%s\".\n", check_point.c_str());
		}
		
		// this block to be printed.
		bsp.pCodeBlock->SetOutputFlag(true);
		// Simulation (implement for each core)
		BlockSimulation (&bsp);
		
		//-------------------------------------------------------------------------------
		// Handle simulation result
		//-------------------------------------------------------------------------------
		// - Fatal error
		if (bsp.result[IBlockSimParam::BSR_FATALERROR]) {
			MSG_ERROR(0, "Occured fatal error on simulation in \"%s\".\n", check_point.c_str());
			return false;
		}
		// - Reasm by regulation code.
		if (bsp.result[IBlockSimParam::BSR_REASM]) {
			if (pAf->MakeLabelHash(bsp.pCodeBlock) != true || pAf->LabelResolve(bsp.pCodeBlock) != true) {
				MSG_ERROR(0, "Fail to re-asm of \"%s\".\n", check_point.c_str());
				// Regulation code overwrap with next block.
				return false;
			}
		}
		// - To be rollbacked
		if (bsp.result[IBlockSimParam::BSR_ROLLBACK]) {
			if (pAf->MakeLabelHash(bsp.pCodeBlock) != true || pAf->LabelResolve(bsp.pCodeBlock) != true) {
				MSG_ERROR(0, "Fail to re-asm of \"%s\".\n", check_point.c_str());
				// Regulation code overwrap with next block.
				return false;
			}
			if (!m_pSim->Rollback()) {
				//MSG_ERROR(0, "Fail to rollback to \"%s\".\n", rpoint_name.data());
				return false;
			}
		}
		// List of BreakParam
		if( bsp.result[IBlockSimParam::BSR_SUCCESS] && bsp.result[IBlockSimParam::BSR_JUMPING] && bsp.bPrevChain && bsp.pCodeBlock->IsRegulation()) {
             if ( !( bsp.pBreakParam.empty()) || (! bsp.pNotBreakParam.empty())) {
                 GenerateBreakPointSetupBlock(&bsp);
                 bsp.pCodeBlock->SetBreakSetupDone();
             }
		}
		// - Success simulation
		if (bsp.result[IBlockSimParam::BSR_EXIT_SUCCESS]) {
			return true;
		}
	}
	return true;
}
