#ifndef IFASSEMBLER_H_
#define IFASSEMBLER_H_

#include	"rtg_common.h"

/**
 * @brief アセンブル機能を提供するインターフェースクラス。
 */
class IAssembler {
public:

	//! エンディアンを示す列挙子
	typedef enum {
		IASM_LITTLE	= 0,	//!< @brief リトルエンディアン
		IASM_BIG	= 1		//!< @brief ビッグエンディアン
	} IASM_ENDIAN;


	/**
	 * @brief  このオブジェクトを構築します。
	 */	
	IAssembler() {}
	
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */	
	virtual ~IAssembler() {}


	/**
	 * @brief       このオブジェクトを破棄します。
	 * @param param エンディアン
	 */	
	virtual void Init(IASM_ENDIAN param) = 0;


	/**
	 * @brief      指定された文字列をアセンブルし、オペコード領域に格納します。
	 *             アセンブルが成功した場合、命令長を返します。
	 * @param str  命令文
	 * @param opecode  オペコード領域
	 * @return     命令長(失敗時は０を返す)
	 */
	virtual UI32 Asm(LPCTSTR str, UI64* opecode) = 0;
	virtual UI32 Disasm(LPSTR str, UI64 opecode) = 0;

public:
	static IAssembler* New();
};

#endif /*IFASSEMBLER_H_*/
