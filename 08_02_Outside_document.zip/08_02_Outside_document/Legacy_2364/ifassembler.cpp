
#include	"ifassembler.h"
#include	"assembler.h"

IAssembler* IAssembler::New() {

		IAssembler* pAsm = new CAssembler();
		pAsm->Init(IASM_LITTLE);
		return pAsm;

}
