#ifndef ASM_SRC_H_
#define ASM_SRC_H_

#include	"rtg_common.h"
#include	"ifinstruction.h"
#include	"ifnode.h"
#include	"codeblock.h"
#include	"linker.h"

/**
 * @brief 出力ファイルを抽象化するクラスです。
 *        生成出力コードに必要な情報を管理、ファイル出力をハンドリングします。
 */
class CAssemblerSourceFile
{
	typedef std::tuple  <MEMADDR, UI32, UI64> ConstVal;
	typedef std::vector <ConstVal> PresetData;
public:

	/**
	 * @brief このオブジェクトを構築します。
	 */
	CAssemblerSourceFile();
	
	/**
	 * @brief このオブジェクトを破棄します。
	 *        登録されたNODEはこのデストラクタでdeleteします。
	 */
	virtual ~CAssemblerSourceFile();


	/**
	 * @brief  ファイルヘッダを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pHeader ノード参照
	 */
	virtual void AddNode(CFileHeader* pHeader) {
		_ASSERT(pHeader);
		m_vHeader.push_back(pHeader);
	}

	/**
	 * @brief  ベクタテーブルを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pVector ノード参照
	 */
	virtual void AddNode(CVectorBlock* pVector) {
		_ASSERT(pVector);
		m_vVector.push_back(pVector);
//std::cout << __FILE__ << " Add : " << pVector->GetLabel() << ", SIZE=" << m_vVector.size() << std::endl;
	}

	/**
	 * @brief  ハンドラブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pHandler ノード参照
	 */
	virtual void AddNode(CHandlerBlock* pHandler) {
		_ASSERT(pHandler);
		m_vHandler.push_back(pHandler);
	}

	/**
	 * @brief  プリロード処理を追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pPreload ノード参照
	 */
	virtual void AddNode(CPreloadBlock* pPreload) {
		_ASSERT(pPreload);
		m_vPreload.push_back(pPreload);
	}


	/**
	 * @brief  プロローグ処理を追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pPrologue ノード参照
	 */
	virtual void AddNode(CPrologueBlock* pPrologue) {
		_ASSERT(pPrologue);
		m_vPrologue.push_back(pPrologue);
	}

	/**
	 * @brief  同期処理を追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pPrologue ノード参照
	 */
	virtual void AddNode(CSyncBlock* pSync) {
		_ASSERT(pSync);
		m_vSync.push_back(pSync);
	}
		
	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pCode ノード参照
	 */
	virtual void AddNode(CCodeBlock* pCode) {
		_ASSERT(pCode);
//		std::string l = pCode->GetLabel();
//		std::stringstream	ss;
//		ss << "_" << std::dec << std::setw(2) << std::setfill('0') << m_vBody.size();
//		pCode->SetLabel(l + (ss.str().c_str()) );
		m_vBody.push_back(pCode);
	}

	/**
	 * @brief  同期処理を追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pPrologue ノード参照
	 */
	virtual void AddNode(CTeSyncBlock* pSync) {
		_ASSERT(pSync);
		m_vTeSync.push_back(pSync);
	}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pCode ノード参照
	 */
	virtual void AddNodeS(std::vector<CCodeBlock*>* ve) {
		_ASSERT(ve);
		std::vector<CCodeBlock*> Cblock;
		for (UI32 i = 0; i<ve->size();i++) {
			ve->at(i)->AddNodeS(&m_vVector, &m_vHandler, &m_vPreload, &m_vPrologue, &m_vSync, &m_vBody, &m_vFunction, &m_vEpilogue, &m_vTerminate);
		}
		std::cout << "Block count----" << std::endl;
		std::cout << "vector    = " << m_vVector.size() << std::endl; 
		std::cout << "handler   = " << m_vHandler.size() << std::endl; 
		std::cout << "preload   = " << m_vPreload.size() << std::endl; 
		std::cout << "prologue  = " << m_vPrologue.size() << std::endl; 
		std::cout << "sync      = " << m_vSync.size() << std::endl; 
		std::cout << "random    = " << m_vBody.size() << std::endl; 
		std::cout << "function  = " << m_vFunction.size() << std::endl; 
		std::cout << "epilogue  = " << m_vEpilogue.size() << std::endl; 
		std::cout << "terminate = " << m_vTerminate.size() << std::endl;
		std::cout << "---------------" << std::endl;
	}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pCode ノード参照
	 */
	virtual void AddNode(CFunctionBlock* pCode) {
		_ASSERT(pCode);
		m_vFunction.push_back(pCode);
	}

	/**
	 * @brief  終了ブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pCode ノード参照
	 */
	virtual void AddNode(CEpilogueBlock* pCode) {
		m_vEpilogue.push_back(pCode);
	}
	
	/**
	 * @brief  終了ブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pCode ノード参照
	 */
	virtual void AddNode(CTerminateBlock* pCode) {
		m_vTerminate.push_back(pCode);
	}
	
	/**
	 * @brief  ユーザブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 * @param  pCode ノード参照
	 */
	virtual void AddNode(CUserBlock* pCode) {
		m_vUser.push_back(pCode);
	}
	 	
	/**
	 * @brief  指定されたランダム生成ブロックの参照を取得します。
	 * @param  n ノード番号
	 * @return ノード参照
	 */
	virtual inline INode* Body(int n) {
		try {
			return m_vBody.at(n);
		} catch (std::out_of_range){}
		return NULL;
	}

	/**
	 * @brief  ベクタノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetVectorBlock() {
		return m_vVector;
	}

	virtual inline std::vector<INode*>& GetHandlerBlock() {
		return m_vHandler;
	}

	/**
	 * @brief  プリロードノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetPreloadBlock() {
		return m_vPreload;
	}

	/**
	 * @brief  プロローグノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetPrologueBlock() {
		return m_vPrologue;
	}
	
	/**
	 * @brief  同期処理ブロックノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetSyncBlock() {
		return m_vSync;
	}
	
	/**
	 * @brief  ランダムブロックノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetCodeBlock() {
		return m_vBody;
	}

	virtual inline std::vector<INode*>& GetTeSyncBlock() {
		return m_vTeSync;
	}

	virtual inline std::vector<INode*>& GetFunctionBlock() {
		return m_vFunction;
	}

	/**
	 * @brief  エピローグブロックノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetEpilogueBlock() {
		return m_vEpilogue;
	}

	/**
	 * @brief  ターミネートブロックノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetTerminateBlock() {
		return m_vTerminate;
	}

	/**
	 * @brief  ターミネートブロックノードの参照を取得します
	 * @return pNode ノード参照
	 */
	virtual inline std::vector<INode*>& GetUserBlock() {
		return m_vUser;
	}

	/**
	 * @brief  各ブロックに存在するデータテーブルブロックを収集します。
	 * @param  v ノード参照
	 */
	virtual void GetConstTable(std::vector<CCodeBlock*>& v);
	
		
	/**
	 * @brief  全コードブロックに定義されるラベルに対して実効値を計算します。
	 * @return 成功した場合、真を返します。
	 */
	virtual bool MakeLabelHash(void);

	
	/**
	 * @brief  指定コードブロックに定義されるラベルに対して実効値を計算します。
	 * @param  pCb  ラベル計算とリンクを再実効するコードブロックを指定
	 * @return 成功した場合、真を返します。
	 */
	virtual bool MakeLabelHash(CCodeBlock* pCb);
	
	/**
	 * @brief  全コードブロック内のラベル指示オペランドを実効値に変更します。
	 * @return 未定義ラベルが使用されている場合、偽を返します。
	 */
	virtual bool LabelResolve(void);

	virtual SI32 SearchAddress(std::string label);
	
	/**
	 * @brief  指定コードブロック内のラベル指示オペランドを実効値に変更します。
	 * @return 未定義ラベルが使用されている場合、偽を返します。
	 */
	virtual bool LabelResolve(CCodeBlock* pcb);

	
	/**
	 * @brief  指定ブロックと同一のブロック名と差し替えます。
	 * @param  pCB  差し替えるブロック
	 * @return 差し替えた場合、真を返します。
	 */
	virtual bool ReplaceCodeBlock(CCodeBlock* pCB);

		
	/**
	 * @brief  命令の配置アドレスを決定します。
	 * @return 成功した場合、真を返します。
	 */
	virtual bool Link(void);

	/**
	 * @brief  Remove label that set for OPR_ATTR_ALABEL operand
	 * @return None
	 */
	virtual void RemoveDispLabel(void);

	/**
	 * @brief Delete allocated memory for a specific codeblock
	 * @return true if sucess, otherwise false
	 */
	virtual bool ReleaseBlock(CCodeBlock *pCB) {
		return m_pLinker->Remove(pCB->GetAddress());
	}

	/** @brief  命令の配置アドレスを決定します。
	 * @return 成功した場合、真を返します。
	 */
	virtual void SetAvailableAddress(const std::set<MEMRANGE>& s, CLinker::MEM_ATTRIBUTE att) {
		std::set<MEMRANGE>::iterator i;
		for (i = s.begin(); i != s.end(); i++) {
			if (m_pLinker->Reserve(*i, att) != true) {
				std::cout << "err:" << __FILE__  << ":" << __LINE__ << std::endl;
				break;
			}
		}
		m_pLinker->Reload();
	}
	
	/**
	 * @brief  指定アドレスを含むコードブロックを検索します。
	 * @param  adr 検索アドレス
	 * @return 成功した場合、コードブロックの参照を返します。
	 */
	virtual CCodeBlock* Search(UI32 adr);
	
	/**
	 * @brief  作成したパタンをファイルへフラッシュします。
	 * @param filename  出力ファイルパス
	 * @return 成功した場合、真を返します。
	 */
	virtual bool Flush(std::string& filename);

	
	/**
	 * @brief  作成したパタンをファイルへフラッシュします。
	 * @param filename  出力ファイルパス
	 * @return 成功した場合、真を返します。
	 */
	virtual bool LinkMap(std::string& filename);	
	
	/**
	 * @brief  作成したパタンをファイルへフラッシュします。
	 * @param filename  出力ファイルパス
	 * @return 成功した場合、真を返します。
	 */
	virtual void SetSconst(MEMADDR adr, UI32 len, UI64 val) {
		m_Sconst.push_back( ConstVal(adr,len,val) );
	}
	
	/**
	 * @brief  [デバッグ用]ラベル名と配置アドレスを出力します。
	 * @param  os 出力ストリーム
	 */
	void PrintLabel(std::ostream& os = std::cout);

protected:

	/**
	 * @brief  実行コード部(ファイルヘッダ部を含まない)を結合します。
	 * @param  va 結合先配列
	 */
	void MergeCode(std::vector<INode*>& va); 
	
	
protected:
	std::vector<INode*>		m_vHeader;			//<! @brief 登録されたノード(ヘッダコメント)を管理します
	std::vector<INode*>		m_vVector;			//<! @brief 登録されたノード(ベクタテーブル)を管理します
	std::vector<INode*>		m_vHandler;			//<! @brief 登録されたノード(ハンドラ)を管理します
	std::vector<INode*>		m_vPreload;			//<! @brief 登録されたノード(プリロードメモリ初期化)を管理します
	std::vector<INode*>		m_vPrologue;		//<! @brief 登録されたノード(セットアップ)を管理します
	std::vector<INode*>		m_vSync;			//<! @brief 登録されたノード(同期)を管理します
	std::vector<INode*>		m_vBody;			//<! @brief 登録されたノード(ランダム命令列)を管理します
	std::vector<INode*>		m_vTeSync;			//<! @brief 登録されたノード(スレッド終了同期)を管理します
	std::vector<INode*>		m_vFunction;		//<! @brief 登録されたノード(ファンクション)を管理します
	std::vector<INode*>		m_vEpilogue;		//<! @brief 登録されたノード(終了前処理)を管理します
	std::vector<INode*>		m_vTerminate;		//<! @brief 登録されたノード(終了処理)を管理します
	std::vector<INode*>		m_vUser;			//<! @brief 登録されたノード(ユーザ処理)を管理します
	std::map<std::string,UI32> m_LHash;			//<! @brief ラベルとアドレスの対応を管理します。
	CLinker*				m_pLinker;			//<! @brief 配置アドレスを管理するリンカ
	PresetData              m_Sconst;			//<! @brief ROM用のプリロードデータ
};


typedef std::vector<CVectorBlock*>			VectorSet;
typedef std::unique_ptr<VectorSet> 			VectorPtr;

typedef std::vector<CHandlerBlock*>			HandlerSet;
typedef std::unique_ptr<HandlerSet> 		HandlerPtr;

typedef std::vector<CPreloadBlock*>			PreloadSet;
typedef std::unique_ptr<PreloadSet> 		PreloadPtr;

typedef std::vector<CPrologueBlock*>		PrologueSet;
typedef std::unique_ptr<PrologueSet> 		ProloguePtr;

typedef std::vector<CSyncBlock*>			SyncSet;
typedef std::unique_ptr<SyncSet> 			SyncPtr;

typedef std::vector<CCodeBlock*>			RandomSet;
typedef std::unique_ptr<RandomSet> 			RandomPtr;

typedef std::vector<CTeSyncBlock*>			TeSyncSet;
typedef std::unique_ptr<TeSyncSet> 			TeSyncPtr;

typedef std::vector<CEpilogueBlock*>		EpilogueSet;
typedef std::unique_ptr<EpilogueSet> 		EpiloguePtr;

typedef std::vector<CTerminateBlock*>		TerminateSet;
typedef std::unique_ptr<TerminateSet> 		TerminatePtr;

typedef std::vector<CFunctionBlock*>		FunctionSet;
typedef std::unique_ptr<FunctionSet> 		FunctionPtr;

typedef std::vector<CUserBlock*>			UserSet;
typedef std::unique_ptr<UserSet>		 	UserPtr;

#endif /*ASM_SRC_H_*/
