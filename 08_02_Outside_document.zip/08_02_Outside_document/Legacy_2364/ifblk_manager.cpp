#include "ifexception.h"
#include "ifblk_manager.h"
#include "weight_parser.h"
#include "rtg_app.h"
#include "blk_manager.h"

IBlockManager* IBlockManager::New(LIST_INSSET*  WeightSet) {
 		
	return new CBlockManager( WeightSet );
 
}
