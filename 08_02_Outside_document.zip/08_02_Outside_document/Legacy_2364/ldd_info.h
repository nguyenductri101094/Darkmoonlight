#ifndef LDD_INFO_H_
#define LDD_INFO_H_

#include "rtg_common.h"

/**
 * @brief	リンクディレクティブを抽象化するクラス
 *          命令に対して付加される。
 */
struct IDirective {
	IDirective(){}
	virtual ~IDirective(){}
	virtual void Print(std::ostream& os) = 0;
	virtual std::string GetLabel() = 0;
	virtual bool SetAddress(UI32 newAddr) = 0;
	virtual IDirective* GetAsyncLabel() {return NULL;};
};


/**
 * @brief	ラベルを抽象化するクラス
 *          命令に対して付加される。
 */
struct CLabel : public IDirective {
	CLabel() : m_addr(0), m_label(""){}
	CLabel(LPCTSTR l, UI32 a) : m_addr(a){
		m_label = /*m_prefix + */l;
	}
	virtual ~CLabel(){} 
	virtual bool IsRelative() {return false;}
	virtual void Print(std::ostream& os) {
		os << m_prefix << m_label << ':' << std::endl;
	}
	void SetLable(std::string& l) {
		m_label = /*m_prefix + */l;
	}
	std::string GetLabel() {
		return m_label;
	}
/**
 * @brief	change address value
 * @param	newAddr is new value
 * @return	true in class has address
 */
	bool SetAddress(UI32 newAddr){
		m_addr = newAddr;
		return true;
	}

	LPCTSTR GetLabelStr() {
		return m_label.c_str();
	}

	UI32		m_addr;			//<! @brief アドレス
	static std::string		m_prefix;
	// TODO:アドレスもprotect
protected:
	std::string m_label;		//<! @brief ラベル名
};


/**
 * @brief	ロケーション・カウンタを抽象化するクラス
 *          命令に対して付加される。
 */
struct CLdOrg : public IDirective {
	CLdOrg() : m_val(0){}
	CLdOrg(UI32 a) : m_val(a){}
	~CLdOrg(){} 
	virtual void Print(std::ostream& os) {
		os << ".org    0x" << std::hex << m_val << std::endl;
	}

	/**
	 * @brief	virtual function to get label
	 * @return	NULL in class has not label
	 */
	std::string GetLabel() {
		return std::string("");
	}

	/**
	 * @brief	virtual function change address value
	 * @param	newAddr is new value
	 * @return	false in class has not address
	 */
	bool SetAddress(UI32 newAddr){
		return false;
	}
	UI32		m_val;			//<! @brief アドレス

};

#define NONE_SET		(0x0FFFFFFF)

struct CAsyncLabel : public IDirective {
	CAsyncLabel() : m_name(""), m_context(""), m_channel(NONE_SET), m_priority(NONE_SET), m_index(NONE_SET), m_causecode(NONE_SET), m_repeat(1), m_bAssert(true), m_nEventId(0), m_gpid(NONE_SET) {}

	CAsyncLabel(std::string name, std::string context, UI32 index, bool assert, UI32 repeat = 1)
		: m_name(name), m_context(context), m_channel(NONE_SET), m_priority(NONE_SET), m_index(index), m_causecode(NONE_SET), m_repeat(repeat), m_bAssert(assert), m_nEventId(0), m_gpid(NONE_SET) {}

	~CAsyncLabel(){} 

	virtual void Print(std::ostream& os) {
		std::string label;
		std::stringstream ss;
		if(m_bAssert)
			ss << CLabel::m_prefix << m_context << "async_assert_" << m_name ;
		else
			ss << CLabel::m_prefix << m_context << "async_deassert_" << m_name ;
		if(m_channel != NONE_SET) {
			ss << "_" << std::hex << std::setw(4) << std::setfill('0') << m_channel;
		}
		ss << "_" << std::hex << std::setw(4) << std::setfill('0') << m_index;

		if(m_priority != NONE_SET) {
			ss << "_" << m_priority;
		}
		ss << "_" << m_repeat;
        if(m_gpid != NONE_SET) {
            ss << "_" << m_gpid;
        }
		label = ss.str();
		os << label << ':' << std::endl;
	}

	virtual IDirective* GetAsyncLabel() {return this;};

	/**
	 * @brief	virtual function to get label
	 * @return	NULL in class has not label
	 */
	std::string GetLabel() {
		return std::string("");
	}
	
	/**
	 * @brief	virtual function change address value
	 * @param	newAddr is new value
	 * @return	false in class has not address
	 */
	virtual bool SetAddress(UI32 newAddr) {
		return false;
	}

	std::string			m_name;
	std::string			m_context;
	UI32				m_channel;
	UI32				m_priority;
	UI32				m_index;
	UI32				m_causecode;
	UI32				m_repeat;
	bool				m_bAssert;
	UI32				m_nEventId;
    UI32                m_gpid;
};

#endif /*LDD_INFO_H_*/
