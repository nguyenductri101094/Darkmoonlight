#ifndef MSG_LOG_H_
#define MSG_LOG_H_

#include "rtg_common.h"

namespace RTG_TOOL {

class CLogMessage {

public:
	CLogMessage() 
		: m_lvlQ()
		, m_msgQ()
		, m_ostream(&std::cout)
		, m_bConWarn(true), m_bConError(true), m_bConInfo(true)
		, m_bLogWarn(false), m_bLogError(false), m_bLogInfo(false) {}
	
	virtual ~CLogMessage() {}
	
	void Warn (UI32 level, const char* fmt, ...);

	void Error(UI32 level, const char* fmt, ...);

	void Info (UI32 level, const char* fmt, ...);

	void SetConsole (std::ostream* console);

	std::string Get (UI32 i);

	inline void SwitchConWarn (bool sw) { m_bConWarn  = sw; }	/* 警告メッセージのコンソール出力抑止		*/
	inline void SwitchConError(bool sw) { m_bConError = sw; }	/* エラーメッセージのコンソール出力抑止	*/
	inline void SwitchConInfo (bool sw) { m_bConInfo  = sw; }	/* 情報メッセージのコンソール出力抑止		*/
	inline void SwitchLogWarn (bool sw) { m_bLogWarn  = sw; }	/* 警告メッセージのログ蓄積抑止			*/
	inline void SwitchLogError(bool sw) { m_bLogError = sw; }	/* エラーメッセージのログ蓄積抑止			*/
	inline void SwitchLogInfo (bool sw) { m_bLogInfo  = sw; }	/* 情報メッセージのログ蓄積抑止			*/
	inline void Clear() { m_msgQ.clear(); }
	inline int  Size()  { return m_msgQ.size(); }

protected:
	std::deque<UI32>		m_lvlQ;
	std::deque<std::string>	m_msgQ;
	std::ostream*			m_ostream;
	bool					m_bConWarn;
	bool					m_bConError;
	bool					m_bConInfo;
	bool					m_bLogWarn;
	bool					m_bLogError;
	bool					m_bLogInfo;
};

} // namespace RTG_TOOL

#define	MSG_WARN(lvl,...)	RTG_TOOL::gMSG.Warn(lvl,__VA_ARGS__)
#define	MSG_ERROR(lvl,...)	RTG_TOOL::gMSG.Error(lvl,__VA_ARGS__)
#define	MSG_INFO(lvl,...)	RTG_TOOL::gMSG.Info(lvl,__VA_ARGS__)
#define DBG_TRACE()         (fprintf(stdout, "Trace : At %s in %s(%d)\n", __FUNCTION__, __FILE__, __LINE__))

namespace RTG_TOOL {
	extern	CLogMessage gMSG;
};

#endif /*MSG_LOG_H_*/

