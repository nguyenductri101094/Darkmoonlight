#include "sim_ctrl.h"
#include "instruction.h"
#include "ifbreakparam.h"
#include "ifblk_manager.h"
#include "adr_selector.h"
#include "insid_set.h"
#include "mxu_parser.h"

extern std::shared_ptr<CGeneratorConfig>	g_cfg;
extern std::unique_ptr<ISysRegSet>	g_srs;
extern std::unique_ptr<IException>          g_exp;
extern std::shared_ptr<CAssemblerSourceFile>    g_asf;
extern std::unique_ptr<IBlockManager>			g_mgr;
extern std::shared_ptr<CGeneratorProfile>		g_prf;
extern TWorkMemory								g_wm;

#define LOGSW_INS_SIM		(!defined(NDEBUG) && 1)
#define LOGSW_REGULATION	(!defined(NDEBUG) && 0)
#define	EXCEPTION_MIN_PROBABLY	100
#define	NewINS(_CB_, _INS_)		((_CB_)->AddOpeCode(_INS_))

CSimulatorControl::CSimulatorControl() {
}

CSimulatorControl::~CSimulatorControl() {
	if (m_pSim) {
		delete m_pSim;
		m_pSim = NULL;
	}
}


/**
 * @brief	シミュレーターを初期化します。
 */	
bool CSimulatorControl::Init(std::string& iniPath) {
	delete m_pSim;
	m_pSim = ISimulator::New();
	if(m_pSim->Init(iniPath) == false) {
		return false;
	}

	m_nFPIStatus = FPI_NONE;
	m_nFPIPendingIns = 0;
	m_nFPIMismatchReg = 0;

	m_nWRMemOffset    = 16;	// Offset for initializing WR at beginning
	m_nWRMemBlockCount = 0;
	m_bNewWRMemBlock = false;

	m_bRollback = false;
	m_pRollbackIns = NULL;

	m_nBlockSimCount = 0;
	m_nDeassertIdx = 0;

    m_MPUlist = g_mgr->GetMPUInfor();
	return (m_pSim != NULL);
}


bool CSimulatorControl::ReadySimulation (ISimulationParam* pSp, IBlockSimParam* pBsp) {
	
	_ASSERT(pBsp);
	_ASSERT(m_pSim);
	
	// Get Next Thread
    pBsp->htid = 0x80000000; // m_pSim->GetNextHT();
    m_pSim->ReadPC(&pBsp->lpc);

	// PC Update(physical)
	UI64 pa1, pa2;
	UI64 ps1, ps2;
	if (m_pSim->MmuTransferAddr(true, 0, (UI64)pBsp->lpc, 1, MXU_ACC_DONTCARE, &pa1, &ps1, &pa2, &ps2) != true) {
		MSG_ERROR(0, "Internal error at address transfer %s(%d).\n", __FUNCTION__, __LINE__);
		return false;
	}
	pBsp->ppc = (UI32)pa1;
		
	//!< Search target block
	if ((pBsp->pCodeBlock = pSp->pAsmSrcObj->Search(pBsp->ppc)) == NULL) {
		MSG_ERROR(0, "Not found address in code. PC={LA=%08X, PA=%08X}\n", pBsp->lpc, pBsp->ppc);
		return false;
	}
	
	pBsp->result = 0;
	
	return true;
}


bool CSimulatorControl::RegulateBranchCondition(CCodeBlock* pCB, IInstruction* pIns) {
	bool bForce = pIns->IsForcedAdjust();

	auto IsAlwaysJump = [](IInstruction *p) -> bool{
		const std::string& mne = p->GetMne();
		return (mne=="ctret" || mne=="eiret" || mne=="feret" || mne=="br" || mne=="jr" || mne=="jmp" || mne=="jarl" 
			|| ((mne=="dispose") && (p->GetOpNum()==3)) );
	};

	if(pIns->Behavior(IInstruction::JMP)){
		if (pIns->HasBranchConstraint() != true) {
			return false;
		}
		
		UI32 psw = GetPSW();
		bool taken = pIns->GetConstraint();
		if (pIns->TakeCondition(psw) == taken) {
			if(!bForce || IsAlwaysJump(pIns)) {
				pIns->DelReverse(); // 反対条件を消す
				return false; // OK!
			}
			pIns->SetConstraint(false);
			if(taken) {
				IInstruction *revIns = pIns->GetReverse();
				revIns->SetConstraint(false);
				if(revIns != nullptr){
					if(revIns->opr(0))
						revIns->opr(0)->SetLabel(pIns->opr(0)->GetLabel());
					pCB->AddOpeCode(revIns, pCB->GetIndex(pIns) + 1);
					return true;
				}
			} else {
				pIns->opr(0)->Replace(pIns->GetLen());
				pIns->opr(0)->RemoveLabel();
				pIns->DelReverse(); // 反対条件を消す
			}
			return false;
		}

		// 反対命令を持たない
		// NotTaken制約BSAがTakenになる場合
		if ((pIns->GetMne()=="bsa") && (taken==false)) {
			pIns->DelReverse(); // 反対条件を消す
			pIns->opr(0)->Replace(pIns->GetLen());
			pIns->opr(0)->RemoveLabel();
			if(bForce){
				pIns->SetConstraint(false);
			}
			return false; // OK!
		}

		// branchの補正処理（反対命令を入れる）
		IInstruction* revIns = pIns->GetReverse();
		if (revIns == nullptr) {
			MSG_ERROR(0, "Internal error -> branch control regulate[%s] ""%s"" psw=%08x\n", (taken?"Taken":"NotTaken"), pIns->GetMne().c_str(), psw);
			FROG_ASSERT(0);
		}

			revIns->SetTaken( pIns->GetConstraint() );

		if (revIns->opr(0)) {
			// brの反対命令はnopにしている。br以外はオペランドあり
			// またbr17命令はISAにない！
			revIns->opr(0)->SetLabel(pIns->opr(0)->GetLabel());
		}

		if(pIns->InSequence(IInstruction::IF_SEQ_C2B1)){
			if(pIns->GetId() == INS_ID_BSA_SD9){
				IInstruction* pPrevIns = pCB->at(pCB->GetIndex(pIns)-1);
				pPrevIns->DelComment();
				pPrevIns->SetC2B1Ins(revIns);
			}
			else{
				IInstruction* pPrevIns = pCB->at(pCB->GetIndex(pIns)-1);
				pPrevIns->SetC2B1Ins(revIns);
				revIns->SetSequence(IInstruction::IF_SEQ_C2B1); //[FROG]TODO
				revIns->AppendComment(pIns->GetComment().c_str());
			}
		}
		pIns->DirMoveTo(revIns);
		pIns->AsyncMoveTo(revIns);
		if( pIns->GetLabel().find("_bp_") != std::string::npos ) {
			revIns->SetLabel(pIns->GetLabel());
		}
		revIns->m_bBreakTargetIns = pIns->m_bBreakTargetIns;
		revIns->m_bBreakInsertIns = pIns->m_bBreakInsertIns;
		if(!bForce) {
			PrepareDeletedIns(pCB, pIns);
			pCB->Replace(pIns, revIns);
			delete pIns;
			return true;
		}
		pIns->SetConstraint(false);
		if(revIns != NULL)
			revIns->SetConstraint(false);
		if(taken) {
			pCB->AddOpeCode(revIns, pCB->GetIndex(pIns));
		} else {
			if (revIns->opr(0)) {
				revIns->opr(0)->Replace(pIns->GetLen());
				revIns->opr(0)->RemoveLabel();
			}
			pCB->Replace(pIns, revIns);
			delete pIns;
		}

		return true;
	}
	else return false;
}

bool CSimulatorControl::MaskSysRegLoad (CCodeBlock* pCB, IInstruction *pIns)
{
	auto ReadSpecialSReg = [&] (UI32 &val, UI32 regId, UI32 selId) -> bool{
		UI32 srVal;
		if (selId == 0)
		{
			if(regId == 8){ // FPST(0,8)
				// FPST reflects FPSR (0, 6) register.
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				UI32 valXC = (srVal >> 10) & 0x3F;
				UI32 valXP = (srVal >> 0) & 0x1F;
				val = (valXC << 8) | (valXP << 0);
				//if (FPU_SEL_FPU20) {	// FPU-2.0 // TODO: Support FPU-2.0
				   // UI32 valPR = (srVal >> 16) & 0x1;
				   // val = ( valPR << 15 ) | (valXC << 8) | (valXP << 0) ;
				//} else {											// FPU-3.0
					UI32 valIF = (srVal >> 22) & 0x1;
					val = (valXC << 8) | ( valIF << 5 ) | (valXP << 0) ;
				//}
				return true;
			}else if(regId == 9){   // FPCC(0,9)
				// FPCC reflects FPSR (0, 6) register.
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				val = (srVal >> 24) & 0xFF;
				return true;
			}else if(regId == 10){  // FPCFG(0, 10)
				// FPCFG reflects FPSR (0, 6) register.
				UI32 valRM, valXE;
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				valRM = (srVal >> 18) & 0x3;
				valXE = (srVal >> 5) & 0x1F;
				val = (valRM << 8) | (valXE << 0);
				return true;
			}
		}
		return false;
	};

	auto GenerateRandomVal = [](UI32 mask){
		UI32 nMask = 1;
		UI32 nCount = 0;
		UI32 randomVal = 0;
		UI32 nResult = 0;

		nCount	= 0;
		nMask = 1;
		while(nMask){
			if(mask & nMask)
				nCount++;
			nMask <<= 1;
		}
		// Generate a random number in range of (0; (2^nCount) - 1)
		randomVal = g_rnd.GetRange((UI32) 0, (UI32) ((1 << nCount) - 1 ));

		nCount	= 0;
		nMask	= 1;
		while(nMask){
			if(mask & nMask){
				nResult |= (randomVal & 1) << nCount;
				randomVal >>= 1;
			}
			nCount++;
			nMask <<= 1;
		}
		return nResult;
	};


	auto IsNeededMPUProtect = [=] (UI32 sr) -> bool {
        UI32 mip_demand_gm = g_prf->m_mpdemand[0] >> 16;
        UI32 mpla_gm = 0, mpua_gm = 0;
		UI32 pc;
		UI32 curMPIDX;
		UI32 svlock = 0, hvcfg = 0, pswh = 0;

		if((GetPSW() & 0x40000000))
			return false;

        m_pSim->ReadNcReg(&curMPIDX, 16, 5);
        m_pSim->WriteNcReg(mip_demand_gm, 16, 5);
        m_pSim->ReadNcReg(&mpla_gm, 20, 5);
        m_pSim->ReadNcReg(&mpua_gm, 21, 5);
        m_pSim->WriteNcReg(curMPIDX, 16, 5);
        m_pSim->ReadNcReg(&svlock, 8, 1);
        m_pSim->ReadNcReg(&hvcfg, 16, 1);
        m_pSim->ReadNcReg(&pswh, 15, 0);

		m_pSim->ReadPC(&pc);
		
		if(mpla_gm <= pc && pc <= mpua_gm) {
			return false;
		}
		// SPID, MPM, MPLA, MPUA, MPAT, MPIDn can not be update when SVLOCK.SVL = 1
		if(svlock != 0 
			&& ((sr >> 5) == 0x5 /* MPU SRs */ || (sr == (1 * 32) +  0)  /* SPID */ ))
			return false;

        if ((hvcfg & 0x1) != 0 && (pswh & 0x80000000) == 0)
            return false;

		return true;
	};
	// lambda: Check whether instruction is first regulation code.
	auto IsFirstRegulationIns = [](CCodeBlock* pCB, IInstruction* pIns){
		IInstruction *pPrev;
		UI32 nInsPos;

		// The first instruction of CB
		nInsPos = pCB->GetIndex(pIns);
		if(nInsPos == 0)
			return true;

		// Not the first regulation instruction
		pPrev = pCB->at(nInsPos - 1);
		if(pPrev->GetRegulationTarget() != NULL)
			return false;

		return true;
	};

	const std::string &mne = pIns->GetMne();

	//if(pIns->Behavior(IInstruction::LOAD_SR) && pIns->opr(0)->GetConstraint() == NULL)
	if(mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr")
	{
		const UI32 NO_MASK = 0xffffffff;
		IValConstraint *pConst = pIns->opr(0)->GetConstraint();

		UI32 sr = (UI32) *(pIns->opr(1));
		UI32 regId = (sr & 0x1f);
		UI32 selId = (sr >> 5);
		UI32 nMask;

		nMask = g_srs->GetWriteMask(regId, selId);
		if(nMask != NO_MASK){
			UI32 grVal, srVal;

			if( pConst == NULL || !pConst->GetType(IValConstraint::DUMMY))
			return true;

			//m_pSim->ReadGrReg(&grVal, pIns->opr(0)->Idx(), 0/*htid#0*/);
			grVal = GenerateRandomVal(nMask);

			// Special cases FPST(0,8), FPCC(0,9), FPCFG(0, 10)
			if(!ReadSpecialSReg(srVal, regId, selId)){
				UI32 nContext;
				const UI32 NC = 1 << 0; //CSysReg::SR_CONTEXT_NC
				const UI32 VC = 1 << 1; //CSysReg::SR_CONTEXT_VC
				const UI32 TC = 1 << 2; //CSysReg::SR_CONTEXT_TC
				const UI32 CONTEXT_END = 1 << 3; //CSysReg::SR_CONTEXT_END

				if(mne == "ldtc.sr")
					nContext = TC;
				else if (mne == "ldvc.sr")
					nContext = VC;
				else
				if(!g_srs->GetContext(regId, selId, nContext))
					nContext = CONTEXT_END;

				if(nContext == NC || IsNativeMode()) // Native Context
				{
					m_pSim->ReadNcReg(&srVal, regId, selId);
				}
				else if (nContext == VC || (nContext == (NC | VC) && !IsNativeMode())) // Virtual Context
				{
					UI32 htcfg0;
					UI32 htid = 0; // TODO: Not support multi-thread
					UI32 vcid;
					m_pSim->ReadTcReg(&htcfg0, 0,  2, htid);
					vcid = (htcfg0 >> 8) & 7 ;
					m_pSim->ReadVcReg(&srVal, regId, selId, vcid);
				}
				else if (nContext == TC || ((nContext == (NC | TC)) && !IsNativeMode())) // Thread Context
					m_pSim->ReadTcReg(&srVal, regId, selId, 0/*htid#0*/); // TODO: Support multi-thread
				else{
					MSG_INFO (0, "Can not read current system register SR[%d][%d].\n", selId, regId );
					return true;
				}
			}
			grVal = (grVal & nMask) | (srVal & ~nMask);
			pIns->opr(0)->RemoveConstraint(); // Remove dummy constraint
			pIns->opr(0)->SetConstraint(new INumConstraint(grVal, grVal));
		} else {

			// Ajust MPIDX to avoid regions that used for MIP/MDP setting
			if(regId == 16 && selId == 5 /* MPIDX */ && pIns->GetRegulationTarget() == NULL) {
				UI32 regVal, newVal;
				m_pSim->ReadGrReg(&regVal, pIns->opr(0)->Idx(), 0);
				
				newVal = regVal;
				while(g_prf->IsWorkMPURegionByIdx(newVal)) {
					newVal = g_rnd.GetRange((UI32)0, g_hwInfo.m_mpnum - 1);
				}
				if(newVal != regVal){
					pIns->opr(0)->SetConstraint(new INumConstraint(newVal, newVal));
				}
			}
		}

        pConst = pIns->opr(0)->GetConstraint();

        if ((GetPSW() & 0x40000000) == 0) {
            UI32 oldValue = 0, newValue = 0, PC = 0;
            m_pSim->ReadPC(&PC);

            if (pConst != nullptr) {
                newValue = pConst->SelectValue();
            } else {
                m_pSim->ReadGrReg(&newValue, pIns->opr(0)->Idx(), 0);
            }

            // Backup old value of system register
            switch (sr) {
                case (0 * 32 + 5):
                    oldValue = m_pSim->GetPSW();
                    break;
                case (1 * 32 + 0):
                {
                    oldValue = m_pSim->GetSPID_MPIDn();

                    char str[8];
                    std::string name;
                    UI32 mpidn = 0;
                    UI32 spid = newValue & 0x1f;
                    newValue = 0;
                    for (UI32 i = 0; i < 8 /*MPID_NUM*/; i++) {
                        sprintf(str, "MPID%d", i);
                        name = std::string(str);
                        m_pSim->ReadSysRegister(&mpidn, name, 0);
                        if (spid == mpidn) {
                            newValue |= 1 << i;
                        }
                    }
                }
                break;
                case (5 * 32 + 0):
                    oldValue = m_pSim->GetMPM();
                    newValue &= 0x7;
                    break;
                case (5 * 32 + 17):
                    oldValue = m_pSim->GetMPBK();
                    newValue &= 0x1;
                    break;
                default:
                    oldValue = 0xffffffff;
                    break;
            }

            if (oldValue != 0xffffffff) {
                // Assign new value for system register
                switch (sr) {
                    case (0 * 32 + 5):
                        m_pSim->SetPSW(newValue);
                        break;
                    case (1 * 32 + 0):
                        m_pSim->SetSPID_MPIDn(newValue);
                        break;
                    case (5 * 32 + 0):
                        m_pSim->SetMPM(newValue);
                        break;
                    case (5 * 32 + 17):
                        m_pSim->SetMPBK(newValue);
                        break;
                    default:
                        std::runtime_error excep("Fail to regulate system register\n ");
                        throw excep;
                        break;
                }

                // MIP do not occur at SYNCI
                if (IsMIPexception(PC + 4, 0x4) != NO_ERROR) {
                    if (sr == (1 * 32 + 0) /*SPID*/) {
                        pIns->opr(0)->SetConstraint(new INumConstraint(m_pSim->GetSPID(), m_pSim->GetSPID()));
                    } else {
                        pIns->opr(0)->SetConstraint(new INumConstraint(oldValue, oldValue));
                    }
                }

                // Restore old value for system register
                switch (sr) {
                    case (0 * 32 + 5):
                        m_pSim->SetPSW(oldValue);
                        break;
                    case (1 * 32 + 0):
                        m_pSim->SetSPID_MPIDn(oldValue);
                        break;
                    case (5 * 32 + 0):
                        m_pSim->SetMPM(oldValue);
                        break;
                    case (5 * 32 + 17):
                        m_pSim->SetMPBK(oldValue);
                        break;
                    default:
                        std::runtime_error excep("Fail to regulate system register\n ");
                        throw excep;
                        break;
                }
            }
        }
	}

	IInstruction *pTarget = pIns->GetRegulationTarget();
    if (pTarget != NULL) {
        UI32 nTargetId = pTarget->GetId();
        if ((nTargetId == INS_ID_LDSR || nTargetId == INS_ID_LDTC_SR || nTargetId == INS_ID_LDVC_SR)
            && IsFirstRegulationIns(pCB, pIns)) {
            UI32 sr = (UI32) *(pTarget->opr(1));
            if (((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12))/*MPU SRs*/
                || (sr == (1 * 32) + 0)  /* SPID */
                || (sr == (0 * 32) + 5)  /* PSW */) {
                if (!IsNeededMPUProtect(sr)) {
                    // Delete adjustment code
                    UI32 idx = pCB->GetIndex(pIns);
                    UI32 nDelete = 0;
                    while (pIns != pTarget) {
                        if (pIns->GetRegulationTarget() == pTarget
                            && pIns->GetComment().find("privilege") == std::string::npos
                            && pIns->GetComment().find("Regulation code") == std::string::npos) {
                            pIns->DirMoveTo(pCB->at(idx + 1));
                            pCB->Remove(pIns);
                            nDelete++;
                        } else {
                            idx++;
                        }
                        pIns = pCB->at(idx);
                    }
                    if (nDelete) {
                        return false;
                    }
                }
            }
        }
    }
	return true;
}

bool CSimulatorControl::AdjustJumpForwarding(CCodeBlock *pCB, IInstruction *pIns) {
	if(pIns->GetRegulationTarget() == nullptr)
		return false;

	auto GetUI32ActualSize = [] (UI32 num) ->UI32 {
		if((num & 0xffffff80) == 0)
			return 1;	// BYTE size
		if((num & 0xffff8000) == 0)
			return 2;	// HWORD size
		return 4;	// WORD size
	};

	// Regulate forwarding for LOOP by replacing termination ins. (MOVI32) by its FWD partner.
	IInstruction *pTarget = pIns->GetRegulationTarget();
	UI32 targetId = pTarget->GetId();
	// Fowarding couple ALU/LD_SPECIAL and ALU/LU_JUMP
	if(targetId == INS_ID_LOOP || targetId == INS_ID_JARL || targetId == INS_ID_JMP || targetId == INS_ID_JMPD32) {
		if(pTarget->GetInsNeed().size() == 0)
			return false;

		std::vector<UI32> ex; // Temporary variable
		UI32 targV = (UI32)(*(pIns->opr(0)));
		UI32 reg = pIns->opr(1)->Idx();
		IInstruction *pNeed = pTarget->GetInsNeed().back();
		// Recover solution for the size of LD less than targV
		if(pNeed->Behavior(IInstruction::LOAD_MEMORY)) {
			UI32 size = pNeed->opr(0)->GetConstraint()->m_nSzm;
			UI32 targSize = GetUI32ActualSize(targV);
			IInstruction *pNew = nullptr;

			if(size == 1) {	// BYTE size but size(targV) > BYTE 
				if(targSize > 2) {	// BYTE size but size(targV) < HWORD
					pNew = new CIns_97_ld_w();
					pNew->opr(0)->SetConstraint(new CLoadAddressSelector(0xFEE00000 /*Not used*/, 0xFEEFFFFF /*Not used*/, 0x03, 4));
				} else if (targSize == 2) {	// size(targV) > HWORD, but size < WORD
					pNew = new CIns_93_ld_h();
					pNew->opr(0)->SetConstraint(new CLoadAddressSelector(0xFEE00000 /*Not used*/, 0xFEEFFFFF /*Not used*/, 0x01, 2));
				}
			}
			if(size == 2 && targSize > 2) {	// HWORD size but size(targV) > HWORD 
				pNew = new CIns_97_ld_w();
				pNew->opr(0)->SetConstraint(new CLoadAddressSelector(0xFEE00000 /*Not used*/, 0xFEEFFFFF /*Not used*/, 0x03, 4));
			}
			if(pNew != nullptr) {
				pNew->Fix();
				pNew->opr(0)->Replace(pNeed->opr(0)->Idx());
				pNew->opr(1)->Replace(pNeed->opr(1)->Idx());
				pIns->ClearInsNeed();
				delete pNeed;
				pNew->SetSequence(IInstruction::IF_SEQ_FWD);
				pNew->AppendComment(" --Forwarding Data instruction");
				pNew->SetForwardIns(pTarget);
				pTarget->SetInsNeed(pNew);
			}
		}

		// Set constraint for JUMP instruction that was not set beforehand.
		if(targetId == INS_ID_JARL || targetId == INS_ID_JMP || targetId == INS_ID_JMPD32) {
			pTarget->opr(0)->SetConstraint(new INumConstraint(targV, targV));
		}
		std::vector<IInstruction*> vIns = RegulateByForwardingIns(0 /*htid*/, targV, reg, ex, pTarget, pCB);

		UI32 idx = pCB->GetIndex(pIns);
		IInstruction *pNewIns = NULL;
		while(vIns.size()) {
			pNewIns = vIns.back();
			pCB->AddOpeCode(pNewIns, idx);
			vIns.pop_back();
		}
		if(pNewIns != NULL) {
			// Move direction to last inserted instruction.
			pIns->DirMoveTo(pNewIns);
			pCB->Remove(pIns);
			pCB->Update();
			return true;
		}
	}
	return false;
}

bool CSimulatorControl::RegulateValueConstraint(CCodeBlock* pCB, IInstruction* pIns) {
	_ASSERT(pCB);
	_ASSERT(pIns);

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	bool bForce = pIns->IsForcedAdjust();
	r.SetForce(bForce);
	r.SetRepeat(pIns->GetRepeat());

	/*skip regulation if UCPOP pIns*/
	UI32 insid = pIns->GetId();
	if ( insid == INS_ID_LDV_DW_2REG || insid == INS_ID_LDV_QW_2REG || insid == INS_ID_LDV_W_2REG || insid == INS_ID_LDVZ_H4_2REG 
	|| insid == INS_ID_STV_DW_2REG || insid == INS_ID_STV_QW_2REG || insid == INS_ID_STV_W_2REG || insid == INS_ID_STVZ_H4_2REG ) {
		return false;
	}

	if(pIns->GetMne() == "loop") {
		IValConstraint *pConst = pIns->opr(0)->GetConstraint();
		if(pConst != NULL && pConst->GetType(IValConstraint::DUMMY)) {
			IInstruction *pTemp;
			IInstruction *pNewIns;
			//[FROG]TODO: Improve it
			UI32 addr = (g_wm.BASE_PE + g_wm.SIZE_PE + 6*4*(512 >> 4));
			UI32 lp = pCB->GetIndex(pIns);
			UI32 i;
			// If r3 is used as loop counter.
			if(pIns->opr(0)->Idx() == 3) {
				UI32 reg = 0;
				for(UI32 i = lp - 1; i >= 0; i--) {
					IInstruction *pTemp = pCB->at(i)->GetRegulationTarget();
					if (pTemp == NULL) {
						pTemp = (pCB->at(i)->GetC2B1Ins() != nullptr) ? pCB->at(i)->GetC2B1Ins() : pCB->at(i)->GetForwardIns();
					}
					if(pTemp!= NULL && pTemp->GetMne() == "loop"){
						pTemp = pCB->at(i + 1);
						reg = pTemp->opr(1)->Idx();
						break;
					}
				}
				pNewIns = MOVR(reg, 3);
				pNewIns->SetInLoop();
				pCB->AddOpeCode(pNewIns, lp);
			}

			i = lp -1; // [FROG]TODO: If async occurs at loop?
			do {
				pTemp = pCB->at(i);
				if(pTemp->GetException().first != 0)
					break;
				i--;
			} while (pTemp->InLoop());
			if(pTemp->InLoop() || (pTemp->GetRegulationTarget() != NULL && pTemp->GetRegulationTarget()->InLoop())) {
				pNewIns = POPSP(1, 31); // Restore register status
				pNewIns->SetInLoop();
				pCB->AddOpeCode(pNewIns, lp);

				// Move stack address to r3
				pNewIns = MOV32(addr, 3);
				pNewIns->SetInLoop();
				pCB->AddOpeCode(pNewIns, lp);
				pIns->DirMoveTo(pNewIns);
			}

			pIns->opr(0)->RemoveConstraint(); // Remove dummy constraint
			return true;
		}
	}

	// Needed to RE-ASM when removing instruction
	if(AdjustJumpForwarding(pCB, pIns))
		return true;

	// Needed to RE-ASM when removing instruction
	if (!MaskSysRegLoad(pCB, pIns)) 
		return true;

	//       (a)  (b)  (c)
	// oprxx r1,  r4,  r1
	// 
	//       「(a)のr1」と「(c)のr1」に値制約がある場合、
	//        制約が矛盾する場合これを解決出来ない。
	//        「(c)のr1」制約は削除する->（a）の制約と同じになる。
	// 

	std::bitset<32> grlist(0);
    if(!pIns->SolveConstraint())
    {
	    for (UI32 x = 0; x < pIns->GetOpNum(); x++) {
		    IOperand* popr = pIns->opr(x);
		    if (popr->IsGR() && (popr->GetConstraint()!=NULL)) {
			    if (grlist[popr->Idx()]) {
				    popr->RemoveConstraint();
			    }else{
				    grlist.set(popr->Idx());
			    }
		    }
	    }
    }

    // WRについても、同一レジスタがオペランドで使用される場合、
    // ２つ目のオペランドに対する制約を削除する。
    // 補正命令が重複して作成されるのを防ぐため。
	std::bitset<32> wrlist(0);
	for( UI32 x = 0; x < pIns->GetOpNum(); x++ ) {
		IOperand* popr = pIns->opr(x);
		if( popr->IsWR() && (popr->GetConstraint() != NULL )) {
			if( wrlist[popr->Idx()] ) {
				popr->RemoveConstraint();
			} else {
				wrlist.set(popr->Idx());
			}
		}
	}


	if(pIns->GetId() == INS_ID_CACHE) {
		IValConstraint *pConst = pIns->opr(1)->GetConstraint();
		IOperand *pCacheOp = pIns->opr(0);
		if(((UI32) *pCacheOp) == 2 /*CFALI*/ && pConst != NULL) {
			pConst->SetType(IValConstraint::FETCH);
		}
	} else if (pIns->GetId() == INS_ID_PREF) {
		IValConstraint *pConst = pIns->opr(1)->GetConstraint();
		IOperand *pPrefOp = pIns->opr(0);
		if(((UI32) *pPrefOp) == 0 /*PREFI*/ && pConst != NULL) {
			pConst->SetType(IValConstraint::FETCH);
		}
	}

	auto CheckHALTReleaseCond = [=] (IInstruction *pIns) -> bool {
		// There is pending event.
		std::vector<CIntInfo*> vAcceptEvent;
		UI32 nPending = 0;
		std::vector<CIntInfo*>::iterator itr;
		for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
			CIntInfo *p = *itr;
			// Event will not be cleared and accepted.
			if(p->nClear != CIntInfo::ASYNC_CLEAR_PEND && CheckAcceptanceCond(p->sName, p->nPriority)) {
				vAcceptEvent.push_back(p);
			}
		}
		// The pending event can be cleared if its order is higher than accepted event
		UI32 *pHandlerOrder = g_mgr->GetHandlerOrder();
		for(itr = vAcceptEvent.begin(); itr < vAcceptEvent.end(); itr++) {
			UI32 nPend = 0;
			UI32 nAddr = g_exp->GetConfig((*itr)->nEventId)->m_addr;
			std::vector<CIntInfo*>::iterator i;
			for(i = m_vRequestedIntStack.begin(); i < m_vRequestedIntStack.end(); i++) {
				UI32 nPendingAddr = g_exp->GetConfig((*i)->nEventId)->m_addr;
				// The pending event may be cleared.
				if((*i)->sName != (*itr)->sName && pHandlerOrder[(nPendingAddr >> 4)] > pHandlerOrder[(nAddr >> 4)])
					nPend++;
			}
			// In the worst case
			if(nPend < nPending)
				nPending = nPend;
		}
		if(nPending > 0)
			return false;

		// HALT instruction need SV privilege
		if((GetPSW() & 0x40000000))
			return false;

		// HALT can not be released in Debug mode
		UI32 dir0 = 0;
		m_pSim->ReadNcReg(&dir0, 20, 3);

		if((dir0 & 0x1))
			return false;

		return true;
	};

	if(pIns->GetId() == INS_ID_HALT) {
		// Checking HALT release condition
		if(CheckHALTReleaseCond(pIns)) {
			IInstruction *p = NOP();
			p->AppendComment("Give-up regulation");
			pIns->DirMoveTo(p);
			pIns->AsyncMoveTo(p);
			PrepareDeletedIns(pCB, pIns);
			p = pCB->Replace(pIns, p);
			delete p;
			pCB->Update();
			return true;
		}
	}

	// ignore regulate the instruction if UCPOP exception occur
	UI32 psw = GetPSW();
	if (!((pIns->GetPriviledge() == 2) && ((psw & 0x20000) == 0))) {
		pIns->Regulate(&r);
		pIns->SetForcedAdjust(false);
	}

	if (r.Pass()) {
		// Memory Init before first access! --> to create __preload codeblock.
		if (pIns->Behavior(IInstruction::LOAD_MEMORY) || 
			pIns->Behavior(IInstruction::STORE_MEMORY) ) { // Store時も周辺８バイトで初期化
			std::vector<std::pair<UI32,UI32> >::iterator itr;
			for (itr = r.m_vEa.begin(); itr != r.m_vEa.end(); itr++) {
				const UI64 PSIZE = 4ULL;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;
				const UI64 ALIGN = ~(PFETCHSIZE - 1);
				UI64 start_na	= itr->first;					// NO Align head
				UI64 end_na		= itr->first + itr->second - 1;	// NO Align tail
				UI64 start_a	= start_na & ALIGN;				// Word Align head
				UI64 end_a		= end_na & ALIGN;

                if (pIns->GetId() == INS_ID_STM_GSR || pIns->GetId() == INS_ID_STM_MP) {
                    m_mNotSelfCheckMemoryList.insert(std::make_pair(start_na, end_na));
                }

                if (IsMDPexception(itr->first, itr->second, pIns->Behavior(IInstruction::LOAD_MEMORY), pIns->Behavior(IInstruction::STORE_MEMORY)) != NO_ERROR) {
                    // Set exception information
                    pIns->SetException(0x91, 0x90);
                }

				for (UI64 z = start_a; z <= end_a; z+=PFETCHSIZE) {
					UI64 rv = 0;
					rv = g_rnd.Get();			// Gereate RANDOM for initial value on memory(32bit upper).
					rv = (rv<<32)| g_rnd.Get();	// Gereate RANDOM for initial value on memory(64bit).
					m_pSim->PresetMemory(true ,0 ,z, PSIZE, (rv & 0xffffffff));
					if(PFETCHSIZE == 8) 
						m_pSim->PresetMemory(true ,0 ,z + PSIZE, PSIZE, (rv >> 32));
					#if DBGMODE && 0
					std::cout << pIns->GetCode() << "       => Preset address = 0x" << std::hex << z
					<< ", size="  << std::dec << PSIZE << ", val=0x" << std::hex << rv << std::endl;
					#endif
				}
			}
		}
		return false; /* false = 補正[しない]*/
	}
	
	if (r.NeedIns()) {
		// GR補正
		std::vector< std::pair<UI32,UI32> > & v_gr = r.m_vGr;
		std::vector< std::pair<UI32,UI32> >::iterator itr;

        // ２レジスタを補正する場合、レジスタAの補正命令を生成、
		// レジスタBの補正命令を生成するときにAの値を使用してはならない。
		// Aの補正後AをpushしBの補正時にはpushされているものは使用しない
		std::vector<UI32> exclude;
		std::vector<IInstruction*> vPrevIns;

		for (itr = v_gr.begin(); itr != v_gr.end(); itr++) {
			if (itr->first == 0) {
				std::cout << "GiveUpRecovery_R0" << std::endl;
				if(itr->second != 0) {
					pIns->SetForcedAdjust(bForce);
					GiveUpRecovery_R0(pIns, &r); // r0を補正しようとした
				}
			} else {

				IInstruction* pNewIns = (pIns->InLoop() || bForce || pIns->GetId() == INS_ID_DISPOSE_R3) ? 
					MOV32(itr->second, itr->first): 
					GenerateRegulatedInstructionGR32(0/*htid*/, itr->second, itr->first, exclude, &vPrevIns, pIns, pCB);

				// NULL means adjusted by forwarding instruction. Do not need to adjust any more.
				if(pNewIns != NULL) {
					if(pNewIns->GetComment().size() == 0)
						pNewIns->AppendComment("Regulation code !");
					//Adjust for dispose instruction
					if (pIns->GetId() == INS_ID_DISPOSE_R3){
						if (itr->first == pIns->opr(2)->Idx()) {
							delete pNewIns;	// Re-create adjustment code
							pNewIns = MOV32P(pIns->GetJumpTarget(), itr->first);
							pIns->SetInsNeed(pNewIns); 
						}
					}
					pNewIns->SetRegulationTarget(pIns);
					if(pIns->GetId() != INS_ID_LOOP)	// Do not move _Loop label to above loop counter intialization
						pIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
					pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
				}
			}
			exclude.push_back(itr->first);
		}

		// WR補正
		std::vector< std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> > > & v_wr = r.m_vWr;
		std::vector< std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> > >::iterator itrwr;
		std::bitset<4> elm_flg;
		__uint128_t val, cur_val;

		IInstruction *pNewIns;
		UI32 reg, addrReg;

		// Exclude loop counter register if current instruction belongs to a loop sequence.
		if(pIns->InLoop()) {
			UI32 idx = pCB->GetIndex(pIns);
			IInstruction *p = NULL;
			IInstruction *pLoop = NULL;
			while(idx < pCB->GetInstructionNum()) {
				p = pCB->at(idx);
				if(p->GetMne() == "loop") {
					pLoop = p;
					exclude.push_back(p->opr(0)->Idx());
					break;
				}
				idx++;
			}
			if(pLoop != NULL) {
				UI32 reglist = 0;
				while(idx > 0) {
					p = pCB->at(idx - 1);
					if(p->GetRegulationTarget() == pLoop)
						break;
					reglist |= p->GetConstraintBit();
					idx--;
				}
				for (UI32 i = 1; i < 32; i++) {
					if(reglist & (1 << i))
						exclude.push_back(i);
				}
			}
			
		}
		
		// Check whether selected register violate any constraint.
		auto IsRegValid = [&] (UI32 reg) {
			if(exclude.end() != std::find_if (exclude.begin(), exclude.end(), [&](UI32 x){return x == (UI32)reg;}))
				return false;
			return true;
		};

		// Randomize register for adjustment sequence.
		addrReg = 0;
		while(addrReg == 0){
			UI32 tmp = g_rnd.GetRange(4, 29);
			if(IsRegValid(tmp))
				addrReg = tmp;
		}

		// Set value for Wide Register
		for( itrwr = v_wr.begin(); itrwr != v_wr.end(); itrwr++ ){
			reg = itrwr->first;
			elm_flg = itrwr->second.first;
			val = itrwr->second.second;
			UI32 nWRMemPreset = g_wm.BASE_WR_PRESET + m_nWRMemOffset;
			
			//[FROG]TODO: Potential bug: when there are more than 8 WRs needed to be preset in loop, 
			// the memory will no enough. But the rate is rare.
			if((nWRMemPreset + 128 > g_wm.BASE_WORK_END) && (!pIns->InLoop())) {
				std::stringstream ss;
				std::string label;
				// Add a new WR memory preset block.
				m_nWRMemBlockCount++;
				m_bNewWRMemBlock = true;
				ss << "NMNT_wr_preset_memory_" << m_nWRMemBlockCount;
				ss >> label;
				pNewIns = MOV32P(label,11);
				pIns->DirMoveTo(pNewIns);// Directive MOVE for Label of Branch condition
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				pNewIns = JMP32(11);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			
				// Set return code after memory preset
				pNewIns = MOVR(g_rnd.GetRange(12, 31), 11);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
				pNewIns->SetLabel(label + "_ret");
				// Set return code after memory preset
				pNewIns = MOVR(g_rnd.GetRange(12, 31), 10);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				// Re-calculate memory address.
				m_nWRMemOffset = 0;
				nWRMemPreset = g_wm.BASE_WR_PRESET + m_nWRMemOffset;

			}

			// Get WR current value
			m_pSim->ReadWrReg(&cur_val, reg, 0);

			// Preset memory for WR. It will be recored and preset in _wr_preset_memory_
			for( UI32 elmnum = 0; elmnum < (sizeof(__uint128_t)/sizeof(UI32)); elmnum++ ){
				UI32 v;
				if( elm_flg.test(elmnum) ) {
					v = (UI32)(( val >> (elmnum * 32)) & ((__uint128_t)0xffffffffUL ));
				} else {
					v = (UI32)(( cur_val >> (elmnum * 32)) & ((__uint128_t)0xffffffffUL ));
				}
				m_pSim->PresetMemory(true, 0, (nWRMemPreset + elmnum * 4), 4, v, true);
			}

			pNewIns = MOV32(nWRMemPreset, addrReg);
			pNewIns->SetRegulationTarget(pIns);
			pIns->DirMoveTo(pNewIns);// Directive MOVE for Label of Branch condition
			pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

			// Load adjustment value to wide register
			pNewIns = LDVQW(0, addrReg, reg);   
			pNewIns->SetRegulationTarget(pIns);
			pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns)); 

			m_nWRMemOffset += 16;
		}

		// ブロック情報の更新
		pCB->Update();
	}

	if(r.GiveUpRegulate()) {
		// If removed instruction is 2nd ins. of C2B1
		if(pIns->InSequence(IInstruction::IF_SEQ_C2B1) && pIns->GetC2B1Ins() == nullptr) {
			IInstruction *pPrevIns = pCB->at(pCB->GetIndex(pIns) - 1);
			pPrevIns->DelComment();
			pPrevIns->SetC2B1Ins(nullptr);
		}
		if(pIns->InSequence(IInstruction::IF_SEQ_FWD) && pIns->GetForwardIns() != nullptr) {
			IInstruction *p = pIns->GetForwardIns();
			if(pCB->GetHandlerAddress() != 0 && (p->Behavior(IInstruction::LOAD_MEMORY) || p->Behavior(IInstruction::STORE_MEMORY)))
				pCB->Remove(p);
		}

		IInstruction *p;
		if ((pIns->GetMne() == "dispose") && (pIns->Behavior(IInstruction::JMP))) {
			// Insert move instruction.
			p = MOV32P(pIns->GetJumpTarget(), pIns->opr(2)->Idx());
			p->AppendComment("Give-up regulation");
			pIns->DirMoveTo(p);
			pCB->AddOpeCode(p, pCB->GetIndex(pIns));

			// Insert jump instruction.
			p =  JMP32(pIns->opr(2)->Idx());
			p->AppendComment("Give-up regulation");
			pIns->AsyncMoveTo(p);
			pCB->AddOpeCode(p, pCB->GetIndex(pIns));

			// Remove dispose instruction.
			pCB->Remove(pIns);

		} else {
			p = NOP();
			p->AppendComment("Give-up regulation");
			pIns->DirMoveTo(p);
			pIns->AsyncMoveTo(p);
			PrepareDeletedIns(pCB, pIns);
			p = pCB->Replace(pIns, p);
			delete p;
		}
		pCB->Update();
	}
	
	/* r.m_result(そのまま実行可能ならば真) => 論理反転する */
	return true; 	
}

bool CSimulatorControl::IsNativeMode( void ) {
	UI32 psw = 0;
	m_pSim->ReadNcReg(&psw, 5, 0);
	return ((psw & 0x80000000)==0);
}

/**
* @brief Get whether the simulator is in guest operation. .
* @Returns true if guest operation is in progress.
*/
bool CSimulatorControl::IsGuestMode(void) {
    UI32 pswh = 0;
    m_pSim->ReadNcReg(&pswh, 15, 0);
    return ((pswh & 0x80000000) != 0);
}

std::string CSimulatorControl::GetMContext() {
	std::stringstream ss;
	std::string strContext = "NM_";
	if(!IsNativeMode()) {

        UI32 gmid = 0, pswh = 0;
        m_pSim->ReadNcReg(&pswh, 15, 0);
        gmid = (pswh >> 8) & 0x7;
        ss << "GM" << std::dec << std::setw(2) << std::setfill('0') << gmid;
		ss << '_';
	}
	ss >> strContext;
	return strContext;
}

std::string CSimulatorControl::GetTContext() {
	std::stringstream ss;
	std::string strContext = "NMNT_";
	if(!IsNativeMode()) {

        UI32 gmid = 0, pswh = 0;
        m_pSim->ReadNcReg(&pswh, 15, 0);
        gmid = (pswh >> 8) & 0x7;
        ss << "GM" << std::dec << std::setw(2) << std::setfill('0') << gmid;

		ss << "T00"; // TODO: Support multi-thread
		ss << '_';
	}
	ss >> strContext;
	return strContext;
}

UI32 CSimulatorControl::GetTargetHandlerAddress(IExceptionConfig *pExp) {
	UI32 nHandlerAddress = pExp->m_addr;

	if (pExp->m_name == "EIINT") {
		UI32 pc, ebase, eiic;
		if(IsGuestMode()){
			m_pSim->ReadNcReg(&ebase, 19, 9);
			m_pSim->ReadNcReg(&eiic, 13, 9);
			m_pSim->ReadPC(&pc);
		} else {
            m_pSim->ReadNcReg(&ebase, 3, 1);
            m_pSim->ReadNcReg(&eiic, 13, 0);
            m_pSim->ReadPC(&pc);
		}

		// Direct vector method
		if(pc <= ebase + 0x1f0) {
			nHandlerAddress = pc - ebase;
		} else { // Reference table method
			nHandlerAddress += ((eiic & 0x0f) << 4);
			//[FROG]TODO: EITBL use NM handler
			nHandlerAddress |= 0x1;
		}
	} else if(pExp->m_name == "HVTRAP") {  // HVTRAP use NM handler
		nHandlerAddress |= 0x1;
	}

	nHandlerAddress |= IsNativeMode() ? 1 : 0;

	return nHandlerAddress;
	
}

UI32 CSimulatorControl::GetPSW( void ) {
	UI32 psw = 0, pswh = 0;
	m_pSim->ReadNcReg(&pswh, 15, 0);
	if ((pswh & 0x80000000) != 0) {
		m_pSim->ReadNcReg(&psw, 5, 9);	//GMPSW
	} else {
        m_pSim->ReadNcReg(&psw, 5, 0);  //PSW
    }
	return psw;
}

UI32 CSimulatorControl::GetINTCFG( void ) {
	UI32 intcfg = 0, pswh = 0;
	m_pSim->ReadNcReg(&pswh, 15, 0);
	if ((pswh & 0x80000000) != 0) {
		m_pSim->ReadNcReg(&intcfg, 21, 9);	//GMINTCFG
	} else {
        m_pSim->ReadNcReg(&intcfg, 13, 2);   //INTCFG
    }
	return intcfg;
}

UI32 CSimulatorControl::GetPLMR( void ) {
	UI32 plmr = 0, pswh = 0;
	m_pSim->ReadNcReg(&pswh, 15, 0);
	if ((pswh & 0x80000000) != 0) {
		m_pSim->ReadNcReg(&plmr, 22, 9);	//GMPLMR
	} else {
        m_pSim->ReadNcReg(&plmr, 14, 2);   //PLMR
    }
	return plmr;
}

/**
 * @brief シミュレーションGiveUp時の動作をハンドリングする。 
 * @param pIns シミュレーションも補正も出来ない命令
 */
void CSimulatorControl::GiveUpRecovery_R0(IInstruction* pIns, IRegulation *Reg) {
	
	IOperand* popr = NULL;
	for (UI32 N = 0; N < pIns->GetOpNum(); N++) {
		if (pIns->opr(N)->IsGR() && (pIns->opr(N)->Idx() == 0)) {
			popr = pIns->opr(N);
			break;
		}
	}
	
	if (popr ==NULL) std::cout << __FUNCTION__ << ":" << pIns->GetCode() << std::endl;
	_ASSERT(popr);
	
	/* FPU倍精度：r0でも可能な制約に書き換える */
	BS_ICAT bcat;
	//bcat.set(IInstruction::ICAT_FPU_D);
	//if (pIns->GetCategory() & bcat.to_ulong()) {
	//	//UI32 r = g_rnd.Get() & 3;
	//	UI32 r = g_rnd.Get() & 0; //[FROG]TODO: Fix it
	//	switch (r) {
	//	case 0:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_ZERO));
	//		break;
	//	case 1:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::NEGATIVE_ZERO));
	//		break;
	//	case 2:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_INF));
	//		break;
	//	case 3:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_INF));
	//		break;
	//	default:
	//		break;
	//	}
	//	pIns->AppendComment(" GiveUp-r0 ");
	//}
	
	/* FPU単精度：r0でも可能な制約に書き換える */
	bcat.reset();
	bcat.set(IInstruction::ICAT_FPU_S);
	bcat.set(IInstruction::ICAT_FPU_D);
	if (pIns->GetCategory() & bcat.to_ulong()) {
		popr->RemoveConstraint();
		pIns->AppendComment(" GiveUp-r0 ");
	} else {
		//if a instruction which source register is r0. Infinite loop occur due to can not regulate r0
		Reg->GiveUp();
	}
	
	/* r0からrXへ命令を再構成する */
}


/**
 * @param	htid	Thread id
 * @param	targV	目標値
 * @param	reg		補正対象のレジスタインデックス
 * @param	exclude	使用禁止のレジスタ情報
 */
IInstruction* CSimulatorControl::GenerateRegulatedInstructionGR32(UI32 htid, UI32 targV, UI32 reg, std::vector<UI32>& ex, std::vector<IInstruction*>* vPrevIns, IInstruction* pIns, CCodeBlock* pcb) {
	IInstruction *pNewIns;

	// Generate code for forwarding data instruction with dependent operand has constraint
	if(pIns->GetInsNeed().size() != 0){
		std::vector<IInstruction*> vIns = RegulateByForwardingIns(htid, targV, reg, ex, pIns, pcb);
		UI32 idx = pcb->GetIndex(pIns);
		while(vIns.size()) {
			pNewIns = vIns.back();
			pcb->AddOpeCode(pNewIns, idx);
			vIns.pop_back();
		}
		// Move direction to last inserted instruction.
		pIns->DirMoveTo(pNewIns);
		pcb->Update();
		return NULL;
	} else {
	// Generate regulation code for normal instruction 
	// [FROG]TODO: Adjustment code is alwasy MOV32 instruction (#62929)
//		for (UI32 rid = 1; rid < 31; rid++) {
//			bool bMatchOpr = false;
//			// The register value may be mismatch in RTL in FPI mode.
//			// Do not use these registers for regulation code.
//			if(m_nFPIStatus == FPI_START_PSW_ID_0 || m_nFPIStatus == FPI_START_PSW_ID_1 || m_nFPIStatus == FPI_NOT_ACCEPT)
//				break;
//
//			if (ex.end() != std::find_if (ex.begin(), ex.end(), [&](UI32 x){return x==(UI32)rid;})) {
//				continue;
//			}
//
//			if(vOprIdex.size() > 0){
//				for(UI32 i = 0; i < vOprIdex.size(); i++){
//					if (vOprIdex.at(i) == rid){
//						bMatchOpr = true;
//						break;
//					}
//				}
//			}
//
//			if(bMatchOpr)
//				continue;
//			
//
//			if (m_pSim->ReadGrReg(&reuse, (SI32)rid, htid) != true) {
//				std::runtime_error excep("Simulator error : Read GR");
//				throw excep;
//			}
//
//			// Low16bit補正可能
//			if ((reg & 1) && std::abs(((SI64)val) - reuse) < 0x7fff) {
//				SI32 valBuffer = val - reuse;
//				pNewIns = ADDI(valBuffer,rid,reg);
//
//#if LOGSW_REGULATION
//				MSG_INFO(0, "targV=%08X, reuse:r%d=0x%08X => cur: r%d=0x%08X, targ:r%d=0x%08X (Low:%d)\n", targV, rid, reuse, reg, curV, reg, val, valBuffer);
//#endif
//				return pNewIns;
//			} else if ((reuse>>16) == (val>>16)) {
//				UI32 v = (reuse & 0xffff) ^ (val & 0xffff);
//				pNewIns = XORI(v, rid, reg);
//#if LOGSW_REGULATION
//				MSG_INFO(0, "reuse:r%d=0x%08X => targ:r%d=0x%08X (Low:0x%04X)\n", rid, reuse, reg, val, v);
//#endif
//				return pNewIns;
//			}
//		}
		// TODO: 補正するパターンが必要
		pNewIns = MOV32(targV, reg);
	}
	return pNewIns;
}

std::vector<IInstruction*> CSimulatorControl::RegulateByForwardingIns(UI32 htid, UI32 targV, UI32 reg, std::vector<UI32>& ex, IInstruction* pIns, CCodeBlock* pcb) {
	std::vector<IInstruction*> vNewIns;
	std::vector<IInstruction *> &vNeededIns = pIns->GetInsNeed();
	IInstruction *pNeed = vNeededIns.back();
	IInstruction *pNewIns = NULL;
	UI32 valBuffer = 0;
	SI32 sValBuffer = 0;
	UI32 reuse = 0;
	UI32 nDisp = 0;
	UI32 rTemp = 0;
	auto CheckSignedRange = [] (SI32 val, UI32 bitsize) {
		SI32 min = (-1 * (1 << (bitsize - 1)));
		SI32 max = (1 << (bitsize - 1)) - 1;
		if(val >= min && val <= max)
			return true;
		return false;
	};
	//auto CheckUnSignedRange = [] (SI32 val, UI32 bitsize) {
	//	SI32 min = 0;
	//	SI32 max = (1 << bitsize) - 1;
	//	if(val >= min && val <= max)
	//		return true;
	//	return false;
	//};

	auto GenRandomRegister = [] (IInstruction *p, std::vector<UI32> ex, UI32 mask) {
		std::vector<UI32> reglist;
		std::vector<UI32>::iterator itr;
		UI32 size = mask + 1;
		for(UI32 i = 1; i < 32; i++) {
			UI32 checkInvalid = 0;
			checkInvalid |= (i & mask);	// Check odd/even index.
            for(UI32 r = 0; r < size; r++)
                checkInvalid |= ((1 << (i + r)) & (p->GetGrSrc() | p->GetGrDst()));    // Not used in p
			itr = std::find_if(ex.begin(), ex.end(), [&](UI32 r) {return (i == r);}); // Not be a excluded register.
			checkInvalid |= (itr == ex.end() ? 0 : 1);	// 0: Not included in ex, 1: was excluded
			if (checkInvalid == 0) {
				reglist.push_back(i);
			}
		}
		std::random_shuffle(reglist.begin(), reglist.end(), g_rnd);
		if(reglist.size())
			return reglist[0];
		else
			return (g_rnd.GetRange(0, 31) & ~mask);	// This case may cause error, but never occur.
	};

	switch (pNeed->GetId())
	{
		case INS_ID_SATADD_I5:
		// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > 0x7FFFFFFF)
				break;

			sValBuffer = g_rnd.GetRange((SI32)-16, (SI32)15);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;
			// This case caused saturated result in SATADDI5
			if((SI32) valBuffer < 0 && sValBuffer < 0 && targV != 0x80000000) {
				break;
			}

			// R0 can not be set non-zero value
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADD_I5:
			sValBuffer = g_rnd.GetRange((SI32)-16, (SI32)15);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;

			// R0 can not be set non-zero value
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOVI5:
			if(!CheckSignedRange(targV, 5))
				break;
			pNeed->opr(0)->Replace(targV);
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOV:
			// R0 can not be set non-zero value
			if(pNeed->opr(0)->Idx() == 0 && targV != 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADDI_SI16:
			sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADD:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = targV - reuse;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SUB:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = reuse - targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SUBR:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = reuse + targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ANDI_I16:
			// This instruction will AND only 16 MLS bits
			if(!CheckSignedRange(targV, 16))
				break;

			if(pNeed->opr(1)->Idx() == 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->Replace(g_rnd.GetRange(0, 0xffff) | targV);
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_AND:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			valBuffer = g_rnd.GetRange((UI32)0, (UI32)0xffffffff) | targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ORI:
			if(pNeed->opr(1)->Idx() == 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));

			// Generate random value for immediate
			valBuffer = g_rnd.GetRange(0, 0xffff);
			valBuffer = valBuffer & targV;  // Keep bits whose value is 1
			pNeed->opr(0)->Replace(valBuffer);

			// Generate random value for operand register
			valBuffer = targV & ~valBuffer; // Get the remains bits that need to be 1
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_OR:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			// Generate random operands
			valBuffer = g_rnd.Get();
			valBuffer = valBuffer & targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(0, 0));

			valBuffer = targV & ~valBuffer;
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_HSH:
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_XOR:
			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = reuse ^ targV;
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_NOT:
			valBuffer = ~targV;
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATADD:
			// The result of SATADD can not exceed maximum positive (0x7fffffff)
			if(std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = (SI32)targV - (SI32)reuse;

			// The above expression caused overflow.
			if ((SI32) reuse < 0 && (SI32) valBuffer < 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = targV - reuse;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32) reuse < 0 && (SI32) valBuffer < 0)
					break;

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATADD_R3:
			// The result of SATADD can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32) 0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = targV - reuse;
			// This case will cause saturated result
			if ((SI32) reuse < 0 && (SI32) valBuffer < 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = targV - reuse;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32) reuse < 0 && (SI32) valBuffer < 0)
					break;

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(1)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUB_R3:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = targV + reuse;
			// The above expression caused overflow.
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = (SI32)reuse - (SI32)targV;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(1)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUB:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = (SI32)reuse + (SI32)targV;
			// This case will cause saturated result
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				// The result of this expression can not overfllow because both reuse and targV are positive.
				valBuffer = (SI32)reuse - (SI32)targV;
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUBI:
			// The result of SATSUBI can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > 0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			sValBuffer = reuse - targV;
			if(sValBuffer >= (SI32)-32768 && sValBuffer <= (SI32)32767) {
				pNeed->opr(0)->Replace(sValBuffer);
			} else {
				sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
				pNeed->opr(0)->Replace(sValBuffer);

				valBuffer = sValBuffer + targV;
				// The above expression caused overflow. It will cause saturated in SATSUB
				if((SI32)valBuffer < 0 && (SI32) sValBuffer > 0 && targV != 0x80000000)
					break;
				
				if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUBR:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(1)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = (SI32)reuse + (SI32)targV;
			// This case will cause saturated result
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
				// The result of this expression can not overfllow because both reuse and targV are positive.
				valBuffer = (SI32)reuse - (SI32)targV;
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOVEA:
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			sValBuffer = targV - reuse;
			// Out of range
			if(std::abs((SI64)sValBuffer) >= 0x7FFF && pNeed->opr(1)->Idx() == 0) {
                pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
                m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
                sValBuffer = targV - reuse;
			}
            if(std::abs((SI64)sValBuffer) >= 0x7FFF) {
                sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
				SI32 sNewVal = (SI32)targV - sValBuffer;
                if(pNeed->opr(1)->Idx() == 0 && sNewVal != 0)
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint((UI32)sNewVal, (UI32)sNewVal));
			}
			pNeed->opr(0)->Replace(sValBuffer);
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF); // LD.B fixed bit#0 of disp to 0
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB23(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
						
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BUD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BUD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB23(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
						
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_DW:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if((rTemp & ~0x1) == (pNeed->opr(0)->Idx() & ~0x1) || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0x1);
			pNewIns = STDW23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 8));
			if(reg & 0x1)	// regulated register index is odd (in dest pair register)
				pNewIns->opr(0)->SetConstraint(new INumConstraint((UI64)targV << 32, (UI64)targV << 32));
			else
				pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LDL_W:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HUD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HUD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_WSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_WSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_B:
			nDisp = g_rnd.GetRange(0, 0x3F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTB (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_BU:
			nDisp = g_rnd.GetRange(0, 0xF) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTB (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_H:
			nDisp = g_rnd.GetRange(0, 0x7F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTH (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_HU:
			nDisp = g_rnd.GetRange(0, 0x1F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTH (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_W:
			nDisp = g_rnd.GetRange(0, 0x3F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTW (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
		case INS_ID_LD_B_INC:
		case INS_ID_LD_B_DEC:
		case INS_ID_LD_BU_INC:
		case INS_ID_LD_BU_DEC:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_H_INC:
		case INS_ID_LD_H_DEC:
		case INS_ID_LD_HU_INC:
		case INS_ID_LD_HU_DEC:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_W_INC:
		case INS_ID_LD_W_DEC:
		case INS_ID_LDL_BU:
		case INS_ID_LDL_HU:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
			
		default:
			break;
	}

	//[FROG]TODO: What do FROG do if instruction was passed already?
	// Can not generate forwarding couple
	if(vNewIns.size() == 0) {
		delete pNeed;
		pNewIns = MOV32(targV, reg);
		if(!pIns->InSequence(IInstruction::IF_SEQ_C2B1))
			pNewIns->SetForwardIns(pIns);
		pNewIns->SetSequence(IInstruction::IF_SEQ_FWD);
		pNewIns->AppendComment("Forwarding Data instruction");
		vNewIns.push_back(pNewIns);
	} else {
        // Move async. event label to new instruction by ratio 50:50
        if(g_rnd.Get() & 0x1) {
            pIns->AsyncMoveTo(pNeed);
        }
    }
	if(pcb->GetHandlerAddress() != 0) {
		std::for_each(vNewIns.begin(), vNewIns.end(), [](IInstruction *p) { p->SetForcedAdjust(true); });
	}
	pIns->ClearInsNeed();

	return vNewIns;
}

bool CSimulatorControl::Step(UI32 htid, UI32 lpc, UI32 ppc, IInstruction* pIns, ISimulatorStepResp * res) {
	_ASSERT(pIns);
	
	UI64 opecode	= pIns->Fetch();
	UI32 inslen		= pIns->GetLen();
	UI64 addrL1		= 0;
	UI64 sizeL1		= 0;
	UI64 addrL2		= 0;
	UI64 sizeL2		= 0;
	
	if (m_pSim->MmuTransferAddr(true, 0, lpc, inslen, MXU_ACC_FETCH, &addrL1, &sizeL1, &addrL2, &sizeL2) != true) {
		return false;
	}
	
	_ASSERT(inslen == (sizeL1 + sizeL2));
	
	if (sizeL2 != 0) {
		/* 実際はバイトアクセスされる */
		UI64	splitOpecode = 0;
		UI8*	splitPos = ((UI8*)&opecode) + sizeL1;
		memcpy((void*)&splitOpecode, (void*)splitPos, sizeL2); 
		memset((void*)splitPos, 0, sizeL2);
		if (m_pSim->WriteMemory(addrL2, sizeL2, splitOpecode)!=true) {
			return false;
		}
	}
	
	if (m_pSim->WriteMemory(addrL1, sizeL1, opecode) != true) {
		return false;
	}

	pIns->m_pswb = GetPSW();
	bool ret  = m_pSim->Step(htid, lpc, res);
	pIns->m_pswa = GetPSW();
	return ret;
}


bool CSimulatorControl::DecodeAddress(UI32 L, UI32* PL, UI32* PP) {
	_ASSERT(PP);
	
	UI64 physical;
	if (m_pSim->MmuTransferAddr(true, 0, L, 1, MXU_ACC_DONTCARE, &physical, NULL, NULL, NULL) != true) {
		return false;
	}
	*PL = L;
	*PP = (UI32)physical;
	return true;
}


bool CSimulatorControl::RecalcAbsoluteAddress(IInstruction* pIns) {
	UI32 opNum = pIns->GetOpNum();
	IOperand* popr;
	
	for (UI32 i = 0; i < opNum; i++) {
		popr = pIns->opr(i);
		if (popr->GetLabel() != NULL) {
			if (popr->Attr(IOperand::OPR_ATTR_RLABEL)!=true) {
				MSG_ERROR(0,"YY %s : opr(%d) %s (ALABEL) = 0x%08X\n", pIns->GetCode().data(), i, popr->GetLabel(), (UI32)(*popr));
			}else{
				MSG_INFO (0,"YY %s : opr(%d) %s (ALABEL) = 0x%08X\n", pIns->GetCode().data(), i, popr->GetLabel(), (UI32)(*popr));
			} 			
		}	
	}
	return false;
}

/**
 * @brief
 * 
 * Adjust random code block to control FPI exception
 * 
 */
bool CSimulatorControl::RegulateFPIException (CCodeBlock* pCB, IInstruction* pIns)
{
	// lambda: Check whether instruction is regulated in generation step.
	auto CheckRegulatedIns = [](IInstruction *pIns) {
		UI32 nInsId = pIns->GetId();
		if(nInsId == INS_ID_DISPOSE || nInsId == INS_ID_DISPOSE_R3
			|| nInsId == INS_ID_EIRET || nInsId == INS_ID_FERET || nInsId == INS_ID_CTRET
			|| (nInsId >= INS_ID_JARLSD22 && nInsId <= INS_ID_JARL) || nInsId == INS_ID_JMP) {
			return true;
		}
		return false;
	};

	// lambda: Check whether instruction is first regulation code.
	auto IsFirstRegulationIns = [](CCodeBlock* pCB, IInstruction* pIns){
		IInstruction *pPrev;
		UI32 nInsPos;

		// The first instruction of CB
		nInsPos = pCB->GetIndex(pIns);
		if(nInsPos == 0)
			return true;

		// Not the first regulation instruction
		pPrev = pCB->at(nInsPos - 1);
		if(pPrev->GetRegulationTarget() != NULL)
			return false;

		return true;
	};

	// lambda: Insert whether instruction belongs to a loop or sequence.
	auto CheckInSequenceIns = [](IInstruction *pIns){
		UI32 nInsId = pIns->GetId();
		if(pIns->InSequence() || pIns->InLoop())
			return true;
		if(nInsId == INS_ID_SWITCH || nInsId == INS_ID_WORD || nInsId == INS_ID_SHORT 
			|| nInsId == INS_ID_LOOP )
			return true;
		return false;
	};

	// lambda: Insert code to set PSW.ID = 1.
	auto SetPSWID = [&](IInstruction *pDirMoveIns, UI32 nPosition)
	{
		IInstruction *pNewIns = DI(); // PSW.ID = 1
		pNewIns->AppendComment("FPI Exception");
		pNewIns->SetValid(true);
		if(pDirMoveIns)
			pDirMoveIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
		pCB->AddOpeCode(pNewIns, nPosition);
	};

	// lambda: Insert code to clear PSW.ID = 0.
	auto ClearPSWID = [&](IInstruction *pDirMoveIns, UI32 nPosition)
	{
		IInstruction *pNewIns = EI(); // PSW.ID = 0	
		pNewIns->AppendComment("FPI Exception");
		pNewIns->SetValid(true);
		if(pDirMoveIns)
			pDirMoveIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
		pCB->AddOpeCode(pNewIns, nPosition);
	};

	// lambda: Insert code to clear FEPC.FPIVD = 0.
	auto ClearFPIVD = [&](IInstruction *pDirMoveIns, UI32 nPosition)
	{
		IInstruction *pNewIns = LDSR (0, 11, 0); // FPEC
		pNewIns->AppendComment("FPI Exception");
		pNewIns->SetValid(true);
		if(pDirMoveIns)
			pDirMoveIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
		pCB->AddOpeCode(pNewIns, nPosition);
	};

	// lambda: Insert code to recovery registers.
	auto FPIRec = [&](IInstruction *pDirMoveIns, UI32 nPosition)
	{
		std::string label("NM_");
		UI32 reg = g_rnd.GetRange(4, 29);
		IInstruction *pNewIns = MOV32P(label + "fpi_recovery", reg);
		pNewIns->AppendComment("FPI Exception");
		pNewIns->SetValid(true);
		if(pDirMoveIns)
			pDirMoveIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
		pCB->AddOpeCode(pNewIns, nPosition++);

		pNewIns = JARL32(reg, 31);
		pNewIns->AppendComment("FPI Exception");
		pNewIns->SetValid(true);
		pCB->AddOpeCode(pNewIns, nPosition++);

		pNewIns = MOVR(g_rnd.GetRange(0, 30), 31);
		pNewIns->SetValid(true);
		pNewIns->AppendComment("FPI Exception");
		pCB->AddOpeCode(pNewIns, nPosition); // Overwrite Gr31
	};

	IInstruction *pTargetIns;
	UI32 nPos = pCB->GetIndex(pIns);

	if(m_nFPIStatus == FPI_NONE)
		return false;

	// Support regulation code that inserted in generation phase
	pTargetIns = pIns->GetRegulationTarget();
	if(pTargetIns != NULL && (IsFirstRegulationIns(pCB, pIns) == false 
		|| CheckRegulatedIns(pTargetIns) == false)){
			return false;
	}

	if(pIns->GetMne() == "ei"){
		UI32 idx = nPos;
		IInstruction *p = pIns;
		if(pIns->InLoop() || pIns->InSequence()){
			IInstruction * pTemp = NOP();
			pTemp->AppendComment("Additional instruction for FPI - ei processing");
			pIns->DirMoveTo(pTemp);
			pTemp->SetSequence(pIns->GetSequence());
			pTemp->SetInLoop(pIns->InLoop());
			PrepareDeletedIns(pCB, pIns);
			pTemp = pCB->Replace(pIns, pTemp);
			delete pTemp;
			pCB->Update();
			return true; /* Re-Compile & Re-Sim */
		}

		while(p->InSequence() || p->InLoop() || p->GetMne() == "loop") {
			idx++;
			p = pCB->at(idx);
		}
		// EI is not in a loop/sequence
		if(p == pIns)	idx++;

		if(m_nFPIStatus == FPI_START_PSW_ID_0 || m_nFPIStatus == FPI_START_PSW_ID_1){
			FPIRec(p, idx++);
			ClearFPIVD(NULL, idx++); // Dummy in FROG
			m_nFPIMismatchReg = 0;
		} else 
			ClearFPIVD(p, idx++); // Dummy in FROG
		UI32 psw_id = (GetPSW() & 0x00000020) >> 5;
		psw_id == 1 ? SetPSWID(NULL, idx++) : ClearPSWID(NULL, idx++);
		pCB->Update();
        m_nFPIStatus = FPI_NONE;
		return true; /* Re-Compile & Re-Sim */
	}
	if(pIns->GetMne() == "di" && (m_nFPIStatus == FPI_START_PSW_ID_0 || m_nFPIStatus == FPI_START_PSW_ID_1)){
		IInstruction * pTemp = NOP();
		pIns->DirMoveTo(pTemp);
		pTemp->SetSequence(pIns->GetSequence());
		pTemp->SetInLoop(pIns->InLoop());
		pTemp->AppendComment("Additional instruction for FPI - di processing");
		PrepareDeletedIns(pCB, pIns);
		pTemp = pCB->Replace(pIns, pTemp);
		delete pTemp;
		pCB->Update();
		return true; /* Re-Compile & Re-Sim */
	}

	if( m_nFPIPendingIns == 0 && CheckRegulatedIns(pIns) == false && CheckInSequenceIns(pIns) == false)
	{
		/** FPI Exception description
		 * m_nFPIStatus {FPI_NONE, FPI_START_PSW_ID_0, FPI_START_PSW_ID_1, FPI_NOT_ACCEPT}
		 * m_nFPIPendingIns: Number of instruction that pending FPI handling.
		 */
		if(m_nFPIStatus == FPI_START_PSW_ID_1) {
			if(g_exp->RaiseException(Code_FPI)){
				ClearPSWID(pIns, nPos++);
				FPIRec(NULL, nPos++);
				SetPSWID(NULL, nPos++);
				ClearFPIVD(NULL, nPos++);
				pCB->Update();
				m_nFPIMismatchReg = 0;
				m_nFPIStatus = FPI_NONE;
				return true; /* Re-Compile & Re-Sim */
			} else{
				FPIRec(pIns, nPos++);
				m_nFPIMismatchReg = 0;
				if(!g_exp->RaiseException(Code_FPI)){
					ClearFPIVD(NULL, nPos++);
					m_nFPIStatus = FPI_NONE;
				} else {
					m_nFPIStatus = FPI_NOT_ACCEPT;
					m_nFPIPendingIns = 1;
				}
				pCB->Update();
				return true; /* Re-Compile & Re-Sim */
			}
		} else if (m_nFPIStatus == FPI_NOT_ACCEPT){// Only PSW.ID = 1
			if(!g_exp->RaiseException(Code_FPI)){
				ClearFPIVD(pIns, nPos++);

				pCB->Update();
				m_nFPIStatus = FPI_NONE;
				return true; /* Re-Compile & Re-Sim */
			} else {
				m_nFPIPendingIns = 1;
			}
		} else if (m_nFPIStatus == FPI_START_PSW_ID_0){
				FPIRec(pIns, nPos++);
				ClearFPIVD(NULL, nPos++);
				ClearPSWID(NULL, nPos++);
				pCB->Update();
				m_nFPIMismatchReg = 0;
				m_nFPIStatus = FPI_NONE;
				return true; /* Re-Compile & Re-Sim */
		}
	}
	if(m_nFPIPendingIns == 0)
		m_nFPIPendingIns = 1;

	return false;
}

/**
 * @brief
 * 
 * Remove propagation of FPU mismatch during FPI mode.
 * 
 */
bool CSimulatorControl::OverwriteFPIMismatch(CCodeBlock* pCB, IInstruction *pIns){
	// Overwrite FPCC register before transfer to PSW.Z
	if( (m_nFPIStatus == FPI_START_PSW_ID_0 || m_nFPIStatus == FPI_START_PSW_ID_1) && pIns->GetMne() == "trfsr" ){
		UI32 nPos = pCB->GetIndex(pIns);
		UI32 reg;
		bool bFPCCflag = false;
		if(nPos > 0 && pCB->at(nPos - 1)->GetMne() == "ldsr"){
			IInstruction *pPrevIns = pCB->at(nPos - 1);
			UI32 sreg = (UI32)*(pPrevIns->opr(1));
			if(sreg == 9) // FPCC
				bFPCCflag = true;
		}
		if(!bFPCCflag){
			do{
				reg = g_rnd.GetRange(0,31);
			} while( (m_nFPIMismatchReg & (1 << reg)) != 0 );
			IInstruction* pNewIns = LDSR(reg, 9, 0); // Overwrite FPCC
			pNewIns->SetRegulationTarget(pIns);
			pIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition

			pCB->AddOpeCode(pNewIns, nPos);
			pCB->Update();
			return true;
		}
	}

	// Overwrite general register
	if( m_nFPIMismatchReg != 0) {
		UI32 updateReg = 0;
		IInstruction *pTarget = pIns->GetRegulationTarget();
		if(pTarget == NULL){
			if(pIns->GetMne() == "jarl" || (pIns->Behavior(IInstruction::JMP) && pIns->Behavior(IInstruction::TRAP_EXCEPTION)))
				updateReg = m_nFPIMismatchReg;
			else if(!pIns->Category(IInstruction::ICAT_FPU_S) && !pIns->Category(IInstruction::ICAT_FPU_D) ){
				if(pIns->GetMne() == "loop"){
					IInstruction *p;
					UI32 idx = pCB->GetIndex(pIns) - 1;
					while( pCB->at(idx)->InLoop() == true)
						idx--;
					idx++;
					while((p = pCB->at(idx)) != pIns){
						updateReg |= m_nFPIMismatchReg & p->GetGrSrc();
						idx++;
					}

				} else
					updateReg = m_nFPIMismatchReg & pIns->GetGrSrc();
			}
		} else {
			if(pTarget->GetMne() == "ctret") {
				UI32 idx = pCB->GetIndex(pIns);
				IInstruction *p;
				while((p = pCB->at(idx)) != pTarget){
					updateReg |= m_nFPIMismatchReg & p->GetGrSrc();
					idx++;
				}
			}
		}

		if(updateReg != 0){
			for(UI32 reg = 1; reg < 32; reg++)
			{
				if(updateReg & (1 << reg)){
					IInstruction* pNewIns = MOV32(g_rnd.Get(), reg);
					if(pIns->GetId() != INS_ID_DBT)
						pNewIns->SetRegulationTarget(pIns);
					pIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
					pNewIns->AppendComment("Overwrite FPI mismatch");
					pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
				}
			}
			m_nFPIMismatchReg &= ~(updateReg);
			pCB->Update();
			return true; /* Re-Compile & Re-Sim */
		}
	}
	return false;
}

/**
 * @brief
 * 
 * Update status of FPI control variable.
 * 
 */
void CSimulatorControl::UpdateFPIStatus(IInstruction* pIns){
	//lambda: checking whether FPI Exception is caused.
	auto CheckFPIVDIsSet = [&] (){
		UI32 fpivdVal = 0;
		if(pIns->Category(IInstruction::ICAT_FPU_S) == false &&  pIns->Category(IInstruction::ICAT_FPU_D) == false)
			return false;

        m_pSim->ReadNcReg(&fpivdVal, 11, 0);

		// If FPI is caused, FPEC.FPIVD = 1.
		return (fpivdVal == 1);
	};

	// lambda: Check whether instruction is store value from system register that may be mismatched by FPI.
	auto IsStoreFPISReg = [] (IInstruction *pIns) {
			std::string mne = pIns->GetMne();
			if(mne == "stsr" || mne == "sttc.sr" || mne == "stvc.sr"){
				UI32 sr = (UI32) *(pIns->opr(0));
				UI32 regId = (sr & 0x1f);
				UI32 selId = (sr >> 5);
				if(selId == 0 
					&& (regId == 1 || (regId >=5 && regId <= 11))) { // EIPSW, PSW, FPSR, FPEPC, FPST, FPCC, FPCFG, FPEC
					return true;
				}
				if(selId == 2 && regId == 12) // ICSR
					return true;
			}
			return false;
	};

	if(m_nFPIPendingIns > 0 && (pIns->GetRegulationTarget() == NULL)
		&& (pIns->GetComment().find("for Break") == std::string::npos)) // Do not update FPI for DBTRAP/ORI of SS/AE break
		m_nFPIPendingIns--;

	if(m_nFPIStatus == FPI_NONE && CheckFPIVDIsSet()) { // FPIVD bit is updated to 1 by current instruction.
		m_nFPIPendingIns = g_rnd.GetRange(0, 20);
		if(((GetPSW() & 0x00000020) >> 5) == 1){ // PSW.ID = 1
			m_nFPIStatus = FPI_START_PSW_ID_1;
		} else {
			m_nFPIStatus = FPI_START_PSW_ID_0;
		}
	}

	// OVerwrite general register written back by FPU ins or STSR from FPI system register during FPI Mode
	if( m_nFPIStatus == FPI_START_PSW_ID_0 || m_nFPIStatus == FPI_START_PSW_ID_1 ){
		if(pIns->Category(IInstruction::ICAT_FPU_S) || pIns->Category(IInstruction::ICAT_FPU_D) || IsStoreFPISReg(pIns)){
			m_nFPIMismatchReg |= (pIns->GetGrDst() & ~1); // Remove r0
		} else {
			if(pIns->GetMne().find("div", 0) == std::string::npos){ // ZERO DIV and Skipped Instruction will not update register
				UI32 src = pIns->GetGrSrc();
				UI32 dst = pIns->GetGrDst();
				m_nFPIMismatchReg &= ~(dst & ~src); // Remove register used only as dest operand.
			}
		}
	}
}

/**
 * @brief ブレークポイントの設定と種別選択処理
 */
UI32 CSimulatorControl::GenerateBreakPointBeforeSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk) {
	UI32 num_of_channels = g_exp->GetNumOfChannels();
	UI32 break_point_weight = g_exp->GetBreakPointWeight(); // ブレークポイント生成比率取得
	IBreakParam bparam;
    UI32 break_type = IBreakParam::BREAK_NONE;
    UI32 range = 0;
    std::stringstream ss;
    std::string bp_label;

	if(( break_point_weight != 0 ) && ( pIns->GetId() != INS_ID_DBT ) ) {
		range = g_rnd.GetRange(1,100);
		if( break_point_weight >= range ) { // ブレークポイントを生成する
			// ブレークポイントの種別選択
            bparam = IBreakParam();
            break_type = bparam.m_type = g_exp->GetBreakType();
            bparam.m_block_num = std::atoi(pBlk->GetName().c_str() + 15);
            bparam.m_block_label = pBlk->GetLabel();
#if DBGMODE
                std::fprintf(stdout,"==> GetBreakType:%d\n",break_type);
#endif

            // ブレークポイントの生成時点での登録
            switch( break_type ) {
            case IBreakParam::BREAK_PCB :
				if (p->pBreakParam.size() < num_of_channels){
					ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
					ss >> bp_label;
					ss.str(""); ss.clear(std::stringstream::goodbit);
					pIns->SetLabel(bp_label);
					bparam.m_addr_label = bp_label;
					bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
					bparam.m_addr_mask = 0x0;
					bparam.m_data = 0x0;
					bparam.m_data_mask = 0x0;
					p->pBreakParam.push_back(bparam);
#if DBGMODE
                std::fprintf(stdout,"==> Create BreakParam for BREAK_PCB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;

            case IBreakParam::BREAK_LDB :
                if(pIns->Behavior(IInstruction::LOAD_MEMORY) & (! pIns->Behavior(IInstruction::STORE_MEMORY))&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_LDB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_SDB :
                if(pIns->Behavior(IInstruction::STORE_MEMORY) & (! pIns->Behavior(IInstruction::LOAD_MEMORY))&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_SDB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_RMWB :
                if((pIns->Behavior(IInstruction::STORE_MEMORY)) && (pIns->Behavior(IInstruction::LOAD_MEMORY))&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_RMWB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_LSAB :
                if(((pIns->Behavior(IInstruction::STORE_MEMORY)) || (pIns->Behavior(IInstruction::LOAD_MEMORY)) || (pIns->GetException().first != 0 /*EITBL*/))
					&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_LSAB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;

			    case IBreakParam::BREAK_SS :
                if(( ! pIns->InLoop()) && (!pIns->InSequence()) ) {
                    // SS(SingleStep)用情報生成
                    ss << pBlk->GetLabel() << "_db_" << p->pNotBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); DBTRAP命令にラベルを貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pNotBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_SS on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;

            case IBreakParam::BREAK_AE :
                // Break_AEの場合、対象命令がDISPOSE,PREPARE,POPSP,PUSHSP命令であること
                if(((pIns->GetId() == INS_ID_DISPOSE) || (pIns->GetId() == INS_ID_DISPOSE_R3) || ((pIns->GetId() >= INS_ID_POPSP) && (pIns->GetId() <= INS_ID_PUSHSP)))&& (!pIns->InSequence())) {
                    ss << pBlk->GetLabel() << "_db_" << p->pNotBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    pIns->SetLabel(bp_label);
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pNotBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_AE on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }
                break;
            case IBreakParam::BREAK_RLB :
                if( p->pBreakParam.size() > 0 ) {
                    pBlk->m_bRLB = true;
#if DBGMODE
                    std::fprintf(stdout,"==> Set Block.m_bRLB = 1 for BREAK_RLB\n");
#endif
                    break_type = IBreakParam::BREAK_NONE; // RLBの場合、BreakParamには登録しない
                } else {
                    break_type = IBreakParam::BREAK_NONE; // 条件が合わない場合は、ブレークポイントを生成しない
                }

                break;
            default:
                break_type = IBreakParam::BREAK_NONE; // ブレークポイントを生成しない
            }
        }
    }
#if DBGMODE
    fprintf(stdout,"==> Generate Break Type: %d break_point_weight:%3d range:%3d Pins:%3d %s\n",break_type,break_point_weight,range,pIns->GetId(),pIns->GetCode().c_str());
#endif
    return break_type;
}

/**
 * @brief ブレークポイント情報の生成処理
 */
void CSimulatorControl::GenerateBreakPointSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk) {
	UI32 access_type;
	UI64 address;
	UI32 size;
	UI64 value;
    std::stringstream ss;
    std::string bp_label;
	IBreakParam bparam;
	UI32 num_of_channels = g_exp->GetNumOfChannels();

    UI32 break_type;
    UI32 block_num;
    std::string block_label;

    if(p->pBreakParam.size())
    // ブレークポイントの種別毎に情報を生成する
    switch( p->pBreakParam.back().m_type ) {
    case IBreakParam::BREAK_PCB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_PCB\n");
#endif
        break;

    case IBreakParam::BREAK_LDB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_LDB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }  
		}
#endif
		m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 0, (UI32)m_pSim->SizeMemAccessLog() - 1));
		m_pSim->EachMemAccessLog( access_type, address, size, value );
        if( p->pBreakParam.back().m_addr_label == "" ) {
            p->pBreakParam.back().m_addr = address;
        }
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;
        
        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        case 8: // Double Word Access
            if( p->pBreakParam.size() <= num_of_channels ) {
                p->pBreakParam.back().m_data_mask = 0x00000000;
                bp_label = p->pBreakParam.back().m_addr_label;
                break_type = p->pBreakParam.back().m_type;
                block_num = p->pBreakParam.back().m_block_num;
                block_label = p->pBreakParam.back().m_block_label;
                bparam = IBreakParam();
                bparam.m_type = break_type;
                bparam.m_block_num = block_num;
                bparam.m_block_label = block_label;
                bparam.m_addr_label = bp_label;
                bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                bparam.m_data = (UI32)(value >> 32); // high value
                bparam.m_data_mask = 0x00000000;
                bparam.m_data_size = 0;
                p->pBreakParam.push_back(bparam);
            } else {
                p->pBreakParam.pop_back();
            }
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        if( size == 8 ) {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.at(p->pBreakParam.size()-2).m_addr,p->pBreakParam.at(p->pBreakParam.size()-2).m_addr_mask,p->pBreakParam.at(p->pBreakParam.size()-2).m_data,p->pBreakParam.at(p->pBreakParam.size()-2).m_data_mask);
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        } else {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        }
#endif
        break;
    case IBreakParam::BREAK_SDB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_SDB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }
        }
#endif
		m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 0, (UI32)m_pSim->SizeMemAccessLog() - 1));
		m_pSim->EachMemAccessLog( access_type, address, size, value );
        p->pBreakParam.back().m_addr = address;
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        case 8: // Double Word Access
            if( p->pBreakParam.size() <= num_of_channels ) {
                p->pBreakParam.back().m_data_mask = 0x00000000;
                bp_label = p->pBreakParam.back().m_addr_label;
                break_type = p->pBreakParam.back().m_type;
                block_num = p->pBreakParam.back().m_block_num;
                block_label = p->pBreakParam.back().m_block_label;
                bparam = IBreakParam();
                bparam.m_type = break_type;
                bparam.m_block_num = block_num;
                bparam.m_block_label = block_label;
                bparam.m_addr_label = bp_label;
                bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                bparam.m_data = (UI32)(value >> 32); // high value
                bparam.m_data_mask = 0x00000000;
                bparam.m_data_size = 0;
                p->pBreakParam.push_back(bparam);
            } else {
                p->pBreakParam.pop_back();
            }
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        if( size == 8 ) {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.at(p->pBreakParam.size()-2).m_addr,p->pBreakParam.at(p->pBreakParam.size()-2).m_addr_mask,p->pBreakParam.at(p->pBreakParam.size()-2).m_data,p->pBreakParam.at(p->pBreakParam.size()-2).m_data_mask);
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        } else {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        }
#endif
        break;
    case IBreakParam::BREAK_RMWB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_RMWB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }  
		} 
#endif
		m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 0, (UI32)m_pSim->SizeMemAccessLog() - 1));
		m_pSim->EachMemAccessLog( access_type, address, size, value );
        p->pBreakParam.back().m_addr = address;
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
#endif
        break;
    case IBreakParam::BREAK_LSAB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_LSAB\n");
		m_pSim->SetMemVariable(0);
		while(m_pSim->EachMemAccessLog( access_type, address, size, value )) {
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }  
		}
#endif
		if(m_pSim->SizeMemAccessLog() > 1) {
			m_pSim->SetMemVariable(g_rnd.GetRange((UI32) 1, (UI32)m_pSim->SizeMemAccessLog() - 1));
			m_pSim->EachMemAccessLog( access_type, address, size, value );
		} else {
			std::vector<MEMRANGE> vMem;
			if(pIns->GetException().first == 0x1c) { // SYSERR at autosave
				UI32 rbip, intbp, channel, rbcr0;
				rbip = intbp = channel = 0;
                m_pSim->ReadNcReg(&rbip, 18, 2);
                m_pSim->ReadNcReg(&rbcr0, 15, 2);
				if(IsGuestMode()) {
					m_pSim->ReadNcReg(&intbp, 20, 9);    // GMINTBP
				} else {
                    m_pSim->ReadNcReg(&intbp, 4, 1);
				}
				UI32 n = 0;
				IDirective *pDir = nullptr;
				while((pDir = pIns->GetDirective(n)) != nullptr) {
					CAsyncLabel* pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAsyncLabel != NULL && (pAsyncLabel->m_name == "eitbl" || pAsyncLabel->m_name == "gmeitbl")) {
						channel = pAsyncLabel->m_channel;
						break;
					}
					n++;
				}
				UI32 start, end;
				UI32 bank_size = ((rbcr0 >> 16) & 0x1) ? 0x90 : 0x60;
				start = end = intbp + 4 * channel;
				vMem.push_back(MEMRANGE(start, end));
				start = end = rbip;
				vMem.push_back(MEMRANGE(start, end));
				start = end = rbip;
				start = end = rbip - bank_size * 14;
				vMem.push_back(MEMRANGE(start, end));
				start = end = rbip - bank_size * 15;
				vMem.push_back(MEMRANGE(start, end));

				// Randomize order of vMem
				std::random_shuffle(vMem.begin(), vMem.end(), g_rnd);
				address = g_rnd.GetRange(vMem[0].first, vMem[0].second);
				size = 4;
				value = g_rnd.Get();
			}
		}
        p->pBreakParam.back().m_addr = address;
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
#endif
        break;

    default:
        // 到達しないはず
        break;
    }
    
}


void CSimulatorControl::GenerateBreakPointSetupBlock(IBlockSimParam* bsp) {
    std::vector<INode*>&    vHB = g_asf->GetPreloadBlock();
    std::string labelStr("");
    std::string labelStr2("");
    std::string labelSS("");
    std::string block_label("");
    std::stringstream ss;
    UI32 ins_cnt = 0;
    UI32 tmpR = g_mgr->GetHandlerWorkReg();
    UI32 tmpC = tmpR + 1; // DBPC - 2
    UI32 tmpD = tmpR + 2;
    UI32 dir1 = tmpR + 3;
    IInstruction* pIns;
    UI32 csl;
    CCodeBlock* pHB = nullptr;
    UI32 bpc;
    UI32 addr_mask;
    UI32 data_mask;
    UI32 rbsel;
	CCodeBlock*		pBlk	= bsp->pCodeBlock;
	UI32 SQ0 = 0;
	UI32 SQ1 = 0;
	UI32 peid = 0, gpid = 0, dbgen = 0;
	m_pSim->ReadSysRegister(&peid, "PEID", 0);
	m_pSim->ReadSysRegister(&dbgen, "DBGEN", 0);
	gpid = (peid & 0x700) >> 8;
	g_exp->GetChannelInSequential(&SQ0, &SQ1);
	static std::string sRetLabel = "";


    for( std::vector<INode*>::iterator itr = vHB.begin(); itr != vHB.end(); itr++ ) {
        pHB = static_cast<CCodeBlock*>(*itr);
        // ブレークハンドラの挿入位置を見つける
        if( pHB->GetName().find("breaksetup") != std::string::npos ) {
            if (bsp->pBreakParam.size()) {           
                block_label = bsp->pBreakParam.front().m_block_label.c_str();
                if (bsp->pBreakParam.front().m_addr == 0xff) {
                    bsp->pBreakParam.clear();
                }
            } else {
                block_label = bsp->pNotBreakParam.front().m_block_label.c_str();
            }
			pHB->FreeAddress();

            ss << block_label << "_breaknext";
            ss >> labelStr;
            ss.str(""); ss.clear(std::stringstream::goodbit);

			for (UI32 i = 0; i < pHB->GetInstructionNum(); i++) {
				IInstruction* pTmp = pHB->at(i);
				if (pTmp->GetLabel().find("_entry") != std::string::npos) {
					ins_cnt= i;
					break;
				}
			}

			if (ins_cnt == 0) {
				std::string sEntrLabel = pHB->GetLabel() + "_entry";
				dbgen |= (1 << gpid);
				pIns = MOV32( dbgen, tmpR);//Get Index'address
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = LDSR(tmpR, 0, 3);//Set DBGEN for current GPID
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = MOV32( g_wm.DBTRAP_PC_INDEX,tmpR);//Get Index'address
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = LDW16(0,tmpR,tmpD);	//Load index to reg1
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = ADD5(4, tmpD);
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = STW16(tmpD,0,tmpR); //update the index value
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = LDW16(0,tmpD,tmpR);	//Using tmpD as index to entry value
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = MOV32P(sEntrLabel, tmpD);	//Using tmpD as index to loadPC
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = ADD(tmpD, tmpR);
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = JMP32(tmpR);	//Jump to the suitable entry
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = JR22P(labelStr);
				pIns->SetLabel(sEntrLabel);
				pHB->AddOpeCode(pIns, ins_cnt++);
				sRetLabel = labelStr;
			} else {
				for (UI32 i = ins_cnt; i < pHB->GetInstructionNum(); i++) {
					IInstruction* pTmp = pHB->at(i);
					if (pTmp->GetId() != INS_ID_JRSD22) {
						ins_cnt= i;
						break;
					}
				}
				pIns = JR22P(labelStr);
				pHB->AddOpeCode(pIns, ins_cnt++);
			}

            // ブレークハンドラの対象コードブロック先頭であるか判定する
 /*           pIns = MOV32P( block_label.c_str(), tmpR ); // value of Block address
            pHB->AddOpeCode(pIns, ins_cnt++);
            pIns = CMPR( tmpR, tmpC );                //compare
            pHB->AddOpeCode(pIns, ins_cnt++);
            pIns = BNE17P( labelStr );                //if no then next
            pHB->AddOpeCode(pIns, ins_cnt++);*/

            // チャネルループの初期化とブレークイネーブルを設定する
            pIns = STSR( 21, dir1, 3 );               // Get DIR1
            pHB->AddOpeCode(pIns, ins_cnt++);
            pIns = MOV32( 0xffffff09, tmpR );		  // Clear bit DIR1.SQ0, DIR1.SQ1
            pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = AND( tmpR, dir1 );                 // DIR1.CSL, SQ0, SQ1 clear
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = ORI( 1, dir1, dir1 );              // DIR1.BEN set
			pHB->AddOpeCode(pIns, ins_cnt++);

			if(SQ0 == Code_Ch_DIR1_SQ0){
				pIns = ORI( 0x2, dir1, dir1 );				// DIR1.SQ0 set
				pIns->AppendComment("for Sequential Break Channel 0-1");
				pHB->AddOpeCode(pIns, ins_cnt++);
			}
			if(SQ1 == Code_Ch_DIR1_SQ1){
				pIns = ORI( 0x4, dir1, dir1 ); 
				pIns->AppendComment("for Sequential Break Channel 2-3");
				pHB->AddOpeCode(pIns, ins_cnt++);			// DIR1.SQ1 set
			}

            csl = 0;
			for( std::vector<IBreakParam >::iterator itr = bsp->pNotBreakParam.begin(); itr != bsp->pNotBreakParam.end(); itr++ ) {

				if((*itr).m_type == IBreakParam::BREAK_AE) { // DIR0.AEEの設定はコードブロックで１回のみで良い
					pIns = STSR( 20, tmpR, 3 );              // get DIR0(tmpR)
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = MOV32( 0xfffffdff, tmpD );        // set mask(tmpD)
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = AND( tmpD, tmpR );
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = ORI( 0x200, tmpR, tmpR );
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = LDSR( tmpR, 20, 3 );              // set DIR0.AEE=1
					pHB->AddOpeCode( pIns, ins_cnt++ );
				}
			}

            for( std::vector<IBreakParam >::iterator itr = bsp->pBreakParam.begin(); itr != bsp->pBreakParam.end(); itr++ ) {
                pIns = ORI( csl, dir1, tmpR);
                pHB->AddOpeCode(pIns, ins_cnt++);
                pIns = LDSR( tmpR, 21, 3);   //set DIR1.CSL
                pHB->AddOpeCode(pIns, ins_cnt++);

                if( pBlk->m_bRLB ){ // 他のチャネル登録がある時、リレー設定（RLB）の設定も必要ならば、
                    rbsel = 0x0;
                    // RBVE
                    rbsel |= g_rnd.GetRange(0,1) << 14;
                    // RBVSEL
                    rbsel |= ( 0x1 << g_rnd.GetRange(0,7) ) << 24;
					 // Enable RBCF in single core
					if((g_cfg->m_nSysPeNum <= 1) && (g_cfg->m_nPeWorkIdx == 0))
						rbsel |= 0x1 << 13;
                    // RBCE
                    rbsel |= g_rnd.GetRange(0,1) << 12;
                    // RBCSEL
                    rbsel |= ( 0x1 << g_rnd.GetRange(0,6) ) << 16;

                    pIns = STSR(  20, tmpR, 3 );                // Get DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32( 0x0000AFFF, tmpC );           // clear RBVSEL,RBCSEL,RBVE,RBCE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = AND( tmpC, tmpR );
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32( rbsel, tmpC );                // set RBVSEL,RBCSEL,RBVE,RBCE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = OR( tmpC, tmpR );
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR, 20, 3 );                 // set DIR0
                    pIns->AppendComment(" for Break_RLB ");
                    pHB->AddOpeCode(pIns, ins_cnt++);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_RLB DIR0:%08x\n",rbsel);
#endif                    
                }
				if(g_rnd.GetRange(1, 100) > 50){
					if(((SQ0 == Code_Ch_DIR1_SQ0) && (csl == 0))||((SQ1 == Code_Ch_DIR1_SQ1) && (csl == 32))){
						pIns = STSR( 22, tmpR, 3 );
						pHB->AddOpeCode(pIns, ins_cnt++);
						pIns = ORI( 0x20, tmpR, tmpR );
						pHB->AddOpeCode(pIns, ins_cnt++);
						pIns = LDSR( tmpR, 22, 3 );					// BPC.EO set
						pHB->AddOpeCode(pIns, ins_cnt++);
						csl += 16;
						continue;
					}
				}
				
				g_exp->SetChannel(&bpc, &addr_mask, &data_mask);
				//G4MH20 support enable break point for each GPID
				bpc |= 1 << (16 + gpid);
                // ブレーク例外種別毎にチャネルを設定する
                switch( (*itr).m_type ) {
                case IBreakParam::BREAK_PCB :
                    
                    bpc &= 0xFFFFFFFC; // WE=0,RE=0

                    pIns = MOV32( bpc, tmpR );     
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );                 // set BPC for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = MOV32P( (*itr).m_addr_label, tmpR ); // value of PC
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );                 // set BPAV for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = MOV32( addr_mask, tmpR );     
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );                 // set BPAM for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    break;

                case IBreakParam::BREAK_LDB :
                    
                    if( (*itr).m_data_size == 0 ) { // double word
                        bpc = 0x00000000;
                    } else {
#if DBGMODE
                        bpc = 0x10001019;
#else
                        bpc &= 0xfffffffb; // FE=0
#endif
                    }
                    data_mask |= (*itr).m_data_mask;
#if DBGMODE
                    addr_mask = 0xffffffff;
                    data_mask = 0xffffff00;
#endif
                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    if( (*itr).m_addr_label != "" ) {
                        pIns = MOV32P( (*itr).m_addr_label, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                        pIns = ADDI( (*itr).m_addr, tmpR, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                    } else {
                        pIns = MOV32( (*itr).m_addr, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                    }
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_SDB :
                    
                    if( (*itr).m_data_size == 0 ) { // double word
                        bpc = 0x00000000;
                    } else {
#if DBGMODE
                        bpc = 0x1000101a;
#else
                        bpc &= 0xfffffffb; // FE=0
#endif                        
                    }
                    data_mask |= (*itr).m_data_mask;
#if DBGMODE
                    addr_mask = 0xffffffff;
                    data_mask = 0xffffff00;
#endif
                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_RMWB :
                   
                    bpc &= 0xfffffffb; // FE=0
                    data_mask |= (*itr).m_data_mask;

                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_LSAB :
                    bpc &= 0xfffffffb; // FE=0
                    data_mask |= (*itr).m_data_mask;

                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );

#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x\n",bpc,(*itr).m_addr,addr_mask);
#endif
						break;
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;

                }
                csl += 16;
            }
            // Next Block

			pIns = JR22P(sRetLabel);
			pHB->AddOpeCode(pIns, ins_cnt++);

            pIns = NOP()->SetLabel(labelStr);
            pHB->AddOpeCode(pIns, ins_cnt++);
            for( std::vector<IBreakParam >::iterator itr = bsp->pNotBreakParam.begin(); itr != bsp->pNotBreakParam.end(); itr++ ) {
                labelStr2 = (*itr).m_addr_label + "_setpsw";
                if( (*itr).m_type == IBreakParam::BREAK_SS ) {
                    pIns = STSR( 18, tmpD, 3 );                 // Get DBPC
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32P( (*itr).m_addr_label, tmpR);  // value of SS's dbtrap
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ADDI( 2, tmpR, tmpR );               // dbtrap address + 2
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = CMPR( tmpR, tmpD );                  // Are you SingleStep's dbtrap?
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = BNE17P( labelStr2 );                  // if no then skip
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = STSR(  20, tmpR, 3 );                // Get DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ORI( 0x0010, tmpR, tmpR );           // set SSE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR, 20, 3 );                 // set DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = STSR(  19, tmpR, 3 );                 // Get DBPSW
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ORI( 0x0800, tmpR, tmpR );           // set SS bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR,  19, 3);                  //set DBPSW
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = NOP()->SetLabel(labelStr2);
                    pHB->AddOpeCode(pIns, ins_cnt++);
                }
            }
        }
    }
    bsp->pBreakParam.clear();
	bsp->pNotBreakParam.clear();
}

bool CSimulatorControl::CheckAcceptanceCond(std::string name, UI32 priority) {
	// Check acceptance condition before sending request.
	UI32 psw = 0, pmr = 0, dir0 = 0, ispr = 0, epl = 0; 
	bool bAccepted = true;

    psw = GetPSW();
    epl = (GetINTCFG() & 0x2) >> 0x1;
    pmr = GetPLMR();		// PLMR
    m_pSim->ReadNcReg(&dir0, 20, 3);
    m_pSim->ReadNcReg(&ispr, 10, 2);

	UI32 dir0_dm = dir0 & 0x01;

	if(name == "eiint" || name == "eitbl" || name == "gmeiint" || name == "gmeitbl" ) {
		UI32 plmr_msk = (pmr & 0xFF);
		// PSW.ID and PSW.NP = 0, PMR.PMx is masked
		if((plmr_msk <= priority) || ((psw & 0xa0) != 0) ||  (dir0_dm != 0)) {
			bAccepted = false;
		}

		//G4MH20 specs v1.07 section 3.1. New checking when INTCFG.EPL 
		if(epl == 0x1){// PSW.IMASK <= priority
			UI32 psw_eimask = psw & 0x0ff00000;
			if(psw_eimask <= priority)
				bAccepted = false;
		} else {// Checking ISPR
			priority = (priority > 15 ? 15 : priority);  
			UI32 ispr_msk = (ispr & 0x0ffff) & (0x0ffff >> (15 - priority));
			if(ispr_msk != 0)
				bAccepted = false;
		}

	} else if (name == "feint" || name == "gmfeint") {
		// PSW.NP = 0
		if((psw & 0x80) != 0 || dir0_dm != 0) {
			bAccepted = false;
		}
	} else if (name == "fenmi" || name == "dbint") {
		if(dir0_dm != 0) {
			bAccepted = false;
		}
	} else if (name == "dbnmi") {
		// No condition
	}

	return bAccepted;
}

bool CSimulatorControl::SyncCoProc(CCodeBlock *pCB, IInstruction *pIns) {
	UI32 pos = pCB->GetIndex(pIns);
	IInstruction *p = NULL;
	UI32 reg1, reg2, reglist = pIns->GetConstraintBit();
	// Limitation: Write ignore in G3KH when updating DR, DW, DX bits
	static UI32 default_mpm = 0xffffffff;
	UI32 mpm;

	if(IsGuestMode()) {
		m_pSim->ReadNcReg(&mpm, 25, 9);  // GMMPM
	} else {
        m_pSim->ReadNcReg(&mpm, 0, 5);
	}

	// Initialized default_mpm by first MPM value.
	if(default_mpm == 0xffffffff)
		default_mpm = mpm;

	if((mpm & 0x7) == (default_mpm & 0x7))
		return false;

	for(UI32 n = pos; n < pCB->GetInstructionNum(); n++) {
		IInstruction *p = pCB->at(n);
		if(p->InLoop() == false)
			break;
		if(p->GetMne() == "loop") {
			reglist |= p->opr(0)->Idx();
		}
	}

	do {
		reg1 = g_rnd.GetRange(4, 29);
		reg2 = g_rnd.GetRange(4, 29);
	} while(((1 << reg1) & reglist) || ((1 << reg2) & reglist) || (reg1 == reg2));

	// [FROG]TODO: Resolve hazard issue when updating MPM register
	p = MOV32(default_mpm, reg1);
	p->SetSequence();
	pIns->DirMoveTo(p);
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	p = STSR(8, reg2, 1);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	p = LDSR(0, 8, 1);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);
	
	p = LDSR(reg1, 0, 5);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);
	
	p = SYNCI();
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	p = LDSR(reg2, 8, 1);
	p->SetSequence();
	p->SetValid(true);
	pCB->AddOpeCode(p, pos++);

	return true;
}
/**
 *@brief	Check asynchronous label type of pending interrupt and request interrupt. EIINT, GMEIINT, EITBL, GMEITBL are same type
 *@param	event1: pending interrupt
 *@param	event2: request interrupt
 *@return	bool(true: interrupts have same type, false: different type)
 */
bool CSimulatorControl::CheckSameInterruptType(std::string event1, std::string event2) {
    /* EIINT = GMEIINT = EITBL = GMEITBL */
    /* FEINT = GMFEINT */
    std::set<std::string> InterruptType = {"eiint", "eitbl", "feint", "gmeiint", "gmeitbl", "gmfeint"};

    auto CorrectInterruptName = [=](std::string InterruptName) -> std::string {
        if (InterruptType.find(InterruptName) != InterruptType.end()) {
            if (InterruptName.find("fe") != std::string::npos) {
                return std::string("feint");
            } else {
                return std::string("eiint");
            }

        }
        return InterruptName;
    };

    event1 = CorrectInterruptName(event1);
    event2 = CorrectInterruptName(event2);

    if (event1 == event2) {
        return true;
    }

    return false;
}

/**
 * @brief	Check asynchronous label, then send interrupt request to simulator
 * @pIns	Current simulated instruction
 */
void CSimulatorControl::CheckInterruptRequest(CCodeBlock *pCB, IInstruction *pIns){
	IDirective	*pDir = NULL;
	CAsyncLabel *pAsyncLabel = NULL;
	UI32		n = 0;

	while((pDir = pIns->GetDirective(n)) != nullptr) {
		pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		if(pAsyncLabel == NULL) {
			n++;
			continue;
		}

		if(pAsyncLabel->m_bAssert) {
			const std::string &name = pAsyncLabel->m_name;
			std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
			while(itr < m_vRequestedIntStack.end()) {
				if(CheckSameInterruptType((*itr)->sName,name))
					break;
				itr++;
			}
			
			if(itr == m_vRequestedIntStack.end()) {
				UI32 period = g_rnd.GetRange(1, EXCEPTION_MIN_PROBABLY);
				// Support case MDP at EIINT reference table.
				// To make sure EIINT request at 1st instruction handler was clear before finishing executing MP_Handler.
				if(pCB->GetLabel().find("mp_handler") != std::string::npos) {
					IInstruction *pFirst = pCB->at(0);
					if(pFirst->GetRegulationTarget() != NULL)
						pFirst = pFirst->GetRegulationTarget();

					/* EIINT or GMEIINT or EITBL or GMEITBL */
					if(((name.find("eiint") != std::string::npos) || (name.find("eitbl") != std::string::npos)) && pFirst == pIns) {
						UI32 mei = 0;
                        m_pSim->ReadNcReg(&mei, 8, 2);
	
						if((mei & 0x3e) == 0x2a) { // MDP at reference table access
							pIns->RemoveDirective(pAsyncLabel);
							continue;
						} else 
							period = 0;
					}
				}
				m_vRequestedIntStack.push_back(new CIntInfo(pIns, name, period, pAsyncLabel->m_index, pAsyncLabel->m_priority, pAsyncLabel->m_causecode, pAsyncLabel->m_channel, pAsyncLabel->m_gpid));
				m_vRequestedIntStack.back()->nEventId = pAsyncLabel->m_nEventId;
				m_pSim->RequestInterrupt(0, name, pAsyncLabel->m_channel, pAsyncLabel->m_priority, pAsyncLabel->m_causecode, pAsyncLabel->m_gpid);
			} else {
				MSG_WARN(0, "Pending interrupt (%s) was requested again\n", name.c_str());
				MSG_WARN(0, "Pending interrupt, channel = %d, priority = %d\n", pAsyncLabel->m_channel, pAsyncLabel->m_priority);
				MSG_WARN(0, "New interrupt, channel = %d, priority = %d\n", (*itr)->nChannel, (*itr)->nPriority);
			}
		} else {
			m_pSim->ClearInterrupt(0, pAsyncLabel->m_name);
			std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
			while(itr != m_vRequestedIntStack.end()) {
				CIntInfo* p = *itr;
				if(pAsyncLabel->m_name == p->sName) {
					itr = m_vRequestedIntStack.erase(itr);
					delete p;
					break;
				} else
					itr++;
			}
		}
		n++;
	}
}

/**
 * @brief	Adjust codeblock when exception occurs
 * @param	pCB pointer to a code block structure
 * @param	pIns pointer to current executing instruction
 * @return	Specify whether code block was adjusted or not
 */
bool CSimulatorControl::RegulateException(CCodeBlock* pCB, IInstruction *pIns, IExceptionConfig* pCfg) {
	auto IsExpatEITBL = [&] (IExceptionConfig* pCfg) -> bool {
		bool bExpatEITBL = false;
		// Check whether MDP/SYSERR exception caused by EIINT interrupt
		if(pCfg->m_level == IExceptionConfig::EXP_LEVEL_FE) {

			UI32 cause_code = 0;
            if (IsGuestMode()) {
                m_pSim->ReadNcReg(&cause_code, 14, 9);
            } else {
                m_pSim->ReadNcReg(&cause_code, 14, 0);
            }
			cause_code &= 0x0ffff;
			if(cause_code == 0x95 /* MDP guest management*/ || cause_code == 0x9D /* MDP host management*/ || cause_code == 0x1c /* SYSERR */) {	// At EIINT
				bExpatEITBL = true;
			}
		}
		return bExpatEITBL;
	};

	UI32 insid = pIns->GetId();
	UI32 idx = pCB->GetIndex(pIns);
	bool bExpatEITBL = IsExpatEITBL(pCfg);
	UI32 feic = 0;
    if (IsGuestMode()) {
        m_pSim->ReadNcReg(&feic, 14, 9);
    } else {
        m_pSim->ReadNcReg(&feic, 14, 0);
    }

    feic &= 0xffff;
	// The exception was regulated or is a interrupt
	if(m_bRollback)
		return true;

	if(pCfg->m_bIsInterrupt && (pCfg->m_lcode != 0x0010 /*SYSERR*/ || feic == 0x0010 /*Async SYSEROR*/))
		return true;

	// These exception was processed beforehand due to read-only register DIR0
	if(insid == INS_ID_DBT || insid == INS_ID_RMT || insid == INS_ID_DBHVTRAP)
		return true;

    auto CauseConsecutive = [=] (CCodeBlock* pCB, IInstruction *pPrev) {
        // Mismatch between CFOREST and RTL in G4MH1.0
        // 1. EI        <-- EIINT is pending
        // 2. Ins       <-- Cause exception and de-assert EIINT
        if(pPrev->GetId() == INS_ID_EI) {
            // Check necessary to de-assert EIINT interrupt request
            UI32 *pHandlerOrder = g_mgr->GetHandlerOrder();
	        UI32 level = pHandlerOrder[(pCfg->m_addr >> 4)];

            std::vector<CIntInfo*>::iterator itr;
		    for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
			    CIntInfo* p = (*itr);
			    /* EIINT or GMEIINT or EITBL or GMEITBL */
				if((p->sName.find("eiint") != std::string::npos) || (p->sName.find("eitbl") != std::string::npos)) {
                    IExceptionConfig *pExp = g_exp->GetConfig(g_exp->GetKey(p->sName));
                    UI32 pending_level = pHandlerOrder[(pExp->m_addr >> 4)];
                    if(pending_level > level)
                        break;
                }
		    }

		    // There is pending EITBL/EIINT 
		    if(itr != m_vRequestedIntStack.end()) {
			    return true;
		    }
        }
        return false;
    };

	// Remove consecutive interrupt/event. Error case:
	//	1. Instruction 1 <-- Interrupt request
	//	2. Instruction 2 <-- Exception
	if(idx > 0 && pCfg->m_name != "MIP" && pCfg->m_name != "MIP_HM") {
		IInstruction *pPrev = pCB->at(idx - 1);
        if(pPrev->GetRiePartner() != NULL)
            pPrev = pCB->at(idx - 2); // Checked: (idx - 2) > 0
		if((pPrev->HasAsyncLabel() && !bExpatEITBL) || CauseConsecutive(pCB, pPrev) == true) {
			IInstruction * p = NOP();
			p->AppendComment("Additional instruction for Remove consecutive interrupt/event");
			pIns->DirMoveTo(p);
			pIns->AsyncMoveTo(p);
			pCB->AddOpeCode(p, idx);
			pCB->Update();
			m_pRollbackIns = pIns;
			return false; /* Rollback & Re-Compile & Re-Sim */
		}
	}

	return true;
}

void CSimulatorControl::SetException(IInstruction *pIns, IExceptionConfig *pExp, CCodeBlock* pCB) {
	std::string comment;
	UI32 cause_code = 0;
	std::string exp = pExp->m_name;
	bool bExpatEITBL = false;
	// Get cause code of occurred exception
    cause_code = m_pSim->GetCauseCode() & 0xffff;

	if(cause_code == 0x95 /* MDP guest management*/ || cause_code == 0x9D /* MDP host management*/ || cause_code == 0x1c /* SYSERR */) {	// At EIINT
		bExpatEITBL = true;
	}

	// Set exception information
	pIns->SetException(cause_code, GetTargetHandlerAddress(pExp));

	// Remove interrupt out of interrupt stack
	std::string name = exp;
	UI32 *pHandlerOrder = g_mgr->GetHandlerOrder();
	UI32 level = pHandlerOrder[(pExp->m_addr >> 4)]; // The request (MDP level < request level < EIINT level) will be deleted in EIINT setting.
	std::transform(name.begin(), name.end(), name.begin(), [] (int ch) {return std::tolower(ch);});
	std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
	while(itr < m_vRequestedIntStack.end()) {
		CIntInfo *p = *itr;
		IExceptionConfig *pExp = g_exp->GetConfig(g_exp->GetKey(p->sName));
		if((bExpatEITBL && p->sName == "eitbl") || (bExpatEITBL && p->sName == "gmeitbl")) {
			itr++;
			continue;
		}

		// Remove accepted event.
		if(CheckSameInterruptType(p->sName,name)) {
			itr = m_vRequestedIntStack.erase(itr);
			delete p;
		} else {
			UI32 pending_level = pHandlerOrder[(pExp->m_addr >> 4)];
			// 1. Higher level events can be generated in handler, it may cause conflict
			// 2. SYSERR will be serviced at FENMI vector handler, it is uncontrollable
			if(pending_level > level || (name == "fenmi" && p->sName == "syserr")) {
				UI32 n = 0;
				IDirective *pDir = nullptr;
				while((pDir = pIns->GetDirective(n)) != nullptr) {
					CAsyncLabel* pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAsyncLabel != NULL && pAsyncLabel->m_name == p->sName) {
						break;
					}
					n++;
				}

				// Event is requested by current instruction
				if(pDir != nullptr) {
					pIns->RemoveDirective(pDir);
					delete pDir;
				} else {
					CAsyncLabel *pAsyncLabel = new CAsyncLabel(p->sName, GetTContext(), m_nDeassertIdx++, false);
					pAsyncLabel->m_nEventId = p->nEventId;
					// Event was requested by preceding instruction -> Clear event

					if(pIns->InSequence(IInstruction::IF_SEQ_C2B1) && pIns->GetC2B1Ins() == nullptr){
						for(UI32 i = pCB->GetIndex(pIns); i > 0; i--){
							if(pCB->at(i)->InSequence(IInstruction::IF_SEQ_C2B1) && pCB->at(i)->GetC2B1Ins() == pIns /*&& pCB->at(i)->HasAsyncLabel()*/){
								if(pCB->at(i)->HasAsyncLabel()){
									IDirective *pDir = NULL;
									UI32 n = 0;
									// Gather async labels, and generate randomized position in custom sequence.
									while((pDir = pCB->at(i)->GetDirective(n)) != NULL) {
										CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
										if(pAL != NULL) {
											pCB->at(i)->RemoveDirective(pDir);
											continue;
										}
										n++;
									}
								} else
									pCB->at(i)->SetDirective(pAsyncLabel);
							}
						}
					} else{
						pIns->SetDirective(pAsyncLabel);
					}
				}
				itr = m_vRequestedIntStack.erase(itr);
				m_pSim->ClearInterrupt(0, p->sName);
				delete p;
			} else
				itr++;
		}
	}
}

bool CSimulatorControl::RegulateBeforeException(CCodeBlock *pCB, IInstruction *pIns) {
	CAsyncLabel*	pAsyncLabel;
	IDirective*		pDir;
	UI32			n;
	UI32			insid = pIns->GetId();

	auto CheckRequestExist = [=] (CAsyncLabel* pAsyncLabel) {
		std::vector<CIntInfo*>::iterator itr;
		for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++){
			CIntInfo* p = *itr;
			// Same assert event type is requested again with different channel or priority
			if(p->nClear != CIntInfo::ASYNC_CLEAR_PEND && CheckSameInterruptType(p->sName, pAsyncLabel->m_name)
				&& (p->nChannel != pAsyncLabel->m_channel || p->nPriority != pAsyncLabel->m_priority) ){
				return true;
			}
		}
		return false;
	};

	// De-assert interrupt
	if(DeassertInterrupt(pCB, pIns)) {
		return true; /* Re-Compile & Re-Sim */
	}

#if defined (_G4MH_) && !defined (_G4KH_)
	// Prevent consecutive interrupt request
	// Background: G4MH support executing 2 instruction in parallel.
	// Interrupt will be considered requesting at 2 instruction.
	if (RemoveConsecutiveRequest(pCB, pIns)) {
        return true;
    }
#endif

	n = 0;
	// Check and adjust requests at current instruction
	while((pDir = pIns->GetDirective(n)) != nullptr) {
		pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		if(pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
			const std::string &name = pAsyncLabel->m_name;
			// Remove request if it is pending
			if(CheckRequestExist(pAsyncLabel)) {
				//if(pCB->GetHandlerAddress() == 0
				pIns->RemoveDirective(pDir);
				delete pDir;
				continue;
			}
			// Limitation 2: Control interrupt in callt/syscall block
			if(!CheckAcceptanceCond(name, pAsyncLabel->m_priority) 
				&& (insid == INS_ID_CALLT || insid == INS_ID_SYSCALL || (insid >= INS_ID_JARLSD22 && insid <= INS_ID_JARL) || pIns->InLoop())){
				pIns->RemoveDirective(pDir);
				delete pDir;
				continue;
			}
		}
		n++;
	}

	std::vector<CIntInfo*>::iterator itr;
	// Traveling and check all pending interrupt whether they are accepted next step
	for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
		CIntInfo *pIntInfo = *itr;
		if(pIntInfo->nClear != CIntInfo::ASYNC_CLEAR_PEND && CheckAcceptanceCond(pIntInfo->sName, pIntInfo->nPriority)) {
			break;
		}
	}

	return false;
}

/**
 * @brief	Check status of requested event, then deciding clear un-accepted event
 * @param	pCB		current simulated code block
 * @param	pIns	Current simulated instruction
 * @return	If there is any event cleared, return true, otherwise, return false
 */
bool CSimulatorControl::DeassertInterrupt(CCodeBlock *pCB, IInstruction *pIns) {
	std::vector<CIntInfo*>::iterator itr;
	bool ret = false;

	auto NeedDeassert = [=] (CIntInfo* p) {
		UI32	insid = pIns->GetId();

		// Do not generate deassert label at 2nd instruction of C2B1
		if(pIns->InSequence(IInstruction::IF_SEQ_C2B1) == true && pIns->GetC2B1Ins() == nullptr)
			return false;

		// Reached maximum of pending step
		if(p->nPeriod == 0){
			return true;
        }

		if(!CheckAcceptanceCond(p->sName, p->nPriority) 
			&& ((insid >= INS_ID_JARLSD22 && insid <= INS_ID_JARL) || insid == INS_ID_SYSCALL || insid == INS_ID_CALLT || insid == INS_ID_HVCALL))
			return true;
		
		// Same event is requested in next instruction.
		if(!pIns->Behavior(IInstruction::JMP)) {
			IInstruction *pNext = nullptr;
			if(pIns->InSequence(IInstruction::IF_SEQ_C2B1) && pIns->GetC2B1Ins() != nullptr && !pIns->GetC2B1Ins()->Behavior(IInstruction::JMP)) {
				pNext = pCB->at(pCB->GetIndex(pIns) + 2); // Next instruction is always valid
			} else{
				pNext = pCB->at(pCB->GetIndex(pIns) + 1); // Next instruction is always valid
			}
			if(pNext != nullptr) {
				UI32 n = 0;
				IDirective	*pDir;
				while((pDir = pNext->GetDirective(n)) != nullptr) {
					CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAs != NULL && CheckSameInterruptType(pAs->m_name, p->sName)){
						return true;
					}
					n++;
				}
			}
		}
		// De-assert all pending events after TRAP 0x1d
		if(pCB->GetLabel().find("th_end_sync_sub") != std::string::npos) {
			return true;
		}

		if(pIns->GetComment().find("Changing privilege") != std::string::npos && pIns->GetRegulationTarget() != nullptr)
			return true;

		// De-assert all pending events after finishing simulating random code block
		if(pIns->GetChain()) {
			if (pIns->GetJumpTarget().find("th_end_sync") != std::string::npos)
				return true;
		}

		return false;
	};

	// Adjustment may be adjusted after simulating, don't generate deassert label
	if(pIns->GetRegulationTarget() != nullptr)
		return false;

	std::vector<IDirective *> vDeassertDir;

	itr = m_vRequestedIntStack.begin();
	while(itr < m_vRequestedIntStack.end()) {
		CIntInfo* pIntInfo = *itr;
		// This event was already cleared.
		if(pIntInfo->nClear != CIntInfo::ASYNC_CLEAR_NONE) {
			itr++;
			continue;
		}

		if(NeedDeassert(pIntInfo)) {
			// Generate de-assert label
			CAsyncLabel *pAsyncLabel = new CAsyncLabel(pIntInfo->sName, GetTContext(), m_nDeassertIdx++, false);
			pAsyncLabel->m_nEventId = pIntInfo->nEventId;
			UI32 n = 0;
			IDirective	*pDir;
			while((pDir = pIns->GetDirective(n)) != nullptr) {
				CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				// Remove assert and deassert for same events at the same time.
				if(pAs != NULL && CheckSameInterruptType(pAs->m_name, pIntInfo->sName)){
					pIns->RemoveDirective(pDir);
					delete pDir;
				}
				n++;
			}
			vDeassertDir.push_back(pAsyncLabel);
			pIntInfo->nClear = CIntInfo::ASYNC_CLEAR_PEND;
		}
		itr++;
	}

	auto CheckException = [] (IInstruction *p) {
		UI32 cause_code = p->GetException().first;
		// There is no exception
		if(cause_code == 0)
			return false;

		// MDP/SYSERR at EITBL
		if(cause_code == 0x95 || cause_code == 0x1c)
			return false;
		return true;
	};
	if(vDeassertDir.size() > 0) {
		UI32 idx = pCB->GetIndex(pIns);
		IInstruction *p = pIns;
		if(idx > 0) {
			IInstruction *pPrev = pCB->at(idx - 1);
			if(pPrev->HasAsyncLabel() || CheckException(pPrev)) {
				p = NOP();
				p->AppendComment("Additional instruction for Remove consecutive interrupt/event 1");
				pIns->DirMoveTo(p);
				pCB->AddOpeCode(p, idx);
				pCB->Update();
				ret = true;
			}
		}
		std::for_each(vDeassertDir.begin(), vDeassertDir.end(), [&p] (IDirective *pDir) {p->SetDirective(pDir);});
	}

	return ret;
}

/**
 * @brief	Check EXP/Interrupt due to internal priority
 * @param	pIns instruction need to check EXP/Interrupt
 * @param	pCB code block has internal priority
 * @return	True: Exp can occured at pIns
	        False: Exp can not occured at pIns
 */
bool CSimulatorControl::PredictException (CCodeBlock *pCB, IInstruction *pIns, UI32 expAddr) {

	bool result = false;
	UI32 InsId = pIns->GetId();
	auto GetOperand = [&pIns](UI32* sr) -> bool {
		if(pIns->GetId() == INS_ID_STSR){
			*sr = (UI32) *(pIns->opr(0));
			return true;
			}
		if(pIns->GetId() == INS_ID_LDSR){
			*sr = (UI32) *(pIns->opr(1));
			return true;
			}
		return false;
	};

	auto PSWEnableBit = [&](UI32 bitPos) -> bool {

		UI32 psw = GetPSW();
		if (((psw >> bitPos) & 0x1) == 1) return true;
			return false;
	};

	//Check EXP cause by instruction
	switch (expAddr) {
	case IBlockManager::ADR_VECTOR_RESET:
		break;
	// Not check yet 
	case IBlockManager::ADR_VECTOR_SYSERR:
		break;

	case IBlockManager::ADR_VECTOR_HVTRAP:

		{
		UI32 hvcfg = 0, pswh = 0, um = 0, psw = 0, gmpsw = 0;
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		m_pSim->ReadSysRegister(&psw, "PSW", 0);
		m_pSim->ReadSysRegister(&gmpsw, "GMPSW", 0);
		if(((hvcfg & 0x1) == 1) && InsId == INS_ID_HVTRAP){
			if((pswh >> 31) & 1) // Guest mode
				um = (gmpsw >> 30);
			else
				um = (psw >> 30);

			if(um == 0)
				result = true;
			}
		}

		break;

	case IBlockManager::ADR_VECTOR_FETRAP:
		if(InsId == INS_ID_FETRAP)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_TRAP0:
		if(InsId == INS_ID_TRAP) {
			UI32 vecTrap = (UI32)* (pIns->opr(0));
			if(vecTrap <= 0xf)
				result = true;
		}
		break;

	case IBlockManager::ADR_VECTOR_TRAP1:
		if(InsId == INS_ID_TRAP) {
			UI32 vecTrap = (UI32)* (pIns->opr(0));
			if(vecTrap > 0xf)
				result = true;
		}
		break;

	case IBlockManager::ADR_VECTOR_RIE:
		{
		if(InsId == INS_ID_RIE || InsId == INS_ID_RIE_I9 || InsId == INS_ID_HVCALL || (InsId >= INS_CID_RIE_FPU32 && InsId <= INS_CID_RIE_INT64))
			result = true;

		UI32 hvcfg = 0;
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		if((hvcfg & 0x1) == 0) {
			if ((InsId == INS_ID_HVTRAP) || (InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP))
				result = true;
		}
		}
		break;

	// Not check yet
	case IBlockManager::ADR_VECTOR_FPPFPI:
		{
		//Check FPU instruction
		if (PSWEnableBit(16) == true)	{
			UI32 fpsr = 0;		
			m_pSim->ReadSysRegister(&fpsr, "FPSR", 0);

			// Check FPU exception I V Z O U E
			//E3V5 spec page 340
			if ((/*XE enable*/(fpsr & 0x3E0) || /*no flush*/((fpsr & 0x20000) == 0)) 
				&& (InsId >= INS_ID_ABSF_D && InsId <= INS_ID_TRNCF_SW))
				result = true;
		}

		//Check FPSIMD instruction
		if(PSWEnableBit(17) == true){
			UI32 fxsr = 0;
			m_pSim->ReadSysRegister(&fxsr, "FXSR", 0);
			// Check FXU exception I V Z O U E
			if ((/*XE enable*/(fxsr & 0x3E0) || /*no flush*/((fxsr & 0x20000) == 0))
				&& (InsId >= INS_ID_CMOVF_W4 && InsId <= INS_ID_CMPF_S4))
				result = true;
		}
		}

		break;

	// Not check yet
	case IBlockManager::ADR_VECTOR_UCPOP:
		{
		UI32 sr = 0;
		GetOperand(&sr);
		// Check User Mode
		//Check FPU instruction
		if ((PSWEnableBit(16) == false) && ((InsId >= INS_ID_ABSF_D && InsId <= INS_ID_TRNCF_SW)
			|| ((InsId == INS_ID_LDSR || InsId == INS_ID_STSR) && ((sr >= (0*32) + 6) && (sr <= (0*32) + 11))))){
			result = true;
		}

		//Check SIMD instruction
		if (InsId >= INS_ID_CNVQ15Q30 && InsId <= INS_ID_VXOR){
			result = true;
		}

		//Check not support FPSIMD instruction
		if ( InsId == INS_ID_LDV_DW_2REG || InsId == INS_ID_LDV_QW_2REG || InsId == INS_ID_LDV_W_2REG || InsId == INS_ID_LDVZ_H4_2REG 
		|| InsId == INS_ID_STV_DW_2REG || InsId == INS_ID_STV_QW_2REG || InsId == INS_ID_STV_W_2REG || InsId == INS_ID_STVZ_H4_2REG ) {
	       result = true;
		}

		//Check FPSIMD instruction
		if ((InsId >= INS_ID_CMOVF_W4 && InsId <= INS_ID_CMPF_S4) || (((sr >= (10*32) + 0) && (sr <= (10*32) + 31)))){
			if(PSWEnableBit(17) == false) result = true;

		}

		}
		break;

	case IBlockManager::ADR_VECTOR_MPUMMU:
		//Check MDP 
		if (pIns->GetException().first == 0x91)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_PIE:
		{
		UI32 psw = 0, dir0 = 0, hvcfg = 0, pswh = 0;
		UI32 sr = 0;
		GetOperand(&sr);
		m_pSim->ReadSysRegister(&psw, "PSW", 0);
		m_pSim->ReadSysRegister(&dir0, "DIR0", 0);

		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);

		// Check User Mode
		auto IsUM = [&](UI32 hvcfg, UI32 psw) ->bool {
			return PSWEnableBit(30);
		};

				// Check HV priviledge system register
		auto IsHV = [&](UI32 hvcfg, UI32 pswh) -> bool {
			if(((hvcfg & 0x1) == 1) && ((pswh >> 31) == 0)) {
				return true;
			}
			return false;
		};

		if (IsUM(hvcfg, psw) == true)	{
			if(InsId == INS_ID_HALT || InsId == INS_ID_DI || InsId == INS_ID_EI || InsId == INS_ID_SYSCALL || InsId == INS_ID_DST 
				|| InsId == INS_ID_EST || InsId == INS_ID_HVTRAP || InsId == INS_ID_EIRET || InsId == INS_ID_FERET
				|| (InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP))	{
				result = true;
				break;
			}
			if(InsId == INS_ID_CACHE){
				UI32 cacheop = (UI32) *(pIns->opr(0));
				// CIBII, CFALI, CISTI, CILDI
				if(cacheop == 1 || cacheop == 2 || cacheop == 3 || cacheop == 4)	{
					result = true;
					break;
				}
			}
			// Check SV system register 
			if(InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
				if(/*Basic SysReg*/((sr >= (0*32) + 0) && (sr <= (0*32) + 3)) || (sr == (0*32) + 13) || (sr == (0*32) + 14) 
					|| (sr == (0*32) + 21) || (sr == (0*32) + 28) || (sr == (0*32) + 29) || ((sr >= (1*32) + 0) && (sr <= (1*32) + 6)) 
					|| (sr == (1*32) + 8) || (sr == (1*32) + 11) || (sr == (1*32) + 12) || (sr == (2*32) + 0) || (sr == (2*32) + 1) 
					|| (sr == (2*32) + 6) || (sr == (2*32) + 8) || ((sr >= (2*32) + 15) && (sr <= (2*32) + 18))
					||/*Interrupt Function SysReg*/ (sr == (1*32) + 7) || ((sr >= (2*32) + 10) && (sr <= (2*32) + 14))
					||/*Hardware Thread Control SysReg*/ (sr == (1*32) + 10) || (sr == (2*32) + 5) || ((sr >= (2*32) + 23) && (sr <= (2*32) + 31))
					||/*FPU SysReg*/ (sr == (0*32) + 6) || (sr == (0*32) + 7) || (sr == (0*32) + 11)
					||/*MPU SysReg*/ (sr == (5*32) + 0) || (sr == (5*32) + 2) || (sr == (5*32) + 16)
					|| ((sr >= (5*32) + 8) && (sr <= (5*32) + 11)) || ((sr >= (5*32) + 20) && (sr <= (5*32) + 31))
					||/*Cache Control SysReg*/ ((sr >= (4*32) + 12) && (sr <= (4*32) + 29)) 
					||/*Debug Function Reg*/ (sr == (3*32) + 0) || (sr == (3*32) + 1) || (sr == (3*32) + 13) || (sr == (3*32) + 15) 
                    ||/* count fucntion sysreg*/(sr == (11 * 32) + 8)
					|| (sr == (3*32) + 30) || ((sr >= (3*32) + 17) && (sr <= (3*32) + 27))) {
						result = true;
						break;
				}
			}
		}
		// Check Debug mode
		if((dir0 & 0x1) == 0)	{
			// Check debug instruction
			if(InsId == INS_ID_DBRET){
				result = true;
				break;
			}
			// Check debug system register 
			if(InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
				if(/*Debug Function Reg*/ (sr == (3*32) + 0) || (sr == (3*32) + 1) || (sr == (3*32) + 13) || (sr == (3*32) + 15) 
					|| (sr == (3*32) + 30) || ((sr >= (3*32) + 17) && (sr <= (3*32) + 27))) { 
						result = true;
						break;
				}
			}
		}

		if(IsHV(hvcfg, pswh) == false) {
			if(InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP) {
				result = true;
				break;
			}

			if(InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
				if(/* VM sysreg*/(sr == (0*32) + 15) || (sr == (0*32) + 18) || (sr == (0*32) + 19) ||/* SNZCFG*/ (sr == (0*32) + 21) 
					|| (sr == (1*32) + 16) || (sr == (1*32) + 17) || (sr == (1*32) + 20)
					|| /* DB sysreg*/(sr == (3*32) + 0) || (sr == (3*32) + 13) || (sr == (3*32) + 19) || (sr == (3*32) + 21) || (sr == (3*32) + 22)
					/* GM sysreg*/
					|| ((sr >= (9*32) + 0) && (sr <= (9*32) + 3)) || (sr == (9*32) + 5) || (sr == (9*32) + 13) 
					|| (sr == (9*32) + 14) || (sr == (9*32) + 16) || (sr == (9*32) + 17) || ((sr >= (9*32) + 19) && (sr <= (9*32) + 22)) 
					|| (sr == (9*32) + 25) || (sr == (9*32) + 26) || (sr == (9*32) + 28) || (sr == (9*32) + 29)
					|| /* MPBK sysreg*/(sr == (5*32) + 17) || (sr == (9*32) + 25) || (sr == (9*32) + 26)
					|| /*TSCTRL*/(sr == (11*32) + 2) || /* count fucntion sysreg*/(sr == (11*32) + 9) || ((sr >= (11*32) + 16) && (sr <= (11*32) + 31))
					|| /* all sysreg sel 12, sel 13*/((sr >= (12*32) + 0) && (sr <= (13*32) + 31))) {
						result = true;
						break;
					}
				if(InsId == INS_ID_LDSR && ((sr == (11*32) + 0) || (sr == (11*32) + 1) || /*MPIDn*/((sr >= (5*32) + 24) && (sr <= (5*32) + 31)))){
					result = true;
					break;
				}
			
				// Check Debug mode
				if((dir0 & 0x1) == 0 && ( /* DBPSWH*/(sr == (3*32) + 13) || /* DBPSW*/ (sr == (3*32) + 19))) {
					result = true;
					break;
				}

			}
			// Check cache priviledge
			if(InsId == INS_ID_CACHE){
				UI32 cacheop = (UI32) *(pIns->opr(0));
				// CIBII, CFALI, CISTI, CILDI
				if(cacheop == 1 || cacheop == 2 || cacheop == 3 || cacheop == 4)	{			
					result = true;
					break;
				}
			}
		}
			
		}
		break;

	case IBlockManager::ADR_VECTOR_DEBUG:
		if(InsId == INS_ID_DBT || InsId == INS_ID_DBHVTRAP || InsId == INS_ID_RMT)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_MAE:
		{
		if ((pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) ){
			IValConstraint* pVc = NULL;
			// STC in couple has not constraint
			if(InsId == INS_ID_STC_W || InsId == INS_ID_STC_H){
				UI32 accMem = 0;
				m_pSim->ReadGrReg(&accMem, pIns->opr(1)->Idx(), 0);
				if((InsId == INS_ID_STC_W && ((accMem & 0x3) != 0)) || (InsId == INS_ID_STC_H && ((accMem & 0x1) == 1)) ){
					result = true;
					break;
				}
			}
			for (UI32 N = 0; N< pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					continue;
				}
				if (popr->Attr(IOperand::OPR_ATTR_SMEM) || popr->Attr(IOperand::OPR_ATTR_LMEM)) {
					if (((pVc = popr->GetConstraint()) != NULL) && pVc->m_nMsk && (pVc->m_nUnA >= 1 && pVc->m_nUnA <= pVc->m_nMsk)) {
						result = true;
						break;
					}
				}
				
			}
		}
		break;
		}
	default :
		break;
	}

	return result;

}

/**
 * @brief	Check and prevent consecutive interrupt request
 * @param	pCB		current simulated code block
 * @param	pIns	Current simulated instruction
 * @return	If there is consecutive request, return true; otherwise, return false
 */
bool CSimulatorControl::RemoveConsecutiveRequest(CCodeBlock *pCB, IInstruction *pIns) {
    bool result = false;
	if(pCB == NULL || pIns == NULL)
		return false;

	auto SetInterrupt = [] (std::vector<CIntInfo*> *v) {
		std::vector<CIntInfo*>::iterator itr;
		for(itr = v->begin(); itr < v->end(); itr++)
			(*itr)->nClear = CIntInfo::ASYNC_CLEAR_REJECT;
			
	};

	auto CheckException = [] (IInstruction *p) {
		UI32 cause_code = p->GetException().first;
		// There is no exception
		if(cause_code == 0)
			return false;

		// MDP/SYSERR at EITBL
		if(cause_code == 0x95 || cause_code == 0x1c)
			return false;

		return true;
	};

	auto CanMoveToNext = [] (CCodeBlock *pCb, IInstruction *p) ->bool {
		UI32 idx = pCb->GetIndex(p);
		IInstruction *pNext = (idx < pCb->GetInstructionNum() - 1) ? pCb->at(idx) : NULL;
		if(pNext == NULL)
			return false;
		if(p->Behavior(IInstruction::JMP))
			return false;
		if(p->InSequence(IInstruction::IF_SEQ_C2B1) && p->GetC2B1Ins() == pNext)
			return false;
		if(pNext->InSequence() || pNext->InLoop())
			return false;
		return true;
	};

	auto CheckAsyncExist = [] (IInstruction *p, std::string name) {
		for(UI32 n = 0; n < p->GetDirectiveNum(); n++) {
			CAsyncLabel *pAL = static_cast<CAsyncLabel*> (p->GetDirective(n)->GetAsyncLabel());
			if(pAL == NULL)
				continue;
			/* EIINT = GMEIINT = EITBL = GMEITBL */
			/* FEINT = GMFEINT */
			
			std::string event1, event2;
			std::set<std::string> InterruptType = {"eiint", "eitbl", "feint", "gmeiint", "gmeitbl", "gmfeint"};

			auto CorrectInterruptName = [=](std::string InterruptName) -> std::string {
				if (InterruptType.find(InterruptName) != InterruptType.end()) {
					if (InterruptName.find("fe") != std::string::npos) {
						return std::string("feint");
					} else {
						return std::string("eiint");
					}
				}
				return InterruptName;
			};

			event1 = CorrectInterruptName(pAL->m_name);
			event2 = CorrectInterruptName(name);

			if (event1 == event2) {
				return true;
			}
		}
		return false;
	};

	 auto CauseConsecutive = [=] (CCodeBlock* pCB, IInstruction *pPrev, UI32 handlerAddr) {
        // Mismatch between CFOREST and RTL in G4MH1.0
        // 1. EI        <-- EIINT is pending
        // 2. Ins       <-- Cause exception and de-assert EIINT
        if(pPrev->GetId() == INS_ID_EI) {
            // Check necessary to de-assert EIINT interrupt request
            UI32 *pHandlerOrder = g_mgr->GetHandlerOrder();
	        UI32 level = pHandlerOrder[(handlerAddr >> 4)];

            std::vector<CIntInfo*>::iterator itr;
		    for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
			    CIntInfo* p = (*itr);
			     /* EIINT or GMEIINT or EITBL or GMEITBL */
				if(p->sName.find("eiint") != std::string::npos || p->sName.find("eitbl") != std::string::npos) {
                    IExceptionConfig *pExp = g_exp->GetConfig(g_exp->GetKey(p->sName));
                    UI32 pending_level = pHandlerOrder[(pExp->m_addr >> 4)];
                    if(pending_level > level)
                        break;
                }
		    }

		    // There is pending EITBL/EIINT 
		    if(itr != m_vRequestedIntStack.end()) {
			    return true;
		    }
        }
        return false;
    };

	auto ResolveConsecutiveRequest = [=] (CCodeBlock* pCB, IInstruction *p, bool bCanMoveToNext) -> void {
		UI32 idx = pCB->GetIndex(p);
		// It has consecutive request. Move the request to next instruction
		if(idx < pCB->GetInstructionNum() - 1) {
			IInstruction *pNext = pCB->at(idx + 1);
			// The next instruction may be executed already.
			if(bCanMoveToNext) {
				UI32 n = 0;
				IDirective *pDir = nullptr;
				while((pDir = p->GetDirective(n)) != NULL) {
					CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAL != NULL  && pAL->m_bAssert && CheckAsyncExist(pNext, pAL->m_name) == false) {
						p->RemoveDirective(pAL);
						pNext->SetDirective(pAL);
						continue;
					}
					n++;
				}
			}
			p->ClearAsync();
		}
	};

	UI32 idx = pCB->GetIndex(pIns);
	IInstruction *pPrev;

	if(idx == 0)
		return false;
	pPrev = pCB->at(idx - 1);
    if(pPrev->GetRiePartner() != NULL)
        pPrev = pCB->at(idx - 2);   // Checked: (idx - 2) > 0
	// The previous instruction has async. request or exception
	if(pPrev->HasAsyncLabel() || CheckException(pPrev) 
        || (pPrev->GetId() == INS_ID_EI && pIns->HasDeassertAsyncLabel())) {
        // The 3rd conditions is to support issue in RedMine #70902
	    // 1. EIINT was requested and pending
	    // 2. ei instruction was executed
	    // 3. next instruction (of EI) has deassert label for EIINT <-- EIINT is accepted in RTL, but cancel in CFOREST
		if(pIns->HasDeassertAsyncLabel()) {
			SetInterrupt(&m_vRequestedIntStack);
        }
		bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
		ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
	}
	// Consecutive
    // 1. pPrev has async label.
	// 2. EXP <- cancel async label by deassert label at 1
	for(UI32 handlerAddr = IBlockManager::ADR_VECTOR_RESET; handlerAddr < IBlockManager::ADR_VECTOR_NUM; handlerAddr += 0x10){
		if(PredictException(pCB, pIns, handlerAddr) && (pPrev->HasAsyncLabel() || CauseConsecutive(pCB, pPrev, handlerAddr))){
			IInstruction * p = NOP();
			p->AppendComment("Insertion instruction to avoid consecutive");
			pIns->DirMoveTo(p);
			pIns->AsyncMoveTo(p);
			pCB->AddOpeCode(p, idx);
			pCB->Update();
            result = true;
			break;
		}
	}

	if(pIns->GetId() == INS_ID_EI && idx < pCB->GetInstructionNum() - 1) {
        // Support issue in RedMine #62713#note-23
	    // 1. EIINT was requested and pending
	    // 2. ei instruction was executed
	    // 3. next instruction (of EI) has DBNMI label <-- EIINT is accepted
	    // 4. EIINT sequence (saving resource) <= DBNMI is requested
	    // 5. first instruction of EIINT handler <-- DBNMI is accepted
		std::vector<CIntInfo*>::iterator itr;
		for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
			CIntInfo* p = (*itr);
			if(p->sName.find("eiint") != std::string::npos || p->sName.find("eitbl") != std::string::npos)
				break;
		}
		// There is pending EITBL/EIINT 
		if(itr != m_vRequestedIntStack.end()) {
			IInstruction *pNext = pCB->at(idx + 1);
			bool bCanMoveToNext = CanMoveToNext(pCB, pNext);
			ResolveConsecutiveRequest(pCB, pNext, bCanMoveToNext);
		}
	}
	return result;
}

/**
*@brief	Store information about exception (return PC or code block of breakPC)
*@param	Exception cause code
*@param	pIns pointer to current executing instruction
*/
void CSimulatorControl::StoreExceptionInfo(UI32 cause_code, IInstruction* pIns, CCodeBlock* pCB) {
	static UI32 DBIdx = 0;
	static std::string sCurBlk = "";
	static UI64 DBevent = g_wm.DBTRAP_PC_INDEX;

	// Preset the return value for FEPC
	if (cause_code == 0xC0 /*MAE*/ || cause_code == 0xA0 /*PIE*/ || cause_code == 0x60 /*RIE*/ || cause_code == 0x71 /*FPE*/ || cause_code == 0x75 /*FXE*/ ||
		( cause_code >= 0x80 && cause_code <= 0x82 /*UCPOP*/ ) || 
		( cause_code >= 0x10 && cause_code <= 0x1F && cause_code != 0x1c /*SYSERR == 1c don't need preset*/)) 
	{ 
		UI64 Idxval;

		if (pIns->GetRiePartner() != nullptr) {
			m_pSim->ReadMemory( g_wm.EXP_RET_PC_INDEX , 4 , &Idxval );
			m_pSim->PresetMemory(true, 0, Idxval + 4, 4, 6);// RIE has size=6,implement by .word and .hword
		} else {
			m_pSim->ReadMemory( g_wm.EXP_RET_PC_INDEX , 4 , &Idxval );
			m_pSim->PresetMemory(true, 0, Idxval + 4, 4, pIns->GetLen());
		}

	}

	if (cause_code == 0xB1 /*DBTRAP*/) {
		std::string sBlkLabel = pCB->GetLabel();
		if (sBlkLabel.find("_codeblock_") != std::string::npos) {
			if (sBlkLabel != sCurBlk) {
				//Each value was assigned for a code block.
				DBIdx += 4;
				sCurBlk = sBlkLabel;
				//Increase the store address
				DBevent += 4;
				// Store to that index value
				m_pSim->PresetMemory(true, 0, DBevent, 4, DBIdx);
			} else {
				//Increase the index value
				DBevent += 4;
				// Store to that address
				m_pSim->PresetMemory(true, 0, DBevent, 4, DBIdx);
			}

		} else {
			DBevent += 4;
			m_pSim->PresetMemory(true, 0, DBevent, 4, 0);
		}
	}
}

bool CSimulatorControl::RecoveryFPIResources(CCodeBlock *pCB) {
	// Already inserted code to recover resources
	if(pCB->GetInstructionNum() > 4) {
		return false;
	}

	CSimResource res;
	UI32 size;
	IInstruction *pNewIns;
	UI32 reg = g_rnd.GetRange((UI32) 4, (UI32) 29);
	UI32 ep = 30;
	UI32 pos = 1;

	m_pSim->GetFPIUpdatedResource(&res);

	// Recovery memory
	size = res.m_logs.size();
	for(UI32 n = 0; n < size; n++) {
		T_MEMWRRECORD m = res.m_logs[n];
		UI32 mem_size = m.second.first;
		if(mem_size == 1) {
			pNewIns = MOV32(m.first, ep);	// Address
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = MOV32(m.second.second, reg); // Value
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = SSTB(reg, 0);			// Store memory
			pCB->AddOpeCode(pNewIns, pos++);
		} else if (mem_size == 2) {
			pNewIns = MOV32(m.first, ep);	// Address
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = MOV32(m.second.second, reg); // Value
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = SSTH(reg, 0);			// Store memory
			pCB->AddOpeCode(pNewIns, pos++);
		} else if (mem_size == 4) {
			pNewIns = MOV32(m.first, ep);	// Address
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = MOV32(m.second.second, reg); // Value
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = SSTW(reg, 0);			// Store memory
			pCB->AddOpeCode(pNewIns, pos++);
		} else if (mem_size == 8) {
			pNewIns = MOV32(m.first, ep);	// Address
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = MOV32((m.second.second & 0xffffffff), reg); // Value
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = SSTW(reg, 0);			// Store memory
			pCB->AddOpeCode(pNewIns, pos++);

			pNewIns = MOV32(m.second.second >> 32, reg); // Value
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = SSTW(reg, 4);			// Store memory
			pCB->AddOpeCode(pNewIns, pos++);
		}
	}

	// Recovery system register
	if (IsNativeMode()) {
		size = res.m_nc.size();
		for(UI32 n = 0; n < size; n++) {
			SRVAL srval = res.m_nc[n];
			pNewIns = MOV32(srval.second, reg);
			pCB->AddOpeCode(pNewIns, pos++);
			pNewIns = LDSR(reg, srval.first & 0x1f, srval.first >> 5);
			pCB->AddOpeCode(pNewIns, pos++);
		}
		//[FROG]TODO: TC, VC register is updated in native
	} else {
		// [FROG]TODO: NC Register is updated in virtual mode
		for(UI32 n = 0; n < res.m_tc.size(); n++) {
			for(UI32 m = 0; m < res.m_tc[m].size(); m++) {
				SRVAL srval = res.m_tc[n][m];
				pNewIns = MOV32(srval.second, reg);
				pCB->AddOpeCode(pNewIns, pos++);
				pNewIns = LDSR(reg, srval.first & 0x1f, srval.first >> 5);
				pCB->AddOpeCode(pNewIns, pos++);
			}
		}

		for(UI32 n = 0; n < res.m_vc.size(); n++) {
			for(UI32 m = 0; m < res.m_vc[m].size(); m++) {
				SRVAL srval = res.m_vc[n][m];
				pNewIns = MOV32(srval.second, reg);
				pCB->AddOpeCode(pNewIns, pos++);
				pNewIns = LDSR(reg, srval.first & 0x1f, srval.first >> 5);
				pCB->AddOpeCode(pNewIns, pos++);
			}
		}
	}
	// [FROG]TODO: Recovery wide register

	// Recovery general register
	for (UI32 i = 1; i < 31; i++) {
		pNewIns = RANDGR(i);
		pCB->AddOpeCode(pNewIns, pos++);
	}

	// Recovery vector register
	for (UI32 i = 0; i < 32; i++) {
		pNewIns = LDTC_VR((i & 0x1E), i);
		pCB->AddOpeCode(pNewIns, pos++);
	}
	return false;
}

void CSimulatorControl::RestoreRegulatedGR(CCodeBlock *pCB) {
	if(m_vExpLabelStack.size() == 0)
		return;
	std::string mp_label = m_vExpLabelStack.back();
	std::map<std::string, GRVALSET>::iterator itr = m_mRegulatedGrList.find(mp_label);
	GRVALSET grset;
	if(itr == m_mRegulatedGrList.end()) {
		m_vExpLabelStack.pop_back();
		return;
	}
	grset = itr->second;

	// Overwrite Gr stack memory
	GRVALSET::iterator itrGrVal;
	for(itrGrVal = grset.begin(); itrGrVal < grset.end(); itrGrVal++) {
		UI32 reg = itrGrVal->first;
		if(reg == 3) {
			reg = g_mgr->GetHandlerReg();
		}
		UI32 disp = (31 - reg) * 4;
		UI32 sp_val;
		m_pSim->ReadGrReg(&sp_val, 3, 0);
		m_pSim->WriteMemory(sp_val + disp, 4, itrGrVal->second);
	}
	m_vExpLabelStack.pop_back();
}

/**
 * @brief
 * 
 * コードブロックのシミュレーションを実施する。
 * 
 */
bool CSimulatorControl::BlockSimulation(IBlockSimParam* p) {
	_ASSERT(m_pSim);
	_ASSERT(p);
	_ASSERT(p->pCodeBlock);

	UI32 break_point_weight = g_exp->GetBreakPointWeight(); // ブレークポイント生成比率取得
	CCodeBlock*		pBlk	= p->pCodeBlock;
	IInstruction*	pIns;
    IInstruction*   pNewIns;
    UI32 break_type = IBreakParam::BREAK_NONE;
    std::string labelStr;
#if DBGMODE
    std::stringstream ss;
#endif

	{	// Native Dataの展開
		std::vector<UI32> vndl = pBlk->GetNativeDataArray();
		for (UI32 i = 0; i < vndl.size(); i++) {
			IInstruction* pNd = pBlk->Fetch(vndl[i]);
			m_pSim->WriteMemory (vndl[i], pNd->GetLen(), (UI32)(*pNd->opr(0)));
		}
	}

	// take snapshot(for self-check verifier)
	if (pBlk->IsEnableSnapShot() && pBlk->GetSnapShot()==nullptr) {
		CSimResource* res = GetResource();
		pBlk->SetSnapShot(res); 
	}

	//[FROG]TODO: Improve it
	if(pBlk->GetLabel().find("fpi_recover_resource") != std::string::npos) {
		if(RecoveryFPIResources(pBlk)) {
			p->result.set(IBlockSimParam::BSR_REASM);
			return true; /* Re-Compile & Re-Sim */
		}
	}

	if(pBlk->GetLabel().find("handler_returnsetup") != std::string::npos) {
		RestoreRegulatedGR(pBlk);
	}

	if(pBlk->GetLabel() == "NM_memory_init" && m_bNewWRMemBlock) {
		IInstruction *pNewIns;
		std::stringstream ss;
		std::string label;
		m_bNewWRMemBlock = false;

		ss << "NMNT_wr_preset_memory_" << m_nWRMemBlockCount;
		ss << "_ret";
		ss >> label;
		pNewIns = MOV32P(label,11);
		pBlk->AddOpeCode(pNewIns);
		pNewIns = JMP32(11);
		pBlk->AddOpeCode(pNewIns);

		std::stringstream ss1;
		ss1 << "NMNT_wr_preset_memory_" << (m_nWRMemBlockCount + 1);
		ss1 >> label;
		pNewIns = NOP();
		pNewIns->SetLabel(label);
		pBlk->AddOpeCode(pNewIns);
		p->result.set(IBlockSimParam::BSR_REASM);
        return true; /* Re-Compile & Re-Sim */
	}

	while (true) {
		//!< Fetch Next Instrcution	
		pIns = pBlk->Fetch(p->ppc);
		if (pIns == NULL) {
			if ((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize()))) {
				MSG_ERROR(0, "Detected invalid PC={ LA:%08X, PA:%08X }\n", p->lpc, p->ppc);
				p->result.set(IBlockSimParam::BSR_FATALERROR);
				return false;	/* Sim Stop */
			}else{

                // Issue #2 on ticket #86972
  				if(pBlk->IsRegulation() && pBlk->GetBreakSetupInsFlag() && (p->bPrevChain == true)) {
				    if((p->pBreakParam.size() == 0) &&(p->pNotBreakParam.size() == 0)) {
                         // Create break point dummy
                       // std::cout << "Break_Setup " << pBlk->at(i)->GetOutCode() << "\t" << pBlk->at(i)->GetComment() << std::endl;
                        IBreakParam bparam = IBreakParam();
                        bparam.m_addr = 0xff; // Hit to ceate label
                        bparam.m_block_label = pBlk->GetLabel();
                        p->pBreakParam.push_back(bparam);
                        pBlk->SetBreakSetupInsFlag(false);
                    } else {
                        pBlk->SetBreakSetupInsFlag(false);
                    }
				}
				p->result.set(IBlockSimParam::BSR_JUMPING);
				p->result.set(IBlockSimParam::BSR_SUCCESS); 
				return true;	/* Jumped to other blocks */
			}
		}

        //!< BreakSetupInsert
		if(break_point_weight && (!pIns->GetValid())) {	// WeightがzeroならBreak対象としない
			if((! pBlk->GetBreakSetupInsFlag()) && pBlk->IsRegulation() && pBlk->GetHandlerAddress() == 0
				&& (pBlk->GetLabel().find("callt") == std::string::npos && pBlk->GetLabel().find("syscall") == std::string::npos 
				&& pBlk->GetLabel().find("th_end_sync") == std::string::npos )) {	// Exclude CALLT and SYSCALL block
                // ブレーク例外設定用DBTRAPをランダムコードブロックの先頭に挿入する
                pNewIns = new CIns_218_dbtrap();
                pNewIns->SetValid(true);
                pNewIns->AppendComment("for Break Setup");
				UI32 pos = ((pBlk->GetLabel().find("_00") == std::string::npos) ? 0 : 1);
                pBlk->AddOpeCode(pNewIns, pos); //! 0 for DBTAG 
                pBlk->SetBreakSetupInsFlag();

				UI32 tmpR = 10;
				pNewIns = MOV32(g_wm.BREAK_INFO_PRESET, tmpR);
				pNewIns->SetValid(true);
				pNewIns->AppendComment("for Break Setup");
				pBlk->AddOpeCode(pNewIns, pos); //! 0 for DBTAG

				pNewIns = STW16(tmpR,0,tmpR);
				pNewIns->AppendComment("for Break Setup");
				pBlk->AddOpeCode(pNewIns, pos + 1); //! 0 for DBTAG
#if DBGMODE
                fprintf(stdout,"==> Insert DBTRAP into CodeBlock Top.\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
		}

		//!< Regulation (skip regulation of instruction in which fixed code, that has no constraint, and done.) 
        UI32 psw = GetPSW();

		//!< Checking special custom Ins needed to adjust.
		if (pBlk->IsRegulation() && (pBlk->GetHandlerAddress()==0)){
			if (RegulateSpecialCustomIns(pBlk, pIns)) {
				p->result.set(IBlockSimParam::BSR_REASM);
				return true;
			}
		}
 
		if(pBlk->GetLabel().find("_prologue") != std::string::npos ) {
			if(pIns->GetComment().find("Preset_Register_Bank_Area_000") != std::string::npos && (pIns->GetValid() != true)) {
				UI32 RBIP = 0;
				if ( m_pSim->ReadSysRegister(&RBIP, "RBIP", 0) != true ) {
					std::runtime_error excep("Simulator error : Read GR");
					throw excep;
				}
				const UI32 BankNum = 255;
				const UI32 PSIZE = 4;
				const UI32 SaveMode1 = 144;
				UI32 endAddress = RBIP - SaveMode1 * BankNum;
				for ( UI32 startAddress = RBIP; startAddress > endAddress; startAddress -= PSIZE ) {
					UI32 Value = g_rnd.GetRange((UI32)0,(UI32)(~0)) & 0xfffffff0 ;
					m_pSim->PresetMemory(true ,0 ,startAddress, PSIZE, (Value & 0xffffffff));
				}
			}
		}

		if (pBlk->IsRegulation()){
			IInstruction *pTmp = pIns->GetRegulationTarget();
			if(pTmp != NULL && pTmp->InSequence(IInstruction::IF_SEQ_FWD) == false // MPU_Function was not generated as fowarding
				&& pTmp->GetId() == INS_ID_JARL && pIns->opr(0)->GetLabel() != nullptr) {
				std::string label(pIns->opr(0)->GetLabel());
				// Delete instruction that jump into code block that updates MPU config in UM mode
				if(label.find("mpu_function_") != std::string::npos && (psw & 0x40000000) != 0) {// UM mode
					IInstruction *pTargetIns = pIns->GetRegulationTarget();
					pTmp = pBlk->at(pBlk->GetIndex(pTargetIns) + 1);
					if(pTmp->GetLabel().size() == 0) {
						pIns->DirMoveTo(pTmp);
						pBlk->Remove(pIns); // Remove jarl's adjustment instruction.
						pBlk->Remove(pTargetIns); // Remove JARL instruction
					} else {
						pBlk->Remove(pTargetIns); // Remove JARL instruction
						pIns->SetRegulationTarget(NULL);
						pIns->opr(0)->SetLabel("");
						pIns->opr(0)->Replace(g_rnd.Get());
					}
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
			}

			if(pIns->GetValid() != true) {			
				if (RegulateFPIException(pBlk, pIns)){
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				if (RegulateBranchCondition(pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				if (RegulateValueConstraint(pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				if(RegulateBeforeException(pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

            } else {

                if (pIns->GetId() == INS_ID_JARL /*CIns_82_jarl*/) {
                    std::string sJmpTarget = pIns->GetJumpTarget();
                    if (sJmpTarget.find("mpu_function_") != std::string::npos) {
                        CCodeBlock*	pcb = nullptr;
                        std::vector<INode*> FunctionList = g_asf->GetFunctionBlock();
                        std::vector<INode*>::iterator func_itr = FunctionList.begin();

                        for (; func_itr != FunctionList.end(); func_itr++) {
                            pcb = static_cast<CCodeBlock*>(*func_itr);
                            if (pcb->GetLabel() == sJmpTarget) break;
                        }
                        if (RegulateMPUupdate(pcb, (pIns->opr(1)->Idx())) == false) {
                            PrepareDeletedIns(pBlk, pIns);
                            pBlk->Remove(pIns);
                            p->result.set(IBlockSimParam::BSR_REASM);
                            return true; /* Re-Compile & Re-Sim */
                        }
                    }
                }
            }
			if(OverwriteFPIMismatch(pBlk, pIns)){
				p->result.set(IBlockSimParam::BSR_REASM);
				return true; /* Re-Compile & Re-Sim */
			}
		} else { // if(!pBlk->IsRegulation()){ // Generate preset memory for code block other than random code block.
			// Memory Init before first access! --> to create __preload codeblock.
			if ( pIns->Behavior(IInstruction::STORE_MEMORY) ) 
			{
				IOperand		*pOpr;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;

				for(UI32 nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++)
				{
					pOpr = pIns->opr(nOpr);
					pOpr->AlignData(m_pSim, PFETCHSIZE);
					
				}
			}

            // regulate adjustment code of LDSR (update MPM) in MPU update
            if (pBlk->GetLabel().find("mpu_function_") != std::string::npos && pIns->GetRegulationTarget() != nullptr) {
                UI32 new_mpm = (UI32)*(pIns->opr(0)) & 0x7;
                UI32 old_mpm = m_pSim->GetMPM();
                UI32 PC = 0;
                m_pSim->ReadPC(&PC);
                m_pSim->SetMPM(new_mpm);
                // Check MIP at SYNCI
                if (IsMIPexception(PC + 6, 0x2) != NO_ERROR) {
                    new_mpm = new_mpm & (~0x5);
                    pIns->opr(0)->Replace(new_mpm);
                }
                m_pSim->SetMPM(old_mpm);
            }
		}

        //!< BreakSet
		if(break_point_weight && pBlk->GetBreakSetupInsFlag() && !pBlk->GetBreakSetupDone() && pBlk->GetHandlerAddress() == 0) {	// WeightがzeroならBreak対象としない
            // ブレーク発生対象命令の条件は、ランダムコードブロック内でDBTRAP命令でも、プリフェッチ？（DBTRAPの次の命令）でもないこと
			if((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize())) && (pBlk->IsRegulation()) && (! p->bDebugExcep) && (pIns->GetId() != INS_ID_DBT)) {
                // かつ、補正命令ではなく、ブレーク発生対象命令でもなく、デバッグ例外発生命令でもないこと
                if(( pIns->GetRegulationTarget() == nullptr ) && ( ! pIns->m_bBreakTargetIns ) && ( ! pIns->m_bBreakInsertIns )) {
                    if( pIns->m_bBreakCheckDone ) {
                        break_type = IBreakParam::BREAK_NONE;
                    } else {
                        // ブレーク発生要否とブレーク種別の決定
                        break_type = GenerateBreakPointBeforeSetup(p,pIns,pBlk);
                        if(( break_type == IBreakParam::BREAK_SS ) && ( pIns->m_bBreakNotSS )){
                            break_type = IBreakParam::BREAK_NONE; // Chain_CTRET/EIRET/FERETマクロによるジャンプでは、マクロ中にDBTRAP命令を挿入すると復帰先がずれるのでSSを抑止する
                            p->pNotBreakParam.pop_back();
                        }
                        pIns->m_bBreakCheckDone = true; // 該当命令は、ブレーク発生要否とブレーク種別の決定を行った
                        // ブレーク種別がNONEではなく、未使用チャネルが存在する時、
                        if( break_type != IBreakParam::BREAK_NONE ) {
                            /* ブレークパラメータ発生タイミングとして、ブレーク例外発生対象命令にフラグを設定 */
                            pIns->m_bBreakTargetIns = true;
#if DBGMODE
                            fprintf(stdout,"==> At Created BreakPointSetup, Target Instruction ID:%d Index:%d Code:%s\n", pIns->GetId(),pBlk->GetIndex(pIns),pIns->GetCode().c_str());
#endif                        
                            //!< BreakInsertIns
                            // ブレーク種別がSSの時、デバッグ例外発生命令としてDBTRAP命令を挿入する
                            if( break_type == IBreakParam::BREAK_SS ) {
                                pNewIns = DBTRAP();
                                pNewIns->SetLabel(p->pNotBreakParam.back().m_addr_label);
                                pNewIns->AppendComment(" for Break_SS ");
                                pIns->DirMoveTo(pNewIns);
                                pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                                pNewIns->m_bBreakInsertIns = true;
                                pNewIns->m_bBreakCheckDone = true;
#if DBGMODE
                                fprintf(stdout,"==> Insert dbtrap instruction for Break_SS label:%s\n",pNewIns->GetLabel().c_str());
#endif
                                // DBTRAP will be in-loop if SS is generated at loop instruction.
                                if( pIns->GetId() == INS_ID_LOOP ) {
                                    pIns->SetInLoop();
                                }
                                p->result.set(IBlockSimParam::BSR_REASM);
                                return true; /* Re-Compile & Re-Sim */
                            }
                        }
                    }
                }
            }
            if( break_type == IBreakParam::BREAK_LDB ) {
                pIns->SetLabel(p->pBreakParam.back().m_addr_label);
                fprintf(stdout,"==> SetLabel %s: %s\n",pIns->GetLabel().c_str(),pIns->GetCode().c_str());
                if( pIns->GetId() == INS_ID_SWITCH ) { // SWITCH命令の場合は
                    {
                        UI32 val;
                        m_pSim->ReadGrReg(&val, pIns->opr(0)->Idx(), 0); //TODO:Multi thread not support
                        p->pBreakParam.back().m_addr = ( val << 1 ) + 2; // +2 SWITCH命令のコードサイズ２バイト分を加算したアドレスがメモリアクセス位置
                        fprintf(stdout,"==> SetAddress %#08x\n",val);
                    }
                } else {
                    p->pBreakParam.back().m_addr_label = "";
                }
            }
            // ブレーク種別がAEの時、デバッグ例外発生命令としてAE用のSPミスアライン化命令を挿入する
            if( break_type == IBreakParam::BREAK_AE ) {
                pNewIns = ORI(0x1,3,3);
                pNewIns->AppendComment(" for Break_AE ");
                pIns->DirMoveTo(pNewIns);
                pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                pNewIns->m_bBreakInsertIns = true;
#if DBGMODE
                fprintf(stdout,"==> Insert ori instruction for Break_AE\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
        }

		break_type = IBreakParam::BREAK_NONE;

		//Remove gap code if there are an increase in the size of code 
		if (pBlk->GetCodeSize() != pBlk->m_orgsize && pBlk->IsRegulation()) {
			if (pBlk->RecoverCodesize(pIns)) {
				p->result.set(IBlockSimParam::BSR_REASM);
				return true; /* Re-Compile & Re-Sim */
			} else if (pBlk->GetCodeSize() > pBlk->m_orgsize && pBlk->IsRegulation()) {
				MSG_ERROR(0, "Not enought Gap Code at : \"%s\"\n", pIns->GetCode().c_str());
				p->result.set(IBlockSimParam::BSR_FATALERROR); 
				return false; /* Sim Stop */
			}
		}

		//!< Regulation done!
		if (!pIns->GetValid()) {
			pIns->SetValid(true);
			continue;
		}

		// The interrupt is asserted/de-asserted before rollback.
		auto IsRequested = [=] (IInstruction *pIns) -> bool {
			std::vector<IInstruction*>::iterator itr;
			itr = std::find_if(m_vRequestedIns.begin(), m_vRequestedIns.end(), [=](IInstruction *p) {return (p == pIns);});
			if(itr == m_vRequestedIns.end())
				return false;
			return true;
		};
		if(m_bRollback && pIns == m_pRollbackIns) {
			if(m_vRequestedIns.back() == m_pRollbackIns) {
				m_vRequestedIns.pop_back();
				m_vRequestedIns.push_back(pIns);
			}
			m_pRollbackIns = NULL;
		}
		if(!IsRequested(pIns) ) {
			// Update status of pending interrupt, just in random code block
			if(pBlk->GetHandlerAddress() == 0) {
				for(auto itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
					CIntInfo* p = *itr;
					if(p->nPeriod > 0)
						p->nPeriod--;
					if(p->nClear == CIntInfo::ASYNC_CLEAR_REJECT)
						p->nClear = CIntInfo::ASYNC_CLEAR_NONE;
				}
			}
			CheckInterruptRequest(pBlk, pIns);
			m_vRequestedIns.push_back(pIns);
		} else {
			if(pBlk->GetLabel().find("fix_syserr_handler") != std::string::npos)		// [FROG]TODO: Update to the final solution
				CheckInterruptRequest(pBlk, pIns);
		}

#if DBGMODE
        {
            UI32       nOpr;
            IOperand*  pOpr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintRetVal(m_pSim, ss);
            }
        }
#endif
		
		//!< Send operation code.
		ISimulatorStepResp res;
		if (Step(0, p->lpc, p->ppc, pIns, &res) == false) {
			UI32 code;
			m_pSim->GetErrorInfo(&code);
			if (code == ERR_THREAD_IS_HALT) {
				// Exit successfully
				// TODO: TO BE FIXED ( On multi thread )
				p->result.set(IBlockSimParam::BSR_EXIT_SUCCESS);
				return true;/* Sim Complete */
			}
			MSG_ERROR(0, "Simulation failed (%08X) : \"%s\"\n", code, pIns->GetCode().c_str());
			p->result.set(IBlockSimParam::BSR_FATALERROR); 
			return false; /* Sim Stop */
		}
#if DBGMODE
        {
            UI32       nOpr;
            IOperand*  pOpr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintGetVal(m_pSim, ss);
            }
        }
#endif

		//!< Exception Handling --> No operation for any exceptions without counting for report.
		if (res.exception) {
			IExceptionConfig* pExp = IdentifyException(p->pException, (res.exception & 0x0ffff));
			if (pExp != NULL) {
				if(!RegulateException(pBlk, pIns, pExp)) {
					MSG_ERROR(0, "SIM ERROR: Roll back exception name %s", pExp->m_name.c_str());
					m_bRollback = true;
					p->result.set(IBlockSimParam::BSR_ROLLBACK);
					return true; /* Re-Compile & Re-Sim */
				} else {
					UI32 cause_code = (res.exception & 0x0ffff);
					StoreExceptionInfo(cause_code, pIns, pBlk);

					// Check whether EIINT was  caused by reference table menthod
					std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
					bool bIsEITBL = false;
					while(itr < m_vRequestedIntStack.end()) {
						if((*itr)->sName == "eitbl" || (*itr)->sName == "gmeitbl") {
							bIsEITBL = true;
							break;
						}
						itr++;
					}
					// Set interrupt/exception information
					SetException(pIns, pExp, pBlk);

					//!< BreakSet
					if(break_point_weight && pBlk->GetBreakSetupInsFlag() && !pBlk->GetBreakSetupDone() && pBlk->GetHandlerAddress() == 0) {	// WeightがzeroならBreak対象としない
						// ブレーク発生対象命令の条件は、ランダムコードブロック内でDBTRAP命令でも、プリフェッチ？（DBTRAPの次の命令）でもないこと
						if((pBlk->IsRegulation()) && (! p->bDebugExcep)) {
							UI32 cause_code = (res.exception & 0x0ffff);
							if((pExp->m_id == IException::EXP_EIINT && bIsEITBL) || (pExp->m_id == IException::EXP_GMEIINT && bIsEITBL) || cause_code == 0x95 /*MDP*/ || cause_code == 0x1c /*SYSERR*/ ) {
								// Generate a breakpoint and corresponding parameter
								break_type = GenerateBreakPointBeforeSetup(p, pIns, pBlk);
								if(break_type == IBreakParam::BREAK_LSAB) {
									pIns->m_bBreakTargetIns = true;
									pIns->m_bBreakCheckDone = true;
								} else if (break_type != IBreakParam::BREAK_NONE){
									if(break_type == IBreakParam::BREAK_AE || break_type == IBreakParam::BREAK_SS)
										p->pNotBreakParam.pop_back();
									else
										p->pBreakParam.pop_back();

									// Remove breakpoint label that has set.
									if(break_type == IBreakParam::BREAK_PCB || break_type == IBreakParam::BREAK_AE) {
										UI32 nDirNum = pIns->GetDirectiveNum();
										IDirective *pDir = pIns->GetDirective(nDirNum - 1);
										pIns->RemoveDirective(pDir);
									}
									break_type = IBreakParam::BREAK_NONE;
								}
							}
						}
					}
				}
				p->pException->CountUp(pExp->m_id);
			}
		} else { // TODO: Delete the couple if excetion occur at some instructions that make the instruction be not executed
			// The random code that using for Overwrite precision error (not LDL)
			if (pIns->GetCoupleIns() != nullptr && pIns->GetMne().find("ldl") == std::string::npos) {
				IInstruction* pOverW = pIns->GetCoupleIns();
				if (pOverW->GetComment().find("Overwrite precision error")) {
					pIns->SetCoupleIns(nullptr);
					pBlk->Remove(pOverW);
					pBlk->Update();
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
			}

			m_nPreciMismatchReg &= ~(UI64)((UI64)(pIns->GetWrDst()) << 32);
			m_nPreciMismatchReg &= ~(UI64)(pIns->GetGrDst());
			m_nPreciMismatchReg |= pIns->GetOprIdxMistmatch();
		}
		m_bRollback = false;

		if(pBlk->IsRegulation())
			UpdateFPIStatus(pIns);
		
        //!< GetBreakInfo
        // デバッグ例外発生対象命令ならば、ブレークパラメータを設定する 
        if( pIns->m_bBreakTargetIns ) {
            GenerateBreakPointSetup(p,pIns,pBlk);
			pIns->m_bBreakTargetIns = false;
		}
// -- Debug print
#if LOGSW_INS_SIM
		{
			UI32 psw; m_pSim->ReadNcReg(&psw, 5, 0);
			std::cout << '[';
			std::cout << ((psw & 0x80000000) ? 'V':'N'); 
			if ((psw & 0x80000000) == 0) {
				std::cout << ((psw & 0x40000000) ? 'U':'S'); 
				std::cout << ((psw & 0x00010000) ? '0':'-'); 
				std::cout << ((psw & 0x00020000) ? '1':'-'); 
				std::cout << ((psw & 0x00040000) ? '2':'-');
				std::cout << ':';
				std::cout << ((psw & 0x00000010) ? 'A':'-');
				std::cout << ((psw & 0x00000008) ? 'C':'-');
				std::cout << ((psw & 0x00000004) ? 'V':'-');
				std::cout << ((psw & 0x00000002) ? 'S':'-');
				std::cout << ((psw & 0x00000001) ? 'Z':'-');
			}else{
				UI32 vsw; m_pSim->ReadTcReg(&vsw, 5, 0, 0);
				std::cout << ((vsw & 0x40000000) ? 'U':'S'); 
				std::cout << ((vsw & 0x00010000) ? '0':'-'); 
				std::cout << ((vsw & 0x00020000) ? '1':'-'); 
				std::cout << ((vsw & 0x00040000) ? '2':'-');
				std::cout << ':';
				std::cout << ((vsw & 0x00000010) ? 'A':'-');
				std::cout << ((vsw & 0x00000008) ? 'C':'-');
				std::cout << ((vsw & 0x00000004) ? 'V':'-');
				std::cout << ((vsw & 0x00000002) ? 'S':'-');
				std::cout << ((vsw & 0x00000001) ? 'Z':'-');
			} 
			std::cout << "]: ";
			
			UI32 tabstop = pBlk->IsRegulation() ? 8 : 12;
			std::cout << std::hex << std::setw(tabstop) << std::setfill(' ') << p->lpc << "(L):" << std::setw(tabstop) << std::setfill(' ') << p->ppc<<"(P)";
			std::cout << (((pIns->GetComment().find("Regulation")) == std::string::npos) ? " : " : " ! ");
			std::cout << pIns->GetCode();
			if (res.exception) {
				std::cout << " -> " << p->pException->GetName(res.exception & 0x0ffff);
			}
			if (0) {
				std::bitset<32> r = pIns->GetGrSrc();
				std::bitset<32> w = pIns->GetGrDst();
				std::cout << "\tR:" << r << " W:" << w;
			}
            std::cout << " # " << ss.str() << std::endl;
            ss.str(""); ss.clear(std::stringstream::goodbit);
		}
#endif
		// -- Debug print

        // Debug Exception Flag set/reset
        switch( pIns->GetId() ) {
        case INS_ID_DBT: // DBTRAP
        case INS_ID_RMT: // RMTRAP
            p->bDebugExcep = true;
            break;
        case INS_ID_DBRET: // DBRET
            p->bDebugExcep = false;
            break;
        }

		// PC Update
		p->bPrevChain = pIns->GetChain(); // コードブロック終端判定用
		if (DecodeAddress(res.pc, &p->lpc, &p->ppc) != true) {
			MSG_ERROR(0, "Fail to transfer PC(LA:%08X)\n", p->lpc);
			return false; /* Sim Stop */
		}
	}
	
	p->result.set(IBlockSimParam::BSR_FATALERROR);
	return false; /* Sim abended */
}

/**
 *	@brief
 * 
 *	リソースデータを抽出する。
 * 
 */
CSimResource* CSimulatorControl::GetResource () {

	// Prepare
	CSimResource* res = new CSimResource();

	ISimulatorHwInfo si;
	if (m_pSim->GetSimulatorInfo(si) != true) {
		delete res;
		return nullptr;
	}
	const UI32 V = si.m_vmnum;
	const UI32 T = si.m_htnum;

	// Get GR
	for (UI32 t = 0; t < T; t++) {
		GRSET gset;
		for (UI32 r = 0; r < 32; r++) {
			UI32 val;
			m_pSim->ReadGrReg(&val, r, t);
			gset.push_back(val);
		}
		res->m_gr.push_back(gset);
	}

	// Get VR
	if (0) {
		for (UI32 t = 0; t < T; t++) {
			VRSET vset;
			for (UI32 r = 0; r < 32; r++) {
				UI64 val;
				m_pSim->ReadVeReg(&val, r, t);
				vset.push_back(val);
			}
			res->m_vr.push_back(vset);
		}
	}

	// Get SR
	std::vector <BKREG> sr;
	std::vector <BKREG>::iterator i;
	g_srs->MatchContext (0/* CSysReg::SR_CONTEXT_NC */, &sr);
	// Verify対象のNCSRを取得したので、SIMから期待値を取得
	for (i = sr.begin(); i != sr.end(); ++i) {
		UI32 val;
		m_pSim->ReadNcReg(&val, (*i) & 0x1f,  (*i)>>5);
		res->m_nc.push_back( SRVAL(*i, val) );
	}
	//std::cout << res->m_nc.size();
		
	sr.clear();
	g_srs->MatchContext (1/* CSysReg::SR_CONTEXT_VC */, &sr);
	for (UI32 v = 0; v < V; v++) {
		SRSET vs;
		for (i = sr.begin(); i != sr.end(); ++i) {
			UI32 val;
			m_pSim->ReadVcReg(&val, (*i)&0x1f,  (*i)>>5, v);
			vs.push_back( SRVAL(*i, val) );
		}
		res->m_vc.push_back(vs);
	}

	sr.clear();
	if (V > 0) {
		g_srs->MatchContext (2/* CSysReg::SR_CONTEXT_TC*/, &sr);
		for (UI32 t = 0; t < T; t++) {
			SRSET ts;
			for (i = sr.begin(); i != sr.end(); ++i) {
				UI32 val;
				m_pSim->ReadTcReg(&val, (*i)&0x1f,  (*i)>>5, t);
				ts.push_back( SRVAL(*i, val) );	
			}
			res->m_tc.push_back(ts);
		}
	}	

	m_pSim->GetMemoryWritenData(&res->m_logs);

	if (1) {
		std::ofstream ofs;
		ofs.open("expected.res");
		ofs << (*res);
		ofs << std::endl;
		ofs.close();
	}	
	
	return res;
}
/**
 *	@brief
 * 
 *	This function regulate special custom instruction。
 * 
 */
bool CSimulatorControl::RegulateSpecialCustomIns(CCodeBlock* pCB, IInstruction* pIns) {

	_ASSERT(pCB);
	_ASSERT(pIns);

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	LDL_STC_CusIns_Sim* lspsim = &m_stLDL_STC_Sim;
	
	//------------------------------------------------------------
	// lambda : LDL_STCInitValue
	//------------------------------------------------------------
	//        Init value for starting sequence insert stc instruction. 
	//------------------------------------------------------------
	auto LDL_STCInitValue = [&] (IInstruction* pIns, UI32 LLBit, UI32 Address, LDL_STC_CusIns_Sim* lspsim) {
		LLBit--;
		//!< Checking init value at the first time when staring sequence. 
		if ((lspsim->LLBitSTC[LLBit].InSTCSequence == false) && (lspsim->m_loopCounter == 0)) {	
			//!< Init value for LDL_STC sequence.
			lspsim->LLBitSTC[LLBit].StartSTCSequence = true;
			lspsim->LLBitSTC[LLBit].STCTargetPosition = lspsim->m_nSTCTargetCounter + g_rnd.GetRange(0,0x10);
			lspsim->LLBitSTC[LLBit].STCAddress = Address;
			lspsim->LLBitSTC[LLBit].IsSTCSuccess =  pIns->GetCoupleIns()->IsSTCSuccess();
			lspsim->LLBitSTC[LLBit].IsLDLInLoop = lspsim->m_bIsStatusInsLoop;
				
			char buff[32];
			sprintf(buff, "%#x", lspsim->LLBitSTC[LLBit].STCTargetPosition);
			lspsim->LLBitSTC[LLBit].pInsSTC = pIns->GetCoupleIns();
			lspsim->LLBitSTC[LLBit].pInsSTC->AppendComment(buff);
			lspsim->LLBitSTC[LLBit].STCSourReg = (UI32)lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Idx();
			lspsim->LLBitSTC[LLBit].STCDestReg = (UI32)lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Idx();
			lspsim->LLBitSTC[LLBit].pInsLDL = pIns;
			pIns->AppendComment(buff);
		}
	};

	/***
	* Staring Function.
	***/
	//!< Update LLBit vector from Undo buffer.
	m_pSim->GetLLBitData(&(lspsim->m_vLLBitData));
	while ( lspsim->m_vLLBitData.size()) {
		lspsim->m_stLLBitData = lspsim->m_vLLBitData.back();
		lspsim->m_vLLBitData.pop_back();
		
		//!< Update LLBit status.
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (lspsim->m_stLLBitData.m_address);
		if (LLBitNum != 0 ) {
			LLBitNum--;
			if (lspsim->LLBitSTC[LLBitNum].STCAddress == lspsim->m_stLLBitData.m_address) {
				lspsim->LLBitSTC[LLBitNum].LLBit = true;
				//Update sequence status when LLBit is set.
				if (lspsim->LLBitSTC[LLBitNum].StartSTCSequence == true) {
					lspsim->LLBitSTC[LLBitNum].InSTCSequence = true;
				}
			} else {
				lspsim->LLBitSTC[LLBitNum].LLBit = false;
			}
		}
	}

	//!< Update loop status and position of instruction.
	lspsim->UpdateLDL_STC_Status (pCB, pIns,m_pSim);

	//!< Sequence Checking to Update ldl status then generating stc instruction.
	const UI32 LLBitMax = 2;
	for (UI32 i = 0; i < LLBitMax; i++) {
		if (lspsim->LLBitSTC[i].InSTCSequence ) {
			//!< Check condition and insert stc Ins.
			if (RegulateSpecialCustomInsSTCInsert( pCB, pIns,i,lspsim)) {
				return true;
			}
		}
	}
	//!< Find ldl custom instruction to starting sequence.
	if (pIns->IsLDL_STC_CusIns() && pIns->GetValid()) {
		UI32 nAddress = 0;
		if (m_pSim->ReadGrReg(&nAddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}	
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (nAddress);
		if (LLBitNum != 0) {
			// Init value of sequence at starting time.
			LDL_STCInitValue(pIns,LLBitNum,nAddress,lspsim);
		}
	}

	return false;
}
/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::RegulateSpecialCustomInsSTCInsert (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
	//------------------------------------------------------------
	// lambda : GetJmpPC
	//------------------------------------------------------------
	//        Find register that contain PC value
	//------------------------------------------------------------	
	auto GetJmpPC = [&](CCodeBlock* pCB, IInstruction* pIns){
        UI32 BannedReg = 0;
        if (pIns->Behavior(IInstruction::JMP)) {
            UI32 idx = pCB->GetIndex(pIns);
            if (idx != 0 && pCB->at(idx - 1)->GetMne() == "mov") {
                BannedReg = pCB->at(idx - 1)->opr(1)->Idx();
            }    
        }
        return BannedReg;
	};
	UI32 regPC = GetJmpPC(pCB,pIns);
	//------------------------------------------------------------
	// lambda : InsertSTCSuccess
	//------------------------------------------------------------
	//        Find condition and insert stc for successfull case. 
	//------------------------------------------------------------
	auto InsertSTCSuccess = [&] ( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
		bool InSpecCusIns = false; 
		bool IsWordIns = (pIns->GetMne() == ".word" || pIns->GetMne() == ".hword");		//Do not insert to .word or .hword instruction 
		if (pIns->GetRegulationTarget() ==  NULL) {
			InSpecCusIns = pIns->InSequence(IInstruction::IF_SEQ_FWD) | pIns->InSequence(IInstruction::IF_SEQ_C2B1);
		} else {
			InSpecCusIns = pIns->GetRegulationTarget()->InSequence(IInstruction::IF_SEQ_FWD) | pIns->GetRegulationTarget()->InSequence(IInstruction::IF_SEQ_C2B1);
		}
		//!< Checking exceed max step or found clear LLBit condition. 
		if ((lspsim->m_nSTCTargetCounter > lspsim->LLBitSTC[LLBit].STCTargetPosition) || (PredictLLBitInNextIns(pCB,pIns,LLBit,lspsim))) {
			//!< Check satisfy loop condition.
			if (InSpecCusIns || IsWordIns) {
				lspsim->LLBitSTC[LLBit].STCTargetPosition++;
			}
			if ((!lspsim->LLBitSTC[LLBit].IsSTCInLoop) && (lspsim->m_loopCounter == 0) && (!InSpecCusIns) && (!IsWordIns)) {
			
				if (lspsim->LLBitSTC[LLBit].LLBit) {
					
					//!< Adjust source and destination register of stc instruction to avoid loop counter.
					if (lspsim->m_bIsStatusInsLoop) {
						UI32 idx = pCB->GetIndex(pIns);
						IInstruction *pLoopIns = NULL;
						while(idx < pCB->GetInstructionNum()) {
							pLoopIns = pCB->at(idx);
							if(pLoopIns->GetMne() == "loop")
								break;
							idx++;
						}

						//Find the register that is used as source or dest of ld/st instructions
						UI32 BannedReg = 0;
						SI32 id = pCB->GetIndex(pIns);
						if (pIns->GetLabel().find("_Lp") == std::string::npos) {
							while(id >= 0) {
								IInstruction* pTmp = pCB->at(id);

                                UI32 src = pTmp->GetGrSrc();
                                BannedReg |= src;

								if (pTmp->GetLabel().find("_Lp") != std::string::npos)
									break;
								id--;
							}
						}

						BannedReg |= (UI32)(m_nPreciMismatchReg & 0xffffffff);

						//!< Replace source dest register of stc to void loop counter and avoid register contain PC value.
						UI32 loopCounter = pLoopIns->opr(0)->Idx();
						UI32 RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
						//Try from register 4-29
						UI32 maxTry = 26;
						while ((lspsim->LLBitSTC[LLBit].STCSourReg == loopCounter) || (lspsim->LLBitSTC[LLBit].STCDestReg == loopCounter) ||
                               (lspsim->LLBitSTC[LLBit].STCSourReg == regPC || lspsim->LLBitSTC[LLBit].STCDestReg == regPC) ||  RegConflict != 0) {
							lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
							lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
							// Checking if register is used before by ld/st
							RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
							if (maxTry == 0) {
								lspsim->LLBitSTC[LLBit].Reset();
								return false;
							} else {
								maxTry --;
							}
						}
					} else {
						while (lspsim->LLBitSTC[LLBit].STCDestReg == regPC || lspsim->LLBitSTC[LLBit].STCSourReg == regPC) {
							lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
							lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
						}
					}

					// Adjust address.
					IInstruction* pNewIns = MOV32(lspsim->LLBitSTC[LLBit].STCAddress,lspsim->LLBitSTC[LLBit].STCDestReg);
					pIns->DirMoveTo(pNewIns);
					pNewIns->SetRegulationTarget(lspsim->LLBitSTC[LLBit].pInsSTC);
					pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
					//Re-regulate when insert successflly
					pIns->SetValid(false);
					
					lspsim->LLBitSTC[LLBit].pInsSTC->SetInLoop(lspsim->m_bIsStatusInsLoop);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Replace(lspsim->LLBitSTC[LLBit].STCSourReg);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Replace(lspsim->LLBitSTC[LLBit].STCDestReg);
					pCB->AddOpeCode(lspsim->LLBitSTC[LLBit].pInsSTC, pCB->GetIndex(pIns));
				
					// Reset sequence.
					lspsim->LLBitSTC[LLBit].Reset();
					return true;
				} else  {
					
					lspsim->LLBitSTC[LLBit].Reset();
				}
			}
		}

		return false;
	};

	auto IsFirstRegulationIns = [](CCodeBlock* pCB, IInstruction* pIns){
		IInstruction *pPrev;
		UI32 nInsPos;

		// The first instruction of CB
		nInsPos = pCB->GetIndex(pIns);
		if(nInsPos == 0)
			return true;

		// Not the first regulation instruction
		pPrev = pCB->at(nInsPos - 1);
		if(pPrev->GetRegulationTarget() != NULL)
			return false;

		return true;
	};

	//------------------------------------------------------------
	// lambda : InsertSTCFail
	//------------------------------------------------------------
	//        Find condition and insert stc for false case. 
	//------------------------------------------------------------
	auto InsertSTCFail = [&] ( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
		bool InSpecCusIns = false;
		bool IsWordIns = (pIns->GetMne() == ".word" || pIns->GetMne() == ".hword");		//Do not insert to .word or .hword instruction 
		if (pIns->GetRegulationTarget() ==  NULL) {
			InSpecCusIns = pIns->InSequence(IInstruction::IF_SEQ_FWD) | pIns->InSequence(IInstruction::IF_SEQ_C2B1);
		} else {
			InSpecCusIns = pIns->GetRegulationTarget()->InSequence(IInstruction::IF_SEQ_FWD) | pIns->GetRegulationTarget()->InSequence(IInstruction::IF_SEQ_C2B1);
		}
		
		//!< Checking exceed max step. 
		if ((lspsim->m_nSTCTargetCounter > lspsim->LLBitSTC[LLBit].STCTargetPosition) || (!lspsim->LLBitSTC[LLBit].LLBit)) {
			//!< Check satisfy loop condition.
			if (InSpecCusIns || IsWordIns) {
				lspsim->LLBitSTC[LLBit].STCTargetPosition++;
			}
			if ((!lspsim->LLBitSTC[LLBit].IsSTCInLoop) && (lspsim->m_loopCounter == 0) && (!InSpecCusIns) && (!IsWordIns)) {
				if (!lspsim->LLBitSTC[LLBit].LLBit) {

					//Interrup exception occur in force instruction.
					if ((pIns == lspsim->LLBitSTC[LLBit].pInsForce) || (lspsim->m_pInsExp == pIns) || (pIns->GetRegulationTarget() != NULL && !IsFirstRegulationIns(pCB, pIns))) {
						return false;
					}

					//!< Adjust source and destination register of stc instruction to avoid loop counter.
					if (lspsim->m_bIsStatusInsLoop) {
						UI32 idx = pCB->GetIndex(pIns);
						IInstruction *pLoopIns = NULL;
						while(idx < pCB->GetInstructionNum()) {
							pLoopIns = pCB->at(idx);
							if(pLoopIns->GetMne() == "loop")
								break;
							idx++;
						}
						
						//Find the register that is used as source or dest of ld/st instructions
						UI32 BannedReg = 0;
						SI32 id = pCB->GetIndex(pIns);
						if (pIns->GetLabel().find("_Lp") == std::string::npos) {
							while(id >= 0) {
								IInstruction* pTmp = pCB->at(id);

                                UI32 src = pTmp->GetGrSrc();
                                BannedReg |= src;

								if (pTmp->GetLabel().find("_Lp") != std::string::npos)
									break;
								id--;
							}
						}
						BannedReg |= (UI32)(m_nPreciMismatchReg & 0xffffffff);

						//!< Replace source dest register of stc to avoid loop counter and source/dest of some ld/st ins in loop.
						UI32 loopCounter = pLoopIns->opr(0)->Idx();
						UI32 RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
						//From 4 to 29 registers try
						UI32 maxTry = 26;
						while ((lspsim->LLBitSTC[LLBit].STCSourReg == loopCounter) || (lspsim->LLBitSTC[LLBit].STCDestReg == loopCounter) ||
                            (lspsim->LLBitSTC[LLBit].STCSourReg == regPC) || (lspsim->LLBitSTC[LLBit].STCDestReg == regPC) || RegConflict != 0) {
							lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
							lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
							// Checking if register is used before by ld/st
							RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
							if (maxTry == 0) {
								lspsim->LLBitSTC[LLBit].Reset();
								return false;
							} else {
								maxTry --;
							}
						}
					}else {
						while (lspsim->LLBitSTC[LLBit].STCSourReg == regPC || lspsim->LLBitSTC[LLBit].STCDestReg == regPC) {
								lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
								lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
						}
					}

					// Adjust address.
					IInstruction* pNewIns = MOV32(lspsim->LLBitSTC[LLBit].STCAddress, lspsim->LLBitSTC[LLBit].STCDestReg);
					pIns->DirMoveTo(pNewIns);
					pNewIns->SetRegulationTarget(lspsim->LLBitSTC[LLBit].pInsSTC);
					pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
					//Re-regulate when insert successflly
					pIns->SetValid(false);
					
					lspsim->LLBitSTC[LLBit].pInsSTC->SetRegulationTarget(NULL);
					lspsim->LLBitSTC[LLBit].pInsSTC->SetInLoop(lspsim->m_bIsStatusInsLoop);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Replace(lspsim->LLBitSTC[LLBit].STCSourReg);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Replace(lspsim->LLBitSTC[LLBit].STCDestReg);
					pCB->AddOpeCode(lspsim->LLBitSTC[LLBit].pInsSTC, pCB->GetIndex(pIns));
	
					// Check whether ldl and stc be generated in loop sequence.
					// if ldl and stc in loop sequence wait untill to the end loop sequence then reset ldl stc sequence status.
					lspsim->LLBitSTC[LLBit].Reset();
					return true;
				} else {
					//!< Force LLBit clear.	
					if (!lspsim->LLBitSTC[LLBit].ForceSTCFail) {
						if (ForceClearLLBit (pCB, pIns,LLBit,lspsim)) {
							return true;
						}
					}
				}	
			}
		}
		
		// Intruction cause Interrupt/Exception.
		lspsim->m_pInsExp = pIns;
		return false;
	};
	
	/*
	 Function starting here.
	*/
	//!< Checking and generating stc instruction.
	if (lspsim->LLBitSTC[LLBit].IsSTCSuccess) {
		return InsertSTCSuccess(pCB,pIns,LLBit,lspsim);
	} else {
		return InsertSTCFail(pCB,pIns,LLBit,lspsim);
	}
}
/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::PredictLLBitInNextIns( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
	 
	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	//!< Check .
	UI32 nSTCaddress = lspsim->LLBitSTC[LLBit].STCAddress;
	std::string sMneIns = pIns->GetMne();
	bool bClearLLBit = false;
	UI32 cRange32Byte = 0xFFFFFFE0; 
	
	if (pIns->GetValid() == false) {
		return false;
	}
	/*
	 @Brief  - Checking momery range 32 byte access.
			 - Pridiction condition 1.
	*/
	// Checking memory access of ST kind instructions.
	if ((sMneIns == "st.b") || (sMneIns == "st.h") || (sMneIns == "st.w") || (sMneIns == "st.dw")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of SSTC kind instructions.
	if ((sMneIns == "sst.b") || (sMneIns == "sst.h") || (sMneIns == "sst.w")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		naddress+= (UI32)(*pIns->opr(1));
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of VST instruction.
	if ((sMneIns == "vst.b") || (sMneIns == "vst.h") 
		|| (sMneIns == "vst.w") || (sMneIns == "vst.dw")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}

		//TODO [NP]: Need to check modulo address calculating.
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of SET1 & NOT1 & CLR1 instruction.
	if ((sMneIns.find("set1") != std::string::npos) || (sMneIns.find("not1") != std::string::npos) || (sMneIns.find("clr1") != std::string::npos) ) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		SI32 nImm = (SI32)((UI32)(*pIns->opr(1))); // if Disp 16 return Imm else return 0.
		naddress += nImm; 
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}	
	}
	// Checking access of CAXI instruction.
	if (sMneIns.find("caxi") != std::string::npos) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true){
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		} 
	}
	// Remain prepare and push instruction.
	
	/*
	 @Brief  - Using clear CLL Instruction.
			 - Pridiction condition 2.
	*/
	if ((sMneIns == "cll") || (sMneIns == "est") ||(sMneIns == "dst") ) {
		bClearLLBit = true;
	}

	/*
	 @Brief  - FE/IE return Instruction.
			 - Pridiction condition 3.
	*/
	if (pIns->GetRegulationTarget() != NULL ) {
		if ((pIns->GetRegulationTarget()->GetMne() == "feret") || (pIns->GetRegulationTarget()->GetMne() == "eiret")) {
			bClearLLBit = true;
		}
	}
	/*
	 @Brief  - LDL STC With difference type and address access.
			 - Pridiction condition 4.
	*/
	if (sMneIns == "ldl.w") {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true){
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (naddress);
		UI32 nLLBit   = (LLBit+1);
		if (LLBitNum == nLLBit) {
			bClearLLBit = true;
		}
	}

	if (sMneIns == "stc.w") {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
			
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (naddress);
		UI32 nLLBit   = (LLBit+1);
		if (LLBitNum == nLLBit) {
			bClearLLBit = true;
		}
	}

	//[FROG]TODO Support predict handler. 

	// Checking access of 
	if (bClearLLBit) {
		return true;
	} else {
		return false;
	}
}

/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::ForceClearLLBit( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	
	/*Get the register that may contain PC value */
	auto GetJmpPC = [&](CCodeBlock* pCB, IInstruction* pIns){
        UI32 BannedReg = 0;
        if (pIns->Behavior(IInstruction::JMP)) {
            UI32 idx = pCB->GetIndex(pIns);
            if (idx != 0 && pCB->at(idx - 1)->GetMne() == "mov") {
                BannedReg = pCB->at(idx - 1)->opr(1)->Idx();
            }
        }
        return BannedReg;
	};
	UI32 regPC = GetJmpPC(pCB,pIns);
	//!< Adjust source and destination register of stc instruction to avoid loop counter.
	if (lspsim->m_bIsStatusInsLoop) {
		UI32 idx = pCB->GetIndex(pIns);
		IInstruction *pLoopIns = NULL;
		while(idx < pCB->GetInstructionNum()) {
			pLoopIns = pCB->at(idx);
			if(pLoopIns->GetMne() == "loop")
			break;
			idx++;
		}
		// Find the register that is used as source or dest of ld/st instructions
		UI32 BannedReg = 0;
		SI32 id = pCB->GetIndex(pIns);
		if (pIns->GetLabel().find("_Lp") == std::string::npos) {
			while(id >= 0) {
				IInstruction* pTmp = pCB->at(id);

                UI32 src = pTmp->GetGrSrc();
                BannedReg |= src;

				if (pTmp->GetLabel().find("_Lp") != std::string::npos)
					break;
				id--;
			}
		}
		//!< Replace source dest register of stc to void loop counter.
		UI32 loopCounter = pLoopIns->opr(0)->Idx();
		while ((lspsim->LLBitSTC[LLBit].STCSourReg == loopCounter) || (lspsim->LLBitSTC[LLBit].STCDestReg == loopCounter) 
			|| (lspsim->LLBitSTC[LLBit].STCSourReg == regPC) || (lspsim->LLBitSTC[LLBit].STCDestReg == regPC) || (BannedReg >> lspsim->LLBitSTC[LLBit].STCDestReg) & 0x1){
			lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
			lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
		}
	} else {
		while (lspsim->LLBitSTC[LLBit].STCSourReg == regPC || lspsim->LLBitSTC[LLBit].STCDestReg == regPC) {
			lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
			lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
		}
	}

	//!< Check .
	bool bInloopSequence = lspsim->m_bIsStatusInsLoop;
	UI32 nFailCase;
	if (bInloopSequence) {
		nFailCase = g_rnd.GetRange(2,4);
	} else {
		nFailCase = g_rnd.GetRange(1,5);
	}
	lspsim->LLBitSTC[LLBit].ForceSTCFail = true;
	
	//------------------------------------------------------------
	// lambda : AccessToRange32Byte
	//------------------------------------------------------------
	//     Insert into store instruction access to range 32 byte protected.  
	//------------------------------------------------------------
	auto AccessToRange32Byte = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
		
		const UI32 cRange32Byte = 0xFFFFFFE0;
		UI32 nAccessAddress = (lspsim->LLBitSTC[LLBit].STCAddress & cRange32Byte);
		UI32 nRegSTCDest = lspsim->LLBitSTC[LLBit].STCDestReg;
		UI32 nRegSTCSour = lspsim->LLBitSTC[LLBit].STCSourReg;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		UI32 size;
		IInstruction* pNewIns = NULL;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());

		UI32 ncase;
		
		if ((m_nPreciMismatchReg & 0xfffffffe) != 0)
			ncase = g_rnd.GetRange(1,4);
		else ncase = g_rnd.GetRange(1,6);

		std::set<MEMRANGE> AddSet = g_StorableAddr.KeySet();
		std::set<MEMRANGE>::iterator itr;
		IValConstraint *pConst;
		switch (ncase) {
			//!< Insert ST Instruction.
			case 1:
				// Id Ins 165 to 171 are Id ins of st instruction.
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_ST_B_SD16, INS_ID_ST_W_SD23))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				
				if ((m_nPreciMismatchReg & ((UI64)1 << ((UI32)(*pNewIns->opr(0))))) != 0) {
					for (UI32 r = 1; r < 32; r++) {
						if ((m_nPreciMismatchReg & ((UI64)1 << r)) == 0) pNewIns->opr(0)->Replace(r);
					}
				}
				
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				//nAccessAddress &=  (~(pNewIns->opr(1)->GetConstraint()->m_nMsk));
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Insert SST Instruction.
			case 2:
				// Ins Id of SST is 162 to 164
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_SST_B, INS_ID_SST_W))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pConst = pNewIns->opr(1)->GetConstraint();

				if ((m_nPreciMismatchReg & ((UI64)1 << ((UI32)(*pNewIns->opr(0))))) != 0) {
					for (UI32 r = 1; r < 32; r++) {
						if ((m_nPreciMismatchReg & ((UI64)1 << r)) == 0) pNewIns->opr(0)->Replace(r);
					}
				}
				
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert SET1 CLR1 NOT1 Instruction.
			case 3:
				switch (g_rnd.GetRange(1,3)) {
					//!< CLR1 Instruction.
					case 1:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_CLR1_SD16, INS_ID_CLR1))->Fix();
					break;
					//!< NOT1 Instruction.
					case 2:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_NOT1SD16, INS_ID_NOT1))->Fix();
					break;
					//!< SET1 Instruction.
					case 3:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_SET1_SD16, INS_ID_SET1))->Fix();
					break;
				}
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert CANXI Instruction.
			case 4:
				pNewIns = pInsSet->CreateIns(INS_ID_CAXI)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pNewIns->opr(0)->Replace(nRegSTCDest);
				pNewIns->opr(2)->Replace(nRegSTCSour);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert Push Instruction.
			case 5:
            {
                pNewIns = pInsSet->CreateIns(INS_ID_PUSHSP)->Fix();
                // Because size of llbit area is 32 byte. So range of pushsp less than 8 register
                UI32 rh = g_rnd.GetRange(0, 31);
                UI32 rt = (rh + 7 > 31) ? 31 : g_rnd.GetRange(rh, rh + 7);
                pNewIns->opr(0)->Replace(rh);
                pNewIns->opr(1)->Replace(rt);

                pIns->DirMoveTo(pNewIns);
                pNewIns->SetInLoop(InloopSequence);
                pConst = pNewIns->opr(0)->GetConstraint();
                if (pConst != NULL) {
                    pConst->SetRange(nAccessAddress, nAccessAddress + 32);
                    pConst->SetType(IValConstraint::ACCESS_RANGE);
                }
                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                size++;
            }
			break;
			// Insert Prepare Instruction.
			case 6:
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INST_ID_PREPARE, INST_ID_PREPARE_I32))->Fix();
				pIns->DirMoveTo(pNewIns);
				pNewIns->SetInLoop(InloopSequence);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
		}
		
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};
	//------------------------------------------------------------
	// lambda : ClearByIERET_FERET
	//------------------------------------------------------------
	//          Insert one of FERET and IERET instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByIERET_FERET = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
		UI32 ncase =  g_rnd.GetRange(1,2);
		IInstruction* pAdjustIns;
		IInstruction* pNewIns = NULL;
		UI32 reg1 = lspsim->LLBitSTC[LLBit].STCDestReg;
		//UI32 reg2 = lspsim->m_nSTCSourtReg;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		
		char buff[100];
		sprintf(buff, "_ldl_stc_%#x_%#x_%#x", lspsim->LLBitSTC[LLBit].STCAddress, lspsim->LLBitSTC[LLBit].STCTargetPosition, (LLBit+1));
		std::string dstInsLabel = pCB->GetLabel()+buff;
			
		switch (ncase) {
			//!< Generating eiret instruction.
			case 1:
				pNewIns = new CIns_74_eiret();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->m_bBreakNotSS = true;
				pNewIns->SetTaken(true);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				pAdjustIns  = MOV32P (dstInsLabel, reg1);
				pIns->DirMoveTo(pAdjustIns);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));


				pAdjustIns = LDSR (reg1, 0, 0); // R->eipc
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns  = STSR (5, reg1, 0); // psw->R // Rの値を潰してPC依存を切断
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns = LDSR (reg1, 1, 0); // R->eipsw
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pIns->SetLabel(dstInsLabel);

			break;

			case 2:
				pNewIns = new CIns_75_feret();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->m_bBreakNotSS = true;
				pNewIns->SetTaken(true);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				pAdjustIns  = MOV32P (dstInsLabel, reg1);
				pIns->DirMoveTo(pAdjustIns);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));


				pAdjustIns = LDSR (reg1, 2, 0); // R->fepc
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns  = STSR (5, reg1, 0); // psw->R // Rの値を潰してPC依存を切断
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns =LDSR (reg1, 3, 0); // R->fepsw
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pIns->SetLabel(dstInsLabel);
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};
	//------------------------------------------------------------
	// lambda : ClearByCLL
	//------------------------------------------------------------
	//          Insert one of CLL instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByCLL_EST_DST = [&] (CCodeBlock* pCB, IInstruction* pIns) {
		IInstruction* pNewIns;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		// Insert CLL Instruction.
		pNewIns = new CIns_55_cll();
		pNewIns->SetInLoop(InloopSequence);
		pIns->DirMoveTo(pNewIns);
		pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};

	//------------------------------------------------------------
	// lambda : ClearByLDL_STC
	//------------------------------------------------------------
	//          Insert ldl and stc instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByLDL_STC = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
		UI32 ncase =  g_rnd.GetRange(1,2);
		UI32 nRegSTCDest = lspsim->LLBitSTC[LLBit].STCDestReg;
		UI32 nRegSTCSour = lspsim->LLBitSTC[LLBit].STCSourReg;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		IInstruction* pNewIns = NULL;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());	

		switch (ncase) {
			//!< Generating ldl instruction.
			case 1:
				pNewIns = pInsSet->CreateIns(INS_ID_LDL_W)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->opr(0)->Replace(nRegSTCDest);
				pNewIns->opr(1)->Replace(nRegSTCSour);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;

			case 2:
				pNewIns = pInsSet->CreateIns(INS_ID_STC_W)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->opr(0)->Replace(nRegSTCSour);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};

	//------------------------------------------------------------
	// lambda : ClearByExecption
	//------------------------------------------------------------
	//      Insert expection or interupt to clear LLBit  
	//------------------------------------------------------------
	auto ClearByExecption = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
	
		UI32 ncase =  g_rnd.GetRange(0,6);
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		IInstruction* pNewIns = NULL;
		static CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());

		// Collect the weight of exception to avoid generating the disabled exception
		static UI32 ExpWeight[7] = {
			pInsSet->GetWeight(CIns_76_fetrap::m_id) + g_exp->GetWeight(IException::EXP_FETRAP), 
			pInsSet->GetWeight(CIns_184_trap::m_id) + g_exp->GetWeight(IException::EXP_TRAP0) + g_exp->GetWeight(IException::EXP_TRAP1),
			pInsSet->GetWeight(CIns_193_hvtrap::m_id),
			pInsSet->GetWeight(CIns_127_rie::m_id) + pInsSet->GetWeight(CIns_128_rie::m_id) + g_exp->GetWeight(IException::EXP_RIE),
			pInsSet->GetWeight(CIns_192_hvcall::m_id),
			pInsSet->GetWeight(CIns_183_syscall::m_id ),
			g_exp->GetWeight(IException::EXP_UCPOP0) + g_exp->GetWeight(IException::EXP_UCPOP1) + g_exp->GetWeight(IException::EXP_UCPOP2)
		};

		for (UI32 i = 0; i < 7 /*size of above array*/; i++) {
			if (ExpWeight[ncase] != 0) 
				break;
			else 
				ncase = (ncase + 1) % 7;
		}
		
		if (ExpWeight[ncase] == 0)
			ncase = 7;

		switch (ncase) {
			//!< Generating FETRAP.
			case 0:
				pNewIns = pInsSet->CreateIns(INS_ID_FETRAP)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating TRAP.
			case 1:
				pNewIns = pInsSet->CreateIns(INS_ID_TRAP)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating HVTRAP.
			case 2:
				pNewIns = pInsSet->CreateIns(INS_ID_HVTRAP)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating RIE.
			case 3:
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_RIE, INS_ID_RIE_I9))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating HVCALL.
			case 4:
				pNewIns = pInsSet->CreateIns(INS_ID_HVCALL)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating SYSCALL.
			case 5:
				pNewIns = pInsSet->CreateIns(INS_ID_SYSCALL)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating UCPOP.
			case 6:
				// [FROG]TODO: If SIMD was enable, it is not cause UCPOP
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_CNVQ15Q30, INS_ID_VXOR))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			default:
				// If there are no suiatble exception, clear by accessing memory
				AccessToRange32Byte(pCB,pIns,LLBit,lspsim);
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};

	switch (nFailCase) {
		
		// Generate access to range 32 byte link bit protected. 
		case 1:
			AccessToRange32Byte(pCB,pIns,LLBit,lspsim);
			return true;
		break;
		 // Clear by CLL instruction.
		case 2:
			ClearByCLL_EST_DST(pCB,pIns);
			return true;
		break;
		 // Clear by eiret, feret instructions.
		case 3:
			ClearByIERET_FERET(pCB,pIns,LLBit,lspsim);
			return true;
		break;
		 // Clear by ldl and stc instruction.
		case 4:
			ClearByLDL_STC(pCB,pIns,LLBit,lspsim);
			return true;
		break;
		// Clear by expection.
		case 5:
			ClearByExecption(pCB,pIns,LLBit,lspsim);
			return true;
		break;
	}

	return false;

}

void CSimulatorControl::PrepareDeletedIns(CCodeBlock *pCB, IInstruction *pIns) {
	SI32 idx = pCB->GetIndex(pIns) - 1;
	IInstruction *p;
	UI32 max_try = 10;	// [FROG]TODO: Define this

	if (pIns->GetRiePartner() != nullptr) {
		pCB->Remove(pIns->GetRiePartner());
		pIns->SetRiePartner(nullptr);
		pCB->Update();
	}

	// Remove link to its adjustment code.
	while(idx >= 0 && max_try >= 0) {
		p = pCB->at(idx);

		if(p->GetRegulationTarget() != NULL) {
			if(p->GetRegulationTarget() == pIns)
				p->SetRegulationTarget(nullptr);
		}
		if(p->GetC2B1Ins() != NULL) { // If removed instruction is 2nd ins. of C2B1
			if(p->GetC2B1Ins() == pIns)
				p->SetC2B1Ins(nullptr);
		} /*else
			break;*/
		idx--;
		max_try--;
	}
}

IExceptionConfig* CSimulatorControl::IdentifyException(IException* pExp, UI32 code) {
	std::vector<IExceptionConfig*> vExp;
	std::vector<IExceptionConfig*>::iterator itr;
	IExceptionConfig* pCfg = NULL;
	auto CheckRequestedInterrupt = [=](std::string InputInterruptName, std::string RequestedInterruptName) -> bool {
		if ((InputInterruptName.find("ei") == 0 && RequestedInterruptName.find("ei") == 0) ||
			(InputInterruptName.find("fe") == 0 && RequestedInterruptName.find("fe") == 0) ||
			(InputInterruptName.find("gmei") == 0 && RequestedInterruptName.find("gmei") == 0) ||
			(InputInterruptName.find("gmfe") == 0 && RequestedInterruptName.find("gmfe") == 0)) {
			return true;
		}
		return false;
	};
	vExp = pExp->GetConfigByCode(code);

	if(vExp.size() == 0)
		return NULL;

	if(vExp.size() == 1)
		return vExp[0];

	itr = vExp.begin();
	while(itr < vExp.end()) {
		std::string exp = (*itr)->m_name;
		std::vector<CIntInfo*>::iterator itrReqEvent;
		// Convert to lower cases
		std::transform(exp.begin(), exp.end(), exp.begin(), [] (int ch) {return std::tolower(ch);});
		if((*itr)->m_bIsInterrupt) {
			for(itrReqEvent = m_vRequestedIntStack.begin(); itrReqEvent < m_vRequestedIntStack.end(); itrReqEvent++){
				if(CheckRequestedInterrupt(exp,(*itrReqEvent)->sName)){
					break;
				}
			}	
			if(itrReqEvent == m_vRequestedIntStack.end()) {
				itr = vExp.erase(itr);
				continue;
			}
		} else {
			pCfg = (*itr);
			itr = vExp.erase(itr);
			continue;
		}
		itr++;
	}
	// There is no async. event requested.
	if(vExp.size() == 0)
		return pCfg;
	else {
		//TODO: Generalize this sequence
		if(vExp.size() == 2 && vExp[1]->m_name == "dbnmi"){
			pCfg = vExp[1];
		} else
			pCfg = vExp[0];
	}
	return pCfg;
}


UI32 CSimulatorControl::IsMDPexception(MEMADDR start_addr, UI32 size, bool IsLoad, bool IsStore) {
    UI32 psw = GetPSW();
    UI32 mdp_mask = 0;

    if (IsLoad)
        mdp_mask |= (psw & 0x40000000) ? 0x1 : 0x8;

    if (IsStore)
        mdp_mask |= (psw & 0x40000000) ? 0x2 : 0x10;

    UI32 error_code = CheckMPUexception(start_addr, size, mdp_mask);
    return error_code;
}

/**
*@brief	Regulate MPU update sequence
*/
bool CSimulatorControl::RegulateMPUupdate(CCodeBlock *pCB, UI32 jump_reg) {
    UI32 hvcfg = 0;
    IInstruction* pIns = nullptr;
    IInstruction* target_ins = nullptr;
    UI32 reg = 0, mpm = 0;
    char str[80]; // Comment

    do {
        reg = g_rnd.GetRange(1, 30);
    } while (reg == jump_reg || jump_reg == (reg + 1));

    m_pSim->ReadNcReg(&hvcfg, 16, 1);
    // HVCFG.HVE = 1
    if ((hvcfg & 0x1) != 0) {
        if (RandomGuest_HostEntries(pCB, reg) == false)
            return false;
    } else {
        // Convention Mode
        RandomMPUofConventionMode(pCB, reg);  
    }

    mpm = g_rnd.GetRange(0, 7);
    pIns = new CIns_104_mov();
    pIns->opr(0)->Replace(mpm);
    pIns->opr(1)->Replace(reg);
    sprintf(str, "MPM= 0x%08x", mpm);
    pIns->AppendComment((LPCTSTR)str);
    pCB->AddOpeCode(pIns);
    target_ins = LDSR(reg, 0, 5);
    pIns->SetRegulationTarget(target_ins);
    pCB->AddOpeCode(target_ins);
    pIns = SYNCI();
    pIns->SetSequence();
    pCB->AddOpeCode(pIns);

    pIns = JMP32(jump_reg);
    pIns->AppendComment("--> Return");
    pCB->AddOpeCode(pIns);
    g_mgr->AddDeadCode(pCB);

    pCB->SetBlockGap(0x10);
    if (g_asf->MakeLabelHash(pCB) != true || g_asf->LabelResolve(pCB) != true) {
        MSG_ERROR(0, "Fail to allocate cobe block");
        return false;
    }
    return true;
}

/**
*@brief	Random value for MPIDn (n: 0 -> 7) and SPID
*/
void CSimulatorControl::RandomMPIDn_SPID(CCodeBlock *pCB, UI32 reg) {
    const UI32 SPID_MAX = 31; //!< Maximum value of SPID.
    const UI32 MPID_NUM = 8;
    UI32 hvcfg = 0;
    UI32 selId = 5;    // selId MPID0
    UI32 regId = 24;    // regId MPID0
    UI32 SPID_value = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
    UI32 SPID_Hit = g_rnd.GetRange((UI32)0, (UI32)MPID_NUM);
    UI32 MPIDn_List[MPID_NUM]; //!< List random value of MPIDn.
    m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);

    for (UI32 i = 0; i< MPID_NUM; i++) {
        if (SPID_Hit == 0) {
            MPIDn_List[i] = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
        } else {
            if (i <= (SPID_Hit - 1)) {
                MPIDn_List[i] = SPID_value;
            } else {
                do {
                    MPIDn_List[i] = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
                } while (MPIDn_List[i] == SPID_value);
            }
        }
    }
    std::random_shuffle(std::begin(MPIDn_List), std::end(MPIDn_List), g_rnd);
    for (UI32 i = 0; i < MPID_NUM; i++) {
        NewINS(pCB, MOV5(MPIDn_List[i], reg));
        NewINS(pCB, LDSR(reg, regId + i, selId));
    }

    NewINS(pCB, MOV5(SPID_value, reg));
    NewINS(pCB, LDSR(reg, 0, 1));       // SPID

    if ((hvcfg & 0x1) != 0) {
        NewINS(pCB, LDSR(reg, 16, 9));       // GMSPID
    }
}

/**
*@brief Update MPU register of Host management and Guest Entries
*/
bool CSimulatorControl::RandomGuest_HostEntries(CCodeBlock *pCB, UI32 reg) {
    UI32 pswh = 0, gmmpcfg = 0;
    UI32 val = 0;
    UI32 mpnum = g_hwInfo.m_mpnum;
    T_MP_SETTING 	m_mp_table;
    IInstruction* pIns = nullptr;

    m_pSim->ReadNcReg(&gmmpcfg, 26, 9);
    m_pSim->ReadNcReg(&pswh, 15, 0);
    UI32 hbe = (gmmpcfg >> 8) & 0x3f;
    UI32 end_entry = hbe - 1;
    UI32 gpid = (pswh >> 8) & 0x7;

    // each entry has 3 regester (MPLA, MPUA, MPAT) which need to initialize
    // we use 4 byte to store value of each register
    MEMADDR vacancy_mem = m_pSim->FindVacantMemory(mpnum * 3 * 4, 4);
    if (vacancy_mem == 0) return false;
    MEMADDR temp_vacancy_mem = 0;

    if ((pswh >> 31) == 0) {
        // Host Mode
        end_entry = mpnum - 1;

        hbe = m_MPUlist->RandomHBE();
        NewINS(pCB, MOV32((hbe << 8), reg + 1));
        NewINS(pCB, LDSR(reg + 1, 26, 9));        // GMMPCFG

        m_MPUlist->Fix(HOST_ENTRY);
        m_MPUlist->OutMpuSetting(&m_mp_table, HOST_ENTRY, hbe, mpnum);
        // find locate of memory to start store MPU information of host management to memory
        temp_vacancy_mem = vacancy_mem + hbe * 4 * 3;

        for (UI32 mp_idx = hbe; mp_idx < mpnum; mp_idx++) {
            for (UI32 idx = 0; idx < 3; idx++) {
                val = m_mp_table[mp_idx][idx];
                m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
                temp_vacancy_mem = temp_vacancy_mem + 4;
            }
        }

        // Random value for MPIDn(n: 0 -> 7) and SPID
        RandomMPIDn_SPID(pCB, reg + 1);
    }

    m_MPUlist->Fix(gpid);
    m_MPUlist->OutMpuSetting(&m_mp_table, gpid, 0, hbe);
    temp_vacancy_mem = vacancy_mem;
    // store MPU information of guest management to memory
    for (UI32 mp_idx = 0; mp_idx < hbe; mp_idx++) {
        for (UI32 idx = 0; idx < 3; idx++) {
            val = m_mp_table[mp_idx][idx];
            m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
            temp_vacancy_mem = temp_vacancy_mem + 4;
        }
    }

    pIns = MOV32(vacancy_mem, reg);
    pIns->AppendComment(" Prepare memory for MPU update ");
    pCB->AddOpeCode(pIns);
    pIns = LDM_MP(reg, 0, end_entry);
    pIns->AppendComment(" MPU update ");
    pCB->AddOpeCode(pIns);
    return true;
}

/**
*@brief	Update MPU register of Convention entries
*/
void CSimulatorControl::RandomMPUofConventionMode(CCodeBlock *pCB, UI32 reg) {
    UI32 val = 0, id = 0;
    UI32 mpnum = g_hwInfo.m_mpnum;
    T_MP_SETTING 	m_mp_table;

    UI32 start_entry = g_rnd.GetRange((UI32)0, mpnum - 1);
    UI32 end_entry = g_rnd.GetRange(start_entry + 1, mpnum);

    // Random a setting  machine for convention mode
    if (g_cfg->m_mGMs.size()) {
        // support random HVCFG register
        std::map<UI32, GM_Infor>::iterator gm_itr = g_cfg->m_mGMs.begin();
        UI32 idx = g_rnd.GetRange((UI32)0, g_cfg->m_mGMs.size() - 1);
        std::advance(gm_itr, idx);
        id = gm_itr->first;  //GMID
    } else {
        id = CONVENTION_ENTRY;
    }

    m_MPUlist->Fix(id);
    m_MPUlist->OutMpuSetting(&m_mp_table, id, start_entry, end_entry);
    UI32 regId = 20, selId = 5;     // MPLA
    UI32 mpidx = 0, new_mpidx = 0;

    for (mpidx = start_entry; mpidx < end_entry; mpidx++) {
        // MPIDX
        NewINS(pCB, MOV5(mpidx, reg));
        NewINS(pCB, LDSR(reg, 16, 5));
        // MPLA
        val = m_mp_table[mpidx][0];
        NewINS(pCB, MOV32(val, reg));
        NewINS(pCB, LDSR(reg, regId, selId));
        // MPUA
        val = m_mp_table[mpidx][1];
        NewINS(pCB, MOV32(val, reg));
        NewINS(pCB, LDSR(reg, regId + 1, selId));
        // MPAT
        val = m_mp_table[mpidx][2];
        NewINS(pCB, MOV32(val, reg));
        NewINS(pCB, LDSR(reg, regId + 2, selId));
    }

    new_mpidx = mpidx - 1;
    while (g_prf->IsWorkMPURegionByIdx(new_mpidx)) {
        new_mpidx = g_rnd.GetRange((UI32)0, (UI32)mpnum - 1);
    }

    if (new_mpidx != (mpidx - 1)) {
        NewINS(pCB, MOV5(new_mpidx, reg));
        NewINS(pCB, LDSR(reg, 16, 5));
    }

    // Random value for MPIDn(n: 0 -> 7) and SPID
    RandomMPIDn_SPID(pCB, reg + 1);
}

UI32 CSimulatorControl::IsMIPexception(MEMADDR start_addr, UI32 size) {
    UI32 PSW = GetPSW();
    UI32 mip_mask = (PSW & 0x40000000) ? 0x4 : 0x20;
    UI32 error_code = CheckMPUexception(start_addr, size, mip_mask);

    return error_code;
}

/* @brief check whether memory area(start to end) have occur MIP/MDP or not.
* @return true if memory area occur MIP/MDP exception
*/
UI32 CSimulatorControl::CheckMPUexception(MEMADDR start_addr, UI32 size, UI32 mask) {
    UI32 error_code = NO_ERROR;
    UI32 mpm = m_pSim->GetMPM();
    UI32 spid_mpidn = m_pSim->GetSPID_MPIDn();
    UI32 permission = 0;
    UI32 hbe = 0, hvcfg = 0;
    FrogRegData val = 0;

    gcs_get_nc_register("GMMPCFG", &val);
    hbe = ((UI32)val >> 8) & 0x3f;
    gcs_get_nc_register("HVCFG", &val);
    hvcfg = (UI32)val;

    UI32 end_addr = start_addr + size - 1;

    // match: checking whether addr has belong to any MPU channel or not.
    // start, end is start channel and end channel. 
    // svp_mask: variable to check permission depend on GMMPM.SVP

    auto GetPermission = [=](UI32 start_entry, UI32 end_entry) -> UI32 {
        UI32 permission = 0;

        for (UI32 mpidx = start_entry; mpidx < end_entry; mpidx++) {
            UI32 mpu_lower = m_pSim->GetMPLA(mpidx);
            UI32 mpu_upper = m_pSim->GetMPUA(mpidx) | 0x3;
            if (mpu_lower >= mpu_upper) {
                continue;
            }
            if ((mpu_lower > start_addr) || (end_addr > mpu_upper)) {
                //!・・OutOfRange
                continue;
            }

            UI32 mpat = m_pSim->GetMPAT(mpidx);
            if ((mpat & 0x80) == 0) {
                // channel is disable
                continue;
            }

            if ((mpat & 0x4000) != 0 || ((mpat >> 16) & spid_mpidn) != 0) {	// Check XR permission
                permission |= (mpat & 0x2d);
            }

            if ((mpat & 0x8000) != 0 || ((mpat >> 24) & spid_mpidn) != 0) { // Check W permission
                permission |= (mpat & 0x12);
            }
        }
        return permission;
    };

    if ((hvcfg & 0x1) != 0) {
        if ((mpm & 0x1) != 0) {
            permission = IsGuestMode() ? GetPermission(0, hbe) : GetPermission(hbe, g_hwInfo.m_mpnum);
            if ((mpm & 0x2) == 0) permission |= 0x38;  // MPM.SVP

            if ((permission & mask) != mask) {
                error_code = IsGuestMode() ? VIOLATE_GUEST_ENTRY : VIOLATE_HOST_ENTRY;
                return error_code;
            }
        } 

        if((mpm & 0x4) != 0) {
            permission = GetPermission(hbe, g_hwInfo.m_mpnum);

            if ((permission & mask) != mask) {
                error_code = VIOLATE_HOST_ENTRY;
                return error_code;
            }
        }

    } else {
        // Convention mode
        permission = GetPermission(0, g_hwInfo.m_mpnum);
        if ((mpm & 0x2) == 0) permission |= 0x38;     // MPM.SVP

        if ((permission & mask) != mask) {
            error_code = VIOLATE_CONVENTION_ENTRY;
            return error_code;
        }
    }

    return error_code;
}

bool CSimulatorControl::IsNotSelfCheckMemory(UI32 address) {
    std::map<UI32, UI32>::iterator itr = m_mNotSelfCheckMemoryList.upper_bound(address);
    if (itr != m_mNotSelfCheckMemoryList.begin()) {
        itr--;
        if (address >= itr->first && address <= itr->second)
            return true;
    }

    return false;
}