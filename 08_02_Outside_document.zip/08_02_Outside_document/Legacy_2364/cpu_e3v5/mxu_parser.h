#ifndef MXU_PARSER_H_
#define MXU_PARSER_H_

#include "rtg_common.h"

extern std::shared_ptr<CGeneratorProfile>		g_prf;
extern std::vector<std::pair<UI32, MEMRANGE>>	g_FixedMPU;
extern std::shared_ptr<CGeneratorConfig>		g_cfg;
extern std::unique_ptr<ISysRegSet>	            g_srs;
/**
 * @brief ＴＬＢエントリー情報クラス
 */
class CParserTlbInfo{
public:
    CParserTlbInfo(UI32 telo1 , UI32 telo0 ,UI32 tehi1 ,UI32 tehi0) : m_telo1(telo1) , m_telo0(telo0) ,m_tehi1(tehi1) ,m_tehi0(tehi0) {}
    ~CParserTlbInfo(){}
public:
	UI32 m_telo1 ;
	UI32 m_telo0 ;
	UI32 m_tehi1 ;
	UI32 m_tehi0 ;
} ;

/**
 * @brief ＴＬＢエントリー情報スロットクラス
 */
class CParserTlbSlot {
public:
	
	CParserTlbSlot() {
		m_TlbSlot.clear() ;
	}
	
	~CParserTlbSlot() {
		Clear();
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報スロットをクリアする
	 */
	void Clear() {
		std::vector<CParserTlbInfo*>::iterator itr;
		for (itr = m_TlbSlot.begin(); itr != m_TlbSlot.end(); itr++) {
			delete *itr;
		}
		m_TlbSlot.clear();
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報スロットにエントリー情報を追加する
	 */
	void Set(UI32 telo1 , UI32 telo0 ,UI32 tehi1 ,UI32 tehi0) {
		m_TlbSlot.push_back(new CParserTlbInfo(telo1 , telo0 ,tehi1 ,tehi0)) ;
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報スロットにセットされているＴＬＢエントリー情報数を取得する
	 */
	UI32 Size( void ) {
		return (m_TlbSlot.size()) ;
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報クラスの先頭アドレスを取得する
	 */
	CParserTlbInfo * Get(UI32 index) {
		return (m_TlbSlot.at(index)) ;
	}

protected:
	std::vector<CParserTlbInfo*> m_TlbSlot ;		// ＴＬＢエントリー情報スロット
} ;

/**
 * @brief ＴＬＢエントリー情報リストクラス
 */
class CParserTlbList {
public:
	
	CParserTlbList() {
//		m_TlbList.clear() ;
	}
	
	~CParserTlbList() {
		Clear();
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報リストをクリアする
	 */
	void Clear() {
		std::vector<CParserTlbSlot*>::iterator itr;
		for (itr = m_TlbList.begin(); itr != m_TlbList.end(); itr++) {
			delete *itr;
		}
		m_TlbList.clear();
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報リストにエントリー情報を追加する
	 */
	void Set(CParserTlbSlot * slot) {
		m_TlbList.push_back(slot) ;
	}
	
	/**
	 * @brief	ＴＬＢエントリー情報リストにセットされているスロット数を取得する
	 */
	UI32 Size( void ) {
		return (m_TlbList.size()) ;
	}
	
	/**
	 * @brief	指定されたＴＬＢエントリー情報クラスの先頭アドレスを取得する
	 */
	CParserTlbSlot * Get(UI32 slot_no) {
		return (m_TlbList.at(slot_no)) ;
	}

protected:
	std::vector<CParserTlbSlot*> m_TlbList ;
} ;



/**
 * @brief	MPU/MMU設定 要素オブジェクト
 */
class CMmItem {
public:
	CMmItem( UI32 addr , UI32 rand_1 , UI32 size , UI32 rand_2 , UI32 priv , UI32 rand_3, UI32 PerArbSPID, UI32 rand_4, UI32 ReadPerMPIDn, UI32 rand_5,
		UI32 WritePerMPIDn, UI32 rand_6, bool valid , bool global, bool lock=false ,bool hvc=false)
		: m_nAddr(addr)
		, m_nAddrRnd(rand_1)
		, m_nSize(size)
		, m_nSizeRnd(rand_2)
		, m_nPriv(priv)
		, m_nPrivRnd(rand_3)
		, m_nPerArbSPID(PerArbSPID)
		, m_nPerArbSPIDRnd(rand_4)
		, m_nReadPerMPIDn(ReadPerMPIDn)
		, m_nReadPerMPIDnRnd(rand_5)
		, m_nWritePerMPIDn(WritePerMPIDn)
		, m_nWritePerMPIDnRnd (rand_6)
		, m_bValid(valid)
		, m_bGlobal(global)
		, m_bLock(lock)
		, m_bHVC(hvc)
		{}
	~CMmItem(){}
public:
	UI32 m_nAddr ,m_nAddrRnd ;	//!< 領域先頭アドレス（固定部，乱数部）
	UI32 m_nSize ,m_nSizeRnd ;	//!< 領域サイズ（固定部，乱数部）
	UI32 m_nPriv ,m_nPrivRnd ;	//!< 領域に対する要求権限　bit[5:0] is { SX ,SW ,SR ,UX ,UW ,UR }　（固定部，乱数bit）

	UI32 m_nPerArbSPID, m_nPerArbSPIDRnd;		//!< RG/WG permission with arbitrary SPID.
	UI32 m_nReadPerMPIDn, m_nReadPerMPIDnRnd;	//!< Execution and the reading permission with SPID specified with MPIDn.
	UI32 m_nWritePerMPIDn, m_nWritePerMPIDnRnd;	//!< Write permission with SPID specified with MPIDn.

	bool m_bValid ;					//!< valid bit
	bool m_bGlobal ;				//!< global bit
	bool m_bLock ;					//!< lock bit
	bool m_bHVC ;
	UI32 m_nAddrFix ;				//!< 領域先頭アドレス（乱数解決後）
	UI32 m_nSizeFix ;				//!< 領域サイズ（乱数解決後）
	UI32 m_nPrivFix ;				//!< 領域に対する要求権限（乱数解決後
	UI32 m_nRWPerArbSPIDFix;		//!< RG/WG permission with arbitrary SPID fixed value.
	UI32 m_nReadPerMPIDnFix;		//!< Read and execute MPIDn permission with specific SPID fixed value.
	UI32 m_nWirtePerMPIDnFix;		//!< Write MPIDn permission with specific SPID fixed value.
};



/**
 * @brief	MPU/MMU設定 アドレス空間オブジェクト
 */
class CMmVmAsItem {
public:
	CMmVmAsItem() {}
	~CMmVmAsItem() {
		std::vector<CMmItem*>::iterator itr;
		for (itr = m_MmVmAsItem.begin(); itr != m_MmVmAsItem.end(); itr++) {
			delete *itr;
		}
	}
	/**
	 * @brief	アドレス空間オブジェクトに要素オブジェクトを追加する
	 */
	void Set( UI32 addr , UI32 rand_1 , UI32 size , UI32 rand_2 , UI32 priv , UI32 rand_3, UI32 PerArbSPID, UI32 rand_4, UI32 ReadPerMPIDn, UI32 rand_5,
		UI32 WritePerMPIDn, UI32 rand_6, bool valid , bool global, bool lock=false ,bool hvc=false ) {
		m_MmVmAsItem.push_back(new CMmItem( addr , rand_1 , size , rand_2 , priv , rand_3 , PerArbSPID, rand_4, ReadPerMPIDn, rand_5, WritePerMPIDn, rand_6, valid , global, lock ,hvc )) ;
	}
	/**
	 * @brief	指定された要素オブジェクトを取得する
	 */
	CMmItem * Get( UI32 index ) {
		if (m_MmVmAsItem.size() <= index) {
			return (NULL) ;
		}
		CMmItem * ret= m_MmVmAsItem.at(index) ;
		return (ret) ;
	}
	/**
	 * @brief	アドレス空間オブジェクトに登録されている要素オブジェクト数を取得する
	 */
	UI32 Size() {
		UI32 ret= m_MmVmAsItem.size() ;
		return (ret) ;
	}

protected:
	std::vector<CMmItem*> m_MmVmAsItem ;
};



/**
 * @brief	MMU/MPU設定情報オブジェクト
 */
class CMmList {
public:
	CMmList() : m_CommonRomSiz(0) ,  m_CommonRamSiz(0) , m_hbe(0) , m_reserve_entry(0) {}
	~CMmList() {
		std::map<UI32 ,CMmVmAsItem*>::iterator itr;
		for (itr = m_MmList.begin(); itr != m_MmList.end(); itr++) {
			delete itr->second ;
		}
	}
	/**
	 * @brief	アドレス空間オブジェクトを追加する
	 */
	CMmVmAsItem * Set( UI32 machineId) {
        CMmVmAsItem * pMmVmAs = Get(machineId) ;
		if (pMmVmAs == NULL) {
            pMmVmAs= new CMmVmAsItem() ;
		    m_MmList.insert( std::pair<UI32 ,CMmVmAsItem*>(machineId, pMmVmAs));
        }
		return (pMmVmAs) ;
	}
	/**
	 * @brief	アドレス空間オブジェクトを追加する
	 */
	void Set( UI32 machineId, UI32 addr , UI32 rand_1 , UI32 size , UI32 rand_2 , UI32 priv , UI32 rand_3 , UI32 PerArbSPID, UI32 rand_4, UI32 ReadPerMPIDn, UI32 rand_5,
		UI32 WritePerMPIDn, UI32 rand_6, bool valid , bool global) {
        
		CMmVmAsItem * pMmVmAs = Get(machineId) ;
		if (pMmVmAs == NULL) {
            CMmVmAsItem * pMmVmAs= new CMmVmAsItem() ;
		    m_MmList.insert( std::pair<UI32 ,CMmVmAsItem*>(machineId, pMmVmAs ));
        }
        pMmVmAs->Set(addr , rand_1 , size , rand_2 , priv , rand_3 , PerArbSPID, rand_4, ReadPerMPIDn, rand_5, WritePerMPIDn, rand_6, valid , global) ;
	}
	/**
	 * @brief	指定されたアドレス空間オブジェクトを検索・取得する
	 */
	CMmVmAsItem * Get( UI32 machineId) {
		std::map<UI32 ,CMmVmAsItem*>::iterator itr;
		itr= m_MmList.find(machineId);
		if (itr == m_MmList.end()) {
			return (NULL) ;
		}
		CMmVmAsItem * ret= itr->second ;
		return (ret) ;
	}
	/**
	 * @brief	登録されているアドレス空間オブジェクト数を取得する
	 */
	UI32 Size() {
		UI32 ret= m_MmList.size() ;
		return (ret) ;
	}

    /**
    * @brief	return HBE
    */
    UI32 GetHBE() {
        return m_hbe;
    }

    /**
    * @brief	return reserve_entry
    */
    UI32 GetReserveEntry() {
        return m_reserve_entry;
    }
	/**
	 * @brief	Random value for each field in MPU setting of machineId
     * 
	 */
	void Fix(UI32 machineId) {

		CMmVmAsItem * pMmVmAs ;
		CMmItem * pMmItem ;
        pMmVmAs = Get(machineId);
        if (pMmVmAs == nullptr) return;
        //!・・the random number component of the start address, size and access right of the test area is confirmed.
        UI32 size = pMmVmAs->Size();
        for (UI32 i = 0; i < size; i++) {
            pMmItem = pMmVmAs->Get(i);
            pMmItem->m_nAddrFix = pMmItem->m_nAddr + g_rnd.GetRange((UI32)0, (UI32)(pMmItem->m_nAddrRnd));
            pMmItem->m_nSizeFix = pMmItem->m_nSize + g_rnd.GetRange((UI32)0, (UI32)(pMmItem->m_nSizeRnd));
            UI32 rand = g_rnd.GetRange((UI32)0, (UI32)0xffffffff);
            UI32 mask = pMmItem->m_nPrivRnd;
            pMmItem->m_nPrivFix = ((pMmItem->m_nPriv & ~mask) | (rand & mask));

            // Calculating value for RG/WG fixed bit.
            rand = g_rnd.GetRange((UI32)0, (UI32)0xffffffff);
            UI32 RWPerArbSPID_mask = pMmItem->m_nPerArbSPIDRnd;
            UI32 PerArbSPID = ((pMmItem->m_nPerArbSPID & ~RWPerArbSPID_mask) | (rand & RWPerArbSPID_mask));
            pMmItem->m_nRWPerArbSPIDFix = (PerArbSPID << 14);

            // Calculating value of RMPDIn
            rand = g_rnd.GetRange((UI32)0, (UI32)0xffffffff);
            UI32 ReadPerMPIDn_mask = pMmItem->m_nReadPerMPIDnRnd;
            UI32 ReadPerMPIDn = ((pMmItem->m_nReadPerMPIDn & ~ReadPerMPIDn_mask) | (rand & ReadPerMPIDn_mask));
            pMmItem->m_nReadPerMPIDnFix = (ReadPerMPIDn << 16);

            // Calculating value of WMPDIn
            rand = g_rnd.GetRange((UI32)0, (UI32)0xffffffff);
            UI32 WritePerMPIDn_mask = pMmItem->m_nWritePerMPIDnRnd;
            UI32 WritePerMPIDn = ((pMmItem->m_nWritePerMPIDn & ~WritePerMPIDn_mask) | (rand & WritePerMPIDn_mask));
            pMmItem->m_nWirtePerMPIDnFix = (WritePerMPIDn << 24);
        }
    }

    /**
    * @brief Random entry for MDP/MIP exception
    * @param IsGM = false: convention mode
    */
    void RandomReserveEntry(bool IsGM, UI32 hbe) {
        // hbe corresponding to hvcfg.hve
        UI32 start_entry = 0, end_entry = 0;
        // rev_idx = 0: Guest managemet
        // rev_idx = 1: Host management
        auto GetReserveEntry = [](std::vector<UI32>* vRandomlist, UI32 rev_idx) -> UI32 {
            UI32 index = 0, mp_idx = 0;
            UI32 reserve_entry = 0;
            // Rom area 
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            g_prf->m_mpcommon[rev_idx] |= (mp_idx << 16);
            reserve_entry |= 1 << mp_idx;
            vRandomlist->erase(vRandomlist->begin() + index);

            // Ram area 
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            g_prf->m_mpcommon[rev_idx] |= mp_idx;
            reserve_entry |= 1 << mp_idx;
            vRandomlist->erase(vRandomlist->begin() + index);

            // MIP
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            g_prf->m_mpdemand[rev_idx] |= (mp_idx << 16);
            reserve_entry |= 1 << mp_idx;
            vRandomlist->erase(vRandomlist->begin() + index);

            // MDP at table reference 
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            g_prf->m_mpdemand[rev_idx] |= (mp_idx << 5);
            reserve_entry |= 1 << mp_idx;
            vRandomlist->erase(vRandomlist->begin() + index);

            // MDP at auto save
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            g_prf->m_mpdemand[rev_idx] |= (mp_idx << 10);
            reserve_entry |= 1 << mp_idx;
            vRandomlist->erase(vRandomlist->begin() + index);

            // MDP at normal case
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            g_prf->m_mpdemand[rev_idx] |= mp_idx;
            reserve_entry |= 1 << mp_idx;
            vRandomlist->erase(vRandomlist->begin() + index);

            return reserve_entry;
        };

        if (IsGM) {
            // about 6, 25 please refer to design document of G4MH2.0 MPU function
            if (hbe >= 6 && hbe <= 26) {
                m_hbe = hbe;
            } else {
                m_hbe = g_rnd.GetRange(6, 26);
            }

            end_entry = m_hbe;
        } else {
            end_entry = g_hwInfo.m_mpnum;   // convention mode
        }
        
        // Get reserve entry for guest management or convention mode
        std::vector<UI32> vRandomlist;
        for (UI32 i = start_entry; i < end_entry; i++) vRandomlist.push_back(i);
        m_reserve_entry |= GetReserveEntry(&vRandomlist, 0);

        // Get reserve entry for Host management;
        if (IsGM) {
            start_entry = m_hbe;
            end_entry = g_hwInfo.m_mpnum;

            vRandomlist.clear();
            for (UI32 i = start_entry; i < end_entry; i++) vRandomlist.push_back(i);
            m_reserve_entry |= GetReserveEntry(&vRandomlist, 1);
        }
    }

    /**
    * @brief Update data for entire entry of MPU
    * @param vRandomlist: list entry will store random setting of user
    */

    void UpdateEntryOfMPU(T_MP_SETTING * mp_table, std::vector<UI32>* vRandomlist, UI32 machineId) {

        UI32 mp_idx = 0, index = 0;
        UI32 common_gm = g_prf->m_mpcommon[0];
        UI32 common_hm = g_prf->m_mpcommon[1];

        // Initialize reserve entry
        // Rom area 
        (*mp_table)[common_gm >> 16][0] = m_CommonRomAdr;
        (*mp_table)[common_gm >> 16][1] = m_CommonRomAdr + m_CommonRomSiz + 1;
        (*mp_table)[common_gm >> 16][2] = 0x000040a4;
        // Ram area 
        (*mp_table)[common_gm & 0xffff][0] = m_CommonRamAdr;
        (*mp_table)[common_gm & 0xffff][1] = m_CommonRamAdr + m_CommonRamSiz + 1;
        (*mp_table)[common_gm & 0xffff][2] = 0x0000c09b;

        // MIP 
        (*mp_table)[g_prf->m_mpdemand[0] >> 16][2] = 0x000040a4;

        if (common_hm) {
            // Rom area 
            (*mp_table)[common_hm >> 16][0] = m_CommonRomAdr;
            (*mp_table)[common_hm >> 16][1] = m_CommonRomAdr + m_CommonRomSiz + 1;
            (*mp_table)[common_hm >> 16][2] = 0x000040a4;
            // Ram area 
            (*mp_table)[common_hm & 0xffff][0] = m_CommonRamAdr;
            (*mp_table)[common_hm & 0xffff][1] = m_CommonRamAdr + m_CommonRamSiz + 1;
            (*mp_table)[common_hm & 0xffff][2] = 0x0000c09b;

            // MIP 
            (*mp_table)[g_prf->m_mpdemand[1] >> 16][2] = 0x000040a4;
        }

        CMmVmAsItem * pMmVmAs = Get(machineId);
        if (pMmVmAs == nullptr) return;
       
        UI32 size = pMmVmAs->Size();
        if (size > vRandomlist->size()) {
            switch (machineId) {
                case  9:    // Convenction Mode
                    break;
                case 8:
                    MSG_WARN(0, "Do not enough entry for user setting host machine \n");
                    break;
                default:
                    MSG_WARN(0, "Do not enough entry for user setting machine %d \n", machineId);
                    break;
            }
        }

        //!・・Store MPLAn, MPUAn, MPATn values of user setting for MPU 
        for (UI32 j = 0; vRandomlist->size() && j < size; j++) {
            index = g_rnd.GetRange((UI32)0, vRandomlist->size() - 1);
            mp_idx = (*vRandomlist)[index];
            CMmItem * pMmItem = pMmVmAs->Get(j);
            (*mp_table)[mp_idx][0] = pMmItem->m_nAddrFix;
            (*mp_table)[mp_idx][1] = pMmItem->m_nAddrFix + pMmItem->m_nSizeFix + 1;
            (*mp_table)[mp_idx][2] = pMmItem->m_nPrivFix | ((pMmItem->m_bValid) ? 0x80 : 0) | pMmItem->m_nRWPerArbSPIDFix | pMmItem->m_nReadPerMPIDnFix | pMmItem->m_nWirtePerMPIDnFix;

            vRandomlist->erase(vRandomlist->begin() + index);
        }
    }

    /**
    * @brief random hbe bit
    * @return value of hbe bit
    */
    UI32 RandomHBE() {
        UI32 min = 0, max = 0, hbe = 0;
        UI32 i = 0;
        // find entry which less than minimum reserve entry of host management
        for (i = m_hbe; i < g_hwInfo.m_mpnum; i++) {
            if (((m_reserve_entry >> i) & 1) != 0) {
                max = i;
                break;
            }
        }
        // find entry which greater maximum reserve entry of guest management
        for (i = m_hbe - 1; i > 0; i--) {
            if (((m_reserve_entry >> i) & 1) != 0) {
                min = i + 1;
                break;
            }
        }

        hbe = g_rnd.GetRange(min, max);
        return hbe;
    }

	/**
	 * @brief Create an MPU setting value table for machineId
     * @param start and end is start and end entry which it will be update.
	 */
    void OutMpuSetting(T_MP_SETTING * mp_table, UI32 machineId, UI32 start_entry, UI32 end_entry) {

        UI32 mp_idx = 0;
        std::vector<UI32> vRandomlist;

        for (mp_idx = start_entry; mp_idx < end_entry; mp_idx++) {
            (*mp_table)[mp_idx][0] = 0;
            (*mp_table)[mp_idx][1] = 0;
            (*mp_table)[mp_idx][2] = 0;
            // find entry which it does not reserve for MPU exception
            // the entry is use to get input from user setting
            if (((m_reserve_entry >> mp_idx) & 1) == 0) {
                vRandomlist.push_back(mp_idx);
            }
        }

        UpdateEntryOfMPU(mp_table, &vRandomlist, machineId);
    }

	/**
	 * @brief	MPU設定情報テーブルの内容を表示する。
	 */
	void MpuDump( T_MP_SETTING * mp_table) {
		CMmVmAsItem * pMmVmAs ;
		CMmItem * pMmItem ;
		std::map<UI32 ,CMmVmAsItem*>::iterator itr1;

		printf("\n") ;
		for (itr1 = m_MmList.begin(); itr1 != m_MmList.end(); itr1++) {
			pMmVmAs= itr1->second ;
			printf("Key= 0x%08x\n" ,itr1->first) ;
			UI32 size= pMmVmAs->Size() ;
			for (UI32 i= 0 ;i < size ;i++ ) {
				pMmItem= pMmVmAs->Get(i) ;
				printf("\t Adr= 0x%08x + 0x%08x = 0x%08x : Siz= 0x%08x + 0x%08x = 0x%08x :Pri= 0x%04x + 0x%04x = 0x%08x : RMDIPn= 0x%08x + 0x%08x = 0x%08x : WMPIDn= 0x%08x + 0x%08x = 0x%08x\n"
					,pMmItem->m_nAddr ,pMmItem->m_nAddrRnd ,pMmItem->m_nAddrFix
					,pMmItem->m_nSize ,pMmItem->m_nSizeRnd ,pMmItem->m_nSizeFix
					,pMmItem->m_nPriv ,pMmItem->m_nPrivRnd ,pMmItem->m_nPrivFix
                    ,pMmItem->m_nReadPerMPIDn, pMmItem->m_nReadPerMPIDnRnd, pMmItem->m_nReadPerMPIDnFix
                    ,pMmItem->m_nWritePerMPIDn, pMmItem->m_nWritePerMPIDnRnd, pMmItem->m_nWirtePerMPIDnFix
				) ;
			}
		}

		printf("\n MPLAn      MPUAn      MPATn    \n");
		for (UI32 i= 0 ;i < g_hwInfo.m_mpnum ;i++ ) {
			printf("0x%08x 0x%08x 0x%08x \n" , (*mp_table)[i][0] ,(*mp_table)[i][1] ,(*mp_table)[i][2]);
		}

        printf("\n HBE: %d \n", m_hbe);

        UI32 j = g_prf->m_mpcommon[0];
        printf("COMMON GUEST: ROM= %d RAM= %d \n", (j >> 16), (j & 0x0FFFF));
        j = g_prf->m_mpdemand[0];
        printf("DEMAND GUEST MANAGEMENT: MIP= %d MDP= %x \n", (j >> 16), (j & 0x0FFFF));

        j = g_prf->m_mpcommon[1];
        printf("COMMON HOST: ROM= %d RAM= %d \n", (j >> 16), (j & 0x0FFFF));
        j = g_prf->m_mpdemand[1];
        printf("DEMAND HOST MANAGEMENT: MIP= %d MDP= %x \n", (j >> 16), (j & 0x0FFFF));       
	}

	/**
	 * @brief  重み設定情報コンテナ中にMMU設定情報があれば、それを元にMMU設定情報テーブルを作成する。
	 * @param  list        MPU設定情報テーブル
	 * @param  pWeightSet  重み設定情報コンテナ
	 * @param  pCfg        シミュレータのプロフィール
	 * @return isSUCCESS
	 * @note 現在ファイル入力は行なっておらず、固定値を登録。
	 */
	bool LoadTlbInfo( CParserTlbList * list , std::map< std::string , CWeightList* > *  pWeightSet) {
		_ASSERT(pWeightSet) ;
		_ASSERT(list) ;
	
		CParserTlbSlot * slot ;
	
		//TODO: 固定値を登録。将来的にはファイル入力を行なう。
		//TODO: 暗黙設定エントリーも固定で入れている。将来的には自動挿入する。
	
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0xfee0003f ,0x40100DED ,0x00000002 ) ; // DemandSlot00
		slot->Set( 0x00000000 ,0xfee0103f ,0x40100DED ,0x00000002 ) ; // DemandSlot01
		slot->Set( 0x00000000 ,0xfee0203f ,0x40100DED ,0x00000002 ) ; // DemandSlot02
		slot->Set( 0x00000000 ,0xfee0303f ,0x40100DED ,0x00000002 ) ; // DemandSlot03
		slot->Set( 0x00000000 ,0xfee0403f ,0x40100DED ,0x00000002 ) ; // DemandSlot04
		slot->Set( 0x00000000 ,0xfee0503f ,0x40100DED ,0x00000002 ) ; // DemandSlot05
		slot->Set( 0x00000000 ,0xfee0603f ,0x40100DED ,0x00000002 ) ; // DemandSlot06
		slot->Set( 0x00000000 ,0xfee0703f ,0x40100DED ,0x00000002 ) ; // DemandSlot07
		list->Set( slot ) ;
		
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0x0000002d ,0xc0100222 ,0x00000008 ) ; // 00: Slot00_McnN_AsGLOB
		slot->Set( 0x00000000 ,0xfea0003f ,0xc0100222 ,0xfea0000b ) ; // 01: Slot00_McnN_AsGLOB
		list->Set( slot ) ;
		
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0xfee1003f ,0x800003FF ,0x70120002 ) ; // 02: Slot00_McnN_As03FF
		slot->Set( 0x10000000 ,0xfee1203f ,0x800003FF ,0x70134002 ) ; // 03: Slot00_McnN_As03FF
		slot->Set( 0x00000000 ,0xfee14024 ,0x800003FF ,0x70138002 ) ; // 04: Slot00_McnN_As03FF
		slot->Set( 0x10000000 ,0xfee16012 ,0x800003FF ,0x7013c002 ) ; // 05: Slot00_McnN_As03FF
		slot->Set( 0x20000000 ,0xfee18009 ,0x800003FF ,0x70140005 ) ; // 06: Slot00_McnN_As03FF
		slot->Set( 0x20000000 ,0xfee1a039 ,0x800003FF ,0x70142002 ) ; // 07: Slot00_McnN_As03FF
		slot->Set( 0x20000000 ,0xfee1c034 ,0x800003FF ,0x70144002 ) ; // 08: Slot00_McnN_As03FF
		slot->Set( 0x20000000 ,0x0004202d ,0x800003FF ,0x60140002 ) ; // XX: Slot00_McnN_As03FF
		slot->Set( 0x10000000 ,0x0004402d ,0x800003FF ,0x60138002 ) ; // XX: Slot00_McnN_As03FF
		slot->Set( 0x20000000 ,0x0004602d ,0x800003FF ,0x60142002 ) ; // XX: Slot00_McnN_As03FF
		slot->Set( 0x10000000 ,0x0004803f ,0x800003FF ,0x6013a002 ) ; // XX: Slot00_McnN_As03FF
		slot->Set( 0x20000000 ,0x0004a03f ,0x800003FF ,0x60146002 ) ; // XX: Slot00_McnN_As03FF
		list->Set( slot ) ;
		
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0xfee2003f ,0x80000000 ,0x90152002 ) ; // 10: Slot01_McnN_As0000
		slot->Set( 0x00000000 ,0xfee2203f ,0x80000000 ,0x90122002 ) ; // 11: Slot01_McnN_As0000
		slot->Set( 0x00000000 ,0xfee2403f ,0x80000000 ,0x90132002 ) ; // 12: Slot01_McnN_As0000
		slot->Set( 0x00000000 ,0xfee2633f ,0x80000000 ,0x90132002 ) ; // 13: Slot01_McnN_As0000
		slot->Set( 0x00000000 ,0xfee2823f ,0x80000000 ,0x90142002 ) ; // 14: Slot01_McnN_As0000
		slot->Set( 0x00000000 ,0xfee2a23f ,0x80000000 ,0x90142002 ) ; // 15: Slot01_McnN_As0000
		list->Set( slot ) ;
		
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0xfee2c03f ,0x80158222 ,0x50152002 ) ; // 14: Slot02_Mcn5_AsGLOB
		slot->Set( 0x00000000 ,0xfee2e03f ,0x80158222 ,0x50122002 ) ; // 15: Slot02_Mcn5_AsGLOB
		slot->Set( 0x00000000 ,0xfee3003f ,0x80158222 ,0x30130002 ) ; // 16: Slot02_Mcn5_AsGLOB
		slot->Set( 0x00000000 ,0xfee3203f ,0x80158222 ,0x30132002 ) ; // 17: Slot02_Mcn5_AsGLOB
		slot->Set( 0x00000000 ,0xfee3403f ,0x80158222 ,0x30134002 ) ; // 18: Slot02_Mcn5_AsGLOB
		slot->Set( 0x00000000 ,0xfee2603f ,0x80158222 ,0x30136002 ) ; // 19: Slot02_Mcn5_AsGLOB
		list->Set( slot ) ;
		
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0xfee4003f ,0x80000111 ,0x0f551002 ) ; // 20: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee4203f ,0x80000111 ,0x0f552002 ) ; // 21: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee4403f ,0x80000111 ,0x0f553002 ) ; // 22: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee4603f ,0x80000111 ,0x0f554002 ) ; // 23: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee4803f ,0x80000111 ,0x0f555002 ) ; // 24: Slot03_McnN_AsRndm
		list->Set( slot ) ;
		
		slot= new CParserTlbSlot() ;
		//         TELO1      ,TELO0      ,TEHI1      ,TEHI0      
		slot->Set( 0x00000000 ,0xfee5003f ,0x80000133 ,0x0f556002 ) ; // 25: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee5203f ,0x80000123 ,0x0f557002 ) ; // 26: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee5403f ,0x80000123 ,0x0f558002 ) ; // 27: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee5803f ,0x80000123 ,0x0f559002 ) ; // 28: Slot03_McnN_AsRndm
		slot->Set( 0x00000000 ,0xfee5c03f ,0x80000123 ,0x0f55a002 ) ; // 29: Slot03_McnN_AsRndm
		list->Set( slot ) ;
	
		return (true) ;
	}


	bool LoadMpuInfo() {
	//!<BR>[処理細目]<BR>

        UI32 machine;
        UI32 val1, val2, val3, val4, priv, mask, valid;
        UI32 RWPerArbSPID = 0, RWPerArbSPID_mask = 0x0003;
        UI32 ReadPerArbMPIDn = 0, ReadPerArbMPIDn_mask = 0x000f;
        UI32 WritePerArbMPIDn = 0, WritePerArbMPIDn_mask = 0x000f;
        bool global;

        CGeneratorProfile::SectionData sd;
        CGeneratorProfile::SectionData::iterator sdi;

        sd = g_prf->GetSectionData("::MXU_COMMON_AREA");
        if (sd.size() != 0) {
            sdi = sd.begin();
         	if ((*sdi).size() <  4) {
        	    MSG_ERROR(0, "\"::MXU_COMMON_AREA\" is number of parameters is small.\n");
        	    return ( false ) ;
        	}
        	try {
        		//!・・・共通ROM領域設定を数値に変換しMMU/MPU設定情報オブジェクトに登録。
        		m_CommonRomAdr= (CToolFnc::AtoI((*sdi)[0].c_str())) ;
        		m_CommonRomSiz= (CToolFnc::AtoI((*sdi)[1].c_str())) ;
        		m_CommonRamAdr= (CToolFnc::AtoI((*sdi)[2].c_str())) ;
        		m_CommonRamSiz= (CToolFnc::AtoI((*sdi)[3].c_str())) ;
        	} catch (std::invalid_argument) {
        		//!・・・▽数値に変換できない文字列だった場合は異常リターン。
        		MSG_ERROR(0, "Illigal \"::MXU_COMMON_AREA\" Setting  (Not Number) .\n");
        		return ( false ) ;
        	}
            if (m_CommonRomSiz == 0) {
                MSG_ERROR(0, "Illigal \"::MXU_COMMON_AREA\" Setting  (RomSize is 0) .\n");
        		return ( false ) ;
            }
            if (m_CommonRamSiz == 0) {
                MSG_ERROR(0, "Illigal \"::MXU_COMMON_AREA\" Setting  (RamSize is 0) .\n");
        		return ( false ) ;
            }
        }

	    sd = g_prf->GetSectionData("::MPU_SETTING");

      	if (sd.size() != 0 && m_CommonRomSiz == 0) {
       	    MSG_ERROR(0, "::MXU_COMMON_AREA is not found in weight file.\n");
       	    return ( false ) ;
       	}
	    for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
            UI32 params = (*sdi).size();
    		if(params < 1) {
    			MSG_ERROR(0, "\"::MPU_SETTING\" is number of parameters is small.\n");
    			return ( false ) ;
    		}
            //============================
            //!・・Capture machine number
            //============================
            if ((*sdi)[0] == "CV") {
                UI32 init_hvcfg = g_srs->GetNcInit(16, 1);
                if ((init_hvcfg && 0x1) != 0) {
                    MSG_ERROR(0, "Do not set MPU Setting (machine: \"%s\") when HVCFG.HVE = 1 .\n", (*sdi)[0].c_str());
                    return (false);
                }
                machine = CONVENTION_ENTRY;
            } else if ((*sdi)[0].compare(0, 3, "GM#", 3) == 0) {
                //!・・Convert machine number specification from character string to numerical value. 
                //!. . In case of a character string which can not be converted, an abnormal return is returned if it is omitted or if it is specified exceeding the number of mounted GMs.
                try {
                    machine = CToolFnc::AtoI((*sdi)[0].c_str() + 3);
                } catch (std::invalid_argument) {
                    MSG_ERROR(0, "Illigal MPU Setting (machine: \"%s\") in weight file line %d .\n", (*sdi)[0].c_str(), 0);
                    return (false);
                }
                if (machine >= g_hwInfo.m_gmnum) {
                    MSG_ERROR(0, "Illigal MPU Setting (machine: \"%d\") in weight file line %d .\n", machine, 0);
                    return (false);
                }
            } else if ((*sdi)[0] == "HM") {
                machine = HOST_ENTRY;

            } else if ((*sdi)[0] == "") {
                UI32 index = g_rnd.GetRange((UI32)0, g_cfg->m_mGMs.size());
               
                if (index == g_cfg->m_mGMs.size()) {
                    machine = HOST_ENTRY;
                } else {
                    auto gm_itr = g_cfg->m_mGMs.begin();
                    std::advance(gm_itr, index);
                    machine = gm_itr->first;
                }
            } else {
                MSG_ERROR(0, "Illigal MPU Setting (machine: \"%d\") in weight file line %d .\n", (*sdi)[0].c_str(), 0);
                return (false);
            }

            CMmVmAsItem * pMmVmAs = this->Set(machine);
 
            //================================
    		//!・・VALID指定の取り込み
            //================================
			//!・・・▽パラメータを文字列から数値に変換。変換できない文字列の場合は異常リターン。
    		if ((params < 2)||((*sdi)[1] == "minimum")||((*sdi)[1] == "")) {
                continue;
     		}
     		if ((*sdi)[1] == "enable") {
                valid = true;
    		}
            else
            if ((*sdi)[1] == "disable") {
                valid = false;
    		} else {
   				//!・・▽異常リターン。
   				MSG_ERROR(0, "Illigal MPU Setting (VALID: \"%s\") in weight file line %d .\n", (*sdi)[1].c_str(), 0);
   				return ( false ) ;
    		}

            //===============================================
			//!・・メモリ保護領域アドレス（固定部＋乱数部）の取得
            //===============================================
    		if(params < 3) {
				val1= 0 ;
    		}
            else
     		if((*sdi)[2] == "") {
    			val1= 0 ;
    		} else {
    			try {
    				val1= CToolFnc::AtoI((*sdi)[2].c_str()) ;
    			} catch (std::invalid_argument) {
    				MSG_ERROR(0, "Illigal MPU Setting (Not Number) -->\"%s\" in weight file line %d .\n", (*sdi)[2].c_str(), 0);
    				return ( false ) ;
    			}
            }
        	if(params < 4) {
        		val2= 0 ;
    		}
            else
     		if((*sdi)[3] == "") {
    			val2= 0 ;
       		} else {
    			try {
    				val2= CToolFnc::AtoI((*sdi)[3].c_str()) ;
    			} catch (std::invalid_argument) {
    				MSG_ERROR(0, "Illigal MPU Setting (Not Number) -->\"%s\" in weight file line %d .\n", (*sdi)[3].c_str(), 0);
    				return ( false ) ;
    			}
            }

            //==============================================
			//!・・メモリ保護領域サイズ（固定部＋乱数部）の取得
            //==============================================
   		    if(params < 5) {
				val3= 0 ;
    		}
            else
     		if((*sdi)[4] == "") {
    			val3= 0 ;
    		} else {
			    try {
			    	val3= CToolFnc::AtoI((*sdi)[4].c_str()) ;
			    } catch (std::invalid_argument) {
			    	MSG_ERROR(0, "Illigal MPU Setting (Not Number) -->\"%s\" in weight file line %d .\n", (*sdi)[4].c_str(), 0);
			    	return ( false ) ;
			    }
            }
   		    if(params < 6) {
				val4= 0 ;
    		}
            else
     		if((*sdi)[5] == "") {
    			val4= 0 ;
    		} else {
			    try {
					val4= CToolFnc::AtoI((*sdi)[5].c_str()) ;
			    } catch (std::invalid_argument) {
			    	MSG_ERROR(0, "Illigal MPU Setting (Not Number) -->\"%s\" in weight file line %d .\n", (*sdi)[5].c_str(), 0);
			    	return ( false ) ;
			    }
            }

            //===================================================================================
			//!・・・▽グローバルアドレス空間ビット 指定が０，１のどちらでもなかった場合は異常リターン。
            //===================================================================================

			global= false ;
			if(params < 7) {
			    RWPerArbSPID = 0 ;
				RWPerArbSPID_mask = 0x0003;
			} else {	
				if ((*sdi)[6] == "") {
					RWPerArbSPID = 0;
					RWPerArbSPID_mask = 0x0003;
    			} else {
 					if ((*sdi)[6].size() != 2) {
						MSG_ERROR(0, "Illigal MPU Setting (RG/WG) -->\"%s\" in weight file line %d .\n", (*sdi)[6].c_str() , 0);
						return ( false ) ;
					} else {
    					//!・・・Convert access rights specified from a string to a fixed value and the random number mask value.。In 2 characters "0", "1", the abnormal return if "x" than was used。
    					LPCTSTR s= (*sdi)[6].c_str() ;
    					RWPerArbSPID = 0 ;
    					RWPerArbSPID_mask = 0 ;
    					for (UI32 i= 0 ;i < 2 ;i++ ) {
    						RWPerArbSPID <<= 1 ;
    						RWPerArbSPID_mask <<= 1 ;
    						if ((*s == 'x')||(*s == 'X')) {
    							RWPerArbSPID_mask |= 1 ;
    						}
    						else
    						if (*s == '1') {
    							RWPerArbSPID |= 1;
    						}
    						else
    						if (*s == '0') {
    							;
    						}
    						else {
    							MSG_ERROR(0, "Illigal MPU Setting (Privilege) -->\"%s\" in weight file line %d .\n", (*sdi)[6].c_str(), 0);
    							return ( false ) ;
    						}
    						s++ ;
    					}	
					}
				}
			}

            //======================================================
			//!・・・▽アクセス権 指定の取得
            //======================================================
			//!・・・▽アクセス権 指定が６文字でなかった場合は異常リターン。
   		    if(params < 8) {
			    priv= 0 ;
			    mask= 0x3f ;
			}
            else
    		if ((*sdi)[7] == "") {
			    priv= 0 ;
			    mask= 0x3f ;
    		}
            else
 			if ((*sdi)[7].size() != 6) {
				MSG_ERROR(0, "Illigal MPU Setting (Privilege) -->\"%s\" in weight file line %d .\n", (*sdi)[7].c_str() , 0);
				return ( false ) ;
			} else {
    			//!・・・▽アクセス権 指定を文字列から固定値と乱数マスク値に変換。６文字中で"0","1","x" 以外が使われた場合は異常リターン。
    			LPCTSTR s= (*sdi)[7].c_str() ;
    			priv= 0 ;
    			mask= 0 ;
    			for (UI32 i= 0 ;i < 6 ;i++ ){
    				priv <<= 1 ;
    				mask <<= 1 ;
    				if ((*s == 'x')||(*s == 'X')) {
    					mask |= 1 ;
    				}
    				else
    				if (*s == '1') {
    					priv |= 1;
    				}
    				else
    				if (*s == '0') {
    					;
    				}
    				else {
    					MSG_ERROR(0, "Illigal MPU Setting (Privilege) -->\"%s\" in weight file line %d .\n", (*sdi)[7].c_str(), 0);
    					return ( false ) ;
    				}
    				s++ ;
    			}
            }

			//======================================================
			//!・・・Parse input field RMPIDn
            //======================================================
			const UI32 ReadPerArbMPIDn_size = 8; // size of RMPIn field.
			if(params < 9) {
			    ReadPerArbMPIDn = 0 ;
				ReadPerArbMPIDn_mask = 0x000f;
			} else {	
				if ((*sdi)[8] == "") {
					ReadPerArbMPIDn = 0;
					ReadPerArbMPIDn_mask = 0x000f;
    			} else {
 					if ((*sdi)[8].size() != ReadPerArbMPIDn_size) {
						MSG_ERROR(0, "Illigal MPU Setting (RG/WG) -->\"%s\" in weight file line %d .\n", (*sdi)[8].c_str() , 0);
						return ( false ) ;
					} else {
    					//!・・・Convert access rights specified from a string to a fixed value and the random number mask value.。In 2 characters "0", "1", the abnormal return if "x" than was used。
    					LPCTSTR s= (*sdi)[8].c_str() ;
    					ReadPerArbMPIDn = 0 ;
    					ReadPerArbMPIDn_mask = 0 ;
    					for (UI32 i= 0 ;i < ReadPerArbMPIDn_size ;i++ ) {
    						ReadPerArbMPIDn <<= 1 ;
    						ReadPerArbMPIDn_mask <<= 1 ;
    						if ((*s == 'x')||(*s == 'X')) {
    							ReadPerArbMPIDn_mask |= 1 ;
    						}
    						else
    						if (*s == '1') {
    							ReadPerArbMPIDn |= 1;
    						}
    						else
    						if (*s == '0') {
    							;
    						}
    						else {
    							MSG_ERROR(0, "Illigal MPU Setting (Privilege) -->\"%s\" in weight file line %d .\n", (*sdi)[8].c_str(), 0);
    							return ( false ) ;
    						}
    						s++ ;
    					}	
					}
				}
			}
			//======================================================
			//!・・・Parse input field WMPIDn
            //======================================================
			const UI32 WritePerArbMPIDn_size = 8; // size of RMPIn field.
			if(params < 10) {
			    WritePerArbMPIDn = 0 ;
				WritePerArbMPIDn_mask = 0x000f;
			} else {	
				if ((*sdi)[9] == "") {
					WritePerArbMPIDn = 0;
					WritePerArbMPIDn_mask = 0x000f;
    			} else {
 					if ((*sdi)[9].size() != WritePerArbMPIDn_size) {
						MSG_ERROR(0, "Illigal MPU Setting (RG/WG) -->\"%s\" in weight file line %d .\n", (*sdi)[9].c_str() , 0);
						return ( false ) ;
					} else {
    					//!・・・Convert access rights specified from a string to a fixed value and the random number mask value.。In 2 characters "0", "1", the abnormal return if "x" than was used。
    					LPCTSTR s= (*sdi)[9].c_str() ;
    					WritePerArbMPIDn = 0 ;
    					WritePerArbMPIDn_mask = 0 ;
    					for (UI32 i= 0 ;i < WritePerArbMPIDn_size ;i++ ) {
    						WritePerArbMPIDn <<= 1 ;
    						WritePerArbMPIDn_mask <<= 1 ;
    						if ((*s == 'x')||(*s == 'X')) {
    							WritePerArbMPIDn_mask |= 1 ;
    						}
    						else
    						if (*s == '1') {
    							WritePerArbMPIDn |= 1;
    						}
    						else
    						if (*s == '0') {
    							;
    						}
    						else {
    							MSG_ERROR(0, "Illigal MPU Setting (Privilege) -->\"%s\" in weight file line %d .\n", (*sdi)[9].c_str(), 0);
    							return ( false ) ;
    						}
    						s++ ;
    					}	
					}
				}
			}
            //======================================================
			//!・・・▽領域設定の登録
            //======================================================
            pMmVmAs->Set(val1 , val2 , val3 , val4 , priv, mask ,RWPerArbSPID, RWPerArbSPID_mask, ReadPerArbMPIDn, ReadPerArbMPIDn_mask, WritePerArbMPIDn, WritePerArbMPIDn_mask, valid , global);
			//if(val2 == 0 && val4 == 0 && (mask & 0x1b) == 0 && valid == true) { // Do not randomize and valid
			//	if((priv >> 3) == (priv & 0x7)){ // The config for SV and UM is same
			//		MEMRANGE r(val1, val1 + val3);
			//		g_FixedMPU.push_back(std::make_pair(machine, r));
			//	}
			//}
        }
		return ( true ) ;
    }


protected:
	std::map<UI32, CMmVmAsItem*> m_MmList;	//!< キーの上位１６ビットがＶＭ番号、下位１６ビットがアドレス空間ID
	UI32 m_CommonRomAdr ;						//!< MPU:共通ROM領域先頭アドレス
	UI32 m_CommonRomSiz ;						//!< MPU:共通ROM領域サイズ
	UI32 m_CommonRamAdr ;						//!< MPU:共通RAM領域先頭アドレス　／　MMU:物理メモリプール・開始アドレス
	UI32 m_CommonRamSiz ;						//!< MPU:共通RAM領域サイズ　　　　／　MMU:物理メモリプール・サイズ
    UI32 m_hbe;                                 //! GMMPCFG.HBE
    UI32 m_reserve_entry;                     //! control 32 entry of MPU. if bit index equal 1, entry index is used as reserve entry
};


#endif /*MXU_PARSER_H_*/
