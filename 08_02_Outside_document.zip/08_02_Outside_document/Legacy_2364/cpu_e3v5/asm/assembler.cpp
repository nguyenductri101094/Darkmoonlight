#include	"assembler.h"

//namespace _RTG_APP_CPU_ISA_ {
	
CAssembler::CAssembler() {
}

CAssembler::~CAssembler() {
}

void CAssembler::Init(IASM_ENDIAN param) {
	libccg_init(param);
}

UI32 CAssembler::Asm(LPCTSTR str, UI64* opecode) {
	params_t	t;
	UI32		addr = 0;
	UI32 len = libccg_assemble_insn(str, (uint64_t*)opecode, &t, (uint32_t)addr);
	return len;
}

UI32 CAssembler::Disasm(LPSTR str, UI64 opecode) {
	if (libccg_disasm_insn (opecode, str, 0 ) == 0) {
		return -1;
	}
	return 0;
}
//}
