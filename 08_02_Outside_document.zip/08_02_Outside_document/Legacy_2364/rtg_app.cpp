#include    <thread>
#include    <future>
#include    <condition_variable>
#include <sys/resource.h>
#include    <mutex>
#include    "usr_src.h"
#include	"rtg_cfg.h"
#include	"ifinstruction.h"
#include	"ifinsset.h"
#include	"ifexception.h"
#include	"weight_parser.h"
#include	"ifblk_manager.h"
#include	"codeblock.h"
#include	"assembler.h"
#include	"asm_src.h"
#include	"linker.h"
#include	"ifsim_ctrl.h"
#include	"ifvalconstraint.h"
#include	"insid_set.h"
#include	"ifsysreg.h"
#include	"sim_res.h"

#define     STACK_SIZE  8*1024*1024

std::shared_ptr<CGeneratorConfig>		g_cfg;			 
std::shared_ptr<CGeneratorProfile>		g_prf;			 
std::shared_ptr<CGeneratorProfile>		g_uprf;
std::unique_ptr<IAssembler>				g_asm;			
std::unique_ptr<ISysRegSet>				g_srs;			 
std::shared_ptr<CAssemblerSourceFile>	g_asf;			 
std::unique_ptr<IException>             g_exp;			//!< @brief 例外関連を管理するクラス
std::unique_ptr<IBlockManager>			g_mgr;			 
std::unique_ptr<ISimulatorControl>		g_sim;			 

ISimulatorHwInfo						g_hwInfo;		
CAddressWeight							g_LoadableAddr;	 
CAddressWeight							g_StorableAddr;	
CAddressWeight							g_FetchAddr;	
CAddressWeight							g_RmwAddr;		
CAddressWeight							g_LnkBitAddr;	
CAddressWeight							g_LoadableLnkAddr;
CAddressWeight							g_StorableLnkAddr;
CAddressWeight							g_RmwLnkAddr;
CAddressWeight							g_ExceptionAddr;
CAddressWeight							g_RegisterBankAddr;
CBitWeight  							g_FlagAddr;		  
TWorkMemory								g_wm;			//!< @brief	パタンファイルが使用するワークエリアを定義
std::vector<std::pair<UI32, MEMRANGE>>  g_FixedMPU;

static int	frog_init (int, char**);					//!< @brief	設定ファイルを解析し、生成に必要なデータの準備、初期化を行う
static int	frog_main (void);							//!< @brief	パタンファイルの生成処理
static int	set_address_weight(void);					//!< @brief	メモリアドレスの情報を準備するサブルーチン
static int  set_bit_weight(void);
static int	set_user_profile(void);
static int	genarate_main(void);						//!< @brief	生成処理
static int	simulate_main(void);						//!< @brief	シミュレーション処理
static int	post_simulation (void);						//!< @brief	シミュレーション後処理
static int	output_result(void);						//!< @brief	出力処理
static int	show_report(clock_t t);						//!< @brief	生成情報の表示
static int  check_error(void);

static int	gen_pe_context(TBlockConfig* tbc);			
static int	gen_machine_context(TBlockConfig* tbc);		
static int	gen_thread_context(TBlockConfig* tbc);		
static void *frog_thread(void *p);

std::string CLabel::m_prefix("frog_P00");				//!< @brief TODO : 定義位置

std::shared_ptr<CUserSourceFile>		g_usf;
struct thread_param {
    int argc;
    char **argv;
    int ret;
    std::condition_variable *pcvInit;
    std::condition_variable *pcvFinish;
};

/**
 * app main
 * 
 */
int main (int argc, char** argv) {
    std::condition_variable         cvInit;
    std::mutex                      mtxInit;
    std::unique_lock<std::mutex>    lckInit(mtxInit);
    std::condition_variable         cvFinish;
    std::mutex                      mtxFinish;
    std::unique_lock<std::mutex>    lckFinish(mtxFinish);

    // Initialize thread params
    thread_param param;
    void *thread_status;
    param.argc = argc;
    param.argv = argv;
    param.pcvInit = &cvInit;
    param.pcvFinish = &cvFinish;
    param.ret = EXIT_SUCCESS;

    // Create thread of FROG generation
    pthread_attr_t attr;
    pthread_t threadId;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
    if(pthread_attr_setstacksize(&attr, STACK_SIZE) != 0) {
        MSG_ERROR(0, "Can not set stacksize for FROG generation thread.\n");
    }
    if(pthread_create(&threadId, &attr, frog_thread, (void*) &param) != 0) {
        MSG_ERROR(0, "Can not create FROG generation thread.\n");
    }

    // Waiting for FROG initialization, then, g_cfg->m_nTimeout was valid
    // At this time, g_cfg->m_TimeOut was not valid. So, the timeout is TIMEOUT
    if(cvInit.wait_for(lckInit, std::chrono::seconds(TIMEOUT)) == std::cv_status::timeout) {
        MSG_ERROR(0, "FROG initialization was timeout.\n");
        exit(EXIT_FAILURE);     // Exit process and terminate async thread
    }
    
    // Waiting for FROG executing with timeout
    if(cvFinish.wait_for(lckFinish, std::chrono::seconds(g_cfg->m_nTimeout)) == std::cv_status::timeout) {
        MSG_ERROR(0, "FROG generation was timeout.\n");
        exit(EXIT_FAILURE);     // Exit process and terminate async thread
    }

    // free attribute and wait for the other threads
    pthread_attr_destroy(&attr);
    pthread_join(threadId, &thread_status);

    // Get return code, then return
    return param.ret;	
}

static void *frog_thread(void *p) {
    int		retCode		= EXIT_SUCCESS;
    clock_t		tm_start	= clock();
    thread_param *pParam = (thread_param *)p;
    do {
        if ((retCode = frog_init(pParam->argc, pParam->argv)) != EXIT_SUCCESS) {
		    break;
        }
        pParam->pcvInit->notify_one();

        if ((retCode = frog_main()) != EXIT_SUCCESS) {
            break;
        }

        if ((retCode = show_report(tm_start)) != EXIT_SUCCESS) {
            break;
        }

        // Check error
        if ((retCode = check_error())!= EXIT_SUCCESS) {
            break;
        }
    } while(0);

    pParam->ret = retCode;
    pParam->pcvFinish->notify_one();

    pthread_exit(NULL);
}

/**
 * setup app
 * 
 */
static int frog_init (int argc, char** argv)
{
	// user source file
	g_usf = std::make_shared<CUserSourceFile>();
	
	// parse command line parameters.
	g_cfg = std::make_shared<CGeneratorConfig>();
	if (g_cfg->Parse(argc, argv) != true) {
		return (EXIT_FAILURE);
	}
	
	// parse user profile
	g_uprf = std::make_shared<CGeneratorProfile>();
	if (g_uprf->LoadProfile(g_cfg->m_strUserProfile) != true) {
		return (EXIT_FAILURE);
	}

	// parse master configuration files
	if (g_uprf->LoadMasterFile() != true) {
		return (EXIT_FAILURE);
	}

	// parse profile
	g_prf = std::make_shared<CGeneratorProfile>();
	if (g_prf->LoadProfile(g_cfg->m_strProfile) != true) {
		return (EXIT_FAILURE);
	}

	// overwirte user's profile
	if (set_user_profile() != EXIT_SUCCESS) {
		return (EXIT_FAILURE);
	}

	// set seed
	g_rnd.Seed(&g_cfg->m_nSeed);
	g_cfg->RenameOutfile();	
	
	// create output-file
	g_asf = std::make_shared<CAssemblerSourceFile>();

	// initialize assembler
	std::unique_ptr<IAssembler> u_asm(IAssembler::New());
	g_asm = std::move(u_asm);
	g_asm->Init(IAssembler::IASM_LITTLE);

	// weight - meory access 
	if (set_address_weight() != 0 ||
		set_bit_weight() != 0) {
		return (EXIT_FAILURE);
	}

	g_asf->SetAvailableAddress(g_FetchAddr.KeySet(), CLinker::MEM_FREE_ALLOC);
	g_asf->SetAvailableAddress(g_ExceptionAddr.KeySet(), CLinker::MEM_USER_ALLOC);

	// weight - system register
	std::unique_ptr<ISysRegSet> u_srs(ISysRegSet::New());
	g_srs = std::move(u_srs);
	if (g_srs-> ParseCsv(g_cfg->m_strSrProfile) != true) {
		return (EXIT_FAILURE);
	}
	
	COprSR::m_pSrSource = g_srs.get();
	
	// weight - exception raise
	std::unique_ptr<IException> u_exp(IException::New());
	g_exp = std::move(u_exp);  
	g_exp->SetWeight(g_prf->GetSectionData("::EXCEPTION_GLOBAL"));
	g_exp->SetWeight(g_prf->GetSectionData("::BREAK_GLOBAL"));
	
	// weight - fpu data type
	g_prf->ConfigFpuSingletype();
	g_prf->ConfigFpuDoubletype();
	
	// initialize source-file & linker
	std::unique_ptr<IBlockManager> u_mgr(IBlockManager::New(nullptr));
	g_mgr = std::move(u_mgr);

	// check simulator initialize file
	if(g_cfg->m_strSimIni.length() == 0) {
		MSG_ERROR(0, "--sim_ini_file (file path) is mandatory.\n");
		return (EXIT_FAILURE);
	}

 	// initialize iss
 	std::unique_ptr<ISimulatorControl> u_sim(ISimulatorControl::New());
 	g_sim = std::move(u_sim);
	if(g_sim->Init(g_cfg->m_strSimIni) != true){
		return (EXIT_FAILURE);
	}
	g_sim->GetHwSpecification(&g_hwInfo);
	g_wm.SetMachine(g_hwInfo.m_htnum, g_hwInfo.m_vmnum);

	if (g_prf->ParseMachineSetting(&g_cfg->m_mGMs) != true) {
		return (EXIT_FAILURE);
	}

    // Load MPU information
    CMmList* mpu_infor = g_mgr->GetMPUInfor();
    if (mpu_infor->LoadMpuInfo() == false) {
        return (EXIT_FAILURE);
    }

	return (EXIT_SUCCESS);
}


/**
 * frog_main
 * 
 */
static int frog_main ()
{
	// generation
	if (genarate_main()) {
		return (EXIT_FAILURE);
	}

	// simulation
	if (simulate_main()) {
		return (EXIT_FAILURE);
	}
	
	// initial-val, prefetch, verify-code
	if (post_simulation()) {
		return (EXIT_FAILURE);	
	}

	// result
	if (output_result()) {
		return (EXIT_FAILURE);
	}

	return (EXIT_SUCCESS);
}

	
static int genarate_main() {

	TBlockConfig tbc;
	tbc.InsNum	= g_cfg->m_nINumInBlock;
	tbc.m_pSrSet= g_srs.get();
	tbc.m_bNC	= true;

	MSG_INFO(0, "Generate start by seed %08x.\n", g_cfg->m_nSeed);

    if (g_cfg->m_mGMs.size()) {
        tbc.m_bGM = true;
        // default FROG run first GM in machine setting
        tbc.m_GMID = g_cfg->m_mGMs.begin()->first;
    }

	// System Context
	gen_pe_context (&tbc);
	
	// Native Context
	gen_machine_context(&tbc);	// (NM + NT)
	
	if (g_prf->IsVmSimulation()) {
		
		// Virtual Context
		tbc.m_bNC = false;
		for (tbc.m_VCID = 0, tbc.m_HTID = 0; tbc.m_VCID < 1; tbc.m_VCID++) {
			
			gen_machine_context(&tbc);
			
			// Hardware Thread
			for (tbc.m_HTID = 0/* Base + 1 */; (false); tbc.m_HTID++) {
				gen_thread_context(&tbc);
			}
		}
	}

	if (g_asf->Link() != true) {
		MSG_ERROR(0, "Link Error!\n");
		return (EXIT_FAILURE);
	}

	// Update original code size of block for simulation
	std::vector<INode*>& rRcb = g_asf->GetCodeBlock();
	std::for_each (rRcb.begin(), rRcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	// Update original code size for preload code block
	std::vector<INode*>& rPcb = g_asf->GetPreloadBlock();
	std::for_each (rPcb.begin(), rPcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	// Update original code size for handler code block
	std::vector<INode*>& rHcb = g_asf->GetHandlerBlock();
	std::for_each (rHcb.begin(), rHcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	// Update original code size for terminate code block
	std::vector<INode*>& rTcb = g_asf->GetTerminateBlock();
	std::for_each (rTcb.begin(), rTcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	if (g_cfg->m_bVerbose) {
		std::ofstream ofs;
		ofs.open("label.gen");
		g_asf->PrintLabel(ofs);
		ofs.close();
	}

	return (EXIT_SUCCESS);
}


/**
 * PE　proc
 */
static int gen_pe_context (TBlockConfig* tbc) {
	
    char work[32];
    sprintf(work, "P%02d", g_cfg->m_nPeId);

	tbc->m_bSys = true;
	
	// System Reset vector
	VectorPtr 		v_ptr  (g_mgr->GenerateIntVector(tbc));
	frog::for_each( v_ptr, [] (CVectorBlock* p) {g_asf->AddNode(p);} );
	
	UserPtr         u_ptr  (g_mgr->InsertUserCode(work , "uc_boot" , tbc, v_ptr->front()));
	frog::for_each( u_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
	
	tbc->m_bSys = false;
	
	return (EXIT_SUCCESS);
}


/**
 * MACHINE　CODE
 */
static int gen_machine_context (TBlockConfig* tbc) {
	
    char work[32];
	if (tbc->m_bNC == true) {
        sprintf(work, "P%02dNM", g_cfg->m_nPeId);
    } else {

		sprintf(work, "P%02dGM%02d", g_cfg->m_nPeId, tbc->m_GMID);

	}

	bool vmsim = g_prf->IsVmSimulation();

	VectorPtr 		v_ptr  (g_mgr->GenerateIntVector(tbc));
	frog::for_each( v_ptr, [] (CVectorBlock* p) {g_asf->AddNode(p);} );
	
	HandlerPtr		h_ptr  (g_mgr->GenerateHandler(tbc));
	frog::for_each( h_ptr, [] (CHandlerBlock* p) {g_asf->AddNode(p);} );

	HandlerPtr h_fix_ptr  (g_mgr->GenerateFixHandlerBlock(tbc));
	frog::for_each( h_fix_ptr, [] (CHandlerBlock* p) {g_asf->AddNode(p);} );

	// Gen table refernce for GMINTBP
	tbc->m_bNC = false;
	tbc->m_VCID = 0;
	VectorPtr 		GM_v_ptr  (g_mgr->GenerateIntVector(tbc));
	frog::for_each( GM_v_ptr, [] (CVectorBlock* p) {g_asf->AddNode(p);	} );

	HandlerPtr GM_h_ptr  (g_mgr->GenerateHandler(tbc));
	frog::for_each( GM_h_ptr, [] (CHandlerBlock* p) {g_asf->AddNode(p);} );

	tbc->m_bNC = true;
	
	if (tbc->m_bNC) {
		PreloadPtr		l_ptr  (g_mgr->GeneratePreload(tbc));
		frog::for_each( l_ptr, [] (CPreloadBlock* p) {g_asf->AddNode(p);} );
		UserPtr         u_ptr  (g_mgr->InsertUserCode(work , "uc_preload" , tbc, l_ptr->front()));
		frog::for_each( u_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
	}

	ProloguePtr		p_ptr  (g_mgr->GeneratePrologue(tbc));
	frog::for_each( p_ptr, [] (CPrologueBlock* p) {g_asf->AddNode(p);} );

	EpiloguePtr		e_ptr  (g_mgr->GenerateEpilogue(tbc));
	frog::for_each( e_ptr, [] (CEpilogueBlock* p) {g_asf->AddNode(p);} );
	
	if (tbc->m_bNC) {
	    UserPtr         c_ptr  (g_mgr->InsertUserCode(work, "uc_selfcheck_fail" , tbc, e_ptr->back()));
	    frog::for_each( c_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
	}
	
	TerminatePtr	t_ptr  (g_mgr->GenerateTerminateBlock(tbc));
    frog::for_each( t_ptr, [] (CTerminateBlock* p) {g_asf->AddNode(p);} );

	if (tbc->m_bNC) {
	    UserPtr         c_ptr  (g_mgr->InsertUserCode(work, "uc_terminate" , tbc, t_ptr->front()));
	    frog::for_each( c_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
    }

	if ((vmsim != true) || (tbc->m_bNC != true)) {
		tbc->m_bBase = true;
		gen_thread_context(tbc);
	}else{
		// VMSimするときのNT(Random Codeblock)は実質ブランクである
		// VM遷移しVM Randomが終わればHVTRAPでNMode復帰、このとき復帰先はNM::Epilogueである
		g_mgr->ChainBlock(p_ptr->back(), e_ptr->front());
	}
	
    FunctionPtr		f_ptr(g_mgr->GenerateFunction(tbc));
    frog::for_each(f_ptr, [](CFunctionBlock* p) {g_asf->AddNode(p); });

	PreloadPtr		l_ptr  (g_mgr->GenerateSetupBlock(tbc));
	frog::for_each( l_ptr, [] (CPreloadBlock* p) {g_asf->AddNode(p);} );
	return (EXIT_SUCCESS);
}


/**
 * Thread　proc
 */
static int gen_thread_context (TBlockConfig* tbc) {
	
    char work[32];
	if (tbc->m_bNC == true) {
        sprintf(work, "P%02dNMNT", g_cfg->m_nPeId);
    } else {
        sprintf(work, "P%02dV%02dT%02d", g_cfg->m_nPeId, tbc->m_VCID, tbc->m_HTID);
	}

	// gerarate code for synchronized
	SyncPtr s_ptr(g_mgr->GenerateSync(tbc));
	frog::for_each(s_ptr, [] (CSyncBlock* p) { g_asf->AddNode(p); } );

	UserPtr u_ptr  (g_mgr->InsertUserCode(work , "uc_ht_standby" , tbc, s_ptr->front()));
	frog::for_each( u_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );

	// gerarate code for random test
	RandomPtr r_ptr(new RandomSet());
	for (tbc->N = 0; (tbc->N) < (g_cfg->m_nBlockNum); tbc->N++) {
		CCodeBlock* RandomBlock = g_mgr->GenerateRandomBlock(tbc);
		if(tbc->N == 0)
			RandomBlock->AddOpeCode(DBTAG(), 0); //! Mark it as the start of random block #Redmine#65750
		r_ptr->push_back(RandomBlock);
		g_mgr->PresetException(r_ptr->back(), g_exp.get());
	}
	
	// chaining each random block
	RandomSet::iterator i1 = r_ptr->begin();
	RandomSet::iterator i2 = r_ptr->begin();
	while ( ++i2 != r_ptr->end() ) {
		g_mgr->ChainBlock((*i1), (*i2));
		++i1;
	}
	
	// append random blocks.
	frog::for_each ( r_ptr, [] (CCodeBlock* p) { g_asf->AddNode(p); } );
	
	// gerarate code for synchronized
	TeSyncPtr e_ptr(g_mgr->GenerateTeSync(tbc));
	frog::for_each (e_ptr, [] (CTeSyncBlock* p) { g_asf->AddNode(p); } );
	g_mgr->ChainBlock(r_ptr->back(), e_ptr->front());
	
	UserPtr u2_ptr  (g_mgr->InsertUserCode(work , "uc_ht_complete" , tbc, e_ptr->at(1)));
	frog::for_each( u2_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );				
	g_mgr->ChainBlock(e_ptr->front(), e_ptr->at(1));

	//Generate code for user block random
	std::vector<std::pair<std::string,UI32>> vUcRndKey;
	g_usf->GetRndKey(vUcRndKey);
	std::vector<std::pair<std::string,UI32>>::iterator itr;
	for(itr = vUcRndKey.begin(); itr != vUcRndKey.end(); itr++){
		g_asf->AddNode(g_mgr->GenerateUserBlock(work, tbc, itr->first));
	}

	// Generate user code for handler
	CCodeBlock *pCB = g_mgr->GenerateUserBlock(work, tbc, "uc_handler");
	if(pCB->GetInstructionNum() > 0)
		g_asf->AddNode(pCB);
	else
		delete pCB;

	return (EXIT_SUCCESS);
}


/**
 * simulate_main
 * 
 */
static int simulate_main () {
	// place const data 
	std::vector<CCodeBlock*> v;
	g_asf->GetConstTable(v);
	if (g_sim->SetPrimitiveData(v) != true) {
		return (EXIT_FAILURE);
	}
	
	// ISS simulation
	ISimulationParam simparam(g_asf.get(), g_exp.get());
	if (g_sim->Simulation(&simparam) != true) {
		//g_asf->PrintLabel();
		g_asf->Flush(g_cfg->m_strOutputAsm);
		MSG_ERROR(0, "Give up simulation.\n");
		return (EXIT_FAILURE);
	}

	return (EXIT_SUCCESS);
}


/**
 * post_simulation
 * 
 */
static int post_simulation () {
	
	TBlockConfig tbc;

	if (g_cfg->m_bFrontRegs) {
		std::vector<INode*>& rCb = g_asf->GetCodeBlock();
		std::for_each (rCb.begin(), rCb.end(), [](INode* node) {
			CCodeBlock* p = static_cast<CCodeBlock*>(node);
			p->FrontLoadRegulation();
		}); 
	}

	g_mgr->GenerateReturnSetup();

	if((g_cfg->m_nRanHandler & 0x3) == 0x3)
		g_mgr->FrontRegulationHandler();

	// --selfcheck
	if (g_cfg->m_strSelfCheck.length() > 0) {
		// Generate Verifier
		std::vector<INode*>& rEps = g_asf->GetEpilogueBlock(); 
		std::for_each (rEps.begin(), rEps.end(), [&](INode* n){
			CCodeBlock* p = static_cast<CCodeBlock*>(n);
			p->FreeAddress();
			tbc.m_bNC = true;
			g_mgr->GenVerifier(p, &tbc);
		});
	}

	// Fetch line zeroing
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetVectorBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetHandlerBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetPreloadBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetPrologueBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetSyncBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetCodeBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetTeSyncBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetFunctionBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetEpilogueBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetTerminateBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetUserBlock());

	// Re-Link
	if (g_asf->Link() != true) {
		MSG_ERROR(0, "Link Error!\n");
		return (EXIT_FAILURE);
	}
	
	if (g_cfg->m_bVerbose) {
		std::ofstream ofs;
		ofs.open("label.sim");
		g_asf->PrintLabel(ofs);
		ofs.close();
	}

	return (EXIT_SUCCESS);
}


/**
 * output_result
 * 
 */
static int output_result () {
	
	auto f = [](const T_MEMWRRECORD& t) {
#if 0
		if (g_prf->IsInSconst(t.first))	{
			g_asf->SetSconst(t.first, t.second.first, t.second.second);
		}
#else
		if(g_prf->IsValidMem(t.first)) {
			g_asf->SetSconst(t.first, t.second.first, t.second.second);
		}
#endif
	};

    if (g_cfg->m_bPrefAssist) {
    	// generate prefetch code
        std::vector<INode*>& sync = g_asf->GetSyncBlock();
		UI32 nNumberOfFetchBlock = 3; // RedMine #62133
	    for (std::vector<INode*>::iterator itr_s = sync.begin(); itr_s != sync.end(); itr_s++) {
            std::string name = (*itr_s)->GetName();
            UI32 pos = name.find("_PrefetchMode", 0);
            if (pos != 0xffffffff) {
                //置き換え対象となるプリフェッチコードが見付かった場合の処理
                std::string context = name.substr(0,pos);
    	        CSyncBlock * pPF = new CSyncBlock(name);
                g_mgr->AppendPrefetchCode(context, pPF);
                std::vector<INode*>& body = g_asf->GetCodeBlock();
    	        for (std::vector<INode*>::iterator itr_r = body.begin(); itr_r != body.end(); itr_r++) {
					if(nNumberOfFetchBlock == 0)
						break;
                    std::string label = (*itr_r)->GetName();
                    if (label.find(context) == 0) {
                        g_mgr->AppendPrefetchData((*itr_r)->GetAddress(), (*itr_r)->GetCodeSize(), pPF);
						nNumberOfFetchBlock--;
                    } 
    	        }
                g_mgr->AppendPrefetchData(0, 0, pPF);
    	        pPF->SetOutputFlag(true);
    	        pPF->Update();
                // replace prefetch code
    			delete *(itr_s);
    			itr_s = sync.erase(itr_s);          // itr_s = 削除された最終要素の直後を指す
    			itr_s = sync.insert(itr_s, pPF);    // itr_s = 挿入した要素を指す
            }
        }
	}

	// generate preload code by simulation result
	std::vector<T_MEMWRRECORD> mpd;
    std::vector<T_MEMWRRECORD> mpd_sysmem;
	std::vector<T_MEMWRRECORD> mpd_sharemem;
	g_sim->GetSysMemPreset(&mpd_sysmem);
	mpd_sysmem.erase ( std::remove_if(mpd_sysmem.begin(), mpd_sysmem.end(), [](T_MEMWRRECORD &t)->bool {return (!g_prf->IsValidMem(t.first));}), mpd_sysmem.end() );
	
    //Lambda function that gets memrecords that belongs to shared memory area.
    auto GetShareMem = [] (std::vector<T_MEMWRRECORD> &mpd_sysmem,std::vector<T_MEMWRRECORD> &mpd_sharemem)
	{
		std::vector<T_MEMWRRECORD>::iterator itr;
		itr = mpd_sysmem.begin();
		while(itr != mpd_sysmem.end())
		{
			if(g_prf->IsShareMem(itr->first)){
				std::pair<UI32, UI64> r = std::pair<UI32, UI64> (itr->second.first, itr->second.second);
				mpd_sharemem.push_back(T_MEMWRRECORD(itr->first, r));
				itr = mpd_sysmem.erase(itr);
			}
			else
				itr++;
		}
	};

    //Lambda function that appends mpd_sysmem to mpd at the beginning if memrecord is not included in mpd.
    auto AppendMemRecord = [](std::vector<T_MEMWRRECORD> &mpd,std::vector<T_MEMWRRECORD> &mpd_sysmem)
    {
        std::vector<T_MEMWRRECORD>::iterator itr;
        std::vector<T_MEMWRRECORD>::iterator fndItr;
		itr = mpd_sysmem.begin();
		while(itr != mpd_sysmem.end())
		{
            fndItr = std::find_if(mpd.begin(), mpd.end(), [&](T_MEMWRRECORD mr)->bool{return (itr->first == mr.first);});
            if(fndItr != mpd.end()){
				itr = mpd_sysmem.erase(itr);
			}
			else
				itr++;
		}
        mpd.insert(mpd.begin(), mpd_sysmem.begin() , mpd_sysmem.end());
    };
	GetShareMem(mpd_sysmem, mpd_sharemem);
	CPreloadBlock* pPB = g_mgr->AppendShareMemPreset(&mpd_sharemem);
	pPB->SetOutputFlag(true);
	pPB->Update();
	g_asf->ReplaceCodeBlock( pPB ) ;

	g_sim->GetMemoryPresetData(&mpd) ;
    AppendMemRecord(mpd, mpd_sysmem);
	
	CPreloadBlock * pPD= g_mgr->AppendMemPresetBlock( &mpd ) ;
	pPD->SetOutputFlag(true);
	pPD->Update();
	g_asf->ReplaceCodeBlock( pPD ) ;

	std::for_each (mpd.begin(), mpd.end(), f);

	printf("\n");
	MSG_INFO (0, "Generate memory init code. Code size = %d\n", pPD->GetCodeSize());
	
	// file header comment	
	CFileHeader* pFh = new CFileHeader( XSTR(_RTG_APP_REVISION_) "(rev:" XSTR(_RTG_APP_HASHCODE_)")", g_sim->GetVersion().c_str(), RTG_CPU_ISA);
	pFh->SetParam(g_cfg->CreateHash());
	g_asf->AddNode(pFh);

	// Re-Link
	if (g_asf->Link() != true) {
		MSG_ERROR(0, "Link Error!\n");
		return (EXIT_FAILURE);
	}

	g_asf->RemoveDispLabel();

	// output source & linkmap
	if (!g_asf->Flush(g_cfg->m_strOutputAsm)) {
		MSG_ERROR(0, "File I/O : %s\n", g_cfg->m_strOutputAsm.c_str());
		return (EXIT_FAILURE);
	}
	g_asf->LinkMap(g_cfg->m_strOutputMap);
	
	return (EXIT_SUCCESS); 
}

int set_address_weight() {
	CGeneratorProfile::SectionData sd;
	CGeneratorProfile::SectionData::iterator sdi;
	MEMADDR start = 0, end = 0, weight=0, lnk=1;
	bool isLoad, isStore, isFetch, isTemp, isCmn, isUserCode, isLnk, isException, isRegBank, isMirror;
	
	auto lambdaCsvParse = [&] (const CGeneratorProfile::CsvRow& r) -> int {
      
        isLnk = true ;
		//if (r.size() == 4) {
		//	isLnk = false ;
		//	MSG_WARN(0, "profile format warnning. memory setting need 5 param.\n");
		//} else
		if (r.size() > 6) {
			MSG_ERROR(0, "profile format error. memory setting need < 6 param.\n");
			return -1;
		}
		if (CGeneratorProfile::FindCh(r[0], ":") || CGeneratorProfile::FindCh(r[1], ":")) {
			isLoad = isStore = isFetch = isTemp = isCmn = isUserCode = isException = isRegBank = isMirror = false;
			return 0;
		}
		isLoad	   = CGeneratorProfile::FindCh(r[2], "rR");
		isStore	   = CGeneratorProfile::FindCh(r[2], "wW");
		isFetch	   = CGeneratorProfile::FindCh(r[2], "iI");
		isTemp	   = CGeneratorProfile::FindCh(r[2], "tT");
		isCmn      = CGeneratorProfile::FindCh(r[2], "sS");
		isUserCode = CGeneratorProfile::FindCh(r[2], "uU");
		isException = CGeneratorProfile::FindCh(r[2], "eE");
		isRegBank  = CGeneratorProfile::FindCh(r[2], "bB");		
		
		try {
			if( isLnk ) {
				start 	= CToolFnc::AtoI(r[0].c_str());
				end   	= CToolFnc::AtoI(r[1].c_str());
				lnk  	= CToolFnc::AtoI(r[3].c_str());
				weight	= CToolFnc::AtoI(r[4].c_str());
				//! Get mirror atribute
				if(r.size() == 6)
					isMirror =( CToolFnc::AtoI(r[5].c_str()) > 0) ? true : false;
				else
					isMirror = false;
			} else {
				start 	= CToolFnc::AtoI(r[0].c_str());
				end   	= CToolFnc::AtoI(r[1].c_str());
				weight	= CToolFnc::AtoI(r[3].c_str());
				lnk  	= 1 ;//既存の動作
			}
		}catch (std::invalid_argument e){
			MSG_ERROR(0, "profile format error. address is not numeric.\n");
			return -1;
		}
		return 0;
	};
	
	sd = g_prf->GetSectionData("::ROM_ADDRESS");
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {

		if (lambdaCsvParse(*sdi) != 0) {
			return (EXIT_FAILURE);
		}
		if (isLoad) {
			g_LoadableAddr.Set(start, end, lnk, weight, isMirror);
		}
		if (isStore) {
			MSG_WARN(0, "write accessing to rom is ignored.\n");
			g_StorableAddr.Set(start, end, lnk, weight, isMirror);
		}
		if (isLoad && isStore) {
			g_RmwAddr.Set(start, end, lnk, weight, isMirror);
		}
		if (isFetch) {
            g_FetchAddr.Set(start, end, lnk, 1, isMirror);
		}
		if (isUserCode) {
			g_usf->SetCodeArea(start);
		}
		if (isTemp) {
			MSG_WARN(0, "use rom for temporary.\n");
		}
		if (isCmn) {
			MSG_WARN(0, "use rom for temporary.\n");
		}
		if (isException) {
			g_ExceptionAddr.Set(start, end, lnk, weight, 0);
		}
		if (isRegBank) {
			MSG_WARN(0, "Use rom for register bank.\n");
		}
		if( isLoad || isStore || isFetch || isTemp || isCmn || isUserCode ){
			weight = ( weight == 0 ) ? 1 : weight ;
			g_LnkBitAddr.Set(start, end, lnk, weight, isMirror);
		}
	}

	sd = g_prf->GetSectionData("::RAM_ADDRESS");
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		if (lambdaCsvParse(*sdi) != 0) {
			return (EXIT_FAILURE);
		}
		if (isLoad) {
			g_LoadableAddr.Set(start, end, lnk, weight, isMirror);
			if (lnk)
				g_LoadableLnkAddr.Set(start, end, lnk, weight, isMirror);
		}
		if (isStore) {
			g_StorableAddr.Set(start, end, lnk, weight, isMirror);
			if (lnk)
				g_StorableLnkAddr.Set(start, end, lnk, weight, isMirror);
		}
		if (isLoad && isStore) {
			g_RmwAddr.Set(start, end, lnk, weight, isMirror);
			if (lnk)
				g_RmwLnkAddr.Set(start, end, lnk, weight, isMirror);
		}
		if (isFetch) {
			MSG_WARN(0, "Instruction may be allocated on data ram.\n");			
			g_FetchAddr.Set(start, end, lnk, 1, isMirror);
		}
		if (isTemp) {
			g_wm.SetWorkArea(start, end, 1, 1);
		}
		if (isCmn) {
			g_wm.SetCommonArea(start);
		}
		if (isException) {
			g_ExceptionAddr.Set(start, end, lnk, weight, 0);
		}

		const UI32 BankSizeMax = (0x90 << 8);	  // maximum each bank size 0x90 and there 255 banks.
		if (isRegBank) {
			MEMADDR alignedAddr = ((start | 0x000000ff) + 1);	 // upper boundary alignment.
			if (alignedAddr >  end) {
			   MSG_WARN(0, "Invalid setting for register bank (B) area: %x - %x.\n", start, end);
			} else if ((end - alignedAddr) < BankSizeMax) {
				MSG_WARN(0, "Too small memory was set for register bank (B) area: %x - %x.\n", start, end);
			} else {
				g_RegisterBankAddr.Set(alignedAddr + BankSizeMax, end, lnk, weight, 0);
			} 
		}
		if( isLoad || isStore || isFetch || isTemp || isCmn || isUserCode ){
			weight = ( weight == 0 ) ? 1 : weight ;
			g_LnkBitAddr.Set(start, end, lnk, weight, isMirror);
		}
	}
	
	// check and set default
	if (g_LoadableAddr.Count() == 0) {
		g_LoadableAddr.Set(0xfe000000, 0xfeffffff, 100);
	}	
	if (g_StorableAddr.Count() == 0) {
		g_StorableAddr.Set(0xfe000000, 0xfeffffff, 100);
	}
	if (g_RmwAddr.Count() == 0) {
		g_RmwAddr.Set(0xfe000000, 0xfeffffff, 100);
	}
	if (g_FetchAddr.Count() == 0) {
		g_FetchAddr.Set(0x00000000, 0x03ffffff, 1);
	}
	g_LoadableAddr.ReCalc();
	g_StorableAddr.ReCalc();
	g_RmwAddr.ReCalc();
	g_FetchAddr.ReCalc();
	g_ExceptionAddr.ReCalc();
	g_RegisterBankAddr.ReCalc();
	g_LoadableLnkAddr.ReCalc();
	g_StorableLnkAddr.ReCalc();
	g_RmwLnkAddr.ReCalc();
	return 0;
}
static int set_bit_weight() {
	CGeneratorProfile::SectionData sd;
	CGeneratorProfile::SectionData::iterator sdi;
	MEMADDR addr1(0), addr2(0), lnk;
	UI8	bit1(0), bit2(0), weight(0);
	bool isLnk, mirror;
	
	auto lambdaCsvParse = [&] (const CGeneratorProfile::CsvRow& r) -> int {
		isLnk = true ;
		//if (r.size() == 4) {
		//	isLnk = false ;
		//	MSG_WARN(0, "Profile format warnning. memory setting need 5 param.\n");
		//} else 
		if (r.size() > 6) {
			MSG_ERROR(0, "Profile format error. memory setting need <= 6 param.\n");
			return -1;
		}

		std::string::size_type s = r[0].find(':', 0);
		std::string::size_type e = r[1].find(':', 0);
		if ((s == std::string::npos) && (e == std::string::npos)) {
			addr1 = bit1 = bit2 = weight = 0;
			return 0;
		}
		try {
			if( isLnk ) {
				addr1  = (UI32)CToolFnc::AtoI(r[0].substr(0,  s).c_str());
				bit1   = (UI32)CToolFnc::AtoI(r[0].substr(s + 1).c_str());
				addr2  = (UI32)CToolFnc::AtoI(r[1].substr(0,  e).c_str());
				bit2   = (UI32)CToolFnc::AtoI(r[1].substr(e + 1).c_str());
				lnk    = (UI32)CToolFnc::AtoI(r[3].c_str());
				weight = (UI32)CToolFnc::AtoI(r[4].c_str());
				if(r.size() == 6)
					mirror = ((UI32)CToolFnc::AtoI(r[5].c_str()) > 0) ? true : false;
				else
					mirror = false;
			} else {
				addr1  = (UI32)CToolFnc::AtoI(r[0].substr(0,  s).c_str());
				bit1   = (UI32)CToolFnc::AtoI(r[0].substr(s + 1).c_str());
				addr2  = (UI32)CToolFnc::AtoI(r[1].substr(0,  e).c_str());
				bit2   = (UI32)CToolFnc::AtoI(r[1].substr(e + 1).c_str());
				weight = (UI32)CToolFnc::AtoI(r[3].c_str());
				lnk    = 1;//既存の動作
			}
		} catch (std::invalid_argument e) {
			MSG_ERROR(0, "Profile format error. address or bit is not numeric.\n");
			return -1;
		}
		return 0;
	};

	// ROMについては現状不要(やるならTST1とわけるためにやるがやる価値は無いだろう)
	sd = g_prf->GetSectionData("::RAM_ADDRESS"); 
	for (sdi = sd.begin(); sdi != sd.end(); ++sdi) {
		if (lambdaCsvParse(*sdi) != 0) {
			return (EXIT_FAILURE);
		}
		if (weight == 0) {
			continue;
		}
		// ２バイトにまたがる指定は受け付けないでおく
		if (addr1 != addr2) {
			MSG_ERROR(0, "Bit-weight should be set in a byte. (0x%llx-0x%llx)\n", addr1, addr2);
			return -1;
		}
		if ((bit1 > bit2) || (bit1 > 7) || (bit2 > 7)) {
			MSG_ERROR(0, "Invalid bit value. (0x%llx[%d]-0x%llx[%d])\n", addr1, bit1, addr2, bit2);
			return -1;
		}
		for (UI8 b = bit1; b <= bit2; b++) {
			g_FlagAddr.Set(addr1, b, lnk, weight, mirror);
		}
	}

	g_FlagAddr.ReCalc();
	return 0;
}

static int set_user_profile() {

	// Lambda function that overwrites the default setting by user setting
	auto OverwriteProfile = [] (std::string s)
	{
		std::string urfLabel = s;
		CGeneratorProfile::SectionData usd;

		urfLabel.insert(2, "OVERWRITE_");
		usd = g_uprf->GetSectionData(urfLabel);
		if (usd.size() > 0) {
			CGeneratorProfile::SectionData& sd = g_prf->GetSectionData(s);
			CGeneratorProfile::SectionData::iterator sdi, usdi;
			for (usdi = usd.begin(); usdi != usd.end(); usdi++) {
				CGeneratorProfile::CsvRow& ur = (*usdi);
				for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
					CGeneratorProfile::CsvRow& r = (*sdi);
					if (r[0] == ur[0]) {
						r = ur;
						break;
					}
				}
			}
		}
		return;
	};

	// Lambda function that replaces the default setting by user setting
	auto ReplaceProfile = [] (std::string s)
	{
		std::string urfLabel = s;
		CGeneratorProfile::SectionData usd;

		urfLabel.insert(2, "REPLACE_");
		usd = g_uprf->GetSectionData(urfLabel);
		if (usd.size() > 0) {
			CGeneratorProfile::SectionData& sd = g_prf->GetSectionData(s);
            if (sd.size() > 0) {
			    sd.clear();
			    sd.insert(sd.begin(), usd.begin(), usd.end());
            } else {
                g_prf->InsSection( s, usd );
            }
		}
	};

	OverwriteProfile("::INSTRUCTION_GLOBAL");
	OverwriteProfile("::EXCEPTION_GLOBAL");

	ReplaceProfile("::MACHINE_SETTING");
	ReplaceProfile("::ROM_ADDRESS");
	ReplaceProfile("::RAM_ADDRESS");
	ReplaceProfile("::MXU_COMMON_AREA");
	ReplaceProfile("::MPU_SETTING");

	return EXIT_SUCCESS;
}

int show_report (clock_t tm_start) {
	
	//---------------------------------------------------------------------------------
	// Reporting
	//---------------------------------------------------------------------------------
	MSG_INFO(0, "%sSuccess to generate pattern.%s\n", COUT_BRIGHT, COUT_RESET);
	MSG_INFO(0, " -> Output file         = %s\n", g_cfg->m_strOutputAsm.c_str());
	MSG_INFO(0, " -> Seed value          = 0x%08X\n", g_cfg->m_nSeed);
	MSG_INFO(0, " -> Num of blocks        = %d\n", g_cfg->m_nBlockNum);
	MSG_INFO(0, " -> Num of instructions = %d\n", g_cfg->m_nBlockNum * g_cfg->m_nINumInBlock);
	MSG_INFO(0, " -> Run time            = %.3f sec\n", (double)(clock() - tm_start)/CLOCKS_PER_SEC);
	MSG_INFO(0, " -> Exception Report\n");
	g_exp->Print(std::cout);
	return EXIT_SUCCESS;
}

int check_error(void) {
    UI32 ret = EXIT_SUCCESS;
    auto PrintError = [] (CCodeBlock *pCB, IInstruction *pIns, std::string&& msg) {
        std::cout << msg << std::endl;
        std::cout << "Block: " << pCB->GetLabel() << std::endl;
		if (pIns != nullptr)
			std::cout << "Instruction: " << pIns->GetCode() << std::endl;
    };

    // Get random codeblock
	std::vector<INode*>& rCb = g_asf->GetCodeBlock();
    std::vector<INode*>::iterator itr;
	//Check consecutive interrupt
	for(itr = rCb.begin(); itr < rCb.end(); itr++) {

		CCodeBlock* p = static_cast<CCodeBlock*>(*itr);
        for(UI32 n = 0; n < p->GetInstructionNum(); n++) {
            IInstruction *pIns = p->at(n);
            if(pIns->HasAsyncLabel() && n > 0 && pIns->GetValid() == true) {
                IInstruction *pPrev = p->at(n - 1);
                if(pPrev->HasAsyncLabel() && pPrev->GetValid() == true) {
                    PrintError(p, pIns, "Error: Consecutive interrupt request");
                    ret = EXIT_FAILURE;
                }

                if(pPrev->GetException().first != 0) {
					UI32 k = 0;
                    UI32 cause_code = pPrev->GetException().first;
                    IDirective *pDir = nullptr;

                    while((pDir = pIns->GetDirective(k)) != nullptr) {
                        CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                        if(pAL != NULL  && pAL->m_bAssert == true && 
							(cause_code != 0x95 && cause_code != 0x1c )) {
							// 1. Instruction that cause exception
							// 2. EIINT was requested
							PrintError(p, pIns, "Error: Consecutive interrupt request");
							ret = EXIT_FAILURE;
					    }
                        k++;
                    }
                }

                if(pPrev->GetId() == INS_ID_EI) {
                    UI32 k = 0;
                    IDirective *pDir = nullptr;
                    while((pDir = pIns->GetDirective(k)) != nullptr) {
                        CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
                        if(pAL != NULL  && pAL->m_bAssert == false && (pAL->m_name == "eiint" || pAL->m_name == "eitbl" || pAL->m_name == "gmeiint" || pAL->m_name == "gmeitbl")) {
                            PrintError(p, pIns, "Error: Consecutive interrupt request");
                            ret = EXIT_FAILURE;
					    }
                        k++;
                    }
                }
            }
        }
	}


	// Check Overwrite precision
	for(itr = rCb.begin(); itr < rCb.end(); itr++) {
		CCodeBlock* p = static_cast<CCodeBlock*>(*itr);
		if (p->CheckPrecisionOverwrite(p->GetInstructionNum()) != true) {
			PrintError(p, nullptr, "Error: Overwrite precision error");
			ret = EXIT_FAILURE;
		}
	}

    return ret;
}
