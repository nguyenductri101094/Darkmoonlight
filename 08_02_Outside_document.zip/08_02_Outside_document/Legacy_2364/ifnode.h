#ifndef IFNODE_H_
#define IFNODE_H_

#include	"rtg_common.h"
class CCodeBlock;
/**
 * @brief  ファイル出力するデータ群を抽象化するクラスです。
 */
class INode
{
public:

	/**
	 * @brief  このオブジェクトを構築します。
	 */
	INode() : m_bOutputEnable(false) {}
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual ~INode() {}
	
	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs) = 0;
	
	virtual UI32 PrintLink(std::ostream& ofs){return true;}
	
	/**
	 * @brief  ノード名を取得する
	 * @return ノード名を返す。
	 */
	virtual std::string GetName() = 0;

	/**
	 * @brief  ノードアドレスを取得する
	 * @return ノードアドレスを返す。
	 */
	virtual UI32 GetAddress() const {
		return 0;
	}
	
	/**
	 * @brief  ノードの出力スイッチ
	 * @param  flag 真の場合、出力する
	 */
	virtual void SetOutputFlag(bool flag = true) {
		m_bOutputEnable = flag;
	}

	/**
	 * @brief  ノードの出力スイッチを取得する
	 * @return 真の場合、出力する
	 */
	virtual bool IsEnableOutput() {
		return m_bOutputEnable;
	}
	
	/**
	 *	@brief  このブロックのコードサイズを取得するインタフェース。
	 *  @return コードサイズ(バイト）
	 */
	virtual UI32 GetCodeSize() const {
		return 0;
	}

	/**
	* @brief  各ブロックに存在するデータテーブルブロックを収集します。
	*/
	virtual CCodeBlock* GetConstTable() = 0;

	/**
	 *	@brief  このブロックの命令数を取得します。
	 *	@return 登録された命令数
	 */
	virtual UI32 GetInstructionNum(void) const = 0;

	/**
	 *	@brief update node that was change instruction
	 */
	virtual void Update() = 0;

protected:
	bool m_bOutputEnable;		//!< @brief		出力対象となるか
};

/**
 * @brief  ファイル出力するデータ群を抽象化するクラスです。
 */
class CFileHeader : public INode
{
public:
	
	/**
	 * @brief  このオブジェクトを構築します。
	 */
	CFileHeader()
		: m_PHash(), m_rtgVer(""), m_simVer(""), m_targ("") 
	{
		m_bOutputEnable = true;
	}
	
	/**
	 * @brief  このオブジェクトを構築します。
	 */
	CFileHeader(LPCTSTR rtgVer, LPCTSTR simVer, LPCTSTR targ)
		: m_PHash(), m_rtgVer(rtgVer), m_simVer(simVer), m_targ(targ)
	{
		m_bOutputEnable = true;
	}
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual ~CFileHeader() {}
		
	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs) {
		const int Tabs = 16;
		
		time_t timer;
		struct tm *t; /* local */
		
		timer = time(NULL);
		t = localtime(&timer);
		t->tm_year	+= 1900;
		t->tm_mon	+= 1;
		
		char datestr[256];
		char* week[] = {(char*)"Sun", (char*)"Mon", (char*)"Tue", (char*)"Wed", (char*)"Thu", (char*)"Fri", (char*)"Sat"};
		sprintf (datestr, "%d/%02d/%02d, %s, %02d:%02d:%02d", t->tm_year, t->tm_mon, t->tm_mday, week[t->tm_wday], t->tm_hour, t->tm_min, t->tm_sec);
		
		ofs << std::left << std::setfill(' ');
		
		ofs << "# ========================================================================" << std::endl;
		ofs << "#  Random generator - Target : " <<  m_targ << std::endl;
		ofs << "# ------------------------------------------------------------------------" << std::endl;
		ofs << "#     " << std::setw(Tabs) << "RTG Revision    " << " = " << m_rtgVer << std::endl;
		ofs << "#     " << std::setw(Tabs) << "SIM Revision    " << " = " << m_simVer << std::endl;
		ofs << "#     " << std::setw(Tabs) << "Generate Date   " << " = " << datestr << std::endl;
		ofs << "# -------------------------------------------------------------------------" << std::endl;
		ofs << "#  Parameters:" << std::endl;
		std::map<std::string,std::string>::iterator i;
		for (i = m_PHash.begin(); i != m_PHash.end(); i++) {
		ofs << "#     " << std::setw(Tabs) << i->first << " = " << i->second << std::endl;
		}
		ofs << "# ========================================================================" << std::endl;
		return 3;
	};

	void SetParam (std::map<std::string,std::string>* pHash) {
		if (pHash) {
			m_PHash = (*pHash);
			delete pHash;
		}
	}

	/**
	 *	@brief update node that was change instruction
	 */
	virtual void Update(){}

	/**
	 *	@brief  このブロックの命令数を取得します。
	 *	@return 登録された命令数
	 */
	virtual UI32 GetInstructionNum(void) const {
		return 0;
	}
	
	/**
	* @brief  ノード名を取得する
	* @return ノード名を返す。
	*/
	virtual std::string GetName() {return std::string();}

	/**
	* @brief  各ブロックに存在するデータテーブルブロックを収集します。
	*/
	virtual CCodeBlock* GetConstTable(){
		return nullptr;
	}

protected:
	std::map<std::string,std::string> m_PHash;
	std::string 		m_rtgVer;
	std::string 		m_simVer;
	std::string 		m_targ;
};

#endif /*IFNODE_H_*/
