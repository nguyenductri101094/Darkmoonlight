#ifndef IINS_SET_H_
#define IINS_SET_H_

#include "rtg_common.h"
#include "rnd_gen.h"
#include "ifinstruction.h"

class IInstructionSet
{
public:
	/**
	 * @brief  このオブジェクトを構築します。
	 * @param pRnd 乱数発生源
	 */
	IInstructionSet(IRandom* pRnd) : m_pr(pRnd), m_wrIns(pRnd) {}

	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual ~IInstructionSet(){}

	/**
	 * @brief  全命令を同じ重みで均等に登録する。
	 */
	virtual void DefaultSet(void) = 0;

	/**
	 * @brief　カテゴリ条件に従って命令オブジェクトを構成する
	 * @return 命令オブジェクト
	 */
	virtual UI32 FilterCategory(BS_ICAT mask, BS_ICAT val) = 0;

	/**
	 * @brief　権限条件に従って命令オブジェクトを構成する
	 * @return 命令オブジェクト
	 */
	virtual UI32 FilterPriviledge(BS_IPRV mask, BS_IPRV val) = 0;

	/**
	 * @brief　動作条件に従って命令オブジェクトを構成する
	 * @return 命令オブジェクト
	 */
	virtual UI32 FilterBehavior(BS_IBHV mask, BS_IBHV val) = 0;

	/**
	 * @brief　命令オブジェクトを生成する
	 * @return 命令オブジェクト
	 */
	virtual IInstruction* CreateIns() = 0;

	/**
	 * @brief　命令オブジェクトを生成する
	 * @param  ins_id 命令ID
	 * @return 命令オブジェクト
	 */
	virtual IInstruction* CreateIns(INS_ID ins_id) = 0;

	virtual UI32 SetWeight(std::string str ,UI32 weight_value ) = 0;

	virtual void SetWeight(UI32 weight_id ,UI32 weight_value ){
		m_wrIns.Set( weight_id, weight_value );
	}

	/**
	 * @brief　IDを指定して重みを取得する
	 * @param  ユニークな要素ID値
	 * @return 重み値
	 */
	virtual UI32 GetWeight(UI32 weight_id) {
		return m_wrIns.GetWeight(weight_id);
	}

	/**
     * @brief　IDを指定して命令重み登録キーを取得する
	 * @param  ユニークな要素ID値
     * @return 命令重み登録キー
	 */
	virtual LPCTSTR GetKey(UI32 weight_id) = 0 ;

	virtual void ReCalc( void ) = 0 ;

	virtual void Clear( void ) = 0 ;

	virtual void Dump( void ) = 0 ;

public:
	/**
	 * @brief　命令オブジェクトを生成する
	 * @return 命令オブジェクト
	 */
	 static IInstructionSet* New();

protected:
	IRandom*					m_pr;		//!<　@brief 乱数発生源
	CWeightedRandom<INS_ID>		m_wrIns;	//!<　@brief 重みつき命令セレクタ
};

#endif /*IINS_SET_H_*/
