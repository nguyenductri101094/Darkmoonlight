#ifndef USR_SRC_H_
#define USR_SRC_H_

#include	"rtg_common.h"
#include	"ifinstruction.h"
#include	"ifnode.h"
#include	"codeblock.h"
#include	"linker.h"
#include    "rtg_cfg.h"
#include "ifexception.h"
#include "ifblk_manager.h"
#include "weight_parser.h"

extern std::shared_ptr<CGeneratorConfig>		g_cfg; 
extern TWorkMemory								g_wm;
extern std::unique_ptr<IBlockManager>		g_mgr;

/**
 * @brief 出力ファイルを抽象化するクラスです。
 *        生成出力コードに必要な情報を管理、ファイル出力をハンドリングします。
 */
class CUserSourceFile
{
	typedef	std::string KeyName;
	typedef	std::string CodeStr;
	typedef	std::vector<CodeStr> CodeBody;
	typedef	std::pair<KeyName, CodeBody*> UserCode;
	typedef	std::map <KeyName, CodeBody*> UserCodeMap;
	
	typedef std::pair<std::string, std::string> PlaceHolder;
	typedef std::vector<PlaceHolder> PlaceHolderVec;
public:
	/**
	 * @brief このオブジェクトを構築します。
	 */
	CUserSourceFile() : m_key_mark_up("-- ::") ,m_valid_start_addr(false), m_vRndKey(), m_vDefineList() {}
	
	/**
	 * @brief このオブジェクトを破棄します。
	 *        登録されたNODEはこのデストラクタでdeleteします。
	 */
	virtual ~CUserSourceFile() {
		std::for_each ( m_map.begin(), m_map.end(), [] (const UserCode& p) { delete p.second; } );
	}

	/**
	 * @brief  ユーザコードファイルを開き全行取り込む。
	 */
	virtual void SetFile(const std::string& path) {
		// COPY USER CODE
		m_path = path;
		if (m_path.length() == 0) {
			return;
		}
		
		std::ifstream ifs(m_path, std::ios_base::in);
		if (!ifs) {
			std::cerr << "Fail to retrieve user-code [" << m_path << "]" << "\n";
			return ;
		}
		
		// Register as No-name
		KeyName		row("");
		CodeBody*	pUc = new CodeBody();
		m_map.insert( UserCode(row, pUc) );
		while (ifs.eof() != true) {
			std::getline(ifs, row);
			if (DelComment(row) && (row.length() == 0)) {
				continue; // 先頭からコメントのみ空行出力しない
			}
			if (IsKey(row) == true) {
				UI32 mark = row.find(',', 0);
				
				if(mark < row.length()){
					std::string weight = CToolFnc::Trim(row.substr(mark + 1, row.length()));
					UI32 w = CToolFnc::AtoI(weight.c_str());
					std::string key = GetKey(CToolFnc::Trim(row.substr(0,mark)));
					m_vRndKey.push_back(std::pair<std::string, UI32>(key,w));
				}
				row = GetKey(CToolFnc::Trim(row.substr(0,mark)));
				pUc = new CodeBody();
				if ((m_map.insert( UserCode(row, pUc))).second != true ) {
					MSG_ERROR(0, "User code [%s] is already defined.\n", row.c_str());
					return;
				}
			} else {
				pUc->push_back(row);
			}
		}
	}

	/**
	 * @brief 指定されたタグに対応するユーザーコードを出力する。（デバッグ用）
	 *         
	 * @param  k   タグ名
	 * @param  os  出力ストリーム
	 */
	virtual bool GetRawBody(const KeyName& k, std::stringstream& ss) {
		ss.str("");
		UserCodeMap::iterator itr = m_map.find(k);
		if (itr == m_map.end()) {
			return false;
		}
		std::for_each (itr->second->begin(), itr->second->end(), [&ss](const CodeStr& str){ ss << str; } );
		return true;
	}

	/**
	 * @brief 指定されたタグに対応するユーザーコードを置換リストに従って置き換えながら出力する。
	 *         
	 * @param  k   タグ名
	 * @param  os  出力ストリーム
	 */
	virtual bool GetBody(const KeyName& k, std::ostream& os) {
		UserCodeMap::iterator itr = m_map.find(k);
		if (itr == m_map.end()) {
			return false;
		}

		std::for_each (itr->second->begin(), itr->second->end(), [&](const CodeStr& str){ os << Replace(str) << std::endl; } );
		return true;
	}

	/**
	 * @brief Get content of user code block
	 *         
	 * @param  k   user code key
	 * @param  vUcBody  vector to store user code contents
	 */
	virtual void GetUserCodeBody(const KeyName& k, std::vector<std::string>& vUcBody){
		// lambda function to replace
		auto ReplaceString = [] (std::string &src, const std::string &strOld, const std::string &strNew) {
			std::string::size_type pos;
			while((pos = src.find(strOld, pos)) != std::string::npos) {
				src.replace(pos, strOld.size(), strNew);
				pos += strNew.size();
			}
		};

		UserCodeMap::iterator itr = m_map.find(k);
		if (itr == m_map.end()) {
			return;
		}

		std::vector<CodeStr>::iterator itrCode;
		std::string::size_type pos;
		std::string context = CLabel::m_prefix.substr(CLabel::m_prefix.size() - 3);
		std::string frog_pe = CLabel::m_prefix;

		for(itrCode = itr->second->begin(); itrCode < itr->second->end(); itrCode++){
			std::string code = *itrCode;
			// Remove comment started by "--"
			if((pos = code.find("--")) != std::string::npos) {
				code = code.substr(0, pos);
			}

			// Trim spaces
			code = CToolFnc::Trim(code);
			if(code.size() == 0)
				continue;

			// Replace %FROG_PE%, %CONTEXT%
			ReplaceString(code, "%FROG_PE%", frog_pe);
			ReplaceString(code, "%CONTEXT%", context);

			// Replace defined macro by its value
			if((pos = code.rfind(":")) == std::string::npos) {
				ReplaceMacro(code);
			}
			vUcBody.push_back(code);
		}
		return;
	}

	/**
	 * @brief Get macro definition in uc_define
	 *         
	 * @return  list of macro definition
	 */
	virtual std::vector<std::pair<std::string, std::string>>& GetDefine() {
		auto ParseDefine = [&] (const std::string& row) {
			std::string::size_type pos;
			std::string code = row;
			const std::string key("#define");
			// Remove comments
			if((pos = code.find("--")) != std::string::npos)
				code = code.substr(0, pos);

			// Remove spaces at head and tail.
			code = CToolFnc::Trim(code);
			if(code.size() == 0)
				return;

			// The format of definition: #define	MACRO_NAME	value
			if((pos = code.find(key)) != std::string::npos){
				// Remove "#define" string
				code = CToolFnc::Trim(code.replace(0,  pos + key.size(), ""));

				// Find the first space or tab
				if((pos = code.find(" ")) == std::string::npos) {
					if((pos = code.find("\t")) == std::string::npos)
						pos = code.size();
				} else {
					std::string::size_type tab_pos = code.find("\t");
					if(tab_pos != std::string::npos && tab_pos < pos)
						pos = tab_pos;
				}

				if(pos != std::string::npos) {
					std::string key = CToolFnc::Trim(code.substr(0, pos));
					std::string value = CToolFnc::Trim(code.substr(pos + 1));
					ReplaceMacro(value);
					m_vDefineList.push_back(std::make_pair(key, value));
				} else {
					MSG_ERROR(0, "Invalid definition: \n", row.c_str());
				}
				return;
			}

			// The format of definition: MACRO=value
			if((pos = code.find("=")) != std::string::npos) {
				std::string key = CToolFnc::Trim(code.substr(0, pos));
				std::string value = CToolFnc::Trim(code.substr(pos + 1));
				ReplaceMacro(value);
				m_vDefineList.push_back(std::make_pair(key, value));
				return;
			} else {
				MSG_ERROR(0, "Invalid definition: \n", row.c_str());
			}

			return;
		};

		// The definition was already parsed.
		if(m_vDefineList.size() > 0)
			return m_vDefineList;

		UserCodeMap::iterator itr = m_map.find("uc_define");
		if (itr == m_map.end())  {
			return m_vDefineList;
		}
		
		std::for_each (itr->second->begin(), itr->second->end(), ParseDefine);
		return m_vDefineList;
	}

	/**
	 * @brief get random key in user code file.
	 * @param v_ucRndKey is updated key word and weight.
	**/
	virtual bool GetRndKey(std::vector<std::pair<std::string, UI32>>& vUcRndKey) {
		if (m_vRndKey.size() == 0)
			return false;
		vUcRndKey = m_vRndKey;
		return true;
	}

	/**
	 * @brief Get user code key.
	 * @param index of user code in user code file.
	 * @param pKey output parameter to store key name
	**/
	virtual void GetUserCodeKey(UI32 index, std::string *pKey){
		if(index < 0 || index > m_vRndKey.size())
			return;

		*pKey = (m_vRndKey[index]).first;
	}

	virtual UI32 GetUserCodeNum() {
		return m_vRndKey.size();
	}

	/**
	 * @brief 引数で与えられる文字列を置換リストに従って置き換えを行なう。
	 *         
	 * @param  s  ユーザーコード１行分
	 */
	virtual std::string Replace(std::string s) {
		auto rep = [&s] (PlaceHolder& ph) {
			std::string::size_type pos= 0;
			while((pos = s.find(ph.first.c_str(), pos)) != std::string::npos) {
				s.replace(pos, ph.first.length(), ph.second.c_str());
				pos += ph.second.length();
		    }
 		};
		std::for_each (m_phv.begin(), m_phv.end(), rep);
		return s;
	}
	
	/**
	 * @brief 
	 *         
	 * @param  
	 */
	virtual bool DelComment(std::string& s) {
		const std::string markup("//");
		std::string::size_type pos (s.find(markup));
		if (pos != std::string::npos) {
			s = s.substr(0, pos);
			return true;
		}
		return false;
	}
	
	/**
	 * @brief 
	 *         
	 * @param  
	 */
	virtual bool IsKey(CodeStr s) {
		return ((CGeneratorProfile::Trim(s)).substr(0, m_key_mark_up.length())) == m_key_mark_up;
	}

	/**
	 * @brief デバッグ用ダンプ表示
	 */
	virtual void Dump(std::ostream& os = std::cout) {
		
		std::for_each (m_map.begin(), m_map.end(), 
			[&] (const UserCode& uc) {
				os << uc.first << std::endl;
				os << "---------------------------------" << std::endl;
				std::for_each (uc.second->begin(), uc.second->end(), [&os](const CodeStr& c){os << c << std::endl;});
			}
		);
	}

	/**
	 * @brief 置換リストをクリアする
	 */
	virtual void ClearPlaceHolder() {
        m_phv.clear();
    }

	/**
	 * @brief 置換文字列をリストに登録する
	 *         
	 * @param  strFrom  検索文字列
	 * @param  strTo    置き換え文字列
	 */
	virtual void SetPlaceHolder(std::string strFrom , std::string strTo) {
        PlaceHolder item(strFrom , strTo);
        m_phv.push_back(item);
	}

	/**
	 * @brief ユーザファイルのパスを取得する
	 */
	virtual std::string GetFilePath() {
        return m_path;
	}

	virtual void SetCodeArea(MEMADDR start) {
        m_valid_start_addr = true ;
        m_start_addr = start ;
    }

	virtual MEMADDR GetCodeArea(void) {
        return m_start_addr ;
    }

	virtual bool IsSetCodeArea(void) {
        return m_valid_start_addr ;
    }

	/**
	 * @brief Return information of which handler is defined in user code
	 * @param	pe_context	context of current machine
	 * @return	vector of handler name that is defined in user code
	 */
	virtual std::vector<std::string> GetUserHandler(const std::string &pe_context) {
		if(m_vDefineList.size() == 0)
			GetDefine();

		std::string macro_prefix = pe_context + "vector_";
		std::string macro_postfix = "_UseUserCode";
		std::vector<std::string> vHandler;

		std::vector<std::pair<std::string, std::string>>::iterator itr;
		for(itr = m_vDefineList.begin(); itr < m_vDefineList.end(); itr++){
			std::string macro = itr->first;
			std::string value = itr->second;
			std::string::size_type pos;
			if(macro.find(macro_prefix) == 0 && (pos = macro.find(macro_postfix)) != std::string::npos) {
				std::string handler = macro.substr(macro_prefix.size(), pos - macro_prefix.size());
				if(value == "1"){
					vHandler.push_back(handler);
				}
			}
		}
		return vHandler;
	}

protected:
	virtual std::string GetKey(CodeStr s) {
		return IsKey(s) ? s.substr(m_key_mark_up.length()) : std::string();
	}

	/**
	 * @brief Internal function that replace a macro by its value
	 * @param code	user code
	 */
	void ReplaceMacro(std::string &code) {
		UI32 nIdx = 0;
		UI32 nPrev = 0;
		UI32 nSize = 0;
		while(nIdx < code.size()) {
			char c = code[nIdx];
			if(('0' <= c && c <= '9') || ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || c == '_') {
				if(nSize == 0)
					nPrev = nIdx;
				nSize++;
			} else {
				if(nSize > 0) {
					std::vector<std::pair<std::string, std::string>>::iterator itr;
					std::string strMacro = code.substr(nPrev, nSize);
					for(itr = m_vDefineList.begin(); itr < m_vDefineList.end(); itr++) {
						if(itr->first == strMacro){
							code = code.replace(nPrev, nSize, itr->second);
							nIdx = nPrev + (itr->second).size();
						}
					}
					nSize = 0;
				}
			}
			nIdx++;
		}
		if(nSize > 0) {
			std::vector<std::pair<std::string, std::string>>::iterator itr;
			std::string strMacro = code.substr(nPrev, nSize);
			for(itr = m_vDefineList.begin(); itr < m_vDefineList.end(); itr++) {
				if(itr->first == strMacro){
					code = code.replace(nPrev, nSize, itr->second);
					nIdx = nPrev + (itr->second).size();
				}
			}
		}
	}

	std::string			m_path;
	UserCodeMap			m_map;
	PlaceHolderVec		m_phv;
	std::string			m_key_mark_up;
	bool                m_valid_start_addr;
	MEMADDR             m_start_addr;
	std::vector<std::pair<std::string,UI32>>	m_vRndKey;
	std::vector<std::pair<std::string, std::string>> m_vDefineList;
};
#endif //USR_SRC_H_
