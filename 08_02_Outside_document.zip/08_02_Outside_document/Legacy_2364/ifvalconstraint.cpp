
#include	"ifvalconstraint.h"

/**
 * @brief  制約に適合する値を取得します。
 * @return 適正値。
 */
UI64 IFpuSingleConstraint::SelectValue() {
	UI64	v = 0;
	
	if (pst_WrType == NULL) {
		return IValConstraint::SelectValue();
	} else		
	if (m_pType == NULL && !m_bValid) {
		UI32 type =  pst_WrType->GetObj();
		std::vector<CFpuWeightParam*>::iterator itr;
		itr = std::find_if(vst_FPUParam.begin(), vst_FPUParam.end(), [&type](CFpuWeightParam* p){return (p->m_id == type);});
		if(itr != vst_FPUParam.end())
			m_pType = *itr;
		m_bValid = true;
	}

	if(m_pType == NULL)
		return IValConstraint::SelectValue();
	
	// Randomize sign
	UI32 sign = m_pType->m_sign;
	if(sign == CFpuWeightParam::FPU_RANDOM) {
		sign = g_rnd.Get() & 0x1;
	}
	// Randomize fraction
	UI32 fraction = g_rnd.GetRange((UI32) m_pType->m_fraction_min, (UI32) m_pType->m_fraction_max);
	fraction = (fraction & m_pType->m_fraction_and) | m_pType->m_fraction_or;

	// Randomize exponent
	UI32 exponent = g_rnd.GetRange((UI32) m_pType->m_exponent_min, (UI32) m_pType->m_exponent_max);
	exponent = (exponent & m_pType->m_exponent_and) | m_pType->m_exponent_or;
	v = (sign << 31) | (exponent << 23) | fraction;

	// Noise injection
	UI32 nNumOfNoise = g_rnd.GetRange((UI32)0, (UI32)m_pType->m_max_noise);
	m_noise = 0;
	for(UI32 n = 0; n < nNumOfNoise; n++) {
		UI32 b = g_rnd.GetRange(0, 32);
		if((m_noise & (1 << b)) == 0)
			m_noise |= (1 << b);
	}

	v = (v & ~m_noise) | (~v & m_noise);

	return v;
}

/**
 * @brief  指定された値が、制約に適合するかを検証します。
 * @param  val 検証値
 * @return 適合する場合、真を返す
 */
bool IFpuSingleConstraint::IsValid(UI64 val) {
	if (pst_WrType == NULL) {
		return true;
	} else		
	if (m_pType == NULL && !m_bValid) {
		UI32 type =  pst_WrType->GetObj();
		std::vector<CFpuWeightParam*>::iterator itr;
		itr = std::find_if(vst_FPUParam.begin(), vst_FPUParam.end(), [&type](CFpuWeightParam* p){return (p->m_id == type);});
		if(itr != vst_FPUParam.end())
			m_pType = *itr;
		m_bValid = true;
	}

	if(m_pType == NULL)
		return true;

	// Acquire FPU Param
	UI32	v = (val & ~m_noise) | (~val & m_noise);		// Remove noise
	UI32	sign = v >> 31;
	UI32	exponent = (v >> 23) & 0xff;
	UI32	fraction = (v & 0x7fffff);

	// Remove exponent_or/fraction_or portion
	exponent &= (~(m_pType->m_exponent_or));
	fraction &= (~(m_pType->m_fraction_or));

	if(m_pType->m_sign != CFpuWeightParam::FPU_RANDOM && sign != m_pType->m_sign) {
		return false;
	}

	if(exponent < m_pType->m_exponent_min || exponent > m_pType->m_exponent_max) {
		return false;
	}

	if(exponent & (~(m_pType->m_exponent_and))) {
		return false;
	}

	if(fraction < m_pType->m_fraction_min || fraction > m_pType->m_fraction_max) {
		return false;
	}

	if(fraction & (~(m_pType->m_fraction_and))) {
		return false;
	}

	return true;
}


/**
 * @brief  制約に適合する値を取得します。
 * @return 適正値。
 */
std::pair<std::bitset<4> ,__uint128_t> IFpuSingleConstraint::SelectValueWR() {
	
	__uint128_t val = (__uint128_t)0;
	UI32 v;
	const UI32 size = (sizeof(__uint128_t)/sizeof(UI32));

	// Pre-set m_vType
	while(m_vType.size() < size)
		m_vType.push_back(NULL);

	// Pre-set m_vNoise
	while(m_vNoise.size() < size)
		m_vNoise.push_back(0);

	// Randomize FPU type for each element
	if (pst_WrType != NULL) {
		for(UI32 i = 0; i < m_vType.size(); i++) {
			if(m_vType[i] == NULL) {
				UI32 type =  pst_WrType->GetObj();
				std::vector<CFpuWeightParam*>::iterator itr;
				itr = std::find_if(vst_FPUParam.begin(), vst_FPUParam.end(), [&type](CFpuWeightParam* p){return (p->m_id == type);});
				if(itr != vst_FPUParam.end())
					m_vType[i] = *itr;
			}
		}
	}
		
	for( unsigned int i = 0; i < size; i++ ) {
		if( m_elm_check_flag.test(i)) {
			if(m_vType[i] == NULL) {
				v = IValConstraint::SelectValue();
				val = ( val & ~((__uint128_t)0xffffffffUL << ( i * 32 ))) | ((__uint128_t)v << ( i * 32 ));
				continue;
			}

			// Acquire FPU Param
			CFpuWeightParam *pFPUParam = m_vType[i];
			
			// Randomize sign
			UI32 sign = m_vType[i]->m_sign;
			if(sign == CFpuWeightParam::FPU_RANDOM)
				sign = g_rnd.Get() & 0x1;

			// Randomize fraction
			UI32 fraction = g_rnd.GetRange((UI32) pFPUParam->m_fraction_min, (UI32) pFPUParam->m_fraction_max);
			fraction = (fraction & pFPUParam->m_fraction_and) | pFPUParam->m_fraction_or;

			// Randomize exponent
			UI32 exponent = g_rnd.GetRange((UI32) pFPUParam->m_exponent_min, (UI32) pFPUParam->m_exponent_max);
			exponent = (exponent & pFPUParam->m_exponent_and) | pFPUParam->m_exponent_or;
			v = (sign << 31) | (exponent << 23) | fraction;

			// Noise injection
			UI32 nNumOfNoise = g_rnd.GetRange((UI32)0, (UI32)pFPUParam->m_max_noise);
			m_vNoise[i] = 0;
			for(UI32 n = 0; n < nNumOfNoise; n++) {
				UI32 b = g_rnd.GetRange(0, 32);
				if((m_vNoise[i] & (1 << b)) == 0)
					m_vNoise[i] |= (1 << b);
			}

			v = (v & ~m_vNoise[i]) | (~v & m_vNoise[i]);

			val = ( val & ~((__uint128_t)0xffffffffUL << ( i * 32 ))) | ((__uint128_t)v << ( i * 32 ));
		}
	}
	return std::pair<std::bitset<4> ,__uint128_t>(m_elm_check_flag,val);
}

/**
 * @brief  指定された値が、制約に適合するかを検証します。
 * @param  val 検証値
 * @return 適合する場合、真を返す
 */
bool IFpuSingleConstraint::IsValidWR(__uint128_t val) {
	bool    res = true;
	const UI32 size = (sizeof(__uint128_t)/sizeof(UI32));

	// Pre-set m_vType
	while(m_vType.size() < size)
		m_vType.push_back(NULL);

	// Preset_m_vNoise
	while(m_vNoise.size() < size)
		m_vNoise.push_back(0);

	// Randomize FPU Type
	if (pst_WrType != NULL) {
		for(UI32 i = 0; i < m_vType.size(); i++) {
			if(m_vType[i] == NULL) {
				UI32 type =  pst_WrType->GetObj();
				std::vector<CFpuWeightParam*>::iterator itr;
				itr = std::find_if(vst_FPUParam.begin(), vst_FPUParam.end(), [&type](CFpuWeightParam* p){return (p->m_id == type);});
				if(itr != vst_FPUParam.end())
					m_vType[i] = *itr;
			}
		}
	}
		
			
	for( unsigned int i = 0; i < (sizeof(__uint128_t)/sizeof(UI32)); i++ ) {
		if( m_elm_check_flag.test(i)) {
			if(m_vType[i] == NULL) {
				continue;
			}

			// Acquire FPU Param
			CFpuWeightParam *pFPUParam = m_vType[i];
			UI32	v = (UI32)(( val & ((__uint128_t)0xffffffffUL << (i * 32))) >> (i * 32));
			v = (v & ~m_vNoise[i]) | (~v & m_vNoise[i]);		// Remove noise
			UI32	sign = v >> 31;
			UI32	exponent = (v >> 23) & 0xff;
			UI32	fraction = (v & 0x7fffff);

			// Remove exponent_or/fraction_or portion
			exponent &= (~(pFPUParam->m_exponent_or));
			fraction &= (~(pFPUParam->m_fraction_or));

			if(pFPUParam->m_sign != CFpuWeightParam::FPU_RANDOM && sign != pFPUParam->m_sign) {
				res = false;
			}

			if(exponent < pFPUParam->m_exponent_min || exponent > pFPUParam->m_exponent_max) {
				res = false;
			}

			if(exponent & (~(pFPUParam->m_exponent_and))) {
				res = false;
			}

			if(fraction < pFPUParam->m_fraction_min || fraction > pFPUParam->m_fraction_max) {
				res = false;
			}

			if(fraction & (~(pFPUParam->m_fraction_and))) {
				res = false;
			}
		}
	}
	return res;
}

/**
 * @brief  単精度FPU命令に与えるオペランドの重みを管理する
 *         特定の命令でタイプを選ぶことは少ないと想定されるため、
 *         共通の重みづけを行う。
 */
CWeightedRandom<UI32>* IFpuSingleConstraint::pst_WrType = NULL;
std::vector<CFpuWeightParam*> IFpuSingleConstraint::vst_FPUParam;


/**
 * @brief  制約に適合する値を取得します。
 * @return 適正値。
 */
UI64 IFpuDoubleConstraint::SelectValue() {
	UI64	v = 0;
	
	if (pst_WrType == NULL) {
		return IValConstraint::SelectValue();
	} else		
	if (m_pType == NULL && !m_bValid) {
		UI32 type =  pst_WrType->GetObj();
		std::vector<CFpuWeightParam*>::iterator itr;
		itr = std::find_if(vst_FPUParam.begin(), vst_FPUParam.end(), [&type](CFpuWeightParam* p){return (p->m_id == type);});
		if(itr != vst_FPUParam.end())
			m_pType = *itr;
		m_bValid = true;
	}

	if(m_pType == NULL)
		return IValConstraint::SelectValue();

	// Randomize sign
	UI32 sign = m_pType->m_sign;
	if(sign == CFpuWeightParam::FPU_RANDOM)
		sign = g_rnd.Get() & 0x1;

	// Randomize fraction
	UI64 fraction = g_rnd.GetRange((UI64) m_pType->m_fraction_min, (UI64) m_pType->m_fraction_max);
	fraction = (fraction & m_pType->m_fraction_and) | m_pType->m_fraction_or;

	// Randomize exponent
	UI32 exponent = g_rnd.GetRange((UI32) m_pType->m_exponent_min, (UI32) m_pType->m_exponent_max);
	exponent = (exponent & m_pType->m_exponent_and) | m_pType->m_exponent_or;
	v = ((UI64) sign << 63) | ((UI64)exponent << 52) | fraction;

	// Noise injection
	UI32 nNumOfNoise = g_rnd.GetRange((UI32)0, (UI32)m_pType->m_max_noise);
	for(UI32 n = 0; n < nNumOfNoise; n++) {
		UI32 b = g_rnd.GetRange(0, 64);
		if((m_noise & (1 << b)) == 0)
			m_noise |= (1 << b);
	}

	v = (v & ~m_noise) | (~v & m_noise);

	return v;
}

/**
 * @brief  指定された値が、制約に適合するかを検証します。
 * @param  val 検証値
 * @return 適合する場合、真を返す
 */
bool IFpuDoubleConstraint::IsValid(UI64 val) {
	if (pst_WrType == NULL) {
		return true;
	} else		
	if (m_pType == NULL && !m_bValid) {
		UI32 type =  pst_WrType->GetObj();
		std::vector<CFpuWeightParam*>::iterator itr;
		itr = std::find_if(vst_FPUParam.begin(), vst_FPUParam.end(), [&type](CFpuWeightParam* p){return (p->m_id == type);});
		if(itr != vst_FPUParam.end())
			m_pType = *itr;
		m_bValid = true;
	}

	if(m_pType == NULL)
		return true;

	UI64	v = (val & ~m_noise) | (~val & m_noise);		// Remove noise
	UI32	sign = v >> 63;
	UI32	exponent = (v >> 52) & 0x7ff;
	UI64	fraction = (v & 0xfffffffffffff);

	// Remove exponent_or/fraction_or portion
	exponent &= (~(m_pType->m_exponent_or));
	fraction &= (~(m_pType->m_fraction_or));

	if(m_pType->m_sign != CFpuWeightParam::FPU_RANDOM && sign != m_pType->m_sign) {
		return false;
	}

	if(exponent < m_pType->m_exponent_min || exponent > m_pType->m_exponent_max) {
		return false;
	}

	if(exponent & (~(m_pType->m_exponent_and))) {
		return false;
	}

	if(fraction < m_pType->m_fraction_min || fraction > m_pType->m_fraction_max) {
		return false;
	}

	if(fraction & (~(m_pType->m_fraction_and))) {
		return false;
	}

	return true;
}

/**
 * @brief  倍精度FPU命令に与えるオペランドの重みを管理する
 *         特定の命令でタイプを選ぶことは少ないと想定されるため、
 *         共通の重みづけを行う。
 */
CWeightedRandom<UI32>* IFpuDoubleConstraint::pst_WrType = NULL;
std::vector<CFpuWeightParam*> IFpuDoubleConstraint::vst_FPUParam;

// end_of_file
