#ifndef LINKER_H_
#define LINKER_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"
#include	"codeblock.h"

extern CAddressWeight g_FetchAddr;

/**
 *	@brief  メモリの使用領域を管理するクラス。
 */
class CLinker
{
public:

	/**
	 *	@brief   このオブジェクトを生成します。
	 */
	CLinker();
	
	/**
	 *	@brief   このオブジェクトを破棄します。
	 */
	virtual ~CLinker(){}
	
	/**
	 *	@brief   アロケート情報をクリアします。予約アドレス空間はクリアされません。
	 */
	void Reload(void);

	/**
	 *	@brief   アロケート情報を追加します。
	 *	@param   start  確保する開始アドレスを指定します。 
	 *	@param   end    確保する終端アドレスを指定します。。
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool AllocAddress(MEMADDR start, MEMADDR end);

	/**
	 *	@brief   Update available memory areas 
	 *	@param	 None。 
	 *	@return  None。
	 */
	void UpdateAvailableMemory(MEMRANGE mr);
	
	/**
	 *	@brief   Get range for current address which allcated in memory. 
	 *	@param	 start : started address of range.
	 *	@param	 end : end address of range.
	 *	@param	 CurAdd: Current addres which use to check range.
	 *	@return  true: Found needed range.
				 false: Can not find.
	 */
	bool GetAllocatedArea (MEMADDR* start, MEMADDR* end, MEMADDR CurAdd);
	/**
	 *	@brief   Get available memory map. 
	 *	@param	 。 
	 *	@return  。
	 */
	std::map <MEMADDR,MEMADDR> GetAvailableMemory (void) {
		return m_availableMemory;
	}

	/**
	 *	@brief   Get available memory map without mirror. 
	 *	@param	 size: size of free memory needed 
	 *	@return  start address of free size。
	 */
	MEMADDR GetAvailableMemory (UI32 memsize, UI32 align, bool mirrorAddr) {
		std::map <MEMADDR,MEMADDR>::iterator mMitr;
		std::vector <MEMRANGE> vMem = {};
		MEMADDR StarAddr = 0, result = 0;
        UI32 ups = 0;
		UI32 mask = ~ups;
		if(align != 0){
            ups = align - 1;
			mask = ~ups;
		}
		//Collect all free memory with size > memsize and align address
		for (mMitr = m_availableMemory.begin(); mMitr != m_availableMemory.end(); mMitr++) {
            StarAddr = ((mMitr->first + ups) & mask);
			if ((mMitr->second - StarAddr) > memsize) {
				// Do not collect mirror area in case reallocate code block after simulation
				if(mirrorAddr == false && (g_FetchAddr.InRangeMirror(StarAddr, mMitr->second) == true)){
					continue;
				}
				vMem.push_back(MEMRANGE(StarAddr, mMitr->second));
			}		
		}
		//Get start address randomly
		if (vMem.size()) {
			UI32 n = g_rnd.GetRange((UI32)0, (UI32)vMem.size()-1);
			MEMRANGE Mem = vMem[n];
			result = (UI32)Mem.first;
		}
		return result;
	}

	/**
	 *	@brief   アロケート情報を追加します。
	 *	@param   adr  確保する開始アドレスを指定します。 
	 *	@param   len  確保するデータサイズ（byte）を指定します。 
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool Alloc(MEMADDR start, MEMADDR len) {
		return AllocAddress (start, start + len - 1/* = end address */);
	}

	/**
	 *	@brief   指定サイズで自動アロケートします。
	 *	@param   adr  アロケータされた結果（アドレス）が格納されます。 
	 *	@param   len  確保するデータサイズ（byte）を指定します。 
	 *	@param   rng  検索範囲を指定します。
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool AllocSearch(CCodeBlock * pcb, MEMADDR* adr, MEMADDR len, MEMRANGE rng, MEMADDR align = 1);

	/**
	 *	@brief   指定アドレスのエントリを削除します。
	 *	@param   adr  一致した場合のみ削除します 
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool Remove(MEMADDR adr);

	/**
	 *	@brief   予約領域(検証に使えない)を追加します。
	 *           検証に使う予約（割り当て）はAllocateを使用してください。
	 *	@param   range  一致した場合のみ削除します(start, end)。 
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool Reserve(const MEMRANGE& range) {
		return m_rsv.insert(range).second;
	}
	
	/**
	 *	@brief   指定したアドレスとサイズで競合を検証します。
	 *	@param   adr  検証するアドレスを指定します。 
	 *	@param   len  検証するデータサイズ（byte）を指定します。 
	 *	@return  利用可能である場合は真、競合している場合は偽を返します。 
	 */
	bool IsAvailable(MEMADDR start, MEMADDR end);

	/**
	 *	@brief   アロケート情報を標準出力へ表示します（デバッグ用）。
	 */
	void Debug();
	
	/**
	 *	@brief  Print available memory area。
	 */
	void PrintAvailableMem(void);

	std::map<MEMADDR, MEMADDR>	m_availableMemory;
protected:
	std::map<MEMADDR, MEMADDR>	m_hash;	//!<	@brief アロケーションテーブル<アドレス, サイズ>
	std::set<MEMRANGE>			m_rsv;	//!<	@brief 予約領域(アロケートによる結果でなく最初から使用できない領域)
};


#endif /*LINKER_H_*/

