#include "linker.h"

CLinker::CLinker() : m_hash(), m_rsv() {
}

/**
 * 予約領域には２つある。
 * (1) 検証空間として使用不可能な領域。設定ファイルに記載された領域以外(m_rsv)
 * (2) ジェネレーターで確保済の領域
 * つまり(1)+(2)以外が命令配置可能である。
 * 
 * この関数は(1)だけの状態に戻す。
 */
void CLinker::Reload() {
	// アロケーションテーブルを破棄 
	m_hash.clear();
	m_availableMemory.clear();
	// 使用する領域「以外」を全て予約する
	std::set<MEMRANGE>::iterator i;

	MEMADDR a = 0; 
	for (i = m_rsv.begin(); i != m_rsv.end(); ++i) {
		if (a < i->first) {
			Alloc (a, i->first - a);
		}else if (a == (i->first)) {
			// NOP
		} else {
			// a=0, かつi->first=0は先頭から確保するケースとして許容
			MSG_WARN(0, "Invalid instruction area.%x - %x\n", a, i->first);
		}
		a = i->second + 1;
		m_availableMemory.insert(MEMRANGE(i->first, i->second));
	}
	Alloc(a , 0 - a);
}


bool CLinker::AllocAddress(MEMADDR start, MEMADDR end) {	

	/* 新規登録 */
	if (this->IsAvailable(start, end) != true) {
			/* 領域外、または予約済 */
			//this->Debug();
			return false;
	}
	m_hash.insert(MEMRANGE(start, end));
	UpdateAvailableMemory(MEMRANGE(start, end));
	return true;
}

void CLinker::UpdateAvailableMemory (MEMRANGE mr) {
	
	std::map<MEMADDR, MEMADDR> updateSet = {};
	std::map<MEMADDR, MEMADDR>::iterator itr;
	itr = m_availableMemory.upper_bound(mr.first); // The element that has key greater than mr.first or .end()
	if(itr == m_availableMemory.begin())
		return;
	itr--;
    // Element did not involve mr
    if(mr.second < itr->first || mr.first > itr->second)
        return;

    if(mr.first > itr->first) {
		updateSet.insert(MEMRANGE(itr->first, mr.first - 1));
	}
	
	if(itr->second > mr.second) {
		updateSet.insert(MEMRANGE(mr.second + 1, itr->second));
	}
	m_availableMemory.erase(itr);
	for(itr = updateSet.begin(); itr != updateSet.end(); itr++)
		m_availableMemory.insert(MEMRANGE(itr->first, itr->second));
}

bool CLinker::GetAllocatedArea (MEMADDR* start, MEMADDR* end, MEMADDR CurAdd) {
	
	if (this->IsAvailable(CurAdd, CurAdd)) {
		// Current address is in valid area.
		return false;
	}
	
	//!< Update range of cuurent address.
	std::map <MEMADDR, MEMADDR>::iterator lower;
	lower = m_hash.lower_bound(CurAdd);
	(*start) = lower->first;
	(*end) = lower->second;
	return true;
}

bool CLinker::AllocSearch(CCodeBlock * pcb, MEMADDR* start, MEMADDR len, MEMRANGE rng, MEMADDR align){

	MEMADDR ups  =  0;
	MEMADDR mask = ~ups;
	if (align || ((align & (align - 1)) == 0)) {
		//alignは０でもなく、またはalignは２の冪乗である
		ups = align - 1;
		mask = ~ups;
	}

	if (IsAvailable( rng.first, rng.first ) != true) {
		// 開始位置アドレス(start)からlower_boudをとった時、start位置が予約領域内である場合は次の予約領域のスタート位置が返される。
		//（欲しいのは一番最初に見付かる空アドレスなのでこれは期待ではない、欲しいのは「start位置を予約している領域の終端＋１の位置」）
		// 開始位置が予約領域でない場合は、そこから確保できるかチャレンジすれば良い。
		// よってstart位置が予約領域である場合、イテレータをデクリメントする（開始地点が使用済であるということは,m_hashには１つ以上登録がある）
		// デクリメントして得た予約領域の終端直後が空きアドレス。
		std::map <MEMADDR, MEMADDR>::iterator lower;	//<! adr「以上の」要素が最初に現れる位置
		lower = m_availableMemory.lower_bound(rng.first);
		rng.first = lower->first;
	}
	if (rng.first >= rng.second) {
		return false;
	}

	MEMADDR head = (rng.first + ups) & mask;					//<! このアドレス以降に確保する
	MEMADDR end  = head + len - 1;
	auto CorrectAddr = [&](MEMADDR head, MEMADDR end){
		if(g_FetchAddr.InRangeMirror(head, end) == true){
			if(pcb->GetHandlerAddress() > 1 || pcb->GetLabel().find("codeblock") != std::string::npos){
				return true;
			}else{
				return false;
			}
		}else
			return true;
	};

	if (IsAvailable (head, end) && CorrectAddr(head, end) == true) {
		if ( end > rng.second) {
			return false; // 確保許可される最大アドレスを越えているのでこれ以上やっても無意味。
		}else{
			m_hash.insert(MEMRANGE(head, end));
			UpdateAvailableMemory(MEMRANGE(head, end));
			*start = head;
			return true;
		}
	}

	std::map<MEMADDR, MEMADDR>::iterator next;	//<! adr「以上の」要素が最初に現れる位置
	next = m_availableMemory.lower_bound(head);

	if(next == m_availableMemory.end()) {
		next = m_availableMemory.begin();
	}

	SI32 nTryMax = m_availableMemory.size();

		while(nTryMax > 0) {
		head = (next->first + ups) & mask;
		if (IsAvailable(head, head + len - 1)) {
			if ((head + len) > rng.second) {
				return false; // 確保許可される最大アドレスを越えているのでこれ以上やっても無意味。
			}
			if (CorrectAddr(head, head + len - 1) == false){
				nTryMax--;
				next++;
				continue;
			}
			m_hash.insert(MEMRANGE(head, head + len - 1));
			UpdateAvailableMemory(MEMRANGE(head, head + len - 1));
			*start = head;
			return true;
		}

		nTryMax--;
		next++;
		// Last memory range.
		if(next == m_availableMemory.end()) {
			next = m_availableMemory.begin();
		}
	}

	return false;
}


bool CLinker::Remove(MEMADDR adr) {
	std::map<MEMADDR, MEMADDR>::iterator itr;
	UI32 start, end;
	// Update m_hash
	if ((itr = m_hash.find(adr)) == m_hash.end()) {
		// Non-allocated adddress
		return false;
	}

	start = itr->first;
	end = itr->second;
	m_hash.erase(itr);

	// update m_vacancy
	itr = m_availableMemory.upper_bound(adr);
	if(itr != m_availableMemory.end() && end == (itr->first - 1)) {
		end = itr->second;
		itr = m_availableMemory.erase(itr);
	}
	itr--;
	if(itr->second == (start - 1)) {
		start = itr->first;
		itr = m_availableMemory.erase(itr);
	}
	m_availableMemory.insert(MEMRANGE(start, end));

	return true;
}


bool CLinker::IsAvailable(MEMADDR start, MEMADDR end) {
	
	if (m_hash.empty()) {
		return true;
	}
	
	//Debug();
	std::map <MEMADDR, MEMADDR>::iterator lower;	//<! adr「以上の」要素が最初に現れる位置
	std::map <MEMADDR, MEMADDR>::iterator upper;	//<! adr「以上の」要素が最初に現れる位置
	lower = upper = m_hash.lower_bound(start);

	if (m_hash.begin()->first < start) {	
		lower--;
		if (lower->second >= start) {
			return false;
		}
	}

	if (upper != m_hash.end()) {
		if (upper->first <= end) {
			return false;
		}
	} else {
		MEMADDR a = 0;
		if ( ~a < end ) {
			return false;
		}
	}

	//std::map<MEMADDR, MEMADDR>::iterator itrVac;
	//itrVac = m_availableMemory.lower_bound(start);
	//if(itrVac != m_availableMemory.end()) {
	//	if(itrVac->second < end){
	//		return false;
	//	}
	//}
	return true;
}


void CLinker::Debug(void) {
	std::map <MEMADDR,MEMADDR>::iterator itr;
	int i = 0;
	std::cout << "--- Allocation table ---" << std::endl;
	for (itr = m_hash.begin(); itr != m_hash.end(); itr++) {
		std::cout  << std::setw(2) << std::setfill('0') << std::dec << i << ':' 
		<< std::hex << std::setw(8) << std::setfill('0') << itr->first << '-' 
		<< std::hex << std::setw(8) << std::setfill('0') << itr->second << std::endl;
		i++;
	}
}

void CLinker::PrintAvailableMem(void) {
	std::map <MEMADDR,MEMADDR>::iterator itr;
	int i = 0;
	std::cout << "--- Availabel Memory range ---" << std::endl;
	for (itr = m_availableMemory.begin(); itr != m_availableMemory.end(); itr++) {
		std::cout  << std::setw(2) << std::setfill('0') << std::dec << i << ':' 
		<< std::hex << std::setw(8) << std::setfill('0') << itr->first << '-' 
		<< std::hex << std::setw(8) << std::setfill('0') << itr->second << std::endl;
		i++;
	}
}