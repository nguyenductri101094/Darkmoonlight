#ifndef IFSYSREG_H_
#define IFSYSREG_H_

#include "rtg_common.h"
#include "rnd_gen.h"


class ISysReg
{
public:
	ISysReg() {}
	virtual ~ISysReg() {}
	
	virtual UI32 GetId() = 0;
	virtual std::string GetName() = 0;
	virtual bool RequireInit() = 0;
	virtual bool Loadable() = 0;
	virtual bool Storable() = 0;
	virtual bool IsNC() = 0;
	virtual bool IsVC() = 0;
	virtual bool IsTC() = 0;
	virtual bool ParseCsvRecord(std::vector<std::string> toks) = 0;
	virtual UI32 GetWriteMask() = 0;
	virtual void Dump(std::ostream& os) { os << "Not implemented." << std::endl;}
	virtual void GetRegId(UI32* RegId){}
	virtual bool IsInitTC() = 0;
	virtual bool IsInitNC() = 0;
	virtual bool IsInitVC() = 0;
	virtual void GetSelReg(UI32* SelId) = 0;
	virtual void GetRegName(std::string* RegName) = 0;
	virtual void GetTcInit(UI32* tc) = 0;
	virtual void GetNcInit(UI32* nc) = 0;
	virtual void GetVcInit(UI32* vc) = 0;

public:
	static ISysReg* New();
};


class ISysRegSet
{
public:

	/**
	 * @brief  このオブジェクトを構築します
	 */
	ISysRegSet() : m_setSr(){}
	
	
	virtual ~ISysRegSet() {
		Clear(); /* here does not work polymophism */
	}
	
	virtual void Clear() {
		std::map<UI32,ISysReg*>::iterator itr;
		for (itr = m_setSr.begin(); itr != m_setSr.end(); itr++) {
			delete itr->second;
		}
		m_setSr.clear();
	}

	virtual std::map<UI32,ISysReg*> GetInitalList() {
		std::map<UI32,ISysReg*> retMap;
		std::map<UI32,ISysReg*>::iterator itr;
		
		for (itr = m_setSr.begin(); itr != m_setSr.end(); itr++) {
			if (itr->second->RequireInit()) {
				std::pair<std::map<UI32,ISysReg*>::iterator,bool> result;
				result = retMap.insert(std::pair<UI32,ISysReg*>(itr->first, itr->second));
				_ASSERT(result.second);
			}
		}
		return retMap;
	}

	/**
	 * @brief	NativeコンテキストのSELID/REGIDのリストを作成する。
	 * @param flags 実装で定義する
	 * @return レジスタインデックス
	 */
	virtual bool MatchContext(UI32 flag, std::vector<BKREG>* vec) = 0;	
	
	/**
	 * @brief レジスタを重みランダムで選択する。
	 * @param flags 実装で定義する
	 * @return レジスタインデックス
	 */
	virtual UI32 Select(UI32 flags = 0) = 0;
	
	
	/**
	 * @brief レジスタが搭載されているか確認する。
	 * @param id レジスタID
	 * @return 搭載されていれば true。
	 */
	virtual bool IsLoadable(UI32 regid, UI32 selid) = 0;
	
	
	/**
	 * @brief レジスタへストアが可能か確認する。
	 * @param id レジスタID
	 * @return ストアが可能ならば true。
	 */
	virtual bool IsStorable(UI32 regid, UI32 selid) = 0;
	
	
	/**
	 * @brief レジスタ情報をパースする。
	 *        1レコードについてCSVのパースを行い、
	 *        各カラムの解釈方法はアーキテクチャ部に移譲する。 
	 * @param file ファイルパス
	 * @return 失敗時は偽を返す
	 */
	virtual bool ParseCsv(std::string file);
	
		
	/**
	 * @brief レジスタが名を取得する。
	 * @param id レジスタID
	 * @return レジスタが名。
	 */
	virtual std::string GetName(UI32 regid, UI32 selid) {
		std::map<UI32,ISysReg*>::iterator itr = m_setSr.find((selid << 5) + regid) ;
        if (itr != m_setSr.end()) {
            return itr->second->GetName();
        }
        return "" ; 
    }

    /**
    * @brief レジスタが名を取得する。
    * @param id レジスタID
    * @return レジスタが名。
    */
    virtual UI32 GetNcInit(UI32 regid, UI32 selid) {
        UI32 value = 0;
        std::map<UI32, ISysReg*>::iterator itr = m_setSr.find((selid << 5) + regid);
        if (itr != m_setSr.end()) {
            itr->second->GetNcInit(&value);
        }
        return value;
    }

	/**
	 * @brief [デバッグ用]
	 */
	virtual void Dump(std::ostream& os = std::cout) {
		std::map<UI32,ISysReg*>::iterator itr;
		for (itr = m_setSr.begin(); itr != m_setSr.end(); itr++) {
			itr->second->Dump(os);
		}
	}

	/**
	 * @brief Get the mask that specifies writable bit
	 * @param id Reg number (regid), group number (selid)
	 * @return Mask bit
	 */
	virtual UI32 GetWriteMask(UI32 regid, UI32 selid) = 0;

	/**
	 * @brief Get the available context.
	 * @param id Reg number (regid), group number (selid)
	 * @return Flag specifying all available context
	 */
	virtual bool GetContext(UI32 regid, UI32 selid, UI32 &context) = 0;

public:
	static ISysRegSet* New();

protected:
	std::map<UI32,ISysReg*> m_setSr;
};
#endif /*IFSYSREG_H_*/
