#include "sim_ctrl.h"
#include "instruction.h"
#include "ifbreakparam.h"
#include "ifblk_manager.h"
#include "adr_selector.h"
#include "insid_set.h"
#include "ifinsset.h"

extern std::shared_ptr<CGeneratorConfig>	g_cfg;
extern std::unique_ptr<ISysRegSet>	g_srs;
extern std::unique_ptr<IException>          g_exp;
extern std::shared_ptr<CAssemblerSourceFile>    g_asf;
extern std::unique_ptr<IBlockManager>			g_mgr;
extern std::shared_ptr<CGeneratorProfile>		g_prf;

#define LOGSW_INS_SIM		(!defined(NDEBUG) && 1)
#define LOGSW_REGULATION	(!defined(NDEBUG) && 0)
#define	EXCEPTION_MIN_PROBABLY	100
#define	NewINS(_CB_, _INS_)		((_CB_)->AddOpeCode(_INS_))

CSimulatorControl::CSimulatorControl() {
}

CSimulatorControl::~CSimulatorControl() {
	if (m_pSim) {
		delete m_pSim;
		m_pSim = NULL;
	}
}


/**
 * @brief	シミュレーターを初期化します。
 */	
bool CSimulatorControl::Init(std::string& iniPath) {
	delete m_pSim;
	m_pSim = ISimulator::New();
	if(m_pSim->Init(iniPath) == false) {
		return false;
	}

	m_nWRMemOffset    = 16;	// Offset for initializing WR at beginning
	m_nWRMemBlockCount = 0;
	m_bNewWRMemBlock = false;

	m_bRollback = false;
	m_pRollbackIns = NULL;

	m_nBlockSimCount = 0;
	m_nDeassertIdx = 0;
	m_bNocode = false;
	m_nCurrentChannel = 0;
	m_nReplaceTime	= 10;
	m_pInsCheckedInterrupt = NULL;
	m_nCauseCode = 0;

    m_MPUlist = g_mgr->GetMPUInfor();
	return (m_pSim != NULL);
}


bool CSimulatorControl::ReadySimulation (ISimulationParam* pSp, IBlockSimParam* pBsp) {
	
	_ASSERT(pBsp);
	_ASSERT(m_pSim);
	
	// Get Next Thread
    m_pSim->ReadPC(&pBsp->lpc);

	// PC Update(physical)
	UI64 pa1, pa2;
	UI64 ps1, ps2;
	if (m_pSim->MmuTransferAddr(true, 0, (UI64)pBsp->lpc, 1, MXU_ACC_DONTCARE, &pa1, &ps1, &pa2, &ps2) != true) {
		MSG_ERROR(0, "Internal error at address transfer %s(%d).\n", __FUNCTION__, __LINE__);
		return false;
	}
	pBsp->ppc = (UI32)pa1;
		
	//!< Search target block
	if ((pBsp->pCodeBlock = pSp->pAsmSrcObj->Search(pBsp->ppc)) == NULL) {
		MSG_ERROR(0, "Not found address in code. PC={LA=%08X, PA=%08X}\n", pBsp->lpc, pBsp->ppc);
		return false;
	}
	
	pBsp->result = 0;
	
	return true;
}


	/**
	 * @brief  check target block valid or not
	 * @return true if target PC is valid
					else return false
	 */
bool CSimulatorControl::CheckTatgetPC (ISimulationParam* pSp, CCodeBlock* pCB, IInstruction* pIns, UI32 PC) {

	PC &= 0xfffffffe;

	// Check whether PC has belong to I area or not
	if(g_prf->IsFetchMem(PC) == false)
		return false;

	// Get target code block
	CCodeBlock* TargetBlock = g_asf->GetNextRandomCodeBlock();

	// Get function target block of JARL 
	if(pIns != nullptr && (pIns->GetId() == INS_ID_JARL || pIns->GetId() == INS_ID_JARLSD22) && pIns->GetReverse() == nullptr){
		std::string Targetlabel = pIns->opr(0)->GetLabel();
		std::vector<INode*> vFuncBlock = pSp->pAsmSrcObj->GetFunctionBlock();
		std::vector<INode*>::iterator itr;
		for(itr = vFuncBlock.begin(); itr != vFuncBlock.end(); itr++)
			if((*itr)->GetName() == Targetlabel)
				TargetBlock = static_cast<CCodeBlock*>(*itr);				
	}

	if(TargetBlock == NULL)
		return false;

    // If MIP has occured. It do not occur until EBASE is randomed
    if (IsMIPexception(PC, TargetBlock->GetCodeSize()))
        return false;

	if(g_asf->CheckValidNextBLock(TargetBlock, pIns, PC)){
		TargetBlock->SetAddress(PC);
		if (g_asf->MakeLabelHash(pCB) == false || g_asf->LabelResolve(pCB) == false) {
			// codeblock overwrap with next block.
			std::runtime_error excep("Fail to regulate codeblock in function CheckTatgetPC() \n ");
			throw excep;
		}
		return true;
	} else
		return false;
}

/**
* @brief  allocate target code block at PC address
* @return true if allocate successs
*/
bool CSimulatorControl::AllocateCodeBlockAtPCaddress(CCodeBlock* pCB, UI32 addr) {
    // Check whether PC has belong to I area or not
    if (g_prf->IsFetchMem(addr) == false)
        return false;

    // If MIP has occured. It do not occur until EBASE is randomed
    if (IsMIPexception(addr, pCB->GetCodeSize()))
        return false;

    g_asf->GetLinker()->Remove(pCB->GetAddress());
    // Check whether memory enough to allocate code block or not
    if (g_asf->GetLinker()->Alloc(addr, (pCB->GetCodeSize() + pCB->GetBlockGap())) == false)
        return false;

    pCB->SetAddress(addr);
    // Calculate address and label for instructions in code block
    if (g_asf->LinkCodeBlock(pCB) == false) {
        // codeblock overwrap with other block.
        std::runtime_error excep("Fail to regulate codeblock in function AllocateCodeBlockAtPCaddress() \n ");
        throw excep;
        return false;
    }

    return true;
}

/**
* @return new address of codeblock
*/
bool CSimulatorControl::FindNewAddressforCodeBlock(CCodeBlock* pCB) {
    UI32 trytime = 10;
    UI32 address = pCB->GetAddress();
    UI32 total_size = pCB->GetCodeSize() + pCB->GetBlockGap();
    CLinker* pLinker = g_asf->GetLinker();

    while (trytime != 0 && AllocateCodeBlockAtPCaddress(pCB, address) == false) {
        address = pLinker->GetAvailableMemory(total_size, 0x2, false);
        trytime--;
    }

    if (trytime == 0) {
        return false;
    }

    return true;
}

bool CSimulatorControl::RegulateBranchCondition(ISimulationParam* pSp, CCodeBlock* pCB, IInstruction* pIns) {
	
	UI32 updatePC = 0;

	// Support random XXRET instruction
	// Lamda function to check value in XXPC
    auto ChainXXRET = [&](IInstruction *src) {
        UI32 xxpc = 0, selId = 0, regId = 0;
        UI32 srcId = src->GetId();
        switch (srcId) {
            case INS_ID_CTRET:
                selId = 0;
                regId = 16;
                break;

            case INS_ID_EIRET:
            {
                selId = regId = 0;
                if (IsGuestMode()) {
                    selId = 9;
                    regId = 0;
                }
            }
            break;

            case INS_ID_FERET:
            {
                selId = 0;
                regId = 2;
                if (IsGuestMode()) {
                    selId = 9;
                    regId = 2;
                }
            }
            break;

            case INS_ID_DBRET:
                UI32 dir0;
                m_pSim->ReadNcReg(&dir0, 20, 3);
                if (dir0 & 0x1) {
                    selId = 3;
                    regId = 18;
                } else
                    return true; // PIE exception 
                break;

            default:
                break;
        }

		m_pSim->ReadNcReg(&xxpc, regId, selId);

		if (CheckTatgetPC(pSp, pCB, src, xxpc) == false){
			PrepareDeletedIns(pCB, src);
			g_mgr->ReplaceInsbyOther(pCB, src, src->GetLen());
			return false;
		} else {
			return true;
		}
	};

	// Lamda function to adjust register for DISPOSE and JMP/JARL[reg] instruction
	auto Chain_JmpReg = [&] (IInstruction* src){
  
		// Get correct register content target address
		UI32 regJmpPos = 0;
		if(src->GetId() == INS_ID_DISPOSE_R3)
			regJmpPos = 2;

		UI32 reg = src->opr(regJmpPos)->Idx();
		
		// Collect all register except SP
		std::vector<UI32> vReg;
		for(UI32 i = 1; i < 32; i++)
			if(i != 3 && i != reg)
				vReg.push_back(i);
		// Add SP in case JMP[reg]
		if((src->GetId() == INS_ID_JMP) || src->GetId() == INS_ID_JARL)
			vReg.push_back(3);

		UI32 regVal = 0;
		m_pSim->ReadGrReg(&regVal, reg, 0);
		
		// Bit 0 of the address is masked to “0”
		regVal = regVal & 0xfffffffe;

		while (CheckTatgetPC(pSp, pCB, src, regVal) == false){	
			if(vReg.size() == 0){
				PrepareDeletedIns(pCB, pIns);
				g_mgr->ReplaceInsbyOther(pCB, pIns, pIns->GetLen());				
				return false;
			}
			reg = vReg.back();
			vReg.pop_back();
			m_pSim->ReadGrReg(&regVal, reg, 0);
			regVal = regVal & 0xfffffffe;
		}
		// JARL jump to function block
		if(src->GetId() == INS_ID_JARL && src->GetReverse() == nullptr && src->opr(regJmpPos)->Replace(reg)){
			return true;
		}
		
		if(src->opr(regJmpPos)->Replace(reg) == false){
			PrepareDeletedIns(pCB, src);
			g_mgr->ReplaceInsbyOther(pCB, src, src->GetLen());
			return false;
		}
		return true;
	};
	
	// Calculate target Pc of JMP Instruction
	auto CalculatePC = [&] (IInstruction* pIns){
		UI32 currentPC, updatePC, offSet;
		offSet = ((UI32)*(pIns->opr(0)));
		//Branch instruction will be calculate with current PC
		m_pSim->ReadPC(&currentPC);
		updatePC = currentPC + offSet;
		return (updatePC & 0xFFFFFFFE);
	};

	// Support JMP behavior instruction
	auto Chain_jmpWithDisp = [&] (IInstruction* src, std::string label) {
		// It will be adjust in regulation value 
		if(src->GetId() == INS_ID_JMPD32){
			if(m_bNocode == true)
				label = GetTContext() + "th_end_syncCheck_DB_mode";
			src->SetJumpTargetLabel(label);
			src->AppendComment(label.c_str());
			src->opr(0)->SetLabel(label);
			return true;
		}

		// JARL jump to function block
		// Check function target of JARL disp22 -- sure that target value is in supported range 
		if(src->GetId() == INS_ID_JARLSD22 && src->GetReverse() == nullptr){
			std::string sJmpTarget = src->opr(0)->GetLabel();
			// Check target of JARL jmp to function	
			if(sJmpTarget.size() ){
				SI32 nJump_Address = g_asf->SearchAddress(sJmpTarget);
				if (CheckTatgetPC(pSp, pCB, src, nJump_Address) == false){
					// Set jmp to next random code
					src->SetReverse(NOP());
					src->opr(0)->RemoveLabel(); //Clear function label
				} else {
					UI32 currentPC, offSet;
					m_pSim->ReadPC(&currentPC);	
					offSet = nJump_Address - currentPC;
					if(src->opr(0)->Replace(offSet))
						return true;
					}
			}
		}
		// Check random block target for JARL next block
		if((src->GetId() == INS_ID_JARLSD22 && src->GetReverse() != nullptr) || (src->GetId() == INS_ID_JRSD22)){

			// This case for JARL jmp to function in common block. Other jmp in common block jump inside block by ChainBCondSequence
			// GetReverse == NULL but distance is far, so FROG set SetReverse in LabelResolve
			// Expected jump inside
			if(pCB->GetLabel().find("callt") != std::string::npos){
				src->opr(0)->Replace(src->GetLen());
				src->SetConstraint(false);
				return true;
			}
			UI32 currentPC, updatePC, offSet;
			offSet = ((UI32)*(src->opr(0)));
			m_pSim->ReadPC(&currentPC);
			// Sign-extended to word length
			if((offSet >> 21) & 1)
				offSet = offSet | 0xFFE00000;
			//Bit 0 of the 22-bit displacement is masked to “0”.
			offSet = offSet & 0xfffffffe;
			updatePC = offSet + currentPC;

			UI32 countTime = 20;
			while (CheckTatgetPC(pSp, pCB, nullptr, updatePC) == false){
				pIns->opr(0)->RandomTarget();
				offSet = ((UI32)*(pIns->opr(0)));
				// Sign-extended to word length
				if((offSet >> 21) & 1)
					offSet = offSet | 0xFFE00000;
				//Bit 0 of the 22-bit displacement is masked to “0”.
				offSet = offSet & 0xfffffffe;
				updatePC = offSet + currentPC;
				countTime--;
				if(countTime == 0){
					src->opr(0)->Replace(src->GetLen());
					src->SetConstraint(false);
					pCB->Update();
					return false;
				}
			}

			src->SetConstraint(false);
		}
		// JMP32/JARL32 Can not across section
		if(src->GetId() == INS_ID_JARLD32 || src->GetId() == INS_ID_JRD32)	{
			// jump to next instruction in callt codeblock
			if (pCB->GetLabel().find("callt") != std::string::npos) {
				src->opr(0)->Replace(src->GetLen());
				src->SetConstraint(false);
				return true;
			}

			std::string cbn = pCB->GetName();
			char buff[1024];
			UI32 pInsPos = pCB->GetIndex(pIns);
			std::sprintf(buff, "%s_jmpto_%d", cbn.c_str(), pInsPos);
			std::string label(buff);
			UI32 deadCode = 2;
			if(pCB->GetHandlerAddress() >= IBlockManager::ADR_VECTOR_SYSERR 
				&& pCB->GetHandlerAddress() < IBlockManager::ADR_VECTOR_NUM)
				deadCode = 0;
			UI32 limit_jmp = pCB->GetInstructionNum() - 1 - deadCode; // Remove deadcode		
			UI32 try_time = limit_jmp - pInsPos;
			if(try_time == 0)
				try_time = 1;
			UI32 pos = g_rnd.GetRange(pInsPos+1, limit_jmp);
			while(pCB->at(pos)->InSequence()){
				pos = g_rnd.GetRange(pInsPos+1, limit_jmp);
				try_time--;
				if(try_time == 0){
					pIns->opr(0)->Replace(pIns->GetLen());
					return true;
				}
			}
			pCB->at(pos)->SetLabel(buff);
			pIns->opr(0)->SetLabel(buff);
		}
		return true;
	};

	// Support BCond instruction
	auto Chain_BCondIns = [&] (CCodeBlock* Target) {
		if(Target == NULL){
			pIns->opr(0)->Replace(pIns->GetLen());
			pIns->opr(0)->RemoveLabel();
			pIns->SetConstraint(false);
			pCB->Update();
			return;
		}
		// Check target PC for BCond
		updatePC = CalculatePC(pIns);
		UI32 countTime = 20;
		while (CheckTatgetPC(pSp, pCB, nullptr, updatePC) == false){
			pIns->opr(0)->RandomTarget();
			updatePC = CalculatePC(pIns);
			countTime--;
			pIns->SetTaken(true);
			if(countTime == 0){
				pIns->opr(0)->Replace(pIns->GetLen());
				pIns->opr(0)->RemoveLabel();
				break;		
			}
		}
		pIns->SetConstraint(false);
	};

	// Main operation
	if (pIns->HasBranchConstraint()) {

		// Get target code block
		std::string nextlabel;
		UI32 pInsId = pIns->GetId();
		CCodeBlock* Target = g_asf->GetNextRandomCodeBlock();		
		if(Target == NULL)
			nextlabel = GetTContext() + "th_end_sync";
		else
			nextlabel = Target->GetLabel();

		// Instruction has special kind Forwarding: need some instruction 
		if(pIns->GetInsNeed().size() != 0){
			pIns->SetJumpTargetLabel(nextlabel);
			//pIns->SetConstraint(false);
			return false;
		}
		switch (pInsId) {
		case INS_ID_CTRET:
		case INS_ID_EIRET:
		case INS_ID_FERET:
		case INS_ID_DBRET:
			pIns->SetConstraint(false);
			ChainXXRET(pIns);
			break;

		case INS_ID_DISPOSE_R3:
		case INS_ID_JARL:
		case INS_ID_JMP:

			pIns->SetConstraint(false);
			if(Chain_JmpReg(pIns) && pInsId == INS_ID_DISPOSE_R3)
				pIns->SetJumpTargetLabel(nextlabel);
			break;

		case INS_ID_JARLSD22:
		case INS_ID_JARLD32:
		case INS_ID_JMPD32:
		case INS_ID_JRSD22:
		case INS_ID_JRD32:
			Chain_jmpWithDisp(pIns, nextlabel);
			pIns->SetConstraint(false);
			break;

		default:
			{
			Chain_BCondIns(Target);
			break;
			}
		}

	    return true;
	} else { //Not branch instruction
			return false;
		}
}

bool CSimulatorControl::MaskSysRegLoad (CCodeBlock* pCB, IInstruction *pIns)
{
	auto ReadSpecialSReg = [&] (UI32 &val, UI32 regId, UI32 selId) -> bool{
		UI32 srVal;
		if (selId == 0)
		{
			if(regId == 8){ // FPST(0,8)
				// FPST reflects FPSR (0, 6) register.
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				UI32 valXC = (srVal >> 10) & 0x3F;
				UI32 valXP = (srVal >> 0) & 0x1F;
				val = (valXC << 8) | (valXP << 0);
				//if (FPU_SEL_FPU20) {	// FPU-2.0 // TODO: Support FPU-2.0
				   // UI32 valPR = (srVal >> 16) & 0x1;
				   // val = ( valPR << 15 ) | (valXC << 8) | (valXP << 0) ;
				//} else {											// FPU-3.0
					UI32 valIF = (srVal >> 22) & 0x1;
					val = (valXC << 8) | ( valIF << 5 ) | (valXP << 0) ;
				//}
				return true;
			}else if(regId == 9){   // FPCC(0,9)
				// FPCC reflects FPSR (0, 6) register.
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				val = (srVal >> 24) & 0xFF;
				return true;
			}else if(regId == 10){  // FPCFG(0, 10)
				// FPCFG reflects FPSR (0, 6) register.
				UI32 valRM, valXE;
				m_pSim->ReadTcReg(&srVal, 6, 0, 0);
				valRM = (srVal >> 18) & 0x3;
				valXE = (srVal >> 5) & 0x1F;
				val = (valRM << 8) | (valXE << 0);
				return true;
			}
		}
		return false;
	};

	auto GenerateRandomVal = [](UI32 mask){
		UI32 nMask = 1;
		UI32 nCount = 0;
		UI32 randomVal = 0;
		UI32 nResult = 0;

		nCount	= 0;
		nMask = 1;
		while(nMask){
			if(mask & nMask)
				nCount++;
			nMask <<= 1;
		}
		// Generate a random number in range of (0; (2^nCount) - 1)
		randomVal = g_rnd.GetRange((UI32) 0, (UI32) ((1 << nCount) - 1 ));

		nCount	= 0;
		nMask	= 1;
		while(nMask){
			if(mask & nMask){
				nResult |= (randomVal & 1) << nCount;
				randomVal >>= 1;
			}
			nCount++;
			nMask <<= 1;
		}
		return nResult;
	};


    auto IsNeededMPUProtect = [=](UI32 sr) -> bool {
        UI32 mip_demand_gm = g_prf->m_mpdemand[0];
        UI32 mpla_gm = 0, mpua_gm = 0;
        UI32 pc;
        UI32 curMPIDX;
        UI32 svlock = 0, hvcfg = 0, pswh = 0;

        if ((GetPSW() & 0x40000000))
            return false;

        m_pSim->ReadNcReg(&curMPIDX, 16, 5);
        m_pSim->WriteNcReg(mip_demand_gm, 16, 5);
        m_pSim->ReadNcReg(&mpla_gm, 20, 5);
        m_pSim->ReadNcReg(&mpua_gm, 21, 5);
        m_pSim->WriteNcReg(curMPIDX, 16, 5);
        m_pSim->ReadNcReg(&svlock, 8, 1);
        m_pSim->ReadNcReg(&hvcfg, 16, 1);
        m_pSim->ReadNcReg(&pswh, 15, 0);

        m_pSim->ReadPC(&pc);

        if (mpla_gm <= pc && pc <= mpua_gm) {
            return false;
        }
        // SPID, MPM, MPLA, MPUA, MPAT, MPIDn can not be update when SVLOCK.SVL = 1
        if (svlock != 0
            && ((sr >> 5) == 0x5 /* MPU SRs */ || (sr == (1 * 32) + 0)  /* SPID */))
            return false;

        if ((hvcfg & 0x1) != 0 && (pswh & 0x80000000) == 0)
            return false;

        return true;
    };
	// lambda: Check whether instruction is first regulation code.
	auto IsFirstRegulationIns = [](CCodeBlock* pCB, IInstruction* pIns){
		IInstruction *pPrev;
		UI32 nInsPos;

		// The first instruction of CB
		nInsPos = pCB->GetIndex(pIns);
		if(nInsPos == 0)
			return true;

		// Not the first regulation instruction
		pPrev = pCB->at(nInsPos - 1);
		if(pPrev->GetRegulationTarget() != NULL)
			return false;

		return true;
	};


	const std::string &mne = pIns->GetMne();
	//if(pIns->Behavior(IInstruction::LOAD_SR) && pIns->opr(0)->GetConstraint() == NULL)
	if(mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr")	{
		const UI32 NO_MASK = 0xffffffff;
		IValConstraint *pConst = pIns->opr(0)->GetConstraint();

		UI32 sr = (UI32) *(pIns->opr(1));
		UI32 regId = (sr & 0x1f);
		UI32 selId = (sr >> 5);
		UI32 nMask;

		nMask = g_srs->GetWriteMask(regId, selId);
		if(nMask != NO_MASK){
			UI32 grVal, srVal;

			if( pConst == NULL || !pConst->GetType(IValConstraint::DUMMY))
			return true;

			//m_pSim->ReadGrReg(&grVal, pIns->opr(0)->Idx(), 0/*htid#0*/);
			grVal = GenerateRandomVal(nMask);

			// Special cases FPST(0,8), FPCC(0,9), FPCFG(0, 10)
			if(!ReadSpecialSReg(srVal, regId, selId)){
				UI32 nContext;
				const UI32 VC = 1 << 1; //CSysReg::SR_CONTEXT_VC
				const UI32 TC = 1 << 2; //CSysReg::SR_CONTEXT_TC
				const UI32 CONTEXT_END = 1 << 3; //CSysReg::SR_CONTEXT_END

				if(mne == "ldtc.sr")
					nContext = TC;
				else if (mne == "ldvc.sr")
					nContext = VC;
				else
				if(!g_srs->GetContext(regId, selId, nContext))
					nContext = CONTEXT_END;

				m_pSim->ReadNcReg(&srVal, regId, selId);
	
			}
			grVal = (grVal & nMask) | (srVal & ~nMask);
			pIns->opr(0)->RemoveConstraint(); // Remove dummy constraint
			pIns->opr(0)->SetConstraint(new INumConstraint(grVal, grVal));
		} else {

			// Ajust MPIDX to avoid regions that used for MIP/MDP setting
			if(regId == 16 && selId == 5 /* MPIDX */ && pIns->GetRegulationTarget() == NULL) {
				UI32 regVal, newVal;
				m_pSim->ReadGrReg(&regVal, pIns->opr(0)->Idx(), 0);
				
				newVal = regVal;
				while(g_prf->IsWorkMPURegionByIdx(newVal)) {
					newVal = g_rnd.GetRange((UI32)0, (UI32)g_hwInfo.m_mpnum - 1);
				}

				if(newVal != regVal){
					pIns->opr(0)->SetConstraint(new INumConstraint(newVal, newVal));
				}
			}

			// Purpose Improving ONLY
			// Improve ratio of XXRET by find suitable value for XXPC
			if(((selId == 0 && (regId == 0 || regId == 2 || regId == 16)) || (selId == 3 && regId == 18)) 
				&& pIns->GetRegulationTarget() == nullptr) {
				UI32 OprIdx = pIns->opr(0)->Idx();
				UI32 i = OprIdx, maxIdx = 32;
				while(i < maxIdx) {
					UI32 startAddr = 0;
					m_pSim->ReadGrReg(&startAddr, i, 0);
					if(g_asf->GetLinker()->IsAvailable(startAddr, startAddr + pCB->GetCodeSize()) == true){
						pIns->opr(0)->Replace(i);
						return true;
						}
					i++;
					if(i == maxIdx && (maxIdx - OprIdx) > 0 && (maxIdx - OprIdx) < 31){
						maxIdx = OprIdx;
						i = 1;
						}
					}
				}
			}

        pConst = pIns->opr(0)->GetConstraint();

        if ((GetPSW() & 0x40000000) == 0) {
            UI32 oldValue = 0, newValue = 0, PC = 0;
            m_pSim->ReadPC(&PC);

            if (pConst != nullptr) {
                newValue = pConst->SelectValue();
            } else {
                m_pSim->ReadGrReg(&newValue, pIns->opr(0)->Idx(), 0);
            }

            // Backup old value of system register
            switch (sr) {
                case (0 * 32 + 5):
                    oldValue = m_pSim->GetPSW();
                    break;
                case (1 * 32 + 0):
                {
                    oldValue = m_pSim->GetSPID_MPIDn();

                    char str[8];
                    std::string name;
                    UI32 mpidn = 0;
                    UI32 spid = newValue & 0x1f;
                    newValue = 0;
                    for (UI32 i = 0; i < 8 /*MPID_NUM*/; i++) {
                        sprintf(str, "MPID%d", i);
                        name = std::string(str);
                        m_pSim->ReadSysRegister(&mpidn, name, 0);
                        if (spid == mpidn) {
                            newValue |= 1 << i;
                        }
                    }
                }
                    break;
                case (5 * 32 + 0):
                    oldValue = m_pSim->GetMPM();
                    newValue &= 0x7;
                    break;
                case (5 * 32 + 17):
                    oldValue = m_pSim->GetMPBK();
                    newValue &= 0x1;
                    break;
                default:
                    oldValue = 0xffffffff;
                    break;
            }

            if (oldValue != 0xffffffff) {
                // Assign new value for system register
                switch (sr) {
                    case (0 * 32 + 5):
                        m_pSim->SetPSW(newValue);
                        break;
                    case (1 * 32 + 0):
                        m_pSim->SetSPID_MPIDn(newValue);
                        break;
                    case (5 * 32 + 0):
                        m_pSim->SetMPM(newValue);
                        break;
                    case (5 * 32 + 17):
                        m_pSim->SetMPBK(newValue);
                        break;
                    default:
                        std::runtime_error excep("Fail to regulate system register\n ");
                        throw excep;
                        break;
                }

                // MIP do not occur at SYNCI
                if (IsMIPexception(PC + 4, 0x4)) {
                    if (sr == (1 * 32 + 0) /*SPID*/) {
                        pIns->opr(0)->SetConstraint(new INumConstraint(m_pSim->GetSPID(), m_pSim->GetSPID()));
                    } else {
                        pIns->opr(0)->SetConstraint(new INumConstraint(oldValue, oldValue));
                    }
                }

                // Restore old value for system register
                switch (sr) {
                    case (0 * 32 + 5):
                        m_pSim->SetPSW(oldValue);
                        break;
                    case (1 * 32 + 0):
                        m_pSim->SetSPID_MPIDn(oldValue);
                        break;
                    case (5 * 32 + 0):
                        m_pSim->SetMPM(oldValue);
                        break;
                    case (5 * 32 + 17):
                        m_pSim->SetMPBK(oldValue);
                        break;
                    default:
                        std::runtime_error excep("Fail to regulate system register\n ");
                        throw excep;
                        break;
                }
            }
        } 
    }

	IInstruction *pTarget = pIns->GetRegulationTarget();
	if(pTarget != NULL) {
		UI32 nTargetId = pTarget->GetId();
		if((nTargetId == INS_ID_LDSR || nTargetId == INS_ID_LDTC_SR || nTargetId == INS_ID_LDVC_SR) 
			&& IsFirstRegulationIns(pCB, pIns)) {
			UI32 sr = (UI32) *(pTarget->opr(1));
			if(((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12 ))/*MPU SRs*/ 
				|| (sr == (1 * 32) +  0)  /* SPID */ 
				|| (sr == (0 * 32) +  5)  /* PSW */) {
				if(!IsNeededMPUProtect(sr)) {
					// Delete adjustment code
					UI32 idx = pCB->GetIndex(pIns);
					UI32 nDelete = 0;
					while(pIns != pTarget) {
						if(pIns->GetRegulationTarget() == pTarget 
							&& pIns->GetComment().find("privilege") == std::string::npos
							&& pIns->GetComment().find("Regulation code") == std::string::npos) {
							pIns->DirMoveTo(pCB->at(idx+1));
							pCB->Remove(pIns);
							nDelete++;
						} else
							idx++;
						pIns = pCB->at(idx);
					}
					if(nDelete) {
						return false;
					}
				} 
			}
		}
	}

	return true;
}

bool CSimulatorControl::RegulateValueConstraint(ISimulationParam* pSp, CCodeBlock* pCB, IInstruction* pIns) {

	_ASSERT(pCB);
	_ASSERT(pIns);

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	bool bForce = pIns->IsForcedAdjust();
	r.SetForce(bForce);
	UI32 insid = pIns->GetId();
	if ( insid == INS_ID_LDV_DW_2REG || insid == INS_ID_LDV_QW_2REG || insid == INS_ID_LDV_W_2REG || insid == INS_ID_LDVZ_H4_2REG 
		|| insid == INS_ID_STV_DW_2REG || insid == INS_ID_STV_QW_2REG || insid == INS_ID_STV_W_2REG || insid == INS_ID_STVZ_H4_2REG ) {
		return false;
	}
	// Needed to RE-ASM when removing instruction
	if (!MaskSysRegLoad(pCB, pIns)) 
		return true;

	//       (a)  (b)  (c)
	// oprxx r1,  r4,  r1
	// 
	//       「(a)のr1」と「(c)のr1」に値制約がある場合、
	//        制約が矛盾する場合これを解決出来ない。
	//        「(c)のr1」制約は削除する->（a）の制約と同じになる。
	// 

	std::bitset<32> grlist(0);
    if(!pIns->SolveConstraint())
    {
	    for (UI32 x = 0; x < pIns->GetOpNum(); x++) {
		    IOperand* popr = pIns->opr(x);
		    if (popr->IsGR() && (popr->GetConstraint()!=NULL)) {
			    if (grlist[popr->Idx()]) {
				    popr->RemoveConstraint();
			    }else{
				    grlist.set(popr->Idx());
			    }
		    }
	    }
    }

    // WRについても、同一レジスタがオペランドで使用される場合、
    // ２つ目のオペランドに対する制約を削除する。
    // 補正命令が重複して作成されるのを防ぐため。
	std::bitset<32> wrlist(0);
	for( UI32 x = 0; x < pIns->GetOpNum(); x++ ) {
		IOperand* popr = pIns->opr(x);
		if( popr->IsWR() && (popr->GetConstraint() != NULL )) {
			if( wrlist[popr->Idx()] ) {
				popr->RemoveConstraint();
			} else {
				wrlist.set(popr->Idx());
			}
		}
	}	

	if(pIns->GetId() == INS_ID_CACHE) {
		IValConstraint *pConst = pIns->opr(1)->GetConstraint();
		IOperand *pCacheOp = pIns->opr(0);
		if(((UI32) *pCacheOp) == 2 /*CFALI*/ && pConst != NULL) {
			pConst->SetType(IValConstraint::FETCH);
		}
	} else if (pIns->GetId() == INS_ID_PREF) {
		IValConstraint *pConst = pIns->opr(1)->GetConstraint();
		IOperand *pPrefOp = pIns->opr(0);
		if(((UI32) *pPrefOp) == 0 /*PREFI*/ && pConst != NULL) {
			pConst->SetType(IValConstraint::FETCH);
		}
	}
	
	if(pIns->GetId() == INS_ID_HALT) {
		// Checking HALT release condition
		if(CheckHALTReleaseCond(pIns)) {
			PrepareDeletedIns(pCB, pIns);
			g_mgr->ReplaceInsbyOther(pCB, pIns, pIns->GetLen());						
			return true;
		}
	}

	// Do not overwrite target PC in vector handler, JMP return in Funtion, loop counter when inloop sequence
	UI32 vNotUse = g_mgr->GetConstraintRegister(pCB, pIns);
	UI32 insLen = pIns->GetLen();
	pIns->Regulate(&r, vNotUse);
	pIns->SetForcedAdjust(false);
	// Check issue replace difference PC in common block
	// It may not enter this code 
	if((pCB->GetHandlerAddress() == IBlockManager::ADR_COMMON_CALLT && insLen != pIns->GetLen())
		|| (r.Pass() && pIns->GetId() == INS_ID_SYSCALL && pCB->GetHandlerAddress() == IBlockManager::ADR_VECTOR_MPUMMU && m_nCauseCode == 0x90)/*limitation support syscall occur in MIP*/){
		r.GiveUp();
		r.ReAsm();
		m_nReplaceTime = 0;
	}
	if (r.Pass()) {
		//! Clear C2B1, forwarding couple in case instruction(ins2) do not need additional instruction(ins1)
		if((pIns->InC2B1Ins() && pIns->GetForwardIns() == nullptr) || pIns->GetInsNeed().size() > 0){
			pIns->ClearInsNeed();
			pIns->SetInC2B1Ins(false);
		}
		// Change operand in forwarding instruction 
		IInstruction* forwardingIns = pIns->GetForwardIns();
		if(forwardingIns != nullptr && forwardingIns->GetId() == INS_ID_JMPD32){
			std::vector<UI32> vOprDst;
			for(UI32 oprIdx = 0; oprIdx < pIns->GetOpNum(); oprIdx++) {
				if(pIns->opr(oprIdx)->Attr(IOperand::OPR_ATTR_GR) && pIns->opr(oprIdx)->Attr(IOperand::OPR_ATTR_DST)){
					if(pIns->opr(oprIdx)->Idx() == forwardingIns->opr(0)->Idx()){
						vOprDst = {};
						break;
					}
					vOprDst.push_back(pIns->opr(oprIdx)->Idx());
				}
			}
			while (vOprDst.size() > 0){
				std::random_shuffle(vOprDst.begin(), vOprDst.end(), g_rnd);
				if(forwardingIns->opr(0)->Replace(vOprDst.back()))
					break;
				vOprDst.pop_back();
			}
		}

		// Memory Init before first access! --> to create __preload codeblock.
		if (pIns->Behavior(IInstruction::LOAD_MEMORY) || 
			pIns->Behavior(IInstruction::STORE_MEMORY) ) { // Store時も周辺８バイトで初期化
			std::vector<std::pair<UI32,UI32> >::iterator itr;
			for (itr = r.m_vEa.begin(); itr != r.m_vEa.end(); itr++) {
				const UI64 PSIZE = 4ULL;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;
				const UI64 ALIGN = ~(PFETCHSIZE - 1);
				UI64 start_na	= itr->first;					// NO Align head
				UI64 end_na		= itr->first + itr->second - 1;	// NO Align tail
				UI64 start_a	= start_na & ALIGN;				// Word Align head
				UI64 end_a		= end_na & ALIGN;

                if (IsMDPexception(itr->first, itr->second, pIns->Behavior(IInstruction::LOAD_MEMORY), pIns->Behavior(IInstruction::STORE_MEMORY))) {
                    r.GiveUp();
                    break;
                }

				#if DBGMODE && 1
				std::cout << pIns->GetCode() << "     :: Effective address = 0x"
				<< std::hex << itr->first << ", size="  << std::dec << itr->second << std::endl;
				#endif

				for (UI64 z = start_a; z <= end_a; z+=PFETCHSIZE) {
					UI64 rv = 0;
					rv = g_rnd.Get();			// Gereate RANDOM for initial value on memory(32bit upper).
					rv = (rv<<32)| g_rnd.Get();	// Gereate RANDOM for initial value on memory(64bit).
					//TODO:Multi thread not support
					m_pSim->PresetMemory(true ,0 ,z, PSIZE, (rv & 0xffffffff));
					if(PFETCHSIZE == 8)
						m_pSim->PresetMemory(true ,0 ,z + PSIZE, PSIZE, (rv >> 32));
					#if DBGMODE && 0
					std::cout << pIns->GetCode() << "       => Preset address = 0x" << std::hex << z
					<< ", size="  << std::dec << PSIZE << ", val=0x" << std::hex << rv << std::endl;
					#endif
				}
			}
        }
        if (r.Pass()) {
            pCB->Update();
            if (pSp->pAsmSrcObj->MakeLabelHash(pCB) == false || pSp->pAsmSrcObj->LabelResolve(pCB) == false) {
                // Regulation code overwrap with next block.
                std::runtime_error excep("Fail to regulate codeblock in function RegulateValueConstraint() \n ");
                throw excep;
            }
            // Changing operand->change instuction len and native data also
            // Update native data in case change operand 
            {	// Native Dataの展開
                std::vector<UI32> vndl = pCB->GetNativeDataArray();
                for (UI32 i = 0; i < vndl.size(); i++) {
                    IInstruction* pNd = pCB->Fetch(vndl[i]);
                    m_pSim->WriteMemory(vndl[i], pNd->GetLen(), (UI32)(*pNd->opr(0)));
                }
            }

            m_nReplaceTime = 10;
            return false; /* false = 補正[しない]*/
        }
    }

	if (r.NeedIns()) {
        // Do not insert adjustment code for dispose
        if (pIns->GetId() == INS_ID_DISPOSE_R3 && pCB->GetHandlerAddress() != 0) {
            r.GiveUp();
        } else {
            m_nReplaceTime = 10;
            // GR補正
            std::vector< std::pair<UI32, UI32> > & v_gr = r.m_vGr;
            std::vector< std::pair<UI32, UI32> >::iterator itr;

            // ２レジスタを補正する場合、レジスタAの補正命令を生成、
            // レジスタBの補正命令を生成するときにAの値を使用してはならない。
            // Aの補正後AをpushしBの補正時にはpushされているものは使用しない
            std::vector<UI32> exclude;
            std::vector<IInstruction*> vPrevIns;

            UI32 InsIdx = pCB->GetIndex(pIns);

            UI32 pos = 1;
            if (InsIdx > 4)
                pos = 4;
            else if (InsIdx > 2)
                pos = 2;

            while (pos > 0 && InsIdx > 0) {
                if (((InsIdx - pos) >= 0) && (pCB->at(InsIdx - pos)->InC2B1Ins())) {
                    vPrevIns.push_back(pCB->at(InsIdx - pos));
                }
                pos--;
            }

            while ((InsIdx > 1) && (pCB->at(InsIdx - 1)->GetForwardIns() != nullptr) && (pCB->at(InsIdx - 1)->GetForwardIns() == pCB->at(InsIdx))) {
                vPrevIns.push_back(pCB->at(InsIdx - 1));
                InsIdx--;
            }

            for (itr = v_gr.begin(); itr != v_gr.end(); itr++) {
                if (itr->first == 0) {
                    std::cout << "GiveUpRecovery_R0" << std::endl;
                    if (itr->second != 0) {
                        pIns->SetForcedAdjust(bForce);
                        GiveUpRecovery_R0(pIns); // r0を補正しようとした
                    }
                } else {
                    IInstruction* pNewIns = (pIns->InLoop() || bForce) ?
                        MOV32(itr->second, itr->first) :
                        GenerateRegulatedInstructionGR32(0/*htid*/, itr->second, itr->first, exclude, &vPrevIns, pIns, pCB);
                    if (pNewIns != NULL) {
                        if (pNewIns->GetComment().size() == 0)
                            pNewIns->AppendComment("Regulation code !");
                        //Adjust for dispose instruction
                        if ((pIns->GetMne() == "dispose") && (pIns->GetOpNum() == 3)) {
                            if (itr->first == pIns->opr(2)->Idx()) {
                                pNewIns = MOV32P(pIns->GetJumpTarget(), itr->first);
                                pIns->SetJumpTargetLabel("");
                            }
                        }
                        pIns->ClearInsNeed();
                        if (pIns->GetForward() || pIns->GetForwardLD()) {
                            if (pIns->InLoop()) {
                                pIns->ClearInsNeed();
                                pNewIns->SetSequence();
                            }
                            pNewIns->SetRegulationTarget(pIns);
                            pIns->DirMoveTo(pNewIns);

                            pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                        } else {
                            pNewIns->SetRegulationTarget(pIns);
                            pIns->DirMoveTo(pNewIns);		// Directive MOVE for Label of Branch condition
                            pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                        }
                    }
                }
                exclude.push_back(itr->first);
            }

            // WR補正
            std::vector< std::pair<UI32, std::pair<std::bitset<4>, __uint128_t> > > & v_wr = r.m_vWr;
            std::vector< std::pair<UI32, std::pair<std::bitset<4>, __uint128_t> > >::iterator itrwr;
            std::bitset<4> elm_flg;
            __uint128_t val, cur_val;

            IInstruction *pNewIns;
            UI32 reg, addrReg;

            // Exclude loop counter register if current instruction belongs to a loop sequence.
            if (pIns->InLoop()) {
                UI32 idx = pCB->GetIndex(pIns);
                IInstruction *pLoopIns = NULL;
                while (idx < pCB->GetInstructionNum()) {
                    pLoopIns = pCB->at(idx);
                    if (pLoopIns->GetMne() == "loop")
                        break;
                    idx++;
                }
                if (pLoopIns != NULL) {
                    UI32 loopReg = pLoopIns->opr(0)->Idx();
                    exclude.push_back(loopReg);
                }
            }

            // Check whether selected register violate any constraint.
            auto IsRegValid = [&](UI32 reg) {
                if (exclude.end() != std::find_if(exclude.begin(), exclude.end(), [&](UI32 x) {return x == (UI32)reg; }))
                    return false;
                return true;
            };

            // Randomize register for adjustment sequence.
            addrReg = 0;
            while (addrReg == 0) {
                UI32 tmp = g_rnd.GetRange(4, 29);
                if (IsRegValid(tmp))
                    addrReg = tmp;
            }

            // Set value for Wide Register
            for (itrwr = v_wr.begin(); itrwr != v_wr.end(); itrwr++) {
                reg = itrwr->first;
                elm_flg = itrwr->second.first;
                val = itrwr->second.second;
                UI32 nWRMemPreset = g_wm.BASE_WR_PRESET + m_nWRMemOffset;

                //[TN]TODO: Potential bug: when there are more than 8 WRs needed to be preset in loop, 
                // the memory will no enough. But the rate is rare.
                if ((nWRMemPreset + 128 > g_wm.BASE_WORK_END) && (!pIns->InLoop())) {
                    std::stringstream ss;
                    std::string label;
                    // Add a new WR memory preset block.
                    m_nWRMemBlockCount++;
                    m_bNewWRMemBlock = true;
                    ss << "NMNT_wr_preset_memory_" << m_nWRMemBlockCount;
                    ss >> label;
                    pNewIns = MOV32P(label, 11);
                    pNewIns->SetRegulationTarget(pIns);
                    pIns->DirMoveTo(pNewIns);// Directive MOVE for Label of Branch condition
                    pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                    pNewIns = JMP32(11);
                    pNewIns->SetRegulationTarget(pIns);
                    pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                    // Set return code after memory preset
                    pNewIns = MOVR(g_rnd.GetRange(12, 31), 11);
                    pNewIns->SetRegulationTarget(pIns);
                    pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
                    pNewIns->SetLabel(label + "_ret");
                    // Set return code after memory preset
                    pNewIns = MOVR(g_rnd.GetRange(12, 31), 10);
                    pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                    // Re-calculate memory address.
                    m_nWRMemOffset = 0;
                    nWRMemPreset = g_wm.BASE_WR_PRESET + m_nWRMemOffset;

                }

                // Get WR current value
                m_pSim->ReadWrReg(&cur_val, reg, 0);

                // Preset memory for WR. It will be recored and preset in _wr_preset_memory_
                for (UI32 elmnum = 0; elmnum < (sizeof(__uint128_t) / sizeof(UI32)); elmnum++) {
                    UI32 v;
                    if (elm_flg.test(elmnum)) {
                        v = (UI32)((val >> (elmnum * 32)) & ((__uint128_t)0xffffffffUL));
                    } else {
                        v = (UI32)((cur_val >> (elmnum * 32)) & ((__uint128_t)0xffffffffUL));
                    }
                    m_pSim->PresetMemory(true, 0, (nWRMemPreset + elmnum * 4), 4, v, true);
                }

                pNewIns = MOV32(nWRMemPreset, addrReg);
                pNewIns->SetRegulationTarget(pIns);
                pIns->DirMoveTo(pNewIns);// Directive MOVE for Label of Branch condition
                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                // Load adjustment value to wide register
                pNewIns = LDVQW(0, addrReg, reg);
                pNewIns->SetRegulationTarget(pIns);
                pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

                m_nWRMemOffset += 16;
            }

            // ブロック情報の更新
            pCB->Update();
        }
	}

    if (r.GiveUpRegulate()) {
        //replace dispose instruction by movw instrucion (move valid address to r3)  if it not belong to syscall, callt.
        PrepareDeletedIns(pCB, pIns);
        if (pIns->GetMne() == "dispose" && r.m_vGr.size() && pCB->GetHandlerAddress() == 0) {
            for (UI32 i = 0; i < r.m_vGr.size(); i++) {
                if (r.m_vGr[i].first == 3 && (((vNotUse >> r.m_vGr[i].first) & 0x1) == 0)) {
                    IInstruction *p = MOV32(r.m_vGr[i].second, r.m_vGr[i].first);
                    p->AppendComment("Repalce dispose");
                    pIns->MoveInsAttribute(p);
                    IInstruction* temp = pCB->Replace(pIns, p);
                    delete temp;
                    pCB->Update();
                    return true;
                }
            }
        }
        // Replace random instruction
        if (m_nReplaceTime > 0) {
            g_mgr->ReplaceInsbyOther(pCB, pIns, insLen);
            m_nReplaceTime--;
        } else {
            IInstruction* p = ReplaceInsByNop(pCB, pIns, insLen);
            p->AppendComment("Give up regulation");
        }
        return true;
    }
	
	/* r.m_result(そのまま実行可能ならば真) => 論理反転する */
	return true; 	
}


bool CSimulatorControl::IsNativeMode( void ) {
	UI32 psw = 0;
	// NC:PSW
	m_pSim->ReadNcReg(&psw, 5, 0);
	return ((psw & 0x80000000)==0);
}

/**
* @brief Get whether the simulator is in guest operation. .
* @Returns true if guest operation is in progress.
*/
bool CSimulatorControl::IsGuestMode(void) {
    UI32 pswh = 0;
    m_pSim->ReadNcReg(&pswh, 15, 0);
    return ((pswh & 0x80000000) != 0);
}

std::string CSimulatorControl::GetMContext() {
	std::stringstream ss;
	std::string strContext = "NM_";
	if(!IsNativeMode()) {
		UI32 htcfg0, vcid;
		m_pSim->ReadTcReg(&htcfg0, 0,  2, 0);
		vcid = (htcfg0 >> 8) & 0x7 ;
		ss << 'V' << std::dec << std::setw(2) << std::setfill('0') << vcid;
		ss << '_';
	}
	ss >> strContext;
	return strContext;
}

std::string CSimulatorControl::GetTContext() {
	std::stringstream ss;
	std::string strContext = "NMNT_";
	if(!IsNativeMode()) {
		UI32 htcfg0, vcid;
		m_pSim->ReadTcReg(&htcfg0, 0,  2, 0);
		vcid = (htcfg0 >> 8) & 0x7 ;
		ss << 'V' << std::dec << std::setw(2) << std::setfill('0') << vcid;
		ss << "T00"; // TODO: Support multi-thread
		ss << '_';
	}
	ss >> strContext;
	return strContext;
}

UI32 CSimulatorControl::GetTargetHandlerAddress(IExceptionConfig *pExp) {
	UI32 nHandlerAddress = pExp->m_addr;

	if (pExp->m_name == "EIINT") {
		UI32 pc, ebase, eiic;
        if (IsGuestMode()) {
            m_pSim->ReadNcReg(&ebase, 19, 9);
            m_pSim->ReadNcReg(&eiic, 13, 9);
            m_pSim->ReadPC(&pc);
        } else {
            m_pSim->ReadNcReg(&ebase, 3, 1);
            m_pSim->ReadNcReg(&eiic, 13, 0);
            m_pSim->ReadPC(&pc);
        }

		// Direct vector method
		if(pc <= ebase + 0x1f0) {
			nHandlerAddress = pc - ebase;
		} else { // Reference table method
			nHandlerAddress += ((eiic & 0x0f) << 4);
			//[TN]TODO: EITBL use NM handler
			nHandlerAddress |= 0x1;
		}
	} else if(pExp->m_name == "HVTRAP") {  // HVTRAP use NM handler
		nHandlerAddress |= 0x1;
	}

    nHandlerAddress |= 0x1;

	return nHandlerAddress;
	
}

UI32 CSimulatorControl::GetPSW( void ) {
    UI32 psw = m_pSim->GetPSW();
	return psw;
}


UI32 CSimulatorControl::GetINTCFG( void ) {
	UI32 intcfg = 0, pswh = 0;
	m_pSim->ReadNcReg(&pswh, 15, 0);
	if ((pswh & 0x80000000) != 0) {
		m_pSim->ReadTcReg(&intcfg, 21, 9, 0);	//GMINTCFG
		m_pSim->ReadNcReg(&intcfg, 21, 9);	//GMINTCFG
	} else {
        m_pSim->ReadTcReg(&intcfg, 13, 2, 0);   //INTCFG
		m_pSim->ReadNcReg(&intcfg, 13, 2);   //INTCFG
    }
	return intcfg;
}

UI32 CSimulatorControl::GetPLMR( void ) {
	UI32 plmr = 0, pswh = 0;
	m_pSim->ReadNcReg(&pswh, 15, 0);
	if ((pswh & 0x80000000) != 0) {
		m_pSim->ReadNcReg(&plmr, 22, 9);	//GMPLMR
	} else {
        m_pSim->ReadNcReg(&plmr, 14, 2);   //PLMR
    }
	return plmr;
}

/**
 * @brief シミュレーションGiveUp時の動作をハンドリングする。 
 * @param pIns シミュレーションも補正も出来ない命令
 */
void CSimulatorControl::GiveUpRecovery_R0(IInstruction* pIns) {
	
	IOperand* popr = NULL;
	for (UI32 N = 0; N < pIns->GetOpNum(); N++) {
		if (pIns->opr(N)->IsGR() && (pIns->opr(N)->Idx() == 0)) {
			popr = pIns->opr(N);
			break;
		}
	}
	
	if (popr ==NULL) std::cout << __FUNCTION__ << ":" << pIns->GetCode() << std::endl;
	_ASSERT(popr);
	
	/* FPU倍精度：r0でも可能な制約に書き換える */
	BS_ICAT bcat;
	//bcat.set(IInstruction::ICAT_FPU_D);
	//if (pIns->GetCategory() & bcat.to_ulong()) {
	//	//UI32 r = g_rnd.Get() & 3;
	//	UI32 r = g_rnd.Get() & 0; //[FROG]TODO: Fix it
	//	switch (r) {
	//	case 0:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_ZERO));
	//		break;
	//	case 1:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::NEGATIVE_ZERO));
	//		break;
	//	case 2:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_INF));
	//		break;
	//	case 3:
	//		popr->SetConstraint(new IFpuDoubleConstraint(IFpuDoubleConstraint::POSITIVE_INF));
	//		break;
	//	default:
	//		break;
	//	}
	//	pIns->AppendComment(" GiveUp-r0 ");
	//}
	
	/* FPU単精度：r0でも可能な制約に書き換える */
	bcat.reset();
	bcat.set(IInstruction::ICAT_FPU_S);
	bcat.set(IInstruction::ICAT_FPU_D);
	if (pIns->GetCategory() & bcat.to_ulong()) {
		popr->RemoveConstraint();
		pIns->AppendComment(" GiveUp-r0 ");
	}
	
	/* r0からrXへ命令を再構成する */
}


/**
 * @param	htid	Thread id
 * @param	targV	目標値
 * @param	reg		補正対象のレジスタインデックス
 * @param	exclude	使用禁止のレジスタ情報
 */
IInstruction* CSimulatorControl::GenerateRegulatedInstructionGR32(UI32 htid, UI32 targV, UI32 reg, std::vector<UI32>& ex, std::vector<IInstruction*>* vPrevIns, IInstruction* pIns, CCodeBlock* pcb) {
	IInstruction *pNewIns;

	// Generate code for forwarding data instruction with dependent operand has constraint
	if(pIns->GetInsNeed().size() != 0){
		std::vector<IInstruction*> vIns = RegulateByForwardingIns(htid, targV, reg, ex, pIns, pcb);
		UI32 idx = pcb->GetIndex(pIns);
		while(vIns.size()) {
			pNewIns = vIns.back();
			pcb->AddOpeCode(pNewIns, idx);
			vIns.pop_back();
			pNewIns->SetForcedAdjust();
		}
		// Move direction to last inserted instruction.
		pIns->DirMoveTo(pNewIns);
		pcb->Update();
		return NULL;
	} else {
		pNewIns = MOV32(targV, reg);
	}
	return pNewIns;
}

std::vector<IInstruction*> CSimulatorControl::RegulateByForwardingIns(UI32 htid, UI32 targV, UI32 reg, std::vector<UI32>& ex, IInstruction* pIns, CCodeBlock* pcb) {
	std::vector<IInstruction*> vNewIns;
	std::vector<IInstruction *> &vNeededIns = pIns->GetInsNeed();
	IInstruction *pNeed = vNeededIns.back();
	IInstruction *pNewIns = NULL;
	UI32 valBuffer = 0;
	SI32 sValBuffer = 0;
	UI32 reuse = 0;
	UI32 nDisp = 0;
	UI32 rTemp = 0;
	auto CheckSignedRange = [] (SI32 val, UI32 bitsize) {
		SI32 min = (-1 * (1 << (bitsize - 1)));
		SI32 max = (1 << (bitsize - 1)) - 1;
		if(val >= min && val <= max)
			return true;
		return false;
	};
	//auto CheckUnSignedRange = [] (SI32 val, UI32 bitsize) {
	//	SI32 min = 0;
	//	SI32 max = (1 << bitsize) - 1;
	//	if(val >= min && val <= max)
	//		return true;
	//	return false;
	//};

	auto GenRandomRegister = [] (IInstruction *p, std::vector<UI32> ex, UI32 mask) {
		std::vector<UI32> reglist;
		std::vector<UI32>::iterator itr;
		UI32 size = mask + 1;
		for(UI32 i = 1; i < 32; i++) {
			UI32 checkInvalid = 0;
			checkInvalid |= (i & mask);	// Check odd/even index.
            for(UI32 r = 0; r < size; r++)
                checkInvalid |= ((1 << (i + r)) & (p->GetOprSrc() | p->GetOprDst()));    // Not used in p
			itr = std::find_if(ex.begin(), ex.end(), [&](UI32 r) {return (i == r);}); // Not be a excluded register.
			checkInvalid |= (itr == ex.end() ? 0 : 1);	// 0: Not included in ex, 1: was excluded
			if (checkInvalid == 0) {
				reglist.push_back(i);
			}
		}
		std::random_shuffle(reglist.begin(), reglist.end(), g_rnd);
		if(reglist.size())
			return reglist[0];
		else
			return (g_rnd.GetRange(0, 31) & ~mask);	// This case may cause error, but never occur.
	};
	switch (pNeed->GetId())
	{
		case INS_ID_SATADD_I5:
		// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > 0x7FFFFFFF)
				break;

			sValBuffer = g_rnd.GetRange((SI32)-16, (SI32)15);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;
			// This case caused saturated result in SATADDI5
			if((SI32) valBuffer < 0 && sValBuffer < 0 && targV != 0x80000000) {
				break;
			}

			// R0 can not be set non-zero value
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADD_I5:
			sValBuffer = g_rnd.GetRange((SI32)-16, (SI32)15);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;

			// R0 can not be set non-zero value
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOVI5:
			if(!CheckSignedRange(targV, 5))
				break;
			pNeed->opr(0)->Replace(targV);
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOV:
			// R0 can not be set non-zero value
			if(pNeed->opr(0)->Idx() == 0 && targV != 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_CMP:     
		case INS_ID_CMP_SI5:
			if(pNeed->opr(1)->Idx() == 0 && targV != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));

			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADDI_SI16:
			sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
			pNeed->opr(0)->Replace(sValBuffer);
			valBuffer = (SI32)targV - (SI32)sValBuffer;
			if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ADD:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = targV - reuse;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SUB:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = reuse - targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SUBR:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = reuse + targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ANDI_I16:
			// This instruction will AND only 16 MLS bits
			if(!CheckSignedRange(targV, 16))
				break;

			if(pNeed->opr(1)->Idx() == 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->Replace(g_rnd.GetRange(0, 0xffff) | targV);
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_AND:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			valBuffer = g_rnd.GetRange((UI32)0, (UI32)0xffffffff) | targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ORI:
			if(pNeed->opr(1)->Idx() == 0)
				pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));

			// Generate random value for immediate
			valBuffer = g_rnd.GetRange(0, 0xffff);
			valBuffer = valBuffer & targV;  // Keep bits whose value is 1
			pNeed->opr(0)->Replace(valBuffer);

			// Generate random value for operand register
			valBuffer = targV & ~valBuffer; // Get the remains bits that need to be 1
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_OR:
			if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			// Generate random operands
			valBuffer = g_rnd.Get();
			valBuffer = valBuffer & targV;
			pNeed->opr(0)->SetConstraint(new INumConstraint(0, 0));

			valBuffer = targV & ~valBuffer;
			pNeed->opr(1)->SetConstraint(new INumConstraint(targV, targV));

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_HSH:
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ZXB:
			if(!CheckSignedRange(targV, 8))
				break;
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_ZXH:
			if(!CheckSignedRange(targV, 16))
				break;
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_XOR:
			if (pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = reuse ^ targV;
			pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_NOT:
			valBuffer = ~targV;
			if(pNeed->opr(0)->Idx() == 0)
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATADD:
			// The result of SATADD can not exceed maximum positive (0x7fffffff)
			if(std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = (SI32)targV - (SI32)reuse;

			// The above expression caused overflow.
			if ((SI32) reuse < 0 && (SI32) valBuffer < 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = targV - reuse;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32) reuse < 0 && (SI32) valBuffer < 0)
					break;

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}

			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATADD_R3:
			// The result of SATADD can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32) 0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = targV - reuse;
			// This case will cause saturated result
			if ((SI32) reuse < 0 && (SI32) valBuffer < 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = targV - reuse;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32) reuse < 0 && (SI32) valBuffer < 0)
					break;

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(1)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUB_R3:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = targV + reuse;
			// The above expression caused overflow.
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				valBuffer = (SI32)reuse - (SI32)targV;
				// This case will cause saturated result, do not need to recover
				// Because it will be same with another if adjust both registers
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(1)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUB:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
			valBuffer = (SI32)reuse + (SI32)targV;
			// This case will cause saturated result
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
				// The result of this expression can not overfllow because both reuse and targV are positive.
				valBuffer = (SI32)reuse - (SI32)targV;
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if(pNeed->opr(0)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUBR:
			// The result of SATSUB can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > (UI32)0x80000000)
				break;

			if(pNeed->opr(1)->Idx() == pNeed->opr(1)->Idx())
				pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));

			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			valBuffer = (SI32)reuse + (SI32)targV;
			// This case will cause saturated result
			if ((SI32)valBuffer < 0 && (SI32)reuse > 0 && targV != 0x80000000){
				m_pSim->ReadGrReg(&reuse, pNeed->opr(0)->Idx(), htid);
				// The result of this expression can not overfllow because both reuse and targV are positive.
				valBuffer = (SI32)reuse - (SI32)targV;
				if ((SI32)valBuffer > 0 && (SI32)reuse < 0)
					break;			// The above expression caused overflow.

				if((pNeed->opr(1)->Idx() == 0 && valBuffer != 0) || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			} else {
				if(pNeed->opr(0)->Idx() == 0 || pNeed->opr(0)->Idx() == pNeed->opr(1)->Idx())
					pNeed->opr(0)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(0)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SATSUBI:
			// The result of SATSUBI can not exceed maximum positive (0x7fffffff)
			if (std::abs((SI64)targV) > 0x80000000)
				break;

			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			sValBuffer = reuse - targV;
			if(sValBuffer >= (SI32)-32768 && sValBuffer <= (SI32)32767) {
				pNeed->opr(0)->Replace(sValBuffer);
			} else {
				sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
				pNeed->opr(0)->Replace(sValBuffer);

				valBuffer = sValBuffer + targV;
				// The above expression caused overflow. It will cause saturated in SATSUB
				if((SI32)valBuffer < 0 && (SI32) sValBuffer > 0 && targV != 0x80000000)
					break;
				
				if(pNeed->opr(1)->Idx() == 0 && valBuffer != 0)
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint(valBuffer, valBuffer));
			}
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_MOVEA:
			m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
			sValBuffer = targV - reuse;
			// Out of range
			if(std::abs((SI64)sValBuffer) >= 0x7FFF && pNeed->opr(1)->Idx() == 0) {
                pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
                m_pSim->ReadGrReg(&reuse, pNeed->opr(1)->Idx(), htid);
                sValBuffer = targV - reuse;
			}
            if(std::abs((SI64)sValBuffer) >= 0x7FFF) {
                sValBuffer = g_rnd.GetRange((SI32)-32768, (SI32)32767);
				SI32 sNewVal = (SI32)targV - sValBuffer;
                if(pNeed->opr(1)->Idx() == 0 && sNewVal != 0)
					pNeed->opr(1)->Replace(GenRandomRegister(pNeed, ex, 0));
				pNeed->opr(1)->SetConstraint(new INumConstraint((UI32)sNewVal, (UI32)sNewVal));
			}
			pNeed->opr(0)->Replace(sValBuffer);
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			pNewIns->SetForcedAdjust();
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF); // LD.B fixed bit#0 of disp to 0
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB23(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
						
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BUD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_BUD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF);
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB23(rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
						
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_DW:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if((rTemp & ~0x1) == (pNeed->opr(0)->Idx() & ~0x1) || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0x1);
			pNewIns = STDW23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 8));
			if(reg & 0x1)	// regulated register index is odd (in dest pair register)
				pNewIns->opr(0)->SetConstraint(new INumConstraint((UI64)targV << 32, (UI64)targV << 32));
			else
				pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LDL_W:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HUD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_HUD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x1; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_WSD16:
			nDisp = g_rnd.GetRange(0, 0x7FFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_WSD23:
			nDisp = g_rnd.GetRange(0, 0x3FFFFF) & ~0x3; // Refer COprSDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW23 (rTemp, nDisp, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_B:
			nDisp = g_rnd.GetRange(0, 0x3F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTB (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_BU:
			nDisp = g_rnd.GetRange(0, 0xF) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTB (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_H:
			nDisp = g_rnd.GetRange(0, 0x7F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTH (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_HU:
			nDisp = g_rnd.GetRange(0, 0x1F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTH (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_SLD_W:
			nDisp = g_rnd.GetRange(0, 0x3F) & ~0x3; // Refer COprDispReg::Fix()
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = SSTW (rTemp, nDisp);
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			pNeed->opr(0)->SetDisp(nDisp);
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
		case INS_ID_LD_B_INC:
		case INS_ID_LD_B_DEC:
		case INS_ID_LD_BU_INC:
		case INS_ID_LD_BU_DEC:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STB16(rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x00, 1));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);

			// This instruction will access to same memory as above one.
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_H_INC:
		case INS_ID_LD_H_DEC:
		case INS_ID_LD_HU_INC:
		case INS_ID_LD_HU_DEC:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STH16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x01, 2));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;

		case INS_ID_LD_W_INC:
		case INS_ID_LD_W_DEC:
		case INS_ID_LDL_BU:
		case INS_ID_LDL_HU:
			rTemp = pNeed->opr(1)->Idx();
			if(rTemp == pNeed->opr(0)->Idx() || rTemp == 0)
				rTemp = GenRandomRegister(pNeed, ex, 0);
			pNewIns = STW16 (rTemp, 0x0, pNeed->opr(0)->Idx());
			pNewIns->opr(1)->SetAttr(IOperand::OPR_ATTR_LMEM, true);
			pNewIns->opr(1)->SetConstraint(new CStoreAddressSelector(0xFEE00000, 0xFEEFFFFF, 0x03, 4));
			pNewIns->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			pNewIns->SetRegulationTarget(pNeed);
			vNewIns.push_back(pNewIns);
				
			// This instruction will access to same memory as above one.
			// pNeed->opr(0)->RemoveConstraint();
			vNewIns.push_back(pNeed);
			break;
			
		default:
			pNeed = MOV32(targV, reg);
			pNeed->opr(0)->SetConstraint(new INumConstraint(targV, targV));
			vNewIns.push_back(pNeed);
			break;
	}

	//[FROG]TODO: What do FROG do if instruction was passed already?
	// Can not generate forwarding couple
	if(vNewIns.size() == 0) {
		delete pNeed;
		pNewIns = MOV32(targV, reg);
		if(!pIns->InSequence())
			pNewIns->SetForwardIns(pIns);
		pNewIns->SetSequence();
		pNewIns->AppendComment("Forwarding Data instruction");
		vNewIns.push_back(pNewIns);
	}
	if(pcb->GetHandlerAddress() != 0) {
		std::for_each(vNewIns.begin(), vNewIns.end(), [](IInstruction *p) { p->SetForcedAdjust(true); });
	}

	pIns->ClearInsNeed();
	return vNewIns;
}

bool CSimulatorControl::Step(UI32 htid, UI32 lpc, UI32 ppc, IInstruction* pIns, ISimulatorStepResp * res) {
	_ASSERT(pIns);
	
	UI64 opecode	= pIns->Fetch();
	UI32 inslen		= pIns->GetLen();
	UI64 addrL1		= 0;
	UI64 sizeL1		= 0;
	UI64 addrL2		= 0;
	UI64 sizeL2		= 0;
	
    if (m_pSim->MmuTransferAddr(true, 0, lpc, inslen, MXU_ACC_FETCH, &addrL1, &sizeL1, &addrL2, &sizeL2) != true) {
        return false;
    }

	_ASSERT(inslen == (sizeL1 + sizeL2));
	
	if (sizeL2 != 0) {
		/* 実際はバイトアクセスされる */
		UI64	splitOpecode = 0;
		UI8*	splitPos = ((UI8*)&opecode) + sizeL1;
		memcpy((void*)&splitOpecode, (void*)splitPos, sizeL2); 
		memset((void*)splitPos, 0, sizeL2);
		if (m_pSim->WriteMemory(addrL2, sizeL2, splitOpecode)!=true) {
			return false;
		}
	}
	
	if (m_pSim->WriteMemory(addrL1, sizeL1, opecode) != true) {
		return false;
	}
        
    pIns->m_pswb = GetPSW();
    bool ret = m_pSim->Step(htid, lpc, res);
	pIns->m_pswa = GetPSW();
	return ret;
}


bool CSimulatorControl::DecodeAddress(UI32 L, UI32* PL, UI32* PP) {
	_ASSERT(PP);
	
	UI64 physical;
	if (m_pSim->MmuTransferAddr(true, 0, L, 1, MXU_ACC_DONTCARE, &physical, NULL, NULL, NULL) != true) {
		return false;
	}
	*PL = L;
	*PP = (UI32)physical;
	return true;
}


bool CSimulatorControl::RecalcAbsoluteAddress(IInstruction* pIns) {
	UI32 opNum = pIns->GetOpNum();
	IOperand* popr;
	
	for (UI32 i = 0; i < opNum; i++) {
		popr = pIns->opr(i);
		if (popr->GetLabel() != NULL) {
			if (popr->Attr(IOperand::OPR_ATTR_RLABEL)!=true) {
				MSG_ERROR(0,"YY %s : opr(%d) %s (ALABEL) = 0x%08X\n", pIns->GetCode().data(), i, popr->GetLabel(), (UI32)(*popr));
			}else{
				MSG_INFO (0,"YY %s : opr(%d) %s (ALABEL) = 0x%08X\n", pIns->GetCode().data(), i, popr->GetLabel(), (UI32)(*popr));
			} 			
		}	
	}
	return false;
}

/** 
 * @brief	Check and prevent consecutive interrupt request
 * @param	pCB		current simulated code block
 * @param	pIns	Current simulated instruction
 * @return	If there is consecutive request, return true; otherwise, return false
 */
bool CSimulatorControl::RemoveConsecutiveRequest(CCodeBlock *pCB, IInstruction *pIns) {
	if(pCB == NULL || pIns == NULL)
		return false;

	auto CanMoveToNext = [] (CCodeBlock *pCb, IInstruction *p) ->bool {
		UI32 idx = pCb->GetIndex(p);
		IInstruction *pNext = (idx < pCb->GetInstructionNum() - 1) ? pCb->at(idx) : NULL;
		if(pNext == NULL)
			return false;
		if(p->Behavior(IInstruction::JMP))
			return false;
		if(p->InSequence() && p->GetForwardIns() == pNext)
			return false;
		if(pNext->InSequence() || pNext->InLoop())
			return false;
		return true;
	};

	auto CheckAsyncExist = [=] (IInstruction *p, std::string name) {
		for(UI32 n = 0; n < p->GetDirectiveNum(); n++) {
			CAsyncLabel *pAL = static_cast<CAsyncLabel*> (p->GetDirective(n)->GetAsyncLabel());
			if(pAL == NULL)
				continue;
			/* EIINT = GMEIINT = EITBL = GMEITBL */
			/* FEINT = GMFEINT */
			if(CheckSameInterruptType(pAL->m_name,name)){
				return true;
			}
		}
		return false;
	};


	auto ResolveConsecutiveRequest = [=] (CCodeBlock* pCB, IInstruction *p, bool bCanMoveToNext) -> void {
		UI32 idx = pCB->GetIndex(p);
		// It has consecutive request. Move the request to next instruction
		if(idx < pCB->GetInstructionNum() - 1) {
			IInstruction *pNext = pCB->at(idx + 1);
			// The next instruction may be executed already.
			if(bCanMoveToNext) {
				UI32 n = 0;
				IDirective *pDir = nullptr;
				while((pDir = p->GetDirective(n)) != NULL) {
					CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAL != NULL  && pAL->m_bAssert && CheckAsyncExist(pNext, pAL->m_name) == false) {
						p->RemoveDirective(pAL);
						pNext->SetDirective(pAL);
						continue;
					}
					n++;
				}
			}
			p->ClearAsync();
		}
	};

	UI32 idx = pCB->GetIndex(pIns);
	IInstruction *pPrev;

	if(idx == 0)
		return false;
	pPrev = pCB->at(idx - 1);
	// The previous instruction has async. request or exception
	if(pPrev->HasAsyncLabel()) {
		bool bCanMoveToNext = CanMoveToNext(pCB, pIns);
		ResolveConsecutiveRequest(pCB, pIns, bCanMoveToNext);
	}
	// Support issue in RedMine #62713#note-23
	// 1. EIINT was requested and pending
	// 2. ei instruction was executed
	// 3. next instruction (of EI) has DBNMI label <-- EIINT is accepted
	// 4. EIINT sequence (saving resource) <= DBNMI is requested
	// 5. first instruction of EIINT handler <-- DBNMI is accepted
	if(pIns->GetId() == INS_ID_EI && idx < pCB->GetInstructionNum() - 1) {
		std::vector<CIntInfo*>::iterator itr;
		for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
		CIntInfo* p = (*itr);
		if(p->sName.find("eiint") != std::string::npos || p->sName.find("eitbl") != std::string::npos)
			break;
		}
		// There is pending EITBL/EIINT 
		if(itr != m_vRequestedIntStack.end()) {
			IInstruction *pNext = pCB->at(idx + 1);
			bool bCanMoveToNext = CanMoveToNext(pCB, pNext);
			ResolveConsecutiveRequest(pCB, pNext, bCanMoveToNext);
		}
	}
	return true;
}

/**
 * @brief ブレークポイントの設定と種別選択処理
 */
UI32 CSimulatorControl::GenerateBreakPointBeforeSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk) {
	UI32 num_of_channels = g_exp->GetNumOfChannels();
	UI32 break_point_weight = g_exp->GetBreakPointWeight(); 
	IBreakParam bparam;
    UI32 break_type = IBreakParam::BREAK_NONE;
    UI32 range = 0;
    std::stringstream ss;
    std::string bp_label;

	if(( break_point_weight != 0 ) && ( pIns->GetId() != INS_ID_DBT ) ) {
		range = g_rnd.GetRange(1,100);
		if( break_point_weight >= range ) {
			
            bparam = IBreakParam();
            break_type = bparam.m_type = g_exp->GetBreakType();
            bparam.m_block_num = std::atoi(pBlk->GetName().c_str() + 15);
            bparam.m_block_label = pBlk->GetLabel();
#if DBGMODE
                std::fprintf(stdout,"==> GetBreakType:%d\n",break_type);
#endif
          
            switch( break_type ) {
            case IBreakParam::BREAK_PCB :
			
					ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
					ss >> bp_label;
					ss.str(""); ss.clear(std::stringstream::goodbit);
					pIns->SetLabel(bp_label);
					bparam.m_addr_label = bp_label;
					bparam.m_addr = 0x0; 
					bparam.m_addr_mask = 0x0;
					bparam.m_data = 0x0;
					bparam.m_data_mask = 0x0;
					p->pBreakParam.push_back(bparam);
				
#if DBGMODE
                std::fprintf(stdout,"==> Create BreakParam for BREAK_PCB on label:%s\n",bp_label.c_str());
#endif
                break;

            case IBreakParam::BREAK_LDB :
                if(pIns->Behavior(IInstruction::LOAD_MEMORY) & (! pIns->Behavior(IInstruction::STORE_MEMORY))&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 補正命令生成後に貼る
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0; 
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_LDB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE; 
                }
                break;
            case IBreakParam::BREAK_SDB :
                if(pIns->Behavior(IInstruction::STORE_MEMORY) & (! pIns->Behavior(IInstruction::LOAD_MEMORY))&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label);
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0;
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_SDB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE;
                }
                break;
            case IBreakParam::BREAK_RMWB :
                if((pIns->Behavior(IInstruction::STORE_MEMORY)) && (pIns->Behavior(IInstruction::LOAD_MEMORY))&&(p->pBreakParam.size() < num_of_channels)) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0;
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_RMWB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE;
                }
                break;
            case IBreakParam::BREAK_LSAB :
                if(((pIns->Behavior(IInstruction::STORE_MEMORY)) || (pIns->Behavior(IInstruction::LOAD_MEMORY)))) {
                    ss << pBlk->GetLabel() << "_bp_" << p->pBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label);
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0;
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_LSAB on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE;
                }
                break;

			    case IBreakParam::BREAK_SS :
                if(( ! pIns->InLoop()) && (!pIns->InSequence()) ) {
                    
                    ss << pBlk->GetLabel() << "_db_" << p->pNotBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    // pIns->SetLabel(bp_label); 
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0;
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pNotBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_SS on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE;
                }
                break;

            case IBreakParam::BREAK_AE :
                if(((pIns->GetId() == INS_ID_DISPOSE) || (pIns->GetId() == INS_ID_DISPOSE_R3) || ((pIns->GetId() >= INS_ID_POPSP) && (pIns->GetId() <= INS_ID_PUSHSP)))&& (!pIns->InSequence())) {
                    ss << pBlk->GetLabel() << "_db_" << p->pNotBreakParam.size();
                    ss >> bp_label;
                    ss.str(""); ss.clear(std::stringstream::goodbit);
                    pIns->SetLabel(bp_label);
                    bparam.m_addr_label = bp_label;
                    bparam.m_addr = 0x0;
                    bparam.m_addr_mask = 0x0;
                    bparam.m_data = 0x0;
                    bparam.m_data_mask = 0x0;
                    p->pNotBreakParam.push_back(bparam);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_AE on label:%s\n",bp_label.c_str());
#endif
                } else {
                    break_type = IBreakParam::BREAK_NONE;
                }
                break;
            case IBreakParam::BREAK_RLB :
                if( p->pBreakParam.size() > 0 ) {
                    pBlk->m_bRLB = true;
#if DBGMODE
                    std::fprintf(stdout,"==> Set Block.m_bRLB = 1 for BREAK_RLB\n");
#endif
                    break_type = IBreakParam::BREAK_NONE;
                } else {
                    break_type = IBreakParam::BREAK_NONE;
                }

                break;
            default:
                break_type = IBreakParam::BREAK_NONE;
            }
        }
    }
#if DBGMODE
    fprintf(stdout,"==> Generate Break Type: %d break_point_weight:%3d range:%3d Pins:%3d %s\n",break_type,break_point_weight,range,pIns->GetId(),pIns->GetCode().c_str());
#endif
    return break_type;
}

/**
 * @brief ブレークポイント情報の生成処理
 */
void CSimulatorControl::GenerateBreakPointSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk) {
	UI32 access_type;
	UI64 address;
	UI32 size;
	UI64 value;
    std::stringstream ss;
    std::string bp_label;
	IBreakParam bparam;
	UI32 num_of_channels = g_exp->GetNumOfChannels();

    UI32 break_type;
    UI32 block_num;
    std::string block_label;

    if(p->pBreakParam.size())
    // ブレークポイントの種別毎に情報を生成する
    switch( p->pBreakParam.back().m_type ) {
    case IBreakParam::BREAK_PCB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_PCB\n");
#endif
        break;

    case IBreakParam::BREAK_LDB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_LDB\n");
#endif
		m_pSim->SetMemVariable();
        while( m_pSim->EachMemAccessLog( access_type, address, size, value )) {
#if DBGMODE
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }   
#endif
        }
        if( p->pBreakParam.back().m_addr_label == "" ) {
            p->pBreakParam.back().m_addr = address;
        }
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;
        
        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        case 8: // Double Word Access
            if( p->pBreakParam.size() <= num_of_channels ) {
                p->pBreakParam.back().m_data_mask = 0x00000000;
                bp_label = p->pBreakParam.back().m_addr_label;
                break_type = p->pBreakParam.back().m_type;
                block_num = p->pBreakParam.back().m_block_num;
                block_label = p->pBreakParam.back().m_block_label;
                bparam = IBreakParam();
                bparam.m_type = break_type;
                bparam.m_block_num = block_num;
                bparam.m_block_label = block_label;
                bparam.m_addr_label = bp_label;
                bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                bparam.m_data = (UI32)(value >> 32); // high value
                bparam.m_data_mask = 0x00000000;
                bparam.m_data_size = 0;
                p->pBreakParam.push_back(bparam);
            } else {
                p->pBreakParam.pop_back();
            }
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        if( size == 8 ) {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.at(p->pBreakParam.size()-2).m_addr,p->pBreakParam.at(p->pBreakParam.size()-2).m_addr_mask,p->pBreakParam.at(p->pBreakParam.size()-2).m_data,p->pBreakParam.at(p->pBreakParam.size()-2).m_data_mask);
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        } else {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        }
#endif
        break;
    case IBreakParam::BREAK_SDB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_SDB\n");
#endif
		m_pSim->SetMemVariable();
        while( m_pSim->EachMemAccessLog( access_type, address, size, value )) {
#if DBGMODE
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }   
#endif
        }
        p->pBreakParam.back().m_addr = address;
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        case 8: // Double Word Access
            if( p->pBreakParam.size() <= num_of_channels ) {
                p->pBreakParam.back().m_data_mask = 0x00000000;
                bp_label = p->pBreakParam.back().m_addr_label;
                break_type = p->pBreakParam.back().m_type;
                block_num = p->pBreakParam.back().m_block_num;
                block_label = p->pBreakParam.back().m_block_label;
                bparam = IBreakParam();
                bparam.m_type = break_type;
                bparam.m_block_num = block_num;
                bparam.m_block_label = block_label;
                bparam.m_addr_label = bp_label;
                bparam.m_addr = 0x0; // ラベルでブレーク発生アドレスを指定するので初期化（０クリア）
                bparam.m_addr_mask = 0x0; // GenerateBreakPointSetupBlockで乱数によりマスク作成
                bparam.m_data = (UI32)(value >> 32); // high value
                bparam.m_data_mask = 0x00000000;
                bparam.m_data_size = 0;
                p->pBreakParam.push_back(bparam);
            } else {
                p->pBreakParam.pop_back();
            }
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        if( size == 8 ) {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.at(p->pBreakParam.size()-2).m_addr,p->pBreakParam.at(p->pBreakParam.size()-2).m_addr_mask,p->pBreakParam.at(p->pBreakParam.size()-2).m_data,p->pBreakParam.at(p->pBreakParam.size()-2).m_data_mask);
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        } else {
            std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
        }
#endif
        break;
    case IBreakParam::BREAK_RMWB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_RMWB\n");
#endif
		m_pSim->SetMemVariable();
        while( m_pSim->EachMemAccessLog( access_type, address, size, value )) {
#if DBGMODE
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }   
#endif
        }
        p->pBreakParam.back().m_addr = address;
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
#endif
        break;
    case IBreakParam::BREAK_LSAB :
#if DBGMODE
        std::fprintf(stdout,"==> Recreate BreakParam for BREAK_LSAB\n");
#endif
		m_pSim->SetMemVariable();
        while( m_pSim->EachMemAccessLog( access_type, address, size, value )) {
#if DBGMODE
            if (access_type == 1) {
                std::fprintf(stdout,"==> Read  address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            } else {    
                std::fprintf(stdout,"==> Write address:%08x size:%d data:%016llx\n",(UI32)(address & 0xffffffff),size,value);
            }   
#endif
        }
        p->pBreakParam.back().m_addr = address;
        p->pBreakParam.back().m_data = value;
        p->pBreakParam.back().m_data_size = size;

        switch( size ) {
        case 1:
            p->pBreakParam.back().m_data_mask = 0xFFFFFF00;
            break;
        case 2:
            p->pBreakParam.back().m_data_mask = 0xFFFF0000;
            break;
        case 4:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        default:
            p->pBreakParam.back().m_data_mask = 0x00000000;
            break;
        }
#if DBGMODE
        std::fprintf(stdout,"==> Addr:%08x Mask:%08x Data:%08x Mask:%08x\n",p->pBreakParam.back().m_addr,p->pBreakParam.back().m_addr_mask,p->pBreakParam.back().m_data,p->pBreakParam.back().m_data_mask);
#endif
        break;

    default:
        // 到達しないはず
        break;
    }
    
}


void CSimulatorControl::GenerateBreakPointSetupBlock(IBlockSimParam* bsp) {
    std::vector<INode*>&    vHB = g_asf->GetPreloadBlock();
    std::string labelStr("");
    std::string labelStr2("");
    std::string labelSS("");
    std::string block_label("");
    std::stringstream ss;
    UI32 ins_cnt = 0;
    UI32 tmpR = g_mgr->GetHandlerWorkReg();
    UI32 tmpC = tmpR + 1; // DBPC - 2
    UI32 tmpD = tmpR + 2;
    UI32 dir1 = tmpR + 3;
    IInstruction* pIns;
    UI32 csl;
    CCodeBlock* pHB = nullptr;
    UI32 bpc;
    UI32 addr_mask;
    UI32 data_mask;
    UI32 rbsel;
	CCodeBlock*		pBlk	= bsp->pCodeBlock;
	UI32 SQ0 = 0;
	UI32 SQ1 = 0;
	UI32 channel = 0;
	UI32 peid = 0, gpid = 0, dbgen = 0;
	m_pSim->ReadSysRegister(&peid, "PEID", 0);
	m_pSim->ReadSysRegister(&dbgen, "DBGEN", 0);
	gpid = (peid & 0x700) >> 8;
	UI32 total_chanel = g_exp->GetNumOfChannels();
	g_exp->GetChannelInSequential(&SQ0, &SQ1);

	if(pBlk->GetLabel().find("th_end_sync") != std::string::npos)
		return;

	bool bAsyncEvent = g_exp->GetAsyncBreak();
	if(bAsyncEvent)
		channel = (g_rnd.GetRange(0, 3)) * 16;

	// Clear async event in G3KH
	auto ClearBreakSet = [&](){	
		pIns = MOV32( 0x00, tmpR );
		pHB->AddOpeCode( pIns, ins_cnt++ );
		// BPC
		pIns = LDSR( tmpR, 22, 3 );
		pHB->AddOpeCode( pIns, ins_cnt++ );
		// BPAV
		pIns = LDSR( tmpR, 24, 3 );
		pHB->AddOpeCode( pIns, ins_cnt++ );
		// BPAM
		pIns = LDSR( tmpR, 25, 3 );
		pHB->AddOpeCode( pIns, ins_cnt++ );
		// BPDV
		pIns = LDSR( tmpR, 26, 3 );
		pHB->AddOpeCode( pIns, ins_cnt++ );
		// BPDM
		pIns = LDSR( tmpR, 27, 3 );
		pHB->AddOpeCode( pIns, ins_cnt++ );
	};

    for( std::vector<INode*>::iterator itr = vHB.begin(); itr != vHB.end(); itr++ ) {
        pHB = static_cast<CCodeBlock*>(*itr);

		if( pHB->GetName().find("breaksetup") != std::string::npos ) {

			if(bsp->pBreakParam.size())
				block_label = bsp->pBreakParam.front().m_block_label.c_str();
			else
				block_label = bsp->pNotBreakParam.front().m_block_label.c_str();

			ss << block_label << "_breaknext";
			ss >> labelStr;
			ss.str(""); ss.clear(std::stringstream::goodbit);
						for (UI32 i = 0; i < pHB->GetInstructionNum(); i++) {
				IInstruction* pTmp = pHB->at(i);
				if (pTmp->GetLabel().find("_entry") != std::string::npos) {
					ins_cnt = i;
					break;
				}
			}

			if (ins_cnt == 0 && g_asf->GetNextRandomCodeBlock() == NULL) {
				std::string sEntrLabel = pHB->GetLabel() + "_entry";
				dbgen |= (1 << gpid);
				pIns = MOV32( dbgen, tmpR);//Get Index'address
				pHB->AddOpeCode(pIns, ins_cnt++);
				pIns = LDSR(tmpR, 0, 3);//Set DBGEN for current GPID
				pIns->SetLabel(sEntrLabel);
				pHB->AddOpeCode(pIns, ins_cnt++);
			}
			// Compare to got block will be occur Break Point Exception
			pIns = MOV32P( block_label.c_str(), tmpR ); // value of Block address
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = CMPR( tmpR, tmpC );                //compare
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = BNE17P( labelStr );                //if no then next
			pHB->AddOpeCode(pIns, ins_cnt++);

			pIns = STSR( 21, dir1, 3 );               // Get DIR1
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = MOV32( 0xffffff09, tmpR );		  // Clear bit DIR1.SQ0, DIR1.SQ1
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = AND( tmpR, dir1 );                 // DIR1.CSL, SQ0, SQ1 clear
			pHB->AddOpeCode(pIns, ins_cnt++);
			pIns = ORI( 1, dir1, dir1 );              // DIR1.BEN set
			pHB->AddOpeCode(pIns, ins_cnt++);
			pBlk->SetMainBlock(false);


			if(SQ0 == Code_Ch_DIR1_SQ0){
				pIns = ORI( 0x2, dir1, dir1 );				// DIR1.SQ0 set
				pIns->AppendComment("for Sequential Break Channel 0-1");
				pHB->AddOpeCode(pIns, ins_cnt++);
			}
			if(SQ1 == Code_Ch_DIR1_SQ1){
				pIns = ORI( 0x4, dir1, dir1 ); 
				pIns->AppendComment("for Sequential Break Channel 2-3");
				pHB->AddOpeCode(pIns, ins_cnt++);			// DIR1.SQ1 set
			}
			
			csl = m_nCurrentChannel;
			
			for( std::vector<IBreakParam >::iterator itr = bsp->pNotBreakParam.begin(); itr != bsp->pNotBreakParam.end(); itr++ ) {

				if((*itr).m_type == IBreakParam::BREAK_AE) { // DIR0.AEEの設定はコードブロックで１回のみで良い
					pIns = STSR( 20, tmpR, 3 );              // get DIR0(r15)
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = MOV32( 0xfffffdff, tmpD );        // set mask(r16)
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = AND( tmpD, tmpR );
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = ORI( 0x200, tmpR, tmpR );
					pHB->AddOpeCode( pIns, ins_cnt++ );
					pIns = LDSR( tmpR, 20, 3 );              // set DIR0.AEE=1
					pHB->AddOpeCode( pIns, ins_cnt++ );
				}
			}

            for( std::vector<IBreakParam >::iterator itr = bsp->pBreakParam.begin(); itr != bsp->pBreakParam.end(); itr++ ) {

                pIns = ORI( csl, dir1, tmpR);
                pHB->AddOpeCode(pIns, ins_cnt++);
                pIns = LDSR( tmpR, 21, 3);   //set DIR1.CSL
                pHB->AddOpeCode(pIns, ins_cnt++);
								
				if(bAsyncEvent && (*itr).m_type != IBreakParam::BREAK_LDB && (*itr).m_type != IBreakParam::BREAK_SDB && (*itr).m_type != IBreakParam::BREAK_RMWB){
					csl += 16;
					continue;
				}
                if( pBlk->m_bRLB ){ // 他のチャネル登録がある時、リレー設定（RLB）の設定も必要ならば、
                    rbsel = 0x0;
                    // RBVE
                    rbsel |= g_rnd.GetRange(0,1) << 14;
                    // RBVSEL
                    rbsel |= ( 0x1 << g_rnd.GetRange(0,7) ) << 24;
					 // Enable RBCF in single core
					if((g_cfg->m_nSysPeNum <= 1) && (g_cfg->m_nPeWorkIdx == 0))
						rbsel |= 0x1 << 13;
                    // RBCE
                    rbsel |= g_rnd.GetRange(0,1) << 12;
                    // RBCSEL
                    rbsel |= ( 0x1 << g_rnd.GetRange(0,6) ) << 16;

                    pIns = STSR(  20, tmpR, 3 );                // Get DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32( 0x0000AFFF, tmpC );           // clear RBVSEL,RBCSEL,RBVE,RBCE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = AND( tmpC, tmpR );
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32( rbsel, tmpC );                // set RBVSEL,RBCSEL,RBVE,RBCE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = OR( tmpC, tmpR );
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR, 20, 3 );                 // set DIR0
                    pIns->AppendComment(" for Break_RLB ");
                    pHB->AddOpeCode(pIns, ins_cnt++);
#if DBGMODE
                    std::fprintf(stdout,"==> Create BreakParam for BREAK_RLB DIR0:%08x\n",rbsel);
#endif                    
                }
				if(g_rnd.GetRange(1, 100) > 50){
					if(((SQ0 == Code_Ch_DIR1_SQ0) && (csl == 0))||((SQ1 == Code_Ch_DIR1_SQ1) && (csl == 32))){
						pIns = STSR( 22, tmpR, 3 );
						pHB->AddOpeCode(pIns, ins_cnt++);
						pIns = ORI( 0x20, tmpR, tmpR );
						pHB->AddOpeCode(pIns, ins_cnt++);
						pIns = LDSR( tmpR, 22, 3 );					// BPC.EO set
						pHB->AddOpeCode(pIns, ins_cnt++);
						csl += 16;
						continue;
					}
				}
				g_exp->SetChannel(&bpc, &addr_mask, &data_mask);
				//G4MH20 support enable break point for each GPID
				bpc |= 1 << (16 + gpid);

                // ブレーク例外種別毎にチャネルを設定する
                switch( (*itr).m_type ) {
                case IBreakParam::BREAK_PCB :
                    bpc &= 0xFFFFFFFC; // WE=0,RE=0

                    pIns = MOV32( bpc, tmpR );     
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );                 // set BPC for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = MOV32P( (*itr).m_addr_label, tmpR ); // value of PC
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );                 // set BPAV for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = MOV32( addr_mask, tmpR );     
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );                 // set BPAM for break exception
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    break;

                case IBreakParam::BREAK_LDB :
                    
					if(bAsyncEvent && channel != csl){
						ClearBreakSet();
						break;
					}
                    if( (*itr).m_data_size == 0 ) { // double word
                        bpc = 0x00000000;
                    } else {
#if DBGMODE
                        bpc = 0x10001019;
#else
                        bpc &= 0xfffffffb; // FE=0
#endif
                    }
                    data_mask |= (*itr).m_data_mask;
#if DBGMODE
                    addr_mask = 0xffffffff;
                    data_mask = 0xffffff00;
#endif
                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    if( (*itr).m_addr_label != "" ) {
                        pIns = MOV32P( (*itr).m_addr_label, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                        pIns = ADDI( (*itr).m_addr, tmpR, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                    } else {
                        pIns = MOV32( (*itr).m_addr, tmpR );
                        pHB->AddOpeCode( pIns, ins_cnt++ );
                    }
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_SDB :
                    
					if(bAsyncEvent && channel != csl){
						ClearBreakSet();
						break;
					}
                    if( (*itr).m_data_size == 0 ) { // double word
                        bpc = 0x00000000;
                    } else {
#if DBGMODE
                        bpc = 0x1000101a;
#else
                        bpc &= 0xfffffffb; // FE=0
#endif                        
                    }
                    data_mask |= (*itr).m_data_mask;
#if DBGMODE
                    addr_mask = 0xffffffff;
                    data_mask = 0xffffff00;
#endif
                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_RMWB :
                   
					if(bAsyncEvent && channel != csl){
						ClearBreakSet();
						break;
					}

                    bpc &= 0xfffffffb; // FE=0
                    data_mask |= (*itr).m_data_mask;

                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;
                case IBreakParam::BREAK_LSAB :
                    
                    bpc &= 0xfffffffb; // FE=0
                    data_mask |= (*itr).m_data_mask;

                    // BPC
                    pIns = MOV32( bpc, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 22, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAV
                    pIns = MOV32( (*itr).m_addr, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 24, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPAM
                    pIns = MOV32( addr_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 25, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );

#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x\n",bpc,(*itr).m_addr,addr_mask);
#endif
						break;

                    // BPDV
                    pIns = MOV32( (*itr).m_data, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 26, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    // BPDM
                    pIns = MOV32( data_mask, tmpR );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
                    pIns = LDSR( tmpR, 27, 3 );
                    pHB->AddOpeCode( pIns, ins_cnt++ );
#if DBGMODE
                    std::fprintf(stdout,"==> BPC:%08x BPAV:%08x BPAM:%08x BPDV:%08x BPDM:%08x\n",bpc,(*itr).m_addr,addr_mask,(*itr).m_data,data_mask);
#endif                    
                    break;

                }				
				// Set full debug channel
				if(csl == (total_chanel-1)*16){
					m_nCurrentChannel = csl;
					break;
				}
                csl += 16;
				m_nCurrentChannel = csl;
            }

			// Next Block
			
			pIns = NOP()->SetLabel(labelStr);
			pHB->AddOpeCode(pIns, ins_cnt++);
			
			for( std::vector<IBreakParam >::iterator itr = bsp->pNotBreakParam.begin(); itr != bsp->pNotBreakParam.end(); itr++ ) {
                labelStr2 = (*itr).m_addr_label + "_setpsw";
                if( (*itr).m_type == IBreakParam::BREAK_SS ) {
                    pIns = STSR( 18, tmpD, 3 );                 // Get DBPC
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = MOV32P( (*itr).m_addr_label, tmpR);  // value of SS's dbtrap
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ADDI( 2, tmpR, tmpR );               // dbtrap address + 2
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = CMPR( tmpR, tmpD );                  // Are you SingleStep's dbtrap?
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = BNE17P( labelStr2 );                  // if no then skip
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = STSR(  20, tmpR, 3 );                // Get DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ORI( 0x0010, tmpR, tmpR );           // set SSE bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR, 20, 3 );                 // set DIR0
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = STSR(  19, tmpR, 3 );                 // Get DBPSW
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = ORI( 0x0800, tmpR, tmpR );           // set SS bit
                    pHB->AddOpeCode(pIns, ins_cnt++);
                    pIns = LDSR( tmpR,  19, 3);                  //set DBPSW
                    pHB->AddOpeCode(pIns, ins_cnt++);

                    pIns = NOP()->SetLabel(labelStr2);
                    pHB->AddOpeCode(pIns, ins_cnt++);
                }
            }
        }
    }
    bsp->pBreakParam.clear();
	bsp->pNotBreakParam.clear();
}

bool CSimulatorControl::CheckAcceptanceCond(std::string name, UI32 priority) {
	// Check acceptance condition before sending request.
	UI32 psw = 0, pmr = 0, dir0 = 0, ispr = 0, epl = 0; 
	bool bAccepted = true;

    psw = GetPSW();
    epl = (GetINTCFG() & 0x2) >> 0x1;
    pmr = GetPLMR();		// PLMR
    m_pSim->ReadNcReg(&dir0, 20, 3);
    m_pSim->ReadNcReg(&ispr, 10, 2);

	UI32 dir0_dm = dir0 & 0x01;

	if(name == "eiint" || name == "eitbl" || name == "gmeiint" || name == "gmeitbl" ) {
		UI32 plmr_msk = (pmr & 0xFF);
		// PSW.ID and PSW.NP = 0, PMR.PMx is masked
		if((plmr_msk <= priority) || ((psw & 0xa0) != 0) ||  (dir0_dm != 0)) {
			bAccepted = false;
		}

		//G4MH20 specs v1.07 section 3.1. New checking when INTCFG.EPL 
		if(epl == 0x1){// PSW.IMASK <= priority
			UI32 psw_eimask = psw & 0x0ff00000;
			if(psw_eimask <= priority)
				bAccepted = false;
		} else {// Checking ISPR
			priority = (priority > 15 ? 15 : priority);  
			UI32 ispr_msk = (ispr & 0x0ffff) & (0x0ffff >> (15 - priority));
			if(ispr_msk != 0)
				bAccepted = false;
		}

	} else if (name == "feint" || name == "gmfeint") {
		// PSW.NP = 0
		if((psw & 0x80) != 0 || dir0_dm != 0) {
			bAccepted = false;
		}
	} else if (name == "fenmi" || name == "dbint") {
		if(dir0_dm != 0) {
			bAccepted = false;
		}
	} else if (name == "dbnmi") {
		// No condition
	}

	return bAccepted;
}

/**
 *@brief	Check asynchronous label type of pending interrupt and request interrupt. EIINT, GMEIINT, EITBL, GMEITBL are same type
 *@param	event1: pending interrupt
 *@param	event2: request interrupt
 *@return	bool(true: interrupts have same type, false: different type)
 */
bool CSimulatorControl::CheckSameInterruptType(std::string event1, std::string event2) {
    /* EIINT = GMEIINT = EITBL = GMEITBL */
    /* FEINT = GMFEINT */
    std::set<std::string> InterruptType = {"eiint", "eitbl", "feint", "gmeiint", "gmeitbl", "gmfeint"};

    auto CorrectInterruptName = [=](std::string InterruptName) -> std::string {
        if (InterruptType.find(InterruptName) != InterruptType.end()) {
            if (InterruptName.find("fe") != std::string::npos) {
                return std::string("feint");
            } else {
                return std::string("eiint");
            }

        }
        return InterruptName;
    };

    event1 = CorrectInterruptName(event1);
    event2 = CorrectInterruptName(event2);

    if (event1 == event2) {
        return true;
    }

    return false;
}

/**
 * @brief	Check asynchronous label, then send interrupt request to simulator
 * @pIns	Current simulated instruction
 */
void CSimulatorControl::CheckInterruptRequest(ISimulationParam* pSp, CCodeBlock *pCB, IInstruction *pIns){
	IDirective	*pDir = NULL;
	CAsyncLabel *pAsyncLabel = NULL;
	UI32		n = 0;

	while((pDir = pIns->GetDirective(n)) != nullptr) {
		pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		if(pAsyncLabel == NULL) {
			n++;
			continue;
		}

		if (pAsyncLabel->m_bAssert) {

			m_pInsCheckedInterrupt = NULL;

			const std::string &name = pAsyncLabel->m_name;
			std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
			while(itr < m_vRequestedIntStack.end()) {
				if(CheckSameInterruptType((*itr)->sName,name))
					break;
				itr++;
			}
			if(itr == m_vRequestedIntStack.end()) {
				UI32 period = g_rnd.GetRange(1, EXCEPTION_MIN_PROBABLY);
				// Support case MDP at EIINT reference table.
				// To make sure EIINT request at 1st instruction handler was clear before finishing executing MP_Handler.
				if(pCB->GetLabel().find("mp_handler") != std::string::npos) {
					IInstruction *pFirst = pCB->at(0);
					if(pFirst->GetRegulationTarget() != NULL)
						pFirst = pFirst->GetRegulationTarget();

					/* EIINT or GMEIINT or EITBL or GMEITBL */
					if(((name.find("eiint") != std::string::npos) || (name.find("eitbl") != std::string::npos)) && pFirst == pIns) {
						UI32 mei = 0;
						m_pSim->ReadNcReg(&mei, 8, 2);
				
						if((mei & 0x3e) == 0x2a) { // MDP at reference table access
							pIns->RemoveDirective(pAsyncLabel);
							continue;
						} else 
							period = 0;
					}
				}

				// Increase live time of pending INT. Avoid case assert-deassert consecutive 
				for(auto itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
					CIntInfo* p = *itr;
					p->nPeriod++;
				}
				//pIns->SetValid(false);
				m_vRequestedIntStack.push_back(new CIntInfo(pIns, name, period, pAsyncLabel->m_index, pAsyncLabel->m_priority, pAsyncLabel->m_causecode, pAsyncLabel->m_channel));
				m_pSim->RequestInterrupt(0, name, pAsyncLabel->m_channel, pAsyncLabel->m_priority, pAsyncLabel->m_causecode, pAsyncLabel->m_gpid);
				m_pInsCheckedInterrupt = pIns;
			} else {
				MSG_WARN(0, "Pending interrupt (%s) was requested again\n", name.c_str());
				MSG_WARN(0, "Pending interrupt, channel = %d, priority = %d\n", pAsyncLabel->m_channel, pAsyncLabel->m_priority);
				MSG_WARN(0, "New interrupt, channel = %d, priority = %d\n", (*itr)->nChannel, (*itr)->nPriority);
				pIns->RemoveDirective(pAsyncLabel);
			}
		} else {
			m_pSim->ClearInterrupt(0, pAsyncLabel->m_name);
			std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
			while(itr != m_vRequestedIntStack.end()) {
				CIntInfo* p = *itr;
				if(pAsyncLabel->m_name == p->sName) {
					itr = m_vRequestedIntStack.erase(itr);
					delete p;
					break;
				} else
					itr++;
			}
		}
		n++;
	}
}

/**
 * @brief	find handler address 
 * @param	expName exception/interrupt name
 * @param	sHandlerAddr a set of exception/interrupt handler address
 * @param	checkAddr is address need to check in set
 * @return	True: There is addr in set
            False: There is no addr in set
 */
bool CSimulatorControl::FindHandlerAddr(std::set<UI32> sHandlerAddr, UI32 checkAddr){
	if (sHandlerAddr.size() && sHandlerAddr.find(checkAddr) != sHandlerAddr.end()){
		return true;
	} else	{
		return false;
		}
	}

bool CSimulatorControl::InsertHandlerAddr(std::string expName, UI32 handlerAddr){
	UI32 baseReg = GetBaseAddrHandlerReg(expName, handlerAddr);
	switch (baseReg){
	case CSimulatorControl::EXP_EBASE_ADDR:
		m_setHandlerAddress.insert(handlerAddr);
		break;
	case CSimulatorControl::EXP_INTBP_ADDR:
		m_setEntry_ReferenceTable.insert(handlerAddr);
		break;
	case CSimulatorControl::EXP_GMEBASE_ADDR:
		m_setGMHandlerAddress.insert(handlerAddr);
		break;
	case CSimulatorControl::EXP_GMINTBP_ADDR:
		m_setGMEntry_ReferenceTable.insert(handlerAddr);
		break;
	default:
		return false;
		}
	return true;
	}
/**
 * @brief	Check whether address executed
 * @param	expName exception/interrupt name
 * @param	checkAddr exception/interrupt handler address
 * @param	checkAddr interrupt channel with table reference method
 * @return	True: This address was be executed
 			False: This address was not be executed
 */
bool CSimulatorControl::IsExecutedHandAddr(std::string expName, UI32 checkAddr, UI32 intChannel) {

	UI32 BaseHandlerAddr = GetBaseAddrHandlerReg(expName, checkAddr);
	std::set<UI32> sHandlerAddr;

	switch (BaseHandlerAddr) {
	case CSimulatorControl::EXP_EBASE_ADDR:
		sHandlerAddr = m_setHandlerAddress;
		break;

	case CSimulatorControl::EXP_INTBP_ADDR:
		sHandlerAddr = m_setEntry_ReferenceTable;
		break;
		
	case CSimulatorControl::EXP_GMEBASE_ADDR:
		sHandlerAddr = m_setGMHandlerAddress;
		break;
	
	case CSimulatorControl::EXP_GMINTBP_ADDR:
		sHandlerAddr = m_setGMEntry_ReferenceTable;
		break;

	default:
		break;
	}
	return FindHandlerAddr(sHandlerAddr, checkAddr);
}

/**
 * @brief	Get base address register in current status
 * @param	pSp Simulation
 * @param	expName name of exception/interrupt need to check
 * @return	Specify base address register [INTBP, GMINTBP]
 */
UI32 CSimulatorControl::GetBaseAddrRegForTableReference(std::string expName) {

	UI32 baseAddrReg = CSimulatorControl::EXP_INTBP_ADDR;
	// It is table reference method.
	// PE goes to host mode always Redmine#77457 note#4
	if(expName == "EITBL" )
		baseAddrReg = CSimulatorControl::EXP_INTBP_ADDR;
	if(expName == "GMEITBL" )
		baseAddrReg = CSimulatorControl::EXP_GMINTBP_ADDR;

	return baseAddrReg;
}

/**
 * @brief	Get base address register in current status
 * @param	pSp Simulation
 * @param	expName name of exception need to check
 * @return	Specify base address register [EBASE, RBASE, INTBP, GMEBASE, GMINTBP]
 */
UI32 CSimulatorControl::GetBaseAddrHandlerReg(std::string expName, UI32 addr) {
	UI32 baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
	// Convert to upper cases
	std::transform(expName.begin(), expName.end(), expName.begin(), [] (int ch) {return std::toupper(ch);});
	UI32 hvcfg = 0;
	m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
	UI32 pswh = 0;
	m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
	// HVCFG.HVE = 0. It is conventinal mode same as G4MH1.0
	if((hvcfg & 0x1) == 0) {
		baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
		if(expName.find("EITBL" ) != std::string::npos)
			baseAddrReg = CSimulatorControl::EXP_INTBP_ADDR;
		return baseAddrReg;
	}
	// Checking for table reference interrupt
	if (expName.find("EITBL" ) != std::string::npos)
		return GetBaseAddrRegForTableReference(expName);

	// HVCFG.HVE = 1. Enable virtualization support function
	switch(addr) {
	// It changes to the host mode whenever the exception is generated in the guest mode.
	case IBlockManager::ADR_VECTOR_RESET:
	case IBlockManager::ADR_VECTOR_HVTRAP:
	case IBlockManager::ADR_VECTOR_DEBUG:
	case IBlockManager::ADR_VECTOR_FENMI:
		baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
		break;
	case IBlockManager::ADR_VECTOR_SYSERR:
		{
		//Read GMCFG 
		UI32 gmcfg = 0;
		m_pSim->ReadSysRegister(&gmcfg, "GMCFG", 0);
		// Check GMCFG.GSYSE
		if((gmcfg & 0x10) == 0x10){
			baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
		} else {
			baseAddrReg = CSimulatorControl::EXP_GMEBASE_ADDR;
		}
		break;
		}
	// Other exception/interrupt does not change mode.
	case IBlockManager::ADR_VECTOR_FETRAP:
	case IBlockManager::ADR_VECTOR_TRAP0:
	case IBlockManager::ADR_VECTOR_TRAP1:
	case IBlockManager::ADR_VECTOR_RIE:
	case IBlockManager::ADR_VECTOR_FPPFPI:
	case IBlockManager::ADR_VECTOR_UCPOP:
	case IBlockManager::ADR_VECTOR_PIE:
	case IBlockManager::ADR_VECTOR_MAE:
		{	
		// Guest mode
		if(pswh & 0x80000000)  {
			baseAddrReg = CSimulatorControl::EXP_GMEBASE_ADDR;
		} else {
			baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
		}
		break;
		}

	case IBlockManager::ADR_VECTOR_BGINT:
		baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
		break;

	case IBlockManager::ADR_VECTOR_MPUMMU:
	{
		//Read GMCFG 
        UI32 gmcfg = 0;
        m_pSim->ReadSysRegister(&gmcfg, "GMCFG", 0);
		if (expName == "MIP" || expName == "MDP") {
            baseAddrReg = (gmcfg & 0x1) ? CSimulatorControl::EXP_EBASE_ADDR : CSimulatorControl::EXP_GMEBASE_ADDR;
        } else {
            baseAddrReg = (gmcfg & 0x2) ? CSimulatorControl::EXP_EBASE_ADDR : CSimulatorControl::EXP_GMEBASE_ADDR;
         }
		break;
	}

	case IBlockManager::ADR_VECTOR_FEINT ... IBlockManager::ADR_VECTOR_EIINT015:
		if(expName.find("GM" ) != std::string::npos){
			baseAddrReg = CSimulatorControl::EXP_GMEBASE_ADDR;
		} else {
			baseAddrReg = CSimulatorControl::EXP_EBASE_ADDR;
		}
		break;

	default:
		break;
	}
		return baseAddrReg;
	
}

/**
 * @brief	Adjust codeblock when exception occurs
 * @param	pCB pointer to a code block structure
 * @param	pIns pointer to current executing instruction
 * @return	Specify whether code block was adjusted or not
 */
bool CSimulatorControl::RegulateException(ISimulationParam* pSp, CCodeBlock* pCB, IInstruction *pIns, IExceptionConfig* pCfg) {
	
	UI32 insid = pIns->GetId();
	UI32 cause_code = 0;
	// This instruction was used for changing mode before enter HALT state
	if(pIns->GetComment().find("Change_mode_to_SV") != std::string::npos)
		return true;
	
	// Get cause code of occurred exception
    cause_code = m_pSim->GetCauseCode() & 0xffff;
	// The exception was regulated or is a interrupt
	// MIP can not change MIP here 
	if((m_bRollback) || ((pCfg->m_bIsInterrupt) && (cause_code != 0x1c && cause_code != 0x1d)) || (pCfg->m_lcode == 0x90))
		return true;

	//DBTRAP for init system register and setup debug exception
	UI32 break_point_weight = g_exp->GetBreakPointWeight();
	if(((break_point_weight > 0) && (pCfg->m_level == IExceptionConfig::EXP_LEVEL_DB )) 
		|| (pCfg->m_lcode == 0xb1 && pIns->GetLabel().find("break_channel_init") != std::string ::npos))
		return true;

	// Temporary does not gen EXP
	if (IsExecutedHandAddr(pCfg->m_name, pCfg->m_addr, 0) == true) {
		PrepareDeletedIns(pCB, pIns);
		IInstruction* p = ReplaceInsByNop(pCB, pIns, pIns->GetLen());
		m_pRollbackIns = p;
		p->AppendComment("Delete_EXP_Duplicate");
		return false; 
	}

	// Increase live time of pending INT. Avoid case assert-deassert consecutive 
	for(auto itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
		
		CIntInfo* p = *itr;
		p->nPeriod++;
	}

	// These exception was processed beforehand due to read-only register DIR0
	if((insid == INS_ID_DBT || insid == INS_ID_RMT || insid == INS_ID_DBHVTRAP) && pCfg->m_name != "RIE")
		return true;
	
	return true;
}

void CSimulatorControl::SetException(IInstruction *pIns, IExceptionConfig *pExp, CCodeBlock* pCB) {
	std::string comment;
	UI32 cause_code = 0;
	std::string exp = pExp->m_name;
	bool bExpatEITBL = false;
	
	// Get cause code of occurred exception
 	cause_code = m_pSim->GetCauseCode() & 0xffff;

    if (cause_code == 0x95 /* MDP guest management*/ || cause_code == 0x9D /* MDP host management*/ || cause_code == 0x1c /* SYSERR */) {	// At EIINT
		bExpatEITBL = true;
	}
	
	// Set exception information
	pIns->SetException(cause_code, GetTargetHandlerAddress(pExp));

	// Remove interrupt out of interrupt stack
	std::string name = exp;
	std::transform(name.begin(), name.end(), name.begin(), [] (int ch) {return tolower(ch);});
	std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
	while(itr != m_vRequestedIntStack.end()) {
		CIntInfo *p = *itr;

		if(bExpatEITBL && p->sName == "eitbl") {
			itr++;
			continue;
		}
		// Remove accepted event.
		if(CheckSameInterruptType(p->sName,name)) {
			itr = m_vRequestedIntStack.erase(itr);
			delete p;
		} else {
			itr++;
		}
	}
}

bool CSimulatorControl::CheckHALTReleaseCond (IInstruction *pIns) {
		// There is pending event.
		if(m_vRequestedIntStack.size() != 0)
			return false;

		// HALT instruction need SV privilege
		if((GetPSW() & 0x40000000))
			return false;

		// Check and adjust requests at current instruction
		IDirective *pDir = nullptr;
		UI32 n = 0;
		while((pDir = pIns->GetDirective(n)) != nullptr) {
			CAsyncLabel *pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
			if (pAsyncLabel != NULL && pAsyncLabel->m_bAssert && CheckAcceptanceCond(pAsyncLabel->m_name, pAsyncLabel->m_priority) == false) {
				return false;
			}
			n++;
		}

		// HALT can not be released in Debug mode
		UI32 dir0 = 0;
		m_pSim->ReadNcReg(&dir0, 20, 3);

		if((dir0 & 0x1))
			return false;

		return true;
	}

void CSimulatorControl::AllocateNewHandler(ISimulationParam* pSp, TBlockConfig* tbc, CCodeBlock *pBlk, MEMADDR baseAddress)	{

	// make label for handler codeblock
	UI32 pc = 0;
	m_pSim->ReadPC(&pc);

	std::string label = pBlk->GetLabel();
	std::string label_num = label.substr(label.find_last_of("_") - 2) + "_" + std::to_string(pc % 1000);

	std::string nextBlockLabel;
	if(g_asf->GetNextRandomCodeBlock() != NULL){
		nextBlockLabel = g_asf->GetNextRandomCodeBlock()->GetLabel();
		} else {
			nextBlockLabel = GetTContext() + "th_end_sync";
		}
	g_asf->GetLinker()->Remove(baseAddress);
	// Prepare handler for next time
	std::vector<CVectorBlock*>* vNode = g_mgr->GenerateVectorBlock(tbc, label_num);
	VectorPtr 		v_ptr  (vNode);
	frog::for_each( v_ptr, [&pSp, &baseAddress] (CVectorBlock* pVc) {
		pVc->SetAddress(baseAddress + pVc->GetHandlerAddress());
		g_asf->LinkCodeBlock(pVc);
		g_asf->AddNode(pVc);
		} );			
}

bool CSimulatorControl::RegulateBeforeException(ISimulationParam* pSp, CCodeBlock *pCB, IInstruction *pIns) {
	CAsyncLabel*	pAsyncLabel;
	IDirective*		pDir;
	UI32			n;

	auto CheckRequestExist = [=] (CAsyncLabel* pAsyncLabel) {
		std::vector<CIntInfo*>::iterator itr;
		for(itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++){
			CIntInfo* p = *itr;
			// Same event type is requested again with different channel or priority
			if(CheckSameInterruptType(p->sName, pAsyncLabel->m_name) 
				&& (p->nChannel != pAsyncLabel->m_channel || p->nPriority != pAsyncLabel->m_priority) ){
				return true;
			}
		}
		return false;
	};
	// De-assert interrupt
	DeassertInterrupt(pSp, pCB, pIns);

	// Prevent consecutive interrupt request
	// Background: G4MH support executing 2 instruction in parallel.
	// Interrupt will be considered requesting at 2 instruction.
	RemoveConsecutiveRequest(pCB, pIns);

	n = 0;
	// Check and adjust requests at current instruction
	while((pDir = pIns->GetDirective(n)) != nullptr) {
		pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		if(pAsyncLabel != NULL && pAsyncLabel->m_bAssert) {
			const std::string &name = pAsyncLabel->m_name;
			// Remove request if it is pending
			if(CheckRequestExist(pAsyncLabel)) {
				//[TN]TODO: Bugfix for MDP at EITBL.
				pIns->RemoveDirective(pDir);
				delete pDir;
				continue;
			}
			// Limitation: Control interrupt in loop sequence
			if(!CheckAcceptanceCond(name, pAsyncLabel->m_priority) && pIns->InLoop()){
				pIns->RemoveDirective(pDir);
				delete pDir;
				continue;
			}

			// store all interrupt occurred. if it occurred but FROG does not jump to setting log, remove it.
			IExceptionConfig* pExpCfg = g_exp->GetConfigByName(name);
			if (name.find("eitbl") == std::string::npos && pExpCfg->m_addr > 0) {
				if (IsExecutedHandAddr(pExpCfg->m_name, pExpCfg->m_addr, 0) == true) {
					pIns->RemoveDirective(pDir);
					delete pDir;
					continue;
				}
			}
		}
		n++;
	}
	return false;
}

/**
 * @brief	Check EXP/Interrupt due to internal priority
 * @param	pIns instruction need to check EXP/Interrupt
 * @param	pCB code block has internal priority
 * @return	True: Exp can occured at pIns
	        False: Exp can not occured at pIns
 */
bool CSimulatorControl::PredictException(CCodeBlock *pCB, IInstruction *pIns, UI32 expAddr) {

	bool result = false;
	UI32 InsId = pIns->GetId();
	auto GetOperand = [&pIns](UI32* sr) -> bool {
		if(pIns->GetId() == INS_ID_STSR){
			*sr = (UI32) *(pIns->opr(0));
			return true;
			}
		if(pIns->GetId() == INS_ID_LDSR){
			*sr = (UI32) *(pIns->opr(1));
			return true;
			}
		return false;
	};

	auto PSWEnableBit = [&](UI32 bitPos) -> bool {
		UI32 psw = GetPSW();
		if (((psw >> bitPos) & 0x1) == 1) return true;
			return false;
	};

	//Check EXP cause by instruction
	switch (expAddr) {
	case IBlockManager::ADR_VECTOR_RESET:
		break;

	case IBlockManager::ADR_VECTOR_SYSERR:
		{
		if(pIns->GetId() == INS_ID_RESBANK){
			UI32 RBNR = 0;
			m_pSim->ReadNcReg(&RBNR, 17, 2);
			if (RBNR == 0)
				result = true;
			}
		}
		break;

	case IBlockManager::ADR_VECTOR_HVTRAP:

		{
		UI32 hvcfg = 0, pswh = 0, um = 0, psw = 0, gmpsw = 0;
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		m_pSim->ReadSysRegister(&psw, "PSW", 0);
		m_pSim->ReadSysRegister(&gmpsw, "GMPSW", 0);
		if(((hvcfg & 0x1) == 1) && InsId == INS_ID_HVTRAP){
			if((pswh >> 31) & 1) // Guest mode
				um = (gmpsw >> 30);
			else
				um = (psw >> 30);

			if(um == 0)
				result = true;
			}
		}

		break;

	case IBlockManager::ADR_VECTOR_FETRAP:
		if(InsId == INS_ID_FETRAP)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_TRAP0:
		if(InsId == INS_ID_TRAP) {
			UI32 vecTrap = (UI32)* (pIns->opr(0));
			if(vecTrap <= 0xf)
				result = true;
		}
		break;

	case IBlockManager::ADR_VECTOR_TRAP1:
		if(InsId == INS_ID_TRAP) {
			UI32 vecTrap = (UI32)* (pIns->opr(0));
			if(vecTrap > 0xf)
				result = true;
		}
		break;

	case IBlockManager::ADR_VECTOR_RIE:
		{
		if(InsId == INS_ID_RIE || InsId == INS_ID_RIE_I9 || InsId == INS_ID_HVCALL || (InsId >= INS_CID_RIE_FPU32 && InsId <= INS_CID_RIE_INT64))
			result = true;

		UI32 hvcfg = 0;
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		if((hvcfg & 0x1) == 0) {
			if ((InsId == INS_ID_HVTRAP) || (InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP))
				result = true;
		}
		}
		break;

	// Not check yet
	case IBlockManager::ADR_VECTOR_FPPFPI:
		{
		//Check FPU instruction
		if (PSWEnableBit(16) == true)	{
			UI32 fpsr = 0;		
			m_pSim->ReadSysRegister(&fpsr, "FPSR", 0);

			// Check FPU exception I V Z O U E
			//E3V5 spec page 340
			if ((/*XE enable*/(fpsr & 0x3E0) || /*no flush*/((fpsr & 0x20000) == 0)) 
				&& (InsId >= INS_ID_ABSF_D && InsId <= INS_ID_TRNCF_SW))
				result = true;
		}

		//Check FPSIMD instruction
		if(PSWEnableBit(17) == true){
			UI32 fxsr = 0;
			m_pSim->ReadSysRegister(&fxsr, "FXSR", 0);
			// Check FXU exception I V Z O U E
			if ((/*XE enable*/(fxsr & 0x3E0) || /*no flush*/((fxsr & 0x20000) == 0))
				&& (InsId >= INS_ID_CMOVF_W4 && InsId <= INS_ID_CMPF_S4))
				result = true;
		}
		}

		break;

	// Not check yet
	case IBlockManager::ADR_VECTOR_UCPOP:
		{
		UI32 sr = 0;
		GetOperand(&sr);
		// Check User Mode
		//Check FPU instruction
		if ((PSWEnableBit(16) == false) && ((InsId >= INS_ID_ABSF_D && InsId <= INS_ID_TRNCF_SW)
			|| ((InsId == INS_ID_LDSR || InsId == INS_ID_STSR) && ((sr >= (0*32) + 6) && (sr <= (0*32) + 11))))){
			result = true;
		}

		//Check SIMD instruction
		if (InsId >= INS_ID_CNVQ15Q30 && InsId <= INS_ID_VXOR){
			result = true;

		}
		//Check not support FPSIMD instruction
		if ( InsId == INS_ID_LDV_DW_2REG || InsId == INS_ID_LDV_QW_2REG || InsId == INS_ID_LDV_W_2REG || InsId == INS_ID_LDVZ_H4_2REG 
		|| InsId == INS_ID_STV_DW_2REG || InsId == INS_ID_STV_QW_2REG || InsId == INS_ID_STV_W_2REG || InsId == INS_ID_STVZ_H4_2REG ) {
	       result = true;
		}

		//Check FPSIMD instruction
		if ((InsId >= INS_ID_CMOVF_W4 && InsId <= INS_ID_CMPF_S4) || (((sr >= (10*32) + 0) && (sr <= (10*32) + 31)))){
			if(PSWEnableBit(17) == false) result = true;

		}

		}
		break;

	case IBlockManager::ADR_VECTOR_MPUMMU:
		break;

	case IBlockManager::ADR_VECTOR_PIE:
		{
		UI32 psw = 0, dir0 = 0, hvcfg = 0, pswh = 0;
		UI32 sr = 0;
		GetOperand(&sr);
		m_pSim->ReadSysRegister(&psw, "PSW", 0);
		m_pSim->ReadSysRegister(&dir0, "DIR0", 0);

		m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
		m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
		// Check User Mode
		auto IsUM = [&](UI32 hvcfg, UI32 psw) ->bool {
			return PSWEnableBit(30);
		};

		// Check HV priviledge system register
		auto IsHV = [&](UI32 hvcfg, UI32 pswh) -> bool {
			if(((hvcfg & 0x1) == 1) && ((pswh >> 31) == 0)) {
				return true;
			}
			return false;
		};

		if (IsUM(hvcfg, psw) == true)	{
			if(InsId == INS_ID_HALT || InsId == INS_ID_DI || InsId == INS_ID_EI || InsId == INS_ID_SYSCALL || InsId == INS_ID_DST 
				|| InsId == INS_ID_EST || InsId == INS_ID_HVTRAP || InsId == INS_ID_EIRET || InsId == INS_ID_FERET
				|| (InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP))	{
				result = true;
				break;
			}
			if(InsId == INS_ID_CACHE){
				UI32 cacheop = (UI32) *(pIns->opr(0));
				// CIBII, CFALI, CISTI, CILDI
				if(cacheop == 1 || cacheop == 2 || cacheop == 3 || cacheop == 4)	{
					result = true;
					break;
				}
			}
			// Check SV system register 
			if(InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
				if(/*Basic SysReg*/((sr >= (0*32) + 0) && (sr <= (0*32) + 3)) || (sr == (0*32) + 13) || (sr == (0*32) + 14) 
					|| (sr == (0*32) + 21) || (sr == (0*32) + 28) || (sr == (0*32) + 29) || ((sr >= (1*32) + 0) && (sr <= (1*32) + 6)) 
					|| (sr == (1*32) + 8) || (sr == (1*32) + 11) || (sr == (1*32) + 12) || (sr == (2*32) + 0) || (sr == (2*32) + 1) 
					|| (sr == (2*32) + 6) || (sr == (2*32) + 8) || ((sr >= (2*32) + 15) && (sr <= (2*32) + 18))
					||/*Interrupt Function SysReg*/ (sr == (1*32) + 7) || ((sr >= (2*32) + 10) && (sr <= (2*32) + 14))
					||/*Hardware Thread Control SysReg*/ (sr == (1*32) + 10) || (sr == (2*32) + 5) || ((sr >= (2*32) + 23) && (sr <= (2*32) + 31))
					||/*FPU SysReg*/ (sr == (0*32) + 6) || (sr == (0*32) + 7) || (sr == (0*32) + 11)
					||/*MPU SysReg*/ (sr == (5*32) + 0) || (sr == (5*32) + 1) || (sr == (5*32) + 4) || (sr == (5*32) + 5) 
					|| ((sr >= (5*32) + 8) && (sr <= (5*32) + 11)) || ((sr >= (5*32) + 20) && (sr <= (5*32) + 22))
					||/*Cache Control SysReg*/ ((sr >= (4*32) + 12) && (sr <= (4*32) + 29)) 
					||/*Debug Function Reg*/ (sr == (3*32) + 0) || (sr == (3*32) + 1) || (sr == (3*32) + 13) || (sr == (3*32) + 15) 
					|| (sr == (3*32) + 30) || ((sr >= (3*32) + 17) && (sr <= (3*32) + 27))) {
						result = true;
						break;
				}
			}
		}
		// Check Debug mode
		if((dir0 & 0x1) == 0)	{
			// Check debug instruction
			if(InsId == INS_ID_DBRET){
				result = true;
				break;
			}
			// Check debug system register 
			if(InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
				if(/*Debug Function Reg- DBPSW*/ (sr == (3*32) + 19)) { 
						result = true;
						break;
				}
			}
		}

		if(IsHV(hvcfg, pswh) == false) {
			if(InsId >= INS_ID_STM_GSR && InsId <= INS_ID_LDM_MP) {
				result = true;
				break;
			}

			if(InsId == INS_ID_LDSR || InsId == INS_ID_STSR) {
				if(/* VM sysreg*/(sr == (0*32) + 15) || (sr == (0*32) + 18) || (sr == (0*32) + 19) ||/* SNZCFG*/ (sr == (0*32) + 21) 
					|| (sr == (1*32) + 16) || (sr == (1*32) + 17) || (sr == (1*32) + 20)
					|| /* DB sysreg*/(sr == (3*32) + 0) || (sr == (3*32) + 13) || (sr == (3*32) + 19) || (sr == (3*32) + 21) || (sr == (3*32) + 22)
					/* GM sysreg*/
					|| ((sr >= (9*32) + 0) && (sr <= (9*32) + 3)) || (sr == (9*32) + 5) || (sr == (9*32) + 13) 
					|| (sr == (9*32) + 14) || (sr == (9*32) + 16) || (sr == (9*32) + 17) || ((sr >= (9*32) + 19) && (sr <= (9*32) + 22)) 
					|| (sr == (9*32) + 25) || (sr == (9*32) + 26) || (sr == (9*32) + 28) || (sr == (9*32) + 29)
					|| /* MPBK sysreg*/(sr == (5*32) + 17) || (sr == (9*32) + 25) || (sr == (9*32) + 26)
					|| /*TSCTRL*/(sr == (11*32) + 2) || /* count fucntion sysreg*/(sr == (11*32) + 9) || ((sr >= (11*32) + 16) && (sr <= (11*32) + 31))
					|| /* all sysreg sel 12, sel 13*/((sr >= (12*32) + 0) && (sr <= (13*32) + 31))) {
						result = true;
						break;
					}
				if(InsId == INS_ID_LDSR && ((sr == (11*32) + 0) || (sr == (11*32) + 1) || /*MPIDn*/((sr >= (5*32) + 24) && (sr <= (5*32) + 31)))){
					result = true;
					break;
				}
			
				// Check Debug mode
				if((dir0 & 0x1) == 0 && ( /* DBPSWH*/(sr == (3*32) + 13) || /* DBPSW*/ (sr == (3*32) + 19))) {
					result = true;
					break;
				}

			}
			// Check cache priviledge
			if(InsId == INS_ID_CACHE){
				UI32 cacheop = (UI32) *(pIns->opr(0));
				// CIBII, CFALI, CISTI, CILDI
				if(cacheop == 1 || cacheop == 2 || cacheop == 3 || cacheop == 4)	{			
					result = true;
					break;
				}
			}
		}
			
		}
		break;

	case IBlockManager::ADR_VECTOR_DEBUG:
		if(InsId == INS_ID_DBT || InsId == INS_ID_DBHVTRAP || InsId == INS_ID_RMT)
			result = true;
		break;

	case IBlockManager::ADR_VECTOR_MAE:
		{
		if ((pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) ){
			IValConstraint* pVc = NULL;
			// STC in couple has not constraint
			if(InsId == INS_ID_STC_W || InsId == INS_ID_STC_H){
				UI32 accMem = 0;
				m_pSim->ReadGrReg(&accMem, pIns->opr(1)->Idx(), 0);
				if((InsId == INS_ID_STC_W && ((accMem & 0x3) != 0)) || (InsId == INS_ID_STC_H && ((accMem & 0x1) == 1)) ){
					result = true;
					break;
				}
			}
			// LDL in couple has not constraint
			if(InsId == INS_ID_LDL_HU){
				UI32 accMem = 0;
				m_pSim->ReadGrReg(&accMem, pIns->opr(0)->Idx(), 0);
				if((accMem & 0x1) == 1){
					result = true;
					break;
				}
			}
			for (UI32 N = 0; N< pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					continue;
				}
				if (popr->Attr(IOperand::OPR_ATTR_SMEM) || popr->Attr(IOperand::OPR_ATTR_LMEM)) {
					if (((pVc = popr->GetConstraint()) != NULL) && pVc->m_nMsk && (pVc->m_nUnA >= 1 && pVc->m_nUnA <= pVc->m_nMsk)) {
						result = true;
						break;
					}
				}
				
			}
		}
		break;
		}
	default :
		break;
	}

	return result;

}

/**
 * @brief	Clear EXP/Interrupt due to internal priority
 * @param	pIns instruction need to check EXP/Interrupt
 * @param	pCB code block has internal priority
 * @return	True: pIns was be executed
	        False: pIns was not be executed
 */
bool CSimulatorControl::PreventException(ISimulationParam* pSp, CCodeBlock *pCB, IInstruction *pIns) {

	//Check all exp/interrupt whether it can be occur at pIns
	for(UI32 handlerAddr = IBlockManager::ADR_VECTOR_RESET; handlerAddr < IBlockManager::ADR_BLOCK_NUM; handlerAddr += 0x10){
		if(PredictException(pCB, pIns, handlerAddr)){
			// If lower exp/interrupt can occur in pIns
			// Replace by other instruction or remove async label
			// Get channel in case EIINT
			if(IsExecutedHandAddr("", handlerAddr, 0) == true){
				// Remove async label in case interrupt
				if(handlerAddr >= IBlockManager::ADR_VECTOR_FENMI && handlerAddr <= IBlockManager::ADR_VECTOR_EIINT015) {

				} else {
					PrepareDeletedIns(pCB, pIns);
					pIns = g_mgr->ReplaceInsbyOther(pCB, pIns, pIns->GetLen());
				}
				return true;
			} else {// Check unexpected MIP. Case MIP in handler
				UI32 baseAddr = GetBaseAddrHandlerReg("", handlerAddr);
				if(baseAddr == CSimulatorControl::EXP_EBASE_ADDR){
					m_pSim->ReadNcReg(&baseAddr, 3, 1); //EBASE;
				} else{
					m_pSim->ReadNcReg(&baseAddr, 19, 9); //GMEBASE;
				}
				
				if(IsMIPexception(baseAddr, 0x200) == true){
					PrepareDeletedIns(pCB, pIns);
					pIns = g_mgr->ReplaceInsbyOther(pCB, pIns, pIns->GetLen());
					return true;
				}
			}
		}
	}	

	return false;
}

/**
 * @brief	Check status of requested event, then deciding clear un-accepted event
 * @param	pCB		current simulated code block
 * @param	pIns	Current simulated instruction
 * @return	If there is any event cleared, return true, otherwise, return false
 */
bool CSimulatorControl::DeassertInterrupt(ISimulationParam* pSp, CCodeBlock *pCB, IInstruction *pIns) {
	std::vector<CIntInfo*>::iterator itr;
	UI32 ret = false;

	auto NeedDeassert = [=] (CIntInfo* p) {

		// Do not generate deassert label for roll back instruction
		if(m_bRollback)
			return false;

		// Do not generate deassert label at 2nd instruction of C2B1
		if(pIns->InC2B1Ins() == true && pIns->GetForwardIns() == nullptr)
			return false;

		// check syserr exception occur when this is interrupt RBINT and RBNR.BN > 15
		/*UI32 PSW = 0, RBCR0 = 0, RBNR = 0;

		m_pSim->ReadNcReg(&PSW, 5, 0);
		if ((PSW & 0x80000000) == 0) {
			m_pSim->ReadNcReg(&RBNR, 17, 2);
			m_pSim->ReadNcReg(&RBCR0, 15, 2);
		} else {
			m_pSim->ReadTcReg(&RBNR, 17, 2, 0);
			m_pSim->ReadTcReg(&RBCR0, 15, 2, 0);
		}*/

		// 0x1c: cause code and 0x10: handler address of syserr in the context is saved in the register bank automatically
		//UI32 mask = (RBCR0 >> p->nPriority) & 0x1;
		//if(p->sName == "eitbl" && mask == 1 && RBNR > 15 && pCB->GetHandlerAddress() != 0x10 && m_nCauseCode == 0x1c){
		//	m_nCauseCode = 0;
		//	return true;
		//}

		// Reached maximum of pending step
		if(p->nPeriod == 0)
			return true;

		// De-assert all pending events after finishing simulating random code block
		if (pCB->GetLabel().find("th_end_sync") != std::string::npos){
				return true;
		}

		// Same event is requested in next instruction.
		if(!pIns->Behavior(IInstruction::JMP)) {
			IInstruction *pNext = nullptr;
			if(pIns->InC2B1Ins() && pIns->GetForwardIns() != nullptr && !pIns->GetForwardIns()->Behavior(IInstruction::JMP)) {
				pNext = pCB->at(pCB->GetIndex(pIns) + 2); // Next instruction is always valid
			} else{
				pNext = pCB->at(pCB->GetIndex(pIns) + 1); // Next instruction is always valid
			}
			if(pNext != nullptr) {
				UI32 n = 0;
				IDirective	*pDir;
				while((pDir = pNext->GetDirective(n)) != nullptr) {
					CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
					if(pAs != NULL && CheckSameInterruptType(pAs->m_name, p->sName) && m_pRollbackIns != pNext){
						pNext->RemoveDirective(pDir);
						//return true;
					}
					n++;
				}
			}
		}

		return false;
	};

	// Movement after simulating, don't generate deassert label
	if(pIns->GetRegulationTarget() != nullptr)
		return false;

	itr = m_vRequestedIntStack.begin();
	while(itr < m_vRequestedIntStack.end()) {
		CIntInfo* pIntInfo = *itr;
		if(NeedDeassert(pIntInfo)) {
			// Generate de-assert label
			CAsyncLabel *pAsyncLabel = new CAsyncLabel(pIntInfo->sName, GetTContext(), m_nDeassertIdx++, false);
			UI32 n = 0;
			IDirective	*pDir;
			while((pDir = pIns->GetDirective(n)) != nullptr) {
				CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				// Remove assert and deassert for same events at the same time.
				if(pAs != NULL && CheckSameInterruptType(pAs->m_name, pIntInfo->sName)){
					pIns->RemoveDirective(pDir);
					delete pDir;
				}
				n++;
			}
			pIns->SetDirective(pAsyncLabel);
			itr = m_vRequestedIntStack.erase(itr);
			ret = true;
		} else
			itr++;
	}
	return ret;
}


/**
 * @brief
 * 
 * コードブロックのシミュレーションを実施する。
 * 
 */
bool CSimulatorControl::BlockSimulation(ISimulationParam* pSp, IBlockSimParam* p, TBlockConfig* tbc) {
	_ASSERT(m_pSim);
	_ASSERT(p);
	_ASSERT(p->pCodeBlock);

	UI32 break_point_weight = g_exp->GetBreakPointWeight(); // ブレークポイント生成比率取得
	CCodeBlock*		pBlk	= p->pCodeBlock;
	IInstruction*	pIns;
    IInstruction*   pNewIns;
    UI32 break_type = IBreakParam::BREAK_NONE;
    std::string labelStr;
	const UI32 htid = 0;

#if DBGMODE
    std::stringstream ss;
#endif
	
	{	// Native Dataの展開
		std::vector<UI32> vndl = pBlk->GetNativeDataArray();
		for (UI32 i = 0; i < vndl.size(); i++) {
			IInstruction* pNd = pBlk->Fetch(vndl[i]);
			m_pSim->WriteMemory (vndl[i], pNd->GetLen(), (UI32)(*pNd->opr(0)));
		}
	}

	// take snapshot(for self-check verifier)
	if (pBlk->IsEnableSnapShot() && pBlk->GetSnapShot()==nullptr) {
		CSimResource* res = GetResource();
		pBlk->SetSnapShot(res); 
	}


	if(pBlk->GetLabel() == "NM_memory_init" && m_bNewWRMemBlock) {
		IInstruction *pNewIns;
		std::stringstream ss;
		std::string label;
		m_bNewWRMemBlock = false;

		ss << "NMNT_wr_preset_memory_" << m_nWRMemBlockCount;
		ss << "_ret";
		ss >> label;
		pNewIns = MOV32P(label,11);
		pBlk->AddOpeCode(pNewIns);
		pNewIns = JMP32(11);
		pBlk->AddOpeCode(pNewIns);

		std::stringstream ss1;
		ss1 << "NMNT_wr_preset_memory_" << (m_nWRMemBlockCount + 1);
		ss1 >> label;
		pNewIns = NOP();
		pNewIns->SetLabel(label);
		pBlk->AddOpeCode(pNewIns);
		p->result.set(IBlockSimParam::BSR_REASM);
        return true; /* Re-Compile & Re-Sim */
	}

	while (true) {
		//!< Fetch Next Instrcution		
		pIns = pBlk->Fetch(p->ppc);
		if (pIns == NULL) {
			if ((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize()))) {
				MSG_ERROR(0, "Detected invalid PC={ LA:%08X, PA:%08X }\n", p->lpc, p->ppc);
				p->result.set(IBlockSimParam::BSR_FATALERROR);
				return false;	/* Sim Stop */
			}else{
				p->result.set(IBlockSimParam::BSR_JUMPING);
				p->result.set(IBlockSimParam::BSR_SUCCESS); 
				return true;	/* Jumped to other blocks */
			}
		}

        //!< Insert DBTRAP for BreakSetup
		if(break_point_weight) {
			if(pBlk->GetBreakSetupInsFlag() && pBlk->IsRegulation()	&& pBlk->GetLabel().find("callt") == std::string::npos
				 && pBlk->GetLabel().find("th_end_sync") == std::string::npos ) {	// Exclude CALLT and SYSCALL block
                m_nCurrentChannel = 0;			
                pNewIns = new CIns_218_dbtrap();
                pNewIns->SetValid(true);
                pNewIns->AppendComment("for Break Setup");
                UI32 pos = ((pBlk->GetLabel().find("codeblock_00") == std::string::npos) ? 0 : 1);
                pBlk->AddOpeCode(pNewIns, pos); //! 0 for DBTAG
				pBlk->SetBreakSetupInsFlag(false);
				IBreakParam bparam = IBreakParam();
				break_type = bparam.m_type = g_exp->GetBreakType();
				bparam.m_block_num = std::atoi(pBlk->GetName().c_str() + 15);
				bparam.m_block_label = pBlk->GetLabel();
				p->pBreakParam.push_back(bparam);
				p->pNotBreakParam.push_back(bparam);
#if DBGMODE
                fprintf(stdout,"==> Insert DBTRAP into CodeBlock Top.\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
		}

		//!< Regulation (skip regulation of instruction in which fixed code, that has no constraint, and done.) 
        UI32 psw = GetPSW();
		
		if(pBlk->GetLabel().find("_prologue") != std::string::npos ) {
			if(pIns->GetComment().find("Preset_Register_Bank_Area_000") != std::string::npos && (pIns->GetValid() != true)) {
				UI32 RBIP = 0;
				if ( m_pSim->ReadSysRegister(&RBIP, "RBIP", 0) != true ) {
					std::runtime_error excep("Simulator error : Read GR");
					throw excep;
				}
				const UI32 BankNum = 255;
				const UI32 PSIZE = 4;
				const UI32 SaveMode1 = 144;
				UI32 endAddress = RBIP - SaveMode1 * BankNum;
				for ( UI32 startAddress = RBIP; startAddress > endAddress; startAddress -= PSIZE ) {
					UI32 Value = g_rnd.GetRange((UI32)0,(UI32)(~0)) & 0xfffffff0 ;
					m_pSim->PresetMemory(true ,0 ,startAddress, PSIZE, (Value & 0xffffffff));
				}
			}
		}

		// Remove all instruction in vector block that change mode before HALT
		if(m_bNocode == true && pBlk->GetHandlerAddress() != 0 && pBlk->IsRegulation())	{		
			if(pIns->GetId() != INS_ID_JMPD32) {
				PrepareDeletedIns(pBlk, pIns);
				if(pBlk->Remove(pIns) == false){
					IInstruction* p = NOP();
					IInstruction* temp = pBlk->Replace(pIns, p);
					delete temp;
					}
				pBlk->Update();
				p->result.set(IBlockSimParam::BSR_REASM);
				return true; /* Re-Compile & Re-Sim */		
			} else
				pIns->ClearDirective();
		}
		pBlk->SetAllocated(true);

		if (pBlk->IsRegulation()){
			IInstruction *pTmp = pIns->GetRegulationTarget();
			if(pTmp != NULL && pTmp->GetId() == INS_ID_JARL) {
				std::string label(pIns->opr(0)->GetLabel());
				// Delete instruction that jump into code block that updates MPU config in UM mode
				if(label.find("mpu_function_") != std::string::npos && (psw & 0x40000000) != 0) {// UM mode
					IInstruction *pTargetIns = pIns->GetRegulationTarget();
					pTmp = pBlk->at(pBlk->GetIndex(pTargetIns) + 1);
					if(pTmp->GetLabel().size() == 0) {
						pIns->DirMoveTo(pTmp);
						PrepareDeletedIns(pBlk, pIns);
						IInstruction* pNOP1 = ReplaceInsByNop(pBlk, pIns, pIns->GetLen());
						m_pRollbackIns = pNOP1;
						pNOP1->AppendComment("Remove jarl's adjustment instruction.");

						PrepareDeletedIns(pBlk, pTargetIns);
						IInstruction* pNOP2 = ReplaceInsByNop(pBlk, pTargetIns, pTargetIns->GetLen());
						m_pRollbackIns = pNOP2;
						pNOP2->AppendComment("Remove JARL instruction");
					} else {
						PrepareDeletedIns(pBlk, pTargetIns);
						IInstruction* pNOP = ReplaceInsByNop(pBlk, pTargetIns, pTargetIns->GetLen());
						m_pRollbackIns = pNOP;
						pNOP->AppendComment("Remove JARL instruction");
						pIns->SetRegulationTarget(NULL);
						pIns->opr(0)->SetLabel("");
						pIns->opr(0)->Replace(g_rnd.Get());
					}
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
			}

			//! Add comment for mark simulation instruction 
			if(pIns->GetComment().find("--simulated") == std::string::npos)
				pIns->AppendComment("--simulated");
			if(pIns->GetValid() != true) {

				if(RegulateBeforeException(pSp, pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				if (RegulateBranchCondition(pSp, pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
				if (RegulateValueConstraint(pSp, pBlk, pIns)) {					
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}

				//!< Checking special custom Ins needed to adjust.
				if (pBlk->GetHandlerAddress() == 0) {
					if (RegulateSpecialCustomIns(pBlk, pIns)) {
						p->result.set(IBlockSimParam::BSR_REASM);
						return true;
					}
				}

				if (PreventException(pSp, pBlk, pIns)) {					
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
            } else {
                if (pIns->GetId() == INS_ID_JARL /*CIns_82_jarl*/) {
                    std::string sJmpTarget = pIns->GetJumpTarget();
                    if (sJmpTarget.find("mpu_function_") != std::string::npos) {
                        CCodeBlock*	pcb = nullptr;
                        std::vector<INode*> FunctionList = g_asf->GetFunctionBlock();
                        std::vector<INode*>::iterator func_itr = FunctionList.begin();

                        for (; func_itr != FunctionList.end(); func_itr++) {
                            pcb = static_cast<CCodeBlock*>(*func_itr);
                            if (pcb->GetLabel() == sJmpTarget) break;
                        }

                        if (/*check MIP before jump to disable_mpu*/ IsMIPexception(pcb->GetAddress(), 0xC) || RegulateMPUupdate(pcb, (pIns->opr(1)->Idx())) == false) {
                            PrepareDeletedIns(pBlk, pIns);
                            g_mgr->ReplaceInsbyOther(pBlk, pIns, pIns->GetLen());
                            p->result.set(IBlockSimParam::BSR_REASM);
                            return true; /* Re-Compile & Re-Sim */
                        }
                    }
                }
            }

			UI32 id = pIns->GetId();
			if (id == INS_ID_LDSR || id == INS_ID_LDTC_SR || id == INS_ID_LDVC_SR){
				if (RegulateBaseAddressRegister(pSp, tbc, pSp->pAsmSrcObj->GetLinker(), pBlk, pIns, htid) == false) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true;
				}
			}

		} else { // if(!pBlk->IsRegulation()){ // Generate preset memory for code block other than random code block.
			// Memory Init before first access! --> to create __preload codeblock.
			if ( pIns->Behavior(IInstruction::STORE_MEMORY) ) {
				IOperand		*pOpr;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;

				for(UI32 nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++)
				{
					pOpr = pIns->opr(nOpr);
					pOpr->AlignData(m_pSim, PFETCHSIZE);
					
				}
			}

            // regulate adjustment code of LDSR (update MPM) in MPU update
            if (pBlk->GetLabel().find("mpu_function_") != std::string::npos && pIns->GetRegulationTarget() != nullptr) {
                UI32 new_mpm = (UI32)*(pIns->opr(0)) & 0x7;
                UI32 old_mpm = m_pSim->GetMPM();
                UI32 reg_jump_val = 0;
                m_pSim->ReadGrReg(&reg_jump_val, g_mgr->GetHandlerReg(), htid);
                UI32 PC = 0, CTPC = 0;
                m_pSim->ReadPC(&PC);
                m_pSim->SetMPM(new_mpm);

                if (/*Check MIP at MPU update*/ IsMIPexception(PC + 6, 0x4) != NO_ERROR || IsMIPexception(reg_jump_val, 0x64) != NO_ERROR /*Check next 100 byte after return*/) {       //0x4: two last instruction of MPU update: synci, jump
                    new_mpm = new_mpm & (~0x5);
                    pIns->opr(0)->Replace(new_mpm);
                } else {
                    // Check MIP occur after return from callt code block
                    CCodeBlock* pCB = g_asf->Search(reg_jump_val);
                    m_pSim->ReadSysRegister(&CTPC, "CTPC", htid);
                    if (pCB->GetLabel().find("callt") != std::string::npos && IsMIPexception(CTPC, 0x64) != NO_ERROR) {
                        new_mpm = new_mpm & (~0x5);
                        pIns->opr(0)->Replace(new_mpm);
                    }
                }
                m_pSim->SetMPM(old_mpm);
            }
        }

        //!< BreakSet
		if(break_point_weight  && (!pBlk->GetBreakSetupInsFlag()) && !pBlk->GetBreakSetupDone()) {	// WeightがzeroならBreak対象としない
            
			if((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize())) && (pBlk->IsRegulation()) && (! p->bDebugExcep) && (pIns->GetId() != INS_ID_DBT) && pBlk->GetHandlerAddress() == 0) {
              
                if(( pIns->GetRegulationTarget() == nullptr ) && ( ! pIns->m_bBreakTargetIns ) && ( ! pIns->m_bBreakInsertIns )) {
                    if( pIns->m_bBreakCheckDone ) {
                        break_type = IBreakParam::BREAK_NONE;
                    } else {						                      
                        break_type = GenerateBreakPointBeforeSetup(p,pIns,pBlk);
                        if(( break_type == IBreakParam::BREAK_SS ) && ( pIns->m_bBreakNotSS )){
                            break_type = IBreakParam::BREAK_NONE;
                            p->pNotBreakParam.pop_back();
                        }
                        pIns->m_bBreakCheckDone = true; // 該当命令は、ブレーク発生要否とブレーク種別の決定を行った
                        // ブレーク種別がNONEではなく、未使用チャネルが存在する時、
                        if( break_type != IBreakParam::BREAK_NONE ) {
                            /* ブレークパラメータ発生タイミングとして、ブレーク例外発生対象命令にフラグを設定 */
                            pIns->m_bBreakTargetIns = true;
#if DBGMODE
                            fprintf(stdout,"==> At Created BreakPointSetup, Target Instruction ID:%d Index:%d Code:%s\n", pIns->GetId(),pBlk->GetIndex(pIns),pIns->GetCode().c_str());
#endif                        
                            //!< BreakInsertIns
                            // ブレーク種別がSSの時、デバッグ例外発生命令としてDBTRAP命令を挿入する
                            if( break_type == IBreakParam::BREAK_SS ) {
                                pNewIns = DBTRAP();
                                pNewIns->SetLabel(p->pNotBreakParam.back().m_addr_label);
                                pNewIns->AppendComment(" for Break_SS ");
                                pIns->DirMoveTo(pNewIns);
                                pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                                pNewIns->m_bBreakInsertIns = true;
                                pNewIns->m_bBreakCheckDone = true;
#if DBGMODE
                                fprintf(stdout,"==> Insert dbtrap instruction for Break_SS label:%s\n",pNewIns->GetLabel().c_str());
#endif
                                // DBTRAP will be in-loop if SS is generated at loop instruction.
                                if( pIns->GetId() == INS_ID_LOOP ) {
                                    pIns->SetInLoop();
                                }
                                p->result.set(IBlockSimParam::BSR_REASM);
                                return true; /* Re-Compile & Re-Sim */
                            }
                        }
                    }
                }
            }
            if( break_type == IBreakParam::BREAK_LDB ) {
                pIns->SetLabel(p->pBreakParam.back().m_addr_label);
                fprintf(stdout,"==> SetLabel %s: %s\n",pIns->GetLabel().c_str(),pIns->GetCode().c_str());
                if( pIns->GetId() == INS_ID_SWITCH ) { // SWITCH命令の場合は
                    {
                        UI32 val;
                        m_pSim->ReadGrReg(&val, pIns->opr(0)->Idx(), 0); //TODO:Multi thread not support
                        p->pBreakParam.back().m_addr = ( val << 1 ) + 2; // +2 SWITCH命令のコードサイズ２バイト分を加算したアドレスがメモリアクセス位置
                        fprintf(stdout,"==> SetAddress %#08x\n",val);
                    }
                } else {
                    p->pBreakParam.back().m_addr_label = "";
                }
            }
            // ブレーク種別がAEの時、デバッグ例外発生命令としてAE用のSPミスアライン化命令を挿入する
            if( break_type == IBreakParam::BREAK_AE ) {
                pNewIns = ORI(0x1,3,3);
                pNewIns->AppendComment(" for Break_AE ");
                pIns->DirMoveTo(pNewIns);
                pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                pNewIns->m_bBreakInsertIns = true;
#if DBGMODE
                fprintf(stdout,"==> Insert ori instruction for Break_AE\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
        }

		break_type = IBreakParam::BREAK_NONE;

		//!< Regulation done!
		pIns->SetValid(true);

		// The interrupt is asserted/de-asserted before rollback.
		if(m_bRollback == false || pIns != m_pRollbackIns ) {
			// Update status of pending interrupt, just in random code block
			if ((pBlk->GetHandlerAddress() == 0 || pBlk->IsRegulation()) && pIns != m_pInsCheckedInterrupt) {
				for(auto itr = m_vRequestedIntStack.begin(); itr < m_vRequestedIntStack.end(); itr++) {
					CIntInfo* p = *itr;
					if(p->nPeriod > 0 && pIns-> InLoop() == false)
						p->nPeriod--;
				}
			}

			//Regulate request same channel and prepare next address for request accepted
			RegulateReferenceTable(pBlk, pIns, htid);

			if (pIns != m_pInsCheckedInterrupt)	{
				CheckInterruptRequest(pSp, pBlk, pIns);
			}
		}

#if DBGMODE
        {
            UI32       nOpr;
            IOperand*  pOpr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintRetVal(m_pSim, ss);
            }
        }
#endif

		//!< Send operation code.
		ISimulatorStepResp res;
		if (Step(0, p->lpc, p->ppc, pIns, &res) == false) {
			UI32 code;
			m_pSim->GetErrorInfo(&code);
			if (code == ERR_THREAD_IS_HALT) {
				// Exit successfully
				// TODO: TO BE FIXED ( On multi thread )
				p->result.set(IBlockSimParam::BSR_EXIT_SUCCESS);
				return true;/* Sim Complete */
			}
			MSG_ERROR(0, "Simulation failed (%08X) : \"%s\"\n", code, pIns->GetCode().c_str());
			p->result.set(IBlockSimParam::BSR_FATALERROR); 
			return false; /* Sim Stop */
		}
#if DBGMODE
        {
            UI32       nOpr;
            IOperand*  pOpr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintGetVal(m_pSim, ss);
            }
        }
#endif

		//!< Exception Handling --> No operation for any exceptions without counting for report.
		if (res.exception) {
			m_nCauseCode = res.exception & 0xffff;
			IExceptionConfig* pExp = IdentifyException(p->pException, m_nCauseCode);
			if(!RegulateException(pSp, pBlk, pIns, pExp)) {
				m_bRollback = true;
				p->result.set(IBlockSimParam::BSR_ROLLBACK);
				MSG_ERROR(0, "SIM ERROR: Roll back exception name %s", pExp->m_name.c_str());
				return true; /* Re-Compile & Re-Sim */
			} else {
				// Check whether EIINT was  caused by reference table menthod
				std::vector<CIntInfo*>::iterator itr = m_vRequestedIntStack.begin();
				bool bIsEITBL = false;
				while(itr < m_vRequestedIntStack.end()) {
					if((*itr)->sName == "eitbl") {
						bIsEITBL = true;
						break;
					}
					itr++;
				}
				pIns->SetExp(true);
				// Set interrupt/exception information
				SetException(pIns, pExp, pBlk);
				// store all exception occurred
				// ADR_VECTOR_RESET <= pExp->m_addr < ADR_VECTOR_NUM. current exception differ EITBL, VECTOR_DEBUG
                if (pExp->m_addr >= IBlockManager::ADR_VECTOR_RESET && pExp->m_addr < IBlockManager::ADR_VECTOR_NUM) {
                    if (InsertHandlerAddr(pExp->m_name, pExp->m_addr) == false)
                        MSG_ERROR(0, "SIM ERROR: When insert handler address into set");
                }
					//!< BreakSet
				if(break_point_weight && pBlk->GetBreakSetupInsFlag() && !pBlk->GetBreakSetupDone() && pBlk->GetHandlerAddress() == 0) {	// WeightがzeroならBreak対象としない
					// ブレーク発生対象命令の条件は、ランダムコードブロック内でDBTRAP命令でも、プリフェッチ？（DBTRAPの次の命令）でもないこと
					if((pBlk->IsRegulation()) && (! p->bDebugExcep)) {
						UI32 cause_code = (res.exception & 0x0ffff);
						if((pExp->m_id == IException::EXP_EIINT && bIsEITBL) || cause_code == 0x95 /*MDP*/ || cause_code == 0x9D /*MDP*/ || cause_code == 0x1c /*SYSERR*/ ) {
							// Generate a breakpoint and corresponding parameter
							break_type = GenerateBreakPointBeforeSetup(p, pIns, pBlk);
							if(break_type == IBreakParam::BREAK_LSAB) {
								pIns->m_bBreakTargetIns = true;
								pIns->m_bBreakCheckDone = true;
							} else if (break_type != IBreakParam::BREAK_NONE){
								if(break_type == IBreakParam::BREAK_AE || break_type == IBreakParam::BREAK_SS)
									p->pNotBreakParam.pop_back();
								else
									p->pBreakParam.pop_back();

								// Remove breakpoint label that has set.
								if(break_type == IBreakParam::BREAK_PCB || break_type == IBreakParam::BREAK_AE) {
									UI32 nDirNum = pIns->GetDirectiveNum();
									IDirective *pDir = pIns->GetDirective(nDirNum - 1);
									pIns->RemoveDirective(pDir);
								}
								break_type = IBreakParam::BREAK_NONE;
							}
						}
					}
				}
			}	
			if(pBlk->GetLabel().find("th_end_sync") != std::string::npos){
				// Update base vector address register
				m_bNocode = true;
			}
			p->pException->CountUp(pExp->m_id);
			}
		m_bRollback = false;
		
        //!< GetBreakInfo
        // デバッグ例外発生対象命令ならば、ブレークパラメータを設定する 
        if( pIns->m_bBreakTargetIns ) {
            GenerateBreakPointSetup(p,pIns,pBlk);
		}

        // Debug Exception Flag set/reset
        switch( pIns->GetId() ) {
        case INS_ID_DBT: // DBTRAP
        case INS_ID_RMT: // RMTRAP
            p->bDebugExcep = true;
            break;
        case INS_ID_DBRET: // DBRET
            p->bDebugExcep = false;
            break;
        }

		// PC Update
		p->bPrevChain = pIns->GetChain(); // コードブロック終端判定用
		if (DecodeAddress(res.pc, &p->lpc, &p->ppc) != true) {
			MSG_ERROR(0, "Fail to transfer PC(LA:%08X)\n", p->lpc);
			return false; /* Sim Stop */
		}
	}
	
	p->result.set(IBlockSimParam::BSR_FATALERROR);
	return false; /* Sim abended */
}

/**
 *	@brief
 * 
 *	リソースデータを抽出する。
 * 
 */
CSimResource* CSimulatorControl::GetResource () {

	// Prepare
	CSimResource* res = new CSimResource();

	ISimulatorHwInfo si;
	if (m_pSim->GetSimulatorInfo(si) != true) {
		delete res;
		return nullptr;
	}
	const UI32 V = si.m_vmnum;
	const UI32 T = si.m_htnum;

	// Get GR
	for (UI32 t = 0; t < T; t++) {
		GRSET gset;
		for (UI32 r = 0; r < 32; r++) {
			UI32 val;
			m_pSim->ReadGrReg(&val, r, t);
			gset.push_back(val);
		}
		res->m_gr.push_back(gset);
	}

	// Get VR
	if (0) {
		for (UI32 t = 0; t < T; t++) {
			VRSET vset;
			for (UI32 r = 0; r < 32; r++) {
				UI64 val;
				m_pSim->ReadVeReg(&val, r, t);
				vset.push_back(val);
			}
			res->m_vr.push_back(vset);
		}
	}

	// Get SR
	std::vector <BKREG> sr;
	std::vector <BKREG>::iterator i;
	g_srs->MatchContext (0/* CSysReg::SR_CONTEXT_NC */, &sr);
	// Verify対象のNCSRを取得したので、SIMから期待値を取得
	for (i = sr.begin(); i != sr.end(); ++i) {
		UI32 val;
		m_pSim->ReadNcReg(&val, (*i) & 0x1f,  (*i)>>5);
		res->m_nc.push_back( SRVAL(*i, val) );
	}
	//std::cout << res->m_nc.size();
		
	sr.clear();
	g_srs->MatchContext (1/* CSysReg::SR_CONTEXT_VC */, &sr);
	for (UI32 v = 0; v < V; v++) {
		SRSET vs;
		for (i = sr.begin(); i != sr.end(); ++i) {
			UI32 val;
			m_pSim->ReadVcReg(&val, (*i)&0x1f,  (*i)>>5, v);
			vs.push_back( SRVAL(*i, val) );
		}
		res->m_vc.push_back(vs);
	}

	sr.clear();
	if (V > 0) {
		g_srs->MatchContext (2/* CSysReg::SR_CONTEXT_TC*/, &sr);
		for (UI32 t = 0; t < T; t++) {
			SRSET ts;
			for (i = sr.begin(); i != sr.end(); ++i) {
				UI32 val;
				m_pSim->ReadTcReg(&val, (*i)&0x1f,  (*i)>>5, t);
				ts.push_back( SRVAL(*i, val) );	
			}
			res->m_tc.push_back(ts);
		}
	}	

	m_pSim->GetMemoryWritenData(&res->m_logs);

	if (1) {
		std::ofstream ofs;
		ofs.open("expected.res");
		ofs << (*res);
		ofs << std::endl;
		ofs.close();
	}	
	
	return res;
}

bool CSimulatorControl::SyserrOccur(IInstruction* pIns, std::string name, UI32 eitbl_priority){
	UI32 RBNR = 0, RBCR0 = 0;
	UI32 adj_pri = (eitbl_priority >= 16) ? 15 : eitbl_priority;
	m_pSim->ReadNcReg(&RBNR, 17, 2);
	m_pSim->ReadNcReg(&RBCR0, 15, 2);

	if (pIns->GetId() == INS_ID_RESBANK)
		return RBNR == 0;

	if (name.size() > 0){
		UI32 mask = (RBCR0 >> adj_pri) & 0x1;
		UI32 maxBank = ((GetINTCFG() & 0x2)>>0x1 == 1) ? 254: 15;
		if (mask == 1 && RBNR > maxBank) {
			// occur syserr exception
			return true;
		}

	}
	return false;
}

/**
 *	@brief
 * 
 *	FROG New Mechanism。
 *  Regulate request same channel and prepare next address for request accepted
 */

bool CSimulatorControl::RegulateReferenceTable(CCodeBlock* pCB, IInstruction* pIns, UI32 htid) {
	_ASSERT(m_pSim);

	// handle for request interrupt was accepted
	auto HandleAcceptanceInterrupt = [&](UI32 channel) -> bool {
		// Get target code block
		UI32 NextAddress = 0;
		UI32 INTBP = 0;
		m_pSim->ReadNcReg(&INTBP, 4, 1);
        CCodeBlock* pCB = g_asf->GetNextRandomCodeBlock();
		if (pCB != NULL) {
            if (FindNewAddressforCodeBlock(pCB) == false) {
                NextAddress = g_asf->SearchAddress(GetTContext() + "th_end_sync");
            } else {
				NextAddress = pCB->GetAddress();
				}
		} else {
			NextAddress = g_asf->SearchAddress(GetTContext() + "th_end_sync");
		}

		UI32 address = INTBP + channel * 4;

		if (IsMDPexception(address, 4, true, false) == false) {
			m_pSim->PresetMemory(true, 0, address, 4, NextAddress, false);
			if(InsertHandlerAddr("eitbl", channel) == false)
				MSG_ERROR(0, "SIM ERROR: when insert INT channel into set");
            return true;
        } else {
            return false;
        }
	};

	//Check interrupt pending
	std::vector<CIntInfo*>::iterator itr;
	for (itr = m_vRequestedIntStack.begin(); itr != m_vRequestedIntStack.end(); itr++) {
		if ((*itr)->sName.find("eitbl") != std::string::npos && CheckAcceptanceCond((*itr)->sName, (*itr)->nPriority)) {

			bool SYSERR = SyserrOccur(pIns, (*itr)->sName, (*itr)->nPriority );
			if (SYSERR == true) {
				// occur syserr exception
				return false;
			}

			HandleAcceptanceInterrupt((*itr)->nChannel);
			return true;
		}
	}

	UI32 n = 0;
	IDirective	*pDir = NULL;
	CAsyncLabel *pAsyncLabel = NULL;
	while ((pDir = pIns->GetDirective(n)) != nullptr) {
		pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
		if (pAsyncLabel == NULL) {
			n++;
			continue;
		}

		std::string &name = pAsyncLabel->m_name;
		if ((pAsyncLabel->m_bAssert) && (name.find("eitbl") != std::string::npos)) {
			// check whether the channel was accessed or not. if yes, random another channel.
			UI32 count_time = 10; // magic number
			while (IsExecutedHandAddr(name, 0, pAsyncLabel->m_channel)) {
				IExceptionConfig* pExpCfg = g_exp->GetConfigByName(name);
				UI32 channel = g_rnd.GetRange(pExpCfg->m_lchannel, pExpCfg->m_uchannel);
				pAsyncLabel->m_channel = channel;
				// Convert from channel -> interrupt cause code
				UI32 causecode = pExpCfg->m_lcode + channel;
				if (causecode > pExpCfg->m_ucode)
					causecode = pExpCfg->m_ucode;
				pAsyncLabel->m_causecode = causecode;
				count_time--;

				if (count_time == 0) {
					pIns->RemoveDirective(pDir);
					delete pDir;
					n++;
					continue;
				}
			}

			if (CheckAcceptanceCond(pAsyncLabel->m_name, pAsyncLabel->m_priority)) {
				bool SYSERR = SyserrOccur(pIns, pAsyncLabel->m_name, pAsyncLabel->m_priority );
				if (SYSERR == true) {
				// occur syserr exception
					return false;
				}
                if (HandleAcceptanceInterrupt(pAsyncLabel->m_channel) == false) {
                    pIns->RemoveDirective(pDir);
                    delete pDir;
                    return false;
                }
				return true;
			} else {
				n++;
			}
		} else {
			n++;
		}
	}

	return false;
}

/**
 *	@brief
 * 
 *	This function regulate special custom instruction。
 * 
 */
bool CSimulatorControl::RegulateSpecialCustomIns(CCodeBlock* pCB, IInstruction* pIns) {

	_ASSERT(pCB);
	_ASSERT(pIns);

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	LDL_STC_CusIns_Sim* lspsim = &m_stLDL_STC_Sim;
	
	//------------------------------------------------------------
	// lambda : LDL_STCInitValue
	//------------------------------------------------------------
	//        Init value for starting sequence insert stc instruction. 
	//------------------------------------------------------------
	auto LDL_STCInitValue = [&] (IInstruction* pIns, UI32 LLBit, UI32 Address, LDL_STC_CusIns_Sim* lspsim) {
		LLBit--;
		//!< Checking init value at the first time when staring sequence. 
		if ((lspsim->LLBitSTC[LLBit].InSTCSequence == false) && (lspsim->m_loopCounter == 0)) {	
			//!< Init value for LDL_STC sequence.
			lspsim->LLBitSTC[LLBit].StartSTCSequence = true;
			lspsim->LLBitSTC[LLBit].STCTargetPosition = lspsim->m_nSTCTargetCounter + g_rnd.GetRange(0,0x10);
			lspsim->LLBitSTC[LLBit].STCAddress = Address;
			lspsim->LLBitSTC[LLBit].IsSTCSuccess =  pIns->GetCoupleIns()->IsSTCSuccess();
			lspsim->LLBitSTC[LLBit].IsLDLInLoop = lspsim->m_bIsStatusInsLoop;
				
			char buff[32];
			sprintf(buff, "%#x", lspsim->LLBitSTC[LLBit].STCTargetPosition);
			lspsim->LLBitSTC[LLBit].pInsSTC = pIns->GetCoupleIns();
			lspsim->LLBitSTC[LLBit].pInsSTC->AppendComment(buff);
			lspsim->LLBitSTC[LLBit].STCSourReg = (UI32)lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Idx();
			lspsim->LLBitSTC[LLBit].STCDestReg = (UI32)lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Idx();
			lspsim->LLBitSTC[LLBit].pInsLDL = pIns;
			pIns->AppendComment(buff);
		}
	};

	/***
	* Staring Function.
	***/
	//!< Update LLBit vector from Undo buffer.
	m_pSim->GetLLBitData(&(lspsim->m_vLLBitData));
	while ( lspsim->m_vLLBitData.size()) {
		lspsim->m_stLLBitData = lspsim->m_vLLBitData.back();
		lspsim->m_vLLBitData.pop_back();
		
		//!< Update LLBit status.
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (lspsim->m_stLLBitData.m_address);
		if (LLBitNum != 0 ) {
			LLBitNum--;
			if (lspsim->LLBitSTC[LLBitNum].STCAddress == lspsim->m_stLLBitData.m_address) {
					lspsim->LLBitSTC[LLBitNum].LLBit = true;
					//Update sequence status when LLBit is set.
					if (lspsim->LLBitSTC[LLBitNum].StartSTCSequence == true) {
						lspsim->LLBitSTC[LLBitNum].InSTCSequence = true;
					}
			} else {
					lspsim->LLBitSTC[LLBitNum].LLBit = false;
			}
		}
	}

	//!< Update loop status and position of instruction.
	lspsim->UpdateLDL_STC_Status (pCB, pIns,m_pSim);

	//!< Sequence Checking to Update ldl status then generating stc instruction.
	const UI32 LLBitMax = 2;
	for (UI32 i = 0; i < LLBitMax; i++) {
		if (lspsim->LLBitSTC[i].InSTCSequence ) {
			//!< Check condition and insert stc Ins.
			if (RegulateSpecialCustomInsSTCInsert( pCB, pIns,i,lspsim)) {
				return true;
			}
		}
	}
	//!< Find ldl custom instruction to starting sequence.
	if (pIns->IsLDL_STC_CusIns()) {
		UI32 nAddress = 0;
		if (m_pSim->ReadGrReg(&nAddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}	
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (nAddress);
		if (LLBitNum != 0) {
			// Init value of sequence at starting time.
			LDL_STCInitValue(pIns,LLBitNum,nAddress,lspsim);
		}
	}

	return false;
}
/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::RegulateSpecialCustomInsSTCInsert (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
	//------------------------------------------------------------
	// lambda : GetJmpPC
	//------------------------------------------------------------
	//        Find register that contain PC value
	//------------------------------------------------------------	
    auto GetJmpPC = [&](CCodeBlock* pCB, IInstruction* pIns) {
        UI32 BannedReg = 0;
        if (pIns->Behavior(IInstruction::JMP)) {
            UI32 idx = pCB->GetIndex(pIns);
            if (idx != 0 && pCB->at(idx - 1)->GetMne() == "mov") {
                BannedReg = pCB->at(idx - 1)->opr(1)->Idx();
            }
        }
        return BannedReg;
    };
	UI32 regPC = GetJmpPC(pCB,pIns);
	//------------------------------------------------------------
	// lambda : InsertSTCSuccess
	//------------------------------------------------------------
	//        Find condition and insert stc for successfull case. 
	//------------------------------------------------------------
	auto InsertSTCSuccess = [&] ( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
		bool InSpecCusIns = false; 
		bool IsWordIns = (pIns->GetMne() == ".word" || pIns->GetMne() == ".hword");		//Do not insert to .word or .hword instruction 
		if (pIns->GetRegulationTarget() ==  NULL) {
			InSpecCusIns = pIns->GetForward() | pIns->GetForwardLD() | pIns->InC2B1Ins() | (pIns->GetComment().find("Forwarding") != std::string::npos);
		} else {
			InSpecCusIns = pIns->GetRegulationTarget()->GetForward() | pIns->GetRegulationTarget()->GetForwardLD() | pIns->GetRegulationTarget()->InC2B1Ins();
			InSpecCusIns |= (pIns->GetRegulationTarget()->GetComment().find("Forwarding") != std::string::npos);
		}
		//!< Checking exceed max step or found clear LLBit condition. 
		if ((lspsim->m_nSTCTargetCounter > lspsim->LLBitSTC[LLBit].STCTargetPosition) || (PredictLLBitInNextIns(pCB,pIns,LLBit,lspsim))) {
			//!< Check satisfy loop condition.
			if (InSpecCusIns || IsWordIns) {
				lspsim->LLBitSTC[LLBit].STCTargetPosition++;
			}
			if ((!lspsim->LLBitSTC[LLBit].IsSTCInLoop) && (lspsim->m_loopCounter == 0) && (!InSpecCusIns) && (!IsWordIns)) {
			
				if (lspsim->LLBitSTC[LLBit].LLBit) {
					
					//!< Adjust source and destination register of stc instruction to avoid loop counter.
					if (lspsim->m_bIsStatusInsLoop) {
						UI32 idx = pCB->GetIndex(pIns);
						IInstruction *pLoopIns = NULL;
						while(idx < pCB->GetInstructionNum()) {
							pLoopIns = pCB->at(idx);
							if(pLoopIns->GetMne() == "loop")
								break;
							idx++;
						}

						//Find the register that is used as source or dest of ld/st instructions
						UI32 BannedReg = 0;
						SI32 id = pCB->GetIndex(pIns);
						if (pIns->GetLabel().find("_Lp") == std::string::npos) {
							while(id >= 0) {
								IInstruction* pTmp = pCB->at(id);

                                UI32 src = pTmp->GetOprSrc();
                                BannedReg |= src;

								if (pTmp->GetLabel().find("_Lp") != std::string::npos)
									break;
								id--;
							}
						}


						//!< Replace source dest register of stc to void loop counter and avoid register contain PC value.
						UI32 loopCounter = pLoopIns->opr(0)->Idx();
						UI32 RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
						while ((lspsim->LLBitSTC[LLBit].STCSourReg == loopCounter) || (lspsim->LLBitSTC[LLBit].STCDestReg == loopCounter) ||
                            (lspsim->LLBitSTC[LLBit].STCSourReg == regPC) || (lspsim->LLBitSTC[LLBit].STCDestReg == regPC) ||  RegConflict != 0) {
							lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
							lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
							// Checking if register is used before by ld/st
							RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
						}
					} else {
						while (lspsim->LLBitSTC[LLBit].STCDestReg == regPC || lspsim->LLBitSTC[LLBit].STCSourReg == regPC) {
							lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
							lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
						}
					}

					// Adjust address.
					IInstruction* pNewIns = MOV32(lspsim->LLBitSTC[LLBit].STCAddress,lspsim->LLBitSTC[LLBit].STCDestReg);
					pNewIns->AppendComment("Regulation code for STC in couple_success");
					pIns->DirMoveTo(pNewIns);
					pIns->SetConstraint(true);
					pNewIns->SetRegulationTarget(lspsim->LLBitSTC[LLBit].pInsSTC);
					pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
					
					lspsim->LLBitSTC[LLBit].pInsSTC->SetInLoop(lspsim->m_bIsStatusInsLoop);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Replace(lspsim->LLBitSTC[LLBit].STCSourReg);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Replace(lspsim->LLBitSTC[LLBit].STCDestReg);
					pCB->AddOpeCode(lspsim->LLBitSTC[LLBit].pInsSTC, pCB->GetIndex(pIns));
				
					// Reset sequence.
					lspsim->LLBitSTC[LLBit].Reset();
					return true;
				} else  {
					
					lspsim->LLBitSTC[LLBit].Reset();
				}
			}
		}

		return false;
	};

	auto IsFirstRegulationIns = [](CCodeBlock* pCB, IInstruction* pIns){
		IInstruction *pPrev;
		UI32 nInsPos;

		// The first instruction of CB
		nInsPos = pCB->GetIndex(pIns);
		if(nInsPos == 0)
			return true;

		// Not the first regulation instruction
		pPrev = pCB->at(nInsPos - 1);
		if(pPrev->GetRegulationTarget() != NULL)
			return false;

		return true;
	};

	//------------------------------------------------------------
	// lambda : InsertSTCFail
	//------------------------------------------------------------
	//        Find condition and insert stc for false case. 
	//------------------------------------------------------------
	auto InsertSTCFail = [&] ( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit, LDL_STC_CusIns_Sim* lspsim) {
		bool InSpecCusIns = false;
		bool IsWordIns = (pIns->GetMne() == ".word" || pIns->GetMne() == ".hword");		//Do not insert to .word or .hword instruction 
		if (pIns->GetRegulationTarget() ==  NULL) {
			InSpecCusIns = pIns->GetForward() | pIns->GetForwardLD() | pIns->InC2B1Ins();
		} else {
			InSpecCusIns = pIns->GetRegulationTarget()->GetForward() | pIns->GetRegulationTarget()->GetForwardLD() | pIns->GetRegulationTarget()->InC2B1Ins();
		}
		//!< Checking exceed max step. 
		if ((lspsim->m_nSTCTargetCounter > lspsim->LLBitSTC[LLBit].STCTargetPosition) || (!lspsim->LLBitSTC[LLBit].LLBit)) {
			//!< Check satisfy loop condition.
			if (InSpecCusIns || IsWordIns) {
				lspsim->LLBitSTC[LLBit].STCTargetPosition++;
			}
			if ((!lspsim->LLBitSTC[LLBit].IsSTCInLoop) && (lspsim->m_loopCounter == 0) && (!InSpecCusIns) && (!IsWordIns)) {
				if (!lspsim->LLBitSTC[LLBit].LLBit) {

					//Interrup exception occur in force instruction.
					if ((pIns == lspsim->LLBitSTC[LLBit].pInsForce) || (lspsim->m_pInsExp == pIns) || (pIns->GetRegulationTarget() != NULL && !IsFirstRegulationIns(pCB, pIns))) {
						return false;
					}

					//!< Adjust source and destination register of stc instruction to avoid loop counter.
					if (lspsim->m_bIsStatusInsLoop) {
						UI32 idx = pCB->GetIndex(pIns);
						IInstruction *pLoopIns = NULL;
						while(idx < pCB->GetInstructionNum()) {
							pLoopIns = pCB->at(idx);
							if(pLoopIns->GetMne() == "loop")
								break;
							idx++;
						}
						
						//Find the register that is used as source or dest of ld/st instructions
						UI32 BannedReg = 0;
						SI32 id = pCB->GetIndex(pIns);
						if (pIns->GetLabel().find("_Lp") == std::string::npos) {
							while(id >= 0) {
								IInstruction* pTmp = pCB->at(id);

                                UI32 src = pTmp->GetOprSrc();
                                BannedReg |= src;

								if (pTmp->GetLabel().find("_Lp") != std::string::npos)
									break;
								id--;
							}
						}
						
						//!< Replace source dest register of stc to avoid loop counter and source/dest of some ld/st ins in loop.
						UI32 loopCounter = pLoopIns->opr(0)->Idx();
						UI32 RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
						while ((lspsim->LLBitSTC[LLBit].STCSourReg == loopCounter) || (lspsim->LLBitSTC[LLBit].STCDestReg == loopCounter) ||
                            (lspsim->LLBitSTC[LLBit].STCSourReg == regPC) || (lspsim->LLBitSTC[LLBit].STCDestReg == regPC) || RegConflict != 0) {
							lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
							lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
							// Checking if register is used before by ld/st
							RegConflict = BannedReg & ((1 << lspsim->LLBitSTC[LLBit].STCSourReg) | (1 << lspsim->LLBitSTC[LLBit].STCDestReg));
						}
					}else {
						while (lspsim->LLBitSTC[LLBit].STCDestReg == regPC || lspsim->LLBitSTC[LLBit].STCSourReg == regPC) {
								lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
								lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
						}
					}

					// Adjust address.
					IInstruction* pNewIns = MOV32(lspsim->LLBitSTC[LLBit].STCAddress, lspsim->LLBitSTC[LLBit].STCDestReg);
					pNewIns->AppendComment("Regulation code for STC in couple_fail");
					pIns->DirMoveTo(pNewIns);
					pIns->SetConstraint(true);
					pNewIns->SetRegulationTarget(lspsim->LLBitSTC[LLBit].pInsSTC);
					pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
					
					lspsim->LLBitSTC[LLBit].pInsSTC->SetRegulationTarget(NULL);
					lspsim->LLBitSTC[LLBit].pInsSTC->SetInLoop(lspsim->m_bIsStatusInsLoop);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(0)->Replace(lspsim->LLBitSTC[LLBit].STCSourReg);
					lspsim->LLBitSTC[LLBit].pInsSTC->opr(1)->Replace(lspsim->LLBitSTC[LLBit].STCDestReg);
					pCB->AddOpeCode(lspsim->LLBitSTC[LLBit].pInsSTC, pCB->GetIndex(pIns));
	
					// Check whether ldl and stc be generated in loop sequence.
					// if ldl and stc in loop sequence wait untill to the end loop sequence then reset ldl stc sequence status.
					lspsim->LLBitSTC[LLBit].Reset();
					return true;
				} else {
					//!< Force LLBit clear.	
					if (!lspsim->LLBitSTC[LLBit].ForceSTCFail) {
						if (ForceClearLLBit (pCB, pIns,LLBit,lspsim)) {
							return true;
						}
					}
				}	
			}
		}
		
		// Intruction cause Interrupt/Exception.
		lspsim->m_pInsExp = pIns;
		return false;
	};
	
	/*
	 Function starting here.
	*/
	//!< Checking and generating stc instruction.
	if (lspsim->LLBitSTC[LLBit].IsSTCSuccess) {
		return InsertSTCSuccess(pCB,pIns,LLBit,lspsim);
	} else {
		return InsertSTCFail(pCB,pIns,LLBit,lspsim);
	}
}
/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::PredictLLBitInNextIns( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
	 
	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	//!< Check .
	UI32 nSTCaddress = lspsim->LLBitSTC[LLBit].STCAddress;
	std::string sMneIns = pIns->GetMne();
	bool bClearLLBit = false;
	UI32 cRange32Byte = 0xFFFFFFE0; 

	/*
	 @Brief  - Checking momery range 32 byte access.
			 - Pridiction condition 1.
	*/
	// Checking memory access of ST kind instructions.
	if ((sMneIns == "st.b") || (sMneIns == "st.h") || (sMneIns == "st.w") || (sMneIns == "st.dw")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of SSTC kind instructions.
	if ((sMneIns == "sst.b") || (sMneIns == "sst.h") || (sMneIns == "sst.w")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		naddress+= (UI32)(*pIns->opr(1));
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of VST instruction.
	if ((sMneIns == "vst.b") || (sMneIns == "vst.h") 
		|| (sMneIns == "vst.w") || (sMneIns == "vst.dw")) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}

		//TODO [NP]: Need to check modulo address calculating.
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}
	}
	// Checking access of SET1 & NOT1 & CLR1 instruction.
	if ((sMneIns.find("set1") != std::string::npos) || (sMneIns.find("not1") != std::string::npos) || (sMneIns.find("clr1") != std::string::npos) ) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		SI32 nImm = (SI32)((UI32)(*pIns->opr(1))); // if Disp 16 return Imm else return 0.
		naddress += nImm; 
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		}	
	}
	// Checking access of CAXI instruction.
	if (sMneIns.find("caxi") != std::string::npos) {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true){
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if ((naddress & cRange32Byte) == (nSTCaddress & cRange32Byte)) {
			bClearLLBit = true;
		} 
	}
	// Remain prepare and push instruction.
	
	/*
	 @Brief  - Using clear CLL Instruction.
			 - Pridiction condition 2.
	*/
	if ((sMneIns == "cll") || (sMneIns == "est") ||(sMneIns == "dst") ) {
		bClearLLBit = true;
	}

	/*
	 @Brief  - FE/IE return Instruction.
			 - Pridiction condition 3.
	*/
	if (pIns->GetRegulationTarget() != NULL ) {
		if ((pIns->GetRegulationTarget()->GetMne() == "feret") || (pIns->GetRegulationTarget()->GetMne() == "eiret")) {
			bClearLLBit = true;
		}
	}
	/*
	 @Brief  - LDL STC With difference type and address access.
			 - Pridiction condition 4.
	*/
	if (sMneIns == "ldl.w") {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true){
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (naddress);
		UI32 nLLBit   = (LLBit+1);
		if (LLBitNum == nLLBit) {
			bClearLLBit = true;
		}
	}

	if (sMneIns == "stc.w") {
		UI32 naddress = 0;
		if (m_pSim->ReadGrReg(&naddress, (SI32)pIns->opr(1)->Idx(),r.m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
			
		UI32 LLBitNum = g_LnkBitAddr.GetLnk (naddress);
		UI32 nLLBit   = (LLBit+1);
		if (LLBitNum == nLLBit) {
			bClearLLBit = true;
		}
	}

	//[FROG]TODO Support predict handler. 

	// Checking access of 
	if (bClearLLBit) {
		return true;
	} else {
		return false;
	}
}

/**
 *	@brief
 * 
 *	This function to be define。
 * 
 */
bool CSimulatorControl::ForceClearLLBit( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {

	IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
	
	/*Get the register that may contain PC value */
    auto GetJmpPC = [&](CCodeBlock* pCB, IInstruction* pIns) {
        UI32 BannedReg = 0;
        if (pIns->Behavior(IInstruction::JMP)) {
            UI32 idx = pCB->GetIndex(pIns);
            if (idx != 0 && pCB->at(idx - 1)->GetMne() == "mov") {
                BannedReg = pCB->at(idx - 1)->opr(1)->Idx();
            }
        }
        return BannedReg;
    };

	UI32 regPC = GetJmpPC(pCB,pIns);
	//!< Adjust source and destination register of stc instruction to avoid loop counter.
	if (lspsim->m_bIsStatusInsLoop) {
		UI32 idx = pCB->GetIndex(pIns);
		IInstruction *pLoopIns = NULL;
		while(idx < pCB->GetInstructionNum()) {
			pLoopIns = pCB->at(idx);
			if(pLoopIns->GetMne() == "loop")
			break;
			idx++;
		}

        // Find the register that is used as source or dest of ld/st instructions
        UI32 BannedReg = 0;
        SI32 id = pCB->GetIndex(pIns);
        if (pIns->GetLabel().find("_Lp") == std::string::npos) {
            while (id >= 0) {
                IInstruction* pTmp = pCB->at(id);

                UI32 src = pTmp->GetOprSrc();
                BannedReg |= src;

                if (pTmp->GetLabel().find("_Lp") != std::string::npos)
                    break;
                id--;
            }
        }
		//!< Replace source dest register of stc to void loop counter.
		UI32 loopCounter = pLoopIns->opr(0)->Idx();
        while ((lspsim->LLBitSTC[LLBit].STCSourReg == loopCounter) || (lspsim->LLBitSTC[LLBit].STCDestReg == loopCounter)
            || (lspsim->LLBitSTC[LLBit].STCSourReg == regPC) || (lspsim->LLBitSTC[LLBit].STCDestReg == regPC) || (BannedReg >> lspsim->LLBitSTC[LLBit].STCDestReg) & 0x1) {
			lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
			lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
		}
	} else {
		while (lspsim->LLBitSTC[LLBit].STCSourReg == regPC || lspsim->LLBitSTC[LLBit].STCDestReg == regPC) {
			lspsim->LLBitSTC[LLBit].STCSourReg = g_rnd.GetRange(4,29);
			lspsim->LLBitSTC[LLBit].STCDestReg = g_rnd.GetRange(4,29);
		}
	}

	//!< Check .
	bool bInloopSequence = lspsim->m_bIsStatusInsLoop;
	UI32 nFailCase;
	if (bInloopSequence) {
		nFailCase = g_rnd.GetRange(2,4);
	} else {
		nFailCase = g_rnd.GetRange(1,5);
	}
	lspsim->LLBitSTC[LLBit].ForceSTCFail = true;
	
	//------------------------------------------------------------
	// lambda : AccessToRange32Byte
	//------------------------------------------------------------
	//     Insert into store instruction access to range 32 byte protected.  
	//------------------------------------------------------------
	auto AccessToRange32Byte = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
		
		const UI32 cRange32Byte = 0xFFFFFFE0;
		UI32 nAccessAddress = (lspsim->LLBitSTC[LLBit].STCAddress & cRange32Byte);
		UI32 nRegSTCDest = lspsim->LLBitSTC[LLBit].STCDestReg;
		UI32 nRegSTCSour = lspsim->LLBitSTC[LLBit].STCSourReg;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		UI32 size;
		IInstruction* pNewIns = NULL;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());

		UI32 ncase =  g_rnd.GetRange(1,6);
		std::set<MEMRANGE> AddSet = g_StorableAddr.KeySet();
		std::set<MEMRANGE>::iterator itr;
		IValConstraint *pConst;
		switch (ncase) {
			//!< Insert ST Instruction.
			case 1:
				// Id Ins 165 to 171 are Id ins of st instruction.
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_ST_B_SD16, INS_ID_ST_W_SD23))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				//nAccessAddress &=  (~(pNewIns->opr(1)->GetConstraint()->m_nMsk));
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Insert SST Instruction.
			case 2:
				// Ins Id of SST is 162 to 164
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_SST_B, INS_ID_SST_W))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert SET1 CLR1 NOT1 Instruction.
			case 3:
				switch (g_rnd.GetRange(1,3)) {
					//!< CLR1 Instruction.
					case 1:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_CLR1_SD16, INS_ID_CLR1))->Fix();
					break;
					//!< NOT1 Instruction.
					case 2:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_NOT1SD16, INS_ID_NOT1))->Fix();
					break;
					//!< SET1 Instruction.
					case 3:
						pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_SET1_SD16, INS_ID_SET1))->Fix();
					break;
				}
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pConst = pNewIns->opr(1)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert CANXI Instruction.
			case 4:
				pNewIns = pInsSet->CreateIns(INS_ID_CAXI)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pNewIns->opr(0)->Replace(nRegSTCDest);
				pNewIns->opr(2)->Replace(nRegSTCSour);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			// Insert Push Instruction.
			case 5:
				pNewIns = pInsSet->CreateIns(INS_ID_PUSHSP)->Fix();
				pIns->DirMoveTo(pNewIns);
				pNewIns->SetInLoop(InloopSequence);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
				size++;	
			break;
			// Insert Prepare Instruction.
			case 6:
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INST_ID_PREPARE, INST_ID_PREPARE_I32))->Fix();
				pIns->DirMoveTo(pNewIns);
				pNewIns->SetInLoop(InloopSequence);
				pConst = pNewIns->opr(0)->GetConstraint();
				if(pConst != NULL) {
					pConst->SetRange(nAccessAddress, nAccessAddress + 32);
					pConst->SetType(IValConstraint::ACCESS_RANGE);
				}
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
		}
		
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};
	//------------------------------------------------------------
	// lambda : ClearByIERET_FERET
	//------------------------------------------------------------
	//          Insert one of FERET and IERET instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByIERET_FERET = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
		UI32 ncase =  g_rnd.GetRange(1,2);
		IInstruction* pAdjustIns;
		IInstruction* pNewIns = NULL;
		UI32 reg1 = lspsim->LLBitSTC[LLBit].STCDestReg;
		//UI32 reg2 = lspsim->m_nSTCSourtReg;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		
		char buff[100];
		sprintf(buff, "_ldl_stc_%#x_%#x_%#x", lspsim->LLBitSTC[LLBit].STCAddress, lspsim->LLBitSTC[LLBit].STCTargetPosition, (LLBit+1));
		std::string dstInsLabel = pCB->GetLabel()+buff;
			
		switch (ncase) {
			//!< Generating eiret instruction.
			case 1:
				pNewIns = new CIns_74_eiret();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->m_bBreakNotSS = true;
				pNewIns->SetTaken(true);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				pAdjustIns  = MOV32P (dstInsLabel, reg1);
				pIns->DirMoveTo(pAdjustIns);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));


				pAdjustIns = LDSR (reg1, 0, 0); // R->eipc
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns  = STSR (5, reg1, 0); // psw->R // Rの値を潰してPC依存を切断
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns = LDSR (reg1, 1, 0); // R->eipsw
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pIns->SetLabel(dstInsLabel);

			break;

			case 2:
				pNewIns = new CIns_75_feret();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->m_bBreakNotSS = true;
				pNewIns->SetTaken(true);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));

				pAdjustIns  = MOV32P (dstInsLabel, reg1);
				pIns->DirMoveTo(pAdjustIns);
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));


				pAdjustIns = LDSR (reg1, 2, 0); // R->fepc
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns  = STSR (5, reg1, 0); // psw->R // Rの値を潰してPC依存を切断
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pAdjustIns =LDSR (reg1, 3, 0); // R->fepsw
				pAdjustIns->m_bBreakNotSS = true;
				pAdjustIns->SetRegulationTarget(pNewIns);
				pCB->AddOpeCode(pAdjustIns, pCB->GetIndex(pNewIns));

				pIns->SetLabel(dstInsLabel);
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};
	//------------------------------------------------------------
	// lambda : ClearByCLL
	//------------------------------------------------------------
	//          Insert one of CLL instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByCLL_EST_DST = [&] (CCodeBlock* pCB, IInstruction* pIns) {
		IInstruction* pNewIns;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		// Insert CLL Instruction.
		pNewIns = new CIns_55_cll();
		pNewIns->SetInLoop(InloopSequence);
		pIns->DirMoveTo(pNewIns);
		pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};

	//------------------------------------------------------------
	// lambda : ClearByLDL_STC
	//------------------------------------------------------------
	//          Insert ldl and stc instruction to clear LLBit  
	//------------------------------------------------------------
	auto ClearByLDL_STC = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
		UI32 ncase =  g_rnd.GetRange(1,2);
		UI32 nRegSTCDest = lspsim->LLBitSTC[LLBit].STCDestReg;
		UI32 nRegSTCSour = lspsim->LLBitSTC[LLBit].STCSourReg;
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		IInstruction* pNewIns = NULL;
		CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());	

		switch (ncase) {
			//!< Generating ldl instruction.
			case 1:
				pNewIns = pInsSet->CreateIns(INS_ID_LDL_W)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->opr(0)->Replace(nRegSTCDest);
				pNewIns->opr(1)->Replace(nRegSTCSour);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;

			case 2:
				pNewIns = pInsSet->CreateIns(INS_ID_STC_W)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pNewIns->opr(0)->Replace(nRegSTCSour);
				pNewIns->opr(1)->Replace(nRegSTCDest);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};

	//------------------------------------------------------------
	// lambda : ClearByExecption
	//------------------------------------------------------------
	//      Insert expection or interupt to clear LLBit  
	//------------------------------------------------------------
	auto ClearByExecption = [&] (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBit ,LDL_STC_CusIns_Sim* lspsim) {
	
		//There are 7 kind of exception which is used to clear ll bit, they was indexed from 0 to 6
		UI32 ncase =  g_rnd.GetRange(0,6);
		bool InloopSequence = lspsim->m_bIsStatusInsLoop;
		IInstruction* pNewIns = NULL;
		static CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());

		// Collect the weight of exception to avoid generating the disabled exception
		static UI32 ExpWeight[7] = {
			pInsSet->GetWeight(CIns_76_fetrap::m_id) + g_exp->GetWeight(IException::EXP_FETRAP), 
			pInsSet->GetWeight(CIns_184_trap::m_id) + g_exp->GetWeight(IException::EXP_TRAP0) + g_exp->GetWeight(IException::EXP_TRAP1),
			// TODO: Modify for G4MH20
			pInsSet->GetWeight(CIns_193_hvtrap::m_id),

			pInsSet->GetWeight(CIns_127_rie::m_id) + pInsSet->GetWeight(CIns_128_rie::m_id) + g_exp->GetWeight(IException::EXP_RIE),
			pInsSet->GetWeight(CIns_192_hvcall::m_id),
			pInsSet->GetWeight(CIns_183_syscall::m_id ),
			g_exp->GetWeight(IException::EXP_UCPOP0) + g_exp->GetWeight(IException::EXP_UCPOP1) + g_exp->GetWeight(IException::EXP_UCPOP2)
		};

		for (UI32 i = 0; i < 7 /*size of above array*/; i++) {
			if (ExpWeight[ncase] != 0) 
				break;
			else 
				ncase = (ncase + 1) % 7;
		}
		
		if (ExpWeight[ncase] == 0)
			ncase = 7;

		switch (ncase) {
			//!< Generating FETRAP.
			case 0:
				pNewIns = pInsSet->CreateIns(INS_ID_FETRAP)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating TRAP.
			case 1:
				pNewIns = pInsSet->CreateIns(INS_ID_TRAP)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating HVTRAP.
			case 2:
				pNewIns = pInsSet->CreateIns(INS_ID_HVTRAP)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating RIE.
			case 3:
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_RIE, INS_ID_RIE_I9))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating HVCALL.
			case 4:
				pNewIns = pInsSet->CreateIns(INS_ID_HVCALL)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating SYSCALL.
			case 5:
				pNewIns = pInsSet->CreateIns(INS_ID_SYSCALL)->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			//!< Generating UCPOP.
			case 6:
				// [FROG]TODO: If SIMD was enable, it is not cause UCPOP
				pNewIns = pInsSet->CreateIns(g_rnd.GetRange(INS_ID_CNVQ15Q30, INS_ID_VXOR))->Fix();
				pNewIns->SetInLoop(InloopSequence);
				pIns->DirMoveTo(pNewIns);
				pCB->AddOpeCode(pNewIns, pCB->GetIndex(pIns));
			break;
			default:
				// If there are no suiatble exception, clear by accessing memory
				AccessToRange32Byte(pCB,pIns,LLBit,lspsim);
			break;
		}
		//Record Instruction use to Force.
		lspsim->LLBitSTC[LLBit].pInsForce = pNewIns;
	};

	switch (nFailCase) {
		
		// Generate access to range 32 byte link bit protected. 
		case 1:
			AccessToRange32Byte(pCB,pIns,LLBit,lspsim);
			return true;
		break;
		 // Clear by CLL instruction.
		case 2:
			ClearByCLL_EST_DST(pCB,pIns);
			return true;
		break;
		 // Clear by eiret, feret instructions.
		case 3:
			ClearByIERET_FERET(pCB,pIns,LLBit,lspsim);
			return true;
		break;
		 // Clear by ldl and stc instruction.
		case 4:
			ClearByLDL_STC(pCB,pIns,LLBit,lspsim);
			return true;
		break;
		// Clear by expection.
		case 5:
			ClearByExecption(pCB,pIns,LLBit,lspsim);
			return true;
		break;
	}

	return false;

}

void CSimulatorControl::PrepareDeletedIns(CCodeBlock *pCB, IInstruction *pIns) {
	SI32 idx = pCB->GetIndex(pIns) - 1;
	IInstruction *p;

	if (pIns->GetRiePartner() != nullptr) {
		pCB->Remove(pIns->GetRiePartner());
		//pIns->SetRiePartner(nullptr);
		pCB->Update();
	}
	// Remove link to its adjustment code.
	while(idx >= 0) {
		p = pCB->at(idx);
		if(p->GetRegulationTarget() != NULL) {
			if(p->GetRegulationTarget() == pIns)
				p->SetRegulationTarget(nullptr);
		} else if(p->GetForwardIns() != NULL) { // If removed instruction is 2nd ins. of C2B1
			if(p->GetForwardIns() == pIns)
				p->SetForwardIns(nullptr);
		} /*else
			break;*/
		idx--;
	}
	// Deleted instruction is 1st in couple
	if(pIns->GetForwardIns() != NULL)
		pIns->GetForwardIns()->ClearInsNeed();

	if(pIns->GetId() == INS_ID_SWITCH)
		for(UI32 i = pCB->GetIndex(pIns) + 1; i < pCB->GetInstructionNum(); i++)
			if(pCB->at(i)->GetId() == INS_ID_SHORT){
				pCB->at(i)->SetInLoop(pIns->InLoop());
				pCB->at(i)->SetSequence(pIns->InSequence());
				g_mgr->ReplaceInsbyOther(pCB, pCB->at(i), 2); // SHORT->GetLen == 2
			}else
				break;
}

/**
* @brief  replace pIns instruction by NOPs that suitable with instruction len
* @return pIns after replace
*/
IInstruction* CSimulatorControl::ReplaceInsByNop(CCodeBlock *pCB, IInstruction* pIns, UI32 delSize) {
	IInstruction* pNop = NOP();
	pIns->MoveInsAttribute(pNop);
	UI32 pos = pCB->GetIndex(pIns);
	IInstruction* temp = pCB->Replace(pIns, pNop);
	// Fill up lennth for couple of RIE partner instructions
	if (pIns->GetRiePartner() != nullptr) {
		delSize = delSize + 2;
		pIns->SetRiePartner(nullptr);
	}
	// Handle in CALLT block
	if (pCB->GetHandlerAddress() == IBlockManager::ADR_COMMON_CALLT /*ADR_COMMON_CALLT*/) {
		UI32 numOfNop = delSize / pNop->GetLen() - 1;
		for (UI32 i = 0; i < numOfNop; i++) {
			IInstruction* pJns = NOP();
			pJns->AppendComment("Fill the len callt block");
			pCB->Insert(pJns, pCB->at(pos + 1));
		}
	}
	delete temp;
	pCB->Update();
	return pNop;
}

IExceptionConfig* CSimulatorControl::IdentifyException(IException* pExp, UI32 code) {
	std::vector<IExceptionConfig*> vExp;
	std::vector<IExceptionConfig*>::iterator itr;
	IExceptionConfig* pCfg = NULL;
	vExp = pExp->GetConfigByCode(code);

	if(vExp.size() == 0)
		return NULL;

	if(vExp.size() == 1)
		return vExp[0];

	itr = vExp.begin();
	while(itr < vExp.end()) {
		std::string exp = (*itr)->m_name;
		std::vector<CIntInfo*>::iterator itrReqEvent;
		// Convert to lower cases
		std::transform(exp.begin(), exp.end(), exp.begin(), [] (int ch) {return tolower(ch);});
		if((*itr)->m_bIsInterrupt) {
			for(itrReqEvent = m_vRequestedIntStack.begin(); itrReqEvent < m_vRequestedIntStack.end(); itrReqEvent++){
				if(CheckSameInterruptType(exp,(*itrReqEvent)->sName)){
					break;
				}
			}
			if(itrReqEvent == m_vRequestedIntStack.end()) {
				itr = vExp.erase(itr);
				continue;
			}
		} else {
			pCfg = (*itr);
			itr = vExp.erase(itr);
			continue;
		}
		itr++;
	}
	// There is no async. event requested.
	if(vExp.size() == 0)
		return pCfg;
	else {
		//TODO: Generalize this sequence
		if(vExp.size() == 2 && vExp[1]->m_name == "dbnmi"){
			pCfg = vExp[1];
		} else
			pCfg = vExp[0];
	}
	return pCfg;
}

bool CSimulatorControl::RegulateBaseAddressRegister(ISimulationParam* pSp, TBlockConfig* tbc, CLinker* pClinker, CCodeBlock* pCB, IInstruction *pIns, UI32 htid) {
	_ASSERT(pClinker);

	UI32 sr = (UI32)*(pIns->opr(1));
	UI32 reg = 0, reg_temp = 0;
	reg_temp = reg = pIns->opr(0)->Idx();
	UI32 size = 0, val_reg = 0, align = 0, mask = 0;
	UI32 basereg = 0; // 0 - CTBP, 1 - SCBP, 2 - INTBP, 3 - EBASE, 4 - GMEBASE, 5 - GMINTBP
	bool flag_result = false;
	

	if ((sr == 32 * 0 + 20) || (sr == 32 * 1 + 12) || (sr == 32 * 1 + 4)   /*CTBP, SCBP, INTBP*/
		|| (sr == 32 * 1 + 3) || (sr == 32 * 9 + 19) || (sr == 32 * 9 + 20)){ /*EBASE, GMEBASE, GMINTBP*/
		// Do not regulate more time instruction in loop
		if (pIns->IsRegulate()) return true;

		//if a request interrupt accepted, update these base register do not succeed
		IDirective	*pDir = NULL;
		CAsyncLabel *pAsyncLabel = NULL;
		UI32		n = 0;
		while ((pDir = pIns->GetDirective(n)) != nullptr) {
			pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
			if (pAsyncLabel == NULL) {
				n++;
				continue;
			}

			IExceptionConfig* pExpCfg = g_exp->GetConfigByName(pAsyncLabel->m_name);
			if (pAsyncLabel->m_bAssert && CheckAcceptanceCond(pAsyncLabel->m_name, pAsyncLabel->m_priority) == true
				&& !(pExpCfg->m_addr == 0xB0 && g_exp->GetBreakPointWeight() != 0)) {
				return true;
			}
			break;
		}
		UI32 psw = 0, pswh;
		m_pSim->ReadNcReg(&psw, 5, 0);
		m_pSim->ReadNcReg(&pswh, 15, 0);
		// G4MH privilege: CTBP(UM), SCBP(SV), INTBP(SV), EBASE(HV/SV), GMEBASE(HV), GMINTBP(HV).
		// PIE exception occur if instrucion execute do not have privilege. In this case, writing is ignored
		if ((psw & 0x40000000) != 0 && (sr != 32 * 0 + 20)) return true;
		if (( pswh & 0x80000000) != 0 && ((sr == 32 * 9 + 19) || (sr == 32 * 9 + 20))) return true;

		switch (sr){
			// max length of any instruction is 6 byte
			// load/store array have max instruction is 8. So Here, choise 10
			case (32 * 0 + 20) : size = MAX_ENTRY_CALLT * 2 /*lookup table*/ + MAX_ENTRY_CALLT * 10 * 6 /*code block*/ + 3 * 6 /*dead code*/ + 20 * 4 /*max ctret were inserted*/;
				basereg = 0;
				align = 2;
				break;
			case (32 * 1 + 12) : size = MAX_ENTRY_SYSCALL * 4 /*lookup table*/;
				basereg = 1;
				align = 2;
				break;
			case (32 * 1 + 4) : size = (g_mgr->GetMaxChannelInterrupt(g_exp->GetException())) * 4 /*reference table*/;
				basereg = 2;
				align = 512;
				break;
			case (32 * 1 + 3): size = 0x200 /*handler block size*/;
				basereg = 3;
				align = 512;
				break;
			case (32 * 9 + 19): size = 0x200 /*handler block size*/;
				basereg = 4;
				align = 512;
				break;
			case (32 * 9 + 20): size = (g_mgr->GetMaxChannelInterrupt(g_exp->GetException())) * 4 /*reference table*/;
				basereg = 5;
				align = 512;
				break;
			default:
				_ASSERT(false);
				break;
		}

		mask = ~(align - 1);
		if (reg == 0) reg = reg_temp = 1; //value of r0 alway is 0
		//handle all general register and find valid value
		// e.g: current reg is r4 then execution order maximum is 4,5,..,31,1,2,3
		do {
			// Do not change register if it is used in loop sequence
			if (pIns->InLoop()) {
				UI32 vNotUse = g_mgr->GetConstraintRegister(pCB, pIns);
				if (((1 << reg_temp) && vNotUse) == 1) {
					reg_temp++;
					if (reg_temp == 32) reg_temp = 1;
					continue;
				}
			}

			m_pSim->ReadGrReg(&val_reg, reg_temp, htid);
			val_reg = val_reg & mask;
			if (pClinker->AllocAddress(val_reg, val_reg + size) == true){
				flag_result = true;
				break;
			}

			reg_temp++;
			if (reg_temp == 32) reg_temp = 1;

		} while (reg_temp != reg);

		if (flag_result) {
			pIns->opr(0)->Replace(reg_temp);
			pIns->SetRegulate(true);
			// handle for each callt, syscall, interrupt block
			switch (basereg) {
				case 0: AllocateCalltBlock(pSp, tbc, pCB, val_reg, MAX_ENTRY_CALLT * 10 * 6);
					break;
				case 1: m_setEntry_SysCall.clear();
					break;
				case 2: m_setEntry_ReferenceTable.clear();
					break;
				case 3:
				
				{
					UI32 hvcfg = 0;
					m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);
					if((hvcfg & 0x1) == 1) {
						UI32 pswh = 0;
						m_pSim->ReadSysRegister(&pswh, "PSWH", 0);
						// Guest mode access EBASE->GMEBASE
						if(pswh & 0x80000000){
							m_setGMHandlerAddress.clear();
							tbc->m_bNC = false;
						}else
							m_setHandlerAddress.clear();
					} else
						m_setHandlerAddress.clear();
				}

					AllocateNewHandler(pSp, tbc, pCB, val_reg);
					tbc->m_bNC = true;
					break;
				case 4:
					m_setGMHandlerAddress.clear();
					tbc->m_bNC = false;
					AllocateNewHandler(pSp, tbc, pCB, val_reg);
					tbc->m_bNC = true;
					break;
				case 5:
					m_setGMEntry_ReferenceTable.clear();
					break;

				default:
					_ASSERT(false);
					break;
			}
		}
		else{
			g_mgr->ReplaceInsbyOther(pCB, pIns, pIns->GetLen());
			return false;
		}
	}
	return true;
}


void CSimulatorControl::AllocateCalltBlock(ISimulationParam* pSp, TBlockConfig* tbc, CCodeBlock* pCB, UI32 address, UI32 blocksize) {
	// Make label for callt code block
	UI32 pc;
    m_pSim->ReadPC(&pc);

	std::string label = pCB->GetLabel();
	std::string label_num = label.substr(label.find_last_of("_") - 2) + "_" + std::to_string(pc % 1000);

	CPreloadBlock* pCalltBlock = g_mgr->GenerateCalltBlock(tbc, label_num, blocksize);
	pCalltBlock->SetAddress(address);
	pCalltBlock->Update(); // calculate address for each instruction

	m_vEntry_Callt.clear();

	// calculate address for each instruction and corresponding label
	pSp->pAsmSrcObj->LinkCodeBlock(pCalltBlock);
	pSp->pAsmSrcObj->AddNode(pCalltBlock);
	UI32 i = 0;
	IInstruction* pIns = pCalltBlock->at(i);
	UI32 baseAddr = pCalltBlock->GetAddress();

	while (pIns->GetMne() == ".hword"){
		m_pSim->WriteMemory(baseAddr, 2, (UI32)*pIns->opr(0));
		baseAddr += pIns->GetLen();
		i++;
		pIns = pCalltBlock->at(i);
	}
}

/* @brief check whether memory area(start to end) have occur MIP/MDP or not.
 * @return true if memory area occur MIP/MDP exception
 */

UI32 CSimulatorControl::CheckMPUexception(MEMADDR start_addr, UI32 size, UI32 mask){
    UI32 error_code = NO_ERROR;
    UI32 mpm = m_pSim->GetMPM();
    UI32 spid_mpidn = m_pSim->GetSPID_MPIDn();
    UI32 permission = 0;
    UI32 hbe = 0, hvcfg = 0;
    FrogRegData val = 0;

    gcs_get_nc_register("GMMPCFG", &val);
    hbe = ((UI32)val >> 8) & 0x3f;
    gcs_get_nc_register("HVCFG", &val);
    hvcfg = (UI32)val;

    UI32 end_addr = start_addr + size - 1;

    // match: checking whether addr has belong to any MPU channel or not.
    // start, end is start channel and end channel. 
    // svp_mask: variable to check permission depend on GMMPM.SVP

    auto GetPermission = [=](UI32 start_entry, UI32 end_entry) -> UI32 {
        UI32 permission = 0;

        for (UI32 mpidx = start_entry; mpidx < end_entry; mpidx++) {
            UI32 mpu_lower = m_pSim->GetMPLA(mpidx);
            UI32 mpu_upper = m_pSim->GetMPUA(mpidx) | 0x3;
            if (mpu_lower >= mpu_upper) {
                continue;
            }
            if ((mpu_lower > start_addr) || (end_addr > mpu_upper)) {
                //!・・OutOfRange
                continue;
            }

            UI32 mpat = m_pSim->GetMPAT(mpidx);
            if ((mpat & 0x80) == 0) {
                // channel is disable
                continue;
            }

            if ((mpat & 0x4000) != 0 || ((mpat >> 16) & spid_mpidn) != 0) {	// Check XR permission
                permission |= (mpat & 0x2d);
            }

            if ((mpat & 0x8000) != 0 || ((mpat >> 24) & spid_mpidn) != 0) { // Check W permission
                permission |= (mpat & 0x12);
            }
        }
        return permission;
    };

    if ((hvcfg & 0x1) != 0) {
        if ((mpm & 0x1) != 0) {
            permission = IsGuestMode() ? GetPermission(0, hbe) : GetPermission(hbe, g_hwInfo.m_mpnum);
            if ((mpm & 0x2) == 0) permission |= 0x38;  // MPM.SVP

            if ((permission & mask) != mask) {
                error_code = IsGuestMode() ? VIOLATE_GUEST_ENTRY : VIOLATE_HOST_ENTRY;
                return error_code;
            }
        }

        if ((mpm & 0x4) != 0) {
            permission = GetPermission(hbe, g_hwInfo.m_mpnum);

            if ((permission & mask) != mask) {
                error_code = VIOLATE_HOST_ENTRY;
                return error_code;
            }
        }

    } else {
        // Convention mode
        permission = GetPermission(0, g_hwInfo.m_mpnum);
        if ((mpm & 0x2) == 0) permission |= 0x38;     // MPM.SVP

        if ((permission & mask) != mask) {
            error_code = VIOLATE_CONVENTION_ENTRY;
            return error_code;
        }
    }

    return error_code;
}

bool CSimulatorControl::IsMIPexception(MEMADDR start_addr, UI32 size) {
    UI32 PSW = GetPSW();
    UI32 constexpr MP_HandlerAddr = 0x90;
    UI32 mip_mask = (PSW & 0x40000000) ? 0x4 : 0x20;
    UI32 error_code = CheckMPUexception(start_addr, size, mip_mask);

    if (error_code != NO_ERROR) {
        std::string exp_name = "MIP";

        if (error_code == VIOLATE_HOST_ENTRY)
            exp_name = "MIP_HM";

        if (IsExecutedHandAddr(exp_name, MP_HandlerAddr, 0)) {
            return true;
        } else {
            UI32 ebase = 0;
            UI32 BaseHandlerAddr = GetBaseAddrHandlerReg(exp_name, MP_HandlerAddr);

            if (BaseHandlerAddr == CSimulatorControl::EXP_EBASE_ADDR) {
                m_pSim->ReadSysRegister(&ebase, "EBASE", 0);
            } else {
                m_pSim->ReadSysRegister(&ebase, "GMEBASE", 0);
            }

            if (CheckMPUexception(ebase + MP_HandlerAddr, 0x10, 0x20) != NO_ERROR) {
                return true;
            }
        }
    }
    return false;
}

bool CSimulatorControl::IsMDPexception(MEMADDR start_addr, UI32 size, bool IsLoad, bool IsStore) {
    UI32 psw = GetPSW();
    UI32 constexpr MP_HandlerAddr = 0x90;
    UI32 mdp_mask = 0;

    if (IsLoad)
        mdp_mask |= (psw & 0x40000000) ? 0x1 : 0x8;

    if (IsStore)
        mdp_mask |= (psw & 0x40000000) ? 0x2 : 0x10;

    UI32 error_code = CheckMPUexception(start_addr, size, mdp_mask);

    if (error_code != NO_ERROR) {
        std::string exp_name = "MDP";

        if (error_code == VIOLATE_HOST_ENTRY)
            exp_name = "MDP_HM";

        if (IsExecutedHandAddr(exp_name, MP_HandlerAddr, 0)) {
            return true;
        } else {
            UI32 ebase = 0;
            UI32 BaseHandlerAddr = GetBaseAddrHandlerReg(exp_name, MP_HandlerAddr);

            if (BaseHandlerAddr == CSimulatorControl::EXP_EBASE_ADDR) {
                m_pSim->ReadSysRegister(&ebase, "EBASE", 0);
            } else {
                m_pSim->ReadSysRegister(&ebase, "GMEBASE", 0);
            }

            if (CheckMPUexception(ebase + MP_HandlerAddr, 0x10, 0x20) != NO_ERROR) {
                return true;
            }
        }
    }

    return false;
}
/**
*@brief	Regulate MPU update sequence
*/
bool CSimulatorControl::RegulateMPUupdate(CCodeBlock *pCB, UI32 jump_reg) {
    UI32 hvcfg = 0;
    IInstruction* pIns = nullptr;
    IInstruction* target_ins = nullptr;
    UI32 reg = 0;
    char str[80]; // Comment
    UI32 mpm = g_rnd.GetRange(0, 7);

    do {
        reg = g_rnd.GetRange(1, 30);
    } while (reg == jump_reg || jump_reg == (reg + 1));

    m_pSim->ReadNcReg(&hvcfg, 16, 1);
    // HVCFG.HVE = 1
    if ((hvcfg & 0x1) != 0) {
        if (RandomGuest_HostEntries(pCB, reg) == false)
            return false;
    } else {
        // Convention Mode
        if (RandomMPUofConventionMode(pCB, reg) == false)
            return false;
    }

    pIns = new CIns_104_mov();
    pIns->opr(0)->Replace(mpm);
    pIns->opr(1)->Replace(reg);
    sprintf(str, "MPM= 0x%08x", mpm);
    pIns->AppendComment((LPCTSTR)str);
    pCB->AddOpeCode(pIns);
    target_ins = LDSR(reg, 0, 5);
    pIns->SetRegulationTarget(target_ins);
    pCB->AddOpeCode(target_ins);
    pIns = SYNCI();
    pIns->SetSequence();
    pCB->AddOpeCode(pIns);

    pIns = JMP32(jump_reg);
    pIns->AppendComment("--> Return");
    pCB->AddOpeCode(pIns);
    g_mgr->AddDeadCode(pCB);

    if (g_asf->LinkCodeBlock(pCB) == false) {
        MSG_ERROR(0, "Fail to allocate cobe block");
        return false;
    }

    return true;
}

/**
*@brief	Random value for MPIDn (n: 0 -> 7) and SPID
*/
void CSimulatorControl::RandomMPIDn_SPID(CCodeBlock *pCB, UI32 reg) {
    const UI32 SPID_MAX = 31; //!< Maximum value of SPID.
    const UI32 MPID_NUM = 8;
    UI32 hvcfg = 0;
    UI32 selId = 5;    // selId MPID0
    UI32 regId = 24;    // regId MPID0
    UI32 SPID_value = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
    UI32 SPID_Hit = g_rnd.GetRange((UI32)0, (UI32)MPID_NUM);
    UI32 MPIDn_List[MPID_NUM]; //!< List random value of MPIDn.
    m_pSim->ReadSysRegister(&hvcfg, "HVCFG", 0);

    for (UI32 i = 0; i< MPID_NUM; i++) {
        if (SPID_Hit == 0) {
            MPIDn_List[i] = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
        } else {
            if (i <= (SPID_Hit - 1)) {
                MPIDn_List[i] = SPID_value;
            } else {
                do {
                    MPIDn_List[i] = g_rnd.GetRange((UI32)0, (UI32)SPID_MAX);
                } while (MPIDn_List[i] == SPID_value);
            }
        }
    }
    std::random_shuffle(std::begin(MPIDn_List), std::end(MPIDn_List), g_rnd);
    for (UI32 i = 0; i < MPID_NUM; i++) {
        NewINS(pCB, MOV5(MPIDn_List[i], reg));
        NewINS(pCB, LDSR(reg, regId + i, selId));
    }

    NewINS(pCB, MOV5(SPID_value, reg));
    NewINS(pCB, LDSR(reg, 0, 1));       // SPID

    if ((hvcfg & 0x1) != 0) {
        NewINS(pCB, LDSR(reg, 16, 9));       // GMSPID
    }
}

/**
*@brief Update MPU register of Host management and Guest Entries
*/
bool CSimulatorControl::RandomGuest_HostEntries(CCodeBlock *pCB, UI32 reg) {
    UI32 pswh = 0, gmmpcfg = 0;
    UI32 val = 0;
    UI32 mpnum = g_hwInfo.m_mpnum;
    T_MP_SETTING 	m_mp_table;
    IInstruction* pIns = nullptr;
    UI32 PC = 0, reserve_entry = 0;
    m_pSim->ReadPC(&PC);

    m_pSim->ReadNcReg(&gmmpcfg, 26, 9);
    m_pSim->ReadNcReg(&pswh, 15, 0);
    UI32 hbe = (gmmpcfg >> 8) & 0x3f;
    UI32 end_entry = hbe - 1;
    UI32 gpid = (pswh >> 8) & 0x7;

    // each entry has 3 regester (MPLA, MPUA, MPAT) which need to initialize
    // we use 4 byte to store value of each register
    MEMADDR vacancy_mem = m_pSim->FindVacantMemory(mpnum * 3 * 4, 4);
    if (vacancy_mem == 0) return false;
    MEMADDR temp_vacancy_mem = 0;

    if ((pswh >> 31) == 0) {
        // Host Mode
        end_entry = mpnum - 1;

        hbe = m_MPUlist->RandomHBE();
        NewINS(pCB, MOV32((hbe << 8), reg + 1));
        NewINS(pCB, LDSR(reg + 1, 26, 9));        // GMMPCFG

        m_MPUlist->Fix(HOST_ENTRY);
        m_MPUlist->OutMpuSetting(&m_mp_table, HOST_ENTRY, hbe, mpnum);
        // find locate of memory to start store MPU information of host management to memory
        temp_vacancy_mem = vacancy_mem + hbe * 4 * 3;

        for (UI32 mp_idx = hbe; mp_idx < mpnum; mp_idx++) {
            for (UI32 idx = 0; idx < 3; idx++) {
                val = m_mp_table[mp_idx][idx];
                m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
                temp_vacancy_mem = temp_vacancy_mem + 4;
            }
        }

        // Random value for MPIDn(n: 0 -> 7) and SPID
        RandomMPIDn_SPID(pCB, reg + 1);
    }

    m_MPUlist->Fix(gpid);
    m_MPUlist->OutMpuSetting(&m_mp_table, gpid, 0, hbe);

    // protect for codeblock which jump to MPU update function
    if (IsGuestMode()) {
        reserve_entry = g_prf->m_mpdemand[0];
        m_mp_table[reserve_entry][0] = PC;
        m_mp_table[reserve_entry][1] = PC + 0x3FC;
        m_mp_table[reserve_entry][2] = 0x000040ad;
    }

    temp_vacancy_mem = vacancy_mem;
    // store MPU information of guest management to memory
    for (UI32 mp_idx = 0; mp_idx < hbe; mp_idx++) {
        for (UI32 idx = 0; idx < 3; idx++) {
            val = m_mp_table[mp_idx][idx];
            m_pSim->PresetMemory(true, 0, temp_vacancy_mem, 4, val);
            temp_vacancy_mem = temp_vacancy_mem + 4;
        }
    }

    pIns = MOV32(vacancy_mem, reg);
    pIns->AppendComment(" Prepare memory for MPU update ");
    pCB->AddOpeCode(pIns);
    pIns = LDM_MP(reg, 0, end_entry);
    pIns->AppendComment(" MPU update ");
    pCB->AddOpeCode(pIns);
    return true;
}

/**
*@brief	Update MPU register of Convention entries
*/
bool CSimulatorControl::RandomMPUofConventionMode(CCodeBlock *pCB, UI32 reg) {
    UI32 val = 0, id = 0;
    UI32 mpnum = g_hwInfo.m_mpnum;
    T_MP_SETTING 	m_mp_table;
    UI32 PC = 0, reserve_entry = 0;
    m_pSim->ReadPC(&PC);

    UI32 start_entry = g_rnd.GetRange((UI32)0, mpnum - 1);
    UI32 end_entry = g_rnd.GetRange(start_entry + 1, mpnum);

    // Random a setting  machine for convention mode
    if (g_cfg->m_mGMs.size()) {
        // support random HVCFG register
        std::map<UI32, GM_Infor>::iterator gm_itr = g_cfg->m_mGMs.begin();
        UI32 idx = g_rnd.GetRange((UI32)0, g_cfg->m_mGMs.size() - 1);
        std::advance(gm_itr, idx);
        id = gm_itr->first;  //GMID
    } else {
        id = CONVENTION_ENTRY;
    }

    m_MPUlist->Fix(id);
    m_MPUlist->OutMpuSetting(&m_mp_table, id, start_entry, end_entry);

    // protect for codeblock which jump to MPU update function
    reserve_entry = g_prf->m_mpdemand[0];
    m_mp_table[reserve_entry][0] = PC;
    m_mp_table[reserve_entry][1] = PC + 0x3FC;
    m_mp_table[reserve_entry][2] = 0x000040ad;

    UI32 regId = 20, selId = 5;     // MPLA
    UI32 mpidx = 0, new_mpidx = 0;

    for (mpidx = start_entry; mpidx < end_entry; mpidx++) {
        // MPIDX
        NewINS(pCB, MOV5(mpidx, reg));
        NewINS(pCB, LDSR(reg, 16, 5));
        // MPLA
        val = m_mp_table[mpidx][0];
        NewINS(pCB, MOV32(val, reg));
        NewINS(pCB, LDSR(reg, regId, selId));
        // MPUA
        val = m_mp_table[mpidx][1];
        NewINS(pCB, MOV32(val, reg));
        NewINS(pCB, LDSR(reg, regId + 1, selId));
        // MPAT
        val = m_mp_table[mpidx][2];
        NewINS(pCB, MOV32(val, reg));
        NewINS(pCB, LDSR(reg, regId + 2, selId));
    }

    new_mpidx = mpidx - 1;
    while (g_prf->IsWorkMPURegionByIdx(new_mpidx)) {
        new_mpidx = g_rnd.GetRange((UI32)0, (UI32)mpnum - 1);
    }

    if (new_mpidx != (mpidx - 1)) {
        NewINS(pCB, MOV5(new_mpidx, reg));
        NewINS(pCB, LDSR(reg, 16, 5));
    }

    // Random value for MPIDn(n: 0 -> 7) and SPID
    RandomMPIDn_SPID(pCB, reg + 1);

    return true;
}