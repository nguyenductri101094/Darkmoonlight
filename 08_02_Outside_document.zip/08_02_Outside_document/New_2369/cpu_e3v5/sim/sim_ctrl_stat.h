#ifndef SIM_CTRL_STAT_H_
#define SIM_CTRL_STAT_H_

#include	"rtg_common.h"
#include	"ifsim_ctrl.h"
#include    "instruction.h"


//====================================== フラグ条件判定マクロ
#define _FA (0x10U)  //SAT
#define _FC (0x08U)  //CY
#define _FV (0x04U)  //OV
#define _FS (0x02U)  //S
#define _FZ (0x01U)  //Z
#define _cond_0000(f) (((f)&_FV)!=0)
#define _cond_0001(f) (((f)&_FC)!=0)
#define _cond_0010(f) (((f)&_FZ)!=0)
#define _cond_0011(f) (((f)&(_FC|_FZ))!=0)
#define _cond_0100(f) (((f)&_FS)!=0)
#define _cond_0101(f) (true)
#define _cond_0110(f) ((((f)^((f)>>1))&2)!=0)
#define _cond_0111(f) (_cond_0010(f)||_cond_0110(f))
#define _cond_1000(f) (!_cond_0000(f))
#define _cond_1001(f) (!_cond_0001(f))
#define _cond_1010(f) (!_cond_0010(f))
#define _cond_1011(f) (!_cond_0011(f))
#define _cond_1100(f) (!_cond_0100(f))
#define _cond_1101(f) (((f)&_FA)!=0)
#define _cond_1110(f) (!_cond_0110(f))
#define _cond_1111(f) (!_cond_0111(f))

#define Bcond_BGE(f) _cond_1110(f)
#define Bcond_BGT(f) _cond_1111(f)
#define Bcond_BLE(f) _cond_0111(f)
#define Bcond_BLT(f) _cond_0110(f)
#define Bcond_BH(f)  _cond_1011(f)
#define Bcond_BL(f)  _cond_0001(f)
#define Bcond_BNH(f) _cond_0011(f)
#define Bcond_BNL(f) _cond_1001(f)
#define Bcond_BE(f)  _cond_0010(f)
#define Bcond_BNE(f) _cond_1010(f)
#define Bcond_BC(f)  _cond_0001(f)
#define Bcond_BF(f)  _cond_0001(f)
#define Bcond_BN(f)  _cond_0100(f)
#define Bcond_BNC(f) _cond_1001(f)
#define Bcond_BNV(f) _cond_1000(f)
#define Bcond_BNZ(f) _cond_1010(f)
#define Bcond_BP(f)  _cond_1100(f)
#define Bcond_BR(f)  _cond_0101(f)
#define Bcond_BSA(f) _cond_1101(f)
#define Bcond_BT(f)  _cond_0010(f)
#define Bcond_BV(f)  _cond_0000(f)
#define Bcond_BZ(f)  _cond_0010(f)

#define setf_S_N(f) _cond_0100(f)
#define setf_NS_P(f) _cond_1100(f)
#define setf_C_L(f) _cond_0001(f)
#define setf_NC_NL(f) _cond_1001(f)

#define sasf_S_N(f) _cond_0100(f)
#define sasf_NS_P(f) _cond_1100(f)
#define sasf_C_L(f) _cond_0001(f)
#define sasf_NC_NL(f) _cond_1001(f)

#define cmov_S_N(f) _cond_0100(f)
#define cmov_NS_P(f) _cond_1100(f)
#define cmov_C_L(f) _cond_0001(f)
#define cmov_NC_NL(f) _cond_1001(f)

#define sbf_S_N(f) _cond_0100(f)
#define sbf_NS_P(f) _cond_1100(f)
#define sbf_C_L(f) _cond_0001(f)
#define sbf_NC_NL(f) _cond_1001(f)

#define adf_S_N(f) _cond_0100(f)
#define adf_NS_P(f) _cond_1100(f)
#define adf_C_L(f) _cond_0001(f)
#define adf_NC_NL(f) _cond_1001(f)

#define _condition_satisfied( c, f ) \
((c)== 0 ? _cond_0000(f) \
:(c)== 1 ? _cond_0001(f) \
:(c)== 2 ? _cond_0010(f) \
:(c)== 3 ? _cond_0011(f) \
:(c)== 4 ? _cond_0100(f) \
:(c)== 5 ? _cond_0101(f) \
:(c)== 6 ? _cond_0110(f) \
:(c)== 7 ? _cond_0111(f) \
:(c)== 8 ? _cond_1000(f) \
:(c)== 9 ? _cond_1001(f) \
:(c)==10 ? _cond_1010(f) \
:(c)==11 ? _cond_1011(f) \
:(c)==12 ? _cond_1100(f) \
:(c)==13 ? _cond_1101(f) \
:(c)==14 ? _cond_1110(f) \
:(c)==15 ? _cond_1111(f) \
:(false))
//======================================

enum _BRANCH_CONTINUOUS {
    JUMP_REST ,
    JUMP_TAKEN ,
    JUMP_NOT_TAKEN
} ;

union SY_ {
    UI32 v;
    std::bitset<IOperand::OPR_ATTR_NUM> tmp13;
} ;


class StatisticsInstItem {
public:
    ~StatisticsInstItem() {} ;
    StatisticsInstItem() {
        m_ref = 0 ;
        m_count = 0 ;
        m_flag_rise = 0 ;
        m_flag_fall = 0 ;
        m_seq.reset() ;
        for (UI32 i = 0 ; i < 4 ; i++) {
            m_stack[i] = 4 ;
            m_stack_or[i] = 0 ;
            m_stack_and[i] = 0xffffffffffffffffULL ;
        }
    }

    void Print(std::string key , UI32 expect , std::ofstream &ofs) {
        ofs << key << "," << std::dec << expect << "," << m_count ;
        ofs << "," << std::dec << m_flag_rise << "," << m_flag_fall ;
        for (UI32 i = 0 ; i < 4 ; i++) {
            ofs << "," << std::dec << m_stack[i] ;
            ofs << ",0x" << std::hex << std::right << std::setw(16) << std::setfill('0') << m_stack_or[i] ;
            ofs << ",0x" << std::hex << std::right << std::setw(16) << std::setfill('0') << m_stack_and[i]  ;
        }
        ofs << "," << m_seq.to_string() << std::endl ;
    }

public:
    UI32 m_ref ;
    UI32 m_count ;
    UI32 m_stack[4] ;
    UI64 m_stack_or[4] ;
    UI64 m_stack_and[4] ;
    UI32 m_flag_rise ;
    UI32 m_flag_fall ;
    std::bitset<NUM_OF_INS+1> m_seq ;
};


class StatisticsSregItem {
public:
    ~StatisticsSregItem() {}
    StatisticsSregItem() : m_stsr (0), m_ldsr (0),
                           m_inside_stvc_sr (0), m_inside_ldvc_sr (0),
                           m_inside_sttc_sr (0), m_inside_ldtc_sr (0),
                           m_outside_stvc_sr (0), m_outside_ldvc_sr (0),
                           m_outside_sttc_sr (0), m_outside_ldtc_sr (0),
                           m_other_load (0) { }

public:
    UI32 m_stsr;
    UI32 m_ldsr;
    UI32 m_inside_stvc_sr ;
    UI32 m_inside_ldvc_sr ;
    UI32 m_inside_sttc_sr ;
    UI32 m_inside_ldtc_sr ;
    UI32 m_outside_stvc_sr ;
    UI32 m_outside_ldvc_sr ;
    UI32 m_outside_sttc_sr ;
    UI32 m_outside_ldtc_sr ;
    UI32 m_other_load ;
};

#define NUM_FPU_OPR_TYPE 12

union SWITCH_DIMENSION32 {
    UI32 * d; 
    UI32 (*d1)[NUM_FPU_OPR_TYPE];
    UI32 (*d2)[NUM_FPU_OPR_TYPE][NUM_FPU_OPR_TYPE];
    UI32 (*d3)[NUM_FPU_OPR_TYPE][NUM_FPU_OPR_TYPE][NUM_FPU_OPR_TYPE];
} ;

class StatisticsFpuItem {
public:
    ~StatisticsFpuItem() {}
    StatisticsFpuItem(UI32 size) : m_ptr(nullptr) {
        if (size == 1) {
            m_ptr = reinterpret_cast<UI32*>(new UI32[NUM_FPU_OPR_TYPE]()) ;
        }
        else 
        if (size == 2) {
            m_ptr = reinterpret_cast<UI32*>(new UI32[NUM_FPU_OPR_TYPE][NUM_FPU_OPR_TYPE]()) ;
        }
        else 
        if (size == 3) {
            m_ptr = reinterpret_cast<UI32*>(new UI32[NUM_FPU_OPR_TYPE][NUM_FPU_OPR_TYPE][NUM_FPU_OPR_TYPE]()) ;
        } else {
            _ASSERT(false) ;
        }
        m_size = size ;
    }
    void Free(void) {
        delete m_ptr;
    }
    void increment(UI32 v1, UI32 v2, UI32 v3) {
        _ASSERT(m_size == 3) ;
        SWITCH_DIMENSION32 p;
        p.d = m_ptr ;
        (*p.d3)[v1][v2][v3]++ ;
    }
    void increment(UI32 v1, UI32 v2) {
        _ASSERT(m_size == 2) ;
        SWITCH_DIMENSION32 p;
        p.d = m_ptr ;
        (*p.d2)[v1][v2]++ ;
    }
    void increment(UI32 v1) {
        _ASSERT(m_size == 1) ;
        SWITCH_DIMENSION32 p;
        p.d = m_ptr ;
        (*p.d1)[v1]++ ;
    }
    void Print(std::ofstream &ofs, UI32 inst_id) {
        SWITCH_DIMENSION32 p;
        p.d = m_ptr ;
        ofs << "::FPU_OPR," << inst_id << "," << m_size << std::endl;
        if (m_size == 1) {
            for (UI32 opr1 = 0 ;opr1 < (NUM_FPU_OPR_TYPE - 1) ;opr1++ ) {
                ofs << std::dec << (*p.d1)[opr1] << ","  ;
            }
            ofs << std::dec << (*p.d1)[(NUM_FPU_OPR_TYPE - 1)] << std::endl ;
        }
        else 
        if (m_size == 2) {
            for (UI32 opr1 = 0 ;opr1 < NUM_FPU_OPR_TYPE ;opr1++ ) {
                for (UI32 opr2 = 0 ;opr2 < NUM_FPU_OPR_TYPE ;opr2++ ) {
                    ofs << std::dec << (*p.d2)[opr1][opr2] << ","  ;
                }
                ofs << std::dec << opr1 << std::endl ;
            }
        }
        else 
        if (m_size == 3) {
            for (UI32 opr1 = 0 ;opr1 < NUM_FPU_OPR_TYPE ;opr1++ ) {
                for (UI32 opr2 = 0 ;opr2 < NUM_FPU_OPR_TYPE ;opr2++ ) {
                    for (UI32 opr3 = 0 ;opr3 < NUM_FPU_OPR_TYPE ;opr3++ ) {
                        ofs << std::dec << (*p.d3)[opr1][opr2][opr3] << ","  ;
                    }
                    ofs << std::dec << opr1 << "," << opr2 << std::endl ;
                }
            }
        } else {
            _ASSERT(false) ;
        }
    }

    UI32 * m_ptr; 
    UI32 m_size;
} ;


class StatisticsJumpItem {
public:
    ~StatisticsJumpItem() {}
    StatisticsJumpItem() : m_t_after_t (0), m_t_after_nt (0), m_nt_after_t (0), m_nt_after_nt (0) ,m_taken (0) ,m_not_taken (0)
    {
        for (UI32 i = 0 ; i < (sizeof(m_difference)/sizeof(m_difference[0])) ;i++) {
            m_difference[i] = 0 ;
        }
        for (UI32 i = 0 ; i < (sizeof(m_boundary)/sizeof(m_boundary[0])) ;i++) {
            m_boundary[i] = 0 ;
        }
    }


    void SetDifference(UI32 before ,UI32 after) {
        SI32 diff = after - before ;
        UI32 pos = 18 ;
        /****/ if (diff < -0x00200000) {   // -0x80000000 ... -0x00200002
            pos = 0;
        } else if (diff < -0x00010000) {   // -0x00020000 ... -0x00010002
            pos = 1;
        } else if (diff < -0x00000100) {   // -0x00010000 ... -0x00000102
            pos = 2;
        } else if (diff < -0x00000020) {   // -0x00000100 ... -0x00000022
            pos = 3;
        } else if (diff < -0x00000010) {   // -0x00000020 ... -0x00000012
            pos = 4;
        } else if (diff < -0x00000008) {   // -0x00000010 ... -0x0000000a
            pos = 5;
        } else if (diff < -0x00000000) {   // -8 , -6 , -4 , -2
            pos = 6 + (diff + 8) / 2 ;
        } else if (diff <  0x00000002) {   //  0
            ;
        } else if (diff <  0x00000008) {   //  2 , 4 , 6
            pos = 10 + (diff - 2) / 2 ;
         } else if (diff < 0x00000010) {   //  0x00000008 ... 0x0000000e 
            pos = 13;
        } else if (diff <  0x00000020) {   //  0x00000010 ... 0x0000001e
            pos = 14;
        } else if (diff <  0x00010000) {   //  0x00000020 ... 0x0000fffe
            pos = 15;
        } else if (diff <  0x00200000) {   //  0x00010000 ... 0x001ffffe
            pos = 16;
        } else {                           //  0x00200000 ... 0x7ffffffe
            pos = 17;
        }
        m_difference[ pos ]++ ;
        m_boundary[(after & 0x1F) >> 1]++ ;
#if defined(_DBG_SIM01_)
        printf("j| m_difference[pos=%d] is %d , m_boundary[%d] is %d \n", pos , m_difference[ pos ] , ((after & 0x1F) >> 1) , m_boundary[(after & 0x1F) >> 1] );
#endif
    }

    void SetTaken(_BRANCH_CONTINUOUS prev_taken, bool taken) {
        if (taken == JUMP_TAKEN) {
            m_taken++;
            if (prev_taken == JUMP_TAKEN) {
                m_t_after_t++;
            }
            else if (prev_taken == JUMP_NOT_TAKEN) {
                m_t_after_nt++;
            }
            else {
                ; // JUMP_REST;
            }
        } else {
            m_not_taken++;
            if (prev_taken == JUMP_TAKEN) {
                m_nt_after_t++;
            }
            else if (prev_taken == JUMP_NOT_TAKEN) {
                m_nt_after_nt++;
            }
            else {
                ; // JUMP_REST;
            }
        }
    }


    UI32 GetInstId() {
        return ( m_inst_id ) ;
    }

    void SetInstId(UI32 inst_id) {
        m_inst_id = inst_id ;
    }

    void Print(std::ofstream &ofs) {
        ofs <<         std::dec << m_taken ;
        ofs << ","  << std::dec << m_not_taken ;
        ofs << ","  << std::dec << m_t_after_t ;
        ofs << ","  << std::dec << m_t_after_nt ;
        ofs << ","  << std::dec << m_nt_after_t ;
        ofs << ","  << std::dec << m_nt_after_nt ;
        ofs << ","  << std::dec << m_inst_id  << std::endl ;
    }

    void Print_difference(std::ofstream &ofs) {
        for (UI32 i = 0 ; i < (sizeof(m_difference)/sizeof(m_difference[0])) ; i++) {
            ofs << std::dec << m_difference[i] << "," ;
        }
        ofs << std::dec << m_inst_id  << std::endl ;
    }

    void Print_boundary(std::ofstream &ofs) {
        for (UI32 i = 0 ; i < (sizeof(m_boundary)/sizeof(m_boundary[0])) ; i++) {
            ofs << std::dec << m_boundary[i] << "," ;
        }
        ofs << std::dec << m_inst_id  << std::endl ;
    }

protected:
    UI32 m_inst_id ;
    UI32 m_difference[19] ;
    UI32 m_boundary[16] ;
    UI32 m_t_after_t ;
    UI32 m_t_after_nt ;
    UI32 m_nt_after_t ;
    UI32 m_nt_after_nt ;
    UI32 m_taken ;
    UI32 m_not_taken ;
} ;


class StatisticsWReg {
 public:
	StatisticsWReg() {
		for(int wr=0;wr<32;wr++) {
			for(int w=0;w<4;w++) {
				m_wreg[wr].way[w].src_cnt = 0;
				m_wreg[wr].way[w].des_cnt = 0;
			}
		}
	}
	~StatisticsWReg() {}

	void CountUp(int wr_idx, int way_num, bool flag) {
		if( flag ) {
			m_wreg[wr_idx].way[way_num].src_cnt++;
		} else {
			m_wreg[wr_idx].way[way_num].des_cnt++;
		}
	}

    void Print(std::ofstream &ofs) {
		ofs << "::WReg" <<std::endl;
		for(int wr=0;wr<32;wr++) {
			ofs << std::dec << wr;
			for(int w=0;w<4;w++) {
				ofs << "," << std::dec << m_wreg[wr].way[w].src_cnt;
				ofs << "," << std::dec << m_wreg[wr].way[w].des_cnt;
			}
			ofs << std::endl;
		}
	}
 protected:
	struct {
		struct {
			UI32 src_cnt;
			UI32 des_cnt;
		} way[4];
	} m_wreg[32];
};


class StatisticsInst {
public:
    StatisticsInst() {}
    ~StatisticsInst() {
        /* ::FPU */
        std::map<UI32,StatisticsFpuItem>::iterator itr ;
    	for (itr = m_fpu.begin() ; itr != m_fpu.end() ; itr++) {
            (*itr).second.Free() ;
        }
    }

    void Init() ;

	void BeforeAcquisition(bool is_statistics, IInstruction* pIns, ISimulator* pSim, UI32 htid) ;

    void AfterAcquisition(bool is_statistics, IInstruction* pIns, ISimulator* pSim, UI32 htid) ;

    void Print(std::ofstream &ofs) ;

    void ResetTaken() {
        m_branch_continuous = JUMP_REST ;
    }

    void SetTaken(StatisticsJumpItem * item , bool taken) {
        item->SetTaken(m_branch_continuous, taken) ;
        m_branch_continuous = (taken) ? JUMP_TAKEN : JUMP_NOT_TAKEN ;
    }

    UI32 m_fpu_idx1 ;
    UI32 m_fpu_idx2 ;
    UI32 m_fpu_idx3 ;

protected:
    UI32 FpuSingleType(UI32 val);
    UI32 FpuDoubleType(UI64 val);

    std::vector<StatisticsInstItem>	    m_inst ;
    std::vector<StatisticsJumpItem>	    m_jump ;
    std::map<UI32,StatisticsFpuItem>	m_fpu ;
    std::map<UI32,StatisticsSregItem>	m_sreg_stat ;        //key: tcid * 0x200 + selId * 0x20 + regId
    UI32 m_step_count ;
    UI32 m_before_inst_id ;
    UI32 m_psw_before ;
    UI32 m_pc_before ;
    UI32 m_peid ;
    UI32 m_vcid ;
    UI32 m_vcsel ;
    UI32 m_tcsel ;
    enum _BRANCH_CONTINUOUS m_branch_continuous;

	StatisticsWReg* m_wreg;

};



class StatisticsMemAreaItem {
public:
    ~StatisticsMemAreaItem() {} ;
    StatisticsMemAreaItem() {
        m_IsRomArea = false;
        m_read_ref = 0 ;
        m_write_ref = 0 ;
        m_read_count = 0 ;
        m_write_count = 0 ;
        m_pe = 0 ;
        m_begin_adr = 0 ;
        m_end_adr = 0 ;
        m_attr = "" ;
		m_lnk = 1 ;
        for (UI32 j = 0 ; j < 4 ; j++) {
            for (UI32 i = 0 ; i < 64 ; i++) {
                m_bus_access_intervals[j][i] = 0 ;
            }
        }
        for (UI32 i = 0 ; i < 64 ; i++) {
            m_bus_access_hopping[i] = 0 ;
        }
    }
    void CountAccessAreaHopping(UI32 before_area) {
        m_bus_access_hopping[before_area]++ ;
#if defined(_DBG_SIM01_)
        printf (".hopping[before_area=%d] is %d\n", before_area, m_bus_access_hopping[before_area]);
#endif
    }

    void SetAccessIntervalBase(UI64 addr , UI32 read1_write0) {
        m_BeforeAddress = addr ;
        m_BeforeAccess  = read1_write0 ;
    }

    void CountAccessInterval(UI64 addr , UI32 read1_write0) {
        UI32 seq = 0 ;
        if (read1_write0  == 1) {
            seq = (m_BeforeAccess == 0) ? 2 : 0 ; 
        }
        else
        if (read1_write0  == 0) {
            seq = (m_BeforeAccess == 0) ? 3 : 1 ; 
        } else {
            _ASSERT(false) ;
        }

       SI32 diff = addr - m_BeforeAddress ;
       UI32 pos ;

        /****/ if (diff < -64 ) {   //    ... -65
            pos = 0;
        } else if (diff < -32) {   // -64 ... -33
            pos = 1;
        } else if (diff < -16) {   // -32 ... -17
            pos = 2;
        } else if (diff  < 17) {   // -16 ...  16
            pos = 3 + 16 + diff ;
        } else if (diff <  32) {   //  17 ...  31
            pos = 36;
        } else if (diff <  64) {   //  32 ...  63
            pos = 37;
        } else {                   //  64 ...
            pos = 38;
        }
        m_bus_access_intervals[seq][pos]++ ;
        m_BeforeAddress = addr ;
        m_BeforeAccess  = read1_write0 ;
#if defined(_DBG_SIM01_)
        printf (".interval[seq=%d][pos=%d] is %d ", seq , pos, m_bus_access_intervals[seq][pos] );
#endif
    }


public:
    bool m_IsRomArea ;
    UI32 m_pe ;
    UI32 m_begin_adr ;
    UI32 m_end_adr ;
    UI32 m_read_ref ;
    UI32 m_write_ref ;
    UI32 m_read_count ;
    UI32 m_write_count ;
    std::string m_attr ;
	UI32 m_lnk ;

    UI32 m_BeforeAddress ;
    UI32 m_BeforeAccess;
    UI32 m_bus_access_intervals[4][64] ;
    UI32 m_bus_access_hopping[64] ;
    UI32 m_bus_access_hopping_index ;
};



class StatisticsMemory {
public:
    ~StatisticsMemory() {}
    StatisticsMemory() : m_BeforeArea(0xffffffff) {}

    void Init(UI32 expiration) ;

    void Acquisition(bool is_statistics, IInstruction* pIns, ISimulator* pSim) ;

    void Print(std::ofstream &ofs) ;

protected:
    std::vector<StatisticsMemAreaItem> m_memarea_stat ;
    UI32 m_read_access_count ;
    UI32 m_write_access_count ;
    UI32 m_bus_read_access[8][16] ;
    UI32 m_bus_write_access[8][16] ;
    UI32 m_BeforeArea;
    UI32 m_BeforeCount;
    UI32 m_expiration ;     // Number of steps to memory access expiration.
};




/**
 * @brief	シミュレータを制御するクラス
 */
class CSimulatorControl_stat : public CSimulatorControl
{
public:

	/**
	 * @brief  このオブジェクトを構築します。
	 */	
	CSimulatorControl_stat();
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */	
	virtual ~CSimulatorControl_stat();

	/**
	 * @brief	このオブジェクトを初期化します。
	 * @return	初期化に成功した場合、真を返す。
	 */	
	virtual bool Init(std::string&);

protected:
	/**
	 * @brief	ブロック単位でシミュレーションします。
	 * @return	バージョンを示す文字列
	 */	
	virtual bool BlockSimulation(ISimulationParam* pSp, IBlockSimParam* p, TBlockConfig* tbc);	

    StatisticsInst m_inst_statistics ;
    StatisticsMemory m_memory_statistics ;
};

#endif /*SIM_CTRL_STAT_H_*/
