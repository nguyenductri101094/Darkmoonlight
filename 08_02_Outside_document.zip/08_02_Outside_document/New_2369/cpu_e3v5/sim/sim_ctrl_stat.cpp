#include "sim_ctrl.h"
#include "sim_ctrl_stat.h"
#include "ifblk_manager.h"
#include "ifinstruction.h"
#include "ifinsset.h"
#include "rtg_cfg.h"
#include "ifexception.h"
#include "ifsysreg.h"
#include "ifvalconstraint.h"
#include "ifsimulator.h"
#include "simulator.h"
#include <sys/stat.h>
#include "ifbreakparam.h"
#include "insid_set.h"

extern std::shared_ptr<CGeneratorConfig>	g_cfg;
extern std::shared_ptr<CGeneratorProfile>   g_prf;
extern std::unique_ptr<IBlockManager>		g_mgr;
extern std::unique_ptr<IException>          g_exp;
extern std::unique_ptr<ISysRegSet>			g_srs;
extern std::shared_ptr<CAssemblerSourceFile>    g_asf;

#define LOGSW_INS_SIM		(!defined(NDEBUG) && 1)
#define LOGSW_REGULATION	(!defined(NDEBUG) && 0)


LPCTSTR fpu_opr_type [] ={ "UNKNOWN","CONS","+QNaN","-QNaN","+SNaN","-SNaN","+ZERO","-ZERO","+INF","-INF","+SUBNORM","-SUBNORM","+NORM","-NORM" } ;

LPCTSTR read_item_name[]= { "read_1byte" , "read_2byte" , "read_4byte" , "read_8byte" , "read_12byte" , "read_16byte" , "read_16byteOver" , "illigal"};

LPCTSTR write_item_name[]= { "write_1byte" , "write_2byte" , "write_4byte" , "write_8byte" , "write_12byte" , "write_16byte" , "write_16byteOver" , "illigal"};

LPCTSTR key_sreg[] = {
    "EIPC" ,     "EIPSW" ,    "FEPC" ,     "FEPSW" ,    "0x04" ,     "PSW" ,      "FPSR" ,     "FPEPC" ,    "FPST" ,     "FPCC" ,     "FPCFG" ,    "FPEC" ,     "SESR" ,     "EIIC" ,     "FEIC" ,     "0_0x0F" ,   
    "CTPC" ,     "CTPSW" ,    "0x12" ,     "0x13" ,     "CTBP" ,     "0x15" ,     "0x16" ,     "0x17" ,     "0x18" ,     "0x19" ,     "0x1A" ,     "0x1B" ,     "EIWR" ,     "FEWR" ,     "0x1E" ,     "BSEL" ,     
    "MCFG0" ,    "MCFG1" ,    "RBASE" ,    "EBASE" ,    "INTBP" ,    "MCTL" ,     "PID" ,      "FPIPR" ,    "0x28" ,     "0x29" ,     "TCSEL" ,    "SCCFG" ,    "SCBP" ,     "HVCCFG" ,   "HVCBP" ,    "VCSEL" ,    
    "VMPRT0" ,   "VMPRT1" ,   "VMPRT2" ,   "0x33" ,     "0x34" ,     "0x35" ,     "0x36" ,     "VMSCCTL" ,  "VMSCTBL0" , "VMSCTBL1" , "VMSCTBL2" , "VMSCTBL3" , "0x3C" ,     "0x3D" ,     "0x3E" ,     "0x3F" ,     
    "HTCFG0" ,   "0x41" ,     "0x42" ,     "0x43" ,     "0x44" ,     "HTCTL" ,    "MEA" ,      "ASID" ,     "MEI" ,      "0x49" ,     "ISPR" ,     "PMR" ,      "ICSR" ,     "INTCFG" ,   "0x4E" ,     "0x4F" ,     
    "TLBSCH" ,   "0x51" ,     "0x52" ,     "0x53" ,     "0x54" ,     "0x55" ,     "0x56" ,     "HTSCCTL" ,  "HTSCTBL0" , "HTSCTBL1" , "HTSCTBL2" , "HTSCTBL3" , "HTSCTBL4" , "HTSCTBL5" , "HTSCTBL6" , "HTSCTBL7" , 
    "VMSCPTR" ,  "HTSCPTR" ,  "0x62" ,     "0x63" ,     "0x64" ,     "0x65" ,     "0x66" ,     "0x67" ,     "0x68" ,     "0x69" ,     "0x6A" ,     "0x6B" ,     "0x6C" ,     "0x6D" ,     "0x6E" ,     "DBIC" ,     
    "0x70" ,     "DBCMC" ,    "DBPC" ,     "DBPSW" ,    "DIR0" ,     "DIR1" ,     "BPC" ,      "0x77" ,     "BPAV" ,     "BPAM" ,     "BPDV" ,     "BPDM" ,     "0x7C" ,     "0x7D" ,     "DBWR" ,     "0x7F" ,     
    "TLBIDX" ,   "0x81" ,     "0x82" ,     "0x83" ,     "TELO0" ,    "TELO1" ,    "TEHI0" ,    "TEHI1" ,    "0x88" ,     "0x89" ,     "TLBCFG" ,   "0x8B" ,     "BWERRL" ,   "BWERRH" ,   "BRERRL" ,   "BRERRH" ,   
    "ICTAGL" ,   "ICTAGH" ,   "ICDATL" ,   "ICDATH" ,   "DCTAGL" ,   "DCTAGH" ,   "DCDATL" ,   "DCDATH" ,   "ICCTRL" ,   "DCCTRL" ,   "ICCFG" ,    "DCCFG" ,    "ICERR" ,    "DCERR" ,    "0x9E" ,     "0x9F" ,     
    "MPM" ,      "MPRC" ,     "0xA2" ,     "0xA3" ,     "MPBRGN" ,   "MPTRGN" ,   "0xA6" ,     "0xA7" ,     "MCA" ,      "MCS" ,      "MCC" ,      "MCR" ,      "0xAC" ,     "0xAD" ,     "0xAE" ,     "0xAF" ,     
    "0xB0" ,     "0xB1" ,     "0xB2" ,     "0xB3" ,     "MPPRT0" ,   "MPPRT1" ,   "MPPRT2" ,   "0xB7" ,     "0xB8" ,     "0xB9" ,     "0xBA" ,     "0xBB" ,     "0xBC" ,     "0xBD" ,     "0xBE" ,     "0xBF" ,     
    "MPLA0" ,    "MPUA0" ,    "MPAT0" ,    "0xC3" ,     "MPLA1" ,    "MPUA1" ,    "MPAT1" ,    "0xC7" ,     "MPLA2" ,    "MPUA2" ,    "MPAT2" ,    "0xCB" ,     "MPLA3" ,    "MPUA3" ,    "MPAT3" ,    "0xCF" ,     
    "MPLA4" ,    "MPUA4" ,    "MPAT4" ,    "0xD3" ,     "MPLA5" ,    "MPUA5" ,    "MPAT5" ,    "0xD7" ,     "MPLA6" ,    "MPUA6" ,    "MPAT6" ,    "0xDB" ,     "MPLA7" ,    "MPUA7" ,    "MPAT7" ,    "0xDF" ,     
    "MPLA8" ,    "MPUA8" ,    "MPAT8" ,    "0xE3" ,     "MPLA9" ,    "MPUA9" ,    "MPAT9" ,    "0xE7" ,     "MPLA10" ,   "MPUA10" ,   "MPAT10" ,   "0xEB" ,     "MPLA11" ,   "MPUA11" ,   "MPAT11" ,   "0xEF" ,     
    "MPLA12" ,   "MPUA12" ,   "MPAT12" ,   "0xF3" ,     "MPLA13" ,   "MPUA13" ,   "MPAT13" ,   "0xF7" ,     "MPLA14" ,   "MPUA14" ,   "MPAT14" ,   "0xFB" ,     "MPLA15" ,   "MPUA15" ,   "MPAT15" ,   "0xFF" ,     
    "MPLA16" ,   "MPUA16" ,   "MPAT16" ,   "MPLA17" ,   "MPUA17" ,   "MPAT17" ,   "MPLA18" ,   "MPUA18" ,   "MPAT18" ,   "MPLA19" ,   "MPUA19" ,   "MPAT19",    "MPUA20" ,   "MPAT20" ,   "MPLA20" ,   "MPLA21" ,   
    "MPUA21" ,   "MPAT21" ,   "MPLA22" ,   "MPUA22" ,   "MPAT22" ,   "MPLA23" ,   "MPUA23" ,   "MPAT23" ,
    } ;



//---------------------------------------------------
//命令生成カウンタの初期化
//---------------------------------------------------
void StatisticsInst::Init() {
    StatisticsInstItem temp;
    IInstructionSet * weight_set = g_mgr->GetWeightSet();
    CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());
    IInstruction * pIns;
    union SY_ sy { 0 } ;
    UI32 idx;

    for (UI32 i= 1; i <= NUM_OF_INS ; i++) {
        temp.m_ref = weight_set->GetWeight( i );
        m_inst.push_back(temp);
        pIns = pInsSet->CreateIns(i);
        // FPU
        if (((pIns->GetCategory() & (1 << IInstruction::ICAT_SIMD)) == 0 ) && (pIns->GetCategory() & ((1 << IInstruction::ICAT_FPU_S)|(1 << IInstruction::ICAT_FPU_D)))) {
            idx = 0;
            for (UI32 i = 0 ;i < pIns->GetOpNum() ;i++) {
                IOperand* operand = pIns->opr(i);
                sy.tmp13 = operand->GetAttr();
                if ((sy.tmp13.test(IOperand::OPR_ATTR_GR)) && (sy.tmp13.test(IOperand::OPR_ATTR_SRC))  ) {
                    idx++;
                }
            }
            if( idx != 0 ) {
                StatisticsFpuItem temp(idx);
                m_fpu.insert(std::pair<UI32,StatisticsFpuItem>(pIns->GetId(),temp));
            }
        }

        // FP-SIMD
        if ((pIns->GetCategory() & (1 << IInstruction::ICAT_SIMD)) && (pIns->GetCategory() & (1 << IInstruction::ICAT_FPU_S))) {
            idx = 0;
            for (UI32 i = 0 ;i < pIns->GetOpNum() ;i++) {
                IOperand* operand = pIns->opr(i);
                sy.tmp13 = operand->GetAttr();
                if ((sy.tmp13.test(IOperand::OPR_ATTR_WR)) && (sy.tmp13.test(IOperand::OPR_ATTR_SRC)) ) {
                    idx++;
                }
            }
            if( idx != 0 ) {
                StatisticsFpuItem temp(idx);
                m_fpu.insert(std::pair<UI32,StatisticsFpuItem>(pIns->GetId(),temp));
            }
        }

    }
    //総ステップ数（ランダム部のみ）カウンタの初期化
    m_step_count = 0 ;

    //直前に実行した命令ＩＤの初期化
    m_before_inst_id = 0 ;


	// WRegアクセスカウント初期化
	m_wreg = new StatisticsWReg();
}



UI32 StatisticsInst::FpuDoubleType(UI64 val) {
    //UI32 type ; //[FROG]TODO: Support statistic for new FPU mechanism.

   /* if (val == 0) {
        type = IFpuDoubleConstraint::POSITIVE_ZERO ;
    } else if (val == 0x8000000000000000ull) {
        type = IFpuDoubleConstraint::NEGATIVE_ZERO ;
    } else if (val == 0x7ff0000000000000ull) {
        type = IFpuDoubleConstraint::POSITIVE_INF ;
    } else if (val == 0xfff0000000000000ull) {
        type = IFpuDoubleConstraint::NEGATIVE_INF ;
    } else if ((val & 0xfff8000000000000ull) == 0x7ff8000000000000ull) {
        type = IFpuDoubleConstraint::POSITIVE_QNaN ;
    } else if ((val & 0xfff8000000000000ull) == 0xfff8000000000000ull) {
        type = IFpuDoubleConstraint::NEGATIVE_QNaN ;
    } else if (((val & 0xfff8000000000000ull) == 0x7ff0000000000000ull) && ((val & 0x0007ffffffffffffull) != 0ull)) {
        type = IFpuDoubleConstraint::POSITIVE_SNaN ;
    } else if (((val & 0xfff8000000000000ull) == 0xfff0000000000000ull) && ((val & 0x0007ffffffffffffull) != 0ull)) {
        type = IFpuDoubleConstraint::NEGATIVE_SNaN ;
    } else if (((val & 0xfff0000000000000ull) == 0x0000000000000000ull) && ((val & 0x000fffffffffffffull) != 0ull)) {
        type = IFpuDoubleConstraint::POSITIVE_SUBNORM ;
    } else if (((val & 0xfff0000000000000ull) == 0x8000000000000000ull) && ((val & 0x000fffffffffffffull) != 0ull)) {
        type = IFpuDoubleConstraint::NEGATIVE_SUBNORM ;
    } else {
        UI32 se = (UI32)(val>>52);
        if (((se & 0x800) == 0ull) && ((se & 0x7ffull) != 0x7ffull) && ((se & 0x7ffull) != 0ull)) {
            type = IFpuDoubleConstraint::POSITIVE_NORM ;
        } else if (((se & 0x800) != 0ull) && ((se & 0x7ffull) != 0x7ffull) && ((se & 0x7ffull) != 0ull)) {
            type = IFpuDoubleConstraint::NEGATIVE_NORM ;
        } else {
            type = -1;
            _ASSERT(false) ;
        }
    }*/

    //return type ;
	return -1;
}



UI32 StatisticsInst::FpuSingleType(UI32 val) {
    //UI32 type ;

   /* if (val == 0) {
        type = IFpuSingleConstraint::POSITIVE_ZERO ;
    } else if (val == 0x80000000) {
        type = IFpuSingleConstraint::NEGATIVE_ZERO ;
    } else if (val == 0x7f800000) {
        type = IFpuSingleConstraint::POSITIVE_INF ;
    } else if (val == 0xff800000) {
        type = IFpuSingleConstraint::NEGATIVE_INF ;
    } else if (((val & 0xff800000) == 0) && ((val & 0x7fffff) != 0)) {
        type = IFpuSingleConstraint::POSITIVE_SUBNORM ;
    } else if (((val & 0xff800000) == 0x80000000) && ((val & 0x7fffff) != 0)) { 
        type = IFpuSingleConstraint::NEGATIVE_SUBNORM ;
    } else if ((val & 0xffc00000) == 0x7fc00000) {
        type = IFpuSingleConstraint::POSITIVE_QNaN ;
    } else if ((val & 0xffc00000) == 0xffc00000) {
        type = IFpuSingleConstraint::NEGATIVE_QNaN ;
    } else if (((val & 0xffc00000) == 0x7f800000) && ((val & 0x3fffff) != 0)) { 
        type = IFpuSingleConstraint::POSITIVE_SNaN ;
    } else if (((val & 0xffc00000) == 0xff800000) && ((val & 0x3fffff) != 0)) {
        type = IFpuSingleConstraint::NEGATIVE_SNaN ;
    } else {
        UI32 se = (UI32)(val>>23);
        if (((se & 0x100)==0) && ((se & 0xff)!=0xff) && ((se & 0xff)!=0)) {
            type = IFpuSingleConstraint::POSITIVE_NORM ;
        } else if (((se & 0x100)!=0) && ((se & 0x7ff)!=0xff) && ((se & 0xff)!=0)) {
            type = IFpuSingleConstraint::NEGATIVE_NORM ;
        } else {
            type = -1;
            _ASSERT(false) ;
        }
    }*/

    //return type ;
	return -1;
}



void StatisticsInst::BeforeAcquisition(bool is_statistics, IInstruction* pIns, ISimulator* pSim, UI32 htid) {
    if (!is_statistics) {
        m_before_inst_id = 0 ;
        return;
    }

    m_psw_before = 0;
    m_pc_before = 0;
    pSim->ReadNcReg(&m_psw_before, 5, 0);
    bool is_nm = ((m_psw_before & 0x80000000U) == 0);

    m_peid = g_cfg->m_nPeId;
    m_vcid = -1 ;
    m_vcsel = 0 ;
    m_tcsel = 0 ;
    if (is_nm) {
//      UI32 htcfg0;
//      pSim->ReadNcReg(&htcfg0, 5,  0);
//      m_peid = (htcfg0 >> 16) & 0x3f ;
        pSim->ReadNcReg(&m_vcsel, 15,  1);
        pSim->ReadNcReg(&m_tcsel, 10,  1);
        pSim->ReadPC(&m_pc_before);
    } else {
        UI32 htcfg0;
        pSim->ReadTcReg(&m_psw_before, 5, 0, htid);
        pSim->ReadTcReg(&m_tcsel, 10,  1, htid);
        pSim->ReadTcReg(&htcfg0, 0,  2, htid);
//      m_peid = (htcfg0 >> 16) & 0x3f ;
        m_vcid = (htcfg0 >> 8) & 7 ;
        pSim->ReadVcReg(&m_vcsel, 15,  1, m_vcid);
        pSim->ReadPC(&m_pc_before, htid);
    }

    union SY_ sy { 0 } ;
    UI32 opnum = pIns->GetOpNum();

    IFpuSingleConstraint * pSingle1 = NULL ;
    IFpuSingleConstraint * pSingle2 = NULL ;
    IFpuDoubleConstraint * pDouble1 = NULL ;
    IFpuDoubleConstraint * pDouble2 = NULL ;
    UI32 BeforeRegIdx1 = -1 ;
    UI32 BeforeRegIdx2 = -1 ;
    UI32 BeforeRegIdx3 = -1 ;

    UI32 inst_id = pIns->GetId();
#if defined(_DBG_SIM01_)
    std::string mne = pIns->GetCode();
    printf( ":>> %s", ((is_nm) ? "NM: " : "VM: "));
    printf( "Behavior= 0x%03x ,Category= 0x%02x ,Priviledge= %d ,inslen= %d ,binary= 0x%016llx , ",
            pIns->GetBehavior(), pIns->GetCategory(), pIns->GetPriviledge(), pIns->GetLen(), pIns->Fetch());
    printf( "%-24s , InstNo= %3d ,OpNum= %d ", mne.c_str(), inst_id, opnum);
#endif

    UI32 low_value = 0;
    UI32 high_value = 0 ;
    UI32 count = 1 ;
    m_fpu_idx1 = -1 ;
    m_fpu_idx2 = -1 ;
    m_fpu_idx3 = -1 ;
	for (UI32 i = 0 ;i < opnum ;i++) {
        IOperand* operand = pIns->opr(i);
        sy.tmp13 = operand->GetAttr();

#if defined(_DBG_SIM01_)
        printf("(Attr=0x%04x ", sy.v);
        if (sy.tmp13.test(IOperand::OPR_ATTR_SR)) {
            printf("Sr%d ",  (UI32)*operand);
        }
        else
        if (sy.tmp13.test(IOperand::OPR_ATTR_GR)) {
            printf("Gr%d ",  operand->Idx());
        }
        else
        if (sy.tmp13.test(IOperand::OPR_ATTR_VR)) {
            std::string work = operand->GetCode();
            printf("Vr%d ",  atoi(work.c_str() + 2));
        }
		else
		if (sy.tmp13.test(IOperand::OPR_ATTR_WR)) {
            std::string work = operand->GetCode();
            printf("Wr%d ",  atoi(work.c_str() + 2));
		}       
		else
        if (sy.tmp13.test(IOperand::OPR_ATTR_IMM)) {
            printf("Imm:0x%08x ",  (UI32)*operand);
        }
#endif
        if ((sy.tmp13.test(IOperand::OPR_ATTR_GR)) && (sy.tmp13.test(IOperand::OPR_ATTR_SRC))  ) {
            
			// ソースオペランドAND-OR計測
            UI32 reg_no = operand->Idx() ;
            if (sy.tmp13.test(IOperand::OPR_ATTR_PAIR)) {
                pSim->ReadGrReg(&low_value  , reg_no     , ((is_nm) ? 0 : htid));
                pSim->ReadGrReg(&high_value , reg_no + 1 , ((is_nm) ? 0 : htid));
                UI64 value = 0ULL ;
                value = (static_cast<UI64>(high_value) << 32) + low_value ;
                m_inst[inst_id].m_stack_or[count]  |= value ;
                m_inst[inst_id].m_stack_and[count] &= value ;
                m_inst[inst_id].m_stack[count] = 2 ;
            } else {
                pSim->ReadGrReg(&low_value , reg_no , ((is_nm) ? 0 : htid));
                m_inst[inst_id].m_stack_or[count]  |= low_value ;
                m_inst[inst_id].m_stack_and[count] &= (0xffffffff00000000ULL | low_value) ;
                m_inst[inst_id].m_stack[count] = 1 ;
            }
            count++ ;

            // FPUオペランド計測
	        if (pIns->GetCategory() & ((1 << IInstruction::ICAT_FPU_S)|(1 << IInstruction::ICAT_FPU_D))) {
                if (!sy.tmp13.test(IOperand::OPR_ATTR_PAIR)) {
                    UI32 reg_idx = operand->Idx() ;
                    IFpuSingleConstraint * p ;
                    if (BeforeRegIdx1 == reg_idx){
                        p = pSingle1 ;
                    }
                    else
                    if (BeforeRegIdx2 == reg_idx){
                        p = pSingle2 ;
                    } else {
                        p = reinterpret_cast<IFpuSingleConstraint *>(operand->GetConstraint()) ;
                        _ASSERT(p);
                        if (BeforeRegIdx1 == static_cast<UI32>(-1)) {
                            BeforeRegIdx1 = reg_idx ;
                            pSingle1 = p ;
                        }
                        else
                        if (BeforeRegIdx2 == static_cast<UI32>(-1)) {
                            BeforeRegIdx2 = reg_idx ;
                            pSingle2 = p ;
                        }
                        else
                        if (BeforeRegIdx3 == static_cast<UI32>(-1)) {
                            BeforeRegIdx3 = reg_idx ;
                        }
                    }
                    UI32 value;
                    pSim->ReadGrReg(&value , reg_idx , ((is_nm) ? 0 : htid));
                    if (m_fpu_idx1 == static_cast<UI32>(-1)) {
                        m_fpu_idx1 = FpuSingleType(value) ;
                    }
                    else
                    if (m_fpu_idx2 == static_cast<UI32>(-1)) {
                        m_fpu_idx2 = FpuSingleType(value) ;
                    }
                    else
                    if (m_fpu_idx3 == static_cast<UI32>(-1)) {
                        m_fpu_idx3 = FpuSingleType(value) ;
                    }

#if defined(_DBG_SIM01_)
                    printf("Single[ %s val=0x%08x %s ] ",  fpu_opr_type [p->pst_WrType->GetObj()] , value , fpu_opr_type [FpuSingleType(value)] );
#endif

                    if (!p->IsValid(value)) {
#if defined(_DBG_SIM01_)
                        printf( "\n");
#endif
                        _ASSERT(false);
                    }
                } else {
                    UI32 reg_idx = operand->Idx() ;
                    IFpuDoubleConstraint * p ;
                    if (BeforeRegIdx1 == reg_idx){
                        p = pDouble1 ;
                    }
                    else
                    if (BeforeRegIdx2 == reg_idx){
                        p = pDouble2 ;
                    } else {
                        p = reinterpret_cast<IFpuDoubleConstraint *>(operand->GetConstraint()) ;
                        _ASSERT(p);
                       if (BeforeRegIdx1 == static_cast<UI32>(-1)) {
                            BeforeRegIdx1 = reg_idx ;
                            pDouble1 = p ;
                        }
                        else
                        if (BeforeRegIdx2 == static_cast<UI32>(-1)) {
                            BeforeRegIdx2 = reg_idx ;
                            pDouble2 = p ;
                        }
                    }
                    UI32 upper_value;
                    UI32 lower_value;
                    pSim->ReadGrReg(&lower_value , reg_idx     , ((is_nm) ? 0 : htid));
                    pSim->ReadGrReg(&upper_value , reg_idx + 1 , ((is_nm) ? 0 : htid));
                    UI64 value = (static_cast<UI64>(upper_value) << 32) | lower_value ;

                    if (m_fpu_idx1 == static_cast<UI32>(-1)) {
                        m_fpu_idx1 = FpuDoubleType(value) ;
                    }
                    else
                    if (m_fpu_idx2 == static_cast<UI32>(-1)) {
                        m_fpu_idx2 = FpuDoubleType(value) ;
                    }
                    else
                    if (m_fpu_idx3 == static_cast<UI32>(-1)) {
                        m_fpu_idx3 = FpuDoubleType(value) ;
                    }

#if defined(_DBG_SIM01_)
                    printf("Double[ %s val=0x%016llx %s ] ",  fpu_opr_type [p->pst_WrType->GetObj()] , value , fpu_opr_type [FpuDoubleType(value)] );
#endif

                    if (!p->IsValid(value)) {
#if defined(_DBG_SIM01_)
                        printf( "\n");
#endif
                        _ASSERT(false);
                    }
                }
            }
        }
#if defined(_DBG_SIM01_)
        printf( ") ");
#endif
    }
#if defined(_DBG_SIM01_)
    printf( "\n");
#endif
}



void StatisticsInst::AfterAcquisition(bool is_statistics, IInstruction* pIns, ISimulator* pSim, UI32 htid) {
    if (!is_statistics) {
        return;
    }

    union SY_ sy { 0 } ;
    UI32 opnum = pIns->GetOpNum();
    UI32 inst_id = pIns->GetId();
    bool is_nm = ((m_psw_before & 0x80000000U) == 0);

    // オペコード計測
    m_step_count++ ;

    m_inst[inst_id].m_count++ ;

    if (m_before_inst_id != 0) {
        m_inst[m_before_inst_id].m_seq.set(inst_id);
// if (m_before_inst_id == 3) {
//   std::cout << m_before_inst_id << "," << inst_id << "," << m_inst[m_before_inst_id].m_seq.to_string() << std::endl ;
// }
    }
    m_before_inst_id = inst_id ;

    // ディスティネーション・オペランドAND-OR計測
    UI32 low_value = 0;
    UI32 high_value = 0 ;
    UI32 count = 0 ;
    UI32 reg_no = 0;

    for (UI32 i = 0 ;i < opnum ;i++) {
        IOperand* operand = pIns->opr(i);
        sy.tmp13 = operand->GetAttr();
        if (  (!sy.tmp13.test(IOperand::OPR_ATTR_GR))
           || (!sy.tmp13.test(IOperand::OPR_ATTR_DST))  )
        {
            continue;
        }

        reg_no = operand->Idx() ;
        if (sy.tmp13.test(IOperand::OPR_ATTR_PAIR)) {
            pSim->ReadGrReg(&low_value  , reg_no     , ((is_nm) ? 0 : htid));
            pSim->ReadGrReg(&high_value , reg_no + 1 , ((is_nm) ? 0 : htid));
            count = 2;
            break;
        }
        if (count == 1) {
            pSim->ReadGrReg(&high_value , reg_no , ((is_nm) ? 0 : htid));
            count = 2;
            break ;
        }
        pSim->ReadGrReg(&low_value , reg_no , ((is_nm) ? 0 : htid));
        count = 1;
    }
    UI64 value = 0ULL ;
    if (count == 2) {
        value = (static_cast<UI64>(high_value) << 32) + low_value ;
        m_inst[inst_id].m_stack_or[0]  |= value ;
        m_inst[inst_id].m_stack_and[0] &= value ;
    }
    else
    if (count == 1) {
        m_inst[inst_id].m_stack_or[0]  |= low_value ;
        m_inst[inst_id].m_stack_and[0] &= (0xffffffff00000000ULL | low_value) ;
    }

    m_inst[inst_id].m_stack[0] = count ;

    UI32 psw_after = 0;
    UI32 pc_after = 0;
    if (is_nm) {
        pSim->ReadNcReg(&psw_after, 5, 0);
        pSim->ReadPC(&pc_after);
    } else {
        pSim->ReadTcReg(&psw_after, 5, 0, htid);
        pSim->ReadPC(&pc_after, htid);
    }
    UI32 psw_diff = (m_psw_before ^ psw_after) & 0x0000001f ;   // canged flag
    m_inst[inst_id].m_flag_rise |= psw_diff & psw_after  ;
    m_inst[inst_id].m_flag_fall |= psw_diff & m_psw_before ;

    //
    // システムレジスタ計測
    //
    for (UI32 i = 0 ;i < opnum ;i++) {
        IOperand* operand = pIns->opr(i);
        sy.tmp13 = operand->GetAttr();
        if (!sy.tmp13.test(IOperand::OPR_ATTR_SR)) {
            continue;
        }
        UI32 key = *operand + 0x200 * (is_nm ? 0 : 1);
        std::map<UI32,StatisticsSregItem>::iterator itr = m_sreg_stat.find(key);
        if (itr == m_sreg_stat.end()) {
            StatisticsSregItem temp;
            std::pair<std::map<UI32,StatisticsSregItem>::iterator,bool> result ;
            result = m_sreg_stat.insert(std::pair<UI32,StatisticsSregItem>(key,temp));
            itr = result.first;
        }
        switch ( inst_id ) {
        case INS_ID_LDSR:
            itr->second.m_ldsr++ ;
            break;
        case INS_ID_STSR:
            itr->second.m_stsr++ ;
            break;
        case INS_ID_LDVC_SR:
            if (m_vcsel == ((!is_nm ? 0x80000000 : 0) | m_vcid) ) {
                itr->second.m_inside_ldvc_sr++ ;
            } else {
                itr->second.m_outside_ldvc_sr++ ;
            }
            break;
        case INS_ID_STVC_SR:
            if (m_vcsel == ((!is_nm ? 0x80000000 : 0) | m_vcid) ) {
                itr->second.m_inside_stvc_sr++ ;
            } else {
                itr->second.m_outside_stvc_sr++ ;
            }
            break;
        case INS_ID_LDTC_SR:
            if (m_tcsel == ((!is_nm ? 0x80000000 : 0) | htid) ) {
                itr->second.m_inside_ldtc_sr++ ;
            } else {
                itr->second.m_outside_ldtc_sr++ ;
            }
            break;
        case INS_ID_STTC_SR:
            if (m_tcsel == ((!is_nm ? 0x80000000 : 0) | htid) ) {
                itr->second.m_inside_sttc_sr++ ;
            } else {
                itr->second.m_outside_sttc_sr++ ;
            }
            break;
        default:
            _ASSERT(false);
           break;
        }
#if defined(_DBG_SIM01_)
        printf(":>>> PE%02d %s: inst=%d Sr%d\n", m_peid, ((is_nm) ? "NM: " : "VM: "), inst_id, (UI32)*operand );
#endif
    }

    // FPUオペランド結果記録
    std::pair<std::map<UI32,StatisticsFpuItem>::iterator,bool> result ;
    if (m_fpu_idx1 != static_cast<UI32>(-1)) {
        std::map<UI32,StatisticsFpuItem>::iterator itr = m_fpu.find(inst_id);
        if (m_fpu_idx3 != static_cast<UI32>(-1)) {
            if (itr == m_fpu.end()) {
                StatisticsFpuItem temp(3);
                result = m_fpu.insert(std::pair<UI32,StatisticsFpuItem>(inst_id,temp));
                itr = result.first;
            }
            itr->second.increment(m_fpu_idx1 - 2, m_fpu_idx2 - 2, m_fpu_idx3 - 2) ;
        }
        else
        if (m_fpu_idx2 != static_cast<UI32>(-1)) {
            if (itr == m_fpu.end()) {
                StatisticsFpuItem temp(2);
                result = m_fpu.insert(std::pair<UI32,StatisticsFpuItem>(inst_id,temp));
                itr = result.first;
            }
            itr->second.increment(m_fpu_idx1 - 2, m_fpu_idx2 - 2) ;
        } else {
            if (itr == m_fpu.end()) {
                StatisticsFpuItem temp(1);
                result = m_fpu.insert(std::pair<UI32,StatisticsFpuItem>(inst_id,temp));
                itr = result.first;
            }
            itr->second.increment(m_fpu_idx1 - 2) ;
        }
    }

// taken = pCnd->GetConstraint();
// printf(":>> 0x%02d\n", taken);
    if (pIns->GetBehavior() & (1 << IInstruction::JMP)) {
        bool match = false ;
        std::vector<StatisticsJumpItem>::iterator itr_jump = m_jump.begin() ;
        while (itr_jump != m_jump.end()) {
            if (itr_jump->GetInstId() == inst_id) {
                match = true ;
                break ;
            }
            itr_jump++ ;
        }
        if (!match) {
            StatisticsJumpItem temp ;
            m_jump.push_back( temp ) ;
            itr_jump = (m_jump.end() - 1) ;
            itr_jump->SetInstId( inst_id ) ;
        }

        bool taken = false ;
	    if (pIns->HasBranchConstraint()) {
            UI32 cccc = pIns->Fetch() & 0x0f ;
            taken = _condition_satisfied( cccc , m_psw_before );
//          bool  target = pCnd->GetConstraint();
//          printf("@@@@@ <%d:%d> 0x%x PSW=0x%08x\n",  target, taken, cccc , m_psw_before);
	    }
        else
	    if (pIns->GetMne() == "loop") {
            UI32 value = 0 ;
            UI32 opnum = pIns->GetOpNum();
            for (UI32 i = 0 ;i < opnum ;i++) {
                IOperand* operand = pIns->opr(i);
                sy.tmp13 = operand->GetAttr();
                if (sy.tmp13.test(IOperand::OPR_ATTR_GR)) {
                    pSim->ReadGrReg(&value , reg_no , ((is_nm) ? 0 : htid));
                    break ;
                }
			}
            taken = (value == 0) ? false : true ;
		} else {
            taken = true ;
        }
        SetTaken( &(*itr_jump) , taken );
        if (taken) {
            itr_jump->SetDifference(m_pc_before, pc_after ) ;
        }
    } else {
        ResetTaken();
    }
}



void StatisticsInst:: Print(std::ofstream &ofs) {

    ofs << "::INSTRUCTION" << std::endl;
    IInstructionSet * weight_set = g_mgr->GetWeightSet();
    CInstructionSet * pInsSet = static_cast<CInstructionSet*>(g_mgr->GetWeightSet());
    IInstruction * pIns;
    union SY_ sy { 0 } ;
    UI32 inst_weight_sum = 0;
    UI32 count;

    for (UI32 i= 1; i <= NUM_OF_INS ; i++) {
        pIns = pInsSet->CreateIns(i);
        count = 1;
        for (UI32 j = 0 ;j < pIns->GetOpNum(); j++) {
            sy.tmp13 = pIns->opr(j)->GetAttr();
            
        	if (sy.tmp13.test(IOperand::OPR_ATTR_GR)) {
                if(sy.tmp13.test(IOperand::OPR_ATTR_SRC)) {
                    if (sy.tmp13.test(IOperand::OPR_ATTR_PAIR)) {
                        m_inst[i].m_stack[count] = 2 ;
                    }else{
                        m_inst[i].m_stack[count] = 1 ;
                    }
                    count++;
                }
                if(sy.tmp13.test(IOperand::OPR_ATTR_DST)) {
                    if (sy.tmp13.test(IOperand::OPR_ATTR_PAIR)) {
                        m_inst[i].m_stack[0] = 2 ;
                    }else{
                        m_inst[i].m_stack[0] = 1 ;
                    }
                }
            }
        }
        inst_weight_sum += weight_set->GetWeight( i );
    }
    for (UI32 i= 1; i <= NUM_OF_INS ; i++) {
        std::string key = weight_set->GetKey( i ) ;
        UI32 wt = weight_set->GetWeight( i );
        UI64 expect64 = 0;
        if (inst_weight_sum != 0) {
            expect64 = (1000ULL * wt * m_step_count) / inst_weight_sum ;
        }
        UI32 expect32 = (expect64 >= 0x100000000ULL) ? 0xffffffffU : static_cast<UI32>( expect64 ) ;
        m_inst[i].Print( key , expect32 , ofs );
    }

    ofs << "::EXCEPTION" << std::endl;
    std::map< UI32,IExceptionConfig*>& excep = g_exp->GetException();
	std::map <UI32,IExceptionConfig*>::iterator i;
	for (i = excep.begin(); i != excep.end(); i++) {
		if (i->second->m_lcode) {
            UI32 cause = i->first;
            std::string wt = std::to_string(i->second->m_weight);
            if ((0xf000 <= cause)&&(cause <= 0xf01f)) {         // HVTRAP
                if (weight_set->GetWeight( 193 ) == 0) {
                    wt = "-2";
                } else {
                    wt = "-1";
                }
            }
            else
            if ((0xe000 <= cause)&&(cause <= 0xe0ff)) {         // HVCALL
                if (weight_set->GetWeight( 192 ) == 0) {
                    wt = "-2";
                } else {
                    wt = "-1";
                }
            }
            else
            if ((0x8000 <= cause)&&(cause <= 0x80ff)) {         // SYSCALL
                if (weight_set->GetWeight( 183 ) == 0) {
                    wt = "-2";
                } else {
                    wt = "-1";
                }
            }
            else
            if ((0x0031 <= cause)&&(cause <= 0x003f)) {         // FETRAP
                if (weight_set->GetWeight( 76 ) == 0) {
                    wt = "-2";
                } else {
                    wt = "-1";
                }
            }
            else 
            if ((0x0040 <= cause)&&(cause <= 0x005f)) {         // TRAP
               if (weight_set->GetWeight( 184 ) == 0) {
                    wt = "-2";
                } else {
                    wt = "-1";
                }
            }
            else {
                switch ( cause ) {
                    case 0xc0 :                                 // MAE
                    case 0x91 :                                 // MDP
                        break ;
                    case 0xb1 :                                 // DBTRAP
                        if (weight_set->GetWeight( 218 ) == 0) {
                            wt = "-2";
                        } else {
                            wt = "-1";
                        }
                        break ;
                    case 0xb2 :                                 // RMTRAP
                        if (weight_set->GetWeight( 219 ) == 0) {
                            wt = "-2";
                        } else {
                            wt = "-1";
                        }
                        break ;
                    case 0xb4 :                                 // DBHVTRAP
                        if (weight_set->GetWeight( 214 ) == 0) {
                            wt = "-2";
                        } else {
                            wt = "-1";
                        }
                        break ;
                     default :
                        wt = "-3";                              // not support
                        break ;
                }
            }
			ofs << i->second->m_name  << "," << wt << "," << std::dec << i->second->m_count_random << std::endl;
		}
	}

    ofs << "::SREG" << std::endl;
    bool ldvc = (weight_set->GetWeight( 194 ) != 0) ;
    bool stvc = (weight_set->GetWeight( 195 ) != 0) ;
    bool ldtc = (weight_set->GetWeight( 201 ) != 0) ;
    bool sttc = (weight_set->GetWeight( 205 ) != 0) ;
    bool ldsr = (weight_set->GetWeight(  99 ) != 0) ;
    bool stsr = (weight_set->GetWeight( 173 ) != 0) ;
#if 1
    for (UI32 mcn = 0 ;mcn <= 1 ;mcn++ ) {
        for (UI32 selreg = 0 ;selreg < 256 ;selreg++ ) {
            UI32 selid = (selreg >> 5) & 7;
            UI32 regid = selreg & 0x1f;
            UI32 key = 512 * mcn + selreg ;
            std::string context = (mcn != 0) ? "VM" : "NM" ;
            std::string name = key_sreg[ selreg ] ;
            bool loadable = false ;
            bool storable = false ;
            if (g_srs->GetName( regid , selid) != "") {
                loadable = g_srs->IsLoadable(regid, selid) ;
                storable = g_srs->IsStorable(regid, selid) ;
            }
            std::map<UI32,StatisticsSregItem>::iterator itr_sr = m_sreg_stat.find( key ) ;
            if (itr_sr == m_sreg_stat.end()) {
                if (name.substr( 0, 1 ) == "0") {
                    continue;
                }
                ofs <<        ((stsr && loadable) ? "0" : "-1") ;
                ofs << "," << ((ldsr && storable) ? "0" : "-1") ;
                ofs << "," << ((stvc && loadable) ? "0" : "-1") ;
                ofs << "," << ((ldvc && storable) ? "0" : "-1") ;
                ofs << "," << ((sttc && loadable) ? "0" : "-1") ;
                ofs << "," << ((ldtc && storable) ? "0" : "-1") ;
                ofs << "," << ((stvc && loadable) ? "0" : "-1") ;
                ofs << "," << ((ldvc && storable) ? "0" : "-1") ;
                ofs << "," << ((sttc && loadable) ? "0" : "-1") ;
                ofs << "," << ((ldtc && storable) ? "0" : "-1") ;
                ofs << "," << std::dec << key << "," << context << ":" << name << std::endl ;
            } else {
                StatisticsSregItem item = itr_sr->second;
                ofs <<        (((item.m_stsr            != 0) || (stsr && loadable)) ? std::to_string(item.m_stsr)            : "-1") ;
                ofs << "," << (((item.m_ldsr            != 0) || (ldsr && storable)) ? std::to_string(item.m_ldsr)            : "-1") ;
                ofs << "," << (((item.m_inside_stvc_sr  != 0) || (stvc && loadable)) ? std::to_string(item.m_inside_stvc_sr)  : "-1") ;
                ofs << "," << (((item.m_inside_ldvc_sr  != 0) || (ldvc && storable)) ? std::to_string(item.m_inside_ldvc_sr)  : "-1") ;
                ofs << "," << (((item.m_inside_sttc_sr  != 0) || (sttc && loadable)) ? std::to_string(item.m_inside_sttc_sr)  : "-1") ;
                ofs << "," << (((item.m_inside_ldtc_sr  != 0) || (ldtc && storable)) ? std::to_string(item.m_inside_ldtc_sr)  : "-1") ;
                ofs << "," << (((item.m_outside_stvc_sr != 0) || (stvc && loadable)) ? std::to_string(item.m_outside_stvc_sr) : "-1") ;
                ofs << "," << (((item.m_outside_ldvc_sr != 0) || (ldvc && storable)) ? std::to_string(item.m_outside_ldvc_sr) : "-1") ;
                ofs << "," << (((item.m_outside_sttc_sr != 0) || (sttc && loadable)) ? std::to_string(item.m_outside_sttc_sr) : "-1") ;
                ofs << "," << (((item.m_outside_ldtc_sr != 0) || (ldtc && storable)) ? std::to_string(item.m_outside_ldtc_sr) : "-1") ;
                ofs << "," << std::dec << key << "," << context << ":" << name << std::endl ;
            }
        }
    }
#else
    std::map<UI32,StatisticsSregItem>::iterator itr_sr ;
    for (itr_sr = m_sreg_stat.begin() ; itr_sr != m_sreg_stat.end() ; itr_sr++) {
        UI32 key = itr_sr->first;
        std::string context = (key / 0x200) ? "VM" : "NM" ;
        std::string name = g_srs->GetName((key & 0x1f), ((key >> 5) & 0x0f)) ;
        bool loadable = g_srs->IsLoadable((key & 0x1f), ((key >> 5) & 0x0f)) ;
        bool storable = g_srs->IsStorable((key & 0x1f), ((key >> 5) & 0x0f)) ;
        if (name == "") {
            char buf[32] ;
            name = sprintf(buf ,"%02d:%02d", ((key >> 5) & 0x0f), (key & 0x1f) ) ;
        } 
        StatisticsSregItem item = itr_sr->second;
        ofs <<        (((item.m_stsr            != 0) || (stsr && loadable)) ? std::to_string(item.m_stsr)            : "-1") ;
        ofs << "," << (((item.m_ldsr            != 0) || (ldsr && storable)) ? std::to_string(item.m_ldsr)            : "-1") ;
        ofs << "," << (((item.m_inside_stvc_sr  != 0) || (stvc && loadable)) ? std::to_string(item.m_inside_stvc_sr)  : "-1") ;
        ofs << "," << (((item.m_inside_ldvc_sr  != 0) || (ldvc && storable)) ? std::to_string(item.m_inside_ldvc_sr)  : "-1") ;
        ofs << "," << (((item.m_inside_sttc_sr  != 0) || (sttc && loadable)) ? std::to_string(item.m_inside_sttc_sr)  : "-1") ;
        ofs << "," << (((item.m_inside_ldtc_sr  != 0) || (ldtc && storable)) ? std::to_string(item.m_inside_ldtc_sr)  : "-1") ;
        ofs << "," << (((item.m_outside_stvc_sr != 0) || (stvc && loadable)) ? std::to_string(item.m_outside_stvc_sr) : "-1") ;
        ofs << "," << (((item.m_outside_ldvc_sr != 0) || (ldvc && storable)) ? std::to_string(item.m_outside_ldvc_sr) : "-1") ;
        ofs << "," << (((item.m_outside_sttc_sr != 0) || (sttc && loadable)) ? std::to_string(item.m_outside_sttc_sr) : "-1") ;
        ofs << "," << (((item.m_outside_ldtc_sr != 0) || (ldtc && storable)) ? std::to_string(item.m_outside_ldtc_sr) : "-1") ;
        ofs << "," << std::dec << key << "," << context << ":" << name << std::endl ;
    }
#endif
    /* ::FPU */
    std::map<UI32,StatisticsFpuItem>::iterator itr ;
    for (itr = m_fpu.begin() ; itr != m_fpu.end() ; itr++) {
        (*itr).second.Print( ofs, (*itr).first ) ;
    }
    /* ::JUMP */
    std::vector<StatisticsJumpItem>::iterator itr_jump ;
    ofs << "::JUMP" << std::endl;
    for (itr_jump = m_jump.begin() ; itr_jump != m_jump.end() ; itr_jump++ ) {
        itr_jump->Print( ofs ) ;
    }
    ofs << "::JUMP_difference" << std::endl;
    for (itr_jump = m_jump.begin() ; itr_jump != m_jump.end() ; itr_jump++ ) {
        itr_jump->Print_difference( ofs ) ;
    }
    ofs << "::JUMP_boundary" << std::endl;
    for (itr_jump = m_jump.begin() ; itr_jump != m_jump.end() ; itr_jump++ ) {
        itr_jump->Print_boundary( ofs ) ;
    }

	/* WReg */
	m_wreg->Print(ofs);

}



void StatisticsMemory::Init( UI32 expiration ) {
    m_expiration = expiration ;
    //---------------------------------------------------
    //メモリ領域カウンタの初期化
    //---------------------------------------------------
    CGeneratorProfile::SectionData::iterator sdi;
    CGeneratorProfile::SectionData sd;
    CGeneratorProfile::CsvRow::iterator ri;
    StatisticsMemAreaItem mem_temp;
    sd = g_prf->GetSectionData("::ROM_ADDRESS");
    for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
        CGeneratorProfile::CsvRow& r = (*sdi);
		UI32 lnk = 1 ;
		UI32 wt  = 0 ;
        if ((r.size() < 3)||(r[2] == "I")||(r[2] == "i")) {
            continue;
        }
		if(r.size() == 4 ){
			wt  = CToolFnc::AtoI(r[3].c_str());
		} else if(r.size() == 5 ){
			lnk = CToolFnc::AtoI(r[3].c_str());
			wt  = CToolFnc::AtoI(r[4].c_str());
		}
        if (wt == 0) {
            continue;
        }
        UI32 begin_adr = CToolFnc::AtoI(r[0].c_str());
        UI32 end_adr   = CToolFnc::AtoI(r[1].c_str());
        std::string attr = r[2];
        std::vector<StatisticsMemAreaItem>::iterator itr;
        for (itr = m_memarea_stat.begin(); itr != m_memarea_stat.end(); itr++) {
            if (  ((*itr).m_IsRomArea == true)
               && ((*itr).m_begin_adr == begin_adr)
               && ((*itr).m_end_adr   == end_adr)
               && ((*itr).m_attr.compare(r[2]) == 0)  )
            {
                break ;
            }
        }
        if (itr == m_memarea_stat.end()) {
            mem_temp.m_IsRomArea = true;
            mem_temp.m_begin_adr = CToolFnc::AtoI(r[0].c_str());
            mem_temp.m_end_adr   = CToolFnc::AtoI(r[1].c_str());
            mem_temp.m_attr      = r[2];
            mem_temp.m_read_ref  = 0;
            mem_temp.m_write_ref  = 0;
			mem_temp.m_lnk       = lnk ;
            if (  (mem_temp.m_attr.find("R",0) != std::string::npos)
               || (mem_temp.m_attr.find("r",0) != std::string::npos)  )
            {
               mem_temp.m_read_ref  = wt;
            }
            if (  (mem_temp.m_attr.find("W",0) != std::string::npos)
               || (mem_temp.m_attr.find("w",0) != std::string::npos)  )
            {
                mem_temp.m_write_ref = wt;
            }
            mem_temp.m_bus_access_hopping_index = m_memarea_stat.size() ;
            m_memarea_stat.push_back(mem_temp);
        }
    }
    sd = g_prf->GetSectionData("::RAM_ADDRESS");
    for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		UI32 lnk = 1 ;
		UI32 wt  = 0 ;
        CGeneratorProfile::CsvRow& r = (*sdi);
        if ((r.size() < 3)||(r[2] == "I")||(r[2] == "i")) {
            continue;
        }
		if(r.size() == 4 ){
			wt  = CToolFnc::AtoI(r[3].c_str());
		} else if(r.size() == 5 ){
			lnk = CToolFnc::AtoI(r[3].c_str());
			wt  = CToolFnc::AtoI(r[4].c_str());
		}
        if (wt == 0) {
            continue;
        }
		if(r[0].find(':', 0) != std::string::npos || r[1].find(':', 0) != std::string::npos) {
			continue;
		}

        UI32 begin_adr = CToolFnc::AtoI(r[0].c_str());
        UI32 end_adr   = CToolFnc::AtoI(r[1].c_str());
        std::string attr = r[2];
        std::vector<StatisticsMemAreaItem>::iterator itr;
        for (itr = m_memarea_stat.begin(); itr != m_memarea_stat.end(); itr++) {
            if (  ((*itr).m_IsRomArea == false)
               && ((*itr).m_begin_adr == begin_adr)
               && ((*itr).m_end_adr   == end_adr)
               && ((*itr).m_attr.compare(r[2]) == 0)  )
            {
                break ;
            }
        }
        if (itr == m_memarea_stat.end()) {
            mem_temp.m_IsRomArea = false;
            mem_temp.m_begin_adr = CToolFnc::AtoI(r[0].c_str());
            mem_temp.m_end_adr   = CToolFnc::AtoI(r[1].c_str());
            mem_temp.m_attr      = r[2];
            mem_temp.m_read_ref  = 0;
            mem_temp.m_write_ref  = 0;
			mem_temp.m_lnk       = lnk ;
            if (  (mem_temp.m_attr.find("R",0) != std::string::npos)
               || (mem_temp.m_attr.find("r",0) != std::string::npos)  )
            {
               mem_temp.m_read_ref  = wt;
            }
            if (  (mem_temp.m_attr.find("W",0) != std::string::npos)
               || (mem_temp.m_attr.find("w",0) != std::string::npos)  )
            {
                mem_temp.m_write_ref = wt;
            }
            mem_temp.m_bus_access_hopping_index = m_memarea_stat.size() ;
            m_memarea_stat.push_back(mem_temp);
        }
    }

    //---------------------------------------------------
    //メモリアクセスカウンタの初期化
    //---------------------------------------------------
    for (UI32 i = 0; i < 8 ;i++) {
        for (UI32 j = 0; j < 16 ;j++) {
            m_bus_read_access[i][j] = 0;
            m_bus_write_access[i][j] = 0;
        }
    }
    //メモリアクセスカウント数（ランダム部のみ）の初期化
    m_read_access_count = 0 ;
    m_write_access_count = 0 ;
}


void StatisticsMemory::Acquisition(bool is_statistics, IInstruction* pIns, ISimulator* pSim) {
    if (!is_statistics) {
        return;
    }
    if (pSim->SizeMemAccessLog() == 0) {
        // メモリアクセスが無かった場合
        if (m_BeforeCount > 0) {
            m_BeforeCount-- ;
        } else {
            m_BeforeArea = 0xffffffff ;
        }
        return ;
    }

    UI32 read1_write0 ;
    UI64 addr ;
    UI32 byte ;
    while (pSim->PopMemAccessLog(read1_write0 , addr , byte )) {

        // メモリバスアクセス計測（設定領域に対するカウント）
        if (read1_write0  == 1) {
            m_read_access_count++ ;
#if defined(_DBG_SIM01_)
            printf("M| ADDR=0x%08llx ,Sise=%d, TotalRd=%d ", addr , byte , m_read_access_count);
#endif
        } else {
            m_write_access_count++ ;
#if defined(_DBG_SIM01_)
            printf("M| ADDR=0x%08llx ,Size=%d, TotalWr=%d ", addr , byte , m_write_access_count);
#endif
        }
        UI32 end_adr = addr + byte ;
        UI32 area_counter = 0 ;
        bool area_match = false ;
        std::vector<StatisticsMemAreaItem>::iterator itr;
        for (itr = m_memarea_stat.begin(); itr != m_memarea_stat.end(); itr++) {
            if (((*itr).m_begin_adr > end_adr) || ((*itr).m_end_adr < addr)) {
                area_counter++ ;
                continue;
            }
            if ((*itr).m_begin_adr > addr) {
                area_counter++ ;
                continue;
            }
            if ((*itr).m_end_adr < end_adr) {
                area_counter++ ;
                continue;
            }
            if (read1_write0  == 1) {
                (*itr).m_read_count++ ;
#if defined(_DBG_SIM01_)
            printf("Area_%02d.read_count=%d \n", area_counter , (*itr).m_read_count);
#endif
            } else {
                (*itr).m_write_count++ ;
#if defined(_DBG_SIM01_)
            printf("Area_%02d.write_count=%d \n", area_counter , (*itr).m_write_count);
#endif
            }
            area_match = true ;
            break;
        }
        if (area_match) {
            if (m_BeforeArea == area_counter) {
#if defined(_DBG_SIM01_)
            printf ("B| area_%02d", area_counter );
#endif
                // 同一の設定領域内に連続してメモリアクセスがあった場合、カウントする。
                (*itr).CountAccessInterval(addr , read1_write0) ;
#if defined(_DBG_SIM01_)
            printf ("\n");
#endif
            } else {
                // 設定領域内にメモリアクセスがあった場合、カウントに備えてアクセスを記録する。
                (*itr).SetAccessIntervalBase(addr , read1_write0) ;
                if (m_BeforeArea <= 63) {
#if defined(_DBG_SIM01_)
            printf ("B| area_%02d", area_counter );
#endif
                    (*itr).CountAccessAreaHopping(m_BeforeArea) ;
#if defined(_DBG_SIM01_)
            printf ("\n");
#endif
                }
            }
            m_BeforeArea = area_counter ;
            m_BeforeCount = m_expiration ;
#if defined(_DBG_SIM01_)
            printf ("\n");
#endif
        } else {
            // 設定領域以外にメモリアクセスがあった場合
            m_BeforeArea = 0xffffffff ;
            m_BeforeCount = 0 ;
#if defined(_DBG_SIM01_)
            printf("not belong any Area.\n");
#endif
        }

        // メモリバスアクセス計測（１６バイト境界オフセット・サイズ）
        if (read1_write0  == 1) {
            switch ( byte ) {
            case 1:
                m_bus_read_access[0][addr & 15]++ ;
                break;
            case 2:
                m_bus_read_access[1][addr & 15]++ ;
                break;
            case 4:
                m_bus_read_access[2][addr & 15]++ ;
                break;
            case 8:
                m_bus_read_access[3][addr & 15]++ ;
                break;
            case 12:
                m_bus_read_access[4][addr & 15]++ ;
                break;
            case 16:
                m_bus_read_access[5][addr & 15]++ ;
                break;
            default:
                if (byte > 16) {
                    m_bus_read_access[6][addr & 15]++ ;
                } else {
                    m_bus_read_access[7][addr & 15]++ ;         //for internal debug
                }
                break;
            }
        } else {
            switch ( byte ) {
            case 1:
                m_bus_write_access[0][addr & 15]++ ;
                break;
            case 2:
                m_bus_write_access[1][addr & 15]++ ;
                break;
            case 4:
                m_bus_write_access[2][addr & 15]++ ;
                break;
            case 8:
                m_bus_write_access[3][addr & 15]++ ;
                break;
            case 12:
                m_bus_write_access[4][addr & 15]++ ;
                break;
            case 16:
                m_bus_write_access[5][addr & 15]++ ;
                break;
            default:
                if (byte > 16) {
                    m_bus_write_access[6][addr & 15]++ ;
                } else {
                    m_bus_write_access[7][addr & 15]++ ;     //for internal debug
                }
                break;
            }
        }
    }
#if 0
    printf("\n");
#endif
}



void StatisticsMemory:: Print(std::ofstream &ofs) {
    UI32 num = m_memarea_stat.size() ;
    ofs << "::MEMORY_AREA" << "," << num << std::endl;
    UI32 mem_read_weight_sum = 0;
    UI32 mem_write_weight_sum = 0;
    std::vector<StatisticsMemAreaItem>::iterator itr;
    for (itr = m_memarea_stat.begin(); itr != m_memarea_stat.end(); itr++) {
        mem_read_weight_sum += (*itr).m_read_ref;
        mem_write_weight_sum += (*itr).m_write_ref;
    }
    for (itr = m_memarea_stat.begin(); itr != m_memarea_stat.end(); itr++) {
        UI64 read_expect64 = 0;
        if (mem_read_weight_sum != 0) {
        	read_expect64 = (1000ULL * (*itr).m_read_ref * m_read_access_count) / mem_read_weight_sum ;
        }
        UI32 read_expect32 = (read_expect64 >= 0x100000000ULL) ? 0xffffffffU : static_cast<UI32>( read_expect64 ) ;
        UI64 write_expect64 = 0;
        if (mem_write_weight_sum != 0) {
            write_expect64 = (1000ULL * (*itr).m_write_ref * m_write_access_count) / mem_write_weight_sum ;
        }
        UI32 write_expect32 = (write_expect64 >= 0x100000000ULL) ? 0xffffffffU : static_cast<UI32>( write_expect64 ) ;
        ofs << "PE" << std::dec << g_cfg->m_nPeId ;
        ofs << ","  << (((*itr).m_IsRomArea) ? "ROM" : "RAM") ;
        ofs << ",0x" << std::hex << std::right << std::setw(8) << std::setfill('0') << (*itr).m_begin_adr;
        ofs << ",0x" << std::hex << std::right << std::setw(8) << std::setfill('0') << static_cast<UI32>((*itr).m_end_adr);
        ofs << "," << (*itr).m_attr ;
        ofs << "," << std::dec << read_expect32 << "," << write_expect32 ;
        ofs << "," << (*itr).m_read_count << "," << (*itr).m_write_count ;
        ofs << "," << std::dec << (*itr).m_bus_access_hopping_index ;
        for (UI32 i = 0; i < num ;i++) {
            ofs << "," << std::dec << (*itr).m_bus_access_hopping[i] ;
        }
        ofs << std::dec << std::endl;
    }
    for (itr = m_memarea_stat.begin(); itr != m_memarea_stat.end(); itr++) {
        ofs << "::MEMORY_AREA_INTERVAL,"  << "PE" << g_cfg->m_nPeId << "_" << (((*itr).m_IsRomArea) ? "ROM" : "RAM") ;
        ofs << "_0x" << std::hex << std::right << std::setw(8) << std::setfill('0') << (*itr).m_begin_adr;
        ofs << "_0x" << std::hex << std::right << std::setw(8) << std::setfill('0') << static_cast<UI32>((*itr).m_end_adr);
        ofs << std::endl;
        for (UI32 j = 0; j < 4 ;j++) {
            for (UI32 i = 0; i < 64 ;i++) {
                ofs << std::dec << (*itr).m_bus_access_intervals[j][i] << "," ;
            }
        ofs << std::dec << j << std::endl;
        }
    }
    ofs << "::MEMORY_BUS_ADDRESS,PE" << std::dec << g_cfg->m_nPeId << std::endl;
    for (UI32 i = 0; i < 4 ;i++) {
        for (UI32 j = 0; j < 16 ;j++) {
            ofs <<  m_bus_read_access[i][j] << "," ;
        }
        ofs << read_item_name[i] << std::endl ;
    }
    for (UI32 i = 0; i < 4 ;i++) {
        for (UI32 j = 0; j < 16 ;j++) {
            ofs <<  m_bus_write_access[i][j] << "," ;
        }
        ofs <<  write_item_name[i] << std::endl ;
    }
}


CSimulatorControl_stat::CSimulatorControl_stat() {
}


CSimulatorControl_stat::~CSimulatorControl_stat() {
    struct stat st ;
    if (stat("./statistics" , &st) == -1) {
        if (errno == ENOENT) {
            mkdir("./statistics", 0777);
        }
    } else {
        if (!S_ISDIR(st.st_mode)) {
            MSG_ERROR(0, "./statistics is not directry.\n");
        }
    }

    UI32 begin = 0 ;
    std::string::size_type pos = 0 ;
	std::string oname_stat = g_cfg->m_strOutputAsm;
	pos = oname_stat.rfind('/') ;
	if (pos != std::string::npos) {
		begin = static_cast<UI32>(pos) ;
	}
	pos = oname_stat.rfind('.') ;
	if (pos != std::string::npos) {
		oname_stat = "statistics/" + oname_stat.substr (begin + 1 , static_cast<UI32>(pos - begin - 1)) + ".st";
	}else{
		oname_stat = "statistics/" + oname_stat + ".st";
	}

    if (m_pSim) {
        std::cout << g_cfg->m_strOutputAsm << std::endl;
    	std::ofstream	ofs(oname_stat.c_str(), (std::ios::out | std::ios::trunc));
    	if (ofs) {
//          ofs << "::PEID," <<  g_cfg->m_nPeId << std::endl;
            m_inst_statistics.Print(ofs);
            m_memory_statistics.Print(ofs);
    	}

		delete m_pSim;
		m_pSim = NULL;
    }
}


/**
 * @brief	このオブジェクトを初期化する。
 * @return	初期化に成功した場合、真を返す。
 */	
bool CSimulatorControl_stat::Init(std::string& iniPath) {
	delete m_pSim;
	m_pSim = ISimulator::New();
	m_pSim->Init(iniPath) ;
    UI32 expiration = 3;

    std::string file_name( "./statistics.profile" ) ;
    CGeneratorProfile * prof = new CGeneratorProfile() ;
	if (prof->LoadProfile(file_name) == true) {
		CGeneratorProfile::SectionData& sd = prof->GetSectionData(std::string( "::APP_SETTING" )) ;
	    CGeneratorProfile::SectionData::iterator sdi;
   	    for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
            CGeneratorProfile::CsvRow& r = (*sdi) ;
            if ((r.size() >= 2)||(r[0] == "EXPIRATION_STEP")) {
                expiration = CToolFnc::AtoI(r[1].c_str()) ;
                break ;
            }
        }
	}
    delete prof ;

    m_inst_statistics.Init() ;
    m_memory_statistics.Init( expiration ) ;

	return (m_pSim != NULL);
}


/**
 * @brief
 * 
 * コードブロックのシミュレーションを実施する。
 * 
 */
bool CSimulatorControl_stat::BlockSimulation(ISimulationParam* pSp, IBlockSimParam* p, TBlockConfig* tbc) {
	
	_ASSERT(m_pSim);
	_ASSERT(p);
	_ASSERT(p->pCodeBlock);
	
	UI32 break_point_weight = g_exp->GetBreakPointWeight(); // ブレークポイント生成比率取得
	CCodeBlock*		pBlk	= p->pCodeBlock;
	IInstruction*	pIns;
    IInstruction*   pNewIns;
    UI32 break_type = IBreakParam::BREAK_NONE;
    std::string labelStr;
#if DBGMODE
    std::stringstream ss;
#endif
    UI32            htid = 0 ;

	{	// Native Dataの展開
		std::vector<UI32> vndl = pBlk->GetNativeDataArray();
		for (UI32 i = 0; i < vndl.size(); i++) {
			IInstruction* pNd = pBlk->Fetch(vndl[i]);
			m_pSim->WriteMemory (vndl[i], pNd->GetLen(), (UI32)(*pNd->opr(0)));
		}
	}

	// take snapshot(for self-check verifier)
	if (pBlk->IsEnableSnapShot() && pBlk->GetSnapShot()==nullptr) {
		CSimResource* res = GetResource();
		pBlk->SetSnapShot(res); 
	}

#if DBGMODE
	static bool debug_flag = false;
	if (debug_flag); // squash warning
#endif
	
	UI32 inBlockSimCount = 0;

	while (true) {
#if DBGMODE //PC_BREAK_ENTRY
		if (p->ppc == 0x0021255c) {
			UI32 val;
			m_pSim->ReadTcReg(&val, 20, 0, 0);
			UI32 psw; m_pSim->ReadNcReg(&psw, 5, 0);
			//p->pCodeBlock->Dump(std::cout);
            pIns = (pBlk->Fetch(p->ppc)) ;
			if (pIns != NULL) {
				std::cout << " >>> START >>>>>>>>>>> "<< pIns->GetCode() << std::endl;
			}
		}
#endif
		//!< Fetch Next Instrcution		
		pIns = pBlk->Fetch(p->ppc);
		if (pIns == NULL) {
			if ((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize()))) {
				MSG_ERROR(0, "Detected invalid PC={ LA:%08X, PA:%08X }\n", p->lpc, p->ppc);
				p->result.set(IBlockSimParam::BSR_FATALERROR);
				return false;	/* Sim Stop */
			}else{
  				if(pBlk->IsRegulation() && pBlk->GetBreakSetupInsFlag() && (p->bPrevChain == true)) {
                    if(p->pBreakParam.size() == 0) {
						// ランダムコードブロックの内側から外へPCが変化して、前の命令がコードブロック間接続用命令で
						// 挿入したブレーク例外設定用DBTRAPが不要ならば、NOPに置換する
						UI32 nPos = 0;
						for(UI32 i=0; i< pBlk->GetInstructionNum();i++){
							if(pBlk->at(i)->GetComment().find("for Break Setup") != std::string::npos && pBlk->at(i)->GetId() == INS_ID_DBT)
								nPos = i;
						}
						pNewIns = new CIns_115_nop();
						IInstruction* pOldIns = pBlk->at(nPos);
						IInstruction* pReplaceIns = pBlk->Replace(pOldIns,pNewIns);
						delete pReplaceIns;
#if DBGMODE
						std::fprintf(stdout,"==> Replace top dbtrap -> nop!!\n");
#endif
					}
				}
				p->result.set(IBlockSimParam::BSR_JUMPING);
				p->result.set(IBlockSimParam::BSR_SUCCESS); 
				return true;	/* Jumped to other blocks */
			}
		}

        //!< BreakSetupInsert
		if(break_point_weight) {	// WeightがzeroならBreak対象としない
            if((! pBlk->GetBreakSetupInsFlag()) && pBlk->IsRegulation()) {
                // ブレーク例外設定用DBTRAPをランダムコードブロックの先頭に挿入する
                pNewIns = new CIns_218_dbtrap();
                pNewIns->AppendComment("for Break Setup");
                pBlk->AddOpeCode(pNewIns, 0);
                pBlk->SetBreakSetupInsFlag();
#if DBGMODE
                fprintf(stdout,"==> Insert DBTRAP into CodeBlock Top.\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
        }

		//!< Regulation (skip regulation of instruction in which fixed code, that has no constraint, and done.) 
		UI32 psw; m_pSim->ReadNcReg(&psw, 5, 0);
		if ((psw & 0x80000000) == 0) {
		}else{
			UI32 vsw; m_pSim->ReadTcReg(&vsw, 5, 0, 0);
			psw = vsw;
		}
		if (pBlk->IsRegulation()){
			if((pIns->GetValid() != true) && (! ((pIns->GetPriviledge()==2) && ((psw & 0x20000)==0)) )) {
				if (RegulateBranchCondition(pSp, pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
				if (RegulateValueConstraint(pSp, pBlk, pIns)) {
					p->result.set(IBlockSimParam::BSR_REASM);
					return true; /* Re-Compile & Re-Sim */
				}
			}
		} else { // if(!pBlk->IsRegulation()){ // Generate preset memory for code block other than random code block.
			// Memory Init before first access! --> to create __preload codeblock.
			if ( pIns->Behavior(IInstruction::STORE_MEMORY) ) 
			{
				IOperand		*pOpr;
				const UI64 PFETCHSIZE = g_cfg->m_nFetchSize >> 3;

				for(UI32 nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++)
				{
					pOpr = pIns->opr(nOpr);
					pOpr->AlignData(m_pSim, PFETCHSIZE);
					
				}
			}
		}

        //!< BreakSet
		if(break_point_weight) {	// WeightがzeroならBreak対象としない
            // ブレーク発生対象命令の条件は、ランダムコードブロック内でDBTRAP命令でも、プリフェッチ？（DBTRAPの次の命令）でもないこと
			if((pBlk->GetAddress() <= p->ppc) && (p->ppc < (pBlk->GetAddress() + pBlk->GetCodeSize())) && (pBlk->IsRegulation()) && (! p->bDebugExcep) && (pIns->GetId() != INS_ID_DBT)) {
                // かつ、補正命令ではなく、ブレーク発生対象命令でもなく、デバッグ例外発生命令でもないこと
                if(( pIns->GetRegulationTarget() == nullptr ) && ( ! pIns->m_bBreakTargetIns ) && ( ! pIns->m_bBreakInsertIns )) {
                    if( pIns->m_bBreakCheckDone ) {
                        break_type = IBreakParam::BREAK_NONE;
                    } else {
                        // ブレーク発生要否とブレーク種別の決定
                        break_type = GenerateBreakPointBeforeSetup(p,pIns,pBlk);
                        if(( break_type == IBreakParam::BREAK_SS ) && ( pIns->m_bBreakNotSS )){
                            break_type = IBreakParam::BREAK_NONE; // Chain_CTRET/EIRET/FERETマクロによるジャンプでは、マクロ中にDBTRAP命令を挿入すると復帰先がずれるのでSSを抑止する
                            p->pBreakParam.pop_back();
                        }
                        pIns->m_bBreakCheckDone = true; // 該当命令は、ブレーク発生要否とブレーク種別の決定を行った
                        // ブレーク種別がNONEではなく、未使用チャネルが存在する時、
                        if(( break_type != IBreakParam::BREAK_NONE ) && ( p->pBreakParam.size() <= g_exp->GetNumOfChannels() )){
                            /* ブレークパラメータ発生タイミングとして、ブレーク例外発生対象命令にフラグを設定 */
                            pIns->m_bBreakTargetIns = true;
#if DBGMODE
                            fprintf(stdout,"==> At Created BreakPointSetup, Target Instruction ID:%d Index:%d Code:%s\n", pIns->GetId(),pBlk->GetIndex(pIns),pIns->GetCode().c_str());
#endif                        
                            //!< BreakInsertIns
                            // ブレーク種別がSSの時、デバッグ例外発生命令としてDBTRAP命令を挿入する
                            if( break_type == IBreakParam::BREAK_SS ) {
                                pNewIns = DBTRAP();
                                pNewIns->SetLabel(p->pBreakParam.back().m_addr_label);
                                pNewIns->AppendComment(" for Break_SS ");
                                pIns->DirMoveTo(pNewIns);
                                pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                                pNewIns->m_bBreakInsertIns = true;
                                pNewIns->m_bBreakCheckDone = true;
#if DBGMODE
                                fprintf(stdout,"==> Insert dbtrap instruction for Break_SS label:%s\n",pNewIns->GetLabel().c_str());
#endif
                                // 該当命令をReplaceしているので、DBTRAP命令挿入処理の前に移動できない。
                                if( pIns->GetId() == INS_ID_LOOP ) {
                                    pIns->SetInLoop();
                                }
                                p->result.set(IBlockSimParam::BSR_REASM);
                                return true; /* Re-Compile & Re-Sim */
                            }
                        }
                    }
                }
            }
            if( break_type == IBreakParam::BREAK_LDB ) {
                pIns->SetLabel(p->pBreakParam.back().m_addr_label);
                fprintf(stdout,"==> SetLabel %s: %s\n",pIns->GetLabel().c_str(),pIns->GetCode().c_str());
                if( pIns->GetId() == INS_ID_SWITCH ) { // SWITCH命令の場合は
                    {
                        UI32 val;
                        m_pSim->ReadGrReg(&val, pIns->opr(0)->Idx(), 0); //TODO:Multi thread not support
                        p->pBreakParam.back().m_addr = ( val << 1 ) + 2; // +2 SWITCH命令のコードサイズ２バイト分を加算したアドレスがメモリアクセス位置
                        fprintf(stdout,"==> SetAddress %#08x\n",val);
                    }
                } else {
                    p->pBreakParam.back().m_addr_label = "";
                }
            }
            // ブレーク種別がAEの時、デバッグ例外発生命令としてAE用のSPミスアライン化命令を挿入する
            if( break_type == IBreakParam::BREAK_AE ) {
                pNewIns = ORI(0x1,3,3);
                pNewIns->AppendComment(" for Break_AE ");
                pIns->DirMoveTo(pNewIns);
                pBlk->AddOpeCode(pNewIns, pBlk->GetIndex(pIns));
                pNewIns->m_bBreakInsertIns = true;
#if DBGMODE
                fprintf(stdout,"==> Insert ori instruction for Break_AE\n");
#endif
                p->result.set(IBlockSimParam::BSR_REASM);
                return true; /* Re-Compile & Re-Sim */
            }
        }
		break_type = IBreakParam::BREAK_NONE;
		//!< Regulation done!
		if(pIns-> InLoop() == false)
			pIns->SetValid(true);

#if DBGMODE
        {
            UI32       nOpr;
            IOperand*  pOpr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
                pOpr = pIns->opr(nOpr);
				pOpr->PrintRetVal(m_pSim, ss);
            }
        }
#endif
		//!< Send operation code.
		ISimulatorStepResp res;

        m_inst_statistics.BeforeAcquisition(pBlk->GetStatistics(), pIns, m_pSim, htid) ;

		if (Step(htid, p->lpc, p->ppc, pIns, &res) == false) {
			UI32 code;
			m_pSim->GetErrorInfo(&code);
			if (code == ERR_THREAD_IS_HALT) {
				// Exit successfully
				// TODO: TO BE FIXED ( On multi thread )
				p->result.set(IBlockSimParam::BSR_EXIT_SUCCESS);
				return true;/* Sim Complete */
			}
			MSG_ERROR(0, "Simulation failed (%08X) : \"%s\"\n", code, pIns->GetCode().c_str());
			p->result.set(IBlockSimParam::BSR_FATALERROR); 
			return false; /* Sim Stop */
		}
#if DBGMODE
        {
            UI32       nOpr;
            IOperand*  pOpr;
            
            for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++) {
               pOpr = pIns->opr(nOpr);
			   pOpr->PrintGetVal(m_pSim, ss);
            }
        }
#endif

        m_inst_statistics.AfterAcquisition(pBlk->GetStatistics(), pIns, m_pSim, htid);
        m_memory_statistics.Acquisition(pBlk->GetStatistics(), pIns, m_pSim);
		IExceptionConfig* pExp = IdentifyException(p->pException, (res.exception & 0x0ffff));
        if (res.exception && pBlk->GetStatistics()) {
            p->pException->CountUpRandom(pExp->m_id);
        }

		//!< Exception Handling --> No operation for any exceptions without counting for report.
		if (res.exception) {
			p->pException->CountUp(pExp->m_id);
		}
		
        //!< GetBreakInfo
        //!< デバッグ例外発生対象命令ならば、ブレークパラメータを設定する 
        if( pIns->m_bBreakTargetIns ) {
            GenerateBreakPointSetup(p,pIns,pBlk);
		}
// -- Debug print
#if LOGSW_INS_SIM
		{
			UI32 psw; m_pSim->ReadNcReg(&psw, 5, 0);
			std::cout << '[';
			std::cout << ((psw & 0x80000000) ? 'V':'N'); 
			if ((psw & 0x80000000) == 0) {
				std::cout << ((psw & 0x40000000) ? 'U':'S'); 
				std::cout << ((psw & 0x00010000) ? '0':'-'); 
				std::cout << ((psw & 0x00020000) ? '1':'-'); 
				std::cout << ((psw & 0x00040000) ? '2':'-');
				std::cout << ':';
				std::cout << ((psw & 0x00000010) ? 'A':'-');
				std::cout << ((psw & 0x00000008) ? 'C':'-');
				std::cout << ((psw & 0x00000004) ? 'V':'-');
				std::cout << ((psw & 0x00000002) ? 'S':'-');
				std::cout << ((psw & 0x00000001) ? 'Z':'-');
			}else{
				UI32 vsw; m_pSim->ReadTcReg(&vsw, 5, 0, 0);
				std::cout << ((vsw & 0x40000000) ? 'U':'S'); 
				std::cout << ((vsw & 0x00010000) ? '0':'-'); 
				std::cout << ((vsw & 0x00020000) ? '1':'-'); 
				std::cout << ((vsw & 0x00040000) ? '2':'-');
				std::cout << ':';
				std::cout << ((vsw & 0x00000010) ? 'A':'-');
				std::cout << ((vsw & 0x00000008) ? 'C':'-');
				std::cout << ((vsw & 0x00000004) ? 'V':'-');
				std::cout << ((vsw & 0x00000002) ? 'S':'-');
				std::cout << ((vsw & 0x00000001) ? 'Z':'-');
			} 
			std::cout << "]: ";
			
			UI32 tabstop = pBlk->IsRegulation() ? 8 : 12;
			std::cout << std::hex << std::setw(tabstop) << std::setfill(' ') << p->lpc << "(L):" << std::setw(tabstop) << std::setfill(' ') << p->ppc<<"(P)";
			std::cout << (((pIns->GetComment().find("Regulation")) == std::string::npos) ? " : " : " ! ");
			std::cout << pIns->GetCode();
			if (res.exception) {
				std::cout << " -> " << p->pException->GetName(res.exception & 0x0ffff);
			}
			if (0) {
				std::bitset<32> r = pIns->GetOprSrc();
				std::bitset<32> w = pIns->GetOprDst();
				std::cout << "\tR:" << r << " W:" << w;
			}
            std::cout << " # " << ss.str() << std::endl;
            ss.str(""); ss.clear(std::stringstream::goodbit);
		}
#endif
		// -- Debug print
		
        // Debug Exception Flag set/reset
        switch( pIns->GetId() ) {
        case INS_ID_DBT:
        case INS_ID_RMT:
            p->bDebugExcep = true;
            break;
        case INS_ID_DBRET:
            p->bDebugExcep = false;
            break;
        }

		// PC Update
		p->bPrevChain = pIns->GetChain(); // コードブロック終端判定用
		if (DecodeAddress(res.pc, &p->lpc, &p->ppc) != true) {
			MSG_ERROR(0, "Fail to transfer PC(LA:%08X)\n", p->lpc);
			return false; /* Sim Stop */
		}
		
		// 1Blockで1万ステップを越える場合、無限ループに入り込んでいる可能性が高い
		// 異常終了させる
		if (inBlockSimCount > 10000) {
			MSG_ERROR(0, "Simulation overflow (simulator exceeded the upper limit of steps in block[%s].)\n",pBlk->GetName().c_str());
			break;
		}
	}
	
	p->result.set(IBlockSimParam::BSR_FATALERROR);
	return false; /* Sim abended */
}


