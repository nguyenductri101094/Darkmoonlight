#include "exception.h"

CException::CException()
{
}

CException::~CException()
{
}

IException* CException::Setup() {
	
	IExceptionConfig cfg;

	cfg.m_id		= EXP_RESET;
	cfg.m_name		= "RESET";
	cfg.m_lcode		= 0x0000;
	cfg.m_ucode		= 0x0000;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_NONE;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_SYSERR;
	cfg.m_name		= "SYSERR";
	cfg.m_lcode		= 0x0010;
	cfg.m_ucode		= 0x001f;
	cfg.m_addr		= 0x0010;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;
	
	cfg.m_id		= EXP_HVTRAP;
	cfg.m_name		= "HVTRAP";
	cfg.m_lcode		= 0xf000;
	cfg.m_ucode		= 0xf01f;
	cfg.m_addr		= 0x0020;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	SetConfig(&cfg);

	cfg.m_id		= EXP_FETRAP;
	cfg.m_name		= "FETRAP";
	cfg.m_lcode		= 0x0031;
	cfg.m_ucode		= 0x003f;
	cfg.m_addr		= 0x0030;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_TRAP0;
	cfg.m_name		= "TRAP0";
	cfg.m_lcode		= 0x0040;
	cfg.m_ucode		= 0x004f;
	cfg.m_addr		= 0x0040;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_TRAP1;
	cfg.m_name		= "TRAP1";
	cfg.m_lcode		= 0x0050;
	cfg.m_ucode		= 0x005f;
	cfg.m_addr		= 0x0050;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	SetConfig(&cfg);

	cfg.m_id		= EXP_RIE;
	cfg.m_name		= "RIE";
	cfg.m_lcode		= 0x0060;
	cfg.m_ucode		= 0x0060;
	cfg.m_addr		= 0x0060;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);
	cfg.m_id		= EXP_FPP;
	cfg.m_name		= "FPE";
	cfg.m_lcode		= 0x0071;
	cfg.m_ucode		= 0x0071;
	cfg.m_addr		= 0x0070;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	SetConfig(&cfg);

	cfg.m_id		= EXP_FXE;
	cfg.m_name		= "FXE";
	cfg.m_lcode		= 0x0075;
	cfg.m_ucode		= 0x0075;
	cfg.m_addr		= 0x0070;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	SetConfig(&cfg);

	cfg.m_id		= EXP_UCPOP0;
	cfg.m_name		= "UCPOP(0)";
	cfg.m_lcode		= 0x0080;
	cfg.m_ucode		= 0x0080;
	cfg.m_addr		= 0x0080;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);

	cfg.m_id		= EXP_UCPOP1;
	cfg.m_name		= "UCPOP(1)";
	cfg.m_lcode		= 0x0081;
	cfg.m_ucode		= 0x0081;
	cfg.m_addr		= 0x0080;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);

	cfg.m_id		= EXP_UCPOP2;
	cfg.m_name		= "UCPOP(2)";
	cfg.m_lcode		= 0x0082;
	cfg.m_ucode		= 0x0082;
	cfg.m_addr		= 0x0080;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_MIP;
	cfg.m_name		= "MIP";
	cfg.m_lcode		= 0x0090;
	cfg.m_ucode		= 0x0090;
	cfg.m_addr		= 0x0090;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);

	cfg.m_id		= EXP_MDP;
	cfg.m_name		= "MDP";
	cfg.m_lcode		= 0x0091;
	cfg.m_ucode		= 0x0091;
	cfg.m_addr		= 0x0090;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);

	cfg.m_id		= EXP_MDP_INT;
	cfg.m_name		= "MDP_INT";
	cfg.m_lcode		= 0x0095;
	cfg.m_ucode		= 0x0095;
	cfg.m_addr		= 0x0090;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);

    cfg.m_id = EXP_MIP_HM;
    cfg.m_name = "MIP_HM";
    cfg.m_lcode = 0x0098;
    cfg.m_ucode = 0x0098;
    cfg.m_addr = 0x0090;
    cfg.m_weight = 0x0000;
    cfg.m_level = IExceptionConfig::EXP_LEVEL_FE;
    SetConfig(&cfg);

    cfg.m_id = EXP_MDP_HM;
    cfg.m_name = "MDP_HM";
    cfg.m_lcode = 0x0099;
    cfg.m_ucode = 0x0099;
    cfg.m_addr = 0x0090;
    cfg.m_weight = 0x0000;
    cfg.m_level = IExceptionConfig::EXP_LEVEL_FE;
    SetConfig(&cfg);

    cfg.m_id = EXP_MDP_INT_HM;
    cfg.m_name = "MDP_INT_HM";
    cfg.m_lcode = 0x009D;
    cfg.m_ucode = 0x009D;
    cfg.m_addr = 0x0090;
    cfg.m_weight = 0x0000;
    cfg.m_level = IExceptionConfig::EXP_LEVEL_FE;
    SetConfig(&cfg);

	cfg.m_id		= EXP_PIE;
	cfg.m_name		= "PIE";
	cfg.m_lcode		= 0x00a0;
	cfg.m_ucode		= 0x00a0;
	cfg.m_addr		= 0x00a0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);

	cfg.m_id		= EXP_DBTRAP;
	cfg.m_name		= "DBTRAP";
	cfg.m_lcode		= 0x00b1;
	cfg.m_ucode		= 0x00b1;
	cfg.m_addr		= 0x00b0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_DB;
	SetConfig(&cfg);
	
#if 1
		cfg.m_id				= EXP_BREAK_NONE;
        cfg.m_name              = "NONE";
        cfg.m_type              = IBreakParam::BREAK_NONE;
        cfg.m_lcode             = 0x2000;
        cfg.m_ucode             = 0x2000;
        cfg.m_addr              = 0x0000;
        cfg.m_weight            = 0x0000;
        SetConfig(&cfg);

		cfg.m_id				= EXP_PCB;
        cfg.m_name              = "PCB";
        cfg.m_type              = IBreakParam::BREAK_PCB;
        cfg.m_lcode             = 0x21b5;
        cfg.m_ucode             = 0x21b5;
        cfg.m_addr              = 0x00b0;
        cfg.m_weight            = 0x0000;
		cfg.m_level				= IExceptionConfig::EXP_LEVEL_DB;
        SetConfig(&cfg);

		cfg.m_id				= EXP_LSAB;
        cfg.m_name              = "LSAB";
        cfg.m_type              = IBreakParam::BREAK_LSAB;
        cfg.m_lcode             = 0x22b5;
        cfg.m_ucode             = 0x22b5;
        cfg.m_addr              = 0x00b0;
        cfg.m_weight            = 0x0000;
		cfg.m_level				= IExceptionConfig::EXP_LEVEL_DB;
        SetConfig(&cfg);

		cfg.m_id				= EXP_AE;
        cfg.m_name              = "AE";
        cfg.m_type              = IBreakParam::BREAK_AE;
        cfg.m_lcode             = 0x24b5;
        cfg.m_ucode             = 0x24b5;
        cfg.m_addr              = 0x00b0;
        cfg.m_weight            = 0x0000;
		cfg.m_level				= IExceptionConfig::EXP_LEVEL_DB;
        SetConfig(&cfg);

#else
	cfg.m_name		= "PCB/LSAB/SDB/AE";
	cfg.m_lcode		= 0x00b5;
	cfg.m_ucode		= 0x00b5;
	cfg.m_addr		= 0x00b0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_DB;
	SetConfig(&cfg);
	
	cfg.m_name		= "LDB/RMWDB";
	cfg.m_lcode		= 0x00b6;
	cfg.m_ucode		= 0x00b6;
	cfg.m_addr		= 0x00b0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_DB;
	SetConfig(&cfg);
#endif	//#ifdef 1

	cfg.m_id		= EXP_DBINT;
	cfg.m_name		= "DBINT";
	cfg.m_lcode		= 0x00b0;
	cfg.m_ucode		= 0x00bf;
	cfg.m_addr		= 0x00b0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_DB;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_DBNMI;
	cfg.m_name		= "DBNMI";
	cfg.m_lcode		= 0x00bf;
	cfg.m_ucode		= 0x00bf;
	cfg.m_addr		= 0x00b0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_DB;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;
	
	cfg.m_id		= EXP_MAE;
	cfg.m_name		= "MAE";
	cfg.m_lcode		= 0x00c0;
	cfg.m_ucode		= 0x00c0;
	cfg.m_addr		= 0x00c0;
	cfg.m_weight	= 0x0000;
	cfg.m_force		= true;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_FENMI;
	cfg.m_name		= "FENMI";
	cfg.m_lcode		= 0x00e0;
	cfg.m_ucode		= 0x00e0;
	cfg.m_addr		= 0x00e0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_FEINT;
	cfg.m_name		= "FEINT";
	cfg.m_lcode		= 0x00f0;
	cfg.m_ucode		= 0x00ff;
	cfg.m_addr		= 0x00f0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_EIINT;
	cfg.m_name		= "EIINT";
	cfg.m_lcode		= 0x1000;
	cfg.m_ucode		= 0x17ff;
	cfg.m_addr		= 0x0100;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_EITBL;
	cfg.m_name		= "EITBL"; //[FROG]TODO
	cfg.m_lcode		= Code_DUMMY;
	cfg.m_ucode		= Code_DUMMY;
	cfg.m_addr		= 0x0100;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_RBINT;
	cfg.m_name		= "RBINT"; //[FROG]TODO
	cfg.m_lcode		= Code_DUMMY - 1;
	cfg.m_ucode		= Code_DUMMY - 1;
	cfg.m_addr		= 0x0100;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	cfg.m_bankNum	= 0;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_GMFEINT;
	cfg.m_name		= "GMFEINT";
	cfg.m_lcode		= 0x00f0;
	cfg.m_ucode		= 0x00ff;
	cfg.m_addr		= 0x00f0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_FE;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_GMEIINT;
	cfg.m_name		= "GMEIINT";
	cfg.m_lcode		= 0x1000;
	cfg.m_ucode		= 0x17ff;
	cfg.m_addr		= 0x0100;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_GMEITBL;
	cfg.m_name		= "GMEITBL";
	cfg.m_lcode		= Code_DUMMY - 2;
	cfg.m_ucode		= Code_DUMMY - 2;
	cfg.m_addr		= 0x0100;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_GMRBINT;
	cfg.m_name		= "GMRBINT";
	cfg.m_lcode		= Code_DUMMY - 3;
	cfg.m_ucode		= Code_DUMMY - 3;
	cfg.m_addr		= 0x0100;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	cfg.m_bankNum	= 0;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_BGFEINT;
	cfg.m_name		= "BGFEINT";
	cfg.m_lcode		= 0xD800;
	cfg.m_ucode		= 0xD80F;
	cfg.m_addr		= 0x00D0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_BGEIINT;
	cfg.m_name		= "BGEIINT";
	cfg.m_lcode		= 0xD000;
	cfg.m_ucode		= 0xD7FF;
	cfg.m_addr		= 0x00D0;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	cfg.m_bIsInterrupt = true;
	SetConfig(&cfg);
	cfg.m_bIsInterrupt = false;

	cfg.m_id		= EXP_SYSCALL;
	cfg.m_name		= "SYSCALL";
	cfg.m_lcode		= 0x8000;
	cfg.m_ucode		= 0x80ff;
	cfg.m_addr		= 0xffff;
	cfg.m_weight	= 0x0000;
	cfg.m_level		= IExceptionConfig::EXP_LEVEL_EI;
	SetConfig(&cfg);
			
	cfg.m_id		= EXP_BREAK_CHANNEL;
	cfg.m_name		= "NumOfChannels";
	cfg.m_lcode		= Code_Ch_NumOfChannels;
	cfg.m_ucode		= Code_Ch_NumOfChannels;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 4;
	SetConfig(&cfg);

	cfg.m_id		= EXP_BPC_TY;
	cfg.m_name		= "BPC.TY";
	cfg.m_lcode		= Code_Ch_BPC_TY;
	cfg.m_ucode		= Code_Ch_BPC_TY;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);

	cfg.m_id		= EXP_BPC_VA;
	cfg.m_name		= "BPC.VA";
	cfg.m_lcode		= Code_Ch_BPC_VA;
	cfg.m_ucode		= Code_Ch_BPC_VA;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);

	cfg.m_id		= EXP_BPC_TE;
	cfg.m_name		= "BPC.TE";
	cfg.m_lcode		= Code_Ch_BPC_TE;
	cfg.m_ucode		= Code_Ch_BPC_TE;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_BPC_BE;
	cfg.m_name		= "BPC.BE";
	cfg.m_lcode		= Code_Ch_BPC_BE;
	cfg.m_ucode		= Code_Ch_BPC_BE;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_BPC_FE;
	cfg.m_name		= "BPC.FE";
	cfg.m_lcode		= Code_Ch_BPC_FE;
	cfg.m_ucode		= Code_Ch_BPC_FE;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_BPC_WE;
	cfg.m_name		= "BPC.WE";
	cfg.m_lcode		= Code_Ch_BPC_WE;
	cfg.m_ucode		= Code_Ch_BPC_WE;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_BPC_RE;
	cfg.m_name		= "BPC.RE";
	cfg.m_lcode		= Code_Ch_BPC_RE;
	cfg.m_ucode		= Code_Ch_BPC_RE;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 50;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_BPAM;
	cfg.m_name		= "BPAM";
	cfg.m_lcode		= Code_Ch_BPAM;
	cfg.m_ucode		= Code_Ch_BPAM;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 0;
	SetConfig(&cfg);
	
	cfg.m_id		= EXP_SEQ;
	cfg.m_name		= "SEQ";
	cfg.m_lcode		= Code_Ch_DIR1_SQ;
	cfg.m_ucode		= Code_Ch_DIR1_SQ;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 0;
	SetConfig(&cfg);

	cfg.m_id		= EXP_DIR1_SQ0;
	cfg.m_name		= "DIR1.SQ0";
	cfg.m_lcode		= Code_Ch_DIR1_SQ0;
	cfg.m_ucode		= Code_Ch_DIR1_SQ0;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 0;
	SetConfig(&cfg);

	cfg.m_id		= EXP_DIR1_SQ1;
	cfg.m_name		= "DIR1.SQ1";
	cfg.m_lcode		= Code_Ch_DIR1_SQ1;
	cfg.m_ucode		= Code_Ch_DIR1_SQ1;
	cfg.m_addr		= 0x0000;
	cfg.m_weight	= 0;
	SetConfig(&cfg);
	
	return this;
}
