#ifndef SYSREG_H_
#define SYSREG_H_

#include		"rtg_common.h"
#include		"ifsysreg.h"

class CSysReg : public ISysReg
{
public:
	
	/**
	 * @brief  このオブジェクトを構築します
	 */
	CSysReg() : m_regId(0), m_selId(0), m_name(), m_priv(0), m_context(0),
		m_bInit(0), m_ncInit(0), m_vcInit(0), m_tcInit(0), m_access(0), m_writeMask(0xffffffff), m_verify(true) {};

	/**
	 * @brief  このオブジェクトを破棄します
	 */
	virtual ~CSysReg(){}
	
	
	enum EN_SR_PRIV{
		SR_PRIV_UM,
		SR_PRIV_SV,
		SR_PRIV_CU0,
		SR_PRIV_CU1,
		SR_PRIV_CU2,
		SR_PRIV_DB,
		SR_PRIV_BIT,
		SR_PRIV_END
	};
	
	enum EN_SR_CONTEXT{
		SR_CONTEXT_NC,
		SR_CONTEXT_VC,
		SR_CONTEXT_TC,
		SR_CONTEXT_END
	};
	
	enum EN_SR_ACCESS{
		SR_ACCESS_LOAD,
		SR_ACCESS_STORE,
		SR_ACCESS_END
	};

	/**/
	virtual UI32 GetId() {
		// E3V5ではBank*32 + regIDをSRユニークなキー値とする。
		return ((m_selId << 5) + m_regId);
	}

	virtual bool ParseCsvRecord(std::vector<std::string> toks);

	virtual bool RequireInit() {
		return (m_bInit != 0);
	}
	virtual bool Loadable() {
		return m_access[SR_ACCESS_LOAD];
	}
	virtual bool Storable() {
		return m_access[SR_ACCESS_STORE];
	}
	virtual bool IsNC() {
		return m_context[SR_CONTEXT_NC];
	}
	virtual bool IsVC() {
		return m_context[SR_CONTEXT_VC];
	}
	virtual bool IsTC() {
		return m_context[SR_CONTEXT_TC];
	}
	virtual bool IsInitNC() {
		return m_bInit[SR_CONTEXT_NC] && m_context[SR_CONTEXT_NC];
	}
	virtual bool IsInitVC() {
		return m_bInit[SR_CONTEXT_VC] && m_context[SR_CONTEXT_VC];
	}
	virtual bool IsInitTC() {
		return m_bInit[SR_CONTEXT_TC] && m_context[SR_CONTEXT_TC];
	}

	virtual UI32 GetWriteMask() {
		return m_writeMask;
	}

	virtual std::string GetName() {
        return m_name;
    }
	
	virtual void Dump(std::ostream& os);

	void GetRegId(UI32* RegId){
		*RegId = m_regId;
	}

	void GetSelReg(UI32* SelId){
		*SelId = m_selId;
	}

	void GetRegName(std::string* RegName){
		*RegName = m_name;
	}

	void GetTcInit(UI32* tc){
		*tc = m_tcInit;
	}

	void GetNcInit(UI32* nc){
		*nc = m_ncInit;
	}

	void GetVcInit(UI32* vc){
		*vc = m_vcInit;
	}
public:
	UI32						m_regId;
	UI32						m_selId;
	std::string					m_name;
	std::bitset<SR_PRIV_END>	m_priv;
	std::bitset<SR_CONTEXT_END>	m_context;
	std::bitset<SR_CONTEXT_END>	m_bInit;
	UI32						m_ncInit;
	UI32						m_vcInit;
	UI32						m_tcInit;
	std::bitset<SR_ACCESS_END>	m_access;
	UI32						m_writeMask;
	bool						m_verify;
};


/**
 * 
 */
class CSysRegSet : public ISysRegSet {

public:

	enum {
		CONTEXT_NC,		//!< @brief  0=>+1 
		CONTEXT_VC,		//!< @brief  1=>+2
		CONTEXT_TC,		//!< @brief  2=>+4
		LOAD,			//!< @brief  3=>+8
		STORE,			//!< @brief  4=>+16
		SRFILTER_NUM	
	} SRFILTER;

	/**
	 * @brief  このオブジェクトを構築します
	 */
	CSysRegSet () : m_NLoad(&g_rnd), m_NStore(&g_rnd), m_VLoad(&g_rnd), m_VStore(&g_rnd), m_TLoad(&g_rnd), m_TStore(&g_rnd) {}


	/**
	 * @brief  このオブジェクトを破棄します
	 */
	virtual ~CSysRegSet () {}
		

	/**
	 * @brief レジスタを選択する。
	 * @return デフォルト構成
	 */
	virtual ISysRegSet* Default();
			

	/**
	 * @brief レジスタを選択する。
	 * @param flags 実装で定義する
	 * @return レジスタインデックス
	 */
	virtual UI32 Select(UI32 flags = 0);
	

	/**
	 * @brief レジスタ情報をパースする。
	 *        1レコードについてCSVのパースを行い、
	 *        各カラムの解釈方法はアーキテクチャ部に移譲する。 
	 * @param file ファイルパス
	 * @param 失敗時は偽を返す
	 */
	virtual bool ParseCsv(std::string file);


	/**
	 * @brief レジスタが搭載されているか確認する。
	 * @param id レジスタID
	 * @return 搭載されていれば true。
	 */
	virtual bool IsLoadable(UI32 regid, UI32 selid)
    {
		std::map<UI32,ISysReg*>::iterator itr = m_setSr.find((selid << 5) + regid) ;
        if (itr != m_setSr.end()) {
            return itr->second->Loadable();
        }
        return false ; 
    }


	/**
	 * @brief レジスタへストアが可能か確認する。
	 * @param id レジスタID
	 * @return ストアが可能ならば true。
	 */
	virtual bool IsStorable(UI32 regid, UI32 selid)
    {
		std::map<UI32,ISysReg*>::iterator itr = m_setSr.find((selid << 5) + regid) ;
        if (itr != m_setSr.end()) {
            return itr->second->Storable();
        }
        return false ; 
    }


	virtual bool MatchContext(UI32 flag, std::vector<BKREG>* vec)
    {
    	FROG_ASSERT(vec);
    	std::map<UI32,ISysReg*>::iterator itr;
        for (itr = m_setSr.begin(); itr != m_setSr.end(); ++itr) {
        	CSysReg* p = static_cast <CSysReg*> (itr->second);
        	if (p->m_context[flag] && p->m_verify==true) {
        		vec->push_back(itr->first);
        	}
        }

        return false ; 
    }

	/**
	 * @brief Get all avaiable contexts of a system register
	 * @param id regid, selid
	 * @param context, output param contains avaiable contexts
	 * @return bool, true: succeeded, false: not found system register
	 */
	virtual bool GetContext(UI32 regid, UI32 selid, UI32 &context)
	{
		context = 0;
		std::map<UI32,ISysReg*>::iterator itr = m_setSr.find((selid << 5) + regid);
		if(itr != m_setSr.end())
		{
			CSysReg* p = static_cast <CSysReg*> (itr->second);
			context |= p->m_context[CONTEXT_NC] << CONTEXT_NC;
			context |= p->m_context[CONTEXT_VC] << CONTEXT_VC;
			context |= p->m_context[CONTEXT_TC] << CONTEXT_TC;
			return true;
		}

		return false;
	}

	/**
	 * @brief [デバッグ用]
	 */
	virtual void Dump(std::ostream& os = std::cout) {

		std::set<UI32>::iterator itr;
		
		std::set<UI32> keySetNL = m_NLoad.KeySet();
		std::cout << "--------- NATIVE LOAD ------------" << std::endl;
		for (itr = keySetNL.begin(); itr != keySetNL.end(); ++itr) {
			std::map<UI32,ISysReg*>::iterator i = m_setSr.find(*itr);
			if (i == m_setSr.end()) {
				_ASSERT(0);
			}
			i->second->Dump(os);
		}
		
		{
		std::set<UI32> keySetNS = m_NStore.KeySet();
		std::cout << "--------- NATIVE STORE ------------" << std::endl;
		for (itr = keySetNS.begin(); itr != keySetNS.end(); ++itr) {
			std::map<UI32,ISysReg*>::iterator i = m_setSr.find(*itr);
			if (i == m_setSr.end()) {
				_ASSERT(0);
			}
			i->second->Dump(os);
		}
		}
		
		std::set<UI32> keySetVL = m_VLoad.KeySet();
		std::cout << "--------- Virtual LOAD ------------" << std::endl;
		for (itr = keySetVL.begin(); itr != keySetVL.end(); ++itr) {
			std::map<UI32,ISysReg*>::iterator i = m_setSr.find(*itr);
			if (i == m_setSr.end()) {
				_ASSERT(0);
			}
			i->second->Dump(os);
		}
		
		std::set<UI32> keySetVS = m_VStore.KeySet();
		std::cout << "--------- Virtual STORE ------------" << std::endl;
		for (itr = keySetVS.begin(); itr != keySetVS.end(); ++itr) {
			std::map<UI32,ISysReg*>::iterator i = m_setSr.find(*itr);
			if (i == m_setSr.end()) {
				_ASSERT(0);
			}
			i->second->Dump(os);
		}
		
		std::set<UI32> keySetTL = m_TLoad.KeySet();
		std::cout << "--------- Thread LOAD ------------" << std::endl;
		for (itr = keySetTL.begin(); itr != keySetTL.end(); ++itr) {
			std::map<UI32,ISysReg*>::iterator i = m_setSr.find(*itr);
			if (i == m_setSr.end()) {
				_ASSERT(0);
			}
			i->second->Dump(os);
		}
		
		std::set<UI32> keySetTS = m_TStore.KeySet();
		std::cout << "--------- Thread STORE ------------" << std::endl;
		for (itr = keySetTS.begin(); itr != keySetTS.end(); ++itr) {
			std::map<UI32,ISysReg*>::iterator i = m_setSr.find(*itr);
			if (i == m_setSr.end()) {
				_ASSERT(0);
			}
			i->second->Dump(os);
		}
	}

	/**
	 * @brief Get the mask that specifies writable bit
	 * @param id Reg number (regid), group number (selid)
	 * @return Mask bit
	 */
	virtual UI32 GetWriteMask(UI32 regid, UI32 selid)
	{
		UI32 nMask = 0xffffffff;
		std::map<UI32,ISysReg*>::iterator itr = m_setSr.find((selid << 5) + regid) ;
		if (itr != m_setSr.end()) {
			nMask = itr->second->GetWriteMask();
		}
		return nMask; 
	}
	
protected:

	/**
	 * @brief 読み出し対象となるシステムレジスタのリストを構成します
	 */
	virtual void MakeList();

	
	/**
	 * @brief  このオブジェクトを構築します
	 */
	CWeightedRandom<UI32>	m_NLoad;
	CWeightedRandom<UI32>	m_NStore;
	CWeightedRandom<UI32>	m_VLoad;
	CWeightedRandom<UI32>	m_VStore;
	CWeightedRandom<UI32>	m_TLoad;
	CWeightedRandom<UI32>	m_TStore;
};

#endif /*SYSREG_H_*/
