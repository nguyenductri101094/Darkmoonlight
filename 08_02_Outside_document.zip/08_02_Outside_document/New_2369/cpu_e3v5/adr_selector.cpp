#include "adr_selector.h"



// --------------------------------------------------------------------------------------
//
//   CAddressSelector
//
// --------------------------------------------------------------------------------------

/**
 * @brief  指定値が制約に適合するかを検証します
 * @param  val 検証値
 * @return 適合する場合真を返す。
 */
bool CAddressSelector::IsValid(UI64 val) {

	bool isvalid = false;
	if (m_pSegList == NULL) {
		return IValConstraint::IsValid(val);
	}

	//m_pSegList->Dump();
	bool bSuccess = !(this->GetType(IValConstraint::RAISE_MERROR));
	std::vector<CSegmentList*>::iterator itr = m_pSegList->begin();
	for (; itr != m_pSegList->end(); itr++){
		if ((*itr)->Valid(val, m_nSzm, bSuccess) == true) {
			/* Exception起こしたくないのに起きる、起こしたいのに起きない */
			isvalid = true;
			break;

		}
	}
	if (!isvalid) return false;
	// MAE
	return IValConstraint::IsValid(val);
}


/**
 * @brief  制約に適合する目標を得る
 * @return 適合値を返す。
 */
UI64 CAddressSelector::SelectValue() {
	
	std::vector<CSegmentList*>::iterator itr;
	// メモリ許可リスト/論理アドレスリスト
	if (m_pSegList == NULL) {
		// データソースがない
		return IValConstraint::SelectValue();
	}
	
	//m_pSegList->Dump();
	
	// アクセス可能なリストをフィルター
	std::vector<CSegmentStatus*> vset;
	
	bool bExp = (this->GetType(IValConstraint::RAISE_MERROR));
	for (itr = m_pSegList->begin(); itr != m_pSegList->end(); itr++){
		(*itr)->FilterSegmentList(vset, !bExp);
	}

	// 候補無しの場合は、例外制御を反転させる	
	if (vset.size() == 0) {
		this->SetType(IValConstraint::RAISE_MERROR, !bExp);
		for (itr = m_pSegList->begin(); itr != m_pSegList->end(); itr++){
			(*itr)->FilterSegmentList(vset, !bExp);
		}
	}
	
	_ASSERT(vset.size());
	if (vset.size() == 0) {
		return IValConstraint::SelectValue();
	}
	
	// Listの中から選択
	CSegmentStatus* pSS = NULL;
	std::random_shuffle(vset.begin(), vset.end(), g_rnd);
	bool bSelected = false;
	UI32 try_time = 3;
	
	while(try_time > 0)	{ // Try to allocate 2 times
		while (vset.size()) {
			pSS = vset.back();
			vset.pop_back();
			if (pSS->m_nSize < m_nSzm) {
				continue;
			}
		
			_ASSERT(pSS);
							
			// エントリに基づいて設定
			UI64 nMin = pSS->m_nAddr;
			UI64 nMax = pSS->m_nAddr + pSS->m_nSize - m_nSzm;
			UI64 nAcMin = 0;
			UI64 nAcMax = 0;
			if(this->GetType(IValConstraint::ACCESS_RANGE)) {
				if(m_nSzm <= 4) {
					// Aligned memory in case of size is < 4bytes
					nMin = (nMin & m_nMsk) ? ((nMin & (~m_nMsk)) + m_nSzm) : nMin;
					nMax = (nMax & (~m_nMsk));
				}
				// Adjust the ranged based on accessed size.
				nAcMin = m_nAccessedMin - m_nSzm + (m_nSzm % 4);
				nAcMax = m_nAccessedMax - m_nSzm;

				// Invalid: 2 memory areas were not overlapped.
				if(nMax < nAcMin || nAcMax < nMin) {
					continue;
				}

				// Select memory range.
				m_nMin = nAcMin > nMin ? nAcMin : nMin;
				m_nMax = nAcMax < nMax ? nAcMax : nMax;
				bSelected = true;
				break;
			} else {
				m_nMin = nMin;
				m_nMax = nMax;
				bSelected = true;
				break;
			}
		}
		// Allocated succesfully
		if(bSelected)
			break;

		try_time--;
		if(try_time == 2)
			this->SetType(IValConstraint::RAISE_MERROR, !bExp);
		else			// Last time
			this->SetType(IValConstraint::ACCESS_RANGE, false);

		for (itr = m_pSegList->begin(); itr != m_pSegList->end(); itr++){
			(*itr)->FilterSegmentList(vset, !bExp);
		}
		std::random_shuffle(vset.begin(), vset.end(), g_rnd);
	}

	vset.clear();// NOT delete! Clear all elements before destructor called.

	return IValConstraint::SelectValue();
}
/**
 * @brief  制約に適合する目標を得る
 * @return 適合値を返す。
 */
UI64 CAddressSelector::SelectValue(UI64 low_add, UI64 high_add) {
	
	std::vector<CSegmentList*>::iterator itr;
	// メモリ許可リスト/論理アドレスリスト
	if (m_pSegList == NULL) {
		// データソースがない
		return IValConstraint::SelectValue();
	}
	
	//m_pSegList->Dump();
	
	// アクセス可能なリストをフィルター
	std::vector<CSegmentStatus*> vset;
	
	bool bExp = (this->GetType(IValConstraint::RAISE_MERROR));
	for (itr = m_pSegList->begin(); itr != m_pSegList->end(); itr++){
		(*itr)->FilterSegmentList(vset, !bExp);
	}

	// 候補無しの場合は、例外制御を反転させる	
	if (vset.size() == 0) {
		this->SetType(IValConstraint::RAISE_MERROR, !bExp);
		for (itr = m_pSegList->begin(); itr != m_pSegList->end(); itr++){
			(*itr)->FilterSegmentList(vset, !bExp);
		}
	}
	
	_ASSERT(vset.size());
	if (vset.size() == 0) {
		return IValConstraint::SelectValue();
	}
	
	// Listの中から選択
	CSegmentStatus* pSS = NULL;
	std::random_shuffle(vset.begin(), vset.end(), g_rnd);
	
	UI64 SSAddressLow = 0;
	UI64 SSAddressHigh = 0;

	while (vset.size()) {
		pSS = vset.back();
		vset.pop_back();
		SSAddressLow = pSS->m_nAddr;
		SSAddressHigh = pSS->m_nAddr + pSS->m_nSize;
		if ((((SSAddressHigh - m_nSzm ) >= low_add) && (SSAddressHigh <= high_add)) 
			|| (((high_add - m_nSzm ) >= SSAddressLow) && (SSAddressLow >= low_add))) {
			break;
		}
	}
	
	_ASSERT(pSS);
					
	// エントリに基づいて設定
	m_nMin = pSS->m_nAddr;
	m_nMax = pSS->m_nAddr + pSS->m_nSize - m_nSzm;
	
	vset.clear();// NOT delete! Clear all elements before destructor called.

	return IValConstraint::SelectValue();
}

// --------------------------------------------------------------------------------------
//
//   CLoadAddressSelector
//
// --------------------------------------------------------------------------------------


// --------------------------------------------------------------------------------------
//
//   CStoreAddressSelector
//
// --------------------------------------------------------------------------------------


