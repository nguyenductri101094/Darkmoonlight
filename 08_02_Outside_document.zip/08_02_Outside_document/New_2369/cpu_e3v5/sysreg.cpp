#include "sysreg.h"
#include "rtg_cfg.h"

bool CSysReg::ParseCsvRecord(std::vector<std::string> toks) {
	auto GenerateRandomVal = [](std::string name, UI32 val, UI32 mask){
		UI32 nMask = 1;
		UI32 nCount, randomVal, nResult;
		nCount = randomVal = nResult = 0;

		if(mask == 0 || name == "PSW")
			return val;
		if(mask == (UI32) 0xffffffff)
			return g_rnd.GetRange((UI32)0 , (UI32) mask);

		while(nMask){
			if(mask & nMask)
				nCount++;
			nMask <<= 1;
		}
		// Generate a random number in range of (0; (2^nCount) - 1)
		randomVal = g_rnd.GetRange((UI32) 0, (UI32) ((1 << nCount) - 1 ));

		nCount	= 0;
		nMask	= 1;
		while(nMask){
			if(mask & nMask){
				nResult |= (randomVal & 1) << nCount;
				randomVal >>= 1;
			}
			nCount++;
			nMask <<= 1;
		}
		return ((val & ~mask) | (nResult & mask));
	};

	UI32 nSetMask = 0;

	if (toks.size() != 14 && toks.size() != 15) { // TODO: Remove "toks.size() != 14", it is supporting old config.
		return false;
	}
	
	try {
		m_selId		= CToolFnc::AtoI(CToolFnc::Trim(toks.at(0)).c_str());		// RegID
		m_regId		= CToolFnc::AtoI(CToolFnc::Trim(toks.at(1)).c_str());		// SelID
		m_name		= toks.at(2);
		
		std::string prv = CToolFnc::Trim(toks.at(3));
		if (prv.length() == 0) {
			m_priv.set(SR_PRIV_UM);
		} else
		if (prv == "SV") {
			m_priv.set(SR_PRIV_SV);
		} else
		if (prv == "CU0") {
			m_priv.set(SR_PRIV_CU0);
		} else
		if (prv == "CU1") {
			m_priv.set(SR_PRIV_CU1);
		} else
		if (prv == "CU2") {
			m_priv.set(SR_PRIV_CU2);
		} else
		if (prv == "SV/CU2") {
			m_priv.set(SR_PRIV_SV);
			m_priv.set(SR_PRIV_CU2);
		} else
		if (prv == "SV/CU0") {
			m_priv.set(SR_PRIV_SV);
			m_priv.set(SR_PRIV_CU0);
		} else
		if (prv == "BIT") {
			m_priv.set(SR_PRIV_BIT); // BITによって権限が異なる
		}
		
		if (CToolFnc::Trim(toks.at(4)).length()) {
			m_context.set(SR_CONTEXT_NC);
		}
		if (CToolFnc::Trim(toks.at(5)).length()) {
			m_context.set(SR_CONTEXT_VC);
		}
		if (CToolFnc::Trim(toks.at(6)).length()) {
			m_context.set(SR_CONTEXT_TC);
		}
		
		if (CToolFnc::Trim(toks.at(10)) == "YES") {
			m_access.set(SR_ACCESS_LOAD);
		}

		if (CToolFnc::Trim(toks.at(11)) == "YES") {
			m_access.set(SR_ACCESS_STORE);
		}
		// Improving EXP, CALLT, SYSCALL ratio.
		if(m_name == "EBASE" || m_name == "GMEBASE" || m_name == "CTBP" || m_name == "SCBP")
			m_access.set(SR_ACCESS_STORE);

		if (CToolFnc::Trim(toks.at(12)) == "NO") {
			m_verify = false;
		}else{
			m_verify = true;
		}
		if (CToolFnc::Trim(toks.at(13)).length()) {
			m_writeMask = CToolFnc::AtoI(CToolFnc::Trim(toks.at(13)).c_str());
			nSetMask = m_writeMask;
		}
		if (CToolFnc::Trim(toks.at(7)).length() > 1) {
			m_ncInit = CToolFnc::AtoI(CToolFnc::Trim(toks.at(7)).c_str());
			m_ncInit = GenerateRandomVal(m_name, m_ncInit, nSetMask);
			m_bInit.set(SR_CONTEXT_NC);
		}
		if (CToolFnc::Trim(toks.at(8)).length() > 1) {
			m_vcInit = CToolFnc::AtoI(CToolFnc::Trim(toks.at(8)).c_str());
			m_vcInit = GenerateRandomVal(m_name, m_ncInit, nSetMask);
			m_bInit.set(SR_CONTEXT_VC);
		}
		if (CToolFnc::Trim(toks.at(9)).length() > 1) {
			m_tcInit = CToolFnc::AtoI(CToolFnc::Trim(toks.at(9)).c_str());
			m_tcInit = GenerateRandomVal(m_name, m_ncInit, nSetMask);
			m_bInit.set(SR_CONTEXT_TC);
		}
	} catch (std::invalid_argument e) {
		return false;
	} catch (std::out_of_range e) {
		return false;
	}
	
	return true;
}

void CSysReg::Dump(std::ostream& os) {
	os << m_name << "=SR(" << std::dec << m_selId << ',' << m_regId << "), Priv(bit)=" << m_priv <<", Context(bit)=" << m_context <<", Preload(bit)=" << 
	m_bInit << "NC=0x" << std::hex << m_ncInit <<", VC=0x" << std::hex << m_vcInit << ", TC=0x" << std::hex << m_tcInit << ", Access(bit)" << m_access << std::endl;
}


//
//
//  CSysRegSet
//
//

/**
 * @brief レジスタ情報をパースする。
 *        1レコードについてCSVのパースを行い、
 *        各カラムの解釈方法はアーキテクチャ部に移譲する。 
 * @param file ファイルパス
 * @param 失敗時は偽を返す
 */
ISysRegSet* CSysRegSet::Default() {
	
	const UI32 regNum = 23;
	std::string defTable[regNum] = {
		"0,0,EIPC,SV,0xXXXXXXXX,,0xXXXXXXXX,0x00000000,-,0x00000000,YES,YES,,",
		"0,1,EIPSW,SV,0x00000020,,0x00000020,,-,,YES,YES,,",
		"0,2,FEPC,SV,0xXXXXXXXX,,0xXXXXXXXX,0x00000000,-,0x00000000,YES,YES,,",
		"0,3,FEPSW,SV,0x00000020,,0x00000020,,-,,YES,YES,,",
		"0,5,PSW,BIT,0x00000020,,0x00000020,,-,,YES,YES,,",
		"0,6,FPSR,SV/CU0,,,0xXXXXXXXX,-,-,0x002201C0,YES,,,",
		"0,7,FPEPC,SV/CU0,,,0xXXXXXXXX,-,-,0x00000000,YES,YES,,",
		"0,8,FPST,CU0,,,0xXXXXXXXX,-,-,0x00000000,YES,YES,,",
		"0,9,FPCC,CU0,,,0xXXXXXXXX,-,-,0x00000000,YES,YES,,",
		"0,10,FPCFG,CU0,,,0xXXXXXXXX,-,-,0x00000000,YES,,,",
		"0,11,FPEC,SV/CU0,0xXXXXXXXX,,0xXXXXXXXX,0x00000000,-,0x00000000,YES,YES,,",
		"0,12,SESR,CU1,,,0xXXXXXXXX,-,-,0x00000000,YES,,,",
		"0,13,EIIC,SV,0x00000000,,0x00000000,,-,,YES,YES,,",
		"0,14,FEIC,SV,0x00000000,,0x00000000,,-,,YES,YES,,",
		"0,16,CTPC,,,,0xXXXXXXXX,-,-,0x00000000,YES,YES,,",
		"0,17,CTPSW,,,,0x00000000,-,-,0x00000000,YES,YES,,",
		"0,20,CTBP,,,,0xXXXXXXXX,-,-,0x00000000,YES,YES,,",
		"0,28,EIWR,SV,0xXXXXXXXX,,0xXXXXXXXX,0x00000000,-,0x00000000,YES,YES,,",
		"0,29,FEWR,SV,0xXXXXXXXX,,0xXXXXXXXX,0x00000000,-,0x00000000,YES,YES,,",
		"0,31,BSEL,SV,0x00000000,,,-,-,-,YES,YES,,",
		"1,1,MCFG1,SV,Unknown,Unknown,,,,-,YES,YES,NO,",
		"1,11,SCCFG,SV,0xXXXXXXXX,0xXXXXXXXX,,0x000000ff,0x000000ff,-,YES,YES,,",
		"1,13,HVCCFG,SV,0xXXXXXXXX,0xXXXXXXXX,,0x000000ff,0x000000ff,-,YES,YES,,"
	};
	
	std::stringstream ss;
	for (UI32 i = 0; i < regNum; i++) {
		ss << defTable[i] << std::endl;
	}
	
    std::istreambuf_iterator<char>   sin(ss);
    std::vector<std::string>            rec;

    std::string                      separator(",");
    std::vector<CQuote>              quotes; // Quateなし

	this->Clear();

    while ( CToolFnc::ReadCSV( rec, sin, separator, quotes) ) {
        std::vector<std::string>::iterator i;
        ISysReg* sr = ISysReg::New();
		if (sr->ParseCsvRecord (rec) != true) {
			delete sr;
			return NULL;
		}
		std::pair<std::map<UI32,ISysReg*>::iterator,bool> result; 
		result = m_setSr.insert(std::pair<UI32,ISysReg*>(sr->GetId(), sr));
		if (result.second != true) {
			delete sr;
			return NULL;
		}
    }
    
	return this;
}

/**
 * @brief レジスタ情報をパースする。
 *        1レコードについてCSVのパースを行い、
 *        各カラムの解釈方法はアーキテクチャ部に移譲する。 
 * @param file ファイルパス
 * @param 失敗時は偽を返す
 */
bool CSysRegSet::ParseCsv(std::string file) {
	
	if (file.length()) {
		if (ISysRegSet::ParseCsv(file) != true) {
			return false;
		}
	}else{
		Default();
	}
	MakeList(); 
	return true;
}

/**
 * @brief 読み出し対象となるシステムレジスタのリストを構成します
 */
void CSysRegSet::MakeList() {
	
	m_NLoad.Clear();
	m_NStore.Clear();
	m_VLoad.Clear();
	m_VStore.Clear();
	m_TLoad.Clear();
	m_TStore.Clear();

	std::map<UI32,ISysReg*>::iterator itr;
	for (itr = m_setSr.begin(); itr != m_setSr.end(); itr++) {
		if (itr->second->Loadable()) {
			m_NLoad.Set(itr->first, 10); // ! CTBPなどもNCとして追加する
			if (itr->second->IsVC()) {
				m_VLoad.Set(itr->first, 10);
			}
			if (itr->second->IsTC()) {
				m_TLoad.Set(itr->first, 10);
			}
		}
		if (itr->second->Storable()) {
			m_NStore.Set(itr->first, 10);
			if (itr->second->IsVC()) {
				m_VStore.Set(itr->first, 10);
			}
			if (itr->second->IsTC()) {
				m_TStore.Set(itr->first, 10);
			}
		}
	}
	m_NLoad.ReCalc();
	m_NStore.ReCalc();
	m_VLoad.ReCalc();
	m_VStore.ReCalc();
	m_TLoad.ReCalc();
	m_TStore.ReCalc();
}


/**
 * @brief 読み出しレジスタを選択する。
 * @param flag コンテキスト＆アクセスフラグ
 * @param レジスタインデックス
 */
UI32 CSysRegSet::Select(UI32 flags) {
	
	std::bitset<SRFILTER_NUM> bs(flags);
	
	std::bitset<SRFILTER_NUM> all;
	all.set(CONTEXT_NC);
	all.set(CONTEXT_VC);
	all.set(CONTEXT_TC);
	
	std::bitset<SRFILTER_NUM> nc;
	nc.set(CONTEXT_NC);

	std::bitset<SRFILTER_NUM> vc;
	vc.set(CONTEXT_VC);
		
	std::bitset<SRFILTER_NUM> tc;
	vc.set(CONTEXT_TC);
	
	CWeightedRandom<UI32>* pSource = NULL;
	
	if (bs[CONTEXT_NC]) {
		pSource = bs[LOAD] ? (&m_NLoad) : (&m_NStore);
	}
	if (bs[CONTEXT_VC]) {
		pSource = bs[LOAD] ? (&m_VLoad) : (&m_VStore);
	}
	if (bs[CONTEXT_TC]) {
		pSource = bs[LOAD] ? (&m_TLoad) : (&m_TStore);
	}
	
	_ASSERT(pSource);
	return pSource->GetObj();
}
