#include "ifexception.h"
#include "ifblk_manager.h"
#include "weight_parser.h"
#include "rtg_app.h"

#include "blk_manager.h"
#include "instruction.h"
#include "insid_set.h"
#include "rtg_cfg.h"
#include "sysreg.h"
#include "adr_selector.h"
#include "usr_src.h"


#define	NewINS(_CB_, _INS_)		((_CB_)->AddOpeCode(_INS_))
//#define BRANCH_DEBUG
extern std::shared_ptr<CUserSourceFile>			g_usf;
extern std::shared_ptr<CAssemblerSourceFile>	g_asf;
extern std::shared_ptr<CGeneratorConfig>		g_cfg;
extern CAddressWeight							g_ExceptionAddr;


CBlockManager::CBlockManager(LIST_INSSET* ws)
	: m_pWeightSet(ws),  m_nAsyncCount(0), m_nHandlerReg(0), m_nWorkReg(0), m_bsVector(0x00000000)
{
	CGeneratorProfile::SectionData sd;
	CGeneratorProfile::SectionData::iterator sdi;
	UI32 nMin, nMax;

	m_nrmSet.Clear();

	sd = g_prf->GetSectionData("::INSTRUCTION_GLOBAL");
	if (sd.size() == 0) {
		m_nrmSet.DefaultSet();
		return;
	}

	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		CGeneratorProfile::CsvRow& r = (*sdi);
		nMin = 0; nMax = 0;

		try {
			// 拡張命令に対するパラメータをとる
			// 本来この構想は無かった、、泥臭い処理が対応する。
			if (r.size() == 4 && r[2].length() && r[3].length()) {
				if (r[0] == "Ins_C010_ld_array") {
					m_nrmSet.m_ldArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C011_st_array") {
					m_nrmSet.m_stArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C012_ls_array") {
					m_nrmSet.m_lsArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C013_sld_array") {
					m_nrmSet.m_sldArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C014_sst_array") {
					m_nrmSet.m_sstArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C015_sls_array") {
					m_nrmSet.m_slsArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else
				if (r[0] == "Ins_C016_caxi_array") {
					m_nrmSet.m_caxiArrayNum = std::pair<UI32,UI32>(CToolFnc::AtoI(r[2].c_str()),  CToolFnc::AtoI(r[3].c_str()));
				}else{
					nMin = CToolFnc::AtoI(r[2].c_str());
					nMax = CToolFnc::AtoI(r[3].c_str());
					//MSG_INFO (0, "Format error ::INSTRUCTION_GLOBAL has too many parameters. %s may be extended ins.\n", r[0].c_str() );
				}
			}else if (r.size() == 2){
				nMin = 1;
				nMax = 1;
			}else {
				// Format error
				MSG_INFO (0, "Format error ::INSTRUCTION_GLOBAL has too many parameters. %s may be extended ins.\n", r[0].c_str() );
				continue;
			}
			
			nMin = (nMin == 0 ? 1 : nMin);
			nMin = (nMin > 64 ? 64 : nMin);
			nMax = (nMax > 64 ? 64 : nMax);
			if(nMin > nMax)
				nMax = nMin;
			std::string key = r[0];
			UI32 w = CToolFnc::AtoI(r[1].c_str());
			if (w) {
				UI32 id = m_nrmSet.SetWeight(key, w);
				if(id){
					std::pair<UI32, UI32> p = std::pair<UI32, UI32> (nMin, nMax);
					m_nrmSet.m_seqInsNum.insert(std::pair<UI32, std::pair<UI32, UI32>>(id, p));
				}
			}
		}catch (std::exception e) {
			MSG_INFO (0, "Format error ::INSTRUCTION_GLOBAL Custom instruction parameters are invalid.\n" );
		}
	}
	m_nrmSet.ReCalc();

	std::vector<std::pair<std::string,UI32>> vUcRndKey;
	const UI32 UC_ID_BASE = MAX_INS_ID + 1;
	UI32 nIdx = UC_ID_BASE;

	g_usf->GetRndKey(vUcRndKey);
	std::vector<std::pair<std::string,UI32>>::iterator itrUc;
	for(itrUc = vUcRndKey.begin(); itrUc != vUcRndKey.end(); itrUc++){
		m_nrmSet.SetWeight(nIdx, itrUc->second);
		nIdx++;
	}
	nIdx = UC_ID_BASE + g_usf->GetUserCodeNum();
	std::map< UI32,IExceptionConfig*>& vExp = g_exp->GetException();
	std::map<UI32, IExceptionConfig*>::iterator itrExp;
	UI32 nBankNum = 0;
	for(itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
		IExceptionConfig* pExpConfig = itrExp->second;
		if(pExpConfig->m_bIsInterrupt && pExpConfig->m_weight != 0) {
			m_nrmSet.SetWeight(nIdx, pExpConfig->m_weight);
			if (pExpConfig->m_name == "RBINT") {
				nBankNum = pExpConfig->m_bankNum;
				if ((nBankNum < 0) || (nBankNum > 16)) {
					MSG_WARN(0, "Register Bank number can not exceed 16");	
				}
			}
		}
		nIdx++;
	}
}

/* @brief  generate pe_check。
 * @return Vector of vectorblock
 */
std::vector<CVectorBlock*>* CBlockManager::GeneratePECheck(TBlockConfig* pCfg) {
	UI32	reg = (m_nHandlerReg == 0) ? g_rnd.GetRange(4,29) : m_nHandlerReg;
	m_nHandlerReg = reg;
	IInstruction * ins ;
	std::vector<CVectorBlock*>* vNode = new std::vector<CVectorBlock*>();
	CVectorBlock* pVB;
	//std::string &frog_pe = CLabel::m_prefix;
	
	std::string contextStr = GetMContext(pCfg);
	UI32 reg2 = g_rnd.GetRange(4,29);
	while(reg2 == reg) {
		reg2 = g_rnd.GetRange(4,29);
	}
	pVB = new CBootBlock (); // ! -> 2 param constructor does not work well....
	pVB-> SetAddress(ADR_VECTOR_RESET);
	pVB-> SetLabel("_pe_reset");

	NewINS( pVB, MOV32P(contextStr + "sync_mem_init", reg) );
	NewINS(pVB, JARL32(reg, 31) );
	NewINS( pVB, MOV32P("_pe_check", reg) );
	NewINS( pVB, JMP32(reg) );
	vNode->push_back(pVB);

	pVB = new CBootBlock ();  // ! -> 2 param constructor does not work well....
	pVB-> SetAddress(0x200);
	pVB-> SetLabel("_pe_check");
	NewINS( pVB, MOV32(0x00008020, reg) );
	NewINS( pVB, LDSR(reg, 5, 0) );

	UI32 addr;

	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;
	NewINS( pVB, MOV32(addr, reg) );
	NewINS( pVB, MOV5 (1, reg2) );
	NewINS( pVB, ins = STB16 (reg2, 0, reg) );
	ins->AppendComment("disable SyncPe") ;

	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_SKIP_PE_COMPLETE;
	NewINS( pVB, MOV32(addr, reg) );
	NewINS( pVB, MOV5 (1, reg2) );
	NewINS( pVB, ins = STB16 (reg2, 0, reg) );
	ins->AppendComment("disable WaitCompletePe") ;

	//GMEBASE
    pCfg->m_bNC = false;
    std::string contextGMStr = GetMContext(pCfg);
    pCfg->m_bNC = true;
    NewINS( pVB, MOV32P(contextGMStr + "vector_reset", reg));
	NewINS( pVB, LDSR(reg, 19, 9)->Note("->GMEBASE") );

	NewINS( pVB, MOV32P("NM_vector_reset", reg) ); // TODO:
	NewINS( pVB, LDSR(reg, 3, 1) );
	NewINS( pVB, JMP32(reg) );
	vNode->push_back(pVB);

	return vNode;
	}


std::vector<CVectorBlock*>* CBlockManager::GenerateIntVector(TBlockConfig* pCfg)
{
	UI32	reg = (m_nHandlerReg == 0) ? g_rnd.GetRange(4,29) : m_nHandlerReg;
	m_nHandlerReg = reg;

	std::vector<CVectorBlock*>* vNode = new std::vector<CVectorBlock*>();
	CVectorBlock* pVB;
	std::string &frog_pe = CLabel::m_prefix;
	
	std::string contextStr = GetMContext(pCfg);
	bool isNC	= pCfg->m_bNC;
    UI32 gap_code = 0;

	// Update vector handler bit set ony enable vector handler will be executed 
	std::map< UI32,IExceptionConfig*>& vExp = g_exp->GetException();
	std::map<UI32, IExceptionConfig*>::iterator itrExp;
	UI32 i = 0;
	//Can not control exception. Occurence base on CPU status
	m_bsVector[BSV_VECTOR_RESET] = 1;
	m_bsVector[BSV_VECTOR_FPPFPI] = 1;
	m_bsVector[BSV_VECTOR_PIE] = 1;
	m_bsVector[BSV_VECTOR_RIE] = 1;

    // Calculate gap for reset vetor
    auto CalculateBlockGap = [](BS_VECTOR bsv, BS_VECTOR bsvUser, UI32 pos) -> UI32 {
        UI32 blockgap = 0;
        pos = pos + 1; //Next vector handler

        while (bsv[pos] == 0 && bsvUser[pos] == 0) {
            if (pos == BSV_VECTOR_NUM)
                break;
            blockgap = blockgap + 16;
            pos++;
        }
        return blockgap;
    };

	for(itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
		IExceptionConfig* pExpConfig = itrExp->second;

		if(pExpConfig->m_weight > 0 ){
			if (pExpConfig->m_name == "SYSERR" || pExpConfig->m_name == "RBINT" || m_nrmSet.GetWeight(INS_ID_RESBANK))
				m_bsVector[BSV_VECTOR_SYSERR] = 1;

			if (pExpConfig->m_name == "HVTRAP" ||  m_nrmSet.GetWeight(INS_ID_HVTRAP) || m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV)) 
				m_bsVector[BSV_VECTOR_HVTRAP] = 1;

			if (pExpConfig->m_name == "FETRAP" ||  m_nrmSet.GetWeight(INS_ID_FETRAP) || m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV)) 
				m_bsVector[BSV_VECTOR_FETRAP] = 1;

			if (pExpConfig->m_name == "TRAP0" ||  m_nrmSet.GetWeight(INS_ID_TRAP) || m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV)) 
				m_bsVector[BSV_VECTOR_TRAP0] = 1;

			if (pExpConfig->m_name == "TRAP1" ||  m_nrmSet.GetWeight(INS_ID_TRAP) || m_nrmSet.GetWeight(INS_CID_CHANGE_PRIV))  
				m_bsVector[BSV_VECTOR_TRAP1] = 1;	

			if (pExpConfig->m_level == IExceptionConfig::EXP_LEVEL_DB || m_nrmSet.GetWeight(INS_ID_DBT))
				m_bsVector[BSV_VECTOR_DEBUG] = 1;

			if (pExpConfig->m_name.find("UCPOP") != std::string::npos)
				m_bsVector[BSV_VECTOR_UCPOP] = 1;

			if (pExpConfig->m_name == "MIP" || pExpConfig->m_name == "MDP") 
				m_bsVector[BSV_VECTOR_MPUMMU] = 1;

			if (pExpConfig->m_name == "MAE"){ 
				m_bsVector[BSV_VECTOR_MAE] = 1;
			}

			if (pExpConfig->m_name == "BGINT"){ 
				m_bsVector[ADR_VECTOR_BGINT] = 1;
			}

			if (pExpConfig->m_name == "FEINT") 
				m_bsVector[BSV_VECTOR_FEINT] = 1;

			if (pExpConfig->m_name == "FENMI") 
				m_bsVector[BSV_VECTOR_FENMI] = 1;

			if (pExpConfig->m_name == "EIINT" || pExpConfig->m_name == "GMEIINT" || pExpConfig->m_name == "RBINT" || pExpConfig->m_name == "GMRBINT"){
				m_bsVector[BSV_VECTOR_EIINT000] = 1;
				for(UI32 priority = 0; priority <= 15; priority++){
					m_bsVector[(BSV_VECTOR_EIINT000 + 1 + priority)] = 1;
				}
			}
		}
		i++;
	}

	std::bitset<BSV_VECTOR_NUM> bsvUser(0x0);
	GetUserHandler(frog_pe + contextStr, &bsvUser);
	
	if (m_bsVector[BSV_VECTOR_RESET]) {
		pVB = new CVectorBlock(contextStr + "vector_reset");
		pVB->SetOutputFlag(true);
		pVB->SetAlign(512);
        gap_code = CalculateBlockGap(m_bsVector, bsvUser, BSV_VECTOR_RESET);
        pVB->SetBlockGap(16 + gap_code);

		if (isNC) {
			NewINS( pVB, MOV32P( contextStr + "preload", reg) );
			NewINS( pVB, JMP32(reg) );
		}else{
			//TODO VMはプリロードなし
			NewINS( pVB, NOP() );
			NewINS( pVB, NOP() );
		}

		vNode->push_back(pVB);
	}
	std::vector<CVectorBlock*>* vVecBlock = GenerateVectorBlock(pCfg, "");
	VectorPtr 		v_ptr  (vVecBlock);
	frog::for_each( v_ptr, [&vNode] (CVectorBlock* p) {vNode->push_back(p);} );

	return vNode;
}


std::vector<CVectorBlock*>* CBlockManager::GenerateVectorBlock(TBlockConfig* pCfg, std::string label_num)
{
	UI32	reg = (m_nHandlerReg == 0) ? g_rnd.GetRange(4,29) : m_nHandlerReg;
	m_nHandlerReg = reg;
	if(label_num.size() > 0)
		label_num = "_" + label_num;

	std::vector<CVectorBlock*>* vNode = new std::vector<CVectorBlock*>();
	BS_VECTOR bsv = m_bsVector;
	CVectorBlock* pVB;
	std::string &frog_pe = CLabel::m_prefix;	
	std::string contextStr = GetMContext(pCfg);
	UI32 vectorHandler_size = 0;
	
	// Calculate vector handler block size
	auto CalculateBlockSize = [](BS_VECTOR bsv, BS_VECTOR bsvUser, UI32 pos) -> UI32 {
		UI32 blocksize = 10;
		pos = pos + 1; //Next vector handler
		
		while(bsv[pos] == 0 && bsvUser[pos] == 0){
			if(pos == BSV_VECTOR_NUM)
				break;
			blocksize = blocksize + 16;
			pos++;
		}
		return blocksize;
	};
	
	std::bitset<BSV_VECTOR_NUM> bsvUser(0x0);
	GetUserHandler(frog_pe + contextStr, &bsvUser);
	if (bsv[BSV_VECTOR_SYSERR]) {
		pVB = new CVectorBlock( contextStr + ("vector_syserr") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_SYSERR);	
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_SYSERR);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "syserr");			
		vNode->push_back(pVB);		
	}

	if (bsv[BSV_VECTOR_HVTRAP]) {
		pVB = new CVectorBlock( contextStr + ("vector_hvtrap") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_HVTRAP);
		pVB->SetHandlerType(0, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_HVTRAP);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "hvtrap");		
		vNode->push_back(pVB);		
	}

	if (bsv[BSV_VECTOR_FETRAP]) {
		pVB = new CVectorBlock( contextStr + ("vector_fetrap") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_FETRAP);
		pVB->SetHandlerType(0, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_FETRAP);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "fetrap");				
		vNode->push_back(pVB);		
	}

	if (bsv[BSV_VECTOR_TRAP0]) {
		pVB = new CVectorBlock( contextStr + ("vector_trap0") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_TRAP0);
		pVB->SetHandlerType(0, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_TRAP0);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "trap0");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_TRAP1]) {
		pVB = new CVectorBlock( contextStr + ("vector_trap1") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_TRAP1);
		pVB->SetHandlerType(0, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_TRAP1);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "trap1");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_RIE]) {
		pVB = new CVectorBlock( contextStr + ("vector_rie") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_RIE);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_RIE);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "rie");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_FPPFPI]) {
		pVB = new CVectorBlock( contextStr + ("vector_fpe") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_FPPFPI);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_FPPFPI);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "fppfpi");		
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_UCPOP]) {
		pVB = new CVectorBlock( contextStr + ("vector_ucpop") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_UCPOP);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_UCPOP);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "ucpop");
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_MPUMMU]) {
		pVB = new CVectorBlock( contextStr + ("vector_mp") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_MPUMMU);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_MPUMMU);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "mp");
		pVB->EnableRegulation(true);	
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_PIE] ) {
		pVB = new CVectorBlock( contextStr + ("vector_pie") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_PIE);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_PIE);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "pie");
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_DEBUG]) {
		pVB = new CVectorBlock( contextStr + ("vector_debug") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_DEBUG);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_DB);
        vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_DEBUG);
        pVB->SetBlockGap(vectorHandler_size + 6);
		if( g_exp->GetBreakPointWeight()){
			NewINS( pVB, LDSR(m_nHandlerReg, 30, 3) );								// DBWR= r3
			NewINS( pVB, MOV32P("debug_handler", reg) );			
			NewINS( pVB, JMP32(reg) );
		} else{
			GenerateRandomCode(pVB, vectorHandler_size-4, g_cfg->m_nINumInBlock, pCfg, contextStr + "debug");					
		}		
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_MAE]) {
		pVB = new CVectorBlock( contextStr + ("vector_mae") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_MAE);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_MAE);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "mae");
		vNode->push_back(pVB);
	}

	if (bsv[ADR_VECTOR_BGINT]) {
		pVB = new CVectorBlock( contextStr + ("vector_dummy") + label_num);
		if(bsvUser[ADR_VECTOR_BGINT]){
			GetUserHanlderBody(frog_pe + contextStr + "vector_dummy", pVB);
		} else{
			NewINS( pVB,  JR22P( contextStr + "vector_dummy"));
			NewINS( pVB, NOP() );
		}
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_FENMI] ) {
		pVB = new CVectorBlock( contextStr + ("vector_fenmi") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_FENMI);	
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE); // Re-execute type
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_FENMI);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "fenmi");			
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_FEINT] ) {
		pVB = new CVectorBlock( contextStr + ("vector_feint") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_FEINT);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_FE);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_FEINT);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "feint");	
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT000]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint000") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT000);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT000);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint0");		
		vNode->push_back(pVB);
	}

	if (bsv[BSV_VECTOR_EIINT001]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint001") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT001);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT001);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint1");	
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT002]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint002") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT002);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT002);
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint2");		
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT003] ) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint003") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT003);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT003);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint3");		
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT004]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint004") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT004);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT004);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint4");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT005]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint005") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT005);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT005);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint5");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT006]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint006") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT006);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT006);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint6");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT007]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint007") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT007);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT007);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint7");		
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT008]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint008") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT008);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT008);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint8");	
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT009] ) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint009") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT009);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT009);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint9");	
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT010]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint010") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT010);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT010);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint10");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT011]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint011") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT011);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT011);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint11");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT012]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint012") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT012);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT012);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint12");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT013]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint013") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT013);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT013);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint13");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT014]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint014") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT014);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT014);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint14");
		vNode->push_back(pVB);
	}
	
	if (bsv[BSV_VECTOR_EIINT015]) {
		pVB = new CVectorBlock( contextStr + ("vector_eiint015") + label_num);
		pVB->SetHandlerAddress(ADR_VECTOR_EIINT015);
		pVB->SetHandlerType(1, CVectorBlock::EXP_LEVEL_EI);
		vectorHandler_size = CalculateBlockSize(bsv, bsvUser, BSV_VECTOR_EIINT015);	
        pVB->SetBlockGap(vectorHandler_size + 6);
		GenerateRandomCode(pVB, vectorHandler_size, g_cfg->m_nINumInBlock, pCfg, contextStr + "eiint15");
		vNode->push_back(pVB);
	}

	for(UI32 i = 0; i < vNode->size(); i++) {
		CVectorBlock * p = static_cast<CVectorBlock*> (vNode->at(i));
		p->EnableRegulation(true);
		if(p->GetHandlerAddress() == ADR_VECTOR_DEBUG && g_exp->GetBreakPointWeight() > 0)
			p->EnableRegulation(false);
	}
	
	return vNode;
}


std::vector<CPreloadBlock*>* CBlockManager::GeneratePreload(TBlockConfig* pCfg) {

	FROG_ASSERT(pCfg);

	std::vector<CPreloadBlock*>* vNode = new std::vector<CPreloadBlock*>();
	std::string contextStr = GetMContext(pCfg);
	bool bSrInit = (pCfg->m_pSrSet != NULL);
	bool bVrInit = false;
	
	// ------------------------------------------------------------------------
	// Main block of "__preload"
	// ------------------------------------------------------------------------
	UI32 reg = g_rnd.GetRange((UI32)4,(UI32)30);
	CPreloadBlock* pPB = new CPreloadBlock( contextStr + "preload");
	
	// 暫定
	if ( CU1isON() ) {
		SwitchCoProcessor(pPB,10,3); // CU0=On, CU1=On
	}else{
		SwitchCoProcessor(pPB,10,1); // CU0=On, CU1=Off
	}
	NewINS(pPB, NOP() );
	NewINS(pPB, NOP() );

	//
	// Frogの仕様上、命令配置アドレスが制御に影響するような命令列は対応していない。
	// --------------------------------------------------------------------------------------------------
	// CTBP, HVCBP, SCBP の値は命令配置であるためこれらのレジスタを読み出す場合には仕組みが必要。
	// (EIPC, FEPC, RBASE ....) 
	//
	//   案1) 読み出しても良いが値が処理に依存しないようにする　→　何かの命令で読み出した汎用レジスタの値を潰す
	//   案2) アドレスが動かないところに配置しておく・・・
	//   案3) システムレジスタの読み出しに制限を書ける（現状はこれ。設定ファイル（つまりユーザー）が制限をかける） 
	//
	// - 初期化コードそのものはシミュレーション実行後に挿入される
	NewINS(pPB, MOV32P( contextStr + "memory_init", 20) );
	NewINS(pPB, JARL32(20, 31) );
	NewINS(pPB, NOP() );
	// - "callt_init"のコードブロックにジャンプすることで
	// CALLTエントリが初期化される（sim_ctrl:: BlockSimulation Nativeデータ展開で処理している）
	NewINS(pPB, MOV32P( contextStr + "callt_init_00", 20) );
	NewINS(pPB, JARL32(20, 31) );
	NewINS(pPB, NOP() );
	
	// - 初期化コードそのものはシミュレーション実行後に挿入される
	NewINS(pPB, MOV32P(contextStr + "stack_entry_init", 20));
	NewINS(pPB, JARL32(20, 31));
	NewINS(pPB, NOP() );

	// VR Init entry
	if (bVrInit) {
		// TC#0-N:VR
		NewINS(pPB, MOVR(0, 20) );										// r20   <= 0;
		if(g_hwInfo.m_htnum <= 0xF)
			NewINS(pPB, MOV5(g_hwInfo.m_htnum, 21) );
		else
			NewINS(pPB, MOV32(g_hwInfo.m_htnum, 21) );						// r21   <= HTNUM;
		NewINS(pPB, LDSR(20, 10, 1)->SetLabel(contextStr + "vr_init_tcsel"));	// TCSEL <= r20 ::__gr_init_tcsel
		NewINS(pPB, JARL22P( contextStr + "vr_init",31) );				// call __vr_init
		NewINS(pPB, ADD5(1, 20) );										// r20   <= (r20 + 1)
		NewINS(pPB, CMPR(21, 20) );										// CMP "tcsel" with r20
		NewINS(pPB, BNE17P( contextStr + "vr_init_tcsel"));				// break loop
		NewINS(pPB, NOP() );
		NewINS(pPB, NOP() );
	}
	
	// SR Init entry
	if (bSrInit) {
		NewINS(pPB, MOV32P(contextStr + "sr_nc_init", 20));
		NewINS(pPB, JARL32(20, 31));
		//NewINS(pPB, JARL22P( contextStr + "sr_nc_init", 31) );
		NewINS(pPB, NOP() );
		NewINS(pPB, NOP() );
		if (g_hwInfo.m_vmnum > 0) {
			NewINS(pPB, MOVR(0, 20) );								    // r20   <= 0;
			NewINS(pPB, LDSR(20, 15, 1)->Note("NC:VCSEL")->SetLabel(contextStr + "sr_vc_init_vcsel"));	// TCSEL <= r20 ::__gr_init_tcsel
			NewINS(pPB, JARL22P(contextStr + "sr_vc_init",31) );
			NewINS(pPB, ADD5(1, 20) );									// r20   <= (r20 + 1)
			NewINS(pPB, CMP5(g_hwInfo.m_vmnum, 20) );                   // CMP "tcsel" with r20
			NewINS(pPB, BNE17P( contextStr + "sr_vc_init_vcsel") );     // break loop
			NewINS(pPB, NOP() );
			NewINS(pPB, NOP() );
		}
		
		if (g_hwInfo.m_vmnum /* htnumでなくvmnum */ > 0) {
			// vmnumが1以上で仮想化機能が有効になる -> NTとHT0を区別する 
			NewINS(pPB, MOVR(0, 20) );								    // r20   <= 0;
			if(g_hwInfo.m_htnum <= 0xF)
				NewINS(pPB, MOV5(g_hwInfo.m_htnum, 21) );
			else
				NewINS(pPB, MOV32(g_hwInfo.m_htnum, 21) );					// r21   <= HTNUM;
			NewINS(pPB, LDSR(20, 10, 1)->Note("TCSEL")->SetLabel( contextStr + "sr_tc_init_tcsel"));	// TCSEL <= r20 ::__gr_init_tcsel
			NewINS(pPB, JARL22P( contextStr + "sr_tc_init", 31) );
			NewINS(pPB, ADD5(1, 20) );									// r20   <= (r20 + 1)
			NewINS(pPB, CMPR(21, 20) );                                 // CMP "tcsel" with r20
			NewINS(pPB, BNE17P( contextStr + "sr_tc_init_tcsel") );     // break loop
			NewINS(pPB, NOP() );
			NewINS(pPB, NOP() );
		}
	}


	//Interrupt init
	UI32 max_channel = this->GetMaxChannelInterrupt(g_exp->GetException());
	if (max_channel){
		NewINS(pPB, MOV32P("_interrupt_eitbl_init", 11));
		NewINS(pPB, LDSR(11, 4, 1)); //INTBP

		//GMINTBP
		NewINS( pPB, MOV32P("_GM_interrupt_eitbl_init", 11) );
		NewINS( pPB, LDSR(11, 20, 9)->Note("->GMEBASE") );

	}

	//syscall_init
	if (m_nrmSet.GetWeight(INS_ID_SYSCALL) > 0) {
		NewINS(pPB, MOV32P("_syscall_init", 11));
		NewINS(pPB, LDSR(11, 12, 1)); // SCBP
	}

	// Goto Next block => __prologue
	NewINS( pPB, MOV32P(contextStr + "prologue", reg) );
	NewINS( pPB, JMP32(reg) );
	vNode->push_back(pPB);
	
	// ------------------------------------------------------------------------
	// Sub block of "__preload"
	// ------------------------------------------------------------------------
	//! VREG INIT
	if (bVrInit) {
		pPB = new CPreloadBlock(contextStr + "vr_init");
		InitLdtcVR( pPB );
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);
	}
	
		
	//! SR INIT
	if (bSrInit) {
			
		std::map<UI32,ISysReg*> list = pCfg->m_pSrSet->GetInitalList();
//		pCfg->m_pSrSet->Dump() ;

		pPB = new CPreloadBlock(contextStr + "sr_nc_init");
		InitNcSR(pPB, &list);
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);

		//pPB = new CPreloadBlock(contextStr + "sr_vc_init");
		//InitVcSR(pPB, &list);
		//NewINS( pPB, JMP32(31) ); // return code
		//vNode->push_back(pPB);
		
		pPB = new CPreloadBlock(contextStr + "sr_tc_init");
		InitTcSR(pPB, &list);
		NewINS( pPB, JMP32(31) ); // return code
		vNode->push_back(pPB);
	}
	
	{
		//! STACK ENTRY INIT
		pPB = new CPreloadBlock(contextStr + "stack_entry_init");
		InitStackEntry(pPB , 5, 6);
		NewINS(pPB, JMP32(31) ); // return code
		NewINS(pPB, NOP() );
		NewINS(pPB, NOP() );
		vNode->push_back(pPB);
	}

	//! Memory INIT
	pPB = new CPreloadBlock(contextStr + "memory_init");
	NewINS( pPB, JMP32(31) ); // return code
	/* <Initialise code will be generated here> */
	NewINS (pPB, NOP()->SetLabel("NMNT_wr_preset_memory_1"));
	vNode->push_back(pPB);
	
	// Synchronization flag INIT
	pPB = new CPreloadBlock(contextStr + "sync_mem_init");
	NewINS( pPB, JMP32(31) );
	pPB->SetBlockGap(0xC8); // Maximum 200 byte for preset Share mem.  
	vNode->push_back(pPB);
	
	// Interrupt init codeblock
	if (max_channel != 0){
		pPB = new CPreloadBlock("_interrupt_eitbl_init");
		pPB->SetOutputFlag();
		pPB->SetAlign(512);
		pPB->SetSize(max_channel * 4);
		vNode->push_back(pPB);

		//GMINTBP
		pPB = new CPreloadBlock("_GM_interrupt_eitbl_init");
		pPB->SetOutputFlag();
		pPB->SetAlign(512);
		pPB->SetSize(max_channel * 4);
		vNode->push_back(pPB);

	}

	// Syscall init codeblock
	if (m_nrmSet.GetWeight(INS_ID_SYSCALL) > 0) {
		pPB = new CPreloadBlock("_syscall_init");
		pPB->SetOutputFlag();
		pPB->SetAlign(2);
		pPB->SetSize(MAX_ENTRY_SYSCALL * 4);
		vNode->push_back(pPB);
	}

	//CALLT INIT
	// callt routine
	if(m_nrmSet.GetWeight(INS_ID_CALLT) > 0){
		pPB = GenerateCalltBlock(pCfg, "00");
	}else {
		pPB = new CPreloadBlock(contextStr + "callt_init_00");
	}
	IInstruction* jmpCallt = JMP32(31);
	jmpCallt->AppendComment("Jump return");
	pPB->AddOpeCode(jmpCallt, 0); // Expand native-data and return!
	if(m_nrmSet.GetWeight(INS_ID_CALLT) == 0) {
		std::string cstrM = "COMMON_callt_00";
		pPB->at(0)->SetLabel(cstrM);
	}

	pPB->SetBreakSetupInsFlag(false);
	vNode->push_back(pPB);

	return vNode;
};



/**
 * @brief  メモリ初期化コードを生成します。
 * @param  メモリ初期化情報
 */
CPreloadBlock * CBlockManager::AppendMemPresetBlock(std::vector<T_MEMWRRECORD > * recode) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
	MSG_INFO(0, "================================= Preset memory ======================================\n");
#endif
	auto GetWRPresetMem = [] (std::vector<T_MEMWRRECORD> *mpd, std::vector<T_MEMWRRECORD> *mpd_wr) {
		std::vector<T_MEMWRRECORD>::iterator itr;
		itr = mpd->begin();
		while(itr != mpd->end()){
			UI32 addr = itr->first;
			if(addr >= g_wm.BASE_WR_PRESET && addr <= g_wm.BASE_WORK_END) {
				std::pair<UI32, UI64> r = std::pair<UI32, UI64> (itr->second.first, itr->second.second);
				mpd_wr->push_back(T_MEMWRRECORD(itr->first, r));
				itr = mpd->erase(itr);
			} else {
				itr++;
			}
		}
	};

	TBlockConfig cfg;
	cfg.m_bNC = true;
	std::string contextStr = GetMContext(&cfg);
	std::vector<T_MEMWRRECORD> mpd_wr;
	GetWRPresetMem(recode, &mpd_wr);


	// Memory INIT
	CPreloadBlock* pPB = new CPreloadBlock(contextStr + "memory_init");
	UI32 reg= 10 ;
	UI32 memreg= 11 ;
	UI32 imm ;
	std::vector<T_MEMWRRECORD >::iterator  itr;
#if 0
	char str[80] ;
	IInstruction * ins ;
	for (itr = recode->begin(); itr != recode->end(); itr++) {
#if defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
				std::cout	<< "Info : "
							<< "Preset Memory: address=0x" << std::setw(8)  << std::right << std::setfill('0') << std::hex << itr->first 
							<< " size=0x"                  << itr->second.first
							<< " data=0x"                  << std::setw(16) << std::right << std::setfill('0') << std::hex << itr->second.second 
							<< std::endl;
#endif
		UI32 size= itr->second.first ;
		if ((size == 0)||(size > 8)) { continue ; }

		// ROM領域に対するプリロード処理（命令でかけないため.WORDで処理する）
		UI32 adr= itr->first ;
		UI64 val=itr->second.second;
		UI32 disp= 0 ;
		if (g_prf->IsInSconst(adr)) {
			continue;
		}
		// <-
		if(g_LoadableAddr.GetMirror(adr) == true || g_StorableAddr.GetMirror(adr) == true || g_RmwAddr.GetMirror(adr) == true)
			continue;
		NewINS( pPB,  ins= MOV32( adr , memreg ) );
		sprintf(str ,"0x%08x: 0x%016llx size_%d" ,adr ,val ,size ) ;
		ins->AppendComment((LPCTSTR)str) ;

		while (size >= 4) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STW16( reg , disp , memreg) );
			disp += 4 ;
			size -= 4 ;
			val >>= 32 ;
		}		
		if (size >= 2) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STH16( reg , disp , memreg) );
			disp += 2 ;
			size -= 2 ;
			val >>= 16 ;
		}		
		if (size != 0) {
			imm= (UI32)val;
			if(imm <= 0xF)
				NewINS(pPB, MOV5( imm , reg ) );
			else
				NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STB16( reg , disp , memreg) );
		}
	}

	if(mpd_wr.size() > 0) {
		NewINS(pPB, MOV32P("NMNT_wr_preset_memory_0",11));
		NewINS(pPB, JMP32(11));
		NewINS(pPB, NOP()->SetLabel("NMNT_wr_preset_memory_0_ret"));
	}
#endif

	NewINS( pPB, JMP32(31) ); // return code

	// Insert memory preset to preset WR Register
	UI32 nBlockCount = 0;
	for (itr = mpd_wr.begin(); itr != mpd_wr.end(); itr++) {
		UI32 adr = itr->first ;
		UI64 val = itr->second.second;

		if(adr == g_wm.BASE_WR_PRESET || itr == mpd_wr.begin()) {
			if(nBlockCount > 1) {
				std::stringstream ss;
				std::string label;
				ss << "NMNT_wr_preset_memory_" << (nBlockCount - 1);
				ss << "_ret";
				ss >> label;
				NewINS(pPB, MOV32P(label,11));
				NewINS(pPB, JMP32(11));
			}
			if(nBlockCount > 0) {
				std::stringstream ss1;
				std::string label;
				ss1 << "NMNT_wr_preset_memory_" << nBlockCount;
				ss1 >> label;
				imm = (UI32)val;
				NewINS( pPB,  MOV32( adr , memreg)->SetLabel(label));
				NewINS( pPB,  MOV32( imm , reg));
				NewINS( pPB,  STW16( reg , 0 , memreg));
			}
			nBlockCount++;

		} else if(nBlockCount > 1){
			imm = (UI32)val;
			NewINS( pPB,  MOV32( adr , memreg));
			NewINS( pPB,  MOV32( imm , reg));
			NewINS( pPB,  STW16( reg , 0 , memreg));
		}
	}
	if(nBlockCount > 1) {
		std::stringstream ss;
		std::string label;
		ss << "NMNT_wr_preset_memory_" << nBlockCount - 1;
		ss << "_ret";
		ss >> label;
		NewINS(pPB, MOV32P(label,11));
		NewINS(pPB, JMP32(11));
	}
	pPB->Update();
	if (pPB->GetInstructionNum() == 1) // JMP return
		return (pPB) ;

	// Re allocate position of this code block.
	UI32 AddSize = pPB->GetCodeSize() + pPB->GetBlockGap();
	UI32 Align = 0;
	MEMADDR ValidMem = g_asf->GetLinker()->GetAvailableMemory(AddSize, Align, false);

	if (ValidMem > 0) {
		//Remove current address.
		g_asf->GetLinker()->Remove(pPB->GetAddress());
		pPB->SetAddress(ValidMem);
		pPB->Update();
		//pPB->Dump(std::cout);
		g_asf->GetLinker()->Alloc(pPB->GetAddress(), AddSize);
	} else {
		std::cout << "Can not replace Add of " <<pPB->GetLabel()<< std::endl;
	}

	return (pPB) ;
}

CPreloadBlock * CBlockManager::AppendShareMemPreset(std::vector<T_MEMWRRECORD > * recode)
{
	TBlockConfig cfg;
	cfg.m_bNC = true;
	std::string contextStr = GetMContext(&cfg);

	// Memory INIT
	CPreloadBlock* pPB = new CPreloadBlock(contextStr + "sync_mem_init");
	char str[80] ;
	IInstruction * ins ;
	UI32 reg= 10 ;
	UI32 memreg= 11 ;
	UI32 imm ;
	std::vector<T_MEMWRRECORD >::iterator  itr;	
	for (itr = recode->begin(); itr != recode->end(); itr++) {
		UI32 size= itr->second.first ;
		if ((size == 0)||(size > 8)) { continue ; }

		// ROM領域に対するプリロード処理（命令でかけないため.WORDで処理する）
		UI32 adr= itr->first ;
		UI64 val=itr->second.second;
		UI32 disp= 0 ;
		if (g_prf->IsInSconst(adr)) {
			continue;
		}
		// <-
		
		NewINS( pPB,  ins= MOV32( adr , memreg ) );
		sprintf(str ,"0x%08x: 0x%016llx size_%d" ,adr ,val ,size ) ;
		ins->AppendComment((LPCTSTR)str) ;

		while (size >= 4) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STW16( reg , disp , memreg) );
			disp += 4 ;
			size -= 4 ;
			val >>= 32 ;
		}		
		if (size >= 2) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STH16( reg , disp , memreg) );
			disp += 2 ;
			size -= 2 ;
			val >>= 16 ;
		}		
		if (size != 0) {
			imm= (UI32)val;
			NewINS( pPB,  MOV32( imm , reg ) );
			NewINS( pPB,  STB16( reg , disp , memreg) );
		}
	}
	NewINS( pPB, JMP32(31) ); // return code

	pPB->Update();

	// Re allocate position of this code block.
	UI32 AddSize = pPB->GetCodeSize() + pPB->GetBlockGap();
	UI32 Align = 0;
	MEMADDR ValidMem = g_asf->GetLinker()->GetAvailableMemory(AddSize, Align, false);

	if (ValidMem > 0) {
		//Remove current address.
		g_asf->GetLinker()->Remove(pPB->GetAddress());
		pPB->SetAddress(ValidMem);
		pPB->Update();
		//pPB->Dump(std::cout);
		g_asf->GetLinker()->Alloc(pPB->GetAddress(), AddSize);
	} else {
		std::cout << "Can not replace Add of " <<pPB->GetLabel()<< std::endl;
	}

	return pPB;
}


CCodeBlock*	CBlockManager::InitGR(CCodeBlock* pCB) {
	
	FROG_ASSERT(pCB);

	for (UI32 i = 1; i < 31; i++) {
		NewINS( pCB, RANDGR(i) );
	}
	return pCB;
}

CCodeBlock*	CBlockManager::InitWR(CCodeBlock* pCB) {
	
	FROG_ASSERT(pCB);

	UI32 reg1 = 1; // Intermediate address to initialize WR
	UI32 addr = g_wm.BASE_WR_INIT;
	ISimulator* pSim = g_sim->GetISimulator();

	//variable using for store preset data for WR
	IRandom* pRand = new CMersenneTwister();
	UI32 PrsVal = 0;
	const UI32 PSIZE = 4;		//Memory size to preset: 4

	if ( CU1isON() ) {

		// -- Reading core type information ---// 
		const UI32 G4MH = 0x06;
		FrogRegData PID_Register = 0;
		if (g_prf->IsVmSimulation ()){
			gcs_get_vc_register ("PID",&PID_Register,0);
		} else {
			gcs_get_nc_register ("PID",&PID_Register);
		}
		UI32 PID_Inf = (UI32)((PID_Register&0xff000000) >> 24) ;
		//---- Init WR for G4MH structure ----//
		if (PID_Inf == G4MH) {

			for (UI32 i = 0; i < 32; i++) {
				//Get the address that contain init value 
				NewINS(pCB, MOV32(addr, reg1));

				//Preset 4th word
				PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
				pSim->PresetMemory(true, 0, addr, PSIZE, PrsVal);
				//Preset 3rd word
				PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
				pSim->PresetMemory(true, 0, addr + PSIZE, PSIZE, PrsVal);
				//Preset 2nd word
				PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
				pSim->PresetMemory(true, 0, addr + 2*PSIZE, PSIZE, PrsVal);
				//Preset 1st word
				PrsVal = pRand->GetRange(0x0U, 0xffffffffU);
				pSim->PresetMemory(true, 0, addr + 3*PSIZE, PSIZE, PrsVal);

				//Load the init value to wire register
				NewINS(pCB, LDVQW(0, reg1, i));
				addr += 4*PSIZE;
			}
		}
	}
	return pCB;
}


CCodeBlock*	CBlockManager::InitLdtcVR(CCodeBlock* pCB) {
	FROG_ASSERT(pCB);
	for (UI32 i = 0; i < 32; i++) {
		NewINS( pCB, LDTC_VR( (i & 0x1E), i) ) ;
	}
	return pCB;
}


CCodeBlock*	CBlockManager::InitNcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* pList) {
	
	FROG_ASSERT(pList);
	
	// NCコンテキスト以外をフィルタリングして初期化リストを作成する。
	std::map<UI32,ISysReg*>::iterator	itr;
	std::vector<std::pair<ISysReg*,UI32> >	nclist;
	
	for (itr = pList->begin(); itr != pList->end(); itr++) {
		// 検討：E3V5Arc部なのだが、I/Fとして公開た方が良いか

		if(itr->second->IsInitNC()) {
			UI32 nc = 0;
			itr->second->GetNcInit(&nc);
			nclist.push_back(std::pair<ISysReg*,UI32>(itr->second, nc));
		}
	}
	return this->InitSR(pCB, nclist);
}

CCodeBlock*	CBlockManager::InitVcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* pList) {
	
	FROG_ASSERT(pList);
	
	// VCコンテキスト以外をフィルタリングして初期化リストを作成する。
	std::map<UI32,ISysReg*>::iterator	itr;
	std::vector<std::pair<ISysReg*,UI32> >	vclist;
	
	for (itr = pList->begin(); itr != pList->end(); itr++) {
		// 検討：E3V5Arc部なのだが、I/Fとして公開た方が良いか
	
		if(itr->second->IsInitVC()) {
			UI32 vc = 0;
			itr->second->GetVcInit(&vc);
			vclist.push_back(std::pair<ISysReg*,UI32>(itr->second, vc));
		}
	}
	return this->InitLdvcSR(pCB, vclist);
}


CCodeBlock*	CBlockManager::InitTcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* pList) {
	
	FROG_ASSERT(pList);
	
	// VCコンテキスト以外をフィルタリングして初期化リストを作成する。
	std::map<UI32,ISysReg*>::iterator	itr;
	std::vector<std::pair<ISysReg*,UI32> >	tclist;
	
	for (itr = pList->begin(); itr != pList->end(); itr++) {
		// 検討：E3V5Arc部なのだが、I/Fとして公開た方が良いか
		
		if(itr->second->IsInitTC()) {
			UI32 tc = 0;
			itr->second->GetTcInit(&tc);
			tclist.push_back(std::pair<ISysReg*,UI32>(itr->second, tc));
		}
	}
	return this->InitLdtcSR(pCB, tclist);
}

CCodeBlock*	CBlockManager::InitSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf) {
	
	FROG_ASSERT(pCB);
	
	UI32 tmpR = 10;
	
	std::vector< std::pair<ISysReg*,UI32> >::iterator itr;
	for (itr = srinf.begin(); itr != srinf.end(); itr++) {
		UI32 regId	= 0;
		itr->first->GetRegId(&regId);
		UI32 selId	= 0;
		itr->first->GetSelReg(&selId);// >> 5;	// selId = v / 23
		UI32 val	= itr->second;
		IInstruction* pIns = NOP();

		UI32 MP_regId = 0;
		if(CU1isON() && (selId == 6 || selId == 7 || selId == 8)){
			if(regId % 4 == 0){
				MP_regId = 28;	//MPLA
			}
			else{
				if(regId % 4 == 1)
					MP_regId = 29;	//MPUA
				else
					MP_regId = 30;	//MPAT
			}
			UI32 channel = ((selId - 6)* 32 + regId)/4;

			NewINS( pCB, MOV32( channel, tmpR));
			pIns = LDSR( tmpR, 16, 5); // MPIDX
			NewINS (pCB, pIns);

			if (val) {
				NewINS( pCB, MOV32( val, tmpR));
				pIns = LDSR( tmpR, MP_regId, 5);
			}
			else {
				pIns = LDSR( 0, MP_regId, 5);// r0を使う
			}
		}else{

			if (val) {
				NewINS( pCB, MOV32( val, tmpR ) );
				pIns = LDSR( tmpR, regId, selId);
			} else {
				pIns = LDSR( 0, regId, selId); // r0を使う
			}

		}

		std::string regName("");
		itr->first->GetRegName(&regName);
		pIns->AppendComment(regName.data());
		NewINS (pCB, pIns);
	}
	return pCB;
}

CCodeBlock*	CBlockManager::InitLdvcSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf) {
	
	FROG_ASSERT(pCB);
	
	UI32 tmpR = 10;
	
	std::vector< std::pair<ISysReg*,UI32> >::iterator itr;
	for (itr = srinf.begin(); itr != srinf.end(); itr++) {
		UI32 regId	= 0;
		itr->first->GetRegId(&regId);
		UI32 selId	= 0;
		itr->first->GetSelReg(&selId);// >> 5;	// selId = v / 23
		UI32 val	= itr->second;
		IInstruction* pIns;
		if (val) {
			NewINS( pCB, MOV32( val, tmpR ) );
			pIns = LDVC_SR( tmpR, regId, selId);
		} else {
			pIns = LDVC_SR( 0, regId, selId); // r0を使う
		}

		std::string regName("");
		itr->first->GetRegName(&regName);
		pIns->AppendComment(regName.data());

		NewINS (pCB, pIns);
	}
	return pCB;
}

CCodeBlock*	CBlockManager::InitLdtcSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf) {
	
	FROG_ASSERT(pCB);
	
	UI32 tmpR = 10;
	
	std::vector< std::pair<ISysReg*,UI32> >::iterator itr;
	for (itr = srinf.begin(); itr != srinf.end(); itr++) {
		UI32 regId	= 0;
		itr->first->GetRegId(&regId);
		UI32 selId	= 0;
		itr->first->GetSelReg(&selId);// >> 5;	// selId = v / 23
		UI32 val	= itr->second;
		IInstruction* pIns = NOP();

		if((( CU1isON()==0 )&&(selId==8))&&((regId==6)||(regId==7)||(regId==8)||(regId==9)||(regId==10)||(regId==11)||(regId==12)||(regId==13)))
		{
		}else{

			if (val) {
			NewINS( pCB, MOV32( val, tmpR ) );
			pIns = LDTC_SR( tmpR, regId, selId);
			} else {
			pIns = LDTC_SR( 0, regId, selId); // r0を使う
			}

		}

		std::string regName("");
		itr->first->GetRegName(&regName);
		pIns->AppendComment(regName.data());
		NewINS (pCB, pIns);
	}
	return pCB;
}


CCodeBlock* CBlockManager::InitStackEntry(CCodeBlock* pCB , UI32 reg, UI32 memreg) {
	IInstruction * ins ;
	char str[80] ;
	for (UI32 i=0 ;i < (g_wm.m_htnum + 1) ;i++ ) {
		UI32 adr= g_wm.BASE_PE_HT + g_wm.SIZE_HT * i + g_wm.OFS_STACK_EI_ENTRY ;
		UI32 ini= g_wm.BASE_PE_HT + g_wm.SIZE_HT * i + g_wm.OFS_STACK_EI + g_wm.SIZ_STACK_EI ;
		NewINS( pCB, MOV32( ini , reg ) );
		NewINS( pCB, MOV32( adr , memreg ) );
		NewINS( pCB, ins= STW16(reg,0, memreg) );
		if (i != g_wm.m_htnum) {
			sprintf(str ,"HT#%d : stack_bottom is 0x%08x" ,i ,ini ) ;
			ins->AppendComment((LPCTSTR)str) ;
		} else {
			sprintf(str ,"NT : stack_bottom is 0x%08x" ,ini ) ;
			ins->AppendComment((LPCTSTR)str) ;
		}
	}

	return (pCB) ;
}


void CBlockManager::GenMmuHandler (TBlockConfig* pCfg , CHandlerBlock* pHB , UI32 reg) {

	IInstruction * ins ;
	std::string contextStr = GetMContext(pCfg);
	char str[120] ;
		
	//!・・ITLBE/DTLBEハンドラはＭＭＵ搭載時のみ生成
	//[ ITLBE判定 ]
	NewINS( pHB,  CMP5(2U,reg));
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_50"));		// BNE
	
	//ITLBE例外処理
	NewINS( pHB,  STSR( 14,reg, 0) );			// FEIC
	NewINS( pHB,  SHR5(16, reg) );
	NewINS( pHB,  ANDI(0x0100, reg ,0) ); 		// if (FEIC.NP == 1) then Goto __fix_mp_handler_30
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_30") );
	NewINS( pHB,  ANDI(0x0040, reg ,0) ); 		// if (FEIC.V  == 0) then Goto __fix_mp_handler_40  ;TLB不一致違反
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_40") );
	NewINS( pHB,  ANDI(0x0200, reg ,0) ); 		// if (FEIC.ME == 1) then Goto __fix_mp_handler_40  ;TLB多重一致違反
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_40") );
	//!・・・ITLBE例外TLB特権違反の処理
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  JR22P( contextStr + "fix_mp_handler_42"));
	//__fix_mp_handler_30:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_30"));
	NewINS( pHB,  ANDI(0x0200, reg ,0) ); 		// if (FEIC.ME == 1) then Goto __fix_mp_handler_40  ;TLB次ページ多重一致違反
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_40"));
	NewINS( pHB,  ANDI(0x0040, reg ,0) ); 		// if (FEIC.V  == 0) then Goto __fix_mp_handler_32
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_32"));
	//ITLBE例外TLB次ページ特権違反の処理
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA + 8
	NewINS( pHB,  ADDI(0x0008, reg ,0) );
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  JR22P( contextStr + "fix_mp_handler_40"));
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
	//!・・・ITLBE例外TLB次ページ不一致違反の処理
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_32"));
	NewINS( pHB,  JARL22P( contextStr + "set_work_ptr", 31));
	NewINS( pHB,  LDW16(g_wm.OFS_ITLB_INFO, 29, reg) );
	NewINS( pHB,  CMP5((-1),reg) );
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_38"));
	{
		//空きエントリ探査
		UI32 start= reg + 1 ;
		UI32 index= reg + 2 ;
		//TODO: startは乱数で決める
		NewINS( pHB,  MOV5(1, start) );
		NewINS( pHB,  MOVR(start, index) );
		//__fix_mp_handler_34:
		// index値でエントリー読み出し
		NewINS( pHB,  LDSR(index, 0, 4)->SetLabel(contextStr + "fix_mp_handler_34"));
		NewINS( pHB,  TLBR() );
		// if ((TEHI1.V == 0)&&(TEHI1.L == 0)) then Goto __fix_mp_handler_37  ; 空きエントリー発見
		NewINS( pHB,  STSR(7, reg, 4) );
		NewINS( pHB,  SHR5(30, reg) );
		NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_37"));	
		// index= index % (TLBCFG + 1)
		NewINS( pHB,  ADD5(1, index) );
		NewINS( pHB,  STSR(10, reg, 4) );
		NewINS( pHB,  ADD5(1, reg) );
		NewINS( pHB,  DIVHW(reg, index, index) );
		// if (start != index) then Goto __fix_mp_handler_34
		NewINS( pHB,  CMPR(start, index) );
		NewINS( pHB,  BNE17P(contextStr + "fix_mp_handler_34"));
		//TODO: 全エントリーが使用中だった場合の処理(不要エントリーを開放する)
		NewINS( pHB,  HALT() );
		NewINS( pHB,  NOP() );
		NewINS( pHB,  NOP() );
		//__fix_mp_handler_37:
		NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_37"));
		NewINS( pHB,  STW16(reg ,g_wm.OFS_ITLB_INFO ,29) );
	}
	//__fix_mp_handler_38:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_38"));
	//該当エントリーを検索して読み取り
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA + 10
	NewINS( pHB,  ADDI(0x10, reg, reg) );
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  STSR(7, reg, 2) );			// TEHI1= f(HTCFG0 ,ASID) 
	NewINS( pHB,  ANDI(0x00ff, reg ,0) ); 
	NewINS( pHB,  STSR(0, reg+1, 2) );
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBS() );
	NewINS( pHB,  STSR(0, reg+1, 4) );			// GR[reg+1]= TLBIDX   (dummy read)
	NewINS( pHB,  TLBR() );
	// GR[reg+2]= 1 << (TEHI0.PGSIZE + 10)
	// TEHI0 += GR[reg+2] ;
	// TELO0= (TELO0 + GR[reg2]) | 0x3f ;
	// TELO1= 0 ;
	NewINS( pHB,  STSR(6, reg, 4) );
	NewINS( pHB,  ANDI(0x001f, reg ,reg+1) );
	NewINS( pHB,  ADD5(10, reg+1 ) );
	NewINS( pHB,  MOV5(1, reg+2 ) );
	NewINS( pHB,  SHL(reg+1, reg+2) );
	NewINS( pHB,  ADD(reg+2, reg ) );
	NewINS( pHB,  LDSR(reg, 6, 4) );			
	NewINS( pHB,  STSR(4, reg, 4) );
	NewINS( pHB,  ADD(reg+2, reg ) );
	NewINS( pHB,  ORI(0x003f, reg ,reg) );
	NewINS( pHB,  LDSR(reg, 4, 4) );			
	NewINS( pHB,  LDSR(0, 5, 4) );				
	// TEHI1.VM= ~HTCFG0.NC ;
	// TEHI1.VCID= ~HTCFG0.VCID ;
	// TEHI1.V= 1 ;
	// TEHI1.L= 1 ;
	// TEHI1.G= 1 ;
	// TEHI1.ASID= 0x222 ;
	// TEHI1.HVC= 0 ;
	NewINS( pHB,  STSR(0, reg+1, 2) );				//HTCFG0
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  MOV32(0xc0100222 , reg+1) );
	NewINS( pHB,  OR(reg+1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	// エントリー書き込み
	NewINS( pHB,  LDW16(g_wm.OFS_ITLB_INFO ,29 ,reg) );
	NewINS( pHB,  LDSR(reg, 0, 4) );				// TLBIDX= reg
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_mp_handler_40:
	//!・・・ITLBE例外TLB不一致違反、TLB多重一致違反の処理
	NewINS( pHB,  NOP()->SetLabel(  contextStr + "fix_mp_handler_40"));
	//===========================================
	//!・・・・jarlブロックの呼び元への強制リターン処理
	//===========================================
	NewINS( pHB,  LDSR(31,2,0) );					// FEPC <- r31
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_mp_handler_42:
	//!・・・ITLBE例外TLB特権違反、TLB次ページ特権違反の処理
	//（TEHI0にMEA値をセットしてからここへjump )
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_42"));
	//!・・・・MEA値をもとにTLBS命令で該当エントリーを探査し、そのエントリーに必要な特権を付与
	NewINS( pHB,  STSR(7, reg, 2) );			// TEHI1= f(HTCFG0 ,ASID) 
	NewINS( pHB,  ANDI(0x00ff, reg ,0) ); 
	NewINS( pHB,  STSR(0, reg+1, 2) );
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBS() );
	NewINS( pHB,  STSR(0, reg+1, 4) );			// reg+1= TLBIDX   (dummy read)
	//
	NewINS( pHB,  TLBR() );
	NewINS( pHB,  STSR(4, reg+1, 4) );			// TELO1.PRIV |= FEIC[21:16]
	NewINS( pHB,  OR(reg+1,reg) );
	NewINS( pHB,  LDSR(reg, 4, 4) );
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );


	//[ DTLBE判定 ]
//__fix_mp_handler_50:
	NewINS( pHB,  CMP5(3U,reg)->SetLabel( contextStr + "fix_mp_handler_50"));
	NewINS( pHB,  BNE17P( contextStr + "fix_mp_handler_60"));		// BNE

	//DTLBE例外処理
	NewINS( pHB,  STSR( 14,reg, 0) );			// FEIC
	NewINS( pHB,  SHR5(16, reg) );
	NewINS( pHB,  ANDI(0x0100, reg ,0) ); 		// if (FEIC.PB == 1) then Goto __fepcInc Else Goto __fix_mp_handler_51
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_51"));
	//!・・・DTLBE例外TLBページ境界違反の処理<BR>
	//!・・・・FEPCを書き換えて、例外を発生した次の命令にFERET
	NewINS( pHB,  MOV32P( contextStr + "fepcInc", reg));
	NewINS( pHB,  JMP32(reg) );
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );	
//__fix_mp_handler_51:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_51" ));
	NewINS( pHB,  ANDI(0x0040, reg ,0) ); 		// if (FEIC.V  == 0) then Goto __fix_mp_handler_55
	NewINS( pHB,  BE17P( contextStr + "fix_mp_handler_55" ));
//==== MEA値をもとにTLBS命令で該当エントリーを検索
	NewINS( pHB,  STSR(6, reg, 2) );			// TEHI0= MEA
	NewINS( pHB,  LDSR(reg, 6, 4) );
	NewINS( pHB,  STSR(7, reg, 2) );			// TEHI1= f(HTCFG0 ,ASID) 
	NewINS( pHB,  ANDI(0x00ff, reg ,0) ); 
	NewINS( pHB,  STSR(0, reg+1, 2) );
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBS() );
	NewINS( pHB,  STSR(0, reg+1, 4) );			// reg+1= TLBIDX   (dummy read)
//====
	NewINS( pHB,  STSR(14,reg, 0) );			// FEIC
	NewINS( pHB,  SHR5(16, reg) );
	NewINS( pHB,  ANDI(0x0200, reg ,0) ); 		// if (FEIC.ME == 1) then Goto __fepcInc Else __fix_mp_handler_52
	NewINS( pHB,  BE17P ( contextStr + "fix_mp_handler_52") );
	//!・・・DTLBE例外DTLB多重違反の処理<BR>
	//!・・・・MEA値をもとにTLBS命令で該当エントリーを検索し、見つかったエントリーを無効化
	NewINS( pHB,  TLBR() );
	NewINS( pHB,  STSR(7, reg, 4) );			// TEHI1.V= 0
	NewINS( pHB,  BINS(0 ,31 ,1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
//__fix_mp_handler_52:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_52" ));
	NewINS( pHB,  ANDI(0x003f, reg ,reg) ); 
	//!・・・DTLBE例外TLB特権違反の処理<BR>
	//!・・・・・MEA値をもとにTLBS命令で該当エントリーを探査し、そのエントリーに必要な特権を付与
	NewINS( pHB,  TLBR() );
	NewINS( pHB,  STSR(4, reg+1, 4) );			// TELO1.PRIV |= FEIC[21:16]
	NewINS( pHB,  OR(reg+1,reg) );
	NewINS( pHB,  LDSR(reg, 4, 4) );
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
//__fix_mp_handler_55:
	//!・・・DTLBE例外TLB不一致違反の処理<BR>
	//!・・・・８つあるデマンドページング用のエントリーのうちの１つを、最小ページサイズでMEA値を含むように充てる。
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_55"));
	NewINS( pHB,  JARL22P( contextStr + "set_work_ptr",31));
	// TLBIDX= (r27 + g_wm.OFS_DTLB_INFO + 4)[g_wm.OFS_DTLB_INFO[r27] * 2] ;
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO ,27 ,reg ) );
	NewINS( pHB,  SHL5(1, reg) );
	NewINS( pHB,  ADD(27, reg) );
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO+4 ,reg ,reg) );
	NewINS( pHB,  LDSR(reg, 0, 4) );
	//OFS_DTLB_INFO[r27]= (OFS_DTLB_INFO[r27] + 1) % (OFS_DTLB_INFO+2)[r27] ;
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO+0 ,27 ,reg   ) );
	NewINS( pHB,  LDHU16(g_wm.OFS_DTLB_INFO+2 ,27 ,reg+1 ) );
	NewINS( pHB,  ADD5(1, reg) );
	NewINS( pHB,  CMPR(reg,reg+1));
	NewINS( pHB,  CMOV5(2 ,0, reg ,reg) );
	NewINS( pHB,  STH16(reg ,g_wm.OFS_DTLB_INFO ,27) );
	//エントリー読み込み
	NewINS( pHB,  TLBR() );
	// TEHI0= MEA & 0xFFFFFC00 ;
	// TELO1= 0 ;
	// TEHI1.VM= ~HTCFG0.NC ;
	// TEHI1.VCID= ~HTCFG0.VCID ;
	// TEHI1.V= 1 ;
	// TEHI1.L= 1 ;
	// TEHI1.G= 0 ;
	// TEHI1.ASID= ASID ;
	// TEHI1.HVC= 0 ;
	NewINS( pHB,  STSR(6, reg, 2) );				// MEA
	NewINS( pHB,  BINS(0 ,0 ,10 ,reg) );
	NewINS( pHB,  LDSR(reg, 6, 4) );			
	NewINS( pHB,  LDSR(0, 5, 4) );					// TEHI0
	NewINS( pHB,  STSR(0, reg+1, 2) );				// HTCFG0
	NewINS( pHB,  SHR5(8, reg+1) );
	NewINS( pHB,  MOVR(0, reg) );
	NewINS( pHB,  BINS(reg+1 ,16 ,3, reg) );
	NewINS( pHB,  SHR5(7, reg+1) );
	NewINS( pHB,  XORI(0x0001, reg+1 ,reg+1) ); 
	NewINS( pHB,  BINS(reg+1 ,15 ,1, reg) );
	NewINS( pHB,  MOV32(0xc0000000 , reg+1) );
	NewINS( pHB,  OR(reg+1, reg) );
	NewINS( pHB,  STSR(7, reg+1, 2) );				// ASID
	NewINS( pHB,  OR(reg+1, reg) );
	NewINS( pHB,  LDSR(reg, 7, 4) );				// TEHI1
	// エントリー書き込み
	NewINS( pHB,  TLBW() );
	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(29,m_nHandlerReg,0) ) ;
	sprintf(str ,"r3= FEWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  FERET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_mp_handler_60:
	NewINS( pHB,  NOP()->SetLabel( contextStr + "fix_mp_handler_60"));
}


std::vector<CHandlerBlock*>* CBlockManager::GenerateHandler(TBlockConfig* pCfg) {
	//!<BR>[処理細目]<BR>

	UI32 reg;
	do {
		reg = g_rnd.GetRange(4, 25);
	} while(reg <= m_nHandlerReg && m_nHandlerReg <= (reg + 4));
	m_nWorkReg = reg;
	std::vector<CHandlerBlock*>* vNode = new std::vector<CHandlerBlock*>();
	CHandlerBlock* pHB = nullptr;
	std::string contextStr = GetMContext(pCfg);
	std::string lable;

	//=============================
	//!・MIP/MDP/ITLB/DTLB例外ハンドラ
	//=============================
    if (m_MmList.Size() != 0) {
        g_prf->m_is_mpu = true;
        UI32 gmmpcfg_hbe = (g_srs->GetNcInit(26, 9) >> 8) & 0x1f;
        m_MmList.RandomReserveEntry(pCfg->m_bGM, gmmpcfg_hbe);
    }

	if (g_hwInfo.m_tlbnum != 0) {
    	GenMmuHandler(pCfg , pHB , reg) ;
	}

	//!・Generate debug handler
	pHB = GenerateDebugHandler(pCfg);
	vNode->push_back(pHB);

	// Calculate return PC from debug handler
	pHB =  GeneratePCIncDebugHandler(pCfg);
	vNode->push_back(pHB);

	// Calculate return PC from break point exception
	pHB = GenerateBreakPointIncPC(pCfg);
	vNode->push_back(pHB);

	//pHB = GenerateWorkingAreaBlock(reg);
	//vNode->push_back(pHB);

	return vNode;
};

CHandlerBlock* CBlockManager::GenerateWorkingAreaBlock(UI32 reg){

	UI32 reg1 = reg + 1;
	UI32 reg2 = reg + 2;
	UI32 reg3 = reg + 3;
	IInstruction* ins;
	CHandlerBlock* pHB = new CHandlerBlock("set_work_ptr");

	NewINS( pHB, ins= NOP() ) ;
	ins->AppendComment("r27= BASE_PE") ;
	NewINS( pHB, ins= NOP() ) ;
	ins->AppendComment("r28= (BASE_PE_VM + ((HTCFG0.NC) ?  8 : HTCFG0.VCID) * SIZE_VM") ;
	NewINS( pHB, ins= NOP() ) ;
	ins->AppendComment("r29= (BASE_PE_HT + ((HTCFG0.NC) ? 64 : HTCFG0.TCID) * SIZE_HT") ;
	NewINS( pHB, STSR(0,reg3,2) ) ;				// HTCFG0
	NewINS( pHB, SHR5(16,reg3) ) ;
	NewINS( pHB, BNC17P("set_work_ptr_01")) ;	//goto case_2

	//case_1: HTCFG0.NC == 1
	NewINS( pHB, MOV32(g_wm.BASE_PE,reg1)) ;
	NewINS( pHB, MOV32((g_wm.BASE_PE_VM + g_wm.SIZE_VM * g_wm.m_vmnum), reg2) ) ;
	NewINS( pHB, MOV32((g_wm.BASE_PE_HT + g_wm.SIZE_HT * g_wm.m_htnum), reg3) ) ;
	NewINS( pHB, BR9P("set_work_ptr_02") );

	//case_2: HTCFG0.NC == 0
	NewINS( pHB, MOV32(g_wm.BASE_PE,reg1)->SetLabel("set_work_ptr_01") );
	NewINS( pHB, STSR(0,reg2,2) ) ;
	NewINS( pHB, SHR5(8,reg2) ) ;
	NewINS( pHB, ANDI(0x007,reg2,reg2) ) ;
	NewINS( pHB, MULHI((SI32)(SI16)(g_wm.SIZE_VM),reg2,reg2) ) ;
	NewINS( pHB, MOV32(g_wm.BASE_PE_VM,reg) ) ;
	NewINS( pHB, ADD(reg,reg2) ) ;
	NewINS( pHB, STSR(0,reg3,2) ) ;
	NewINS( pHB, ANDI(0x003f,reg3,reg3) ) ;
	NewINS( pHB, MULHI((SI32)(SI16)(g_wm.SIZE_HT),reg3,reg3) ) ;
	NewINS( pHB, MOV32(g_wm.BASE_PE_HT,reg) ) ;
	NewINS( pHB, ADD(reg,reg3) ) ;

	NewINS( pHB,  NOP()->SetLabel("set_work_ptr_02"));
	NewINS( pHB, JMP32(31) );

	return pHB;


}
CHandlerBlock* CBlockManager::GenerateDebugHandler(TBlockConfig* pCfg){
	UI32 reg, reg1, reg2;
    reg = m_nWorkReg;
	reg1 = reg + 1;
	reg2 = reg + 2;
	m_nWorkReg = reg;
	IInstruction * ins ;
	char str[120] ;
	std::string lable;
	UI32 machine = (pCfg->m_bNC) ? 0x1 : 0;
	CHandlerBlock* pHB = new CHandlerBlock("debug_handler");
	pHB->SetOutputFlag(true);
	pHB->SetHandlerAddress(machine | ADR_VECTOR_DEBUG);
	pHB->SetExceptionLevel(IExceptionConfig::EXP_LEVEL_DB);
	SaveRegisterDB(pHB , "fix_debug") ;

    //! Initialize for debug dump SReg
    NewINS( pHB,  MOV32P("break_channel_init", reg )); // if the DBTRAP instruction for break_channel_init
    NewINS( pHB,  STSR( 18, reg1, 3));
	NewINS( pHB,  SATSUBI( 2, reg1, reg1));
    NewINS( pHB,  CMPR( reg1, reg ));
    NewINS( pHB,  BNE17P("fix_debug_handler_00" ));

    NewINS( pHB, STSR(21, reg1, 3));     // get DIR1(r11)
    NewINS( pHB, MOV32(0xFFFFFF0F, reg2)); // DIR1.CSL 0 clear
    NewINS( pHB, AND(reg2, reg1));
    NewINS( pHB, LDSR(reg1, 21, 3));

    for( UI32 i = 0; i < g_exp->GetNumOfChannels(); i++ ) {
		UI32 bpc = (UI32)g_rnd.GetRange((UI32)0,(UI32)0xffffffff);
		UI32 addr_mask = (UI32)g_rnd.GetRange((UI32)0,(UI32)0xffffffff);
		UI32 data_mask = (UI32)g_rnd.GetRange((UI32)0,(UI32)0xffffffff);

		if( g_exp->GetBreakPointWeight())
			g_exp->SetChannel(&bpc, &addr_mask, &data_mask);
        if(bpc <= 0xF)
			NewINS( pHB, MOV5(bpc, reg2));
		else
			NewINS( pHB, MOV32(bpc, reg2));

        NewINS( pHB, LDSR(reg2, 22, 3)); // BPC init
        NewINS( pHB, MOV32((UI32)g_rnd.GetRange((UI32)0,(UI32)0xffffffff), reg2));
        NewINS( pHB, LDSR(reg2, 24, 3)); // BPAV init
		NewINS( pHB, MOV32(addr_mask, reg2));
		NewINS( pHB, LDSR(reg2, 25, 3)); // BPAM init

		if(i == (g_exp->GetNumOfChannels()-1))
			break;
		NewINS( pHB, ADDI(16U, reg1, reg1));
        NewINS( pHB, LDSR(reg1, 21, 3));
    }

	NewINS( pHB,  NOP()->SetLabel("fix_debug_handler_00" ) );
	NewINS( pHB,  STSR( 15,reg, 3)  );		//DBIC
	NewINS( pHB,  ANDI(0x00ffU, reg, reg));
	NewINS( pHB,  SATSUBI(0x00B0U,reg,reg));
	NewINS( pHB,  CMP5(1U,reg)->SetLabel( "fix_debug_handler_10"));
	NewINS( pHB,  BE17P("fix_debug_handler_20")); //DBTRAP命令による例外処理へ
	NewINS( pHB,  CMP5(5U,reg));
	NewINS( pHB,  BE17P("fix_debug_handler_15")); //LSAB (sync.), PCB, AE
	NewINS( pHB,  CMP5(6U,reg));
	NewINS( pHB,  BE17P("fix_debug_handler_15")); //LSAB (async.)
	NewINS( pHB,  JR22P("fix_debug_handler_30")); //DBINT, DBNMI

    //DBIC=0xB5,0xB6
    //Increase PC for break point exception
	NewINS( pHB, MOV32P("dbpcInc_break", reg)->SetLabel("fix_debug_handler_15"));
	NewINS( pHB, JMP32(reg) );
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

    // Handling exceptions by DBTRAP instruction
//__fix_debug_handler_20:
	NewINS( pHB,  STSR( 18, reg1, 3)->SetLabel("fix_debug_handler_20") );	//DBPC
	NewINS( pHB,  SATSUBI(2,reg1,reg1) );
	// If it is the DBTRAP instruction at the head of the code block, go to break setting processing
	NewINS( pHB,  MOV32P("debug_breaksetup", reg));
	NewINS( pHB,  JMP32(reg));
	NewINS( pHB,  NOP()->SetLabel("debug_breaksetup_ret"));
	//Overwrite DBGEN is take less instruction than calculation value for DBGEN here
	UI32 dbgen = g_rnd.GetRange(0x0, 0x1FF);
	NewINS( pHB,  MOV32(dbgen, reg));
	NewINS( pHB,  LDSR(reg, 0, 3));
    // Handling exceptions by DBTRAP / RMTRAP / DBHVTRAP instruction
//__fix_debug_handler_30:
	NewINS( pHB,  POPSP(1,31)->SetLabel("fix_debug_handler_30") ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg,3) ) ;
	sprintf(str ,"r3= DBWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

//__fix_debug_handler_40:
	//Hardware debug exception handling (DBIC = 0xBC, 0xBD, 0xBE, 0xBF))
	NewINS( pHB,  POPSP(1,31)->SetLabel("fix_debug_handler_40") ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg,3) ) ;
	sprintf(str ,"r3= DBWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	//__fix_debug_handler_50:	
	NewINS( pHB, MOV32P("dbpcInc", reg)->SetLabel("fix_debug_handler_50") );
	NewINS( pHB, JMP32(reg) );
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
	return pHB;
}

CHandlerBlock* CBlockManager::GenerateBreakPointIncPC(TBlockConfig* pCfg){
	UI32 reg, reg1, reg2, reg3, reg4;
	reg = m_nWorkReg;
	reg1 = reg + 1;
	reg2 = reg + 2;
	reg3 = reg + 3;
	reg4 = reg + 4;
	m_nWorkReg = reg;
	IInstruction * ins ;
	char str[120] ;
	std::string lable;
	UI32 num_of_channels = g_exp->GetNumOfChannels();
	CHandlerBlock* pHB = new CHandlerBlock("dbpcInc_break");
	pHB->SetOutputFlag(true);

    // Clear processing DIR0.AT
    NewINS( pHB,  STSR(20, reg1, 3));
    NewINS( pHB,  ANDI(0x100, reg1, reg2));
    NewINS( pHB,  BE17P("dbpcInc_not_at"));
    NewINS( pHB,  XORI(0x300, reg1, reg1));
    NewINS( pHB,  LDSR(reg1, 20, 3)); // set DIR0.AT=0,AEE=0

    // Check DIR1.BT11 - 0 and loop the channel setting
//__dbpcInc_not_at
    NewINS( pHB,  MOV5( 0x0, reg1 )->SetLabel("dbpcInc_not_at"));       // CSL(reg1) = 0
    NewINS( pHB,  STSR(21, reg3 , 3)  );     // get DIR1(reg3)
    NewINS( pHB,  MOV32(0x00000100, reg4));  // BT_Mask(reg4)

//__dbpcInc_loop0:
    NewINS( pHB,  MOVR(reg3, reg2)->SetLabel("dbpcInc_loop0"));
    NewINS( pHB,  AND(reg4, reg2));
    NewINS( pHB,  BNE17P("dbpcInc_clear")); // to channel setting clear processing

//__dbpcInc_loop1:
    NewINS( pHB,  ADDI(16U,reg1,reg1)->SetLabel("dbpcInc_loop1")); // CSL + 1
	NewINS( pHB,  SATSUBI((num_of_channels << 4),reg1,reg));                                  // TODO：max channelを代入して、ループ回数を削減すること
	NewINS( pHB,  BE17P("dbpcInc_loopend")); //Check all channel

    NewINS( pHB,  SHL5(1U, reg4));           //次のBT
    NewINS( pHB,  JR22P("dbpcInc_loop0"));

   // clear channel setting
    NewINS( pHB,  XOR(reg4, reg3)->SetLabel("dbpcInc_clear")); // BT clear
    NewINS( pHB,  MOV32(0xFFFFFF0F, reg));
    NewINS( pHB,  AND(reg, reg3));
    NewINS( pHB,  OR(reg1, reg3));
    NewINS( pHB,  LDSR(reg3, 21, 3) );                // set DIR1.CSL
    NewINS( pHB,  STSR(22, reg2, 3));                 // get BPC(reg2)

	NewINS( pHB,  ANDI(0xF3, reg3, reg));                         // Get DIR1.CSL, SQ0, BEN
	NewINS( pHB,  CMP5(0x03,reg)); 
	NewINS( pHB,  BE17P("dbpcInc_notclear_EO"));  // Not clear EO in Sequential Channel

	NewINS( pHB,  ANDI(0x25, reg3, reg));                         // Get DIR1.CSL, SQ1, BEN
	NewINS( pHB,  MOV32(0x25, reg3));
	NewINS( pHB,  CMPR(reg3, reg));
	NewINS( pHB,  BE17P("dbpcInc_notclear_EO"));  // Not clear EO in Sequential Channel

	NewINS( pHB,  MOV32(0xFFFFFFC0, reg));                     // clear BPC.EO,TE,BE,FE,WE,RE
	NewINS( pHB,  AND(reg, reg2));
	NewINS( pHB,  LDSR(reg2, 22, 3));                            // set BPC
	NewINS( pHB,  JR22P("dbpcInc_loop1"));

	NewINS( pHB,  MOV32(0xFFFFFFE0, reg)->SetLabel("dbpcInc_notclear_EO"));          // clear BPC.TE,BE,FE,WE,RE
	
	NewINS( pHB,  AND(reg, reg2));
	NewINS( pHB,  LDSR(reg2, 22, 3));                 // set BPC
	NewINS( pHB,  JR22P("dbpcInc_loop1"));

//__dbpcInc_loopend:
	NewINS( pHB,  POPSP(1,31)->SetLabel("dbpcInc_loopend")) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg,3) ) ;
	sprintf(str ,"r3= DBWR ; recover" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );
	return pHB;
}

CHandlerBlock* CBlockManager::GeneratePCIncDebugHandler(TBlockConfig* pCfg){
	UI32 reg, reg1, reg2, reg3, reg4;
	reg = m_nWorkReg;
	reg1 = reg + 1;
	reg2 = reg + 2;
	reg3 = reg + 3;
	reg4 = reg + 4;
	m_nWorkReg = reg;
	IInstruction * ins ;
	char str[120] ;
	std::string lable;

	CHandlerBlock* pHB = new CHandlerBlock("dbpcInc");
	pHB->SetOutputFlag(true);
	
	NewINS( pHB,  STSR(8, reg4, 1));		// Save SVLOCK
	NewINS( pHB,  LDSR(0, 8, 1));			// Disable SVLOCK

	NewINS( pHB,  STSR( 0 ,reg2, 5)  );		// Save MPM
	NewINS( pHB,  LDSR(0,0,5) );			// disable MPM
	NewINS( pHB,  SYNCI());
	NewINS( pHB,  STSR( 18 ,reg1 , 3)  );		// DBPC
	NewINS( pHB,  LDB16(1, reg1, reg));
	NewINS( pHB,  ANDI(6U, reg, reg));
	NewINS( pHB,  CMP5(6U,reg));
	NewINS( pHB,  BE17P("dbpcInc_1"));

	//	FP-SIMD Check Instruction length for UCPOP
	NewINS( pHB,  LDH16(0, reg1, reg));
	NewINS( pHB,  ANDI(0xFFFFU, reg, reg));
	NewINS( pHB,  MOV32(0x8840,reg3) );
	NewINS( pHB,  CMPR(reg,reg3));
	NewINS( pHB,  BE17P("dbpcInc_8"));
	NewINS( pHB,  MOV32(0x8040,reg3) );
	NewINS( pHB,  CMPR(reg,reg3));
	NewINS( pHB,  BE17P("dbpcInc_6"));

	NewINS( pHB,  LDHU16(0, reg1, reg));
	NewINS( pHB,  ANDI(0xFFE0U, reg, reg));
	NewINS( pHB,  SATSUBI(0x02E0U,reg,reg));
	NewINS( pHB,  BE17P("dbpcInc_6"));
	NewINS( pHB,  ADD5(2U,reg1));
	NewINS( pHB,  LDSR(reg1,18,3) );			// DBPC <- r31
	NewINS( pHB,  JR22P("dbpcInc_ret"));

	//__dbpcInc_1:
	NewINS( pHB,  LDHU16(0, reg1, reg3)->SetLabel("dbpcInc_1"));
	NewINS( pHB,  ANDI(0x7C0U, reg3, reg));
	NewINS( pHB,  SATSUBI(0x0780U,reg,reg));
	NewINS( pHB,  BNE17P("dbpcInc_4"));

	NewINS( pHB,  ANDI(0xF800U, reg3, reg));
	NewINS( pHB,  BNE17P("dbpcInc_3"));	// LD.BU or JARL
	NewINS( pHB,  LDH16(2, reg1, reg3));
	NewINS( pHB,  ANDI(31U, reg3, reg));
	NewINS( pHB,  SATSUBI(27U,reg,reg));
	NewINS( pHB,  BNE17P("dbpcInc_2"));
	NewINS( pHB,  ADD5(8U,reg1)->SetLabel("dbpcInc_8"));
	NewINS( pHB,  LDSR(reg1,18,3) );			// DBPC <- r31
	NewINS( pHB,  JR22P("dbpcInc_ret"));

	//__dbpcInc_2:
	NewINS( pHB,  ANDI(31U, reg3, reg)->SetLabel("dbpcInc_2"));
	NewINS( pHB,  SATSUBI(1U,reg,reg));
	NewINS( pHB,  BE17P("dbpcInc_3"));	// PREPARE_NO_EPWB
	NewINS( pHB,  SATSUBI(2U,reg,reg));
	NewINS( pHB,  BE17P("dbpcInc_3"));	// PREPARE_SPWB_EP
	NewINS( pHB,  ANDI(1U, reg3, reg));
	NewINS( pHB,  BE17P("dbpcInc_3"));	// JR

	//_dbpcInc_6:
	NewINS( pHB,  ADD5(6U,reg1)->SetLabel("dbpcInc_6"));
	NewINS( pHB,  LDSR(reg1,18,3) );			// FEPC <- r31
	NewINS( pHB,  JR22P("dbpcInc_ret"));

	//__dbpcInc_4:
	NewINS( pHB,  ANDI(0xffe0U, reg3, reg)->SetLabel("dbpcInc_4"));
	NewINS( pHB,  SATSUBI(0x620U,reg,reg));
	NewINS( pHB,  BE17P("dbpcInc_6"));	// MOVW
	NewINS( pHB,  ANDI(0xffe0U, reg3, reg));
	NewINS( pHB,  SATSUBI(0x6E0U, reg, reg));			// JMPW or LOOP
	NewINS( pHB,  BNE17P("dbpcInc_3"));
	NewINS( pHB,  LDHU16(2, reg1, reg3));
	NewINS( pHB,  ANDI(0x1U, reg3, reg));
	NewINS( pHB,  BE17P("dbpcInc_6"));	// JMPW

	//__dbpcInc_3:
	NewINS( pHB,  ADD5(4U,reg1)->SetLabel("dbpcInc_3"));
	NewINS( pHB,  LDSR(reg1,18,3) );			// FEPC <- r31

	//__dbpcInc_ret:
	NewINS( pHB,  LDSR(reg2,0,5)->SetLabel("dbpcInc_ret"));	// Recover MPM
	NewINS( pHB,  SYNCI());

	NewINS( pHB,  LDSR(reg4, 8, 1));			// Recover SVLOCK

	NewINS( pHB,  POPSP(1,31) ) ;
	NewINS( pHB,  MOVR(m_nHandlerReg, 3));
	NewINS( pHB, ins= STSR(30,m_nHandlerReg,3) ) ;
	sprintf(str ,"r3= DBWR ; recover") ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pHB,  DBRET() ) ;
	NewINS( pHB,  NOP() );
	NewINS( pHB,  NOP() );

	return pHB;
}

CCodeBlock* CBlockManager::SaveRegisterDB(CCodeBlock* pCB , std::string label) {
	IInstruction * ins ;
	char str[130] ;
	std::string s1= label + "_handler_save1";
	std::string s2= label + "_handler_save2";
	UI32 tmp1 ;
	UI32 ret_reg = m_nWorkReg;
	UI32 db_reg = m_nWorkReg + 1;
	UI32 jump_reg = m_nWorkReg + 2;
	
	NewINS( pCB, MOVR(3, m_nHandlerReg));
	NewINS( pCB, ins= STSR(0,3,2) ) ;	// HTCFG0
	sprintf(str ,"r3= (BASE_PE_VM + ((HTCFG0.NC) ? 8 : HTCFG0.VCID) * SIZE_VM + OFS_SAVE_DB + SIZ_SAVE_DB" ) ;
	ins->AppendComment((LPCTSTR)str) ;
	NewINS( pCB, SHR5(16,3) ) ;
	NewINS( pCB, BNC17P(s1.c_str()) ) ;	//goto case_2
	//case_1: HTCFG0.NC == 1
	NewINS( pCB, MOV32((g_wm.BASE_PE_VM + g_wm.OFS_SAVE_DB + g_wm.SIZ_SAVE_DB + g_wm.SIZE_VM * g_wm.m_vmnum),3) ) ;
	NewINS( pCB, BR9P((s2.c_str())));
	//case_2: HTCFG0.NC == 0
	NewINS( pCB, NOP()->SetLabel( s1 ));
	tmp1= (g_wm.BASE_PE_VM + g_wm.OFS_SAVE_DB + g_wm.SIZ_SAVE_DB) ;
	NewINS( pCB, STSR(0,3,2) ) ;
	NewINS( pCB, SHR5(8,3) ) ;
	NewINS( pCB, ANDI(0x0007,3,3) ) ;
	NewINS( pCB, MULHI((SI32)(SI16)(g_wm.SIZE_HT),3,3) ) ;
	NewINS( pCB, MOVHI((SI32)(SI16)(((tmp1 >> 16)&0x0ffff)+((tmp1 & 0x00008000) ? 1 : 0)),3,3) ) ;
	NewINS( pCB, ADDI(((SI16)(tmp1 & 0x0000ffff)),3,3) ) ;

	NewINS( pCB,  NOP()->SetLabel( s2 ));
	NewINS( pCB, PUSHSP(1,31) ) ;

	NewINS( pCB, STSR(15, db_reg, 3));
	NewINS( pCB,  ANDI(0xffffU, db_reg, db_reg));
	NewINS( pCB,  SATSUBI(0x00B0U,db_reg,db_reg));
	NewINS( pCB,  CMP5(1U,db_reg));
	NewINS( pCB,  BZ9P( label + "_handler_returnsetup_ret")); //DBTRAP
	NewINS( pCB,  CMP5(2U,db_reg));
	NewINS( pCB,  BZ9P( label + "_handler_returnsetup_ret")); //RMTRAP
	NewINS( pCB,  CMP5(4U,db_reg));
	NewINS( pCB,  BZ9P( label + "_handler_returnsetup_ret")); //DBHVTRAP
	NewINS( pCB, STSR(18, db_reg, 3));
	NewINS( pCB, MOV32P("handler_returnsetup", jump_reg));
	NewINS( pCB, JARL32(jump_reg, ret_reg)->SetLabel(label + "_handler_save"));
	NewINS( pCB, NOP()->SetLabel(label + "_handler_returnsetup_ret"));

	return pCB;
}

/**
 * @brief	指定コードブロックにCUビットを書き換える命令を追加する。
 * @param	pCB     命令追加するコードブロック
 * @param	reg     CUビットを書き換える処理に使用するレジスタのインデックス値    
 * @param	cubits  CUビット値
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::SwitchCoProcessor(CCodeBlock* pCB, UI32 reg, UI32 cubits) {
	
	FROG_ASSERT(pCB);
	
	reg &=0x1e; // take even index
	reg = (reg & 0x1e) ? (reg & 0x1e) : 6;
	NewINS( pCB, STSR( 5, reg, 0) );
	NewINS( pCB, MOV32(0xFFF8FFFFU,(reg+1)) );
	NewINS( pCB, AND((reg+1), reg) );
	NewINS( pCB, MOV32((cubits<<16),(reg+1)) );
	NewINS( pCB, OR((reg+1), reg) );
	NewINS( pCB, LDSR( reg, 5, 0) );
	
	return pCB;
}


/**
 * @brief	指定コードブロックにユーザーモード遷移する命令を追加する。
 * @param	pCB     命令追加するコードブロック
 * @param	reg     CUビットを書き換える処理に使用するレジスタのインデックス値    
 * @param	cubits  CUビット値
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::TransUserMode(CCodeBlock* pCB, UI32 reg1, UI32 reg2, TBlockConfig* pCfg) {
	
	FROG_ASSERT(pCB);
	std::string contextStr = GetTContext(pCfg);
	std::string lbl = contextStr + "start_um";
	
	NewINS( pCB, MOV32P(lbl.c_str(), reg1) );	// 
	NewINS( pCB, ADDI(4,reg1,reg1) );			// Next address of eiret(32b).
	NewINS( pCB, LDSR(reg1, 0, 0) );			// ldsr reg2, EIPC
	NewINS( pCB, STSR(5, reg1, 0) );			// stsr PSW,  reg1
	NewINS( pCB, MOV32(0x40000000, reg2) );		// mov  0x80000000, reg2
	NewINS( pCB, OR(reg1, reg2) );				// or   reg1, reg2
	NewINS( pCB, LDSR(reg2, 1, 0) );			// ldsr reg2, EIPSW
	NewINS( pCB, EIRET()->SetLabel(lbl.c_str()));
	
	return pCB;
}

/**
* @brief    Transfer to corresponding Guest Mode with GPID
*/
CCodeBlock* CBlockManager::TransGuestMode(CCodeBlock* pCB, UI32 reg1, UI32 reg2, TBlockConfig * pCfg) {

    FROG_ASSERT(pCB);
    std::string contextStr = GetTContext(pCfg);
    std::string lbl = contextStr + "start_gm";
    UI32 pswh = 0x80000000;
    pswh |= (pCfg->m_GMID << 8);

    NewINS(pCB, MOV32P(lbl.c_str(), reg1));	// 
    NewINS(pCB, ADDI(4, reg1, reg1));	    // Next address of eiret(32b).
    NewINS(pCB, LDSR(reg1, 0, 0));			// ldsr reg2, EIPC
    NewINS(pCB, STSR(15, reg1, 0));			// stsr PSWH,  reg1
    NewINS(pCB, MOV32(pswh, reg2));
    NewINS(pCB, OR(reg1, reg2));			// or   reg1, reg2
    NewINS(pCB, LDSR(reg2, 18, 0));			// ldsr reg2, EIPSWH
    NewINS(pCB, STSR(5, reg1, 0));
    NewINS(pCB, LDSR(reg1, 1, 0));          // EIPSW
    NewINS(pCB, EIRET()->SetLabel(lbl.c_str()));

    return pCB;
}
/**
 * @brief	MPU設定コードの生成
 * @param	pCB     命令追加するコードブロック
 * @param	reg     処理に使用するレジスタのインデックス値    
 * @param	pCfg    設定情報
 * @param	m_mp_table 設定データ配列のポインタ。m_mp_table[0〜15][0]がMPLAx。m_mp_table[0〜15][1]がMPLAx。m_mp_table[0〜15][2]がMPLAx。m_mp_table[16][0〜2]がMPPRTx。
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::MpuConfig(CCodeBlock* pCB , UI32 reg , TBlockConfig* pCfg ) {
    char str[80];
    UI32 val;
    UI32 sel = 5, sr = 20;
    IInstruction * ins;
    UI32 mpnum = g_hwInfo.m_mpnum;

    if (pCfg->m_bGM) {
        ISimulator* pSim = g_sim->GetSimulator();
        // each entry has 3 regester (MPLA, MPUA, MPAT) which need to initialize
        // we use 4 byte to store value of each register
        MEMADDR mem = pSim->FindVacantMemory(mpnum * 3 * 4, 4);
        NewINS(pCB, MOV32(mem, reg));

        for (UI32 mpidx = 0; mpidx < mpnum; mpidx++) {
            for (UI32 idx = 0; idx < 3; idx++) {
                val = m_mp_table[mpidx][idx];
                pSim->PresetMemory(true, 0, mem, 4, val);
                mem = mem + 4;
            }
        }

        ins = LDM_MP(reg, 0, mpnum - 1);
        NewINS(pCB, ins);

    } else {

        for (UI32 mpidx = 0; mpidx < mpnum; mpidx++) {

            NewINS(pCB, ins = MOV32(mpidx, reg));
            sprintf(str, "MPIDX= 0x%08x", mpidx);
            ins->AppendComment((LPCTSTR)str);
            NewINS(pCB, LDSR(reg, 16, 5));

            val = m_mp_table[mpidx][0];
            NewINS(pCB, ins = MOV32(val, reg));
            sprintf(str, "MPLA%d= 0x%08x", mpidx, val);
            ins->AppendComment((LPCTSTR)str);
            NewINS(pCB, LDSR(reg, sr, sel));

            val = m_mp_table[mpidx][1];
            NewINS(pCB, ins = MOV32(val, reg));
            sprintf(str, "MPUA%d= 0x%08x", mpidx, val);
            ins->AppendComment((LPCTSTR)str);
            NewINS(pCB, LDSR(reg, sr + 1, sel));

            val = m_mp_table[mpidx][2];
            NewINS(pCB, ins = MOV32(val, reg));
            sprintf(str, "MPAT%d= 0x%08x", mpidx, val);
            ins->AppendComment((LPCTSTR)str);
            NewINS(pCB, LDSR(reg, sr + 2, sel));
        }
    }

    return pCB;
}


/**
 * @brief	MMU設定コードの生成
 * @param	pCB     命令追加するコードブロック
 * @param	reg     処理に使用するレジスタのインデックス値    
 * @param	pCfg    設定情報
 * @param	tlb_setting ＴＬＢエントリー情報リストへのポインタ。
 * @return  追加されたコードブロック（入力コードブロック）
 */
CCodeBlock* CBlockManager::MmuConfig(CCodeBlock* pCB , UI32 reg , TBlockConfig* pCfg ) {
	std::string contextStr = GetMContext(pCfg);
	
	NewINS( pCB, JARL22P( contextStr + "set_work_ptr", 31));
	UI32 memreg=    (reg != 16) ? 16 : 22 ;
	UI32 slot_reg=  (reg != 17) ? 17 : 22 ;
	UI32 count_reg= (reg != 18) ? 18 : 22 ;
	UI32 item_reg=  (reg != 19) ? 19 : 22 ;
	UI32 index_reg= (reg != 20) ? 20 : 22 ;
	UI32 table_reg= (reg != 21) ? 21 : 22 ;

	NewINS( pCB, MOVHI((SI32)(SI16)0x8000,0 ,reg) );
	NewINS( pCB, LDSR(reg, 15 ,1) );					// VCSEL.NC= 1 ;

	//!・Clear V-bit
	NewINS( pCB, LDVC_SR(0, 7 ,4) );					// TEHI1= 0 ;
	NewINS( pCB, MOVEA(64, 0 ,reg));
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_01" ));
	NewINS( pCB, LDVC_SR(reg, 0 ,4) );					// TEBIDX= *(memreg) ;
	NewINS( pCB, TLBW() );
	NewINS( pCB, ADD5(-1, reg) );
	NewINS( pCB, BC17P( contextStr + "mmu_setting_01" ));

	//!・Set TLB-Entry
	NewINS( pCB, MOVR(0, index_reg) );
	NewINS( pCB, MOV32P( contextStr + "tlb_setting_index" ,memreg) );
	NewINS( pCB, LDH16(0 ,memreg ,slot_reg) ) ;		// GR[slot_reg]= *(insigned short *)(GR[memreg]) ;
	NewINS( pCB, ADD5( 4, memreg) );				// GR[memreg] += 4 ;
	NewINS( pCB, CMP5(0 ,slot_reg) ) ;				// if (GR[slot_reg] == 0) then "HALT" ;
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_11"));
	NewINS( pCB, HALT()->SetLabel( contextStr + "mmu_setting_10") );
	NewINS( pCB, BR9P( contextStr + "_mmu_setting_10") );
	NewINS( pCB, NOP());
	NewINS( pCB, NOP());
	//!・DemandSlot情報を設定
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_11") );
	NewINS( pCB, LDH16(0 ,memreg ,count_reg) ) ;	// GR[count_reg]= *(insigned short *)(GR[memreg]) ;
	NewINS( pCB, LDH16(2 ,memreg ,item_reg) ) ;		// GR[item_reg]=  __tlb_setting_table + *(unsigned short *)(GR[memreg]+2) * 4 ;
	NewINS( pCB, SHL5(4 ,item_reg) ) ;
	NewINS( pCB, MOV32P( contextStr + "tlb_setting_table" ,reg) );
	NewINS( pCB, ADD(reg , item_reg) );
	NewINS( pCB, STH16(0 ,g_wm.OFS_DTLB_INFO ,27) ) ;
	NewINS( pCB, STH16(count_reg ,g_wm.OFS_DTLB_INFO+2 ,27) ) ;
	NewINS( pCB, ADDI(g_wm.OFS_DTLB_INFO+4 ,27 ,table_reg) );
	//TODO: index_regは、乱数で空いているTLBを探して決める。
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_12") );
	NewINS( pCB, LDVC_SR(index_reg, 0 ,4) );		// TLBIDX= index_reg ;
	NewINS( pCB, STH16(index_reg ,0 ,table_reg) ) ;
	NewINS( pCB, ADD5(1, index_reg) );
	//
	NewINS( pCB, LDW16(0 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 5 ,4) );				// TELO1= *(memreg) ;
	NewINS( pCB, LDW16(4 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 4 ,4) );				// TELO0= *(memreg +4) ;
	NewINS( pCB, LDW16(8 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 7 ,4) );				// TEHI1= *(memreg +8) ;
	NewINS( pCB, LDW16(12 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 6 ,4) );				// TEHI0= *(memreg +12) ;
	NewINS( pCB, TLBW() );
	NewINS( pCB, ADDI(0x0010, item_reg, item_reg) );
	NewINS( pCB, ADD5(2, table_reg) );
	NewINS( pCB, ADD5(-1, count_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_12"));
	NewINS( pCB, ADD5( 4, memreg) );
	NewINS( pCB, ADD5(-1, slot_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_21"));
	NewINS( pCB, HALT()->SetLabel( contextStr + "mmu_setting_13"));
	NewINS( pCB, BR9P( contextStr + "mmu_setting_13"));
	NewINS( pCB, NOP());
	NewINS( pCB, NOP());


	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_21") );
	NewINS( pCB, LDH16(0 ,memreg ,count_reg) ) ;	// GR[count_reg]= *(insigned short *)(GR[memreg]) ;
	//TODO: ＴＬＢエントリー数制限が必要
	NewINS( pCB, LDH16(2 ,memreg ,item_reg) ) ;		// GR[item_reg]=  __tlb_setting_table + *(unsigned short *)(GR[memreg]+2) * 4 ;
	NewINS( pCB, SHL5(4 ,item_reg) ) ;
	NewINS( pCB, MOV32P( contextStr + "tlb_setting_table" ,reg));
	NewINS( pCB, ADD(reg , item_reg) );
	
	NewINS( pCB, CMP5(0 ,count_reg) ) ;
	NewINS( pCB, BE17P( contextStr + "mmu_setting_90") );
	//TODO: index_regは、乱数で空いているTLBを探して決める。
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_22") );
	NewINS( pCB, LDVC_SR(index_reg, 0 ,4) );		// TLBIDX= index_reg ;
	NewINS( pCB, ADD5(1, index_reg) );
	//
	NewINS( pCB, LDW16(0 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 5 ,4) );				// TELO1= *(memreg) ;
	NewINS( pCB, LDW16(4 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 4 ,4) );				// TELO0= *(memreg +4) ;
	NewINS( pCB, LDW16(8 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 7 ,4) );				// TEHI1= *(memreg +8) ;
	NewINS( pCB, LDW16(12 ,item_reg ,reg) ) ;
	NewINS( pCB, LDVC_SR(reg, 6 ,4) );				// TEHI0= *(memreg +12) ;
	NewINS( pCB, TLBW() );
	NewINS( pCB, ADDI(0x0010, item_reg, item_reg) );
	NewINS( pCB, ADD5(-1, count_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_22"));
	NewINS( pCB, ADD5( 4, memreg) );
	NewINS( pCB, ADD5(-1, slot_reg) );
	NewINS( pCB, BNE17P( contextStr + "mmu_setting_21"));
	//!・ITLBE デマンド・エントリー情報をクリア
	NewINS( pCB, MOV5(-1 ,reg) ) ;
	NewINS( pCB, MOV32(g_wm.BASE_PE_HT,table_reg) ) ;
	NewINS( pCB, MOVEA(64, 0 ,count_reg) );
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_30") );
	NewINS( pCB, STW16(reg ,g_wm.OFS_ITLB_INFO ,table_reg ) );
	NewINS( pCB, ADDI(g_wm.SIZE_HT, table_reg ,table_reg) );
	NewINS( pCB, ADD5(-1 ,count_reg) ) ;
	NewINS( pCB, BNC17P( contextStr + "mmu_setting_30") );
	//
	NewINS( pCB, NOP()->SetLabel( contextStr + "mmu_setting_90") );
	NewINS( pCB, STSR(0 ,reg ,1) );					// MCFG0.MM= 1 ;
	NewINS( pCB, ORI(8,reg,reg) );	
	NewINS( pCB, LDSR(reg, 0 ,1) );


	//!▽リターン。<BR><BR>
	return (pCB) ;
}


std::vector<CPrologueBlock*>* CBlockManager::GeneratePrologue( TBlockConfig* pCfg ) {
	//!<BR>[処理細目]<BR>

	std::vector<CPrologueBlock*>* vNode = new std::vector<CPrologueBlock*>();
	std::string contextStr = GetMContext(pCfg);
	CPrologueBlock* pPB = new CPrologueBlock( contextStr + "prologue" );
	UI32 reg = g_rnd.GetRange((UI32)7,(UI32)15);

    // Break Channel INIT
	if(g_exp->GetBreakPointWeight())
		NewINS(pPB, DBTRAP()->SetLabel("break_channel_init"));
	else
		NewINS(pPB, NOP()->SetLabel("break_channel_init"));
	if (pCfg->m_bNC != true) {	
		NewINS( pPB, NOP() );

		if ( CU1isON() ) {
			SwitchCoProcessor(pPB, reg, 3);	// Enable Co-Processor
		}else{
			SwitchCoProcessor(pPB, reg, 1);	// Enable Co-Processor
		}

		NewINS( pPB, NOP() );
		
		// PSW.EBVを設定する
		NewINS( pPB, STSR(5, reg, 0)->Note("PSW->") );
		NewINS( pPB, ORI(0x8000, reg, reg) );
		NewINS( pPB, LDSR(reg, 5, 0)->Note("->PSW"));
		
		// EBASEを設定する
		NewINS( pPB, MOV32P("NM_vector_reset", reg) );
		NewINS( pPB, LDSR(reg, 3, 1)->Note("->EBASE") );
		NewINS( pPB, NOP() );

		//GMEBASE
		NewINS(pPB, MOV32P("GM00_vector_reset", reg) );
		NewINS( pPB, LDSR(reg, 19, 9)->Note("->GMEBASE") );
		NewINS( pPB, NOP() );


		// CTBP設定しておく
		NewINS(pPB, MOV32P("COMMON_callt_00", 8) );
		NewINS(pPB, LDSR(8, 20, 0)->Note("->CTBP"));	// CTBP

		// スレッド処理へ
		NewINS( pPB, MOV32P( GetTContext(pCfg) + "synchronized", reg) );
		NewINS( pPB, JMP32(reg) );		
		vNode->push_back(pPB);
		return vNode;
	}


	if (1) {
		// CTBP設定しておく
		NewINS(pPB, MOV32P("COMMON_callt_00", 8) );
		NewINS(pPB, LDSR(8, 20, 0)->Note("HT0:CTBP"));	// CTBP
	}



	 // Updated RBIP for Register bank feature.
	if (g_RegisterBankAddr.Count()) {	
		NewINS(pPB, MOV32(g_RegisterBankAddr.SelectValue(), 8) );
	} else {
		const UI32 BankSizeMax = (0x90 << 8);	  // maximum each bank size 0x90  and there 255 banks.
		std::set<MEMRANGE> smr = g_StorableAddr.KeySet();
		std::set<MEMRANGE>::iterator sitr;
		std::vector<MEMADDR> vRBIP;

		for (sitr = smr.begin(); sitr != smr.end(); sitr++) {
			MEMADDR alignedAddr = ((sitr->first | 0x000000ff) + 1);	 // upper boundary alignment.
			if ((sitr->second - alignedAddr) >= BankSizeMax ){
				vRBIP.push_back( g_rnd.GetRange(alignedAddr + BankSizeMax, sitr->second) );
			}
		}
		if (vRBIP.size())  {
			MEMADDR  RBIP = vRBIP[g_rnd.GetRange((UI32)0, (UI32)vRBIP.size() - 1)]; 
			NewINS(pPB, MOV32(RBIP, 8) );
		} else {
			MSG_WARN(0, "Cam not find valid memory area for RBIP. RESBANK instruction will be omitted.\n");
			m_nrmSet.SetWeight(INS_ID_RESBANK, 0);
		}
	}
	NewINS(pPB, LDSR(8, 18, 2));			// RBIP
	if(m_nrmSet.GetWeight(INS_ID_RESBANK) > 0)
		NewINS(pPB, NOP()->Note("Preset_Register_Bank_Area_000"));	// NOP

     //!・When MPU is installed, generate prologue processing for MPU
    if (m_MmList.Size()) {
        InitMPURegister(pPB, pCfg);

        UI32 init_mpbk = g_srs->GetNcInit(17, 5) & 0x3;
        // Change MPU bank
        // if MPBK.BK = 0, (0 + 1) % 2 = 1
        // if MPBK.BK = 1, (1 + 1) % 2 = 0
        init_mpbk = (init_mpbk + 1) % 2;
        NewINS(pPB, MOV5(init_mpbk, reg));
        NewINS(pPB, LDSR(reg, 17, 5));
        // Initialzise new MPU bank
        InitMPURegister(pPB, pCfg);
        // Revert MPU bank
        init_mpbk = (init_mpbk + 1) % 2;
        NewINS(pPB, MOV5(init_mpbk, reg));
        NewINS(pPB, LDSR(reg, 17, 5));

        // set new value for MPIDX if it is same as reserve entry 
        UI32 curMPIDx = g_hwInfo.m_mpnum - 1;  // default is value of convention mode
        if (pCfg->m_bGM) curMPIDx = g_srs->GetNcInit(16, 5);
        UI32 newMPIDX = curMPIDx;

        while (g_prf->IsWorkMPURegionByIdx(newMPIDX)) {
            newMPIDX = g_rnd.GetRange((UI32)0, (UI32)g_hwInfo.m_mpnum - 1);
        }
        if (newMPIDX != curMPIDx) {
            NewINS(pPB, MOV32(newMPIDX, reg));
            NewINS(pPB, LDSR(reg, 16, 5));
        }
    }

	//!・MMUを搭載している場合、MMU向けプロローグ処理を生成
	if (g_hwInfo.m_tlbnum != 0) {
		bool ret= m_MmList.LoadTlbInfo( &m_tlb_setting ,m_pWeightSet) ;
		if ((ret)&&(m_tlb_setting.Size() != 0)) {
			CConstDataBlock* pTable ;
			CConstDataBlock* pTable2 ;
			pTable = new CConstDataBlock( contextStr + "tlb_setting_table" );
			pTable2= new CConstDataBlock( contextStr + "tlb_setting_index" );
			pTable->SetOutputFlag(true);
			pTable2->SetOutputFlag(true);
	
			char str[80] ;
			IInstruction * ins ;
			UI32 total_info= 0 ;
			UI32 num_slot= m_tlb_setting.Size() ;
			NewINS( pTable2 , _WORD((UI32)num_slot));
			for (UI32 slot= 0 ;slot < num_slot ;slot++) {
				CParserTlbSlot * pSlot= m_tlb_setting.Get( slot ) ;
				UI32 num_info= pSlot->Size() ;
				NewINS( pTable2 , _WORD(((total_info << 16) + num_info)));
				total_info += num_info ;
				for (UI32 i= 0 ;i < num_info ;i++) {
					CParserTlbInfo * pInfo= pSlot->Get( i ) ;
					NewINS( pTable ,     _WORD(pInfo->m_telo1));
					NewINS( pTable ,     _WORD(pInfo->m_telo0));
					NewINS( pTable ,     _WORD(pInfo->m_tehi1));
					NewINS( pTable , ins=_WORD(pInfo->m_tehi0));
					sprintf( str ,"Slot%02d_McnX_AsXXX" ,slot ) ;
					ins->AppendComment(str);
				}
			}
			vNode->push_back(pTable2);
			vNode->push_back(pTable);
	
			pTable = new CConstDataBlock( contextStr + "random_table");
			pTable->SetOutputFlag(true);
			for (UI32 i= 0 ;i < 256 ;i++) {
				NewINS( pTable , _WORD(g_rnd.GetRange((UI32)0,(UI32)~0U)));
			}
			vNode->push_back(pTable);
			MmuConfig(pPB , reg , pCfg ) ;
		}
	}

	// NCでのVMセットアップ
	if (g_prf->IsVmSimulation() != true) {
		// NATIVE
		//!・CUビットを書き換える命令を生成
		SwitchCoProcessor(pPB, reg, 3);	// Enable Co-Processor

		//!・ prefix + "synchronized" にジャンプする命令を生成
		NewINS( pPB, MOV32P( (GetTContext(pCfg) + "synchronized").c_str(), reg) );
		NewINS( pPB, JMP32(reg) );
	}else{
		
		// TODO:VMループを構成
		
		UI32		r8 = 8;
		// VIRTUAL
		NewINS(pPB, MOV32(0x00000100, r8) );	
		NewINS(pPB, LDSR(r8, 16, 1)->Note("->VMPRT0"));
		
		#if 0 // TODO: G4P Not Exist
		NewINS(pPB, MOV32(0x00000000, r8) );	
		NewINS(pPB, LDSR(r8, 23, 1)->Note("->VMSCCTL"));
		
		NewINS(pPB, MOV5(0x00000000, r8) );	
		NewINS(pPB, LDSR(r8, 24, 1)->Note("->VMSCTBL0")); 
		#endif

		NewINS(pPB, MOV5(0x00000000, r8) );
		NewINS(pPB, LDSR(r8, 15, 1)->Note("->VCSEL")); 
		
		NewINS(pPB, MOV32P("V00_vector_reset", r8) );
		NewINS(pPB, LDVC_SR(r8, 2, 1)->Note("->VC:RBASE")); 		
		
		UI32 MCTL ;
		{
			UI32 EN		= 1 << 31;
			UI32 MT		= 1 << 30;
			UI32 STID	= 0 << 16;
			UI32 MA		= 0 <<  1;
			UI32 UIC	= 0 <<  0;
			MCTL = (EN | MT | STID | MA | UIC);
		}
		NewINS(pPB, MOV32(MCTL, r8) );
		NewINS(pPB, LDVC_SR(r8, 5, 1)->Note("->VC:MCTL"));	//
		
		UI32 MCFG0 ;
		{
			UI32 SPID	= 0 << 16;
			UI32 MM		= 0 <<  3;
			UI32 HVP	= 1 <<  2;
			UI32 HVCE	= 1 <<  1;
			UI32 HVTE	= 1 <<  0;
			MCFG0 = (SPID | MM | HVP | HVCE | HVTE);
		}
		NewINS(pPB, MOV32(MCFG0, r8) );
		NewINS(pPB, LDVC_SR(r8, 0, 1));	// VC:MCFG0		
		
		UI32 TCSEL = 0;
		NewINS(pPB, MOV32(TCSEL, r8) );
		NewINS(pPB, LDSR(r8, 10, 1));	// TCSEL <- 0

		UI32 HTCTL ;
		{
			UI32 EN		= 1 << 31;
			UI32 HLT	= 0 << 30;
			HTCTL		= (EN | HLT);
		}
		
		NewINS(pPB, MOV32(HTCTL, r8) );
		NewINS(pPB, LDTC_SR(r8, 5, 2));	// TC0:HTCTL
		
		// TODO: スレッドのPC設定方法（ラベルをどう取得するか？）！
		NewINS(pPB, MOV32P("V00_vector_reset", r8) );
		NewINS(pPB, LDTC_PC(r8));	// TC0:PC		
		// TC:HTPC

		// TODO: スレッドのPC設定方法（ラベルをどう取得するか？）！
		NewINS(pPB, MOV32P("NM_epilogue", r8) );
		NewINS(pPB, LDSR(r8, 0, 0));	// NC:EIPC		

		UI32 VM		=  1 << 31;
		UI32 UM		=  0 << 30;
		UI32 HVC	=  0 << 19;
		UI32 CU		=  0 << 16;
		UI32 EBV	=  1 << 15;
		UI32 FLGS	= 32 <<  0;
		UI32 EIPSW	= (VM | UM | HVC | CU | EBV | FLGS);
		NewINS(pPB, MOV32(EIPSW, r8) );
		NewINS(pPB, LDSR(r8, 1, 0));	// EIPSW
		NewINS(pPB, EIRET());
		//NewINS(pPB, NOP()->SetLabel(contextStr + "_next") );
				
	}
	
	//!▽リターン。<BR><BR>
	//std::for_each (vNode->begin(), vNode->end(), [](INode* p){p->SetOutputFlag(true);}); 
	vNode->push_back(pPB);
	return vNode;
};


std::vector<CSyncBlock*>* CBlockManager::GenerateSync( TBlockConfig* pCfg ) {
	std::vector<CSyncBlock*>* vNode = new std::vector<CSyncBlock*>();
	std::string contextStr = GetTContext(pCfg);
	
	CSyncBlock* pSB = new CSyncBlock( contextStr + "synchronized");
	
	//!・ ＰＥ同期処理
	IInstruction* pIns = NOP();
	pIns->AppendComment("Wait other PE to start simulation.");
	NewINS ( pSB, pIns );

    if (pCfg->m_bNC) {
        // NM生成時
        AddPeNotifyStandby(pCfg, pSB);					// 自ＰＥ準備完了フラグをセット

        if (g_cfg->m_nSysPeNum != 0) {
            // マスターＰＥは他のＰＥの準備完了をチェックする。
            AddPeWaitStandby(pCfg, pSB);                // 全ＰＥ準備完了待ち
            AddSysNotifyStandby(pCfg, pSB);             // 全ＰＥ準備完了フラグをセット
        } else {
            // マスターＰＥ以外はマスターＰＥがチェック完了するのを待つ。
            AddWaitStandby(pCfg, pSB);                  // 全ＰＥ準備完了フラグのセット待ち
        }
    } else {
        // VM生成時
        AddHtNotifyStandby(pCfg, pSB);					// 自ＨＴ準備完了フラグをセット

        if ((pCfg->m_VCID == 0) && (pCfg->m_HTID == g_prf->GetMasterThreadNo(0))) {
            // VMのマスタースレッド
            AddHtWaitStandby(pCfg, pSB);			    // 自ＰＥ内全ＴＨ準備完了待ち
            AddPeNotifyStandby(pCfg, pSB);			    // 自ＰＥ準備完了フラグをセット
            if (g_cfg->m_nSysPeNum != 0) {
                // マスターＰＥのマスタースレッドは他のＰＥの準備完了をチェックする。
                AddPeWaitStandby(pCfg, pSB);            // 全ＰＥ準備完了待ち
                AddSysNotifyStandby(pCfg, pSB);         // 全ＰＥ準備完了フラグをセット
            } else {
                // マスターＰＥ以外のマスタースレッドはマスターＰＥがチェック完了するのを待つ。
                AddWaitStandby(pCfg, pSB);              // 全ＰＥ準備完了フラグのセット待ち
            }
        } else {
            // マスタースレッド以外はマスタースレッドがチェック完了するのを待った後、マスターＰＥのマスタースレッドがチェック完了するのを待つ。
            AddHtWait2Standby(pCfg, pSB);			    // 自ＰＥ準備完了フラグをセット待ち
            AddWaitStandby(pCfg, pSB);                  // 全ＰＥ準備完了フラグのセット待ち
        }
    }
	
	SyncStandbyGoNext(pCfg, pSB);                       //!・ "__codeblock_0" にジャンプする命令を生成
	
	vNode->push_back(pSB);

    if (g_cfg->m_bPrefAssist) {
    	//! Prefech
    	pSB = new CSyncBlock(contextStr + "PrefetchMode");
    	NewINS( pSB, JMP32(31) ); // return code
    	vNode->push_back(pSB);
    }
	//[TN]TODO: Disable MPM block
	pSB = new CSyncBlock(contextStr + "disable_mpu");
	pSB->SetOutputFlag(true);
	NewINS( pSB, LDSR(0, 8, 1));	// Disable SVLOCK
	NewINS( pSB, LDSR(0, 0, 5));	// Disable MPM
	NewINS( pSB,  SYNCI());
	NewINS( pSB, JMP32(31) ); // return code
	vNode->push_back(pSB);

    pSB = new CSyncBlock(GetMContext(pCfg) + "permit_exec_cur_PC");
    pSB->SetOutputFlag(true);
    {
        UI32 reg = m_nHandlerReg;
        UI32 pc_reg = reg + 1;
        UI32 mip_demand_gm = g_prf->m_mpdemand[0];
        UI32 newMPIDx = g_hwInfo.m_mpnum - 1;
        while (g_prf->IsWorkMPURegionByIdx(newMPIDx)) {
            newMPIDx = g_rnd.GetRange((UI32)0, (UI32)g_hwInfo.m_mpnum - 1);
        }
        // Guest management
        NewINS(pSB, MOV32(mip_demand_gm, reg));
        NewINS(pSB, LDSR(reg, 16, 5));				// MPIDX
        NewINS(pSB, SATSUBI(0xBF4, pc_reg, reg));	// Calculate lower boundary
        NewINS(pSB, LDSR(reg, 20, 5));				// MPLA
        NewINS(pSB, ADDI(0xBF4, pc_reg, reg));		// [FROG]TODO: Fix me (0xBF4)
        NewINS(pSB, LDSR(reg, 21, 5));				// MPUA

        NewINS(pSB, MOV32(newMPIDx, reg));			// Randomize not constrainted MPIDX
        NewINS(pSB, LDSR(reg, 16, 5));			// MPIDX
        NewINS(pSB, SYNCI());
        NewINS(pSB, JMP32(pc_reg));				// return code
    }
    vNode->push_back(pSB);

	return vNode;
}

CUserBlock* CBlockManager::GenerateUserBlock(LPCTSTR context_key, TBlockConfig* pCfg, std::string labelStr) {

	std::string label("");
	std::stringstream ss;
	ss << GetTContext(pCfg);
	ss << labelStr;
	ss >> label;

	CUserBlock* pUb = new CUserBlock(label);
	pUb->SetOutputFlag(true);
	pUb->EnableRegulation(false);
	pUb->SetKeyName(context_key, labelStr.c_str());

	if(labelStr != "uc_handler") {
		const UI32 ADDR = g_wm.BASE_PE + g_wm.SIZE_PE;
		UI32 reg = 5;

		NewINS(pUb, MOV32(ADDR, reg));
		NewINS(pUb, STW16(31, 0, reg)); // Backup r31

		// Insert User Code to simulate
		std::vector <std::string>	vUcBody;
		g_usf->GetUserCodeBody(labelStr, vUcBody);
		ParseUserCode(vUcBody, pUb);

		NewINS(pUb, MOV32(ADDR, reg));
		NewINS(pUb, LDW16(0, reg, 31)); // Restore r31
		NewINS( pUb, JMP32(31) );
	} else {
		// Generate Handler User code Area section.
		pUb->SetOutputFlag(false);
		GetUserHanlderBody(CLabel::m_prefix + "_usercode_area", pUb);
	}
	
	return pUb;
}
std::vector<CPreloadBlock*>* CBlockManager::GenerateSetupBlock(TBlockConfig* pCfg) {
	UI32 reg = m_nWorkReg;
	std::string contextStr = GetMContext(pCfg);

	std::vector<CPreloadBlock*>* vNode = new std::vector<CPreloadBlock*>();
	CPreloadBlock* pPB = nullptr;

	pPB = new CPreloadBlock("debug_breaksetup" );
	pPB->SetOutputFlag(true);
	pPB->EnableRegulation(false);
	NewINS( pPB, MOV32P("debug_breaksetup_ret", reg));
	NewINS( pPB, JMP32(reg));
	NewINS( pPB, NOP() );
	vNode->push_back(pPB);

	pPB = new CPreloadBlock("handler_returnsetup" );
	pPB->SetOutputFlag(true);
	NewINS( pPB, JMP32(reg));
	NewINS( pPB, NOP() );
	vNode->push_back(pPB);

	return vNode;

}


std::vector<CCodeBlock*> CBlockManager::GenerateRandomBlock(TBlockConfig* pCfg) {

	
	UI32 nFixedReg1 = 0, nFixedReg2 = 0;
	COprSR::m_pSrSource = pCfg->m_pSrSet;
	std::vector<CCodeBlock*> vRandomBlock;
	std::string labelStr("");
	std::stringstream ss;
    pCfg->m_bNC = false;
	ss << GetTContext(pCfg);
	ss << "codeblock_";
	ss << std::dec << std::setw(2) << std::setfill('0') << (pCfg->N);
	ss >> labelStr;
    pCfg->m_bNC = true;
	if (pCfg->m_bNC && g_prf->IsVmSimulation()) {
		// VMシミュレーション時のネイティブコンテキストにランダム部は生成しない
		CCodeBlock* pCB = new CCodeBlock();
		for (int i = 0; i < 8; i++) {
			NewINS( pCB, NOP() );
		}
		pCB->SetLabel(labelStr);
		vRandomBlock.push_back(pCB);
		return vRandomBlock;
	}

	// UserMode && NO PIE
    if (g_prf->IsUserMode(pCfg->m_bGM, pCfg->m_GMID)) {
		// WeightSet 
		// User MODE - filter SV/HV INS
		BS_IPRV bsp(0);
		bsp[IInstruction::IPRIV_SV]	= 1;
		bsp[IInstruction::IPRIV_HV]	= 1;
		bsp[IInstruction::IPRIV_DB]	= 1;
		m_nrmSet.FilterPriviledge(bsp, 0);
		m_nrmSet.ReCalc();
		//pset->Dump();
	}

	CCodeBlock* pCB;
	switch (g_cfg->m_nBlockMix) {
	case 0:		// free
		pCB = GenerateGrBlock(pCfg->N, 0, pCfg->InsNum, 0, pCfg->pInsSet);
		break;
		
	case 1:		// focus 1 reg
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCB = GenerateGrBlock(pCfg->N, 0, pCfg->InsNum, nFixedReg1, pCfg->pInsSet);
		break;

	case 2:		// mix 2 reg interlaced
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCB = GenerateGrBlock(pCfg->N, 0, pCfg->InsNum/2, nFixedReg1, pCfg->pInsSet);
		nFixedReg2 = g_rnd.GetRange(1U, 31U);
		pCB = this->MixBlock (GenerateGrBlock(pCfg->N, 0, pCfg->InsNum/2, nFixedReg2, pCfg->pInsSet), pCB);
		break;

	default:	// free generation
		pCB = GenerateGrBlock(pCfg->N, 0, pCfg->InsNum, 0, pCfg->pInsSet);
		break;
	}

	// 静的な解析からパタンの整合性をとる
	pCB->SetLabel(labelStr);
	if(pCfg->N == 0)
		pCB->AddOpeCode(DBTAG(), 0); //! Mark as begin of random block #Redmine:65750

	// 複合命令を展開する
	ExpandComplexInstruction(pCB, pCfg);

	std::vector<CCodeBlock*> vRandomCB = g_mgr->BreakDownRandomBlock(pCfg, pCB);
	std::vector<CCodeBlock*>::iterator itr;
	for (itr = vRandomCB.begin(); itr < vRandomCB.end(); itr++) {
		CCodeBlock* pCb = static_cast<CCodeBlock*>(*itr);
		// Expand Sequential Instruction
		ExpandSequentialInstruction(pCb);

		// Support bias register to increase register dependance
		IncRegisterDependance(pCb, nFixedReg1, nFixedReg2);
		
		// Check whether C2B1 is combined by random generation
		CombineC2B1(pCb);

		// 伝搬レジスタを切断する(#10198)
		RemoveRegDependance(pCb);

		// R-Type補正（汎用レジスタの重複（Base = {Step/Index}）を除外）
		RTypeVerify(pCb);

		// JARL補正（Jarlの飛び先を設定する=ラベル化）
		LabelingJarl(pCb, GetMContext(pCfg));

		pCB->SetStatistics(true);
		// Adjust system register
		UpdateAccessSysReg(pCfg, pCb);

		MakeLoopSequence(pCb);
		// Switch補正（SWITCHテーブルの挿入）
		// テーブルとSwitchジャンプ先を結びつけるので
		// これ以後、命令を挿入する場合は注意する 
		SwitchPresetTable(pCb);

		ChainBcondSequence(pCb);// Labelが付いた後

		PresetException(pCb, g_exp.get());

		vRandomBlock.push_back(pCb);
	}

	return vRandomBlock;
}

///**
// * @brief	Break down current block into more smaller code block.
// * @param	- Input: Current code block.
//			- Output: vector of smaller code block.
// */
std::vector<CCodeBlock*> CBlockManager::BreakDownRandomBlock(TBlockConfig* pCfg, CCodeBlock* pCb) {

	std::vector<CCodeBlock*> vCodeBlock ;
	CCodeBlock* pBlock = new CCodeBlock();
	IInstruction	*pIns;
	std::string labelStr;
	UI32 nCounter = 0;

	if (pCb->IsRegulation()){
		pBlock->EnableRegulation(true);
	}

	//!< Checking exp/int and branch/jump instruction.
	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		pIns = pCb->at(i);
		pBlock->AddOpeCode(pIns);
		if(pIns->IsComplex())
			continue;

		if (pIns->Behavior(IInstruction::JMP) && (pIns->GetMne().find("trap") == std::string::npos) && pIns->GetId() != INS_ID_SWITCH 
			&& pIns->GetMne().find("jarl") == std::string::npos	&& pIns->GetId() != INS_ID_DISPOSE_R3 && pIns->GetId() != INS_ID_LOOP 
			&& pIns->InSequence() == false && pIns->InLoop() == false && pIns->GetId() != INS_ID_JRD32 
			&& (pIns->GetMne().find("jmp") == std::string::npos) && pIns->GetId() != INS_ID_CALLT){
			if(nCounter == 0){
				pBlock->SetBreakSetupInsFlag(true);	
				pBlock->SetMainBlock();
				pIns->SetChain();
			}
            // Support C2B1 - C2B1 divide into two parts.
            pIns->SetForwardIns(nullptr);
			std::stringstream ss;
			ss << pCb->GetLabel() << "_";
			ss << std::dec << std::setw(2) << std::setfill('0') << (nCounter++);
			ss >> labelStr;
			// 静的な解析からパタンの整合性をとる
			pBlock->SetLabel(labelStr);
			vCodeBlock.push_back(pBlock);
			pBlock = new CCodeBlock();
			//!< 
			if (pCb->IsRegulation()){
				pBlock->EnableRegulation(true);
			}
		}
	}
	//!< push last small code block.
	if (pBlock->GetInstructionNum()) {
			
		std::stringstream ss;
		ss << pCb->GetLabel() << "_";
		ss << std::dec << std::setw(2) << std::setfill('0') << (nCounter++);
		ss >> labelStr;

		// 静的な解析からパタンの整合性をとる
		pBlock->SetLabel(labelStr);
		vCodeBlock.push_back(pBlock);		
		//pBlock->Dump(std::cout);
		if (pCb->IsRegulation()){
			pBlock->EnableRegulation(true);
		}
	}
	vCodeBlock.back()->SetTailBlock();
	return vCodeBlock;

}


void CBlockManager::IncRegisterDependance(CCodeBlock* pCb, UI32 reg1, UI32 reg2) {

	// Lambda expression to reduce number of register in register list 
	// to user setting value based on register frequence and register index.
	auto SelectRegister = [] (std::map<UI32, std::pair<UI32, bool>> &mUGrR, UI32 maxRegInBlock)
	{
		std::map<UI32,std::pair<UI32, bool>>::iterator mItr;
		std::vector<std::pair<UI32, std::pair<UI32, bool>>> vRegList; // <RegIdx, <RegFreq, fixedFlag>>
		std::vector<std::pair<UI32, std::pair<UI32, bool>>>::iterator vItr;
		UI32	nRmCond, nMaxFreq;
		bool	bFinished = false;

		// Find the maximum frequence
		nMaxFreq = 0;
		auto get_max = [&nMaxFreq] (std::pair<UI32,std::pair<UI32, bool>> itr) 
		{
			if(itr.second.second == false && itr.second.first > nMaxFreq )
				nMaxFreq = itr.second.first;
		};
		std::for_each(mUGrR.begin(), mUGrR.end(), get_max);

		// Remove the register that is used in the least until number of register is (maxRegInBlock - 1)
		nRmCond = 1; // The least frequence
		mItr = mUGrR.begin();
		while(!bFinished)
		{
			// In order to avoid increasing number of used register, GrReg 30 need to keep in list.
			if((mItr->first != 30)
				&& (mItr->second.second == false)
				&& (mItr->second.first == nRmCond))
			{
				// Insert removed register's information to the temporary vector,
				// Then, remove it from the register list.
				vRegList.push_back(std::pair<UI32, std::pair<UI32, bool>> 
					(mItr->first, std::pair<UI32, bool>(mItr->second.first, mItr->second.second)));
				mItr = mUGrR.erase(mItr);
			}
			else {
				mItr++;
			}

			// Stop removing if the remained register is maxRegInBlock - 1.
			if(mUGrR.size() == maxRegInBlock - 1)
				bFinished = true;

			// Finished removing all register with current frequence,
			// Continue with higher frequence.
			if(mItr == mUGrR.end())
			{
				nRmCond++;
				if(nRmCond > nMaxFreq)
					bFinished = true; // To avoid infinitive loop
				mItr = mUGrR.begin();
			}
		}

		// A additional register that is in priority of multi of 4, even, then normal.
		std::random_shuffle(vRegList.begin(), vRegList.end(), g_rnd);
		// Lambda expression for checking multi of 4 register index.
		auto IsMulti_4 = [](std::pair<UI32, std::pair<UI32, bool>> p)->bool {return ((p.first & 3) == 0);};
		// Search the first register whose index is multiple of 4.
		vItr = std::find_if(vRegList.begin(), vRegList.end(), IsMulti_4);
		if(vItr == vRegList.end())
		{
			// If there are no multiple of 4 register, FROG will continue searching even register.
			auto is_Even = [](std::pair<UI32, std::pair<UI32, bool>> p)->bool {return ((p.first & 1) == 0);};
			vItr = std::find_if(vRegList.begin(), vRegList.end(), is_Even);
			if(vItr == vRegList.end())
			{
				// If ther is not multiple of 4 and even register, a random register will be choose.
				vItr = vRegList.begin();
			}
		}
		// Insert register information into register list.
		mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
			(vItr->first, std::pair<UI32, bool>(vItr->second.first, vItr->second.second)));

		return;
	};

	// lambda expression, this function processes for custom instructions that have some constraint for operand.
	// return:
	//	- true: means that the operand is replaced.
	//	- false: the operand is not processed, it will be replace as a normal instruction.
	auto CheckReplaceCustomIns = [](IInstruction* pIns, std::map<UI32, std::pair<UI32, bool>> &mUGrR) -> bool
	{
		UI32 nReg1, nReg2;
		UI32 nRetry, nMembit;
		std::map<UI32, std::pair<UI32, bool>>::iterator mItr;
		UI32 InsId = pIns->GetId();
		if(InsId == INS_ID_CLR1 || InsId == INS_ID_NOT1 || InsId == INS_ID_SET1 || InsId == INS_ID_TST1)
		{
			nReg1 = pIns->opr(0)->Idx();
			nReg2 = pIns->opr(1)->Idx();
			// Incase of custom instruction, there is constraint for 2nd operand.
			if(pIns->opr(0)->GetConstraint() != NULL)
			{
				nMembit = pIns->opr(0)->GetConstraint()->m_nMin;
				if(mUGrR.find(nReg1) == mUGrR.end())
				{
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));
					nRetry = 0;
					// Try to get the register that is not fixed register
					// and it must be not 0 when nMembit is not 0 from register list.
					while(nRetry < mUGrR.size() 
						&& ((mItr->first == 0 && nMembit != 0)  
							|| mItr->second.second == true))
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}
					// If there is no suitable register, add current operand to register list.
					if(nRetry == mUGrR.size())
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
						(nReg1, std::pair<UI32, bool> (1, false)));
					else{
						nReg1 = mItr->first;
						pIns->opr(0)->Replace(nReg1);
					}
				}
				if(nReg2 == nReg1 || mUGrR.find(nReg2) == mUGrR.end())
				{
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));
					nRetry = 0;
					// Try to get a register that is not 0, not fixed register and different from 1st operand from register list.
					while(nRetry < mUGrR.size() && 
						(mItr->first == 0 || mItr->second.second == true || mItr->first == nReg1))
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}
					if(nRetry == mUGrR.size())
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
						(nReg2, std::pair<UI32, bool> (1, false)));
					else
					{
						nReg2 = mItr->first;
						pIns->opr(1)->Replace(nReg2);
					}
				}
				return true;
			}
		}
		return false;
	};

	auto ReplaceMacroArray = [] (IInstruction *pIns, std::map<UI32, std::pair<UI32, bool>> &mUGrR)
	{
		auto checkConstraint = [] (UI32 insid, UI32 reg) -> bool
		{
			if(reg == 0) // Macro array do not used Reg#0.
				return false;
            // If instruction is ld_array or st_array or ls_array
			if(( insid == INS_CID_LD_ARRAY || insid == INS_CID_ST_ARRAY || insid == INS_CID_LS_ARRAY) && ((reg & 1) != 0))
				return false;
           // If instruction is sld_array(Short)or sst_array(Short) or sls_array(Short) or caxi_array
			if((insid == INS_CID_SLD_ARRAY || insid == INS_CID_SST_ARRAY || insid == INS_CID_SLS_ARRAY || insid == INS_CID_CAXI_ARRAY) && (reg == 30))
				return false;
			return true;
		};

		auto Replace = [] (IOperand *pOpr, UI32 newReg) -> bool
		{
			if(pOpr == NULL)
				return false;

			// Update register range
			if(!pOpr->SetRange(newReg, newReg))
                return false;
			// Replace register
			if(!pOpr->Replace(newReg))
				return false;

			return true;
		};
		
		// Lamda function to adjust operand follow C2B1 constraint
		auto C2B1Constraint = [](IInstruction* pIns1, UI32 OprIns1, IInstruction* pIns2, UI32 OprIns2, UI32 newOpr){
			pIns1->opr(OprIns1)->Replace(newOpr);
			pIns2->opr(OprIns2)->Replace(newOpr);
		};

		// Lamda function to get general register
		auto GetGrReg = [&] ( std::map<UI32, std::pair<UI32, bool>> &mUGrR){
			std::map<UI32, std::pair<UI32, bool>>::iterator mItr;
			mItr = mUGrR.begin();
			std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));
			return mItr->first;
			
		};

		ComplexInstruction *pCompIns;
		IInstruction		*pSgleIns;
		IInstruction		*pC2B1Ins_1;
		IInstruction		*pC2B1Ins_2;
		UI32				nCompInsNum, nOpr;
		UI32				srcReg = 0;
		UI32				insid;
		const UI32			ElementPointer = 30;
		IOperand			*pOpr, *pBaseOpr = NULL, *pSecOpr1 = NULL, *pSecOpr2 = NULL;
		std::map<UI32, std::pair<UI32, bool>>::iterator mItr;
		UI32 nRetry;
		UI32 regA = 0, regC = 0;

		pCompIns = static_cast<ComplexInstruction*> (pIns);
		insid = pCompIns->GetId();
		switch(insid)
		{
		case INS_CID_PREF_I:
			// Generate 2 random register that is not 0.
			while(regA == 0){
				mItr = mUGrR.begin();
				std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));
				regA = mItr->first;
			}
			while(regC == 0 || regC == regA){
				mItr = mUGrR.begin();
				std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));
				regC = mItr->first;
			}

			pSgleIns = (*pCompIns)[0];
			Replace(pSgleIns->opr(0), regA);
			Replace(pSgleIns->opr(1), regA);

			pSgleIns = (*pCompIns)[1];
			Replace(pSgleIns->opr(1), regC);

			pSgleIns = (*pCompIns)[2];
			Replace(pSgleIns->opr(1), regA);

			pSgleIns = (*pCompIns)[3];
			Replace(pSgleIns->opr(1), regA);
			Replace(pSgleIns->opr(2), regA);

			pSgleIns = (*pCompIns)[4];
			Replace(pSgleIns->opr(0), regC);
			break;
		case INS_CID_LD_ARRAY:
		case INS_CID_ST_ARRAY:
		case INS_CID_LS_ARRAY:
		case INS_CID_SLD_ARRAY:
		case INS_CID_SST_ARRAY:
		case INS_CID_SLS_ARRAY:
		case INS_CID_CAXI_ARRAY:
			for(nCompInsNum = 0; nCompInsNum < pCompIns->size(); nCompInsNum ++)
			{
				pSgleIns = (*pCompIns)[nCompInsNum];
                pBaseOpr = nullptr;
                pSecOpr1 = nullptr;
                pSecOpr2 = nullptr;
				for(nOpr = 0; nOpr < pSgleIns->GetOpNum(); nOpr++)
				{
					pOpr = pSgleIns->opr(nOpr);
					if(pOpr->IsGR())
						pOpr->GetArrayInsOpr(&srcReg, &pBaseOpr, &pSecOpr1, &pSecOpr2);
				}
				// Generate random register for source operand.
				if(pBaseOpr != NULL && mUGrR.find(pBaseOpr->Idx()) == mUGrR.end())
				{
					if(srcReg == 0) // Source register is not generated.
					{
						// Generate random register from used list.
						mItr = mUGrR.begin();
						std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));

						nRetry = 0;
						// Try to replace register.
						while((nRetry < mUGrR.size()) // Retry until short of register
							&& ((checkConstraint(insid, mItr->first) == false) // Register must be even or other than 30.
								|| (Replace(pBaseOpr, mItr->first) == false))) // Replace failed.
						{
							mItr = next(mItr);
							if(mItr == mUGrR.end())
								mItr = mUGrR.begin();
							nRetry++;
						}

						/* No suitable register in used list to replace. Add register to list.*/
						if(nRetry == mUGrR.size())
						{
							mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
								(pBaseOpr->Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register. 
						}
						// srcReg = pBaseOpr->Idx();
					}
					else // If the source is already generated.
                    {
						// pBaseOpr->Replace(srcReg);
                        Replace(pBaseOpr, srcReg);
                    }
				}
                if(srcReg == 0)
                    srcReg = pBaseOpr->Idx();

				// if(pSecOpr1 != NULL && mUGrR.find(pSecOpr1->Idx()) == mUGrR.end())
                if(pSecOpr1 != NULL && (pSecOpr1->Idx() == srcReg || mUGrR.find(pSecOpr1->Idx()) == mUGrR.end()))
				{
					// Generate random register from used list.
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));

					nRetry = 0;
					// Try to replace register by another that is not fixed register.
					while((nRetry < mUGrR.size()) // Try until short of register
						&& ((mItr->first == srcReg)	// The dest reg must be other than source reg.
							|| (checkConstraint(insid, mItr->first) == false) // Register must be even or other than 30.
							|| (Replace(pSecOpr1, mItr->first) == false))) // Replace failed.
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}

					/* No suitable register in used list to replace. Add register to list.*/
					if(nRetry == mUGrR.size())
					{
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
							(pSecOpr1->Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register. 
					}
				} 
				// if(pSecOpr2 != NULL && mUGrR.find(pSecOpr2->Idx()) == mUGrR.end())
                if(pSecOpr2 != NULL && (pSecOpr2->Idx() == srcReg || pSecOpr2->Idx() == pSecOpr1->Idx() || mUGrR.find(pSecOpr2->Idx()) == mUGrR.end()))
				{ 
					// Generate random register from used list.
					mItr = mUGrR.begin();
					std::advance(mItr, g_rnd.GetRange((UI32)0, mUGrR.size() - 1));

					nRetry = 0;
					// Try to replace register by another that is not fixed register.
					while((nRetry < mUGrR.size()) // Try until short of register
						&& ((mItr->first == srcReg) || (mItr->first == pSecOpr1->Idx())	// The dest reg must be other than source reg/ dest1.
							|| (checkConstraint(insid, mItr->first) == false) // Register must be even or other than 30.
							|| (Replace(pSecOpr2, mItr->first) == false))) // Replace failed.
					{
						mItr = next(mItr);
						if(mItr == mUGrR.end())
							mItr = mUGrR.begin();
						nRetry++;
					}

					/* No suitable register in used list to replace. Add register to list.*/
					if(nRetry == mUGrR.size())
					{
						mUGrR.insert(std::pair<UI32, std::pair<UI32, bool>> 
							(pSecOpr2->Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register. 
					}
				}
			}
			break;
		

		case INS_CID_MOV_ALU:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];
			
			regA = GetGrReg(mUGrR);
			regC = GetGrReg(mUGrR);

			pC2B1Ins_1->opr(0)->Replace(regA);
			pC2B1Ins_2->opr(0)->Replace(regC);

			regA = GetGrReg(mUGrR);

			while( regA == regC || regA == 0)
				regA = GetGrReg(mUGrR);
			
			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 1, regA);
			
			break;

		case INS_CID_MOVR_SHIFT:
			regA = GetGrReg(mUGrR);
			regC = GetGrReg(mUGrR);

			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];

			pC2B1Ins_1->opr(0)->Replace(regA);
			while(regC == 0)
				regC = GetGrReg(mUGrR);
			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 1, regC);

			break;

		case INS_CID_MOV_SST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];
			// Replace operand does not relate to C2B1 instruction constraint.
			for(UI32 i = 0; i < pC2B1Ins_1->GetOpNum()-1; i++){
				regA = GetGrReg(mUGrR);
				pC2B1Ins_1->opr(i)->Replace(regA);
			}

			regA = pC2B1Ins_1->opr(1)->Idx();

			while( regA == ElementPointer || regA == 0){
				regA = GetGrReg(mUGrR);
			}
			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 0, regA);
			while(pC2B1Ins_1->opr(0)->Idx() == ElementPointer)
				pC2B1Ins_1->opr(0)->Replace(g_rnd.GetRange(0, 31));
			
			break;

		case INS_CID_MOV5_ST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];

			regA = GetGrReg(mUGrR);
			while(regA == 0)
				regA = GetGrReg(mUGrR);

			C2B1Constraint(pC2B1Ins_1, 1, pC2B1Ins_2, 0, regA);
			regC = GetGrReg(mUGrR);
			while( regC == pC2B1Ins_2->opr(0)->Idx() || regC == 0){
				regC = GetGrReg(mUGrR);
			}
			pC2B1Ins_2->opr(1)->Replace(regC);

			break;

		case INS_CID_MOVEA_SST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];

			regA = GetGrReg(mUGrR);
			while(regA == ElementPointer || regA == 0)
				regA = GetGrReg(mUGrR);
			C2B1Constraint(pC2B1Ins_1, 2, pC2B1Ins_2, 0, regA);

			break;

		case INS_CID_MOVEA_ST:
			pC2B1Ins_1 = (*pCompIns)[0];
			pC2B1Ins_2 = (*pCompIns)[1];
			// Replace operand does not relate to C2B1 instruction constraint.
			for(UI32 i = 0; i< pC2B1Ins_2->GetOpNum()-1;i++){
				regA = GetGrReg(mUGrR);
				pC2B1Ins_2->opr(i)->Replace(regA);
			}
			regC = GetGrReg(mUGrR);
			while( regC == pC2B1Ins_2->opr(1)->Idx() || regC == 0){
				regC = GetGrReg(mUGrR);
			}
			C2B1Constraint(pC2B1Ins_1, 2, pC2B1Ins_2, 0, regC);
			break;

		case INS_CID_CMP_BCC:
			pC2B1Ins_1 = (*pCompIns)[0];
			// Replace operand does not relate to C2B1 instruction constraint.
			for(UI32 i = 0; i < pC2B1Ins_1->GetOpNum()-1; i++){
				regA = GetGrReg(mUGrR);
				pC2B1Ins_1->opr(i)->Replace(regA);
			}
			break;

		default:
			break;
		}
	};

	UI32 nIns, nOpr;
	IInstruction	*pIns;
	IOperand		*pOpr;
	std::map<UI32, std::pair<UI32, bool>> mUsedGrReg;	// <RegIndex, <RegFreq, fixedFlag>>
	std::map<UI32, std::pair<UI32, bool>>::iterator mItr;

	// Do nothing if max register is 32 (maximum).
	if (32 <= g_cfg->m_nMaxRegInBlock)
		return;

	// Traversing all instructions in code block.
	for(UI32 nIns = 0; nIns < pCb->GetInstructionNum(); nIns++)
	{
		pIns = pCb->at(nIns);
		// Check whether current instruction is complex instruction (array)
		if(pIns->IsComplex())
		{
			ComplexInstruction	*pComplexIns;
			UI32				nCpInsCount;

			pComplexIns = static_cast<ComplexInstruction*> (pIns);
			// Traversing and collect register of all instructions in array.
			for( nCpInsCount = 0; nCpInsCount < pComplexIns->size(); nCpInsCount++ )
			{
				for(UI32 i = 0; i< (*pComplexIns)[nCpInsCount]->GetOpNum();i++)
					(*pComplexIns)[nCpInsCount]->opr(i)->GetGrRegister(&mUsedGrReg);
			}
		}
		else {
			// Get generated register of normal instruction.
			for(UI32 i = 0; i< pIns->GetOpNum();i++)
				pIns->opr(i)->GetGrRegister(&mUsedGrReg);
		}
	}

	// Do nothing if number of used register is smaller than user setting
	if( mUsedGrReg.size() <= g_cfg->m_nMaxRegInBlock)
		return;

	// Set fixedFlag for fixed register
	if(reg1 != 0) // Block-mix is 1 or 2.
	{
		mItr = mUsedGrReg.find(reg1);
		mItr->second.second = true;
	}
	if(reg2 != 0) // Block-mix is 2.
	{
		mItr = mUsedGrReg.find(reg2);
		mItr->second.second = true;
	}

	// Collect used register
	SelectRegister(mUsedGrReg, g_cfg->m_nMaxRegInBlock);

	 // Repeat traversing all instructions
	for(nIns = 0; nIns < pCb->GetInstructionNum(); nIns++) 
	{
		pIns = pCb->at(nIns);
		if(pIns->IsComplex()) // Process for macro array instruction
		{
			ReplaceMacroArray(pIns, mUsedGrReg);
		} else {
			// Process for custome instruction 457 -> 464
			if(pIns->GetMne() == "clr1" || pIns->GetMne() == "not1" || 
				pIns->GetMne() == "set1" || pIns->GetMne() == "tst1")
			{
				// CheckReplaceCustomIns return false means that this instruction will be 
				// processed as a normal instruction.
				if(CheckReplaceCustomIns(pIns, mUsedGrReg))
					continue;
			}
			// Repeat traversing all operands
			for(nOpr = 0; nOpr < pIns->GetOpNum(); nOpr++)
			{
				pOpr = pIns->opr(nOpr);
				pOpr->ReplaceOprInList(&mUsedGrReg);
			}
		}
	}
#if	0 //DEBUG
	{
		std::cout << "Used reg: ";
		for(mItr = mUsedGrReg.begin(); mItr != mUsedGrReg.end(); mItr++)
		{
			std::cout << mItr->first << "\t";
		}
		std::cout << std::endl;
	}
#endif
}

std::vector<CTeSyncBlock*>* CBlockManager::GenerateTeSync( TBlockConfig* pCfg ) {

	UI32 reg = 10;
	std::vector<CTeSyncBlock*>* vNode = new std::vector<CTeSyncBlock*>();
	std::string cstrT = GetTContext(pCfg);
	std::string cstrM = GetMContext(pCfg);
	IInstruction *ins;
	CTeSyncBlock* pTS_trap = new CTeSyncBlock( cstrT + "th_end_sync" );
	CTeSyncBlock* pTS_sync = new CTeSyncBlock( cstrT + "th_end_sync_sub" );
	pTS_trap->EnableRegulation(true);
	pTS_trap->SetBreakSetupInsFlag(false);
	pTS_sync->EnableRegulation(false);
    
	NewINS( pTS_trap,  DBTAG());  //! Mark it as the end of random block #Redmine#65750

	// UM -> SV
	NewINS( pTS_trap,  STSR( 0, reg, 2) );  // PEID
	NewINS( pTS_trap,  SHR( 15, reg) );		// PEID.GM
	NewINS( pTS_trap,  CMP5( 1, reg) );		// Check Guest Mode

	NewINS( pTS_trap,  BZ9P( pTS_trap->GetLabel() + "Get_program_status_reggister") );
	NewINS( pTS_trap,  STSR( 5, reg, 0) );  //PSW
	NewINS( pTS_trap,  BR9(6) );  //PSW
	NewINS( pTS_trap,  STSR( 5, reg, 9)->SetLabel(pTS_trap->GetLabel() + "Get_program_status_reggister") );  //GMPSW

	NewINS( pTS_trap,  MOV32(0x40000000, reg+1));
	NewINS( pTS_trap,  AND(reg, reg+1));
	NewINS( pTS_trap,  BZ9P( pTS_trap->GetLabel() + "Check_DB_mode") ); 
	NewINS( pTS_trap, ins=TRAP(0xd) ); ins->AppendComment("Change_mode_to_SV");
	NewINS( pTS_trap, ins=TRAP(0x1d) ); ins->AppendComment("Change_mode_to_SV");
	NewINS( pTS_trap, ins=FETRAP(0xd) ); ins->AppendComment("Change_mode_to_SV");
	NewINS( pTS_trap, ins=RIE() ); ins->AppendComment("Change_mode_to_SV");
	NewINS( pTS_trap, STSR(20, reg, 3)->SetLabel(pTS_trap->GetLabel() + "Check_DB_mode") );;  // DIR0
	NewINS( pTS_trap, MOV32(0x1, reg + 1) );
	NewINS( pTS_trap, AND(reg, reg + 1) );
	NewINS( pTS_trap, BZ9P(pTS_trap->GetLabel() + "In_SV_mode") );
	NewINS( pTS_trap, STSR(19, reg, 3) );  // DBPSW
	NewINS( pTS_trap, MOV32(~(1 << 30), reg + 1));
	NewINS( pTS_trap, AND(reg, reg + 1));
	NewINS( pTS_trap, LDSR(reg + 1, 5, 9) ); // Clear GMPSW.UM bit
	NewINS( pTS_trap, LDSR(reg + 1, 19, 3) ); // Clear DBPSW.UM bit
	NewINS( pTS_trap, MOV32P(pTS_trap->GetLabel() + "In_SV_mode", reg) );
	NewINS( pTS_trap, LDSR(reg, 18, 3) ); // Adjust DBPC
	NewINS( pTS_trap, ins = DBRET());  ins->AppendComment("Change_mode_to_SV");

	NewINS( pTS_trap, NOP()->SetLabel(pTS_trap->GetLabel() + "In_SV_mode") );
	//This is checking when support FPI. 
	//In conlusion FROG does not support FPI so remove here

	//NewINS( pTS_trap, STSR( 11,reg, 0)	);		// FPEC
	//NewINS( pTS_trap, CMP5( 0, reg) );
	//NewINS( pTS_trap, BE9(6) );
	//NewINS( pTS_trap, LDSR(0, 11, 0) );

    // VM生成時
    AddHtNotifyComplete(pCfg, pTS_sync);				// 自ＨＴ準備完了フラグをセット

    if ((pCfg->m_VCID == 0) && (pCfg->m_HTID == g_prf->GetMasterThreadNo(0))) {
        // VMのマスタースレッド
        AddHtWaitComplete(pCfg, pTS_sync);			    // 自ＰＥ内全ＴＨ準備完了待ち

        if (m_MmList.Size() != 0) {
            // MPM off
			NewINS( pTS_trap, MOV32P(cstrT + "disable_mpu", reg));
			NewINS( pTS_trap, JARL32(reg, 31));
        }

        // jump
        NewINS(pTS_sync, MOV32P(cstrM + "epilogue", 31) );
        NewINS(pTS_sync, JMP32(31) );
    }
    NewINS( pTS_sync, NOP() );
    NewINS( pTS_sync, NOP() );
	NewINS( pTS_sync, NOP() );
    NewINS( pTS_sync, NOP() );
    NewINS( pTS_sync, HALT() );
    NewINS( pTS_sync, BR9(-8) );

	vNode->push_back(pTS_trap);
	vNode->push_back(pTS_sync);
	return vNode;
}


/**
 * @brief  プリフェッチコードを生成します。
 * @param  ランダムブロック情報
 */
void CBlockManager::AppendPrefetchCode (std::string & context, CSyncBlock* pPF) {
	const UI32 reg1 = 10;
	const UI32 memreg = 11;
	const UI32 tblreg = 12;
    NewINS( pPF, MOV32P(context + "_PrefetchMode" + "_data", tblreg) );
	NewINS( pPF, ADD5(2, tblreg) );
	NewINS( pPF, LDHU16(2, tblreg, reg1)->SetLabel(context + "_PrefetchMode_1"));
	NewINS( pPF, LDHU16(0, tblreg, memreg));
	NewINS( pPF, SHL5( 16, reg1) );
	NewINS( pPF, OR(reg1,memreg) );
	NewINS( pPF, LDHU16(4, tblreg, reg1));
	NewINS( pPF, CMPR(0, reg1));
	NewINS( pPF, BZ9P((context + "_PrefetchMode_3")));
    NewINS( pPF, PREF(0,memreg)->SetLabel(context + "_PrefetchMode_2"));
	NewINS( pPF, ADDI(0x0020, memreg, memreg) );

	NewINS( pPF, LOOPP(reg1 ,context + "_PrefetchMode_2") );
    NewINS( pPF, PREF(0,memreg));
	NewINS( pPF, ADD5(8, tblreg) );
	NewINS( pPF, BR9P(context + "_PrefetchMode_1"));
	NewINS( pPF, NOP());
	NewINS( pPF, JMP32(31)->SetLabel(context + "_PrefetchMode_3"));
	NewINS( pPF, NOP());
	NewINS( pPF, NOP()->SetLabel(context + "_PrefetchMode" + "_data"));
}


void CBlockManager::AppendPrefetchData (UI32 pf_addr ,UI32 pf_size, CSyncBlock* pPF) {
	IInstruction * ins ;
	char str[80] ;
    if (pf_size == 0) {
        sprintf(str ,"[END OF PREFETCH]" ) ;
	    NewINS( pPF, ins = _WORD(0));
	    ins->AppendComment((LPCTSTR)str) ;
	    NewINS( pPF, _WORD(0));
    } else {
	    sprintf(str ,"[PF_ADR: 0x%08x  SIZE: %d]" ,pf_addr ,pf_size ) ;
        UI32 lines = (((pf_addr % 16) + pf_size - 1) / 16) + 1;
	    NewINS( pPF, ins = _WORD(pf_addr & 0xfffffff0));
	    ins->AppendComment((LPCTSTR)str) ;
	    NewINS( pPF, _WORD(lines));
    }
}

void CBlockManager::FetchLineZeroing (std::vector<INode*>& rCb) {
	UI32 nop_len = NOP()->GetLen();

	for (std::vector<INode*>::iterator node = rCb.begin(); node != rCb.end(); node++) {
		CCodeBlock* p = static_cast<CCodeBlock*>(*node);
		UI32 fetch_size = g_cfg->m_nFetchSize>>3;
		UI32 gap = (fetch_size - (p->GetCodeSize() % fetch_size)) % fetch_size;
		UI32 nop_gap = (gap/nop_len) + ((gap%nop_len)?1:0);
		for (UI32 i = 0; i < nop_gap; i++) {
			NewINS( p, NOP() );
		}
	}
}


CSyncBlock* CBlockManager::SyncStandbyGoNext(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	const UI32 reg1 = 31;

	std::string str = GetTContext(pCfg) + "sync_standby_next";
	NewINS( pSB, NOP()->SetLabel(str));

    if (m_MmList.Size() != 0) {
        UI32 mpm = g_srs->GetNcInit(0, 5) & 0x7;
        mpm |= 0x1;
        NewINS(pSB, MOV5(mpm, 5));
        NewINS(pSB, LDSR(5, 0, 5));

        if (pCfg->m_bGM) {
            UI32 gmmpm = g_srs->GetNcInit(25, 9) & 0x7;
            gmmpm |= 0x5;
            NewINS(pSB, MOV5(gmmpm, 5));
            NewINS(pSB, LDSR(5, 25, 9));
        }
    }

    // HM -> GM
    if (pCfg->m_bGM) {
        TransGuestMode(pSB, 29, 30, pCfg);
    }
	// SV -> UM
    if (g_prf->IsUserMode(pCfg->m_bGM, pCfg->m_GMID)) {
		TransUserMode (pSB, 29, 30, pCfg); // r29, r30 を使用してPSW.UM = 1にするコードを生成
	}

	std::string contextStr = GetTContext(pCfg);

    if (g_cfg->m_bPrefAssist) {
    	NewINS(pSB, MOV32P( contextStr + "PrefetchMode", 20) );
    	NewINS(pSB, JARL32(20, 31) );
    	NewINS(pSB, NOP() );
    	NewINS(pSB, NOP() );
    }

    //! WR INIT
    InitWR(pSB);

    //! GR INIT
    InitGR(pSB);

    pCfg->m_bNC = false;
    std::string GM_contextStr = GetTContext(pCfg);
    pCfg->m_bNC = true;
    NewINS(pSB, MOV32P(GM_contextStr + "codeblock_00_00", reg1));
    NewINS(pSB, JMP32(reg1));

	return pSB;
}


CSyncBlock* CBlockManager::AddHtNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 1;
	const UI32 reg2 = 31;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_STANDBY + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT) + g_prf->GetWaitThreadNo(pCfg->m_HTID);
	
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, MOV5 (1, reg2) );
	NewINS( pSB, STB16 (reg2, 0, reg1) );
		
	return pSB;
}


CSyncBlock* CBlockManager::AddHtWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_STANDBY + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT);
	UI32 size = g_prf->GetWaitThreadNum(); // 同期するHT数
	NewINS( pSB, MOV5 (size, reg1) );
	NewINS( pSB, MOV32(addr, reg2) );
	
	NewINS( pSB, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pSB, BZ9P((str + "4").c_str()));
	
	NewINS( pSB, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pSB, CMP5(1, reg3));
	NewINS( pSB, BZ9P((str + "3").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "2").c_str()));

	NewINS( pSB, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pSB, ADD5(-1, reg1) );
	NewINS( pSB, BNZ9P((str + "2").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "4") );
	
	return pSB;
}


CSyncBlock* CBlockManager::AddHtWait2Standby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address

	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_STANDBY + g_cfg->m_nPeWorkIdx;
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, LDB16(0, reg1, reg2)->SetLabel(str + "5"));
	NewINS( pSB, CMP5(1, reg2));
	NewINS( pSB, BZ9P((str + "6").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "5").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "6") );

	return pSB;
}


CSyncBlock* CBlockManager::AddWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	std::string str = GetTContext(pCfg) + "sync_ht_standby_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address

	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, LDB16(0, reg1, reg2)->SetLabel(str + "5"));
	NewINS( pSB, CMP5(1, reg2));
	NewINS( pSB, BZ9P((str + "6").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "5").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "6") );
	
	return pSB;
}


CSyncBlock* CBlockManager::AddPeNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_STANDBY + g_cfg->m_nPeWorkIdx;
	
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, MOV5 (1, reg2) );
	NewINS( pSB, STB16 (reg2, 0, reg1) );
		
	return pSB;
}


CSyncBlock* CBlockManager::AddPeWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);

	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	const UI32 reg4 = 8;	// psw temp
	std::string str;
    UI32 addr;

	str = GetTContext(pCfg) + "sync_standby_next";
    addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;

	NewINS( pSB, STSR (5, reg4, 0) );  // store PSW in R8

	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, LDB16(0, reg1, reg2));
	NewINS( pSB, CMP5(1, reg2));
	NewINS( pSB, BZ9P((str).c_str()));

	str = GetTContext(pCfg) + "sync_pe_standby_";
	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_STANDBY;
	UI32 size = g_cfg->m_nSysPeNum;
	NewINS( pSB, MOV5 (size, reg1) );
	NewINS( pSB, MOV32(addr, reg2) );
	
	NewINS( pSB, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pSB, BZ9P((str + "4").c_str()));
	
	NewINS( pSB, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pSB, CMP5(1, reg3));
	NewINS( pSB, BZ9P((str + "3").c_str()));
	NewINS( pSB, SNOOZE());
	NewINS( pSB, SNOOZE());
	NewINS( pSB, BR9P((str + "2").c_str()));

	NewINS( pSB, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pSB, ADD5(-1, reg1) );
	NewINS( pSB, BNZ9P((str + "2").c_str()));

	NewINS( pSB, NOP()->SetLabel(str + "4") );

	NewINS( pSB, LDSR (reg4, 5, 0) );  // restore PSW from R8
	
	return pSB;
}


CSyncBlock* CBlockManager::AddSysNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pSB);
	
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_STANDBY;
	
	NewINS( pSB, MOV32(addr, reg1) );
	NewINS( pSB, MOV5 (1, reg2) );
	NewINS( pSB, STB16 (reg2, 0, reg1) );
		
	return pSB;
}


CTeSyncBlock* CBlockManager::AddHtNotifyComplete(TBlockConfig* pCfg, CTeSyncBlock* pTS) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTS);
	
	std::string str = GetTContext(pCfg) + "sync_ht_complete_";
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_COMPLETE + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT) + g_prf->GetWaitThreadNo(pCfg->m_HTID);
	
	NewINS( pTS, MOV32(addr, reg1)->SetLabel(str + "0"));
	NewINS( pTS, MOV5 (1, reg2) );
	NewINS( pTS, STB16 (reg2, 0, reg1) );
		
	return pTS;
}


CTeSyncBlock* CBlockManager::AddHtWaitComplete(TBlockConfig* pCfg, CTeSyncBlock* pTS) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTS);

	std::string str = GetTContext(pCfg) + "sync_ht_complete_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_HT_COMPLETE + (g_cfg->m_nPeWorkIdx * g_wm.SIZ_SYNCHRO_HT);
	UI32 size = g_prf->GetWaitThreadNum(); // 同期するHT数
	NewINS( pTS, MOV5 (size, reg1) );
	NewINS( pTS, MOV32(addr, reg2) );
	
	NewINS( pTS, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pTS, BZ9P((str + "4").c_str()));
	
	NewINS( pTS, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pTS, CMP5(1, reg3));
	NewINS( pTS, BZ9P((str + "3").c_str()));
	NewINS( pTS, SNOOZE());
	NewINS( pTS, SNOOZE());
	NewINS( pTS, BR9P((str + "2").c_str()));

	NewINS( pTS, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pTS, ADD5(-1, reg1) );
	NewINS( pTS, BNZ9P((str + "2").c_str()));

	NewINS( pTS, NOP()->SetLabel(str + "4") );
	
	return pTS;
}


CTerminateBlock* CBlockManager::AddPeNotifyComplete(TBlockConfig* pCfg, CTerminateBlock* pTB) {
	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTB);
	
	const UI32 reg1 = 5;
	const UI32 reg2 = 6;
	
	UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_COMPLETE + g_cfg->m_nPeWorkIdx;
	
	NewINS( pTB, MOV32(addr, reg1) );
	NewINS( pTB, MOV5 (1, reg2) );
	NewINS( pTB, STB16 (reg2, 0, reg1) );
		
	return pTB;
}


CTerminateBlock* CBlockManager::AddPeWaitComplete(TBlockConfig* pCfg, CTerminateBlock* pTB) {

	FROG_ASSERT (pCfg);
	FROG_ASSERT (pTB);

	std::string str = GetTContext(pCfg) + "sync_pe_complete_";
	const UI32 reg1 = 5;	// total num
	const UI32 reg2 = 6;	// flag address
	const UI32 reg3 = 7;	// read buff
	
    UI32 addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_SKIP_PE_COMPLETE;
	NewINS( pTB, MOV32(addr, reg1) );
	NewINS( pTB, LDB16(0, reg1, reg2));
	NewINS( pTB, CMP5(1, reg2));
	NewINS( pTB, BZ9P((str + "4").c_str()));

	addr = g_wm.BASE_COMMON + g_wm.OFS_SYNCHRO_PE_COMPLETE;
	UI32 size = g_cfg->m_nSysPeNum;
	NewINS( pTB, MOV5 (size, reg1) );
	NewINS( pTB, MOV32(addr, reg2) );
	
	NewINS( pTB, CMP5(0, reg1)->SetLabel (str + "1"));
	NewINS( pTB, BZ9P((str + "4").c_str()));
	
	NewINS( pTB, LDB16(0, reg2, reg3)->SetLabel(str + "2"));
	NewINS( pTB, CMP5(1, reg3));
	NewINS( pTB, BZ9P((str + "3").c_str()));
	NewINS( pTB, SNOOZE());
	NewINS( pTB, SNOOZE());
	NewINS( pTB, BR9P((str + "2").c_str()));

	NewINS( pTB, ADD5( 1, reg2)->SetLabel(str + "3") );
	NewINS( pTB, ADD5(-1, reg1) );
	NewINS( pTB, BNZ9P((str + "2").c_str()));

	NewINS( pTB, NOP()->SetLabel(str + "4") );
	
	return pTB;
}


std::vector<CEpilogueBlock*>* CBlockManager::GenerateEpilogue(TBlockConfig* pCfg) {
	
	std::vector<CEpilogueBlock*>* vNode = new std::vector<CEpilogueBlock*>();
	std::string contextStr = GetMContext(pCfg);
	
	UI32 reg_a = 1;
	UI32 reg_b = 31;
	if (pCfg->m_bNC) {
		// -----------------------------------------------------------------
		// NM:Epilogue - 1
		//  セルフチェックする為にレジスタr1,r31を使用する。
		//  r1,r31の値も比較対象にするためr3, r4に足し込む (完全なセルフチェックにはならない)
		//  r1, r31が使用可能な状態にしてEpilogue2へジャンプ
		CEpilogueBlock* pEB = new CEpilogueBlock(contextStr + "epilogue");
		NewINS( pEB, ADD(reg_a, 3) ); // reg1  --+--> reg3
		NewINS( pEB, ADD(reg_b, 4) ); // reg31 --+--> reg4
		NewINS( pEB, MOV32P(contextStr + "eplogue_verifier", reg_a) );
		NewINS( pEB, JMP32(reg_a)  );
		vNode->push_back(pEB);

		// -----------------------------------------------------------------
		// NM:Epilogue - 2
		//   このブロックがシミュレーションされる時点でスナップショット（期待値）がとられる。
		//   全シミュレーションが完了後にスナップショットから比較コードが生成される。
		pEB = new CEpilogueBlock(contextStr + "eplogue_verifier", true);
		NewINS( pEB, MOV32P(contextStr + "terminate", reg_b));
		NewINS( pEB, JMP32(reg_b) ); 		
		// 不一致の場合、ブランチ命令がセクションを跨げないため中継してジャンプする。
		NewINS( pEB, MOV32P(contextStr + "selfcheck_fail", reg_a)->SetLabel(contextStr + "verify_fail"));
		NewINS( pEB, JMP32(reg_a) );
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		vNode->push_back(pEB);

		// -----------------------------------------------------------------
		// NM:Epilogue - 3
		//   Nativeコンテキストのみエラーハンドルブロック追加
		//   ユーザー処理できるようにユーザーコードエントリも追加する
		pEB = new CEpilogueBlock(contextStr + "selfcheck_fail");
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		NewINS( pEB, NOP() );
		NewINS( pEB, MOV32(0xdead0000, 1));
		NewINS( pEB, HALT() );
		NewINS( pEB, BR9(-16) );
		NewINS( pEB, NOP() );
		vNode->push_back(pEB);
	} else {
		// -----------------------------------------------------------------
		// VM :: Epilogue - 1 terminateへつながる処理のみ
		CEpilogueBlock* pEB = new CEpilogueBlock(contextStr + "epilogue");
		NewINS( pEB, MOV32P(contextStr + "terminate", reg_a));
		NewINS( pEB, JMP32(reg_a) ); 
		vNode->push_back(pEB);
	}
	return vNode;
}


void CBlockManager::GenVerifier(CCodeBlock* pCB, TBlockConfig* pCfg) {

	const UI32		GRNUM = 32;
	const UI32		TempR =  1;
	const UI32		TempS =  31;
	
	const UI32		TempX =  2;  // Memory DWORD LOAD
	const UI32		TempY =  4;  // Memory DWORD LOAD
	
	CSimResource*	res;
	const char* opt = g_cfg->m_strSelfCheck.c_str();
	bool bGr = std::strpbrk(opt, "Gg");
	bool bVr = std::strpbrk(opt, "Vv");
	bool bSr = std::strpbrk(opt, "Ss");
	bool bMm = std::strpbrk(opt, "Mm");
	
	if (pCB == nullptr || ((res = pCB->GetSnapShot()) == nullptr)) {
		return;
	}
	std::string fail_handler = GetMContext(pCfg) + "verify_fail";
	UI32 inum = pCB->GetInstructionNum();
	// ¸å¤í¤ËÄÉ²Ã¤·¤Æ¤¤¤­ºÇ¸å¤Ë¥í¡¼¥Æ¡¼¥·¥ç¥ó
	
	//-------------- Must --------------------
	if (bSr) {
		// NC:SR(5,0)PSWは最初に比較する
		SRSET& ms = res->m_nc;
		auto sv = std::find_if (ms.begin(), ms.end(), [](const SRVAL& v){return v.first == (0<<5 | 5);});
		if (sv != ms.end()) {

			ms.erase(std::remove(ms.begin(), ms.end(), *sv), ms.end());
		}
	}

	//--------------- GR ---------------------
	if (bGr) {
		const GRLST& gs = res->m_gr;
		for (UI32 r = 0; r < GRNUM; r++) {
			if (r == TempR || r == TempS) {
				continue; // Temporary gr NOT to be compared 
			}
			if (gs[0][r] != 0) { 
				NewINS( pCB,  MOV32( gs[0][r], TempR) );
				NewINS( pCB,  CMPR( TempR, r) );
			}else{
				// r0で命令サイズ節約
				NewINS( pCB,  CMPR( 0, r) );
			}
			NewINS( pCB,  BNE17P(fail_handler.c_str()) );
		}
		for (UI32 t = 1; t < gs.size(); t++) {
			NewINS( pCB,  MOV5(t, TempR) );
			NewINS( pCB,  LDSR(TempR, 10, 1) ); //TCSEL
			const GRSET& ge = gs[t]; // gs[t]:スレッドID＝tのr0-31の期待値が配列になっている
			for (UI32 r = 0; r < GRNUM; r++) {
				if (ge[r] != 0) {
					NewINS( pCB,  MOV32( ge[r], TempR) );
					NewINS( pCB,  STTC_GR( r, TempS ) );
					NewINS( pCB,  CMPR(TempR, TempS) );
				}else{
					// r0で命令サイズ節約
					NewINS( pCB,  STTC_GR( r, TempS ) );
					NewINS( pCB,  CMPR(0, TempS) );
				}
				NewINS( pCB,  BNE17P(fail_handler.c_str()) );
			}
		}
	}
	
	if (bVr) {
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
		NewINS( pCB, NOP() );
	}
	
	//--------------- SR ---------------------
	// NC
	SwitchCoProcessor(pCB, 2, 3);
	if (bSr) {
		const SRSET& ns = res->m_nc;
		for (UI32 r = 0; r < ns.size(); r++) {
			UI32 selid = ns[r].first >> 5;
			UI32 regid = ns[r].first & 31;
			UI32 value = ns[r].second;
			NewINS( pCB,  MOV32(value, TempR) );
			NewINS( pCB,  STSR( regid, TempS, selid) );
			NewINS( pCB,  CMPR( TempR, TempS) );
			NewINS( pCB,  BNE17P(fail_handler.c_str()) );
		}
		// VC
		for (UI32 v = 0; v < res->m_vc.size(); v++) {
			NewINS( pCB,  MOV5(v, TempR) );
			NewINS( pCB,  LDSR(TempR, 15, 1) ); //VCSEL
			const SRSET& vs = (res->m_vc)[v];
			for (UI32 r = 0; r < vs.size(); r++) {
				UI32 selid = vs[r].first >> 5;
				UI32 regid = vs[r].first & 31;
				UI32 value = vs[r].second;
				NewINS( pCB, MOV32( value, TempR) );
				NewINS( pCB, STVC_SR( regid, TempS, selid ) );
				NewINS( pCB, CMPR(TempR, TempS) );
				NewINS( pCB, BNE17P(fail_handler.c_str()) );
			}
		}
		// TC
		for (UI32 t = 0; t < res->m_tc.size(); t++) {
			NewINS( pCB,  MOV5(t, TempR) );
			NewINS( pCB,  LDSR(TempR, 10, 1) ); //TCSEL
			const SRSET& ts = (res->m_tc)[t];
			for (UI32 r = 0; r < ts.size(); r++) {
				UI32 selid = ts[r].first >> 5;
				UI32 regid = ts[r].first & 31;
				UI32 value = ts[r].second;
				NewINS( pCB, MOV32( value, TempR) );
				NewINS( pCB, STTC_SR( regid, TempS, selid ) );
				NewINS( pCB, CMPR(TempR, TempS) );
				NewINS( pCB, BNE17P(fail_handler.c_str()) );
			}
		}
	}
	
	if (bMm) {
		//memory
		std::vector<T_MEMWRRECORD>& ml = res->m_logs;
		std::vector<T_MEMWRRECORD>::iterator i;

		std::set<MEMRANGE> sRegisterBank = g_RegisterBankAddr.KeySet();
		bool bIsRegBankAdd = false;
	
		UI32 len = 0;
		UI32 count = 0;
		std::string failed_selfcheck = fail_handler + "_0";
		const UI32 BR17_MAX_LEN = 65535 - 64;				// Diplacement 17bits - reserve sized for intermediate failed_selfcheck

		std::vector<T_MEMWRRECORD> vMl;
		std::vector<T_MEMWRRECORD>::iterator itr;
		for (i = ml.begin(); i != ml.end(); ++i) {
			UI32 ep   = 30;
			UI32 addr = i->first;
			UI32 size = i->second.first;
			UI64 data = i->second.second;
			// 部分重複は無いはず->addr一点で除外判断する
			if(g_prf->IsShareMem(addr) || g_prf->IsValidMem (addr) == false) {
				//fprintf (stderr, "Skip verify at address %08x, becase of system area...\n", addr);
				continue; // このエントリは除外
			}
			
			if (g_prf->IsTempMem(addr)) {
				continue; // このエントリは除外
			}
			if(g_LoadableAddr.GetMirror(addr) == true || g_StorableAddr.GetMirror(addr) == true || g_RmwAddr.GetMirror(addr) == true)
				continue;

			std::set<MEMRANGE>::iterator sitr;
			for (sitr = sRegisterBank.begin(); sitr != sRegisterBank.end(); sitr++) {
				if ((sitr->first <= addr) && (addr < sitr->second)) {
					bIsRegBankAdd   = true;
					break;
				}
			}
			//!< Checking is belong into Register bank area.
			if ( bIsRegBankAdd ) {
				continue;
			}

			if (size==1) {
				NewINS( pCB, MOV32( addr, ep) );
				NewINS( pCB, SLDBU (0, TempR) ); // ep
				NewINS( pCB, MOV32( (UI8)data, ep) );
				NewINS( pCB, CMPR(TempR, ep) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 20;
			}
			else
			if (size==2) {
				NewINS( pCB, MOV32( addr, ep) );
				NewINS( pCB, SLDHU (0, TempR) ); // ep
				NewINS( pCB, MOV32( (UI16)data, ep) );
				NewINS( pCB, CMPR(TempR, ep) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 20;
			}
			else
			if (size==4) {
				NewINS( pCB, MOV32( addr, TempS) );
				NewINS( pCB, LDW16 (0, TempS, TempR) );
				NewINS( pCB, MOV32( (UI32)data, TempS) );
				NewINS( pCB, CMPR(TempR, TempS) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 22;
			}
			else
			if (size==8) {
				UI32 lo = (UI32)(data & 0xffffffffU);
				UI32 hi = (UI32)(data >> 32);
				NewINS( pCB, MOV32( addr, TempS) );
				NewINS( pCB, LDDW23 (0, TempS, TempX) );
				NewINS( pCB, MOV32( lo, TempY) );
				NewINS( pCB, MOV32( hi, TempY+1) );
				NewINS( pCB, CMPR(TempX, TempY) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				NewINS( pCB, CMPR(TempX+1, TempY+1) );
				NewINS( pCB, BNE17P(failed_selfcheck.c_str()) );
				len += 36;
			}

			if(len > BR17_MAX_LEN) { // Generate intermedia target for failed self-checking
				std::stringstream ss;
				std::string label;

				count++;
				len = 0;
				ss << fail_handler << "_" << count << std::endl;
				ss >> label;

				NewINS( pCB, BR9(6));						// Jump over intermediate failed_selfcheck
				IInstruction *p = JR22P(label)->SetLabel(failed_selfcheck);	// Jump back to previous failed_selfcheck
				pCB->AddOpeCode(p);
				failed_selfcheck = label;
			}
		}
		NewINS( pCB, BR9(6));											// Jump over intermediate failed_selfcheck
		NewINS( pCB, JR22P(fail_handler)->SetLabel(failed_selfcheck));	// Jump back to previous failed_selfcheck
	}
	
	NewINS( pCB, NOP() );
	pCB->Rotate(inum);

	// Re allocate position of this code block.
	UI32 AddSize = pCB->GetCodeSize() + pCB->GetBlockGap();
	UI32 Align = 0;
	MEMADDR ValidMem = g_asf->GetLinker()->GetAvailableMemory(AddSize, Align, false);

	if (ValidMem > 0) {
		//Remove current address.
		g_asf->GetLinker()->Remove(pCB->GetAddress());
		pCB->SetAddress(ValidMem);
		pCB->Update();
		g_asf->GetLinker()->Alloc(pCB->GetAddress(), AddSize);
	} else {
		std::cout << "Can not replace Add of " <<pCB->GetLabel()<< std::endl;
	}
}


//
// テストパタン終了処理を生成する
//
std::vector<CTerminateBlock*>* CBlockManager::GenerateTerminateBlock(TBlockConfig* pCfg) {

	std::vector<CTerminateBlock*>* vNode = new std::vector<CTerminateBlock*>();
	CTerminateBlock* pTB = NULL;
	std::string cstrT = GetTContext(pCfg);
	std::string cstrM = GetMContext(pCfg);

    pTB = new CTerminateBlock( cstrM + "terminate");
	pTB->SetOutputFlag(true);
	if (pCfg->m_bNC) {
        AddPeNotifyComplete(pCfg, pTB);
        if (g_cfg->m_nSysPeNum != 0) {
            AddPeWaitComplete(pCfg, pTB);
        }
	    NewINS( pTB,  MOV32( 0xffff7ffc, 9) );
	    NewINS( pTB,  STH16(0 , 0U , 9) );
	    NewINS( pTB,  MOVEA(0x0010 , 0 , 10) );
	    NewINS( pTB,  STH16(10 , 2U , 9) );
	    NewINS( pTB,  HALT() );
	    NewINS( pTB,  BR9(-8) );
	    NewINS( pTB,  NOP()  );
	    NewINS( pTB,  NOP()  );
	    NewINS( pTB,  NOP()  );
	} else {
	    NewINS( pTB,  HVTRAP(0x1d) );
	    NewINS( pTB,  NOP()  );
	    NewINS( pTB,  NOP()  );
	    NewINS( pTB,  NOP()  );
    }
    vNode->push_back(pTB);
	
	return vNode;
}

std::vector<CFunctionBlock*>* CBlockManager::GenerateFunction(TBlockConfig* pCfg) {
	FROG_ASSERT(pCfg);
	FROG_ASSERT(pCfg->InsNum);
	std::vector<CFunctionBlock*>* vNode = new std::vector<CFunctionBlock*>();
	// Generating function block for jarl labeling
	GenerateJarlFunction(pCfg, vNode);

    // Generating function block for updating MPU config
    GenerateMPUpdate(pCfg, vNode);

	return vNode;

}

void CBlockManager::GenerateJarlFunction(TBlockConfig* pCfg, std::vector<CFunctionBlock*>* pVFB) {
	// JARL共通ルーチンとなるコードブロックを生成する
	// このコードブロックは補正しない
	//（何度も呼ばれるため、呼ばれるたびに補正されるとシミュレーションが矛盾する）
	// よって制約がつくメモリアクセス命令は出さない。
	// FPU命令にも制約がつくがここでは制約を外して出すようにする(暫定)
	
	std::string cstrM = GetMContext(pCfg);
	auto IsInvalidLDSR = [] (UI32 sr)->bool {
		UI32 const NO_MASK = 0xffffffff;
		if((sr >> 5) == 0x5 /*MPU SRs*/ 
				|| (sr == (1*32) +  0)  /* SPID */ 
				|| (sr == (0*32) +  5)  /* PSW */) {
			return true;
		}
		if(g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK) {
			return true;
		}
		return false;
	};
	
	// LP= GR[F]のファンクションコードを生成する。
	// このブロックの中の命令はGR[F]の値を保持するような命令で構成される。
	for (UI32 F = 1; F < 32; F++) {	

		// label
		std::stringstream ss;
		ss << (cstrM + "function_") << std::dec << F;

		CFunctionBlock* pCb = new CFunctionBlock();
		pCb->SetOutputFlag(true);			// 出力ON
		pCb->EnableRegulation(true);		// 補正不可
		pCb->SetLabel(ss.str().data());		// __function_NN
		pCb->SetHandlerAddress(ADR_VECTOR_NUM + F*0x10);
		pCb->SetStatistics(true);			// コード生成カバレッジ蓄積対象
			
		UI32 i;		// Index
		UI32 m; 	// Give up genearationg function call.
		UI32 g = pCfg->InsNum + 10; 	// Give up genearationg function call.
		IInstruction* pIns;

		// iが所定の命令数になるまでループする
		// mは生成トライ回数でg(必要命令数の10倍回数チャレンジした場合、Giveupする)
		for (i = m = 0; ((i < pCfg->InsNum) && (m < g)) ; m++) { 
			// LPにGR[i]を使うルーチンである為、GR[i]を別のレジスタにする
			pIns = m_nrmSet.CreateIns()->Fix();
			FROG_ASSERT(pIns);
			
			// 制約ありは除外
			if (pIns->IsComplex() || pIns->Behavior(IInstruction::JMP) || pIns->GetId() == INS_ID_RESBANK || pIns->GetId() == INS_ID_LDM_MP 
				|| pIns->GetId() == INS_ID_LDM_GSR || pIns->GetMne().find("rsqrtf") != std::string::npos || pIns->GetMne().find("recipf") != std::string::npos ) {
				delete pIns;
				continue;
			}

			//if(pIns->Behavior(IInstruction::LOAD_SR))
			if(pIns->GetMne() == "ldsr" || pIns->GetMne() == "ldtc.sr" || pIns->GetMne() == "ldvc.sr"){
				UI32 const RETRY_TIMES = 10; // Give up to generate system reg.
				UI32 nCount = 0;
				UI32 sr = (UI32)*(pIns->opr(1));
				while( IsInvalidLDSR(sr) && nCount < RETRY_TIMES){
					// Generate other system register.
					sr = (UI32)*(pIns->opr(1)->ReFix());
					nCount++;
				}
				if (nCount == RETRY_TIMES){
					delete pIns;
					continue;
				}
			}
			
			for (UI32 p = 0; p < pIns->GetOpNum(); p++) {
				IOperand* popr = pIns->opr(p);
				popr->AdjustOprInFunction(F);
			}

			if((pIns->GetOprDst() >> F) & 0x1)	{
				delete pIns;
				continue;
			}

			pCb->AddOpeCode(pIns);
			i++;
		}
		
		pIns = JMP32(F);
		pIns->AppendComment("--> Return");
		pCb->AddOpeCode(pIns);
		// Dead code insert
        InsertDeadCode(pCb);
		
		pVFB->push_back(pCb);
	}
	
	return;
}

/**
 * @brief	Generate code to update MPU configuration
 * @param	pCfg config information
 * @param	pVFB output parameter of function codeblock
*/
void CBlockManager::GenerateMPUpdate(TBlockConfig* pCfg, std::vector<CFunctionBlock*>* pVFB) {
    std::string cstrM = GetMContext(pCfg);
    std::string cstrT = GetTContext(pCfg);
    UI32 gap_size = 0x540;
    // Check HVCFG.HVE = 1 and disable write
    if ((g_srs->GetNcInit(16, 1) & 0x1) != 0 && g_srs->IsStorable(16, 1) == false) gap_size = 0x98;

    for (UI32 idx = 0; idx < m_vMPUpdate.size(); idx++) {
        std::stringstream ss;
        ss << (cstrM + "mpu_function_") << std::dec << idx;

        CFunctionBlock* pCb = new CFunctionBlock();
        pCb->SetOutputFlag(true);
        pCb->EnableRegulation(false);
        pCb->SetLabel(ss.str().data());
        pCb->SetBlockGap(gap_size);

        IInstruction * pIns;
        UI32 reg = m_nWorkReg;

        pIns = MOV32P(cstrT + "disable_mpu", reg);
        pCb->AddOpeCode(pIns);
        pIns = JARL32(reg, 31);
        pCb->AddOpeCode(pIns);
        pVFB->push_back(pCb);
    }
    return;
}

CPreloadBlock* CBlockManager::GenerateCalltBlock(TBlockConfig* pCfg, std::string label_num, UI32 blocksize /* = 0*/) {
	
	const UI32	callt_entry		= MAX_ENTRY_CALLT;
	UI32		callt_insnum	= std::max(16U, callt_entry* 10);
	IInstruction*	pIns;
	UI32 offset = 0;
	std::vector<std::pair<UI32, IInstruction*>> dst;
	const UI32	POS = 0;
	std::string contextStr = GetMContext(pCfg);
	CPreloadBlock* pCallt = new CPreloadBlock(contextStr + "callt_init" + "_" + label_num);

	pCallt->SetOutputFlag(true);			// 出力ON
	pCallt->EnableRegulation(true);		// 補正不可
	pCallt->SetHandlerAddress(ADR_COMMON_CALLT);
	GenerateRandomCode(pCallt, blocksize, callt_insnum, pCfg, "callt");
	callt_insnum = pCallt->GetInstructionNum();
	UI32 i = POS;
	while(i < pCallt->GetInstructionNum()) {
		
		pIns = pCallt->at(i);
		const std::string &mne = pIns->GetMne();
		if (mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr") {
			UI32 sr = (UI32)*(pIns->opr(1));
			if( sr == 32*0 + 16){
				// LDSR  guard to ctpc, non-guard to ctpsw 
				UI32 idx = pCallt->GetIndex(pIns);
				IInstruction *pNext = pCallt->at(idx+1);
				pIns->DirMoveTo(pNext);
				pCallt->Remove(pIns);
				continue;
			}
		}

		if(pIns->InSequence() == true) {
			offset += pIns->GetLen();
			i++;
			continue;
		}

		if(pIns->GetRegulationTarget() != NULL) {
			IInstruction *pRegIns = pIns->GetRegulationTarget();
			if(pRegIns->GetMne() == "ctret") {
				UI32 idx = pCallt->GetIndex(pIns);
				IInstruction *pNext = pCallt->at(idx+1);
				pIns->DirMoveTo(pNext);
				pCallt->Remove(pIns);
				continue;
			}
		} else if (mne != ".hword" && mne != ".dword" && pIns->GetComment() != "Overwrite precision error!" && (i > 0) && (pCallt->at(i-1)->GetId() == INS_ID_CTRET)) {
			dst.push_back(std::make_pair(offset, pIns));
		}
		offset += pIns->GetLen();
		i++;
	}
	
	//Dead Code insertion
    InsertDeadCode(pCallt);
	for (UI32 j = 0; j < callt_entry; j++) {
		UI32 r = 0;
		IInstruction *pIns;
		do {
			r = g_rnd.GetRange(0U, dst.size() - 1);
			pIns = dst[r].second;
		} while(pIns->InLoop() || pIns->InSequence());
		IInstruction *pShort = new CIns_456__short(new COprImm(dst[r].first  + (callt_entry * 2)));
		std::stringstream ss;
		ss << " [" << std::setw(2) << std::setfill('0') << std::dec << j << "] Jump to  ";
		std::string comment = ss.str();
		comment += pIns->GetMne();
		pShort->AppendComment(comment.data());

		pCallt->AddOpeCode(pShort, POS + j);
		pCallt->SetEntry(dst[r].second);
	}

	std::string cstrM = "COMMON_callt";
	cstrM += "_" + label_num;
	pCallt->at(POS)->SetLabel(cstrM);
	return pCallt;
}

CCodeBlock* CBlockManager::GenerateHvCallBlock(CCodeBlock* pHvCall, TBlockConfig* pCfg)
{
	const UI32		hvc_entry	= 256; // imm6
	const UI32		hvc_insnum	= std::max(16U, hvc_entry);//
	IInstruction*	pIns;
	std::vector<std::pair<UI32, IInstruction*>> dst;
	UI32 offset = 0;
	const UI32		POS = 0;
	pHvCall->SetOutputFlag(true);			// 出力ON
	pHvCall->EnableRegulation(false);		// 補正不可

	for (UI32 i = 0; i < hvc_insnum; i++) { 
		pIns = m_nrmSet.CreateIns()->Fix();
		// 制約ありは除外
		if (pIns->HasConstraint() || pIns->IsComplex() ||pIns->Behavior(IInstruction::LOAD_MEMORY) || 
			pIns->Behavior(IInstruction::STORE_MEMORY) || pIns->Behavior(IInstruction::JMP)) {
			delete pIns;
			continue;
		}
		if (pIns->GetMne() == "ldsr" || pIns->GetMne() == "ldtc.sr" || pIns->GetMne() == "ldvc.sr") {
			UI32 const RETRY_TIMES = 10; // Give up to generate system reg.
			UI32 const NO_MASK = 0xffffffff;
			UI32 nCount = 0;
			UI32 sr = (UI32)*(pIns->opr(1));
			while((g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK) && nCount < RETRY_TIMES){
				// Generate other system register.
				sr = (UI32)*(pIns->opr(1)->ReFix());
				nCount++;
			}
			if ( (sr == 32 * 0 + 2) || (sr == 32 * 0 + 3) || (nCount == RETRY_TIMES)) {
				// LDSR fepc, fepswはガード
				delete pIns;
				continue;
			}
		}
		if(pIns->GetMne() == "ei" || pIns->GetMne() == "di"){
			delete pIns;
			continue;
		}
		// PCに依存するSTSRは除外する
		if (pIns->GetMne()=="sttc.pc" || pIns->GetMne()=="stsr" || pIns->GetMne()=="stvc.sr" || pIns->GetMne()=="sttc.sr") {
			delete pIns;
			continue;
		}
		dst.push_back(std::make_pair(offset, pIns));
		offset += pIns->GetLen();
		pHvCall->AddOpeCode(pIns);
	}
	pHvCall->AddOpeCode( (pIns = FERET()) );
	dst.push_back(std::make_pair(offset, pIns));

	// Dead code insert
    InsertDeadCode(pHvCall);

	for (UI32 j = 0; j < hvc_entry; j++) {
		UI32 r = g_rnd.GetRange(0U, dst.size() - 1);
		pHvCall->AddOpeCode( _WORD(dst[r].first + (hvc_entry * 4)), POS);
		pHvCall->SetEntry(dst[r].second);
	}

	pHvCall->at(POS)->SetLabel("COMMON_hvcall");
	pHvCall->SetAlign(4);

	return pHvCall;
}

/**
 * @brief	insert dead code into code block
 * @return	code block after insert
 */
CCodeBlock* CBlockManager::InsertDeadCode(CCodeBlock* pCB){
    UI32 followInsNum = 2;
    while(followInsNum > 0) {
        IInstruction* pIns = m_nrmSet.CreateIns();
        if (pIns->IsComplex()){
            delete pIns;
        }else{
            pIns->AppendComment("Dead Code");
            pCB->AddOpeCode (pIns);
            followInsNum --;
        }
    }

    return pCB;
}

/**
 * @brief	insert return instruction for CALLT/SYSCALL
 * @return	code block
 */
void CBlockManager::BreakCalltBlock (CCodeBlock* pCb){

	if(pCb->GetLabel().find("callt") != std::string::npos){
		UI32 exitTime = g_rnd.GetRange(10, 20);
		UI32 insnum = pCb->GetInstructionNum();
		while (exitTime > 0) {
			IInstruction	* returnIns = CTRET();
			returnIns->AppendComment("Return_from_common_block");
			UI32 pos = g_rnd.GetRange((UI32)2, insnum - 1);
			while(pCb->at(pos)->InLoop() || pCb->at(pos)->InSequence())
				pos = g_rnd.GetRange((UI32)1, (UI32)(insnum-1));
			pCb->AddOpeCode(returnIns, pos);
			exitTime--;
			pCb->Update();
		}
		pCb->AddOpeCode(CTRET());
		pCb->Update();
	}
}


/**
 * 対象ブロック(pCB)にユーザーコードのエントリポイントを作成する。
 * 
 */
std::vector<CUserBlock*>* CBlockManager::InsertUserCode(LPCTSTR context_key , LPCTSTR user_key , TBlockConfig* pCfg, CCodeBlock* pCB) {
	
	const UI32	r5	= 5;	// jump destination
	bool		pos = true;
	
	std::string labelstr = pCB->GetName() + "_uc";
	std::string retstr	 = labelstr + "_ret";
    pCB->at(0)->SetLabel(retstr);
	
	IInstruction* mov	= MOV32P(labelstr.c_str(), r5);
	IInstruction* jmp	= JMP32(r5);

	if (pos) {
		// 対象ブロックの先頭にエントリ作成
		pCB->AddOpeCode( mov, 0);
		pCB->AddOpeCode( jmp, 1);
	}else{
		// 対象ブロックの最後にエントリ作成
		pCB->AddOpeCode( mov );
		pCB->AddOpeCode( jmp );
	}

	UserSet* 	pUs = new UserSet();		// Vector of CUserBlock
	CUserBlock*	pUb = new CUserBlock();		//
    pUb->SetKeyName(context_key, user_key);	// (%CONTEXT%の置換用, ユーザコードファイル内で対応するキー)

	pUb->SetOutputFlag(true);				// 出力ON
	pUb->EnableRegulation(false);			// 補正不可
	
	std::vector <std::string>			vUcBody;
	g_usf->GetUserCodeBody(user_key, vUcBody);
	ParseUserCode(vUcBody, pUb);

	NewINS( pUb, MOV32P(retstr.c_str(), r5));
	NewINS( pUb, JMP32(r5));				// ユーザーコードからのリターン処理
	NewINS( pUb, NOP());
	 
	pUb->SetLabel(labelstr.c_str());		// __function_NN	
	
	pUs->push_back(pUb);
	
	return pUs;
}


CCodeBlock* CBlockManager::GenerateGrBlock(UI32 N, UI32 blocksize, UI32 num, UI32 reg, LIST_INSSET* WeightSet) {

#define	ADD_OPECODE_COMMENT
	// Function to generate instruction when enable sequential
	auto GenerateSequentialIns = [=](IInstruction* pParentIns, IInstructionSet* pset, UI32 nInsId, UI32 nInsNum)
	{
		IInstruction *pIns;
		char memo[256];
		for(UI32 i = 0; i< nInsNum; i++){
			pIns = pset->CreateIns(nInsId)->Fix();
			if (pIns->GetMne()=="loop") {
				// ループ命令に依存を作るとループの繰り返し範囲が狭くなる
				// 自然な生成に任せる（狭い範囲も広い範囲もカバー）
			}else
				if (reg != 0)
					pIns->SetGrAnyOpr(reg);

			if (reg) {
				sprintf(memo, "Block[%03d] r%d (%04d)", N, reg, i);
			}else{
				sprintf(memo, "Block[%03d]     (%04d)", N, i);
			}
			pIns->AppendComment(memo);
#ifdef	ADD_OPECODE_COMMENT	// Test assemble
			UI64	bits;
			if (pIns->Assemble(&bits)) {
				sprintf (memo, "OpeCode(%llX)", bits);
			} else {
				sprintf (memo, "Asm Error !!");
			}
			pIns->AppendComment(memo);
#endif	// Test assemble
			pParentIns->SetSequentialIns(pIns);
		}
	};
	LIST_INSSET::iterator itr ;
	IInstructionSet* pset= &m_nrmSet ;
	std::pair<UI32, UI32> seqRange;
#ifdef	ADD_OPECODE_COMMENT
	UI64	bits;
#endif
	CCodeBlock* pBlock = new CCodeBlock();
	pBlock->EnableRegulation(true);

	// Gen code for vector handler
	if(blocksize > 0){
		while(blocksize >= 2) {
			IInstruction* pIns = pset->CreateIns()->Fix();
			if (pIns->GetMne()=="loop") {
				// ループ命令に依存を作るとループの繰り返し範囲が狭くなる
				// 自然な生成に任せる（狭い範囲も広い範囲もカバー）
			}else
				if (reg != 0)
				{
					pIns->SetGrAnyOpr(reg);
				}
		
				char memo[256];
				if (reg) {
					sprintf(memo, "Block[%03d] r%d ", N, reg);
				}else{
					sprintf(memo, "Block[%03d]  ", N);
				}
				pIns->AppendComment(memo);

#ifdef	ADD_OPECODE_COMMENT	// Test assemble
				if (pIns->Assemble(&bits)) {
					sprintf (memo, ", OpeCode(%llX)", bits);
				} else {
					sprintf (memo, ", Asm Error !!");
				}
				pIns->AppendComment(memo);
#endif	// Test assemble
				UI32 insLen =  pIns->GetLen();
				UI32 InsID = pIns->GetId();				
				if((InsID >= INS_CID_LD_ARRAY && InsID <= INS_CID_CAXI_ARRAY) || InsID == INS_CID_MPU_UPDATE) 
					continue;

				switch (InsID){
				case INS_ID_LOOP:
				case INS_ID_RSQRTF_D:
				case INS_ID_RSQRTF_S:
				case INS_ID_RECIPF_D:
				case INS_ID_RECIPF_S:
				case INS_ID_RECIPF_S4:
				case INS_ID_RSQRTF_S4:
					insLen = insLen + 6;
					break;

				case INS_ID_LDSR:
					insLen = 42;
					break;

				case INS_CID_PREF_I:
					insLen = 16;
					break;				

				case INS_CID_MOV_ALU:
				case INS_CID_MOVEA_ST:
					insLen = 10;
					break;

				case  INS_CID_MOV_SST:
					insLen = 16;
					break;

				case INS_CID_MOVR_SHIFT:
				case INS_CID_FPU_FPU:
					insLen = 8;
					break;

				case INS_CID_MOV5_ST:
					insLen = 6;
					break;

				case INS_CID_MOVEA_SST:
				case INS_CID_LDLBU_STCB_S: 
				case INS_CID_LDLW_STCW_F:
					insLen = 14;
					break;

				case INS_ID_SWITCH:
				case INS_CID_ALU_ALU:
					insLen = 12;
					break;

				case INS_CID_ALU_LDST:
				case INS_CID_ALU_DIV:
				case INS_CID_ALU_MUL:
				case INS_CID_ALU_FPU:
					insLen = 10;
					break;

				case INS_CID_ALU_SPECIAL:
				case INS_CID_LD_LDST:
					insLen = 20;
					break;

				case INS_CID_CMP_BCC:
				case INS_CID_ALU_BCC:
					insLen = 6;
					break;

				case INS_CID_ALU_C2B1:
					insLen = 22;
					break;

				case INS_CID_LD_ALU: 
				case INS_CID_LD_DIV:
				case INS_CID_LD_MUL: 
				case INS_CID_LD_FPU:
					insLen = 14;
					break;

				case INS_CID_LD_SPECIAL:
					insLen = 28;
					break;

				case INS_CID_LD_C2B1:
					insLen = 26;
					break;

				case INS_CID_C2B1_C2B1:
					insLen = 32;
					break;

				case INS_CID_CHANGE_PRIV:
					insLen = 6;
					break;

				case INS_CID_CMPFS_TRFSR:
					insLen = 8;
					break;

				case INS_ID_LD_BSD23:
				case INS_ID_LD_BUD23:
				case INS_ID_LD_HSD23:
				case INS_ID_LD_HUD23:
				case INS_ID_LD_WSD23:
					insLen = 6;
					pIns->opr(0)->ChangeDispTo23Bit();
					break;

				case INS_ID_ST_B_SD23:
				case INS_ID_ST_H_SD23:
				case INS_ID_ST_W_SD23:
					insLen = 6;
					pIns->opr(1)->ChangeDispTo23Bit();
					break;
				}
				
				if(blocksize >= insLen ){
					pBlock->AddOpeCode(pIns);
					pBlock->Update();
					blocksize = blocksize - insLen;
				}
		}
	} else{
		for (UI32 i = 0; i < num; i++) {
			IInstruction* pIns = pset->CreateIns()->Fix();

			if (pIns->GetMne()=="loop") {
				// ループ命令に依存を作るとループの繰り返し範囲が狭くなる
				// 自然な生成に任せる（狭い範囲も広い範囲もカバー）
			}else
				if (reg != 0)
				{
					pIns->SetGrAnyOpr(reg);
				}

				// Adjust JARL instruction to function
				if ((pIns->GetId() == INS_ID_JARLSD22 || pIns->GetId() == INS_ID_JARL) && ((g_rnd.Get() & 1) != 0)) {
					pIns->DelReverse();
					std::random_shuffle(m_vFunctionIndex.begin(), m_vFunctionIndex.end(), g_rnd);
					UI32 FuncIndex = pIns->opr(1)->Idx();
					if(m_vFunctionIndex.size()){
						std::vector<UI32>::iterator itr = std::find(m_vFunctionIndex.begin(), m_vFunctionIndex.end(), FuncIndex);
						if ( itr != m_vFunctionIndex.end() )
							m_vFunctionIndex.erase(itr);
						else{
							pIns->opr(1)->Replace(m_vFunctionIndex.back());
							m_vFunctionIndex.pop_back();
						}
					} else
						continue;
				}
				char memo[256];
				if (reg) {
					sprintf(memo, "Block[%03d] r%d (%04d)", N, reg, i);
				}else{
					sprintf(memo, "Block[%03d]     (%04d)", N, i);
				}
				pIns->AppendComment(memo);

#ifdef	ADD_OPECODE_COMMENT	// Test assemble
				if (pIns->Assemble(&bits)) {
					sprintf (memo, ", OpeCode(%llX)", bits);
				} else {
					sprintf (memo, ", Asm Error !!");
				}
				pIns->AppendComment(memo);
#endif	// Test assemble

				pBlock->AddOpeCode(pIns);

				if(pIns->GetId()<= MAX_INS_ID ){
					// Generate sequential instruction
					seqRange = (static_cast<CInstructionSet*> (pset))->m_seqInsNum.at(pIns->GetId());
					GenerateSequentialIns(pIns, pset, pIns->GetId(), g_rnd.GetRange(seqRange.first, seqRange.second) - 1);
				}
		}
	}

	return pBlock;
}

/**
 * @brief   Expand sequential instruction
 * @param	pCb: Pointer to code block
 */
void CBlockManager::ExpandSequentialInstruction(CCodeBlock* pCb)
{
	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		std::vector<IInstruction*> &pSeqIns = pCb->at(i)->GetSequentialIns();
		while (pSeqIns.size()) {
			pCb->AddOpeCode(pSeqIns.back(), i);
			pSeqIns.pop_back();
		}
	}
	return;
}


/**
 * @brief   Support Indirect Access regiter of MPU in G4MH
 * @param	pCb: Pointer to code block
 */

void CBlockManager::UpdateAccessSysReg(TBlockConfig* pCfg, CCodeBlock* pCb){
	
	IInstruction* pIns;
	const UI32 NO_MASK = 0xffffffff;
	const UI32 MAX_TRY = 10;
	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		pIns = pCb->at(i);
		UI32 InsId = pIns->GetId();

		auto IsHazardedSR = [] (UI32 sr) -> bool{
			if(((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12 ))/*MPU SRs*/ 
				|| (sr == (2*32) + 15) /* RBCR0 */
				|| (sr == (2*32) + 17) /* RBNR */
				|| (sr == (2*32) + 18)  /* RBIP */
				|| (sr == (1*32) +  0)  /* SPID */
				|| (sr == (0*32) +  5)  /* PSW */) {
				return true;
			}
			return false;
		};
				// Adjust LDSR for update specified bit
		if(InsId == INS_ID_LDSR || InsId == INS_ID_LDTC_SR || InsId == INS_ID_LDVC_SR) {
			UI32 sr = (UI32) *(pIns->opr(1));
			UI32 triedCounter = 0;

			if(g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK){
				// r0 can not be updated.
				if(pIns->opr(0)->Idx() == 0){
					pIns->opr(0)->Replace(g_rnd.GetRange(1,31));
				}
				// Set dummy constraint to 
				pIns->opr(0)->SetConstraint(new IDummyConstraint()); //Dummy constraint
			}

			if(IsHazardedSR(sr)) {
				if(pCb->GetHandlerAddress() != 0) {
					triedCounter = 0;
					while(IsHazardedSR(sr) && triedCounter < MAX_TRY) {
						pIns->opr(1)->ReFix();
						sr = (UI32) *(pIns->opr(1));
						triedCounter++;
					}
					if(triedCounter == MAX_TRY) {
						pCb->Remove(pIns);
						i--;
						continue;
					} else if(g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK){
						// r0 can not be updated.
						if(pIns->opr(0)->Idx() == 0){
							pIns->opr(0)->Replace(g_rnd.GetRange(1,31));
						}
						// Set dummy constraint to 
						pIns->opr(0)->SetConstraint(new IDummyConstraint()); //Dummy constraint
					}
				} else {
					UI32 idx = pCb->GetIndex(pIns);
					pCb->AddOpeCode(SYNCI(), idx + 1);
				}
			}

            if (((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12))/*MPU SRs*/
                || (sr == (1 * 32) + 0)  /* SPID */
                || (sr == (0 * 32) + 5)  /* PSW */) {
                IInstruction *p = NULL;
                UI32 idx = pCb->GetIndex(pIns);
                UI32 reg = g_mgr->GetHandlerReg();
                UI32 ret_reg = reg + 1;
                std::string context = GetMContext(pCfg);
                pCb->AddOpeCode((p = JARL32(reg, ret_reg)), idx);
                p->SetValid(true);
                p->SetRegulationTarget(pIns);
                p->SetSequence();

                pCb->AddOpeCode((p = MOV32P(context + "permit_exec_cur_PC", reg)), idx);
                p->SetRegulationTarget(pIns);
                p->SetSequence();
                i += 2;
                pIns->SetSequence();
                if (pCb->GetLabel() == "GM02_T00_codeblock_35_06") std::cout << pIns->GetOutCode() << std::endl;
            }

		}
	}
}


/**
 * @brief   Expand complex instruction
 * 
 * 			convert pseudo instruction to special sequence.
 */
void CBlockManager::ExpandComplexInstruction(CCodeBlock* pCb, TBlockConfig* pCfg)	{
	std::string context = GetMContext(pCfg);
	UI32 i = 0;
	while(i < pCb->GetInstructionNum()) {
		IInstruction* pIns = pCb->at(i);
		if (pIns->IsComplex() != true) {
			i++;
			continue; // Nop for NORMAL INS
		}

		UI32 insid = pIns->GetId();
		IInstruction *pMovIns, *pJarl;
		UI32 reg, targetReg, nNumOfMPUpdate;
		switch (insid) {
		case INS_CID_MPU_UPDATE:
			{	// Dynamic MPU Update
            std::stringstream ss;
            nNumOfMPUpdate = m_vMPUpdate.size();
            ss << (context + "mpu_function_") << nNumOfMPUpdate;

            pJarl = JARL32(m_nHandlerReg + 1, m_nHandlerReg);
            pJarl->AppendComment("Update MPU Config");
            pJarl->SetValid(true);
            pJarl->SetSequence();
            pJarl->SetJumpTargetLabel(ss.str().data());
            pCb->AddOpeCode(pJarl, i);

            pMovIns = MOV32P(ss.str().data(), m_nHandlerReg + 1);
            pMovIns->SetRegulationTarget(pJarl);
            pMovIns->SetSequence();
            pCb->AddOpeCode(pMovIns, i);

            // Overwrite returned register
            pMovIns = MOV32(g_rnd.Get(), m_nHandlerReg);
            pCb->AddOpeCode(pMovIns, i + 2);

            pCb->Remove(pIns);
            m_vMPUpdate.push_back(nNumOfMPUpdate);
			break;
		}
		case INS_CID_CLR1_B ... INS_CID_CAXI_ARRAY:
		case INS_CID_MOV_ALU ... INS_CID_MPU_CHECK:
			{
			ComplexInstruction* pCi = static_cast<ComplexInstruction*>(pIns);
			std::vector<std::pair<IDirective*, UI32>> vAsyncList;
			UI32 size = pCi->size();

			if(size == 0){
				pCb->Remove(pIns);
				pCb->Update();
				continue;
			}
			IDirective *pDir = NULL;
			UI32 n = 0;
			// Gather async labels, and generate randomized position in custom sequence.
			while((pDir = pIns->GetDirective(n)) != NULL) {
				CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				if(pAL != NULL) {
					vAsyncList.push_back(std::make_pair(pDir, g_rnd.GetRange((UI32)1, (UI32)size)));
					pIns->RemoveDirective(pDir);
					continue;
				}
				n++;
			}

            // lambda expression: Check ability to set async. event for sub-instruction in complex
            auto CanRequestAsync = [] (UI32 id, IInstruction *p) {
                if(id >= INS_CID_MOV_ALU && id <= INS_CID_ALU_BCC
                    && p->GetForwardIns() == NULL) { // 2nd instruction of C2B1 couple
                    return false;
                }
				return true;
			};
			IInstruction *p = NULL;
			std::vector<IInstruction*> vIns;    // List of instruction that can be set async. event
			// Expand complex instruction
			while (pCi->size()) {
				p = pCi->back();

				// Difference instruction size issue 
				// Fix displacement 23 for case capacity 23 but actual value  = 16.
				p->SetFixLen();

				if(pCi->GetId() >= INS_CID_RIE_FPU32 && pCi->GetId() <= INS_CID_RIE_INT64)
					p->SetId(pCi->GetId());

				pCb->AddOpeCode(p, i);
				// Avoid inserting instruction in simulation phase. It cause mismatch PC in common block
				if(pCb->GetLabel().find("callt") != std::string::npos)	{
					std::vector<IInstruction*> vneed =  p->GetInsNeed();
					for(UI32 i = 0; i < vneed.size(); i++) {
						IInstruction* pNeed = vneed.back();
						pCb->AddOpeCode(pNeed, i);
						vneed.pop_back();
					}
					p->ClearInsNeed();
				}
			
				pCi->pop_back();
                if(CanRequestAsync(pCi->GetId(), p)) {
                    vIns.push_back(p);
                }
			}

            // Distribute async. event to sub-instruction randomly
			std::vector<std::pair<IDirective*, UI32>>::iterator itr;            
			for(itr = vAsyncList.begin(); itr != vAsyncList.end(); itr++) {
                UI32 pos = g_rnd.GetRange((UI32) 0, (UI32) (vIns.size() - 1));
				vIns[pos]->SetDirective(itr->first);
			}
			pIns->DirMoveTo(p);
			pCi->clear();
			pCb->Remove(pCi);
			break;
		}
		case INS_CID_CHANGE_MODE:
		case INS_CID_CHANGE_VMACHINE:
			MSG_WARN(0, "Setting changing mode/machine doest not affect.\n");
			pCb->Remove(pIns);
			break;

		default :		// User Instruction
			{
			std::string label;
			g_usf->GetUserCodeKey(insid - (MAX_INS_ID + 1), &label);
			if(label.size() != 0) { // User Code
				reg = 31;
				targetReg = g_rnd.GetRange(1, 30);

				// Label of user code block
				std::string labelUserBlock("");
				std::stringstream ss;
				ss << GetTContext(pCfg);
				ss << label;
				ss >> labelUserBlock;

				// Jump to user code
				IInstruction* pJarl = JARL32(targetReg, reg);
				pJarl-> SetValid(true);
				pJarl-> SetSequence();
				pJarl->AppendComment("Jump to user code");
				pCb->AddOpeCode(pJarl, i);

				pMovIns = MOV32P(labelUserBlock, targetReg);
				pMovIns->SetRegulationTarget(pJarl);
				pMovIns->SetSequence();
				pCb->AddOpeCode(pMovIns, i);

				// Overwrite returned register due to mismatch PC
				pMovIns = MOV32(g_rnd.Get(), targetReg);
				pCb->AddOpeCode(pMovIns, i + 2);

				// Overwrite target register due to mismatch PC
				pMovIns = MOV32(g_rnd.Get(), reg);
				pCb->AddOpeCode(pMovIns, i + 2);

				pCb->Remove(pIns);
				i++;
			} else { // Asynchronous Event
				UI32 UC_NUM = g_usf->GetUserCodeNum();

				IExceptionConfig* pExpCfg = NULL;
				UI32 id = insid - (MAX_INS_ID + 1) - UC_NUM;

				// Acquire exception information
				pExpCfg = g_exp->GetExpConfig(id);

				if(pExpCfg != NULL) {
					std::stringstream ss;
					std::string strAsyncLabel;
					std::string strExpName = pExpCfg->m_name;
					CAsyncLabel *pAsyncLabel;

					// Convert to lower cases
					std::transform(strExpName.begin(), strExpName.end(), strExpName.begin(), [] (int ch) {return std::tolower(ch);});

					pAsyncLabel = new CAsyncLabel(strExpName, GetTContext(pCfg), m_nAsyncCount, true);

					if(pExpCfg->m_uchannel != 0){
						// Randomizing interrupt channel
						UI32 channel = g_rnd.GetRange(pExpCfg->m_lchannel, pExpCfg->m_uchannel);
						pAsyncLabel->m_channel = channel;

						// Convert from channel -> interrupt cause code
						UI32 causecode = pExpCfg->m_lcode + channel;
						if(causecode > pExpCfg->m_ucode)
							causecode = pExpCfg->m_ucode;
						pAsyncLabel->m_causecode = causecode;
					} else {
						pAsyncLabel->m_causecode = pExpCfg->m_lcode;
					}

					// Randomizing cause code for SYSERR
					if(pExpCfg->m_name == "SYSERR") {
						//pAsyncLabel->m_causecode = g_rnd.GetRange(pExpCfg->m_lcode, pExpCfg->m_lcode);

						// SYSERR support both sync. and async events depends on HW.
						// It is agreed that causecode 0x010 is for async. type.
						pAsyncLabel->m_causecode = 0x0010;
					} else if (pExpCfg->m_name == "EIINT") {
						pAsyncLabel->m_priority = g_rnd.GetRange(0, 255);
					} else if (pExpCfg->m_name == "EITBL" || pExpCfg->m_name == "RBINT") {
						pAsyncLabel->m_priority = g_rnd.GetRange(0, 255);
					} else if (pExpCfg->m_name == "GMEIINT" || pExpCfg->m_name == "BGEIINT") {
						pAsyncLabel->m_priority = g_rnd.GetRange(0, 255);
                        pAsyncLabel->m_gpid = pCfg->m_GMID; // Guest ID
					} else if (pExpCfg->m_name == "GMEITBL" || pExpCfg->m_name == "GMRBINT") {
						pAsyncLabel->m_priority = g_rnd.GetRange(0, 255);
                        pAsyncLabel->m_gpid = pCfg->m_GMID; // Guest ID
					} else if (pExpCfg->m_name == "GMFEINT" || pExpCfg->m_name == "BGFEINT") {
                        pAsyncLabel->m_gpid = pCfg->m_GMID; // Guest ID
                    }

					if(i < pCb->GetInstructionNum() - 1) {
						IInstruction *pNextIns = pCb->at(i + 1);
						//Consecutive event requested at trap -> handler -> event occur
						if(pNextIns->Behavior(IInstruction::TRAP_EXCEPTION) || pNextIns->GetId() == INS_CID_RIE_FXU64 || pNextIns->GetId() == INS_CID_RIE_INT64 || pNextIns->GetMne() == "loop") {
							IInstruction *pNewIns = NOP();
							pCb->AddOpeCode(pNewIns, i + 1);
							pNextIns = pNewIns;
						}
						pIns->DirMoveTo(pNextIns);
						UI32 n = 0;
						IDirective *pDir = NULL;
						while((pDir = pNextIns->GetDirective(n)) != NULL) {
							CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
							if(pAL != NULL) {
								//if(pAL->m_causecode == pAsyncLabel->m_causecode)
								if(g_sim->CheckSameInterruptType(pAL->m_name, pAsyncLabel->m_name))	// INCT1 can keep only 1 request of a async. event
									break;
							}
							n++;
						}
						if(pDir == NULL) {													// The cause code is not exists
							if (pExpCfg->m_name == "RBINT" || pExpCfg->m_name == "GMRBINT") {
								pExpCfg->m_name == "RBINT" ? pAsyncLabel->m_name = "eitbl" : pAsyncLabel->m_name = "gmeitbl";
								pNextIns->SetDirective(pAsyncLabel);
							} else {
								pNextIns->SetDirective(pAsyncLabel);
							}
					    }
					}
					pCb->Remove(pIns);
					m_nAsyncCount++;
				} else { // Invalid event.
					pCb->Remove(pIns);
				}
			}
			} 
		}
	}
}

/**
 * @brief	Bcond control
 * 
 * 	1. Search all branch(and some of jump) operation.
 * 	2. Set a flag to all branch , TAKEN or NOT. 
 * 	3. Divide block to small block that has TAKEN brancn at the end.
 * 	4. Shuffle small blocks and connect a block end with next head.
 */
void CBlockManager::ChainBcondSequence(CCodeBlock* pCb)
{
	FROG_ASSERT(pCb && pCb->GetInstructionNum());
	// ブロック内の各命令について先頭からのオフセット位置を得る
	std::unique_ptr<std::map<IInstruction*,UI32>> pOffsMap(pCb->GetOffsetMap());
	std::string cbn = pCb->GetName();
	char buff[1024];
	UI32 JmpReg = 0;
	// Lamda function to check pIns jump to next block or inside CCodeBlock
	// Jump to next block: 
	//		- pIns in random block
	//		- pIns is not in loop sequence
	// Jump inside current block:
	//		- Other case
	auto JmpNextBlock = [&] (CCodeBlock* pcb, IInstruction* p) ->bool {
		const UI32 insId = p->GetId();
		// Jump instruction in loop-- jmp inside loop sequence
		if(p->InLoop() == true) 
			return false;
		// Always jump instruction
        if (insId == INS_ID_CTRET || insId == INS_ID_EIRET || insId == INS_ID_FERET || insId == INS_ID_JARL || insId == INS_ID_DBRET
            || insId == INS_ID_JARLD32 || insId == INS_ID_JARLSD22 || insId == INS_ID_JRSD22 || insId == INS_ID_BR_SD9 ||
            insId == INS_ID_JRD32 || insId == INS_ID_JMP || insId == INS_ID_JMPD32 || insId == INS_ID_DISPOSE_R3) {
            p->SetTaken(true);
            return true;
        }
        if (pcb->GetLabel().find("codeblock") != std::string::npos)
            return true;

		return false;
	};

	// Lamda function to set target label for instruction or generate additional instruction
	auto SetTargetLabel = [&JmpReg](IInstruction* p, std::string label)	{
		UI32 pId = p->GetId();
		IInstruction* adjust = nullptr;
		if(pId == INS_ID_JARL || pId == INS_ID_JMP/* || pId == INS_ID_DISPOSE_R3*/)
			adjust = MOV32P (label, p->opr(JmpReg)->Idx());
		
		if(pId == INS_ID_JMPD32 || (pId == INS_ID_DISPOSE_R3 /*&& (p->GetOprDst() & (1 << p->opr(2)->Idx()))*/))
			p->SetJumpTargetLabel(label);

		p->opr(JmpReg)->SetLabel(label);
		return adjust;
	};

	// Lamda function to get target range
	auto GetJmpRange = [](CCodeBlock* pCB, IInstruction* p) ->UI32 {
		UI32 limited = pCB->GetInstructionNum() - 1;
		UI32 stopPoint = 0;
		if(pCB->GetHandlerAddress() == ADR_COMMON_CALLT)
			stopPoint = INS_ID_CTRET;
		if(p->InLoop() == true)
			stopPoint = INS_ID_LOOP;

		// Random dest instruction in loop sequence only
		for(UI32 i = pCB->GetIndex(p) + 1; i < pCB->GetInstructionNum() - 1; i++){
			if(pCB->at(i)->GetId() == stopPoint){
				limited = i;
				break;
			}
		}
		return limited;
	};

	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		IInstruction*		pIns = pCb->at(i);
		IInstruction* adjust = nullptr;
		JmpReg = 0;
		if(pIns->HasBranchConstraint() && pIns->InLoop() == false)
			continue;

		if(pIns->GetReverse() == nullptr)
			continue;

		if (i >= (pCb->GetInstructionNum()-1)) {
			if(pIns->GetMne().find("ret") == std::string::npos){
				pIns->SetTaken(true);
				pIns->opr(0)->RandomTarget();
			}
		}
		// This instruction will be adjust in simulation
		if(JmpNextBlock(pCb, pIns) == true){
			continue;
		}
		// BCond in vector block and common block
		std::sprintf(buff, "%s_br%d", cbn.c_str(), i + 1);
		std::string label(buff);
		if(pIns->GetId() == INS_ID_DISPOSE_R3)
			JmpReg = 2;

		// Set label to branch
		adjust = SetTargetLabel(pIns, label);
		// Do not adjust value again in simulation
		pIns->SetConstraint(false);

		UI32 limited = GetJmpRange(pCb, pIns);
		UI32 pos = g_rnd.GetRange(i+1, limited);
		IInstruction* dst =  pCb->at(pos);
		UI32 distance = std::abs((int)((*pOffsMap)[dst] - (*pOffsMap)[pIns]));
		UI32 try_time = 10;
		// Main operation
		while((cbn.find("debug") != std::string::npos && pCb->at(pos)->GetId() == INS_ID_DBRET) || distance > 80
			|| (pIns->InLoop() == false && pCb->at(pos)->InSequence() == true) || pCb->at(pos)->GetId() == INS_ID_SHORT){
			try_time--;
			if(try_time == 0){
				pIns->opr(JmpReg)->RemoveLabel();
				if(adjust != nullptr || pIns->GetId() == INS_ID_JMPD32){
					dst = pCb->at(i+1);
				} else {
					pIns->opr(JmpReg)->Replace(pIns->GetLen());
					label = "";
				}
				break;
			}
			pos = g_rnd.GetRange(i+1, limited);
			dst =  pCb->at(pos);
			distance = std::abs((int)((*pOffsMap)[dst] - (*pOffsMap)[pIns]));
		}

		if(label.size())
			dst->SetLabel(label);

		if(adjust != nullptr){
			if(pIns->GetId() == INS_ID_DISPOSE_R3){
				pIns->SetInsNeed (adjust);
				continue;
			}
			pIns->DirMoveTo(adjust);
			adjust->SetSequence();
			adjust->SetInLoop(pIns->InLoop());
			pCb->AddOpeCode(adjust, i);
			i++;
		}	
	}
}

/**
 * @brief  指定ブロック内のloop命令を安定的なループに再構成する。
 * @param  pCb 処理対象のブロック
 */
void CBlockManager::MakeLoopSequence(CCodeBlock* pCb) {

#if DBGMODE
	bool debug1 = !true;
	bool debugL = false;
#endif
	// Improving number instruction in loop sequence
	// Lamda function to change register of instruction p
	// Try to keep instruction in loop sequence
	auto ChangingRegister = [] (IInstruction* p, UI32 notUseId)	-> bool {
		UI32 s = p->GetConstraintBit(); // 補正ソースは値が変更される
		UI32 d = p->GetOprDst();
		std::vector <UI32> vfreeIdx;

		// This function was used to replace operand index
		auto ReplaceOperand = [&p, notUseId] (IOperand* opr, UI32 OprIdx){
			// Adjust list12
			UI32 s = p->GetConstraintBit(); // 補正ソースは値が変更される
			UI32 d = p->GetOprDst();
			UI32 clearbit = s & d;
			UI32 updatebit = 0;
			std::vector<UI32> vFreeBit = {};
			for(UI32 i = 20; i < 32; i++)
				if ( (((notUseId >> i) & 0x1) == 0) && (((clearbit >> i) & 0x1) == 0))
					vFreeBit.push_back(i);

			if(vFreeBit.size() != 0){
				std::random_shuffle(vFreeBit.begin(), vFreeBit.end(), g_rnd);
				updatebit = (vFreeBit.back() == 30 ) ? 0 : ((vFreeBit.back() > 27) ? (24 + 31 - vFreeBit.back()) : (20 + 27 - vFreeBit.back()));
			}
			if(clearbit == 0 || clearbit == 0x8)// SP is rw
				return;
			else{
				UI32 val = (((UI32) * opr) | (1 << updatebit));
				for(UI32 i = 0; i < 32; i++)
					if(((clearbit >> i) & 0x1) == 1){
						UI32 ClearPos = (i == 30 ) ? 0 : ((i > 27) ? (24 + 31 - i) : (20 + 27 - i));
						val = val & (~(1 << ClearPos)) ;
				}

				opr->Replace(val);
			}
			s = p->GetConstraintBit();
			d = p->GetOprDst();
			clearbit = (notUseId & (s | d));

			if(clearbit == 0 || clearbit == 0x8)// SP is rw
				return;
			else{
				UI32 val = ((((UI32) * opr) | (1 << updatebit) ) & (~clearbit)) ;
				opr->Replace(val);
			}		
		};
		

		// Collect all free operand index
		for(UI32 i = 0; i < 32; i++)
			if((((notUseId | s | d ) >> i) & 0x1) == 0)
				vfreeIdx.push_back(i);

		std::random_shuffle(vfreeIdx.begin(), vfreeIdx.end(), g_rnd);
		for(UI32 op = 0; op < p->GetOpNum(); op++){
			IOperand* opr = p->opr(op);
			UI32 idx = p->opr(op)->Idx();
			if((p->GetId() == INS_ID_DISPOSE_R3 || p->GetId() == INS_ID_DISPOSE) && op == 1 ){
				ReplaceOperand (opr, vfreeIdx.back());
				continue;
			}
			// Can not improve case idx = 0
			// Can not change r0 in case operand type in: Imm, SImm ...
			// It will be check after this function 
			if(idx == 0)
				continue;

			// Conflict inside instruction and operand
			// 1. divf.d r18, r16, r16
			while ((((s & d) >> idx) & 0x1) && vfreeIdx.size() > 0){
				if(p->opr(op)->Replace(vfreeIdx.back()) == true){
					idx = p->opr(op)->Idx();
					s = p->GetConstraintBit();
					d = p->GetOprDst();
				}
				vfreeIdx.pop_back();
			}

			// divf.d r18, r16, r20;
			// addf.d r18 ,r6, r8;
			while ( (((notUseId & (s | d)) >> idx) & 0x1) && vfreeIdx.size() > 0 ) {
				if(p->opr(op)->Replace(vfreeIdx.back()) == true){
					idx = p->opr(op)->Idx();
					s = p->GetConstraintBit();
					d = p->GetOprDst();
				}
				vfreeIdx.pop_back();
			}
			// It is same with don't use register
			while((notUseId & (1 << idx)) && vfreeIdx.size() > 0){
				if(p->opr(op)->Replace(vfreeIdx.back()) == true){
					idx = p->opr(op)->Idx();
					s = p->GetConstraintBit();
					d = p->GetOprDst();
				}
				vfreeIdx.pop_back();
			}
		}
		
		return true;
	};


	// Loop命令を検出する(下から上)
	// ループカウンタ設定命令を生成しループ範囲を広げれるところまで拡大していく(↑方向)
	UI32 i;
	for (UI32 iNum = pCb->GetInstructionNum(); iNum > 0; iNum--) {
		i = iNum - 1;
		IInstruction* pIns = pCb->at(i);
		std::string   mne  = pIns->GetMne();
		
		if (pIns->InSequence()/* && pIns->GetInsNeed().size() == 0 */) {
			continue; // 一連の手順の一部として生成される不動命令は処理しない(switchに係わる命令等)
		}
		
		if (mne == "loop") {
			
#if DBGMODE
			if (debug1) {
				std::cout<< std::endl << "=============================" << std::endl;
				pCb->Update();
				pCb->Dump(std::cout);
				debug1 = false;
				debugL = true;
			}
#endif
			// ループ構成準備、ループカウンタのレジスタを取得、ラベルを生成。
			std::stringstream ss;
			ss << pCb->GetName() << "_Lp_" << i;
			REGFLG idx  = pIns->opr(0)->Idx();
			
			pIns->SetSequence();
			UI32 looptime = g_rnd.GetRange(1U, g_cfg->m_nMaxLoop+1);
			IInstruction* terminateIns = NULL;
		
			// Do not generate contents for loop in FWD
			if(pIns->GetInsNeed().size()) {
				pIns->opr(1)->Replace(0x0);
				pIns->opr(0)->SetConstraint(new IValConstraint(looptime, looptime,0,0) );
				continue;
			}
			pIns->opr(1)->SetLabel(ss.str().c_str());
			// MOVカウントセット（A）
			terminateIns = MOV5(looptime, idx);

			// loopにラベルが付いている（jmpの着地点など）場合、
			// そのままloopの直前にMOVカウントセットしても、実行されない。
			// 着地点をMOVカウントセット位置に再設定する。
			pIns->DirMoveTo(terminateIns);
			terminateIns->SetRegulationTarget(pIns);
			// ループの範囲を広げていく、範囲が決まったらカウンタ設定命令（A）を挿入する
			// 範囲はループ命令から上に遡りながら命令を走査し調べる。
			// レジスタの依存関係がないことが条件 
			//
			// SetInLoopフラグについて・・・
			//      mov      3,  r9          ; 3周実行
			//__for:                         ;
			//		addi     5,  r4,    r8   ; r8を補正(x)
			//      addf.s  r8,  r5          ; 補正されたオペランドr8で実行
			//      sub     r7,  r4          ; 補正命令(x)に影響するレジスタが書き換えられると
			//		loop    r9,  __for       ; ループで戻ったときにおかしくなる
			//                               ; よってループ内の補正命令は "mov imm, reg"で補正する
			UI32 lp = i;
			REGFLG regX = 0;

			for (; lp > 0; lp--) {
				IInstruction* pJns = pCb->at(lp - 1);	// j::loopのすぐ上の命令
				if (pJns->InSequence()) {
					break; // 立入禁止で打ち切り
				}
				
				if (pJns->Behavior(IInstruction::JMP) ){
					if((pJns->GetId() >= INS_ID_JARLSD22 && pJns->GetId() <= INS_ID_JRD32) || pJns->GetId() == INS_ID_DISPOSE_R3 || pJns->GetId() == INS_ID_SWITCH){
						pJns->SetReverse(NOP());
						pJns->opr(0)->RemoveLabel();
					} else
						break; // ジャンプ命令で打ち切り
				}

				/*[FROG]TODO: Limitation - don't support resbank in loop sequence.
				LDSR can change the status. It cause difference result in 1 and 2 loop
				MDP occur at stc.b r1,[r21] in second loop
					mov5 2,r14
					roundf.dl r30,r6
					stc.b r1,[r21]
					ldsr r17,sr0,sel5
					synci
					floorf.dul r24,r8
					loop r14,0x12*/
				if (pJns->GetId() == INS_ID_RESBANK || pJns->GetId() == INS_ID_LDSR) {
					break;
				}

				if (pJns->GetLabel().length() > 0) {
					break; // ジャンプ命令の着地で打ち切り
				}

				UI32 s = pJns->GetConstraintBit(); //pJns->GetGrSrc(); // 補正ソースは値が変更される
				UI32 d = pJns->GetOprDst();
				UI32 pJnsId = pJns->GetId();

				// FROG [TODO] Increase/ decrease instruction , update SP will error
				if(pJnsId >= INS_ID_LD_B_INC && pJnsId <= INS_ID_ST_W_DEC)
					break;
				
				if((pJnsId == INS_ID_DISPOSE || pJnsId == INS_ID_DISPOSE_R3 || (pJnsId >=  INS_ID_POPSP && pJnsId <= INS_ID_PUSHSP)) && looptime > 1) 	 		
					break;

				// Improving number instruction in loop sequence
				ChangingRegister(pJns, regX);
				s = pJns->GetConstraintBit();
				d = pJns->GetOprDst();
				if (pJns->GetMne() == "dispose") {
					s &= ~(1 << 3);
					if (pJns->GetId() == INS_ID_DISPOSE_R3) {
						s |= (1 << (pJns->opr(2)->Idx()));
					}
				}

				if (s & d) {
					break; // divf.d r18, r16, r16
				}
				if (regX & (s | d)) {
					break; // divf.d r18, r16, r20; addf.d r18 ,r6, r8
				}else{
					regX |= (s | d);
				}
				if (regX & (1 << idx)) {
					break; // loop インデックスに影響する
				}
				pJns->AppendComment(" in_loop");
				pJns->SetInLoop();
				pJns->SetSequence();

				// Do not set sequence for loop instruction in loop sequence -> It will be adjusted in next time
				// mov              3,r8
				// loop             r14,0x4ace  (NMNT_codeblock_11_04_Lp_3
				// sxh              r13
				// cmpf.s4          0xc,wr19,wr9,wr15
				// loop             r8,frog_P00NMNT_codeblock_11_04_Lp_3
				if(pJns->GetId() == INS_ID_LOOP)  {
					UI32 ltime = g_rnd.GetRange(1U, g_cfg->m_nMaxLoop+1);
					while(ltime == looptime)
						ltime = g_rnd.GetRange(1U, g_cfg->m_nMaxLoop+1);
					pJns->opr(1)->Replace(0x0);
					IInstruction* adjustment = MOV5(ltime, pJns->opr(0)->Idx());
					adjustment->SetSequence();
					pCb->AddOpeCode(adjustment, pCb->GetIndex(pJns));
				}
			}

			//--------------------------------------------------------------
			// 繰り返しが自分自身の空ループを間引く、ここから
			if (lp == i) {
				// ラベルが付いていないもの
				if (terminateIns->GetLabel() == "") {
					// 7/8を間引くぐらいが自然になる
					if ((g_rnd.Get() & 3) == 0) {
						delete terminateIns;
						pCb->Remove(pIns);
						pCb->Update();
					}else{
						pCb->at(lp)->SetLabel(ss.str());
						pCb->AddOpeCode(terminateIns, lp);
					}
				}else{
					pCb->at(lp)->SetLabel(ss.str());
					pCb->AddOpeCode(terminateIns, lp);
				}
			}else
			// 繰り返しが自分自身の空ループの処理、ここまで
			//--------------------------------------------------------------
			// 必要ないなら下記ブロックだけ
			{			
				pCb->at(lp)->SetLabel(ss.str());
				pCb->AddOpeCode(terminateIns, lp);
			}
		}
	}
#if DBGMODE
	if (debugL) {
		std::cout << "----------------------------------------------------" << std::endl;
		pCb->Update();
		pCb->Dump(std::cout);
	}
#endif
	
}


/**
 * @brief RType制御(SIMDのアドレッシングについての除外項目)
 * 
 * Base = {Step/Index}となる命令は正常に補正できないため、使用する汎用レジスタを差し替える
 */
void CBlockManager::RTypeVerify(CCodeBlock* pCb) {
	FROG_ASSERT(pCb);
	
	// 
	UI32 iNum = pCb->GetInstructionNum();
	for (UI32 i = 0; i < iNum; i++) {
		pCb->at(i)->RTypeVerify();
	}
}

/**
 * @brief 誤差依存の伝搬切断処理
 * 
 * この関数は3つのラムダ式とメイン処理で構成される。
 * ハードウェアと吸収しきれない差分（FPU演算の誤差など）が
 * シミュレーション制御に影響しないよう、参照される前に上書きされる制御をつくり出す。
 * この問題の最もシンプルな解決方法は誤差命令実行後、すぐにMOV命令で上書きすることである。
 * しかしランダム検証という性質上、生成されるパタンは「自然にでたらめな命令列、かつ無難に終了すること」が期待される本質部分である。
 * 固定コードはとことん避けたいのでつぶす命令位置を後ろにずらしている。
 */
void CBlockManager::RemoveRegDependance(CCodeBlock* pCb) {

		
	auto GenDestIns = [&](IInstruction* pInsMismatch, UI32 reg) -> IInstruction* {
		const UI32 max_challenge = 30;
		UI32 InsId = pInsMismatch->GetId();
		if(InsId == INS_ID_RECIPF_S4 || InsId == INS_ID_RSQRTF_S4) {
			UI32 wr;
			do {
				wr = g_rnd.GetRange(0, 31);
				} while (wr == reg);
			return MOVVW4(wr, reg);
		}
		for (UI32 n = 0; n < max_challenge; n++) {
			IInstruction* pInsNew = m_nrmSet.CreateIns();
			//
			std::string mne = pInsNew->GetMne();
			if (pInsNew->Category(IInstruction::ICAT_FPU_S) || pInsNew->Category(IInstruction::ICAT_FPU_D)) {
				delete pInsNew;
				continue;
			}
			if (/*mne == "rsqrtf.s" || mne == "rsqrtf.d" || mne == "recipf.s" || mne == "recipf.d" ||*/ 
				mne == "stsr" || mne == "sttc.sr"|| mne == "stvc.sr" || mne == "sttc.pc" ||			// 
				mne == "jarl" || mne == "setf")
			{
				delete pInsNew;
				continue;
			}
			if (pInsNew->Behavior(IInstruction::LOAD_MEMORY)) {
				delete pInsNew;
				continue;
			}
			
			// G3M DIV does not write back gr on dividing ZERO.
			if (mne.find("div", 0) == 0) {
				delete pInsNew;
				continue;
			}

			UI32 bitreg = ((1 << reg) | (1 << (reg ^ 1)));
            if ((pInsNew->GetOprSrc() & bitreg) != 0) { 
                delete pInsNew;
                continue; 
            }
            for (UI32 p = 0; p < pInsNew->GetOpNum(); p++) {
                if (pInsNew->opr(p)->Attr(IOperand::OPR_ATTR_GR)  == true  &&
                	pInsNew->opr(p)->Attr(IOperand::OPR_ATTR_DST) == true  &&
                    pInsNew->opr(p)->Attr(IOperand::OPR_ATTR_SRC) == false &&
                    pInsNew->opr(p)->Replace(reg) == true )
                {
                    return pInsNew;
                }
            }
			delete pInsNew;
		}
		return MOV32(g_rnd.Get(),reg);
	};

	
	auto CheckDepend = [&](IInstruction* p, UI32 reg, bool isWR=false) -> SI32 {
		UI32 opNum = p->GetOpNum();
		std::string mne = p->GetMne();

		if (p->Behavior(IInstruction::JMP)) {
			return 1;
		}

		if (p->HasAsyncLabel())
			return 1;

		if(isWR) {
			for (UI32 j = 0; j < opNum; j++) {
				IOperand* jopr = p->opr(j);
				if (jopr->Attr(IOperand::OPR_ATTR_WR) != true) {
					continue;
				}

				UI32 regN = jopr->Idx(); 
				if (jopr->Attr(IOperand::OPR_ATTR_SRC) != true) {
					if ((regN == reg) && (jopr->Attr(IOperand::OPR_ATTR_DST)) && (mne.find("div", 0) != 0)) {
						return -1;
					}
					continue;
				}
				if (regN == reg) {
					return 1;
				}
			}
		} else {
			if ((mne == "prepare" || mne == "pushsp"))
				return 1;
			for (UI32 j = 0; j < opNum; j++) {
				IOperand* jopr = p->opr(j);
				if (jopr->Attr(IOperand::OPR_ATTR_GR) != true) {
					continue;
				}
				
				if (p->HasConstraint()) {
					return 1;
				}

				UI32 regN = jopr->Idx(); 
				if (jopr->Attr(IOperand::OPR_ATTR_SRC) != true) {
					if ((regN == reg) && (jopr->Attr(IOperand::OPR_ATTR_DST)) && (mne.find("div", 0) != 0)) {
						return -1;
					}
					continue;
				}
				if (jopr->Attr(IOperand::OPR_ATTR_PAIR)) {
					if (regN == (reg & ~1U)) {
						return 1;
					}
				}else if (regN == reg) {
					return 1;
				}
			}
		}
		return 0;
	};
	
	bool bdebug = false;

	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		IInstruction* pIns = pCb->at(i);
		std::vector<UI32> depreg = pIns->GetOprIdxMistmatch();
			
		if (depreg.empty() || pIns->GetLabel().find("Change_to") != std::string::npos) {
			if (bdebug) std::cout << " Non depend ins : " << pIns->GetCode() << std::endl;
			continue; // 依存関係でのエラーを発生させない、次の命令へ
		}
		UI32 InsId = pIns->GetId();
		bool IsWReg = false;
		if(InsId == INS_ID_RECIPF_S4 || InsId == INS_ID_RSQRTF_S4)
			IsWReg = true;
	
		// 誤差発生を検出。
		UI32 holdPos = i + 1; // 誤差発生命令の次の命令を指す。
		UI32 h;
		// Detect Depend!! -> search soruce
		if (bdebug) std::cout << "Dependent OPECODE : " << pIns->GetCode() << std::endl;
		
		// 潰すべき汎用レジスタ分処理
		for (UI32 v = 0; v < depreg.size(); v++) {
			if (bdebug) std::cout << "r" << std::dec << depreg[v] <<" - Start Check depend" << std::endl;
			
			IInstruction* dlnk = GenDestIns(pIns, depreg[v]);
			dlnk->AppendComment("Overwrite precision error!");
			for (h = holdPos; h < pCb->GetInstructionNum(); h++) {
				
				if(pIns->GetForwardIns() != nullptr && pIns->GetForwardIns() == pCb->at(h)){
					pCb->AddOpeCode(dlnk, h);
					break;
				}
				if(pCb->at(h)->InSequence()){
					pCb->AddOpeCode(dlnk, h);
					break;
				}
				

				if (pCb->at(h)->GetOprIdxMistmatch().empty() != true){
					if (bdebug) std::cout << " Insert DeLINK : " << dlnk->GetCode() << std::endl;
					if (bdebug) std::cout << "\t\tHAVE DEPEND: " << pCb->at(h)->GetCode() << std::endl;
					pCb->AddOpeCode(dlnk, h);
					break;
				}
				SI32 retDepend = CheckDepend (pCb->at(h), depreg[v], IsWReg); 
				if (retDepend > 0) {
					if (bdebug) std::cout << " Insert DeLINK : " << dlnk->GetCode() << std::endl;
					if (bdebug) std::cout << "\t\tHAVE DEPEND: " << pCb->at(h)->GetCode() << std::endl;
					pCb->AddOpeCode(dlnk, h);
					break;
				} else 
				if (retDepend < 0) {
					// 自然に依存レジスタが潰された、よって何もしない
					if (bdebug) std::cout << "\t\tNEED TO DeLINK: " << pCb->at(h)->GetCode() << std::endl;
					if (pCb->at(h)->GetCoupleIns() == nullptr) {	// this instruction is not LDL
						pCb->at(h)->SetCoupleIns(dlnk);
					}
					pCb->AddOpeCode(dlnk, h+1);
					//delete dlnk;
					break;
				} else {
					if (bdebug) std::cout << "\t\tNO CARE : " << pCb->at(h)->GetCode() << std::endl;
				}
			}
			if (h >= pCb->GetInstructionNum()) {
				if (bdebug) std::cout << "Last Append" << std::endl;
				pCb->AddOpeCode(dlnk);
			}
		}
	}	
}


// ■ 強制例外発生制御
// -------------------------------------------------------------
// ここでは指定された確率に基づいて、例外を起こすか起こさないかを決定する。
// また強制発生ための設定をしておく（方法は要因によって異なる）。
// 
// 命令実行時に例外を発生させるかどうかをランダムに選択させると、
// ロールバックなどにより１つの命令が複数回シミュレーションされた場合、その度に例外発生が分岐する。
// 前回のシミュレーション結果と異ならないような制御も必要になる（補正命令が積み重なる）。
// よって例外の発生判定はここで決定しておく。
//
void CBlockManager::PresetException(CCodeBlock* pCb, IException* pEx) {

	FROG_ASSERT(pCb);
	
	if (pEx == NULL) { // 例外が設定されていない場合
		return;
	}
	
	// Raise Exception
	UI32 jNum = pCb->GetInstructionNum();
	for (UI32 i = 0; i < jNum; i++) {
		IInstruction* pIns = pCb->at(i);
		std::string mne = pIns->GetMne();
		if ((pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) && (pIns->GetRegulationTarget() == nullptr)) {
			
			IValConstraint* pVc = NULL;
	
			// MAE
			pVc = NULL;
			for (UI32 N=0; N< pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					break;
				}
				if (popr->Attr(IOperand::OPR_ATTR_SMEM) || popr->Attr(IOperand::OPR_ATTR_LMEM)) {
					if (((pVc = popr->GetConstraint()) != NULL) && pVc->m_nMsk /* バイトアクセスは対象外 */) {
						break;
					}
				}
				pVc = NULL;
			}
			if ((pVc != NULL) && pEx->RaiseException(IException::EXP_MAE) && mne != "switch") {
				#if !defined(NDEBUG)
				std::cout << "@MAE ---> " << pIns->GetCode() << std::endl;
				#endif
				pVc->Unalign();
				continue;
			}

			// MDP
			pVc = NULL;
			for (UI32 N=0; N < pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					break;
				}
				if ((pVc = popr->GetConstraint()) == NULL) {
					continue;
				}
				if (pVc->GetType(IValConstraint::STORE_MEMORY) || pVc->GetType(IValConstraint::LOAD_MEMORY)) {
					break;
				}
				pVc = NULL;	
			}
			// tableロードは除外(MDP発生する可能性大だけど救出される)
			if (pEx->RaiseException(IException::EXP_MDP) && pVc != NULL &&
				mne != "switch" && mne != "callt" && mne != "hvcall" && mne != "syscall" && mne != "pref") { // "switch"命令はとりあえず除外する, pref=例外非発生
				#if !defined(NDEBUG)
				std::cout << "@MDP ---> " << pIns->GetCode() << std::endl;
				#endif
				pVc->SetType(IValConstraint::RAISE_MERROR);
				
			}
		} 
	}
}


// ■ Jarl制御（E3V5 Internal function)
// -------------------------------------------------------------
// Jarl命令において、ジャンプ先を示すオペランドにラベルを付加しておく
// PC相対ジャンプ、絶対アドレスジャンプの判断はオペランド属性を判定し
// リンク時にアドレスが解決され、オペランドは即値にリプレイスされる。
void CBlockManager::LabelingJarl(CCodeBlock* pCb, std::string contextStr) {
	// JARL補正
	for (UI32 i = 0; i < pCb->GetInstructionNum(); i++) {
		IInstruction* pIns = pCb->at(i);
		if (pIns->GetMne() == std::string("jarl") && pIns->GetValid() == false && (pIns->GetReverse() == nullptr)) {
			pIns->Fix();
			UI32 lp = pIns->opr(1)->Idx();
			std::stringstream ss;
			ss << (contextStr + "function_") << lp;			
			// Limitation JARL32 can not jump cross section
			if (pIns->GetId() == INS_ID_JARLSD22) {
				pIns->opr(0)->SetLabel(ss.str().data());
				pIns->opr(0)->RemoveConstraint();				
				pIns->SetTaken(true);
				pIns->DelReverse();
			}else if (pIns->opr(0)->Attr(IOperand::OPR_ATTR_GR)) {
				pIns->opr(0)->SetLabel(ss.str().data());
				pIns->SetTaken(true);
				pIns->DelReverse();
			}else
			{
				FROG_ASSERT(false);
			}
		}
	}
}


/**
 * @brief  指定ブロックの指定SWITCH命令にテーブルを準備する。
 * @param  pCb  
 * @param  i    
 * @return bool 
 */
bool CBlockManager::MakeSwitchTable(CCodeBlock* pCb, UI32 i) {

	UI32 num = pCb->GetInstructionNum();
	if (num <= i) {
		return false;
	}
	
	IInstruction* pIns = pCb->at(i);
	UI32 next = i + 1;
	
	// filter MNE is Switch
	if (pIns->GetMne() != std::string("switch")) {
		return false;
	}
	bool inLoop = pIns->InLoop();
	UI32 remain = num - next;
	// Limited target range in loop sequence #68067
	if(inLoop == true){
		for(UI32 j = next; j < num - 1; j++)
			if(pCb->at(j)->GetId() == INS_ID_LOOP){
				remain = j - next;
				// Case switch is last instruction uin loop sequence
				if(remain == 0){
					remain = num - next;
					inLoop = false; // Can not find target in loop -> jump out.
				}
				break;
			}
	}
	
	// テーブル数の定義
	const UI32 tableMin = 1;		// 最小テーブルエントリ(1〜)
	const UI32 tableMax = 5;		// 最大テーブルエントリ 
		
	FROG_ASSERT((tableMin != 0) && (tableMin <= tableMax));
	
	// テーブル数を決定（tableMin - tableMaxのランダム）	
	UI32 tableEntry = g_rnd.GetRange((UI32)tableMin, (UI32)tableMax);
	
	// 飛び先アドレスを計算する（テーブルデータに使用）
	std::vector< std::pair<UI32,std::string> > dstInsOffset;
	UI32 skipIns = 0;
	for (UI32 j = 0; j < remain; j++) {
		IInstruction* nextJ = pCb->at(next + j);
		UI32 len = nextJ->GetLen();			// 補正前状態でのswitchの次の命令の長さ
		std::string mne = nextJ->GetMne();
		UI32 pId = nextJ->GetId();
		if ((mne == ".hword") || (mne == ".word") || (mne == "switch")) {
			nextJ->SetSequence();
			skipIns += len;
			continue;
		}
		// SWITCHテーブルの飛び先にブランチがあるとき全てNOT-TAKEN制御とする
		// テーブルの飛び先列が分断されるのを防ぐ
		if( inLoop == false && (nextJ->InSequence() || nextJ->InLoop() || nextJ->GetComment() == "Overwrite precision error!")){
			nextJ->SetSequence();
			if(nextJ->InLoop() && (pId == INS_ID_JARL || pId == INS_ID_JMP))
				skipIns += 6; // Len of MOVE32 (label, jmp) it will be add in ChainBCondSequence
			skipIns += len;
			continue;
		}

		if (mne == "loop") {
			if(nextJ->InSequence()){
				nextJ->SetSequence();
				skipIns += len;
				continue;
			}
		}

		nextJ->SetSequence();				// 一連の命令列にする

		dstInsOffset.push_back (std::pair<UI32,std::string>(skipIns,mne));
		if (tableEntry <= dstInsOffset.size()) {
			break; // エントリ分飛び先が確保できた。
		}

		if( (inLoop == true && nextJ->InLoop() == true)  && (pId == INS_ID_JARL || pId == INS_ID_JMP))
			skipIns += 6; // Len of MOVE32 (label, jmp) it will be add in ChainBCondSequence

		skipIns += len;
	}

	// SWITCH以後の命令（ジャンプ先の候補）がないときNOPを追加しておく
	if (dstInsOffset.size() == 0) {
		IInstruction * nop = NOP();
		nop->SetSequence();
		nop->SetInLoop(pIns->InLoop());
		pCb->AddOpeCode (nop, next); // switch直後にnop挿入
		dstInsOffset.push_back(std::pair<UI32,std::string>(0,"nop"));
	}
	
	// 飛び先が残りの命令に満たない場合（飛び先重複）
	for (UI32 j = dstInsOffset.size(); j < tableEntry; j++) {
		// Destination shuffle
		std::random_shuffle(dstInsOffset.begin(), dstInsOffset.end(), g_rnd);
		dstInsOffset.push_back (dstInsOffset.back());
	}
	
	// Destination shuffle
	std::random_shuffle(dstInsOffset.begin(), dstInsOffset.end(), g_rnd);
	
	// GRの値制約（ロードアドレス制約ではない）！
	// オペランドの汎用レジスタの値がテーブルエントリ数内にあること
	pIns->opr(0)->SetConstraint(new IValConstraint(tableMin-1, tableEntry-1, 0, 2, 0));
	pIns->Fix();
	
	for (UI32 j = 0; j < tableEntry; j++) {
		// テーブル埋め込み
		IInstruction* pHword = new CIns_456__short(new COprImm(tableEntry + ((dstInsOffset.at(j).first)/2) ));
		pHword->SetSequence(true);
		std::stringstream ss;
		ss << " [" << std::setw(2) << std::setfill('0') << std::dec << j << "] Jump to  ";
		std::string comment = ss.str();
		comment += dstInsOffset.at(j).second;
		pHword->AppendComment(comment.data());
		pCb->AddOpeCode (pHword, ++i);
	}
	return true;
}

// ■ Switch制御（E3V5 Internal function)
// -------------------------------------------------------------
// Switch命令でロードされるテーブルを準備する
// ・処理順序から遡って処理しなければならない、飛び先にswitchがあると意図外のアドレスなる。
// ・1switchを処理する毎に命令(テーブルデータ）が挿入されるため全体の命令数が増加する。 
// 
bool CBlockManager::SwitchPresetTable(CCodeBlock* pCb) {

	std::set<IInstruction*> ipSet; // 処理済みswitchを記憶する
	
	for (UI32 i = pCb->GetInstructionNum(); i > 0 ; i--) {
		
		UI32 f = i - 1;
		
		// filter MNE is Switch
		if (pCb->at(f)->GetMne() != std::string("switch")) {
			continue; // 対象外
		}

		if (ipSet.find(pCb->at(f)) != ipSet.end()) {
			continue; // 処理済み
		}

		if (MakeSwitchTable(pCb, f) != true) {
			return false;
		}
		ipSet.insert(pCb->at(f));
		// 命令は増加するが＋側に追加していくためGetInstructionNumしなおす必要はない。
	}
	
	return true;
}


// ■ ブロックチェーン
// -------------------------------------------------------------
// コードブロック間の処理を繋ぐ命令を追加する。
// いくつかのジャンプシーケンスをランダムで選択し、Taken/NotTakenをケアしないブランチ命令も挿入。
CCodeBlock* CBlockManager::ChainBlock(CCodeBlock* src, CCodeBlock* dst) {

	IInstruction* p = m_nrmSet.CreateIns(INS_ID_JMPD32)->Fix();
	if (p->opr(0)->Idx() == 0)
		p->opr(0)->Replace(g_rnd.GetRange(1, 31));
	p->opr(0)->SetConstraint(new ILoadConstraint(0x00000000, 0x07FFFFFF, 0x01, 2, (1<<IValConstraint::FETCH) ));
	p->SetJumpTargetLabel(dst->GetLabel().c_str());
	p->opr(0)->SetLabel(dst->GetLabel().c_str());
	p->Note("-> Jump Next Block");
	p->SetChain();
	NewINS( src, p );
	p->DelReverse();

	// Dead code insert
	InsertDeadCode(src);
	return dst;
}


CCodeBlock* CBlockManager::MixBlock(CCodeBlock* src, CCodeBlock* dst) {
	
	/* src CodeBlockコンテナは削除され、中身のInsはdstに移る */
	dst->Interlace(src);
	
	return dst;
}

void CBlockManager::ParseUserCode(std::vector<std::string> &vUcBody, CCodeBlock* pCB) {
	static const char* cond[] = {
					"V",	"C/L",	"Z",	"NH",	"S/N",	"T",	"LT",	"LE",
					"NV",	"NC/NL","NZ",	"H",	"NS/P",	"SA",	"GE",	"GT"
				};
	static const char* fcond[] = {
					"F",	"UN",	"EQ",	"UEQ",	"OLT",	"ULT",	"OLE",	"ULE",
					"SF",	"NGLE",	"SEQ",	"NGL",	"LT",	"NGE",	"LE",	"NGT"
				};
	auto ParseBCondIns = [&] (std::string &mne) {
		UI16 cond = 0x0;
		if (mne == "bge") cond = 0x1110;
		else if (mne.find("bgt") == 0) cond = 0x1111;
		else if (mne.find("ble") == 0) cond = 0x0111;
		else if (mne.find("blt") == 0) cond = 0x0110;
		else if (mne.find("bh") == 0) cond = 0x1011;
		else if (mne.find("bl") == 0) cond = 0x0001;
		else if (mne.find("bnh") == 0) cond = 0x0011;
		else if (mne.find("bnl") == 0) cond = 0x1001;
		else if (mne.find("be") == 0) cond = 0x0010;
		else if (mne.find("bne") == 0) cond = 0x1010;
		else if (mne.find("bc") == 0) cond = 0x0001;
		else if (mne.find("bf") == 0) cond = 0x1010;
		else if (mne.find("bn") == 0) cond = 0x0100;
		else if (mne.find("bnc") == 0)cond = 0x1001;
		else if (mne.find("bnv") == 0)cond = 0x1000;
		else if (mne.find("bnz") == 0)cond = 0x1010;
		else if (mne.find("bp") == 0) cond = 0x1100;
		else if (mne.find("br") == 0) cond = 0x0101;
		else if (mne.find("bsa") == 0) cond = 0x1101;
		else if (mne.find("bt") == 0) cond = 0x0010;
		else if (mne.find("bv") == 0) cond = 0x0000;
		else if (mne.find("bz") == 0) cond = 0x0010;
		else	cond = 0x0;
		 
		return cond;
	};

	auto Split = [] (const std::string &src, const std::string &key) {
		std::vector <std::string> v;
		std::string str = src;
		std::string::size_type index = 0;
		while(index < str.length()){
			std::string::size_type oldindex = index;
			index = str.find( key, index);
			if(index != std::string::npos){
				std::string item = str.substr(oldindex, index - oldindex);
				v.push_back(CToolFnc::Trim(item));
			}else{
				std::string item = str.substr(oldindex);
				v.push_back(CToolFnc::Trim(item));
				break;
			}
			index += key.length();
		}
		return v;
    };

	auto ConvertCondition = [] (std::string cond, const char** condList) -> std::string {
		std::string strCond;
		UI32 i;
		// Check whether 1st operand is condition name of condition index
		for(i = 0; i < 16; i++) {
			if(condList[i] == cond) {
				strCond = cond;
				break;
			}
		}
		// Convert from condition index to name
		if(i == 16){
			UI32 cc = CToolFnc::AtoI(cond.c_str());
			strCond = condList[cc];
		}
		return strCond;
	};

	std::vector <std::string>::iterator itrUcBody;
	std::string::size_type				nMatchPos;
	std::string							code, label;
	IInstruction*						pUserIns;
	for(itrUcBody = vUcBody.begin(); itrUcBody < vUcBody.end(); itrUcBody++) {
		std::string &code = *itrUcBody;

		// Check whether instruction is a label
		if((nMatchPos = code.rfind(":")) != std::string::npos) {
			label = CToolFnc::Trim(code.substr(0, nMatchPos));
			continue;
		}
		
		// Find the first space or tab character
		std::string::size_type pos;
		if((pos = code.find(" ")) == std::string::npos){
			if((pos = code.find("\t")) == std::string::npos)
				pos = code.size();
		} else {
			std::string::size_type tab_pos = code.find("\t");
			if(tab_pos != std::string::npos && tab_pos < pos)
				pos = tab_pos;
		}
		std::string mne = CToolFnc::Trim(code.substr(0, pos));
		std::string oprs = CToolFnc::Trim(code.substr(pos));
		UI32 ret;

		// Create UserInstruction, then insert to code block.
		if(mne == "movl"){
			std::string::size_type comma = oprs.find(",");
			std::string label = CToolFnc::Trim(oprs.substr(0, comma));
			UI32 reg = CToolFnc::AtoI(oprs.substr(oprs.find("r", comma) + 1).c_str());
			pUserIns = (IInstruction*) new UserMovlIns(label, reg);
		} else if(mne.find("jarl22") == 0) {
			std::string::size_type comma = oprs.find(",");
			std::string label = CToolFnc::Trim(oprs.substr(0, comma));
			UI32 reg = CToolFnc::AtoI(oprs.substr(oprs.find("r", comma) + 1).c_str());
			pUserIns = (IInstruction*) new UserJarl22Ins(label, reg);
		} else if (mne.find("jarl32") == 0) {
			std::string::size_type comma = oprs.find(",");
			std::string label = CToolFnc::Trim(oprs.substr(0, comma));
			UI32 reg = CToolFnc::AtoI(oprs.substr(oprs.find("r", comma) + 1).c_str());
			pUserIns = (IInstruction*) new UserJarl32Ins(label, reg);
		} else if (mne.find("jr22") == 0) {
			pUserIns = (IInstruction*) new UserJr22Ins(oprs);
		} else if (mne.find("jr32") == 0) {
			pUserIns = (IInstruction*) new UserJr32Ins(oprs);
		} else if((ret = ParseBCondIns(mne)) != 0x0){
			UI16 cond = ret;
			std::string::size_type pos17;
			if((pos17 = mne.find("17")) == std::string::npos) { //Disp9
				pUserIns = (IInstruction*) new UserBCond9Ins(mne, oprs, cond);
			} else { // Disp17
				pUserIns = (IInstruction*) new UserBCond17Ins(mne.substr(0, pos17), oprs, cond);
			}
		} else {
			if(mne.find("ldsr") == 0 || mne.find("ldtc.sr") == 0 || mne.find("ldvc.sr") == 0) {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = vOpr[0] + ", sr" + vOpr[1] + ", sel" + (vOpr.size() == 3 ? vOpr[2] : "0");
			} else
			if(mne.find("stsr") == 0 || mne.find("sttc.sr") == 0 || mne.find("stvc.sr") == 0) {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = "sr" + vOpr[0] + "," + vOpr[1] + ", sel" + (vOpr.size() == 3 ? vOpr[2] : "0");
			} else
			if(mne == "pushsp" || mne == "popsp" || mne == "dbpush") { // Replace separator among 2 registers "," (GNU format) to "-" (FROG Asm format)
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = vOpr[0] + "-" + vOpr[1];
			} else
			if(mne == "adf" || mne == "cmov" || mne == "sasf" || mne == "sbf" || mne == "setf") {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
			
				oprs = ConvertCondition(vOpr[0], &cond[0]) + ", " + vOpr[1];
				if(vOpr.size() == 4)
					oprs += ", " + vOpr[2] + ", " + vOpr[3];
			} else 
			if (mne.find("cmpf") == 0) {
				const std::vector<std::string> &vOpr = Split(oprs, ",");
				oprs = ConvertCondition(vOpr[0], &fcond[0]) + ", " + vOpr[1] + ", " + vOpr[2] + ", " + vOpr[3];
			}

			pUserIns = (IInstruction*) new UserInstruction(mne + " " + oprs);
			if(label.empty() == false){
				pUserIns->SetLabel(label);
				label = "";
			}
		}
		
		pCB->AddOpeCode(pUserIns);
	}
}

void CBlockManager::GetUserHanlderBody(const std::string &strHandler, CCodeBlock *pCB) {
	std::vector <std::string>			vUcBody;
	std::vector <std::string>::iterator itrUcBody;
	bool								bFound = false;
	const std::string key(".section");

	g_usf->GetUserCodeBody("uc_handler", vUcBody);
	itrUcBody = vUcBody.begin();
	while(itrUcBody < vUcBody.end()) {
		std::string &code = *itrUcBody;
		std::string::size_type pos;

		if((pos = code.find(key)) != std::string::npos){
			std::string::size_type next_dot = code.find(".", pos + key.size());
			pos = code.find(",");
			code = CToolFnc::Trim(code.substr(next_dot + 1, pos - (next_dot + 1)));
			if(code == strHandler)
				bFound = true;
			else
				bFound = false;
			itrUcBody = vUcBody.erase(itrUcBody);
			continue;
		}
		
		if(!bFound)
			itrUcBody = vUcBody.erase(itrUcBody);
		else
			itrUcBody++;
	}
	ParseUserCode(vUcBody, pCB); // [TN]TODO: Infinite loop when no code in user handler
}

void CBlockManager::GetUserHandler(const std::string &strContext, std::bitset<BSV_VECTOR_NUM> *pBs) {
	std::vector<std::string> vHandler = g_usf->GetUserHandler(strContext);
	const char* handlerArr[] = {"reset", "syserr", "hvtrap", "fetrap", "trap0", "trap1", "rie", "fpe", "ucpop", "mp",
							"pie", "debug", "mae", "dummy", "fenmi", "feint", "eiint", "eiint000", "eiint001", "eiint002",
							"eiint003", "eiint004", "eiint005", "eiint006", "eiint007", "eiint008", "eiint009",
							"eiint010", "eiint011", "eiint012", "eiint013", "eiint014", "eiint015", NULL
	};

	std::vector<std::string>::iterator itr;
	for(itr = vHandler.begin(); itr < vHandler.end(); itr++){
		std::string &strHandler = *itr;
		UI32 idx = 0;
		while(handlerArr[idx] != NULL){
			if(strcmp(handlerArr[idx], strHandler.c_str()) == 0)
				pBs->set(idx);
			idx++;
		}
	}
}

void CBlockManager::PresetFixedMPU(CCodeBlock *pCB) {
	auto SetFixedMPU = [] (IInstruction *pIns) {
		if (pIns->Behavior(IInstruction::LOAD_MEMORY) || pIns->Behavior(IInstruction::STORE_MEMORY)) {
			IValConstraint* pVc = NULL;
			pVc = NULL;
			for (UI32 N=0; N < pIns->GetOpNum(); N++) {
				IOperand* popr = pIns->opr(N);
				if (popr == NULL) {
					break;
				}
				if ((pVc = popr->GetConstraint()) == NULL) {
					continue;
				}
				if (pVc->GetType(IValConstraint::STORE_MEMORY) || pVc->GetType(IValConstraint::LOAD_MEMORY)) {
					pVc->SetType(IValConstraint::FIXED_MPU);
				}
			}
		}
	};

	for (UI32 nIdx = 0; nIdx < pCB->GetInstructionNum(); nIdx++) {
		IInstruction *pIns = pCB->at(nIdx);
		UI32 insid = pIns->GetId();
		if(insid == INS_CID_MPU_UPDATE)
			break;
		if(pIns->IsComplex()) {
			ComplexInstruction* pCi = static_cast<ComplexInstruction*>(pIns);
			IInstruction *p = NULL;
			for(UI32 n = 0; n < pCi->size(); n++) {
				p = (*pCi)[n];
				SetFixedMPU(p);
			}
		} else {
			SetFixedMPU(pIns);
		}
	}
}

/**
* @brief  get register include target PC in vector handler, JMP return in Funtion, loop counter when inloop sequence
* @return setof register index
*/
UI32 CBlockManager::GetConstraintRegister(CCodeBlock* pCB, IInstruction* pIns){
	std::string label = pCB->GetLabel();
	// Get register address in handler
	UI32 regConstraint = 0;
	// Get Loop counter
	if(pIns->InLoop() == true){
		UI32 start_loop = pCB->GetIndex(pIns);
		while (pCB->at(start_loop)->GetLabel().find("_Lp_") == std::string::npos)
			start_loop--;
		//! Collect all destiny register in loop sequence
		for(UI32 i = start_loop; i < pCB->GetInstructionNum(); i++){
			IInstruction* ptempIns = pCB->at(i);
			if(ptempIns->GetId() == INS_ID_LOOP){
				regConstraint = regConstraint | (1 << ptempIns->opr(0)->Idx());
				break;
				} else if (ptempIns == pIns)
					regConstraint |= ptempIns->GetOprDst();
				else
					regConstraint |= (ptempIns->GetOprDst() | ptempIns->GetConstraintBit());			
			}
		}
	// Get JMP return in Funtion
	if(label.find("function") != std::string::npos){
		UI32 FuncReg = CToolFnc::AtoI(label.substr(label.find_last_of("_")+1, label.size()).c_str());
		regConstraint = regConstraint | (1 << FuncReg);
	}
	// G4MH spec constraint for operand of LOAD inc, dec
	if(pIns->GetId() >= INS_ID_LD_B_INC && pIns->GetId() <= INS_ID_LD_W_DEC)
		regConstraint = regConstraint | (1 << pIns->opr(1)->Idx());
	// Forwarding/C2B1
	if(pIns->GetForwardIns() != nullptr && (pIns->GetForwardIns()->GetMne().find("sst") || pIns->GetForwardIns()->GetMne().find("sld")))
		regConstraint |= (1 << 30);
	return regConstraint;
}

/**
* @brief  generate random nomarl instruction
* @return instruction
*/
IInstruction* CBlockManager::ReplaceInsbyOther(CCodeBlock* pCB, IInstruction* pIns, UI32 insLen)	{
	IInstruction* p = NOP();	
	p = m_nrmSet.CreateIns()->Fix();
	// Do not overwrite target PC in vector handler, JMP return in Funtion, loop counter when inloop sequence
	UI32 regConstraint = GetConstraintRegister(pCB, pIns);
	// Totally, E3V5 spec has 40 access memory instructions, page 106
	UI32 try_time = 40;
	// Fill up len for couple of RIE partner instruction
	if (pIns->GetRiePartner() != nullptr) {
		insLen = insLen + 2;
		pIns->SetRiePartner(nullptr);
	}
	//! Get Load/Store attribute
	auto LoadStoreType = [] (IInstruction* pIns){
		return (pIns->Behavior(IInstruction::LOAD_MEMORY) | pIns->Behavior(IInstruction::STORE_MEMORY));
	};

	// These instruction need to gen at before simulation
	auto InsHasSpecialConstraint = [] (IInstruction* pIns, IInstruction* pNewIns) {
		UI32 pNewInsId = pNewIns->GetId();
		if (pNewIns->Behavior(IInstruction::JMP) || pNewIns->Behavior(IInstruction::TRAP_EXCEPTION) || pNewIns->GetMne().find("ret") != std::string::npos 
		|| pNewIns->GetMne().find("rsqrtf") != std::string::npos || pNewIns->GetMne().find("recipf") != std::string::npos || pNewInsId >= NUM_OF_INS  
		|| pNewInsId == INS_ID_LOOP || pNewInsId == INS_ID_SWITCH || pNewInsId == INS_ID_LDSR || pNewInsId == INS_ID_STTC_SR || pNewInsId == INS_ID_STVC_SR
		|| (pNewInsId >= INS_ID_RESBANK && pNewInsId <= INS_ID_LDM_MP))
			return true;
		if(pIns->InLoop() && (pNewIns->GetId() >= INS_ID_LD_B_INC && pNewIns->GetId() <= INS_ID_ST_W_DEC))
			return true;
		
		return false;
	};

	//Try to replace operand when confliction occur
	auto ReplaceOperand = [] (IInstruction* pIns, IInstruction* pNewIns, UI32 notUseIdx)	{

		if(pNewIns->GetOpNum() == 0)
			return true;

		UI32 pInsId = pNewIns->GetId();

		if(pInsId == INS_ID_DISPOSE || pInsId == INS_ID_DISPOSE_R3 || (pInsId >= INS_ID_POPSP && pInsId <= INS_ID_PUSHSP)) {
			if((((notUseIdx >> 3) & 0x1) == 1) || pIns-> InLoop())
				return false;

			if((pInsId >= INST_ID_PREPARE_SP && pInsId <= INST_ID_PREPARE_I32) && (((notUseIdx >> 30) & 0x1) == 1))
				return false;
		}

		if(pInsId != INS_ID_SNOOZE && (pInsId >= INS_ID_SLD_B && pInsId <= INS_ID_SST_W))
			if(((notUseIdx >> 30) & 0x1) == 1)
				return false;

		// This function was used to replace operand index in List
		auto ReplaceRegisterInList = [] (IOperand *opr, UI32 notUseIdx, UI32 clearbit)	{
			
			// Adjust list12
			std::vector<UI32> vFreeBit = {};
			UI32 updatebit = 0;
			for(UI32 i = 20; i < 32; i++)
				if ( (((notUseIdx >> i) & 0x1) == 0) && (((clearbit >> i) & 0x1) == 0))
					vFreeBit.push_back(i);

			if(vFreeBit.size() != 0)	{
				std::random_shuffle(vFreeBit.begin(), vFreeBit.end(), g_rnd);
				updatebit = (vFreeBit.back() == 30 ) ? 0 : ((vFreeBit.back() > 27) ? (24 + 31 - vFreeBit.back()) : (20 + 27 - vFreeBit.back()));
			}
			UI32 val = (((UI32) * opr) | (1 << updatebit));
			for(UI32 i = 0; i < 32; i++)
				if(((clearbit >> i) & 0x1) == 1){
					UI32 ClearPos = (i == 30 ) ? 0 : ((i > 27) ? (24 + 31 - i) : (20 + 27 - i));
					val = val & (~(1 << ClearPos)) ;
				}
				
			val = (val & 0x1) | val >> 20 ;
			opr->Replace(val);
		};

		// Lamda function to get bit that need to be clear
		// notUse include only pIns constraint 
		// notUse MUST to update with new instruction 
		auto GetClearBit = [] (IInstruction* p, IInstruction* pNew, UI32 notUse){
			//notUse = 1, 3, 4, 12;
			//pIns = sld.b 0x7c[ep],r30 -> Error
			if(p->InLoop() == true) {
				notUse |= (pNew->GetOprDst() & pNew->GetConstraintBit());
				return ((pNew->GetOprDst() | pNew->GetConstraintBit()) & (notUse));
				}
			return pNew->GetOprDst() & notUse;
		};

		UI32 needToClearBit = GetClearBit(pIns, pNewIns, notUseIdx);
		// Do not has confliction
		if(needToClearBit == 0)
			return true;
		else	{
			// Collect free register and put in vector
			std::vector <UI32> vFreeBit;
			for(UI32 i = 1; i < 32; i++)
				if(((notUseIdx >> i) & 0x1) == 0)
					vFreeBit.push_back(i);
			if (vFreeBit.size() != 0)	{
				std::random_shuffle(vFreeBit.begin(), vFreeBit.end(), g_rnd);
				for(UI32 i = 0; i < pNewIns->GetOpNum(); i++){
					IOperand *op = pNewIns->opr(i);
					// Replace register in list12 of dispose instruction
					if(pNewIns->GetMne() =="dispose" && i == 1)
						ReplaceRegisterInList(op, notUseIdx, needToClearBit);
					std::vector <UI32> vFreeBitCopy = vFreeBit;
					// LD.DW has pair operand
					UI32 dstOperd = ((op->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << op->Idx());
					// Find exactly error case
					while (needToClearBit & dstOperd)	{
						if (vFreeBitCopy.size() == 0)
							return false;
						op->Replace(vFreeBitCopy.back());
						vFreeBitCopy.pop_back();						
						needToClearBit = GetClearBit(pIns, pNewIns, notUseIdx);
						dstOperd = ((op->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << op->Idx());
					}
				}
			}
		}
		needToClearBit = GetClearBit(pIns, pNewIns, notUseIdx);
		return (needToClearBit == 0);
	};

	// Fix issue replace difference PC in common block
	auto FillLen = [] (CCodeBlock* pCb, UI32 pos, UI32 insLen) {
		if(pCb->GetHandlerAddress() == ADR_COMMON_CALLT){
			UI32 totalNop = insLen/NOP()->GetLen() - 1;
			for(UI32 i = 0; i < totalNop; i++){
				IInstruction* pJns = NOP(); // Find other instruction instead of NOP
				pJns->AppendComment("Fill the len");
				pCb->Insert(pJns, pCb->at(pos + 1));
			}
		}
		
	};

	// Check issue replace difference PC in common block
	auto CheckLength = [] (CCodeBlock* pCb, IInstruction* newpIns, UI32 insLen)	{
		
		UI32 newLen = newpIns->GetLen();
		// Vector block have to fix len to avoid overlap 
		if ((pCb->GetHandlerAddress() > ADR_VECTOR_RESET && pCb->GetHandlerAddress() < ADR_VECTOR_NUM) && newLen > insLen)
			return false;
		
		// 1. pIns len = 4
		// 2. Replace by ld23 with disp in16 -> len = 4
		// 3. Regulate change disp in 23 -> len = 6
		if(pCb->GetHandlerAddress() == ADR_COMMON_CALLT)	{
			UI32 insId = newpIns->GetId();
			if(insId == INS_ID_LD_BSD23 || insId == INS_ID_LD_BUD23 || insId == INS_ID_LD_HSD23 
				|| insId == INS_ID_LD_HUD23 || insId == INS_ID_LD_WSD23) {
				newLen = 6;
				newpIns->opr(0)->ChangeDispTo23Bit();
			}
			if(insId == INS_ID_ST_B_SD23 || insId == INS_ID_ST_H_SD23 || insId == INS_ID_ST_W_SD23){
				newLen = 6;
				newpIns->opr(1)->ChangeDispTo23Bit();
			}
			if(newLen != insLen)
				return false;
		}
		
		return true;
	};

	//! Condition to generate new instruction. This instruction may be inserted in simulation phase.
	while (CheckLength(pCB, p, insLen) == false || (ReplaceOperand(pIns, p, regConstraint) == false) 
		|| ( LoadStoreType(pIns) == true && LoadStoreType(p) == false && try_time > 0) || InsHasSpecialConstraint(pIns, p) )	{
			p = m_nrmSet.CreateIns()->Fix();
			if(LoadStoreType(p) == true)
				try_time--;
			if(try_time == 0){
				FillLen(pCB, pCB->GetIndex(pIns), insLen);
				p = NOP();
				break;
			}
	}
	if(pIns->GetMne() == "dispose" && pIns->GetChain() == true){
		p = m_nrmSet.CreateIns(INS_ID_JMPD32)->Fix();
		p->opr(0)->Replace(pIns->opr(2)->Idx());
		p->SetChain();
	}
	// Change forwarding instruction 
	IInstruction* forwardingIns = pIns->GetForwardIns();
	if(forwardingIns != nullptr && forwardingIns->GetId() == INS_ID_JMPD32){
		p->SetForwardIns(forwardingIns);
		forwardingIns->ClearInsNeed();
		forwardingIns->SetInsNeed(p);
	}

	p->AppendComment("Replace other instruction");
	pIns->MoveInsAttribute(p);
	IInstruction* temp = pCB->Replace(pIns, p);
	delete temp;
	pCB->Update();

	return p;
}

void CBlockManager::GenerateRandomCode(CCodeBlock* pCB, UI32 blocksize, UI32 num, TBlockConfig* pCfg, const std::string &name) {
	CCodeBlock* pCodeBlock;
	UI32 nFixedReg1 = 0, nFixedReg2 = 0;

	//!< lamda function for insert register bank insterrupt into eiint handler codeblock!
	auto InsertRegisterInterrupt = [] (CCodeBlock* pHB)
	{
		if (((pHB->GetHandlerAddress()>>4) >= (ADR_VECTOR_EIINT000 >> 4)) && ((pHB->GetHandlerAddress()>>4) <= (ADR_VECTOR_EIINT015 >> 4))) {
			IInstruction* pIns;
			//Caculating Id of Register bank Interrupt.
			const UI32 UC_ID_BASE = MAX_INS_ID + 1;
			UI32 nIdx = UC_ID_BASE + g_usf->GetUserCodeNum();
			std::map< UI32,IExceptionConfig*>& vExp = g_exp->GetException();
			std::map<UI32, IExceptionConfig*>::iterator itrExp;
			for(itrExp = vExp.begin(); itrExp != vExp.end(); itrExp++) {
				IExceptionConfig* pExpConfig = itrExp->second;
				if((pExpConfig->m_bIsInterrupt) && (pExpConfig->m_name == "RBINT")) {
					pIns = (IInstruction*) new ComplexInstruction (nIdx, "User_Instruction");
					//!< Insert register bank interrupt.
					UI32 nPosIns = g_rnd.GetRange((UI32)0, (UI32)(pHB->GetInstructionNum()-1));
					pHB->Insert(pIns,pHB->at(nPosIns));
					break;
				}
				nIdx++;
			}		
		}
	};
	

	switch (g_cfg->m_nBlockMix) {
	case 0:		// free
		pCodeBlock = GenerateGrBlock(0, blocksize, num, 0, pCfg->pInsSet);
		break;
		
	case 1:		// focus 1 reg
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCodeBlock = GenerateGrBlock(0, blocksize, num, nFixedReg1, pCfg->pInsSet);
		break;

	case 2:		// mix 2 reg interlaced
		nFixedReg1 = g_rnd.GetRange(1U, 31U);
		pCodeBlock = GenerateGrBlock(0, blocksize/2, num/2, nFixedReg1, pCfg->pInsSet);
		nFixedReg2 = g_rnd.GetRange(1U, 31U);
		pCodeBlock = this->MixBlock (GenerateGrBlock(0, blocksize/2, num/2, nFixedReg2, pCfg->pInsSet), pCodeBlock);
		break;
		
	default:	// free generation
		pCodeBlock = GenerateGrBlock(pCfg->N, blocksize, pCfg->InsNum, 0, pCfg->pInsSet);
		break;
	}
	for(UI32 i = 0; i < pCodeBlock->GetInstructionNum(); i++) {
		IInstruction *pIns = pCodeBlock->at(i);
		const std::string &mne = pIns->GetMne();
		
		if(pIns->IsComplex()) {
			pCodeBlock->Erase(pIns);
			pCB->AddOpeCode(pIns);
			continue;
		}
		
		if (mne == "ldsr" || mne == "ldtc.sr" || mne == "ldvc.sr" ) {
			UI32 const RETRY_TIMES = 10; // Give up to generate system reg.
			UI32 const NO_MASK = 0xffffffff;
			UI32 nCount = 0;
			UI32 sr = (UI32)*(pIns->opr(1));			
			
			// Do not update handler resource SRs
			if (name == "callt" && ((sr == 32 * 0 + 16) || (sr == 32 * 0 + 17))) { // ctpc, ctpsw
				continue;
			}

			// Mismtach PC when using JARL to check PC_permission
			if(name == "callt" && ((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12 )))/*MPU SRs*/ 
				continue;

			while((g_srs->GetWriteMask((sr & 0x1f), (sr >> 5)) != NO_MASK) && nCount < RETRY_TIMES){
				// Generate other system register.
				sr = (UI32)*(pIns->opr(1)->ReFix());
				nCount++;
			}
			// Masked register update
			if (nCount == RETRY_TIMES) {
				continue;
			}
		}
		
		if(pIns->GetMne().find("ret") != std::string::npos)	{		
			UI32 pInsId = pIns->GetId();
			UI32 HanlderLevel = pCB->GetHandlerLevel();
			
			if(HanlderLevel == CVectorBlock::EXP_LEVEL_EI)
				// Does not support XXRET same type in re-execution type handler
				if((pInsId == INS_ID_EIRET && pCB->GetHandlerType() == 1) || pInsId != INS_ID_EIRET) 			
					continue;

			if(HanlderLevel == CVectorBlock::EXP_LEVEL_FE)
				// Does not support XXRET same type in re-execution type handler
				if((pInsId == INS_ID_FERET && pCB->GetHandlerType() == 1) || pInsId != INS_ID_FERET)
					continue;

			if(HanlderLevel == CVectorBlock::EXP_LEVEL_DB)
				if(pInsId == INS_ID_EIRET || pInsId == INS_ID_FERET || pCB->GetHandlerType() == 1)
					continue;
			if(HanlderLevel == CVectorBlock::EXP_LEVEL_NONE)
				continue;
		}

		
		//[TODO:NN] Improve by check correct position for CTRET
		if((mne.find("rsqrtf") != std::string::npos || mne.find("recipf") != std::string::npos) && (name == "callt" || name == "syscall")){			
			continue;
		}

		// Do not recover EIPC
		if((mne == "resbank" || mne == "ldm.gsr" )&& name == "callt")
			continue;

		// Do not generate pure callt -> overwrite XXRET
		if(mne == "callt" && name == "callt")
			continue;

		// CALLT->MIP->CALLT
	//	if(g_exp.get()->GetWeight(11) != 0 && name.find("mp") != std::string::npos && (mne == "callt" || mne == "syscall"))
		//	continue;
		
		pCodeBlock->Erase(pIns);
		pCB->AddOpeCode(pIns);
		}
	if(name != "callt"){
		IInstruction* JmpToNext =  m_nrmSet.CreateIns(INS_ID_JMPD32)->Fix();
		JmpToNext->opr(0)->SetConstraint(new ILoadConstraint(0x00000000, 0x07FFFFFF, 0x01, 2, (1<<IValConstraint::FETCH) ));
		pCB->AddOpeCode(JmpToNext);
	}
	delete pCodeBlock;

	BreakCalltBlock(pCB);

	InsertRegisterInterrupt(pCB);

	// Expand Sequential Instruction
	ExpandSequentialInstruction(pCB);
	
	// Support bias register to increase register dependance
	IncRegisterDependance(pCB, nFixedReg1, nFixedReg2);

	// Add constraint attribute to generate fixed MPU memories
	//PresetFixedMPU(pCB);

	// 複合命令を展開する
	ExpandComplexInstruction(pCB, pCfg);
	
	// Check whether C2B1 is combined by random generation
	CombineC2B1(pCB);

	// Adjust LDSR for update specified bit
	UpdateAccessSysReg(pCfg, pCB);

	// 伝搬レジスタを切断する(#10198)
	RemoveRegDependance(pCB);

	// R-Type補正（汎用レジスタの重複（Base = {Step/Index}）を除外）
	RTypeVerify(pCB);

	// JARL補正（Jarlの飛び先を設定する=ラベル化）
	LabelingJarl(pCB, GetMContext(pCfg));
	
	MakeLoopSequence(pCB);
	// Switch補正（SWITCHテーブルの挿入）
	// テーブルとSwitchジャンプ先を結びつけるので
	// これ以後、命令を挿入する場合は注意する 
	SwitchPresetTable(pCB);

	pCB->SetStatistics(true);
	
	ChainBcondSequence(pCB);// Labelが付いた後	
	
	PresetException(pCB, g_exp.get());

	return;
}

void CBlockManager::CombineC2B1(CCodeBlock *pCB) {

	for(UI32 n = 0; n < pCB->GetInstructionNum() - 1; n++) {
		IInstruction *pIns = pCB->at(n);
		IInstruction *pNext = pCB->at(n+1);
		if(pIns->InC2B1Ins())
			continue;

		if(CheckC2B1Couple(pIns, pNext)) {
			UI32 i = 0;
			IDirective *pDir = nullptr;

			while((pDir = pNext->GetDirective(i)) != nullptr) {
				CAsyncLabel* pAsyncLabel = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				if(pAsyncLabel != NULL) {

					UI32 j = 0;
					IDirective *pDir1 = nullptr;
					while((pDir1 = pIns->GetDirective(j)) != nullptr) {
						CAsyncLabel* pAs = static_cast<CAsyncLabel*> (pDir1->GetAsyncLabel());
						if(pAs != NULL && !g_sim->CheckSameInterruptType(pAs->m_name, pAsyncLabel->m_name)) { // This request is not existed in pIns
							pIns->SetDirective(pDir);
						}
						j++;
					}

					pNext->RemoveDirective(pDir);
				}
				i++;
			}

			pIns->SetInC2B1Ins(true);
			pNext->SetInC2B1Ins(true);
			pIns->SetForwardIns(pNext);

			pIns->SetSequence();
			//pNext->SetSequence();
			pIns->AppendComment("C2B1 instruction");
			pNext->AppendComment("C2B1 instruction");
			n++;	// Bypass pNext
		}
	}
}

bool CBlockManager::CheckC2B1Couple(IInstruction* pIns1, IInstruction* pIns2){

	UI32 InsC2B1Id = 0;

	// Check valid operand in second instruction 
	auto CheckValidOperand = [](IInstruction *pIns, UI32 OprCons, UI32 OprChange){

		if(pIns->opr(OprCons)->Idx() == 0) // Not use r0
			return false;
			
		if (pIns->opr(OprCons)->Idx() == pIns->opr(OprChange)->Idx())
			return false;
			
		return true;
	};

	// Lamda function check operand follow C2B1 constraint
	auto C2B1Constraint = [](IInstruction* pIns1, UI32 OprIns1, IInstruction* pIns2, UI32 OprIns2){
		UI32 regIns1 = pIns1->opr(OprIns1)->Idx();
		UI32 regIns2 = pIns2->opr(OprIns2)->Idx();
		
		if((pIns1->GetId() == INS_ID_MOVI5 && pIns2->GetId() == INS_ID_ADD_I5) || pIns1->GetId() == INS_ID_BR_SD9)
			return false;
			
		if(pIns1->GetId() == INS_ID_MOVEA && pIns1->opr(1)->Idx() != 0)
			return false;
			
		if (regIns1 != regIns2)
			return false;
			
		return true;
	};
	
	auto CheckC2B1InsId = [&InsC2B1Id](UI32 InsId1, UI32 InsId2){
		std::vector<UI32> ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_SUB, INS_ID_SUBR};
#ifdef _G4MH_
		ALU = {INS_ID_ADD, INS_ID_ADD_I5, INS_ID_SUB, INS_ID_SUBR, INS_ID_TST, INS_ID_AND, INS_ID_OR, INS_ID_XOR, INS_ID_SHL_I5, INS_ID_SHR_I5, INS_ID_SAR_I5};
#endif
		std::vector<UI32> SHIFT = {INS_ID_SHL_I5, INS_ID_SHR_I5};
		std::vector<UI32> SHORT_STORE = {INS_ID_SST_B, INS_ID_SST_H, INS_ID_SST_W};
		std::vector<UI32> STORE_C2B1 = {INS_ID_ST_B_SD16, INS_ID_ST_H_SD16, INS_ID_ST_W_SD16};
	
		if( InsId1 == INS_ID_MOV || InsId1 == INS_ID_MOVI5){
			for(UI32 i = 0; i < ALU.size(); i++)
				if(InsId2 == ALU.at(i))
					InsC2B1Id = INS_CID_MOV_ALU;
					
			for(UI32 i = 0; i < SHORT_STORE.size(); i++)
				if(InsId2 == SHORT_STORE.at(i))
					InsC2B1Id = INS_CID_MOV_SST;		
			}
			
		if( InsId1 == INS_ID_MOV){	
			for(UI32 i = 0; i < SHIFT.size(); i++)
				if(InsId2 == SHIFT.at(i))
					InsC2B1Id = INS_CID_MOVR_SHIFT;
		
		}
		
		if( InsId1 == INS_ID_MOVI5){	
			for(UI32 i = 0; i < STORE_C2B1.size(); i++)
				if(InsId2 == STORE_C2B1.at(i))
					InsC2B1Id = INS_CID_MOV5_ST;
		
		}
		
		if( InsId1 == INS_ID_MOVEA){	
			for(UI32 i = 0; i < SHORT_STORE.size(); i++)
				if(InsId2 == SHORT_STORE.at(i))
					InsC2B1Id = INS_CID_MOVEA_SST;
					
			for(UI32 i = 0; i < STORE_C2B1.size(); i++)
				if(InsId2 == STORE_C2B1.at(i))
					InsC2B1Id = INS_CID_MOVEA_ST;		
		
		}
		
		if(InsId1 == INS_ID_CMP || InsId1 == INS_ID_CMP_SI5) {
			if( InsId2 >= INS_ID_BC_SD9 && InsId2 <= INS_ID_BZ_SD17)
				InsC2B1Id = INS_CID_CMP_BCC;
		}
	
		if(InsId2 >= INS_ID_BC_SD9 && InsId2 <= INS_ID_BZ_SD17) {
			for(UI32 i = 0; i < ALU.size(); i++)
				if(InsId1 == ALU.at(i))
					InsC2B1Id = INS_CID_ALU_BCC;
		}
	};
	
	CheckC2B1InsId(pIns1->GetId(), pIns2->GetId());
	
	if(InsC2B1Id == 0)
		return false;
	
	switch (InsC2B1Id){
	
		case INS_CID_MOV_ALU:
			if(CheckValidOperand(pIns2, 1, 0) == false || C2B1Constraint(pIns1, 1, pIns2, 1) == false)
				return false;
			break;
				
		case INS_CID_MOVR_SHIFT:
			if(C2B1Constraint(pIns1, 1, pIns2, 1) == false)
				return false;
			break;
				
		case INS_CID_MOV_SST:
			if(CheckValidOperand(pIns2, 1, 0) == false || C2B1Constraint(pIns1, 1, pIns2, 0) == false)
				return false;
			break;
				
		case INS_CID_MOV5_ST:
			if(CheckValidOperand(pIns2, 0, 1) == false || C2B1Constraint(pIns1, 1, pIns2, 0) == false)
				return false;
			break;

		case INS_CID_MOVEA_SST:
			if(CheckValidOperand(pIns2, 1, 0) == false || C2B1Constraint(pIns1, 2, pIns2, 0) == false)
				return false;
			break;
		
		
		case INS_CID_MOVEA_ST:
			if(CheckValidOperand(pIns2, 0, 1) == false || C2B1Constraint(pIns1, 2, pIns2, 0) == false)
				return false;
			break;
		
		
		case INS_CID_CMP_BCC:
		case INS_CID_ALU_BCC:
			return true;
		
		default:
			return false;
	}
	return true;

}

void CBlockManager::AddDeadCode(CCodeBlock *pCB) {
    UI32 followInsNum = 2;
    while (followInsNum > 0) {
        IInstruction* pIns = m_nrmSet.CreateIns();
        if (pIns->IsComplex() || pIns->GetId() > INS_ID_RESBANK) {
            delete pIns;
        } else {
            pIns->AppendComment("Dead Code");
            pCB->AddOpeCode(pIns);
            followInsNum--;
        }
    }
}

UI32 CBlockManager::GetMaxChannelInterrupt (std::map<UI32, IExceptionConfig*> mExp){
	std::map<UI32, IExceptionConfig*>::iterator itrExp;
	UI32 max_channel = 0;
	/*find max channel in interrupt type: EITBL and RBINT*/
	for (itrExp = mExp.begin(); itrExp != mExp.end(); itrExp++) {
		IExceptionConfig* pExpConfig = itrExp->second;
		if ((pExpConfig->m_name == "EITBL" || pExpConfig->m_name == "RBINT") && (pExpConfig->m_weight > 0)) {
			UI32 uchannel = pExpConfig->m_uchannel + 1;
			max_channel = uchannel > max_channel ? uchannel : max_channel;
		}
	}
	
	return max_channel;
}

void CBlockManager::InitMPURegister(CCodeBlock* pCB, TBlockConfig* pCfg) {
    UI32 reg = g_rnd.GetRange(7, 15);

    if (pCfg->m_bGM) {
        m_MmList.Fix(pCfg->m_GMID);  // Guest management
        m_MmList.Fix(HOST_ENTRY); // Host management
        UI32 hbe = m_MmList.GetHBE();
        m_MmList.OutMpuSetting(&m_mp_table, pCfg->m_GMID, 0, hbe);      // Guest management
        m_MmList.OutMpuSetting(&m_mp_table, HOST_ENTRY, hbe, g_hwInfo.m_mpnum);        // Host management

        //m_MmList.MpuDump(&m_mp_table);
        NewINS(pCB, MOV32((hbe << 8), 8));
        NewINS(pCB, LDSR(8, 26, 9));         //GMMPCFG
        MpuConfig(pCB, reg, pCfg);

    } else {
        // Convention mode
        m_MmList.Fix(CONVENTION_ENTRY);
        m_MmList.OutMpuSetting(&m_mp_table, CONVENTION_ENTRY, 0, g_hwInfo.m_mpnum);
        MpuConfig(pCB, reg, pCfg);
    }
}