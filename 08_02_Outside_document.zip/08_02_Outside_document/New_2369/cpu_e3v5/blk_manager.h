#ifndef BLK_MANAGER_H_
#define BLK_MANAGER_H_

#include	"rnd_gen.h"
#include	"ifblk_manager.h"
#include	"insid_set.h"
#include	"sysreg.h"

/**
 * @brief コードブロックを管理するクラス。IBlockManagerを実装します。
 */
class CBlockManager : public IBlockManager
{
public:
	//
	//! ベクタフラグ列挙子（std::bitset<BSV_VECTOR_NUM>アクセス用）
	enum BSV_INTVECTOR {
		BSV_VECTOR_RESET	= 0,
		BSV_VECTOR_SYSERR,
		BSV_VECTOR_HVTRAP,
		BSV_VECTOR_FETRAP,
		BSV_VECTOR_TRAP0,
		BSV_VECTOR_TRAP1,
		BSV_VECTOR_RIE,
		BSV_VECTOR_FPPFPI,//ff
		BSV_VECTOR_UCPOP,
		BSV_VECTOR_MPUMMU,
		BSV_VECTOR_PIE,
		BSV_VECTOR_DEBUG,
		BSV_VECTOR_MAE,
		ADR_VECTOR_BGINT,
		BSV_VECTOR_FENMI,
		BSV_VECTOR_FEINT, //ffff
		BSV_VECTOR_EIINT000,
		BSV_VECTOR_EIINT001,
		BSV_VECTOR_EIINT002,
		BSV_VECTOR_EIINT003,
		BSV_VECTOR_EIINT004,
		BSV_VECTOR_EIINT005,
		BSV_VECTOR_EIINT006,
		BSV_VECTOR_EIINT007,
		BSV_VECTOR_EIINT008,
		BSV_VECTOR_EIINT009,
		BSV_VECTOR_EIINT010,
		BSV_VECTOR_EIINT011,
		BSV_VECTOR_EIINT012,
		BSV_VECTOR_EIINT013,
		BSV_VECTOR_EIINT014,
		BSV_VECTOR_EIINT015,
		BSV_VECTOR_NUM		/* END */
	};
	
public:

	/**
	 * @brief  このオブジェクトを生成します。
	 */
	CBlockManager(LIST_INSSET*  WeightSet);

	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual ~CBlockManager(){}

	/**
	 * @brief PSW.CU1ビットの問い合わせ関数
	 * @return CU1の場合:true
	 */
	virtual bool CU1isON(void) {
		return (gcs_check_simd_function() == 1);
	}

	/**
	 * @brief  ベクタブロックコードを生成します。
	 * @return ベクタブロックコード
	 */
	virtual std::vector<CVectorBlock*>* GenerateIntVector(TBlockConfig*);

	/* @brief  generate pe_check。
	 * @return Vector of vectorblock
	 */
	virtual std::vector<CVectorBlock*>* GeneratePECheck(TBlockConfig*);

	/**
	 * @brief  ベクタブロックコードを生成します。
	 * @return ベクタブロックコード
	 */
	virtual std::vector<CVectorBlock*>* GenerateVectorBlock(TBlockConfig*, std::string label_num);

	/**
	 * @brief  ハンドラコードを生成します。
	 * @return ブロックコード
	 */
	virtual std::vector<CHandlerBlock*>* GenerateHandler(TBlockConfig*);
	
	/**
	 * @brief  generate debug handler
	 * @return handler block
	 */
	virtual CHandlerBlock* GenerateDebugHandler(TBlockConfig*);

	/**
	 * @brief  working area block
	 * @return handler block
	 */
	virtual CHandlerBlock* GenerateWorkingAreaBlock(UI32 );


	/**
	 * @brief  generate code block for calculate return PC from debug handler
	 * @return handler block
	 */
	virtual CHandlerBlock* GeneratePCIncDebugHandler(TBlockConfig*);

	/**
	 * @brief  generate code block for calculate return PC from breakpoint exception
	 * @return handler block
	 */
	virtual CHandlerBlock* GenerateBreakPointIncPC(TBlockConfig*);

	/**
	 * @brief  プリロードコードを生成します。
	 * @return プリロードコード
	 */
	virtual std::vector<CPreloadBlock*>* GeneratePreload(TBlockConfig*);
	
		
	/**
	 * @brief  メモリ初期化コードを生成します。
	 * @param  recode メモリ初期化情報
	 */
	virtual CPreloadBlock* AppendMemPresetBlock(std::vector<T_MEMWRRECORD > * recode) ;
	

	/**
	 * @brief  プロローグコードを生成します。
	 * @return プロローグコード
	 */
	virtual std::vector<CPrologueBlock*>* GeneratePrologue(TBlockConfig * pCfg);

	
	/**
	 * @brief  同期ブロックコードを生成します。
	 * @return 同期ブロックコード
	 */
	virtual std::vector<CSyncBlock*>* GenerateSync(TBlockConfig*);
    CSyncBlock* AddHtNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* AddHtWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* AddHtWait2Standby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* AddWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* AddPeNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* AddPeWaitStandby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* AddSysNotifyStandby(TBlockConfig* pCfg, CSyncBlock* pSB);
    CSyncBlock* SyncStandbyGoNext(TBlockConfig* pCfg, CSyncBlock* pSB);
	
		
	/**
	 * @brief  プリフェッチコードを生成します。
	 * @param  recode プリフェッチ開始アドレス
	 * @param  recode プリフェッチサイズ
	 */
	virtual void AppendPrefetchCode (std::string & context, CSyncBlock* pPF);
	virtual void AppendPrefetchData (UI32 pf_addr ,UI32 pf_size, CSyncBlock* pPF);

	virtual void FetchLineZeroing (std::vector<INode*>& rCb);

	/**
	*  @brief Get max channel of all interrupt
	*/
	virtual UI32 GetMaxChannelInterrupt(std::map<UI32, IExceptionConfig*> mExp);

	/**
	 * @brief  create break setup block for break function
	 * @return preload block
	 */
	std::vector<CPreloadBlock*>* GenerateSetupBlock(TBlockConfig* pCfg);


	/**
	 * @brief  replace pIns by random nomarl instruction
	 * @return instruction
	 */
	virtual IInstruction* ReplaceInsbyOther(CCodeBlock* pCb, IInstruction* curpIns, UI32 insLen);

	/**
	 * @brief  get register include target PC in vector handler, JMP return in Funtion, loop counter when inloop sequence
	 * @return setof register index
	 */
	virtual UI32 GetConstraintRegister(CCodeBlock* pCb, IInstruction* pIns);

	/**
	 * @brief  ランダムタブロックコードを生成します。
	 * @param	pCfg    設定情報
	 * @return ブロックコード
	 */
	virtual std::vector<CCodeBlock*> GenerateRandomBlock(TBlockConfig* pCfg);

	/**
	* @brief	Break down current block into more smaller code block.
	* @param	- Input: Current code block.			
				- Output: vector of smaller code block.
	*/
	virtual std::vector<CCodeBlock*> BreakDownRandomBlock(TBlockConfig* pCfg, CCodeBlock* pCb);


	/**
	 * @brief  同期ブロックコードを生成します。
	 * @return 同期ブロックコード
	 */
	virtual std::vector<CTeSyncBlock*>* GenerateTeSync(TBlockConfig*);	
    CTeSyncBlock* AddHtNotifyComplete(TBlockConfig* pCfg, CTeSyncBlock* pTS);
    CTeSyncBlock* AddHtWaitComplete(TBlockConfig* pCfg, CTeSyncBlock* pTS);

	/**
	 * @brief	Generate function codes
	 * @param	Config information
	 * @return	Function code
	 */
	virtual std::vector<CFunctionBlock*>* GenerateFunction(TBlockConfig*);	

	/**
	 * @brief	Generate code to update MPU configuration
	 * @param	pCfg config information
	 * @param	pVFB output parameter of function codeblock
	 */
    void GenerateMPUpdate(TBlockConfig* pCfg, std::vector<CFunctionBlock*>* pVFB);
	/**
	 * @brief  エピローグコードを生成します。
	 * @return エピローグコード
	 */
	virtual std::vector<CEpilogueBlock*>* GenerateEpilogue(TBlockConfig*);
	
	
	/**
	 * @brief  終了コードを生成します。
	 * @return 終了コード
	 */
	virtual std::vector<CTerminateBlock*>* GenerateTerminateBlock(TBlockConfig*);
    CTerminateBlock* AddPeNotifyComplete(TBlockConfig* pCfg, CTerminateBlock* pTB);
    CTerminateBlock* AddPeWaitComplete(TBlockConfig* pCfg, CTerminateBlock* pTB);


	/**
	 * @brief generate random user code block
	 * @return new user code block
	 */
	virtual CUserBlock* GenerateUserBlock(LPCTSTR context_key, TBlockConfig* pCfg, std::string labelStr);

	/**
	 * @brief  ユーザコードを生成します。
	 * @return ユーザコード
	 */
	virtual std::vector<CUserBlock*>* InsertUserCode(LPCTSTR context_key , LPCTSTR user_key , TBlockConfig* pCfg, CCodeBlock* pCB) ;

	/**
	 * @brief  汎用レジスタを交差させるランダムタブロックコードを生成します。
	 * @param  N    ブロック番号
	 * @param  num  命令数
	 * @param  WeightSet 発生させる命令重みセット 
	 * @return ブロックコード
	 */
	virtual CCodeBlock* GenerateGrBlock(UI32 N, UI32 blocksize, UI32 num, UI32 reg, LIST_INSSET* WeightSet);

	/**
	 * @brief  ブロック間を繋ぐ命令を追加します。
	 * @param  src 前処理ブロック。このブロックに後処理へつながる命令が追加される。
	 * @param  dst 後処理ブロック
	 * @return 後処理の参照
	 */
	virtual CCodeBlock* ChainBlock(CCodeBlock* src, CCodeBlock* dst);
	virtual CCodeBlock* MixBlock(CCodeBlock* src, CCodeBlock* dst);

	/**
	 * @brief 例外を起こす命令を事前に決定させる。
	 * @param pCb    処理するコードブロックの参照
	 * @param pEx    例外発生確率を設定する
	 */
	virtual void PresetException(CCodeBlock* pCb, IException* pEx);

	/**
	 * @brief This function append code block initializing sharing memory
	 * @param recode    Accessed memory record
	 * @return Code block
	 */
	virtual CPreloadBlock * AppendShareMemPreset(std::vector<T_MEMWRRECORD > * recode);
	
	/**
	 * @brief 命令セットの重み情報へのポインタを取得。
	 */
	virtual CInstructionSet * GetWeightSet() {
		return &m_nrmSet ;
	}


	/********************  E3V5 Architecture functions *********************/
protected:

	/**
	 * @brief		 レジスタ退避コードのパーツを生成しコードブロックに追加する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param label  
	 * @return       追加されたブロック
	 */
	CCodeBlock*		SaveRegisterDB(CCodeBlock* pCB , std::string label) ;
	
	/**
	 * @brief		 指定されたブロックにPSW.CUビットを書き換えるコードを追加する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param reg    生成コードの実行時に１つ必要となる汎用レジスタのレジスタ番号を指定する。
	 * @param cubits CUビット値(0-7)
	 * @return       追加されたブロック
	 */
	CCodeBlock*		SwitchCoProcessor(CCodeBlock* pCB, UI32 reg, UI32 cubits);


	/**
	 * @brief		 指定されたブロックにPSW.CUビットを書き換えるコードを追加する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param reg    生成コードの実行時に１つ必要となる汎用レジスタのレジスタ番号を指定する。
	 * @param cubits CUビット値(0-7)
	 * @return       追加されたブロック
	 */
	 CCodeBlock* TransUserMode(CCodeBlock* pCB, UI32 reg1, UI32 reg2, TBlockConfig * pCfg);
	 
     /**
     * @brief    Transfer to corresponding Guest Mode with GPID
     */
     CCodeBlock* TransGuestMode(CCodeBlock* pCB, UI32 reg1, UI32 reg2, TBlockConfig * pCfg);

	/**
	 * @brief	MPU設定コードの生成
	 * @param	pCB     命令追加するコードブロック
	 * @param	reg     処理に使用するレジスタのインデックス値    
	 * @param	pCfg    設定情報
	 * @return  追加されたコードブロック（入力コードブロック）
	 */
	CCodeBlock*		MpuConfig(CCodeBlock* pCB , UI32 reg , TBlockConfig* pCfg ) ;


	/**
	 * @brief	MMU設定コードの生成
	 * @param	pCB     命令追加するコードブロック
	 * @param	reg     処理に使用するレジスタのインデックス値    
	 * @param	pCfg    設定情報
	 * @return  追加されたコードブロック（入力コードブロック）
	 */
	CCodeBlock*		MmuConfig(CCodeBlock* pCB , UI32 reg , TBlockConfig* pCfg ) ;


	/**
	 * @brief		 指定されたブロックの汎用レジスタを初期化する（mov）
	 * @param pCB    命令を追加するコードブロックの参照
	 * @return       追加されたブロック
	 */
	CCodeBlock*		InitGR(CCodeBlock* pCB);

	void			PresetFixedMPU(CCodeBlock *pCB);

	/**
	 * @brief		 指定されたブロックのFP-SIMD汎用レジスタを初期化する（movvi）
	 * @param pCB    命令を追加するコードブロックの参照
	 * @return       追加されたブロック
	 */
	CCodeBlock*		InitWR(CCodeBlock* pCB);

	/**
	 * @brief		 指定されたブロックのベクトルレジスタを初期化する（ldtc.vr）
	 * @param pCB    命令を追加するコードブロックの参照
	 * @return       追加されたブロック
	 */
	CCodeBlock*		InitLdtcVR(CCodeBlock* pCB);


	/**
	 * @brief		 指定されたブロックにNCレジスタの初期化コードを追加する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param lst    初期化が指示されたSRリスト
	 * @return       追加されたブロック
	 */
	CCodeBlock* InitNcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* lst);


	/**
	 * @brief		 指定されたブロックにVCレジスタの初期化コードを追加する(ldvc.sr)
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param lst    初期化が指示されたSRリスト
	 * @return       追加されたブロック
	 */
	CCodeBlock* InitVcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* lst);


	/**
	 * @brief		 指定されたブロックにTCレジスタの初期化コードを追加する(ldtc.sr)
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param lst    初期化が指示されたSRリスト
	 * @return       追加されたブロック
	 */
	CCodeBlock* InitTcSR(CCodeBlock* pCB, std::map<UI32,ISysReg*>* lst);
	 
	 
	/**
	 * @brief		 LDSR命令により指定されたブロックのシステムレジスタを初期化する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param srinf  SR list :: vector< std::pair < KEY=(sel*32+reg),VAL=(value) > >
	 * @param        追加されたコードブロック
	 */
	CCodeBlock*	InitSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf);


	/**
	 * @brief		 LDVC.SR命令により指定されたブロックのシステムレジスタを初期化する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param srinf  SR list :: vector< std::pair < KEY=(sel*32+reg),VAL=(value) > >
	 * @param        追加されたコードブロック
	 */
	CCodeBlock*	InitLdvcSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf);


	/**
	 * @brief		 LDTC.SR命令により指定されたブロックのシステムレジスタを初期化する
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param srinf  SR list :: vector< std::pair < KEY=(sel*32+reg),VAL=(value) > >
	 * @param        追加されたコードブロック
	 */
	CCodeBlock*	InitLdtcSR(CCodeBlock* pCB, std::vector< std::pair<ISysReg*,UI32> >& srinf);


	/**
	 * @brief		 EI割り込み用のスタックエントリー値を設定するコードを生成する。
	 * @param pCB    命令を追加するコードブロックの参照
	 * @param reg    生成コードの実行時に必要となる汎用レジスタのレジスタ番号を指定する。
	 * @param memreg 生成コードの実行時に必要となるベースアドレスレジスタのレジスタ番号を指定する。
	 */
	CCodeBlock* InitStackEntry(CCodeBlock* pCB , UI32 reg, UI32 memreg ) ;

	/**
	 * @brief [E3v5] RType演算のレジスタ重複回避処理を行う。
	 * @param pCb    処理するコードブロックの参照
	 */
	virtual void RTypeVerify(CCodeBlock* pCb);

	/**
	 * @brief   Expand sequential instruction
	 * @param	pCb: Pointer to code block
	 */
	void ExpandSequentialInstruction(CCodeBlock* pCb);

	/**
	 * @brief [E3v5] 複合命令を単命令列に展開する。
	 * @param pCb    処理するコードブロックの参照
	 */
	void ExpandComplexInstruction(CCodeBlock* pCb, TBlockConfig* pCfg);

	/**
	 * @brief	Adjust load system register instruction to mask some specified bits
	 * @param	A pointer to a code block
	 */

	void UpdateAccessSysReg(TBlockConfig* pCfg, CCodeBlock* pCb);

	/**
	 * @brief [E3v5] Jarl命令のラベル処理を行う。
	 * @param pCb    処理するコードブロックの参照
	 */
	virtual void LabelingJarl(CCodeBlock* pCb, std::string contextStr);


	/**
	 * @brief ブランチ構造を構築する（ブランチ命令）
	 */
	void RemoveRegDependance(CCodeBlock* pCb);


	/**
	 * @brief ブランチ構造を構築する（ブランチ命令）
	 */
	void ChainBcondSequence(CCodeBlock* pCb);


	/**
	 * @brief  指定ブロック中からSWITCH命令を検索しテーブルを準備する。
	 * @param  pCb 処理対象のブロック
	 * @return 成功した場合、真を返す。
	 */
	bool SwitchPresetTable(CCodeBlock* pCb); 


	/**
	 * @brief  システムレジスタに対するセルフチェックコードを生成する
	 * @param  pEB  命令を生成するコードブロック
	 * @param  pCfg 生成設定
	 */
	void GenVerifier(CCodeBlock* pEB, TBlockConfig* pCfg);

	/**
	 * @brief	calltのテーブル＋命令列を生成する
	 * @return	calltブロック（先頭にロードテーブル、その後にランダム命令が並ぶ）
	 */
	virtual CPreloadBlock* GenerateCalltBlock(TBlockConfig*, std::string label_num, UI32 blocksize = 0);

	/**
	 * @brief	hvcallのテーブル＋命令列を生成する
	 * @return	hvcallブロック（先頭にロードテーブル、その後にランダム命令が並ぶ）
	 */
	CCodeBlock* GenerateHvCallBlock(CCodeBlock* pCb, TBlockConfig*);

    /**
     * @brief	insert dead code into code block
     * @return	code block after insertion
     */
    CCodeBlock* InsertDeadCode(CCodeBlock* pCb);


    /**
	 * @brief	insert return instruction for CALLT/SYSCALL
	 * @return	code block
	 */
	void BreakCalltBlock(CCodeBlock* pCb);

	/**
	 * @brief  指定ブロックの指定したSWITCH命令を検索しテーブルを準備する。
	 * @param  pCb 処理対象のブロック
	 * @param  i   先頭からの命令数（switchの位置）
	 * @return 成功した場合、真を返す。
	 */
	bool MakeSwitchTable(CCodeBlock* pCb, UI32 i);

	/**
	 * @brief  指定ブロック内のloop命令を安定的なループに再構成する。
	 * @param  pCb 処理対象のブロック
	 */
	void MakeLoopSequence(CCodeBlock*);

	void GenMmuHandler(TBlockConfig* pCfg , CHandlerBlock* pHB , UI32 reg);

	/**
	 * @brief	This function increase the register dependence by reducing number register used in each random code block.
	 * @param	pCb The pointer to random code block. 
	 * @param	reg1 The 1st fixed register in case of block-mix is 1 or 2.
	 * @param	reg2 The 2nd fixed register in case of block-mix is 2.
	 */
	void IncRegisterDependance(CCodeBlock* pCb, UI32 reg1, UI32 reg2);

	/**
	 * @brief  ファンクションコードを生成します。
	 * @param	pCfg Config information
	 * @param	pVFB output parameter of function codeblock
	 */
	void GenerateJarlFunction(TBlockConfig* pCfg, std::vector<CFunctionBlock*>* pVFB);
	
	std::string GetMContext(TBlockConfig* pCfg) {
		std::string contextStr("NM_");
		if (pCfg->m_bNC != true) {

			std::stringstream ss;
			ss << 'G' << 'M' << std::dec << std::setw(2) << std::setfill('0') << pCfg->m_GMID;
			ss << '_';  
			ss >> contextStr;
		}
		return contextStr;
	}
	
	std::string GetTContext(TBlockConfig* pCfg) {
		std::string contextStr("NMNT_");
		if (pCfg->m_bNC != true) {
			std::stringstream ss;
            ss << 'G' << 'M' << std::dec << std::setw(2) << std::setfill('0') << pCfg->m_GMID;
			ss << 'T' << std::dec << std::setw(2) << std::setfill('0') << pCfg->m_HTID;
			ss << '_';  
			ss >> contextStr;
		}
		return contextStr;
	}

	/**
	 * @brief  Parsing user code from string to UserInstruction
	 * @param	vUcBody	vector that contains user code strings
	 * @param	pCB	pointer of code block that will be inserted user code
	 */
	void ParseUserCode(std::vector<std::string> &vUcBody, CCodeBlock* pCB);

	/**
	 * @brief  Generating random instruction for handler
	 * @param	pCB	pointer to handler code block
	 */
	void GenerateRandomCode(CCodeBlock* pCB, UI32 blocksize, UI32 num, TBlockConfig* pCfg, const std::string &name);

	/**
	 * @brief	Get information of which handler is defined in user code
	 * @param	pBs	pointer to bitset that manages which handler is defined in user code
	 */
	void GetUserHandler(const std::string &strContext, std::bitset<BSV_VECTOR_NUM> *pBs);

	/**
	 * @brief  Get body of user defined handler
	 * @param	pCB	pointer to handler code block
	 */
	void GetUserHanlderBody(const std::string &strHandler, CCodeBlock *pCB);

	/**
	 * @brief	Check whether 2 random instruction can create a C2B1 couple
	 * @param	pIns1, pIn2: 2 input instruction.
	 */
	bool CheckC2B1Couple(IInstruction *pIns1, IInstruction *pIns2);

	/**
	 * @brief	Find and set C2B1 attribute for random instruction in codeblock.
	 * @param	pCB	pointer to code block.
	 */
	void CombineC2B1(CCodeBlock *pCB);

    /**
    * @brief	Add Dead Code
    * @param	pCB	pointer to code block, pIns  pointer to instruction
    */
    virtual void AddDeadCode(CCodeBlock *pCB);

	/**
	 * @brief Get general register used in handler
	 */
	virtual UI32 GetHandlerWorkReg() {return m_nWorkReg;}

	virtual UI32 GetHandlerReg() {return m_nHandlerReg;};

    /**
    * @brief Get variable which save MPU information
    */
    virtual CMmList* GetMPUInfor() { return &m_MmList; }

    /**
    * @brief Initialize MPU register
    */
    void InitMPURegister(CCodeBlock* pCB, TBlockConfig* pCfg);


protected:
	CInstructionSet	m_nrmSet;		//!< @brief ランダム部で使用する命令セット
	LIST_INSSET* 	m_pWeightSet;	//!< @brief セット名 => 重みつき命令セレクタ
	CMmList			m_MmList;		//!< @brief	MMU/MPU設定情報オブジェクト
	T_MP_SETTING 	m_mp_table;		//!< @brief	MPUレジスタ設定値テーブル。構成：{MPLA0 ,MPUA0 ,MPAT0}, ... ,{MPLA15 ,MPUA15 ,MPAT15} ,{MPPRT0 ,MPPRT1 ,MPPRT2 }
	CParserTlbList	m_tlb_setting;	//!< @brief	TLBエントリー設定値テーブル。
	bool			m_bStatistics;  //!< @brief コード生成カバレッジ蓄積対象
	std::vector<UI32>	m_vMPUpdate; //!< @brief Store information of dynamic MPU update in random code
	UI32			m_nAsyncCount;
	UI32			m_nHandlerReg;
	UI32			m_nWorkReg;
	std::vector<std::pair<UI32, std::vector<UI32>>> m_vHandlerConstraintReg;
	std::vector<UI32>	m_vFunctionIndex = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};

public:
	std::bitset<BSV_VECTOR_NUM> m_bsVector;	//!< @brief ベクタ有効ビット
};

typedef	std::bitset<CBlockManager::BSV_VECTOR_NUM> BS_VECTOR;

#endif /*BLK_MANAGER_H_*/


