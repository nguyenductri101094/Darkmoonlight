#ifndef IFVALCONSTRAINT_H_
#define IFVALCONSTRAINT_H_

#include "rtg_common.h"
#include "rnd_gen.h"
#include "ifsimulator.h"



class CAddressWeight;
/**
 * @brief	値制約を抽象化するクラス。
 */
class IValConstraint {
public:
	typedef enum EN_CONSTRAINT_TYPE {
		FETCH,
		LOAD_MEMORY, 
		STORE_MEMORY, 
		PARAM_VALUE,
		RAISE_MERROR,
		FIXED_MPU,
		DUMMY,
		ACCESS_RANGE,
		CONSTRAINT_TYPE_NUM
	} CONSTRAINT_TYPE;
	
	/**
	 * @brief 	このオブジェクトを生成します
	 * @param	min
	 * @param	max
	 * @param	mask
	 * @param	size
	 */	
	IValConstraint(UI64 min, UI64 max, UI64 mask, UI32 size)
	 : m_nMin(min), m_nMax(max), m_nMsk(mask), m_nUnA(0), m_nSzm(size), m_bIsChangeSize(false), m_bsCtype(0) {}

	/**
	 * @brief 	このオブジェクトを生成します
	 * @param	min
	 * @param	max
	 * @param	size
	 */	
	IValConstraint(UI64 min, UI64 max, UI32 size)
	 : m_nMin(min), m_nMax(max), m_nMsk(size - 1), m_nUnA(0), m_nSzm(size), m_bIsChangeSize(false), m_bsCtype(0) {}

	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IValConstraint(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<CONSTRAINT_TYPE_NUM> bs)
	 : m_nMin(min), m_nMax(max), m_nMsk(mask), m_nUnA(0), m_nSzm(size), m_bIsChangeSize(false), m_bsCtype(bs) {}
	
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~IValConstraint(){}


	/**
	 * @brief  指定値が制約に適合するかを検証します
	 * @param  val 検証値
	 * @return 適合する場合真を返す。
	 */
	virtual bool IsValid(UI64 val) {
		if (InRange(val)) {		// 範囲内であることは必須
			return m_nUnA ? (IsAligned(val)!=true) : IsAligned(val);
		}
		return false;
	}

	/**
	 * @brief  指定値が制約に適合するかを検証します(for WReg)
	 * @param  val 検証値
	 * @return 適合する場合真を返す。
	 */
	virtual bool IsValidWR(__uint128_t val) {
		return false;
	}


	/**
	 * @brief  指定値が適切な値範囲内にあるかを検証します。
	 * @param  val 検証値
	 * @return 適合する場合真を返す。
	 */
	virtual bool InRange(UI64 val) {
		return (m_nMin <= val) && (val <= ( ((m_nMin == 1)&&(m_nMax == 1)) ? 1 : ((m_nMax-m_nSzm+1) < m_nMin ) ? (m_nMax) : ( (m_nMax+1 >= m_nSzm) ? (m_nMax-m_nSzm+1) : 0)));
	}


	/**
	 * @brief  指定値が適切なアラインメントであるかを検証します。
	 * @param  val 検証値
	 * @return 適合する場合真を返す。
	 */
	virtual bool IsAligned(UI64 val) {
		return ((val & m_nMsk)==0); 
	}


	/**
	 * @brief  指定値が適切なアラインメントであるかを検証します。
	 *         ミスアラインを発生させる端数を設定（端数値がランダム）
	 */
	virtual void Unalign() {
		if (m_nMsk > 0) {
			m_nUnA = g_rnd.GetRange((UI32)1,(UI32)m_nMsk);
		}
	}


	/**
	 * @brief  制約に適合する値を取得します。
	 * @return 適正値。
	 */
	virtual UI64 SelectValue() {
		return (g_rnd.GetRange((UI64)m_nMin, (UI64)( ((m_nMin == 1)&&(m_nMax == 1)) ? 1 : ((m_nMax+1 >= m_nSzm) ? (m_nMax-m_nSzm+1):0))) & ~m_nMsk) + m_nUnA;

	}
	
	/**
	 * @brief  制約に適合する値を取得します。
	 * @return 適正値。
	 */
	virtual UI64 SelectValue(UI64 low_add, UI64 high_add) {return 0;} 

	/**
	 * @brief  制約に適合する値を取得します。(for Wreg)
	 * @return 適正値。
	 */
	virtual std::pair<std::bitset<4> ,__uint128_t> SelectValueWR() {
		return std::pair<std::bitset<4> ,__uint128_t>(0,(__uint128_t)0);
	}
	
	
	/**
	 * @brief  制約属性を取得します。
	 * @param  t 制約属性
	 * @return 指定フラグが立っている場合真を返す。
	 */
	virtual bool GetType(CONSTRAINT_TYPE t) {
		return m_bsCtype[t];
	}
	
	
	/**
	 * @brief  制約属性を設定します。
	 * @param  t 制約属性
	 * @param  v 属性値
	 */
	virtual void SetType(CONSTRAINT_TYPE t, bool v = true) {
		m_bsCtype.set(t, v);
	}
	
	/**
	 * @brief Set range for allocated memory
	 * @param nMin lower boundary value
	 * @param nMax upper boundary value
	 * @return None
	 */
	virtual void SetRange(UI64 nMin, UI64 nMax) {
		m_nMin = nMin;
		m_nMax = nMax;
	}

	/**
	 * @brief  制約属性をダンプします。
	 * @param  os   [in] ダンプ出力先
	 */
	virtual void Dump (std::ostream& os = std::cout) {
		os << "MIN  = 0x" << std::hex << std::setw(16) << std::setfill('0') << m_nMin << std::endl;
		os << "MAX  = 0x" << std::hex << std::setw(16) << std::setfill('0') << m_nMax << std::endl;
		os << "MASK = 0x" << std::hex << std::setw(16) << std::setfill('0') << m_nMsk << std::endl;
		os << "UAln = 0x" << std::hex << std::setw(8)  << std::setfill('0') << m_nUnA << std::endl;
		os << "Size = " << std::dec << m_nSzm << std::endl;
	}

	/**
	 * @brief virtual function was using for specify base class and derived class in inheritance tree  
	 * @return true for class need to adjust memmory. Each derived class will return different value.
	 */
	virtual bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM){
		return false;
	}

	/**
	 * @brief virtual function was using for specify base class and derived class in inheritance tree  
	 * @return true for class need to adjust memmory. Each derived class will return different value.
	 */
	virtual bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM, UI32 lnk){
		return false;
	}
	/**
	 * @brief  メモリ情報（アクセス権限）の情報を設定します。
	 * @param  pSL セグメントテーブル
	 */
	virtual void SetSegmentList(std::vector<CSegmentList*>* pSL) {}

	virtual bool IsLock() {
		return false;
	}

	virtual void SetSize(UI32 size) {
		m_nSzm = size;
	}
	virtual UI32 GetSize() {
		return m_nSzm;
	}

	UI64		m_nMin;		/*!< @brief 範囲下限値 */
	UI64		m_nMax;		/*!< @brief 範囲上限値 */
	UI64		m_nMsk;		/*!< @brief マスク(アラインアクセス用のマスク) */
	UI32		m_nUnA;		/*!< @brief アンアラインオフセット(アライン＋アドレス＝0以外だとMAEを発生を意味する) */
	UI32		m_nSzm;		/*!< @brief アクセスサイズ */
    bool        m_bIsChangeSize;    //!< @brief It euqal true if original size is changed
	std::bitset<CONSTRAINT_TYPE_NUM>	m_bsCtype;	/*!< @brief action */
};


/**
 * @brief	値制約を抽象化するクラス。
 */
class CAddressWeight {
public:
    CAddressWeight () : m_wrAdr(&g_rnd) {}
    virtual ~CAddressWeight(){}
	
	bool Set(MEMADDR start, MEMADDR end, UI32 ratio) {
        if (ratio == 0) {
        	MSG_WARN(0, "Address (%08x - %08x) weight is ZERO.\n", start, end);
        	return false;
        }
        if (start > end) {
        	MSG_WARN(0, "Invalid address range (start > end) in weight file.\n");
        	return false;
        }
   		MEMRANGE mr(start, end);
    	return m_wrAdr.Set(mr, ratio);
    }

	bool Set(MEMADDR start, MEMADDR end, UI32 lnk, UI32 ratio, bool isMirror) {
        if (ratio == 0) {
        	MSG_WARN(0, "Address (%08x - %08x) weight is ZERO.\n", start, end);
        	return false;
        }
        if (start > end) {
        	MSG_WARN(0, "Invalid address range (start > end) in weight file.\n");
        	return false;
        }
        if( lnk > 2 ) {
        	MSG_WARN(0, "Invalid lnk ( lnk > 2 ) in weight file.\n");
        	return false;
        }
   		MEMRANGE mr(start, end);
    	return m_wrAdr.Set(mr, lnk, ratio, isMirror);
    }
    
    MEMADDR SelectValue () {
    	MEMRANGE mr = SelectRange();
    	return g_rnd.GetRange(mr.first, mr.second);
    }

    MEMRANGE SelectRange () {
    	if (m_wrAdr.Count()) {
    		return m_wrAdr.GetObj();
    	} else {
    		return MEMRANGE(0xFEE00000, 0xFEFFFFFF);
    	}
    }
    
    std::set<MEMRANGE> KeySet() {
    	return m_wrAdr.KeySet();
    }
    
    void Dump() {
    	std::set<MEMRANGE> s = m_wrAdr.KeySet();
    	std::for_each (s.begin(), s.end(), [](const MEMRANGE& m) {std::cout << std::hex << m.first << ", " << m.second << std::endl;});
    }
    
    size_t Count () {
    	return m_wrAdr.Count();
    }
    
    void Delete(MEMRANGE mr) {
    	m_wrAdr.Delete(mr);
    	ReCalc();
    }
    
    void ReCalc () {
    	m_wrAdr.ReCalc();
    }
    
	UI32 GetLnk( UI32 adr ) {
    	std::set<MEMRANGE> s = m_wrAdr.KeySet();
        std::set<MEMRANGE>::iterator itr ;

        for(itr=s.begin(); itr!=s.end(); itr++) {
            if( (itr->first < adr) && (itr->second > adr) ){
                return m_wrAdr.GetLnk( *itr );
            }
        }
        //MSG_WARN(0, "No Range Instruction Address : 0x%08x\n", adr) ;
        return 0 ;
    }

	bool GetMirror( MEMADDR adr ) {
		std::set<MEMRANGE> s = m_wrAdr.KeySet();
		std::set<MEMRANGE>::iterator itr ;
		if( s.empty() ){
			//MSG_WARN(0, "Un define \"mirror\" in weight file.\n");
			return false ;
		}
		for(itr=s.begin(); itr!=s.end(); itr++) {
			if( (itr->first <= adr) && (itr->second >= adr) ){
				return m_wrAdr.GetMirror( *itr );
			}
		}
		//MSG_WARN(0, "No Range Instruction Address : 0x%08x\n", adr) ;
		return false ;
	}

	UI32 GetMirrorSize() {	
		return m_wrAdr.GetMirrorSize();
	}

	// Check mirror area overlap with memory range 
	bool InRangeMirror(MEMADDR start, MEMADDR end) {
		return m_wrAdr.InRangeMirror(start, end) ;
	}

	UI32 GetWeight(MEMRANGE mr) {
		return m_wrAdr.GetWeight(mr);
	}

private:
	CWeightedRandom <MEMRANGE> m_wrAdr;
};


class CBitWeight {
public:
    CBitWeight () : m_wrAdr(&g_rnd) {}
    virtual ~CBitWeight(){}
	
	bool Set(MEMADDR addr, UI8 bpos, UI32 ratio) {
        if (ratio == 0) {
        	MSG_WARN(0, "Address:bit (%08llx:%d) weight is ZERO.\n", addr, bpos);
        	return false;
        }
   		MEMBITS mb(addr, bpos);
    	return m_wrAdr.Set(mb, ratio);
    }

	bool Set(MEMADDR addr, UI8 bpos, UI32 lnk, UI32 ratio, UI32 mirror) {
        if (ratio == 0) {
        	MSG_WARN(0, "Address:bit (%08llx:%d) weight is ZERO.\n", addr, bpos);
        	return false;
        }
        if( lnk > 2 ) {
        	MSG_WARN(0, "Invalid lnk ( lnk > 2 ) in weight file.\n");
        	return false;
        }
   		MEMBITS mb(addr, bpos);
    	return m_wrAdr.Set(mb, lnk, ratio, mirror);
    }
    
    MEMBITS SelectValue () {
    	return m_wrAdr.GetObj();
    }
    
    void Dump() {
    	std::set<MEMBITS> s = m_wrAdr.KeySet();
    	std::for_each (s.begin(), s.end(), [](const MEMBITS& m) {std::cout << std::hex << m.first << ":" <<std::dec << (int)m.second << std::endl;});
    }
    
    size_t Count () {
    	return m_wrAdr.Count();
    }
    
    void Delete(MEMBITS mb) {
    	m_wrAdr.Delete(mb);
    	ReCalc();
    }
    
    void ReCalc () {
    	m_wrAdr.ReCalc();
    }

private:
	CWeightedRandom <MEMBITS> m_wrAdr;
};


/**
 * @brief	LOAD
 */
class ILoadConstraint : public IValConstraint {
public:
	
	/**
	 * @brief  このオブジェクトを生成します
	 */	
	ILoadConstraint(UI64 min, UI64 max, UI64 mask, UI32 size)
	 : IValConstraint(min, max, mask, size, (1 << IValConstraint::LOAD_MEMORY)) {}


	/**
	 * @brief  このオブジェクトを生成します
	 */	
	ILoadConstraint(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<IValConstraint::CONSTRAINT_TYPE_NUM> bs)
	 : IValConstraint(min, max, mask, size, (bs.to_ulong() | (1 << IValConstraint::LOAD_MEMORY)) ) {}
	
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~ILoadConstraint(){}
};


/**
 * @brief	STORE
 */
class IStoreConstraint : public IValConstraint {
public:
	
	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IStoreConstraint(UI64 min, UI64 max, UI64 mask, UI32 size)
	 : IValConstraint(min, max, mask, size, (1 << IValConstraint::STORE_MEMORY)) {}


	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IStoreConstraint(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<IValConstraint::CONSTRAINT_TYPE_NUM> bs)
	 : IValConstraint(min, max, mask, size, (bs.to_ulong() | (1 << IValConstraint::STORE_MEMORY)) ) {}
	 
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~IStoreConstraint(){}
};


/**
 * @brief	FPU単精度の値制約を抽象化するクラス。
 *			全てのオペランドはこのインターフェースを実装する必要がある。 
 */
class CFpuWeightParam {
public:
	enum {
		FPU_POSITIVE,
		FPU_NEGATIVE,
		FPU_RANDOM
	} FPU_SIGN;

	CFpuWeightParam () : m_name(""), m_id(0), m_weight(0), m_sign(FPU_RANDOM), m_fraction_min(0), m_fraction_max(0x7fffff), m_fraction_and(0x7fffff), m_fraction_or(0),
		m_exponent_min(0), m_exponent_max(0xff), m_exponent_and(0xff), m_exponent_or(0), m_max_noise(0) {}
	~CFpuWeightParam () {}

public:
	std::string		m_name;
	UI32			m_id;
	UI32			m_weight;
	UI32			m_sign;
	UI64			m_fraction_min;
	UI64			m_fraction_max;
	UI64			m_fraction_and;
	UI64			m_fraction_or;
	UI32			m_exponent_min;
	UI32			m_exponent_max;
	UI32			m_exponent_and;
	UI32			m_exponent_or;
	UI32			m_max_noise;
};

class FpuTypeWeight : public CWeightedRandom<UI32> {
public:

	FpuTypeWeight(IRandom* pr) : CWeightedRandom<UI32>(pr) {}
	virtual ~FpuTypeWeight(){}

	virtual void SetWeight(std::vector<CFpuWeightParam*> vFPU){
		Clear();
		for(UI32 n = 0; n < vFPU.size(); n++) {
			Set(vFPU[n]->m_id, vFPU[n]->m_weight); 
		}
		return;
	}
};

/**
 * @brief	FPU単精度の値制約を抽象化するクラス。
 *			全てのオペランドはこのインターフェースを実装する必要がある。 
 */
class IFpuSingleConstraint : public IValConstraint {
public:
	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IFpuSingleConstraint() : IValConstraint(0,0,0,0), m_pType(NULL), m_noise(0), m_bValid(false), m_vType(), m_vNoise(), m_elm_check_flag(0) {}

	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IFpuSingleConstraint(std::bitset<4> flag) : IValConstraint(0,0,0,0), m_pType(NULL), m_noise(0), m_bValid(false), m_vType(), m_vNoise(), m_elm_check_flag(flag) {}
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~IFpuSingleConstraint(){}

	/**
	 * @brief  エレメントフラグを設定する。
	 */
	virtual void SetElmCheckFlag( int flag ) {
		m_elm_check_flag = std::bitset<4>(flag);
	}

	/**
	 * @brief  制約に適合する値を取得します。
	 * @return 適正値。
	 */
	virtual UI64 SelectValue();

	/**
	 * @brief  指定された値が、制約に適合するかを検証します。
	 * @param  val 検証値
	 * @return 適合する場合、真を返す
	 */
	virtual bool IsValid(UI64 val);
	
	/**
	 * @brief  制約に適合する値を取得します。
	 * @return 適正値。
	 */
	virtual std::pair<std::bitset<4> ,__uint128_t> SelectValueWR();

	/**
	 * @brief  指定された値が、制約に適合するかを検証します。
	 * @param  val 検証値
	 * @return 適合する場合、真を返す
	 */
	virtual bool IsValidWR(__uint128_t val);

	/**
	 * @brief  制約属性をダンプします。
	 * @param  os   [in] ダンプ出力先
	 */
	virtual void Dump (std::ostream& os = std::cout) {
		os << "m_type = 0x" << std::hex << m_pType->m_name << std::dec << std::endl;
		for(UI32 i = 0; i < m_vType.size(); i++) {
			os << "m_vType[" << i << "] = 0x" << std::hex << (m_vType[i] == NULL ? "NULL" : m_vType[i]->m_name) << std::dec << std::endl;
		}
	}
		
protected:
	CFpuWeightParam*				m_pType;
	UI32							m_noise;
	bool							m_bValid;
	std::vector<CFpuWeightParam*>	m_vType;
	std::vector<UI32>				m_vNoise;
	std::bitset<(sizeof(__uint128_t)/sizeof(UI32))> m_elm_check_flag;

public:
	static CWeightedRandom<UI32>*			pst_WrType;
	static std::vector<CFpuWeightParam*>	vst_FPUParam;
};	

/**
 * @brief	FPU倍精度の値制約を抽象化するクラス。
 *			全てのオペランドはこのインターフェースを実装する必要がある。 
 */
class IFpuDoubleConstraint : public IValConstraint {
public:
	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IFpuDoubleConstraint() : IValConstraint(0,0,0,0), m_pType(NULL), m_noise(0), m_bValid(false) {}
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~IFpuDoubleConstraint(){}

	/**
	 * @brief  制約に適合する値を取得します。
	 * @return 適正値。
	 */
	virtual UI64 SelectValue();

	/**
	 * @brief  指定された値が、制約に適合するかを検証します。
	 * @param  val 検証値
	 * @return 適合する場合、真を返す
	 */
	virtual bool IsValid(UI64 val);

protected:
	CFpuWeightParam*			m_pType;
	UI64						m_noise;
	bool						m_bValid;

public:
	static CWeightedRandom<UI32>* pst_WrType;
	static std::vector<CFpuWeightParam*> vst_FPUParam;
};

/**
 * @brief	Generate a random value in range.
 */
class INumConstraint : public IValConstraint{
public:
	
	/**
	 * @brief 	Constructure
	 * @param	min
	 * @param	max
	 */	
	INumConstraint(UI64 min, UI64 max)
	 : IValConstraint(min, max, 0, 0) {}
	
	/**
	 * @brief  Destructure
	 */	
	virtual ~INumConstraint(){}


	/**
	 * @brief  Check whether input value satifies constraint
	 * @param  val checking value
	 * @return true if value is value, otherwise return false.
	 */
	virtual bool IsValid(UI64 val) {
		return ((m_nMin <= val) && (val <= (m_nMax >= m_nMin ? m_nMax : m_nMin)));
	}

	/**
	 * @brief  Select a random value under constraint.
	 * @return selected value
	 */
	virtual UI64 SelectValue() {
		return g_rnd.GetRange((UI64)m_nMin, (UI64)(m_nMax >= m_nMin ? m_nMax : m_nMin));

	}
};

/**
 * @brief	Dummy Constraint
 */
class IDummyConstraint : public IValConstraint{
public:
	
	IDummyConstraint()
	 : IValConstraint(0, 0xFFFFFFFF, 0, 1, (1<<IValConstraint::DUMMY)) {}

	virtual bool IsValid(UI64 val) {return true;}
	virtual UI64 SelectValue() {return g_rnd.GetRange(m_nMin, m_nMax);}

	/**
	 * @brief  Destructure
	 */	
	virtual ~IDummyConstraint(){}
};

#endif /*IFVALCONSTRAINT_H_*/

extern CAddressWeight g_LoadableAddr;
extern CAddressWeight g_StorableAddr;
extern CAddressWeight g_FetchAddr;
extern CAddressWeight g_RmwAddr;
extern CAddressWeight g_LnkBitAddr;
extern CAddressWeight g_RegisterBankAddr;
extern std::vector<std::pair<UI32, MEMRANGE>>	g_FixedMPU;
extern ISimulatorHwInfo							g_hwInfo;
extern CAddressWeight g_LoadableLnkAddr;
extern CAddressWeight g_StorableLnkAddr;
extern CAddressWeight g_RmwLnkAddr;
// eof
