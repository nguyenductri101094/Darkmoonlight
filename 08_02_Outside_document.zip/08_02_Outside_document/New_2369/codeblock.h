#ifndef CODEBLOCK_H_
#define CODEBLOCK_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"
#include	"ifnode.h"
#include	"ifoperand.h"
#include	"ifinstruction.h"
#include	"sim_res.h"
#include    "ifbreakparam.h"

/**
 *	@brief  コードブロックを管理するクラスです。
 *          コードブロックはPCがシーケンシャルに進む一連の命令群です。
 * 
 * m_vcode = このブロック内の命令配列
 * m_lhash = アドレスをKey、命令参照をValueとするハッシュテーブル
 * 
 */
class CCodeBlock : public INode
{
public:

	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CCodeBlock();


	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CCodeBlock(std::string label);


	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 *  @param  addr  配置アドレスを指定します。
	 */
	CCodeBlock(std::string label, UI32 addr);
	
		
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CCodeBlock();


	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs);


	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 PrintLink(std::ostream& ofs);


	/**
	 *	@brief  このブロックに命令を追加します。
	 *  @param  pIns  オペコードオブジェクト
	 */
	virtual void AddOpeCode(IInstruction* pIns);

	
	/**
	 *	@brief  このブロックに命令を追加します。
	 *  @param  pIns  オペコードオブジェクト
	 *  @param  order 挿入位置
	 */
	virtual void AddOpeCode(IInstruction* pIns, UI32 order);


	/**
	 *	@brief  このブロックに命令を追加します。
	 *  @param  pIns  オペコードオブジェクト
	 *  @param  order 挿入位置
	 */
	virtual bool Insert(IInstruction* pIns, IInstruction* pos){
		auto i = std::find (m_vcode.begin(), m_vcode.end(), pos);
		if (i != m_vcode.end()) {
			m_vcode.insert(i, pIns);
			return true;
		}
		return false;
	}
		
	
	/**
	 *	@brief  このブロックを配置するアドレスを設定します。
	 *  @param  adr  配置アドレス
	 */
	void SetAddress(UI32 adr) {
		m_borg	  = true;
		m_address = adr & 0xFFFFFFFE;
	}
	
	/**
	 *	@brief  このブロックを配置するアドレスを取得します。
	 *  @return 配置アドレス
	 */
	UI32 GetAddress(void) const {
		return m_address;
	}

	/**
	 * @brief Specify the address was specified by user.
	 * @return None
	 */
	void SetUserAddress(bool bUserAddress) {
		m_bUserAddress = bUserAddress;
	}

	/**
	 * @brief Check whether the address was specified by user.
	 * @return bool type, TRUE: specified by user, FALSLE: using auto allocation
	 */
	bool IsUserAddress(void) {
		return m_bUserAddress;
	}

	/**
	 *	@brief  このブロックを配置するアドレスを設定します。
	 *  @param  adr  配置アドレス
	 */
	void SetAlign(UI32 align) {
		m_align = align;
	}	

	/**
	 *	@brief  このブロックを配置するアドレスを設定します。
	 *  @param  adr  配置アドレス
	 */
	UI32 GetAlign() {
		return m_align;
	}

	/**
	 *	@brief  配置アドレスが指定されているかどうかを取得します。
	 *          ベクタなどの配置が自明な場合に使用します。
	 *  @return 指定されている場合、真を返します。
	 */
	bool IsLocationCount(void) const {
		return m_borg;
	}

	/**
	 *	@brief  再配置するため配置済フラグをクリアします。
	 *          再配置不許可（アドレスが固定）のブロックは仮想関数で空実装してください。
	 */
	virtual bool FreeAlloc (void) {
		return (m_borg = false);
	}

	/**
	 *	@brief  このブロックのコードサイズを取得します。
	 *  @return コードサイズ(バイト）
	 */
	UI32 GetCodeSize(void) {
		return m_codesize;
	}
	
	/**
	*	@brief  Calculate code size of code block
	*   @return code size
	*/
	UI32 CalculateCodeSize() {

		if (m_label == "_syscall_init" || m_label.find("_interrupt_eitbl_init") != std::string::npos)
			return m_codesize;

		std::vector<IInstruction*>::iterator itr;
		m_codesize = 0;

		for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
			m_codesize += (*itr)->GetLen();
		}
		return m_codesize;
	}

	/**
	*	@brief  set size for code block
	*/
	void SetSize(UI32 size) {
		m_codesize = size;
	}

	/**
	 *	@brief  このブロックに付加するラベル名を設定します。
	 *  @param  name  ラベル名
	 */
	void SetLabel(std::string& name) {
		m_label = name;
	}

	/**
	 *	@brief  このブロックに付加するラベル名を設定します。
	 *  @param  name  ラベル名
	 */
	void SetLabel(std::string&& name) {
		m_label = name;
	}	
	
	/**
	 *	@brief  このブロックに付加するラベル名を設定します。
	 *  @param  name  ラベル名
	 */
	void SetLabel(LPCTSTR name) {
		std::string l(name);
		SetLabel(l);
	}
	
	/**
	 *	@brief  このブロックに付加するラベル名を取得します。
	 *  @return ラベル名
	 */
	std::string& GetLabel(void) {
		return m_label;
	}	

	/**
	 * @brief  ノード名を取得する
	 * @return ノード名を返す。
	 */
	virtual std::string GetName() {return std::string(m_label);}
	
	/**
	 *	@brief  このブロックに付加するラベル名を設定します。
	 *  @param  pIns  オペコードオブジェクト
	 *  @return 何番目に位置するかを返します。
	 */
	UI32 GetIndex(IInstruction* pIns) throw (std::runtime_error);
	
	
	/**
	 *	@brief  このブロックの命令数を取得します。
	 *  @return 登録された命令数
	 */
	UI32 GetInstructionNum(void) const {
		return m_vcode.size();
	}
	
	
	/**
	 *	@brief  インデックスからこのブロックの命令を取得します。
	 *  @param  n ブロック内の命令インデックス
	 *  @return 命令への参照
	 */
	IInstruction* at(int n) {
        if ((n > (int)m_vcode.size()) || n < 0) throw std::out_of_range("vector::out of range");
        return m_vcode[n];
    }
	
	
	/**
	 *	@brief  ブロック内の命令を交互にMIXします。
	 *          <注>パラメータbで与えられたブロック内の命令列はクリアされます。
	 *  @param  b マージするブロック
	 *  @return 命令への参照
	 */
	void Interlace(CCodeBlock* b);


	/**
	 *	@brief  指定されたブロック分割します。
	 *  @param  i  分割位置（命令数で指定）
	 *  @return 分割後の後半ブロック
	 */
	CCodeBlock* Split(UI32 i);


	/**
	 *	@brief  指定されたブロックを結合します。
	 *          <注>パラメータbで与えられたブロック内の命令列はクリアされます。
	 *  @param  b マージするブロック
	 *  @return 命令への参照
	 */
	void Append(CCodeBlock* b);


	/**
	 *	@brief  指定された命令を置換します。
	 *  @param  before 置換前命令
	 *  @param  after  置換後命令
	 *  @return 置換前命令（不要ならdeleteしてください）
	 */
	virtual IInstruction* Replace(IInstruction* before, IInstruction* after) {
		auto itr = std::find (m_vcode.begin(), m_vcode.end(), before);
		if (itr == m_vcode.end()) {
			return after;
		}
		IInstruction* old = *itr;
		itr = m_vcode.erase(itr);
		m_vcode.insert(itr, after);
		return old;
	}

	/**
	 *	@brief  指定された命令を置換します。
	 *  @param  before 置換前命令
	 *  @param  after  置換後命令
	 *  @return 置換前命令（不要ならdeleteしてください）
	 */
	virtual bool Remove(IInstruction* p) {
		auto itr = std::find (m_vcode.begin(), m_vcode.end(), p);
		if (itr == m_vcode.end()) {
			return false;
		}
		delete *itr;
		m_vcode.erase(itr);
		return true;
	}	

	bool Erase(IInstruction *p) {
		auto itr = std::find (m_vcode.begin(), m_vcode.end(), p);
		if (itr == m_vcode.end()) {
			return false;
		}
		m_vcode.erase(itr);
		return true;
	}

	/**
	 *	@brief  このブロック内の指定アドレスから命令を取得します。
	 *  @param  addr フェッチアドレス
	 *  @return ブロック外のアドレスが指定された場合、NULLを返します。
	 */
	IInstruction* Fetch(UI32 addr);

	/**
	 *	@brief  このブロック内の命令順をローテーションします。
	 *  @param  n  ローテート数
	 */
	void Rotate(UI32 n) {
		if (n < m_vcode.size()) {
			std::rotate(m_vcode.begin(), m_vcode.begin() + n, m_vcode.end());
		}
	}

	/**
	 *	@brief  ブロックの情報をリフレッシュします。
	 *          登録された命令をアセンブルし、ブロックサイズを更新します。
	 */
	virtual void Update();


	/**
	 *	@brief  ブロック内の命令補正可否を設定します。
	 *  @param  flag 真の場合、補正を許可します
	 */
	void EnableRegulation(bool flag) { m_bmod = flag; }


	/**
	 *	@brief  ブロックが補正可能であるか取得します。
	 *  @return 真の場合、補正可能であることを意味します。
	 */
	bool IsRegulation() { return m_bmod; }
	

	/**
	 *	@brief  ブロックの配置マージンを取得します
	 *  @return 最後の命令からとられるマージン
	 */
	virtual UI32 GetBlockGap() {

		if (m_blockGap > 0){
			if ((SI32)(m_blockGap - m_codesize) < 0) 
				MSG_WARN(0, "Overload expected size: codesize=%d - blockgap=%d \n", m_codesize, m_blockGap);
			return (m_blockGap - m_codesize);
		} else {
			m_blockGap = 2 * m_codesize;
			if (m_codesize < 0x28){
				m_blockGap += 0x20; // 0x20: Gap for block that code size small than additional NOP for fetch
				return (m_codesize + 0x20);
			}
			return m_codesize;
		}
	}

    virtual void SetBlockGap(UI32 value) { m_blockGap = value; };
	/**
	 *	@brief 補正命令について、レジスタ干渉しない限りにおいて前倒しにリオーダーする。
	 */
	virtual void FrontLoadRegulation();
	

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	virtual void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler,
		std::vector<INode*> *m_vPreload, std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,
		std::vector<INode*> *m_vBody, std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vBody->push_back(nullptr);
	}

	/**
	 * @brief  各ブロックに存在するデータテーブルブロックを収集します。
	 */
	virtual CCodeBlock* GetConstTable(){
		return nullptr;
	}

	/**
	 * 
	 */
	virtual bool IsEnableSnapShot() { return false; }
	virtual CSimResource* GetSnapShot() { return nullptr; }
	virtual void SetSnapShot(CSimResource* res){ delete res;}

	/**
	 * 
	 */
	std::map<IInstruction*, UI32>* GetOffsetMap(){
		Update();
		const UI32 MOV32_LENGHT = 4;
		const UI32 LDVQW_LENGHT = 6;
		auto mp = new std::map<IInstruction*, UI32>();
		UI32 N = m_vcode.size();
		UI32 P = 0;
		for (UI32 i = 0; i < N; i++) {
			mp->insert(std::pair<IInstruction*, UI32>(m_vcode.at(i), P));
			if (m_vcode.at(i)->Category(IInstruction::IF_INS_CAT2)){
			//--- Caculate adjust code lenght for WR----//
				P += m_vcode.at(i)->GetLen();
				for (UI32 x = 0; x <  m_vcode.at(i)->GetOpNum(); x++) {
					IOperand* popr =  m_vcode.at(i)->opr(x);
					if (popr->IsWR() && (popr->GetConstraint()!=NULL)) {
						P += MOV32_LENGHT;
						P += LDVQW_LENGHT;
					}
				}				
			} else {		
				P += m_vcode.at(i)->GetLen();
			}
			if(m_vcode.at(i)->GetForwardLD())
				P +=14; // Length of regulation code will be added in simulation phase

			if(m_vcode.at(i)->GetForward() && (!m_vcode.at(i)->GetForwardLD()))
				P +=8; // Length of regulation code will be added in simulation phase
			if(m_vcode.at(i)->GetMne() == "fetrap" || m_vcode.at(i)->GetMne() == "trap" || m_vcode.at(i)->GetMne() == "syscall")
				P +=20; //Add length of backup resource instruction
		}
		return mp;
	}
	
	std::vector<UI32>& GetNativeDataArray() {return m_vndat;}

	

	/**
	 *	@brief  [デバッグ用] このブロックに含まれる命令とアドレスを指定ストリームに出力します。
	 *  @param  os 出力先ストリーム
	 */
	void Dump(std::ostream& os = std::cout);
	

	/**
	 *	@brief  このブロックを配置するアドレスを設定します。
	 *  @param  adr  配置アドレス
	 */
	void SetStatistics(bool sw) {
		m_bStatistics = sw;
	}	
	
	virtual UI32 GetHandlerType() {
		return 0;
	}

	virtual UI32 GetHandlerLevel() {
		return 0;
	}
	/**
	 *	@brief  このブロックを配置するアドレスを設定します。
	 *  @param  adr  配置アドレス
	 */
	bool GetStatistics() {
		return m_bStatistics;
	}	
#if 0
	/**
	 * @brief このブロックに対するブレーク設定のパラメータの有無を返す。
	 */
	bool HasBreakSetup() {
		return false;
	}
#endif	
	/**
	 * @ brief ブレークポイント設定用DBTRAP命令挿入フラグセット
	 */
	void SetBreakSetupInsFlag(bool flag = true) {
		m_bBreakSetupInsFlag = flag;
	}

	/**
	 * @brief ブレークポイント設定用DBTRAP命令挿入フラグを返す
	 */
	bool GetBreakSetupInsFlag() {
		return m_bBreakSetupInsFlag;
	}

	/**
	 * @ brief specify block start blocknum_00
	 */
	void SetMainBlock(bool flag = true) {
		m_bMainBlock = flag;
	}

	/**
	 * @ brief get block start blocknum_00
	 */
	bool IsMainBlock() {
		return m_bMainBlock;
	}

	virtual bool FinishUpdating(){
		return true;
	}

	virtual void SetUpdating(bool flag) {}

	/**
	 * @ brief specify block end blocknum_00
	 */
	void SetTailBlock(bool flag = true) {
		m_bTailBlock = flag;
	}

	/**
	 * @ brief specify block end blocknum_00
	 */
	bool IsTailBlock() {
		return m_bTailBlock;
	}

	/**
	 * @brief Set breakpoint was setup
	 * flag	bool (true: done (default); false: Not yet)
	 */
	void SetBreakSetupDone(bool flag = true) {
		m_bBreakSetDone = flag;
	}

	/**
	 * @brief Check whether breakpoint was setup
	 */
	bool GetBreakSetupDone() {
		return m_bBreakSetDone;
	}


	/*
	 * @brief 
	 */
	void SetRandomBlock (bool flag) {
		m_bRandomBlock = flag;
	}

	bool IsRandomBlock (void) {
		return m_bRandomBlock;
	}

	/*
	 * @brief 
	 */
	virtual void SetAllocated (bool flag) {
		m_bIsAllocated = flag;
	}

	virtual bool IsAllocated (void) {
		return m_bIsAllocated;
	}

	/*
	 * @brief 
	 */
	void SetNextRandomBlock (CCodeBlock* pCB) {
		m_NextBlock = pCB;
	}

	CCodeBlock* GetNextRandomBlock (void) {
		return m_NextBlock;
	}

	virtual void SetEntry (IInstruction *pIns) {};

	virtual UI32 GetHandlerAddress() {return 0;};
	virtual void SetHandlerAddress(UI32 addr) {};

	virtual UI32 GetExceptionLevel() {return 0;}

	/*
	 * @Support the instructions that can't be compile by current GNU
	 */
	virtual void AdjustNotSupportedIns();

public:
    bool                            m_bRLB;     //!< @brief リレーブレーク設定要否フラグ
    
protected:
	bool							m_borg;		//!< @brief 配置アドレス指定フラグ（真の場合、.org指定される）
	bool							m_bmod;		//!< @brief 補正対象ブロック
	bool							m_bUserAddress; // !<@brief Address was specified by user, not need to allocate
	UI32							m_address;	//!< @brief 配置アドレス（m_borgが真の場合有効）
	UI32							m_align;	//!< @brief 配置アライン
	UI32							m_codesize;	//!< @brief コードブロックのサイズ
	std::string						m_label;	//!< @brief コードブロックに付加するラベル名
	std::vector<IInstruction*>		m_vcode;	//!< @brief コードブロック内の命令列
	std::map<UI32,IInstruction*>	m_lhash;	//!< @brief アドレスと命令の関係を保持する(PC,pINS)
	std::vector<UI32>				m_vndat;	//!< @brief コードブロック内のネイティブデータ(PC)
	bool							m_bStatistics;  //!< @brief コード生成カバレッジ蓄積対象
	bool                            m_bBreakSetupInsFlag; //!< @brief ブレークポイント設定用DBTRAP命令挿入フラグ
	bool							m_bBreakSetDone; // !< @brief Break generation was done flag
	bool							m_bRandomBlock;	 // !< @brief Checking wheter random codeblock.
	bool							m_bIsAllocated;  // !< @brief Checking wheter codeblock is allocated in m_hash.
	CCodeBlock*						m_NextBlock;
	std::vector<IBreakParam*>       m_vbreak;   //!< @brief ブレーク設定パラメータ
	bool							m_bMainBlock;
	bool							m_bTailBlock;
	UI32							m_blockGap;
};


/**
 *	@brief  ベクタテーブルを管理するクラスです。
 */
class CVectorBlock : public virtual CCodeBlock {
public:
	typedef enum {
		EXP_LEVEL_NONE = 0,
		EXP_LEVEL_FE,
		EXP_LEVEL_EI,
		EXP_LEVEL_DB,
		EXP_LEVEL_NUM
	}  EXP_LEVEL;

	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CVectorBlock() : m_gap(0) {
		m_align = 0x10;
		m_gap = 0;
		m_bUpdated = false;
		m_nHandlerType = 0;
		m_ExceptionLevel = 0;
	}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CVectorBlock(std::string label)
    : CCodeBlock(label), m_gap(0), m_strHandler(""), m_nHandlerType(0), m_bIsSys(false), m_nHandlerAddress(0), m_bUpdated(false), m_ExceptionLevel(0) {
		m_align = 0x10;
	}


	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 *  @param  addr  配置アドレス
	 */
	CVectorBlock(std::string label, UI32 addr, bool isSys=false) 
    : CCodeBlock(label, addr), m_gap(0), m_strHandler(""), m_nHandlerType(0), m_bIsSys(false), m_nHandlerAddress(addr), m_bUpdated(false), m_ExceptionLevel(0) {
		m_align = 0x10;
        m_bIsSys = isSys;
	}

	/**
	 * @brief  ノード・アセンブラコード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs);

	void SetHandlerAddress(UI32 addr) {m_nHandlerAddress = addr;}

	virtual UI32 GetHandlerAddress() {return m_nHandlerAddress;};
	/**
	 * @brief  ノード・セクション定義出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 最終アドレスを返す。
	 */
	virtual UI32 PrintLink(std::ostream& ofs);

	/**
	 * @brief  そのベクターが使われない見込みでかつ使われる場合とは異なるハンドラルーチンを実行させたいある場合に、そのラベル名を設定する
	 * @param  ハンドラルーチンのラベル名
	 * @param  例外レベル
	 */
	virtual void SetHandlerType(UI32 type, UI32 level) {
		m_nHandlerType = type;
		m_ExceptionLevel = level;
	}

	virtual UI32 GetHandlerType() {
		return m_nHandlerType;
	}

	virtual UI32 GetHandlerLevel() {
		return m_ExceptionLevel;
	}

	/**
	 *	@brief  再配置するため配置済フラグをクリアします。
	 *          再配置不許可（アドレスが固定）のブロックは仮想関数で空実装してください。
	 */
	virtual bool FreeAlloc (void) {return IsLocationCount();}
	
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CVectorBlock(){}

	bool FinishUpdating(){
		return m_bUpdated;
	}

	void SetUpdating(bool flag){
		m_bUpdated = flag;
	}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	 void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler,	std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync, std::vector<INode*> *m_vBody, 
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vVector->push_back(nullptr);
	}

protected:
	UI32	m_gap;
	std::string m_strHandler;		//!< @brief		ハンドラルーチンのラベル名
    UI32	m_nHandlerType;         //!< @brief	store exception type and occurrence	[Exception Type] 0:Other, 1:Re-execute type
    bool    m_bIsSys;
	UI32    m_nHandlerAddress;
	bool	m_bUpdated;
	std::map<UI32, UI32>    m_returnTypeSet = {{1, (UI32)0}, {2, (UI32)0}, {3, (UI32)0}, {4, (UI32)0}};
	UI32 m_ExceptionLevel; //!< @brief	store exception level EXP_LEVEL_FE = 0,	EXP_LEVEL_EI = 1, EXP_LEVEL_DB = 2
};


/**
 *	@brief  ベクタテーブルを管理するクラスです。
 */
class CBootBlock : public CVectorBlock {
public:

	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CBootBlock() : CVectorBlock(){}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CBootBlock(std::string label) : CVectorBlock(label) {}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 *  @param  addr  配置アドレス
	 */
	CBootBlock(std::string label, UI32 addr) : CVectorBlock(label, addr) {}

	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs) {
		ofs << ".ifndef FROG_MANYCORE_GEN" << std::endl;
	    ofs << "    .global      " << CLabel::m_prefix << m_label << std::endl;
		UI32 ret = CCodeBlock::Print(ofs);
		ofs << ".endif" << std::endl;
		ofs << std::endl;
		return ret;
	}

	/**
	 *	@brief  再配置するため配置済フラグをクリアします。
	 *          再配置不許可（アドレスが固定）のブロックは仮想関数で空実装してください。
	 */
	virtual bool FreeAlloc (void) {return IsLocationCount();}

	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CBootBlock(){}
};


/**
 *	@brief  初期化を管理するクラスです。
 */
class CPreloadBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CPreloadBlock() : m_vEntry(){}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CPreloadBlock(std::string label) : CCodeBlock(label), m_nHandlerAddress(0), m_vEntry(), m_nExceptionLevel(0){};
	
	virtual void SetEntry (IInstruction *pIns) {
		m_vEntry.push_back(pIns);
	}

	virtual void Update();

	virtual UI32 GetBlockGap() override {
		return (UI32)8;  // 8 is the number of byte which PC fetch
	}

	virtual bool Remove(IInstruction* p);

	virtual IInstruction* Replace(IInstruction* before, IInstruction* after);

	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CPreloadBlock(){}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vPreload->push_back(nullptr);
	}

	void SetExceptionLevel(UI32 level) {m_nExceptionLevel = level;}
	virtual UI32 GetExceptionLevel() {return m_nExceptionLevel;}

	virtual UI32 GetHandlerAddress() {return m_nHandlerAddress;};
	virtual void SetHandlerAddress(UI32 addr) {m_nHandlerAddress = addr;};

	UI32								m_nHandlerAddress;
protected:
	std::vector<IInstruction*>			m_vEntry;
	UI32								m_nExceptionLevel;
};


/**
 *	@brief  ハンドラ処理を管理するクラスです。
 */
class CHandlerBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CHandlerBlock(): m_nHandlerAddress(0), m_nExceptionLevel(0), m_bRecovered(false){
		SetOutputFlag(true);
	}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CHandlerBlock(std::string label) : CCodeBlock(label), m_nHandlerAddress(0), m_nExceptionLevel(0), m_bRecovered(false){};

	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CHandlerBlock(){}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vHandler->push_back(nullptr);
	}

	void SetHandlerAddress(UI32 addr) {m_nHandlerAddress = addr;}
	virtual UI32 GetHandlerAddress() {return m_nHandlerAddress;};
	void SetExceptionLevel(UI32 level) {m_nExceptionLevel = level;}
	virtual UI32 GetExceptionLevel() {return m_nExceptionLevel;}

	UI32						m_nHandlerAddress;
	UI32						m_nExceptionLevel;
	bool						m_bRecovered;
};

/**
 *  @brief  ブレークポイント設定処理を管理するクラスです。
 */
class CBreakSetupBlock : public virtual CCodeBlock {
 public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CBreakSetupBlock() {
		SetOutputFlag(true);
	}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CBreakSetupBlock(std::string label) : CCodeBlock(label){};

	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CBreakSetupBlock(){}
};

/**
 *	@brief  セットアップを管理するクラスです。
 */
class CPrologueBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CPrologueBlock(){}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CPrologueBlock(std::string label) : CCodeBlock(label){};
	
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CPrologueBlock(){}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vPrologue->push_back(nullptr);
	}

};



/**
 *	@brief  ランダム開始前に同期をとるクラスです。
 */
class CSyncBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CSyncBlock(){}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CSyncBlock(std::string label) : CCodeBlock(label){};
	
	/**
	 *	@brief  ブロックの配置マージンを取得します
	 *  @return 最後の命令からとられるマージン
	 */
	virtual UI32 GetBlockGap() {
		return 0x0200;
	}

	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CSyncBlock(){}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody, 
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vSync->push_back(nullptr);
	}
};

/**
 *	@brief  ランダム開始前に同期をとるクラスです。
 */
class CTeSyncBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CTeSyncBlock(){}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CTeSyncBlock(std::string label) : CCodeBlock(label){};
	
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CTeSyncBlock(){}

};

/**
 *	@brief  終了前処理を管理するクラスです。
 */
class CEpilogueBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CEpilogueBlock() {
		SetOutputFlag(true);			// 必ず出力する
		EnableRegulation(false);		// 補正制御はしない
	}

	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CEpilogueBlock() {
		delete m_pRes;
	}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	explicit CEpilogueBlock(std::string label) : CCodeBlock(label), m_bShapshot(false), m_pRes(nullptr){
		SetOutputFlag(true);			// 必ず出力する
		EnableRegulation(false);		// 補正制御はしない
          // ToBeFixed[R205]:ここでやるべきだがこの版では乱数系一致の為後でやる
	}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	explicit CEpilogueBlock(std::string label, bool snapshot) : CCodeBlock(label), m_bShapshot(snapshot), m_pRes(nullptr){
		SetOutputFlag(true);			// 必ず出力する
		EnableRegulation(false);		// 補正制御はしない
		// ToBeFixed[R205]:ここでやるべきだがこの版では乱数系一致の為後でやる
	}

	/**
	 *	@brief  ブロックの配置マージンを取得します
	 *  @return 最後の命令からとられるマージン
	 */
	virtual UI32 GetBlockGap() {
		if (m_bShapshot) {
			return (1024 * 16);
		}else{
			return 0x010;
		}
	}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vEpilogue->push_back(nullptr);
	}

	virtual bool IsEnableSnapShot() { return m_bShapshot; }
	virtual CSimResource* GetSnapShot() { return m_pRes; }
	virtual void SetSnapShot(CSimResource* res){ delete m_pRes; m_pRes = res;}
		
protected:
	bool m_bShapshot;
	CSimResource* m_pRes;
};


/**
 *	@brief  ベクタテーブルを管理するクラスです。
 */
class CFunctionBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
    CFunctionBlock() {}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CFunctionBlock(std::string label) : CCodeBlock(label), m_nHandlerAddress(0) {};
			
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CFunctionBlock(){}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vFunction->push_back(nullptr);
	}

	virtual UI32 GetHandlerAddress() {return m_nHandlerAddress;};
	virtual void SetHandlerAddress(UI32 addr) {m_nHandlerAddress = addr;};

	UI32	m_nHandlerAddress;
};

/**
 *	@brief  ベクタテーブルを管理するクラスです。
 */
class CUserBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CUserBlock() {}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CUserBlock(std::string label) : CCodeBlock(label) {};

	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs);
	
	/**
	 *	@brief  ブロックの配置マージンを取得します
	 *  @return 最後の命令からとられるマージン
	 */
	virtual UI32 GetBlockGap() {
		UI32 blockSize = CCodeBlock::GetBlockGap();
		return blockSize + 0x200;
	}
	
    void SetKeyName(LPCTSTR context_key , LPCTSTR user_key ) {
        m_context_key = context_key ;
        m_user_key    = user_key ;
    }

		
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CUserBlock(){}

protected:	
	std::string	m_context_key;
	std::string	m_user_key;
};


/**
 *	@brief  終了処理を管理するクラスです。
 */
class CTerminateBlock : public virtual CCodeBlock {
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CTerminateBlock(): m_nHandlerAddress(0), m_nExceptionLevel(0), m_bRecovered(false) {}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CTerminateBlock(std::string label) : CCodeBlock(label), m_nHandlerAddress(0), m_nExceptionLevel(0), m_bRecovered(false){};
			
	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CTerminateBlock(){}

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload,
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vTerminate->push_back(nullptr);
	}

	void SetHandlerAddress(UI32 addr) {m_nHandlerAddress = addr;}
	virtual UI32 GetHandlerAddress() {return m_nHandlerAddress;};
	void SetExceptionLevel(UI32 level) {m_nExceptionLevel = level;}
	virtual UI32 GetExceptionLevel() {return m_nExceptionLevel;}

	UI32						m_nHandlerAddress;
	UI32						m_nExceptionLevel;
	bool						m_bRecovered;
};



/**
 *	@brief  テーブルデータを管理するクラスです。
 */
class CConstDataBlock :
	public virtual CVectorBlock, 
	public virtual CPreloadBlock, 
	public virtual CPrologueBlock, 
	public virtual CEpilogueBlock, 
	public virtual CFunctionBlock, 
	public virtual CTerminateBlock
{
public:
	/**
	 *	@brief  このオブジェクトを生成します。
	 */
	CConstDataBlock() {
		SetOutputFlag(true);			// 必ず出力する
		EnableRegulation(false);		// 補正制御はしない
	}

	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 */
	CConstDataBlock(std::string label) : CCodeBlock(label){};


	/**
	 *	@brief  このオブジェクトを生成します。
	 *  @param  label ラベル文字列を指定します
	 *  @param  addr  配置アドレスを指定します
	 */
	CConstDataBlock(std::string label, UI32 addr) : CCodeBlock(label, addr){};


	/**
	 *	@brief  このオブジェクトを破棄します。
	 */
	virtual ~CConstDataBlock(){}

	/**
	 *	@brief  ブロックの配置マージンを取得します
	 *  @return 最後の命令からとられるマージン
	 */
	virtual UI32 GetBlockGap() {
		return 0;
	}

	virtual UI32 GetHandlerAddress() {return 1;};

	virtual void SetHandlerAddress(UI32 addr) {};

	/**
	 * @brief  コードブロックを追加します
	 *         (注)インターフェースINodeで受けない
	 */
	void AddNodeS(std::vector<INode*> *m_vVector, std::vector<INode*> *m_vHandler, std::vector<INode*> *m_vPreload, 
		std::vector<INode*> *m_vPrologue, std::vector<INode*> *m_vSync,	std::vector<INode*> *m_vBody,
		std::vector<INode*> *m_vFunction, std::vector<INode*> *m_vEpilogue, std::vector<INode*> *m_vTerminate) {
			m_vVector->push_back(nullptr);
	}

	/**
	 * @brief  各ブロックに存在するデータテーブルブロックを収集します。
	 */
	CCodeBlock* GetConstTable(){
		return this;
	}

	virtual UI32 GetExceptionLevel() {return 0;}

	/**
	 * @brief  ノード出力インターフェース
	 * @param  ofs  出力ストリームオブジェクト
	 * @return 出力行数を返す。
	 */
	virtual UI32 Print(std::ostream& ofs) {
		UI32 num = GetInstructionNum();
	
		if (m_borg) {
			ofs << std::endl; 
			ofs << ".org " << "0x" << std::hex << m_address << std::endl;
		}
	
		if (m_label.length()) {
			if (!m_borg) {
				ofs << std::endl;
			}
			ofs << CLabel::m_prefix << m_label << ':' << std::endl;
		}

		UI32 i4 = 0;
		UI32 i2 = 0;
		UI32 i	= 0;
		std::string comment;
		
		for (i = 0; i < num; i++) {
			UI32 len = at(i)->GetLen();
			
			if (len == 4 && i4 == 0) {
				ofs << "    ";
				ofs << std::setw(17) << std::left << std::setfill(' ') << (at(i)->GetMne());
			}
			if (len == 2 && i2 == 0) {
				ofs << "    ";
				ofs << std::setw(17) << std::left << std::setfill(' ') << (at(i)->GetMne());
			}

			UI32 val = (UI32)(*(at(i)->opr(0)));
			char buff[32];
			sprintf(buff, "0x%08X",val);
			ofs << buff;
			// TODO: 原因不明
			//ofs << "0x" << std::hex << std::setw(8) << std::setfill('0') << val << std::flush; //(UI32)(*(at(i)->opr(0)));
			comment += at(i)->GetComment();
			
			if (len == 4) {
				i4++;
				i2 = 0;
				if (i4 >= 4) {
					ofs << " -- " << comment;
					ofs << std::endl;
					comment = "";
					i4 = 0;
				}else{
					if (i < num-1){
						ofs << ",  ";
					}else{
						ofs << " -- " << comment;
						comment = "";
					}
				}
			}
			if (len == 2) {
				i4 = 0;
				i2++;
				if (i2 >= 4) {
					ofs << " -- " << comment;
					ofs << std::endl;
					comment = "";
					i2 = 0;
				}else{
					if (i < num-1){
						ofs << ",  ";
					}else{
						ofs << " -- " << comment;
						comment = "";
					}
				}
			}
		}
		ofs << std::endl;
		return i;
	}
};

#endif /*CODEBLOCK_H_*/
