#ifndef IFBLK_MANAGER_H_
#define IFBLK_MANAGER_H_

#include	<iostream>
#include	"ifinsset.h"
#include	"ifsysreg.h"
#include	"codeblock.h"
#include	"ifinsset.h"
#include    "cpu_e3v5/mxu_parser.h"

typedef		std::map<std::string,CWeightList*>	LIST_INSSET;


/**
 * @brief コードブロックの生成条件をもつパラメータクラス。
 */
struct TBlockConfig {
public:
	TBlockConfig() : 
		N(0), InsNum(0), pInsSet(NULL), m_pSrSet(NULL),
		m_bSys(false), m_bNC(true), m_bBase(false), m_VCID(0), m_HTID(0), m_ucfile(),  m_bGM(false), m_GMID(0)
	{}
	~TBlockConfig(){}
	
	// アーキテクチャに合わせて必要なフィールドを追加してよい
	UI32				N;			//<! @brief ブロックインデックス番号
	UI32				InsNum;		//<! @brief ブロック内の命令数
	
	// 破棄予定-> ここから
	std::map<std::string,CWeightList*>* pInsSet;	//<! @brief 命令セットのリスト 
	ISysRegSet*			m_pSrSet;		//<! @brief SR制御
	// 破棄予定-> ここまで
	
	//------------------------------
	bool				m_bSys;		//<! @brief 生成するブロックが実行されるスレッド番号
	bool				m_bNC;		//<! @brief 生成するブロックがNativeContextのコードであるとき真
	bool				m_bBase;	//<! @brief 生成するブロックがベースコンテキストであるとき真
	UI32				m_VCID;		//<! @brief 生成するブロックが実行されるVM番号
	UI32				m_HTID;		//<! @brief 生成するブロックが実行されるスレッド番号
	std::string			m_ucfile;
    bool                m_bGM;      //<! @brief True if the generated block is a guest mode code
    UI32				m_GMID;		//<! GM number of the block to be generated
};


/**
 * @brief コードブロックの生成と処理を抽象化するインターフェースクラスです。
 */
class IBlockManager
{
public:
	//! ベクタアドレス列挙子(Architecture)
	enum ADDR_INTVECTOR {
		ADR_VECTOR_RESET	= 0x00,		//!< @brief Resetベクタアドレス
		ADR_VECTOR_SYSERR	= 0x10,		//!< @brief SysErrorベクタアドレス
		ADR_VECTOR_HVTRAP	= 0x20,		//!< @brief HV Trapベクタアドレス
		ADR_VECTOR_FETRAP	= 0x30,		//!< @brief FE Trapベクタアドレス
		ADR_VECTOR_TRAP0	= 0x40,		//!< @brief Trap0ベクタアドレス
		ADR_VECTOR_TRAP1	= 0x50,		//!< @brief Trap1ベクタアドレス
		ADR_VECTOR_RIE		= 0x60,		//!< @brief 予約命令例外ベクタアドレス
		ADR_VECTOR_FPPFPI	= 0x70,		//!< @brief 浮動小数点命令例外ベクタアドレス
		ADR_VECTOR_UCPOP	= 0x80,		//!< @brief コプロ使用権例外ベクタアドレス
		ADR_VECTOR_MPUMMU	= 0x90,		//!< @brief メモリアクセス例外ベクタアドレス
		ADR_VECTOR_PIE		= 0xA0,		//!< @brief 特権命令例外ベクタアドレス
		ADR_VECTOR_DEBUG	= 0xB0,		//!< @brief デバッグ例外ベクタアドレス
		ADR_VECTOR_MAE		= 0xC0,		//!< @brief ミスアラインアクセス例外ベクタアドレス
		ADR_VECTOR_BGINT	= 0xD0,		//!< @brief RFUベクタアドレス
		ADR_VECTOR_FENMI	= 0xE0,		//!< @brief FENMI例外ベクタアドレス
		ADR_VECTOR_FEINT	= 0xF0,		//!< @brief FEレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT000	= 0x100,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT001	= 0x110,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT002	= 0x120,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT003	= 0x130,	//!< @brief EIレベル割り込みベクタアドレス
		ADR_VECTOR_EIINT004	= 0x140,
		ADR_VECTOR_EIINT005	= 0x150,
		ADR_VECTOR_EIINT006	= 0x160,
		ADR_VECTOR_EIINT007	= 0x170,
		ADR_VECTOR_EIINT008	= 0x180,
		ADR_VECTOR_EIINT009	= 0x190,
		ADR_VECTOR_EIINT010	= 0x1a0,
		ADR_VECTOR_EIINT011	= 0x1b0,
		ADR_VECTOR_EIINT012	= 0x1c0,
		ADR_VECTOR_EIINT013	= 0x1d0,
		ADR_VECTOR_EIINT014	= 0x1e0,
		ADR_VECTOR_EIINT015	= 0x1f0,
		ADR_VECTOR_NUM		= 0x200,
		ADR_FUNCTION_001	= 0x210,
		ADR_FUNCTION_002	= 0x220,
		ADR_FUNCTION_003	= 0x230,
		ADR_FUNCTION_004	= 0x240,
		ADR_FUNCTION_005	= 0x250,
		ADR_FUNCTION_006	= 0x260,
		ADR_FUNCTION_007	= 0x270,
		ADR_FUNCTION_008	= 0x280,
		ADR_FUNCTION_009	= 0x290,
		ADR_FUNCTION_010	= 0x2A0,
		ADR_FUNCTION_011	= 0x2B0,
		ADR_FUNCTION_012	= 0x2C0,
		ADR_FUNCTION_013	= 0x2D0,
		ADR_FUNCTION_014	= 0x2E0,
		ADR_FUNCTION_015	= 0x2F0,
		ADR_FUNCTION_016	= 0x300,
		ADR_FUNCTION_017	= 0x310,
		ADR_FUNCTION_018	= 0x320,
		ADR_FUNCTION_019	= 0x330,
		ADR_FUNCTION_020	= 0x340,
		ADR_FUNCTION_021	= 0x350,
		ADR_FUNCTION_022	= 0x360,
		ADR_FUNCTION_023	= 0x370,
		ADR_FUNCTION_024	= 0x380,
		ADR_FUNCTION_025	= 0x390,
		ADR_FUNCTION_026	= 0x3A0,
		ADR_FUNCTION_027	= 0x3B0,
		ADR_FUNCTION_028	= 0x3C0,
		ADR_FUNCTION_029	= 0x3D0,
		ADR_FUNCTION_030	= 0x3E0,
		ADR_FUNCTION_031	= 0x3F0,
		ADR_FUNCTION_032    = 0x400,
		ADR_COMMON_CALLT	= 0x410,
		ADR_BLOCK_NUM		= 0x430,
	};
	/**
	 * @brief  このオブジェクトを構築します。
	 */	
	IBlockManager(){}
	
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual	~IBlockManager() {}


	/**
	 * @brief  ベクタブロックコードを生成します。
	 * @return ベクタブロックコード
	 */
	virtual std::vector<CVectorBlock*>* GenerateIntVector(TBlockConfig*) = 0;

	/* @brief  generate pe_check。
	 * @return Vector of vectorblock
	 */
	virtual std::vector<CVectorBlock*>* GeneratePECheck(TBlockConfig*) = 0;
	/**
	 * @brief  ベクタブロックコードを生成します。
	 * @return ベクタブロックコード
	 */
	virtual std::vector<CVectorBlock*>* GenerateVectorBlock(TBlockConfig*, std::string) = 0;

	/**
	* @brief	calltのテーブル＋命令列を生成する
	* @return	calltブロック（先頭にロードテーブル、その後にランダム命令が並ぶ）
	*/
	virtual CPreloadBlock* GenerateCalltBlock(TBlockConfig*, std::string label_num, UI32 blocksize = 0) = 0;

	/**
	 * @brief  ハンドラコードを生成します。
	 * @return ブロックコード
	 */
	virtual std::vector<CHandlerBlock*>* GenerateHandler(TBlockConfig*) = 0;

	/**
	 * @brief  プリロードコードを生成します。
	 * @return プリロードコード
	 */
	virtual std::vector<CPreloadBlock*>* GeneratePreload(TBlockConfig*) = 0;
	
		
	/**
	 * @brief  メモリ初期化コードを生成します。
	 * @param recode メモリ初期化情報
	 */
	virtual CPreloadBlock* AppendMemPresetBlock(std::vector<T_MEMWRRECORD > * recode) = 0;

	/**
	 * @brief This function append code block initializing sharing memory
	 * @param recode    Accessed memory record
	 * @return Code block
	 */
	virtual CPreloadBlock * AppendShareMemPreset(std::vector<T_MEMWRRECORD > * recode) = 0;
		
		
	/**
	 * @brief  プリフェッチコードを生成します。
	 * @param  pf_addr プリフェッチ開始アドレス
	 * @param  pf_size プリフェッチサイズ
	 */
	virtual void AppendPrefetchCode (std::string & context, CSyncBlock* pPF) = 0;
	virtual void AppendPrefetchData (UI32 pf_addr ,UI32 pf_size, CSyncBlock* pPF) = 0;
	
	virtual void FetchLineZeroing (std::vector<INode*>& rCb) = 0;


	/**
	 * @brief  プロローグコードを生成します。
	 * @return プロローグコード
	 */
	virtual std::vector<CPrologueBlock*>* GeneratePrologue(TBlockConfig*) = 0;
	

	/**
	 * @brief  同期ブロックコードを生成します。
	 * @return 同期ブロックコード
	 */
	virtual std::vector<CSyncBlock*>* GenerateSync(TBlockConfig*) = 0;
	
	/**
	 * @brief  create break setup block for break function
	 * @return preload block
	 */
	virtual std::vector<CPreloadBlock*>* GenerateSetupBlock(TBlockConfig* pCfg) = 0;
	/**
	 * @brief  ランダムタブロックコードを生成します。
	 * @param  pCfg 構成情報 
	 * @return ブロックコード
	 */
	virtual std::vector<CCodeBlock*> GenerateRandomBlock(TBlockConfig* pCfg)  = 0;
	/**
	* @brief	Break down current block into more smaller code block.
	* @param	- Input: Current code block.			
				- Output: vector of smaller code block.
	*/

	virtual std::vector<CCodeBlock*> BreakDownRandomBlock(TBlockConfig* pCfg, CCodeBlock* pCb) =0;

	/**
	 * @brief  同期ブロックコードを生成します。
	 * @return 同期ブロックコード
	 */
	virtual std::vector<CTeSyncBlock*>* GenerateTeSync(TBlockConfig*) = 0;
	
	/**
	 * @brief  replace pIns by random nomarl instruction
	 * @return instruction
	 */
	virtual IInstruction* ReplaceInsbyOther(CCodeBlock* pCb, IInstruction* curpIns, UI32 insLen) = 0;

	/**
	 * @brief  get register include target PC in vector handler, JMP return in Funtion, loop counter when inloop sequence
	 * @return setof register index
	 */
	virtual UI32 GetConstraintRegister(CCodeBlock* pCb, IInstruction* pIns) = 0;

	/**
	 * @brief  汎用レジスタを交差させるランダムタブロックコードを生成します。
	 * @param  N    ブロック番号
	 * @param  num  命令数
	 * @param  WeightSet 発生させる命令重みセット 
	 * @return ブロックコード
	 */
	//virtual CCodeBlock* GenerateGrInteraceBlock(UI32 N, UI32 num, std::map< std::string , CWeightList* > *  WeightSet= NULL) = 0;

	/**
	 * @brief  ファンクションコードを生成します。
	 * @return ファンクションコード
	 */
	virtual std::vector<CFunctionBlock*>* GenerateFunction(TBlockConfig*) = 0;
	
	/**
	 * @brief  エピローグコードを生成します。
	 * @return エピローグコード
	 */
	virtual std::vector<CEpilogueBlock*>* GenerateEpilogue(TBlockConfig*) = 0;

	/**
	 * @brief  期待値生成コードを生成します。
	 * @return ブロックコード
	 */
	virtual void GenVerifier(CCodeBlock* pEB, TBlockConfig* pCfg){};

	/**
	 * @brief  終了コードを生成します。
	 * @return ブロックコード
	 */
	virtual std::vector<CTerminateBlock*>* GenerateTerminateBlock(TBlockConfig*) = 0;
	
	/**
	 * @brief generate random user code block
	 * @return new user code 
	 */
	virtual CUserBlock* GenerateUserBlock(LPCTSTR context_key, TBlockConfig* pCfg, std::string labelStr) = 0;
	
	/**
	 * @brief  ランダムタブロックコードを生成します。
	 * @param  num  命令数
	 * @param  pset 発生させる命令セット 
	 * @return ブロックコード
	 */
	//virtual CCodeBlock* GenerateBlock(UI32 num, IInstructionSet* pset) = 0;
	
	/**
	 * @brief  コードブロックに例外をプリセットします(強制例外の設定)。
	 *         例外の発生要因はアーキテクチャに依存する。
	 * @param  pCb  例外を設定するコードブロック
	 * @param  pEx	発生させる例外とその確率 
	 */
	virtual void PresetException(CCodeBlock* pCb, IException* pEx) = 0;
	
	virtual std::vector<CUserBlock*>* InsertUserCode(LPCTSTR context_key , LPCTSTR user_key , TBlockConfig* pCfg, CCodeBlock* pCB) {return nullptr;}

	
	/**
	 * @brief  ブロック間を繋ぐ命令を追加します。
	 * @param  src 前処理ブロック。このブロックに後処理へつながる命令が追加される。
	 * @param  dst 後処理ブロック
	 * @return 後処理の参照
	 */
	virtual CCodeBlock* ChainBlock(CCodeBlock* src, CCodeBlock* dst) = 0;
	virtual CCodeBlock* MixBlock(CCodeBlock* src, CCodeBlock* dst) = 0;

	
	/**
	 * @brief 命令セットの重み情報へのポインタを取得。
	 */
	virtual IInstructionSet * GetWeightSet() = 0;

	virtual bool CU1isON(void) = 0;

	virtual UI32 GetHandlerWorkReg() = 0;

	virtual UI32 GetHandlerReg() = 0;

	/**
	*  @brief Get max channel of all interrupt
	*/
	virtual UI32 GetMaxChannelInterrupt(std::map<UI32, IExceptionConfig*> mExp) = 0;

    /**
    * @brief Get variable which save MPU information
    */
    virtual CMmList* GetMPUInfor() = 0;

    /**
    * @brief	Add Dead Code
    * @param	pCB	pointer to code block, pIns  pointer to instruction
    */
    virtual void AddDeadCode(CCodeBlock *pCB) = 0;


public:

	/**
	 * @brief  このオブジェクトを生成します。
	 * @return ブロックマネージャオブジェクト
	 */
	static IBlockManager* New(LIST_INSSET*  ws);
};

struct TWorkMemory {
	TWorkMemory() {
		SetCommonArea (0xfea00000);
		SetWorkArea (0xfea00400, 0xfea01400, 1, 1);
		SetRegisterBankMemory(0,0);
	}

	void SetCommonArea(UI32 ba) {
		BASE_COMMON			= ba;
	}
	void SetWorkArea(UI32 ba, UI32 ea, UI32 vmnum, UI32 htnum) {
		BASE_PE				= ba;
		BASE_WORK_END		= ea;
		m_vmnum				= vmnum;
		m_htnum				= htnum;
		ReCalc();
	}
	void SetMachine(UI32 vmnum, UI32 htnum) {
		m_vmnum				= vmnum;
		m_htnum				= htnum;
		ReCalc();
	}

	void ReCalc() {
		OFS_STACK_EI		= (OFS_SAVE_FE + SIZ_SAVE_FE);
		OFS_STACK_EI_ENTRY	= (OFS_STACK_EI + SIZ_STACK_EI);
		OFS_RANDAM_PTR		= (OFS_STACK_EI_ENTRY + SIZ_STACK_EI_ENTRY);
		OFS_ITLB_INFO		= (OFS_RANDAM_PTR + SIZ_RANDAM_PTR);

		BASE_PE_HT			= (BASE_PE + SIZE_PE_COMMON);
		SIZE_PE_HT			= (SIZE_HT * (m_htnum + 1));

		BASE_PE_VM			= (BASE_PE_HT  + SIZE_PE_HT);
		SIZE_PE_VM			= (SIZE_VM * (m_vmnum + 1));

		SIZE_PE				= (SIZE_PE_COMMON + SIZE_PE_HT + SIZE_PE_VM);

		BASE_WR_INIT		= (BASE_PE + SIZE_PE + 1024 + 48) & (~0xf); // [FROG]TODO: Reserve for exception handler

		BASE_WR_PRESET		= BASE_WR_INIT + 512;	// Wire register init range: 32*16 = 512 bytes
	}

	void SetRegisterBankMemory(UI32 start, UI32 end) {
		RBIP_START				= start;
		RBIP_END				= end;
	}
 
//HT
	UI32			m_vmnum;
	UI32			m_htnum;
	const	UI32	OFS_SAVE_FE			= 0;
	const	UI32	SIZ_SAVE_FE			= 0x080;
	UI32			OFS_STACK_EI;
	const	UI32	SIZ_STACK_EI		= 508;
	UI32			OFS_STACK_EI_ENTRY;
	const	UI32	SIZ_STACK_EI_ENTRY	= 4;
	UI32			OFS_RANDAM_PTR;
	const	UI32	SIZ_RANDAM_PTR		= 8;
	UI32			OFS_ITLB_INFO;
	const	UI32	SIZ_ITLB_INFO		= 4;
	const	UI32	SIZE_HT				= 1024; //= 8192;
//VM
	const	UI32	OFS_SAVE_DB			= 0;
	const	UI32	SIZ_SAVE_DB			= 0x080;
	const	UI32	SIZE_VM				= 1024; // = 4096;
//PE
	const	UI32	OFS_DTLB_INFO		= 0;
	const	UI32	SIZ_DTLB_INFO		= 64;
//----------------------------------------------------------------
	const UI32		SIZE_COMMON			= 1024;
	const UI32		SIZE_PE_COMMON		= 0;
	const UI32		SIZ_SYNCHRO_HT      = 16;

    const UI32		OFS_SYNCHRO_HT_COMPLETE  = 0;
    const UI32		SIZ_SYNCHRO_HT_COMPLETE  = 256;

    const UI32		OFS_SYNCHRO_HT_STANDBY  = OFS_SYNCHRO_HT_COMPLETE + SIZ_SYNCHRO_HT_COMPLETE ;
    const UI32		SIZ_SYNCHRO_HT_STANDBY  = 256;

    const UI32		OFS_SYNCHRO_PE_COMPLETE  = OFS_SYNCHRO_HT_STANDBY + SIZ_SYNCHRO_HT_STANDBY;
    const UI32		SIZ_SYNCHRO_PE_COMPLETE  = 16;

    const UI32		OFS_SYNCHRO_PE_STANDBY  = OFS_SYNCHRO_PE_COMPLETE + SIZ_SYNCHRO_PE_COMPLETE ;
    const UI32		SIZ_SYNCHRO_PE_STANDBY  = 16;

    const UI32		OFS_SYNCHRO_STANDBY  = OFS_SYNCHRO_PE_STANDBY + SIZ_SYNCHRO_PE_STANDBY ;
    const UI32		SIZ_SYNCHRO_STANDBY  = 1;

    const UI32		OFS_SYNCHRO_SKIP_PE_COMPLETE  = OFS_SYNCHRO_STANDBY + SIZ_SYNCHRO_STANDBY ;
    const UI32		SIZ_SYNCHRO_SKIP_PE_COMPLETE  = 1;

	UI32		BASE_COMMON;
	UI32 		BASE_PE; 	// PEが使用するアドレス先頭
	UI32		BASE_PE_HT;	// HTが使用する先頭サイズ
	UI32		SIZE_PE_HT; 	// HTが使用する全体サイズ
	UI32		BASE_PE_VM;	// VMが使用する先頭サイズ
	UI32		SIZE_PE_VM;	// VMが使用する全体サイズ 
	UI32		SIZE_PE;		// PEが使用する全体サイズ
	UI32		BASE_WR_INIT;	// Memory which is used to store init value of wire registers
	UI32		BASE_WR_PRESET;	// 
	UI32		BASE_WORK_END;

	//!< Define area for Register bank RBIP 
	UI32		RBIP_START;
	UI32		RBIP_END;

	void Show() {
		std::cerr << "--WORK INFO------------------------" << std::endl;
		std::cerr << "BASE_COMMON : " << std::hex << BASE_COMMON << std::endl;
		std::cerr << "BASE_PE     : " << std::hex << BASE_PE << std::endl;
		std::cerr << "BASE_PE_HT  : " << std::hex << BASE_PE_HT << std::endl;
		std::cerr << "SIZE_PE_HT  : " << std::hex << SIZE_PE_HT << std::endl; 
		std::cerr << "BASE_PE_VM  : " << std::hex << BASE_PE_VM << std::endl;
		std::cerr << "SIZE_PE_VM  : " << std::hex << SIZE_PE_VM << std::endl; 
		std::cerr << "SIZE_PE     : " << std::hex << SIZE_PE << std::endl; 
		std::cerr << "End of PE1  : " << std::hex << (BASE_PE + SIZE_PE - 1) << std::endl; 
		std::cerr << "BASE_WORK_END: " << std::hex << BASE_WORK_END << std::endl;
		std::cerr << "----------------------------------------" << std::endl;
	}
};
extern CAddressWeight g_LoadableAddr;
extern CAddressWeight g_StorableAddr;
extern CAddressWeight g_RmwAddr;
extern TWorkMemory g_wm;
#endif /*IFBLK_MANAGER_H_*/



