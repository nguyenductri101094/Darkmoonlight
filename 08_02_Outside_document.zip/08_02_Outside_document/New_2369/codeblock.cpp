#include	"codeblock.h"
#include    "usr_src.h"
#include    "operand.h"
#include "instruction.h"
#include	"rtg_app.h"

extern std::shared_ptr<CUserSourceFile>		g_usf;

CCodeBlock::CCodeBlock() : 
	m_bRLB(false), m_borg(false), m_bmod(false), m_bUserAddress(false), m_address(0), m_align(2),
	m_codesize(0), m_label(""), m_vcode(), m_lhash(), m_vndat(), m_bStatistics(false), m_bBreakSetupInsFlag(false), m_bBreakSetDone(false), m_bRandomBlock(false), m_bIsAllocated(false), m_NextBlock(NULL), m_bMainBlock(false), m_bTailBlock(false), m_blockGap(0)
{
	//DBG_TRACE();
}


CCodeBlock::CCodeBlock(std::string label) : 
	m_bRLB(false), m_borg(false), m_bmod(false), m_bUserAddress(false), m_address(0), m_align(2),
	m_codesize(0), m_label(label), m_vcode(), m_lhash(), m_vndat(), m_bStatistics(false), m_bBreakSetupInsFlag(false), m_bBreakSetDone(false), m_bRandomBlock(false), m_bIsAllocated(false), m_NextBlock(NULL), m_bMainBlock(false), m_bTailBlock(false), m_blockGap(0)
{
	//DBG_TRACE();
}


CCodeBlock::CCodeBlock(std::string label, UI32 addr) : 
	m_bRLB(false), m_borg(true), m_bmod(false), m_address(addr), m_align(2),
	m_codesize(0), m_label(label), m_vcode(), m_lhash(), m_vndat(), m_bStatistics(false), m_bBreakSetupInsFlag(false), m_bBreakSetDone(false), m_bRandomBlock(false), m_bIsAllocated(false), m_NextBlock(NULL), m_bMainBlock(false), m_bTailBlock(false), m_blockGap(0)
{
	//DBG_TRACE();
}


CCodeBlock::~CCodeBlock()
{
	std::for_each (m_vcode.begin(), m_vcode.end(), [](IInstruction* i){ delete i;} );
}


UI32 CCodeBlock::Print(std::ostream& ofs) {

	if (!IsEnableOutput()) {
		return 0;
	}

	ofs << std::setfill(' ');
	ofs << std::left;

#if 0
	if (m_borg) {
		ofs << std::endl; 
		ofs << ".org " << "0x" << std::hex << m_address << std::endl;
	}
#else
	std::string l = m_label;
	if (l.length() == 0) {
		std::stringstream ss;
		ss << std::hex << std::setw(8) << std::setfill('0');
		ss >> l;
	}
	ofs << "    .section    " << '.' << CLabel::m_prefix << l << ',' << " \"ax\"" << std::endl;
#endif

	if (m_label.length()) {
		if (!m_borg) {
			ofs << std::endl;
		}
		ofs << CLabel::m_prefix << m_label << ':' << std::endl;
	}

	std::vector<IInstruction*>::iterator itr;
#if defined(NDEBUG)
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		ofs << (**itr);
	}
#else
	UI32 addr = m_address ;
	char buf[20] ;
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		sprintf(buf , " ADDR: 0x%08x " , addr );
 		(**itr).AppendComment(buf);
		ofs  << (**itr);
 		addr += (**itr).GetLen();
	}
#endif

	ofs << std::endl;
	return m_vcode.size();
}


UI32 CCodeBlock::PrintLink(std::ostream& ofs) {

	if (IsEnableOutput() && IsLocationCount() ) {
		ofs << std::setfill(' ');
		ofs << std::left;
	
		std::string l = GetLabel();
		UI32		a = GetAddress();
		if (l.length() == 0) {
			std::stringstream	ss;
			ss << std::setw(8) << std::setfill('0') << a;
			ss >> l;
		}
		ofs << "    " << '.' << CLabel:: m_prefix << l << "    0x" << std::right << std::hex << std::setw(8) << std::setfill('0') << a << ':'  << " {" << std::endl; 
		ofs << "    " << "    " << "* (." << CLabel:: m_prefix << l << ')' << std::endl;
		ofs << "    " << '}' << std::endl;
		ofs << std::endl;
        return (GetAddress() + GetCodeSize());
	} else {
		return 0;
	}
}


void CCodeBlock::AddOpeCode(IInstruction* popr) {
	_ASSERT(popr);
	m_vcode.push_back(popr);
}


void CCodeBlock::AddOpeCode(IInstruction* popr, UI32 order) {
	
	_ASSERT(popr);
	if (this->GetInstructionNum() < order) {
	_ASSERT(this->GetInstructionNum() >= order);
	}
	
	std::vector<IInstruction*>::iterator itr = m_vcode.begin();
	advance(itr, order);
	m_vcode.insert(itr, popr);
}

UI32 CCodeBlock::GetIndex(IInstruction* pIns) throw (std::runtime_error){
	
	UI32 max = GetInstructionNum();
	for (UI32 idx = 0; idx < max; idx++) {
		if (at(idx) == pIns) {
			return idx;
		}
	}
	std::runtime_error excep("Not found instruction\n");
	throw excep;
	return 0;
}

void CCodeBlock::Interlace(CCodeBlock* b) {

	_ASSERT(b);
		
	/* TODO: 要検討 */
	/* CCodeBlock bとこのブロックが命令を多重で参照しないように         */
	/* bはクリアする。デストラクタにより2重解放になる。                 */
	/* コピーコンストラクタで対応すべきであるがパフォーマンスを考慮した。 */
	
	std::vector<IInstruction*> vmix;
	
	int aNum = this->m_vcode.size();
	int bNum = b->m_vcode.size();
	int ia, ib;
	
	for (ia = ib = 0; (ia < aNum) && (ib < bNum); ) {
		if (ia < aNum) {
			vmix.push_back(this->at(ia));
			ia++;
		}
		if (ib < bNum) {
			vmix.push_back(b->at(ib));
			ib++;
		}
	}
	
	this->m_codesize += b->m_codesize;
	b->m_vcode.clear();		// bの参照を切る(b->Clearを呼ばない)
	delete b;
	
	m_vcode = vmix;			// そのまま上書きする
}


void CCodeBlock::Append(CCodeBlock* b) {
	
	_ASSERT(b);
	m_vcode.insert(m_vcode.end(), b->m_vcode.begin(), b->m_vcode.end()); 	
	this->m_codesize += b->m_codesize;
	
	b->m_vcode.clear();		// bの参照を切る(b->Clearを呼ばない)
	delete b;
}


CCodeBlock* CCodeBlock::Split(UI32 i) {
	
	if (i < GetInstructionNum()) {
		std::vector<IInstruction*>::iterator itr = m_vcode.begin();
		std::advance(itr, i);
		
		CCodeBlock* splitCb = new CCodeBlock();
		splitCb->m_vcode.insert(splitCb->m_vcode.end(), itr, this->m_vcode.end()); 	
		this->m_vcode.erase(itr, this->m_vcode.end());
		
		// 補正可否も継承する
		splitCb->EnableRegulation(this->IsRegulation());
		
		return splitCb;
	}
	return NULL;
}


IInstruction* CCodeBlock::Fetch(UI32 addr) {
	std::map<UI32,IInstruction*>::iterator itr;
	if ((itr = m_lhash.find(addr)) != m_lhash.end()) {
		return itr->second;
	}
	return NULL;
}


void CCodeBlock::Update() {
	std::vector<IInstruction*>::iterator itr;
	m_codesize	= 0;
	
	m_lhash.clear();
	m_vndat.clear();
	
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		m_lhash.insert(std::pair<UI32,IInstruction*>(m_address+m_codesize, (*itr)));
		if ((*itr)->Category(IInstruction::ICAT_NATIVEDATA)) {
			m_vndat.push_back(m_address+m_codesize);
		}
		m_codesize	+= (*itr)->GetLen();
	}
}


/**
 *	@brief 補正命令について、レジスタ干渉しない限りにおいて前倒しにリオーダーする。
 */
void CCodeBlock::FrontLoadRegulation() {

	// 上から走査、補正コードが検出されたら逆方向に遡る
	auto ri = m_vcode.begin() + 1;
	auto GetSrIndex = [](IInstruction* p) -> UI32 {
		UI32 N = p->GetOpNum();
		for (UI32 i = 0; i < N; i++) {
			if (p->opr(i)->Attr(IOperand::OPR_ATTR_SR)) {
				return *(p->opr(i));
			}
		}
		return ~0U;
	};

	//std::cout << "-------------------------------------Before------------------------------------" << std::endl;
	//Dump(std::cout);
	for (; ri != m_vcode.end() ; ++ri) {
		if ((*ri)->InSequence() && (*ri)->GetForward() == false) {
			continue;
		}
		//if (((*ri)->GetComment().find("Regulation")) != std::string::npos) { // On testing, comment search....
		if ((*ri)->GetRegulationTarget() != nullptr) {
			auto rt = ri;
			std::string strTargetMne = (*ri)->GetRegulationTarget()->GetMne();
			if(strTargetMne == "feret" || strTargetMne == "eiret" || strTargetMne == "trfsr")
				continue;
			if((*ri)->HasAsyncLabel() || (*ri)->GetLabel().size() > 0) {
				continue;
			}

			//std::cout << "--" << std::endl;
			while (rt != m_vcode.begin()) {
				auto rh = rt - 1;
				if ((*rh)->GetRegulationTarget() != nullptr) {
					break; // 補正コードを密集させるためここでSTOP
				}
				UI32 TargetId = (*rt)->GetRegulationTarget()->GetId();
				if(TargetId == INS_ID_JMP || TargetId == INS_ID_JMPD32){
					break;
				}

				//prevent resbank instruction update adjustment code.
				if((*rh)->GetMne() == "resbank" || (*rh)->HasExp()) {
					break;
				}

				//Preceding instruction has asynchronous event label.
				if((*rh)->GetException().first != 0){ //[TN]TODO:
					break;
				}

				
				if((*rh)->GetComment().find("Mirror") !=std::string::npos)
					break;

				// Event may be accepted at adjustment code after moving.
				if((*rh)->HasDeassertAsyncLabel()) {
					break;
				}

				if ((*rh)->InSequence()){
					IInstruction *pForwardIns = (*rh)->GetForwardIns();
					while(pForwardIns != nullptr && (pForwardIns->GetId() != INS_ID_LOOP)  
						&& (GetIndex(*rh) < GetIndex(*rt) && (GetIndex(pForwardIns) > GetIndex(*rt))) ) {
						//Preceding instruction has asynchronous event label.
						if((*rh)->GetException().first != 0 || (*rh)->HasDeassertAsyncLabel()){
							break;
						}
						auto rt_dst = (*rt)->GetOprDst();
						auto rh_r = (*rh)->GetOprDst() | (*rh)->GetOprSrc();
						//[FROG]TODO: This case was not supported.
						// mov              hilo(0x16a943b4), r6
						// sbf              4, r6, r15, r13			<-- r6 is src register
						// caxi             [r6],r13,r20			<-- r6 is src register without forwarding
						if (rt_dst & rh_r) {
							break;
						}

						(*rh)->DirMoveTo(*rt);
						std::iter_swap (rt, rh);
						if(rh == m_vcode.begin())
							break;
						rt = rh ;
						rh = rt - 1;
						ri = ri-1;
						pForwardIns = (*rh)->GetForwardIns();
					}
					IInstruction *target = (*rt)->GetRegulationTarget();
					if(target != nullptr && (target->GetMne() == "dispose" && target->InLoop() == true) && (*rt)->GetLabel().size() == 0){
					} else
						break; // 順序不動コードによりSTOP
				}

				if ( ((*rh)->m_pswb != (*rh)->m_pswa ) || ((*rt)->m_pswb != (*rt)->m_pswa ) ) {
					break;
				}
				if ((*rh)->Behavior(IInstruction::JMP)) {
					break; // Jmpコード
				}
				if ((*rh)->GetLabel().length() > 0) {
					break; // Label付き命令（Jmpの着地点になる）
				}

				UI32 sridx = GetSrIndex(*rh);
				if (sridx != ~0U) {
					if (GetSrIndex(*rt) == sridx) {
						//fprintf(stderr, "SR 干渉 sridx=%d\n", sridx);
						break;
					}
				}
				auto rt_r = (*rt)->GetOprSrc();
				auto rt_w = (*rt)->GetOprDst();
				auto rh_r = (*rh)->GetOprSrc();
				auto rh_w = (*rh)->GetOprDst();
				if ( ((rt_r | rt_w) & (rh_r | rh_w)) == 0 ) {
					std::iter_swap (rt, rh);
					rt = rh;
				}else{
					break;
				}
			}
		}
	}
	//std::cout << "-------------------------------------After------------------------------------" << std::endl;
	Update();
	//Dump(std::cout);
	//std::cout << std::endl;
}


void CCodeBlock::Dump(std::ostream& os /* = std::cout*/){
	std::map<UI32,IInstruction*>::iterator i;
	os << '[' << GetLabel() << "] Size=" << GetCodeSize() << std::endl;
	os << std::setfill('0') << std::hex;
	for (i = m_lhash.begin(); i != m_lhash.end(); i++) {
		os << std::setw(8) << i->first << " : " << i->second->GetOutCode()<< " : " << i->second->GetComment();
		
		std::string lbl = i->second->GetLabel();
		if (lbl == "") {
			os << std::endl;
		}else{
			os << "  (" << i->second->GetLabel() << ")" 
			<< std::endl;
		}
	}
}

/*Some instructions which GNU do not support will be modified in this sequence*/
void CCodeBlock::AdjustNotSupportedIns(){
	char memo[256];
	auto ri = m_vcode.begin();
	UI64	bits;
	for (; ri != m_vcode.end() ; ++ri) {
		if ((*ri)->GetId() >= 307 && (*ri)->GetId() <= 454) {
			bits = (*ri)->Fetch();
			IInstruction* pNewIns = _WORD(bits);
			sprintf (memo, "Instruction: %s", (*ri)->GetCode().c_str());
			pNewIns->AppendComment(memo);
			(*ri)->DirMoveTo(pNewIns);
			(*ri)->AsyncMoveTo(pNewIns);
			this->Replace((*ri), pNewIns);
			this->Update();
			
		} 
	}
}

UI32 CUserBlock::Print(std::ostream& ofs) {

	if (!IsEnableOutput()) {
		return 0;
	}

	ofs << std::setfill(' ');
	ofs << std::left;

#if 0
	if (m_borg) {
		ofs << std::endl; 
		ofs << ".org " << "0x" << std::hex << m_address << std::endl;
	}
#else
	std::string l = m_label;
	if (l.length() == 0) {
		std::stringstream ss;
		ss << std::hex << std::setw(8) << std::setfill('0');
		ss >> l;
	}
	ofs << "    .section    " << '.' << CLabel::m_prefix << l << ',' << " \"ax\"" << std::endl;
#endif	
	if (m_label.length()) {
		if (!m_borg) {
			ofs << std::endl;
		}
		ofs << CLabel::m_prefix << m_label << ':' << std::endl;
	}

	// REPRASE SETTING
    g_usf->ClearPlaceHolder();
    g_usf->SetPlaceHolder("%CONTEXT%", m_context_key);
	g_usf->SetPlaceHolder("%FROG_PE%", CLabel::m_prefix);
	// OUTPUT USER CODE
    g_usf->GetBody(m_user_key , ofs);

	std::vector<IInstruction*>::iterator itr;
#if defined(NDEBUG)
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		ofs << (**itr);
	}
#else
	UI32 addr = m_address ;
	char buf[20] ;
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		sprintf(buf , " ADDR: 0x%08x " , addr );
 		(**itr).AppendComment(buf);
		ofs << (**itr);
 		addr += (**itr).GetLen();
	}
#endif

	ofs << std::endl;
	return m_vcode.size();
}


/**
 * @brief  ノード出力インターフェース
 * @param  ofs  出力ストリームオブジェクト
 * @return 出力行数を返す。
 */
UI32 CVectorBlock::Print(std::ostream& ofs) {
    if (m_bIsSys) {
        ofs << ".ifndef FROG_MANYCORE_GEN"<< std::endl;
    }
	std::string l = m_label;
   	ofs << ".ifndef " << CLabel::m_prefix << l  << "_UseUserCode"<< std::endl;

	ofs << std::setfill(' ');
	ofs << std::left;

	if (l.length() == 0) {
		std::stringstream ss;
		ss << std::hex << std::setw(8) << std::setfill('0');
		ss >> l;
	}
	ofs << "    .section    " << '.' << CLabel::m_prefix << l << ',' << " \"ax\"" << std::endl;

	if (m_label.length()) {
		if (!m_borg) {
			ofs << std::endl;
		}
		ofs << CLabel::m_prefix << m_label << ':' << std::endl;
	}

	std::vector<IInstruction*>::iterator itr;
	if (IsEnableOutput() || (m_strHandler == "")) {
#if defined(NDEBUG)
		for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
			ofs << (**itr);
		}
#else
		UI32 addr = m_address ;
		char buf[20] ;
		for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
			sprintf(buf , " ADDR: 0x%08x " , addr );
 			(**itr).AppendComment(buf);
			ofs  << (**itr);
	 		addr += (**itr).GetLen();
		}
#endif
	} else {
        if (m_ExceptionLevel == 1) {
		    ofs  << "	ldsr             r3, 29" << std::endl;
        } else if (m_ExceptionLevel == 2) {
		    ofs  << "	ldsr             r3, 30, 3" << std::endl;
        } else {
		    ofs  << "	ldsr             r3, 28" << std::endl;
        }
		ofs  << "	mov              hilo(" << CLabel::m_prefix << m_strHandler << ") ,r3" << std::endl;
		ofs  << "	jmp              [r3]" << std::endl;
	}

	ofs << std::endl;
	ofs << ".endif" << std::endl;
    if (m_bIsSys) {
        ofs << ".endif" << std::endl;
    }
	ofs << std::endl;
	return m_vcode.size();
}


UI32 CVectorBlock::PrintLink(std::ostream& ofs) {

	if (IsLocationCount()) {
		ofs << std::setfill(' ');
		ofs << std::left;
	
		std::string l = GetLabel();
		UI32		a = GetAddress();
		if (l.length() == 0) {
			std::stringstream	ss;
			ss << std::setw(8) << std::setfill('0') << a;
			ss >> l;
		}
		ofs << "    " << '.' << CLabel:: m_prefix << l << "    0x" << std::right << std::hex << std::setw(8) << std::setfill('0') << a << ':'  << " {" << std::endl; 
		ofs << "    " << "    " << "* (." << CLabel:: m_prefix << l << ')' << std::endl;
		ofs << "    " << '}' << std::endl;
		ofs << std::endl;
        return (GetAddress() + GetCodeSize());
	} else {
		return 0;
	}
}

void CPreloadBlock::Update() {
	// Update lookup table (CALLT)
	if(m_vEntry.size() > 0) {
		std::map <IInstruction*, UI32> mDst;
		IInstruction *pIns;
		UI32 offset = 0;
		UI32 startPos = 0;

		// Search start instruction of TBL
		for(UI32 idx = 0; idx < m_vcode.size(); idx++) {
			pIns = m_vcode[idx];
			if(pIns->GetMne() == ".hword"){
				startPos = idx;
				break;
			}
		}

		// Re-calculate offset
		for(UI32 idx = startPos; idx < m_vcode.size(); idx++) {
			pIns = m_vcode[idx];
			mDst.insert(std::make_pair(pIns, offset));
			offset += pIns->GetLen();
		}

		std::vector<IInstruction*>::iterator itr;
		UI32 entry = 0;
		IInstruction *pWord;
		for(itr = m_vEntry.begin(); itr != m_vEntry.end(); itr++) {
			IInstruction *pIns = *itr;
			UI32 pos = this->GetIndex(pIns);
			IInstruction *pReg = NULL;

			for(SI32 i = pos - 1; i >= 0; i--) {
				IInstruction *p = this->at(i);
				if(p->GetRegulationTarget() == pIns) {
					pReg = p;
				} else
					break;
			}

			if(pReg != NULL) {
				//m_vEntry.insert(itr + 1, pReg);
				//itr = m_vEntry.erase(itr); itr--;
				offset = (mDst.find(pReg))->second;
			} else {
				offset = (mDst.find(pIns))->second;
			}
			
			pWord = m_vcode[startPos + entry];
			pWord->opr(0)->SetRange(offset, offset);
			pWord->opr(0)->Replace(offset);
			entry++;
		}
		std::vector<std::vector<UI32>> vSetEntry = {};
		std::vector<std::vector<UI32>> vCurEntry = {};

		vCurEntry = g_sim->GetCalltEntry();

		std::vector<IInstruction*>	tarIns;
		if(vCurEntry.empty()){
			for(UI32 j = 0; j < m_vEntry.size(); j++){
				IInstruction* dst = m_vEntry.at(j);
				if(tarIns.size() == 0 || std::find(tarIns.begin(), tarIns.end(), dst) == tarIns.end()){
					tarIns.push_back(dst);
				}
			}

		}
	  //Collect all entry index
		for(UI32 i = 0; i< tarIns.size(); i++){
			std::vector<UI32> group_idex;
			for(UI32 j = 0; j < m_vEntry.size(); j++){
				if(m_vEntry.at(j) == tarIns.at(i))
					group_idex.push_back(j);
			}
			if(group_idex.size())
				vSetEntry.push_back(group_idex);
		}

		if(vSetEntry.size())
			g_sim->SetCalltEntry(vSetEntry);

	}
	CCodeBlock::Update();
}

bool CPreloadBlock::Remove(IInstruction* p) {
	// Update lookup table (CALLT, SYSCALL)
	if(m_vEntry.size() > 0) {
		// Replace deleted instruction by next ins in lookup table.
		IInstruction *pNext;
		UI32 idx = this->GetIndex(p);
		if(idx == this->GetInstructionNum()) {
			//this->AddOpeCode(NOP()); //[TN]TODO: Fix it.
		}
		pNext = this->at(idx + 1);

		for(UI32 n = 0; n < m_vEntry.size(); n++) {
			std::vector<IInstruction*>::reference ref = m_vEntry.at(n);
			if(p == ref) {
				ref = pNext;
			}
		}
	}

	// Remove instruction
	return CCodeBlock::Remove(p);
}

IInstruction* CPreloadBlock::Replace(IInstruction* before, IInstruction* after) {
	// Update lookup table (CALLT, SYSCALL)
	if(m_vEntry.size() > 0) {
		// Replace deleted instruction by after in lookup table.
		for(UI32 n = 0; n < m_vEntry.size(); n++) {
			std::vector<IInstruction*>::reference ref = m_vEntry.at(n);
			if(before == ref) {
				ref = after;
			}
		}
	}
	return CCodeBlock::Replace(before,after);
}



