# -------------------------------- HOW TO USE -------------------------------------
# 		python Coverage_Debug.py <Cforest file>
# ---------------------------------------------------------------------------------

import database;
import sys;
import csv;
import re;
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import datetime # support time stamp
import copy
from collections import OrderedDict
import random

# ----------------------------- Private definition -------------------

# ----------------------------- Assisant Function ---------------------
dict_GrIndex = OrderedDict([("r0", 0), ("r1", 0), ("r2", 0), ("r3", 0), ("r4", 0), ("r5", 0), ("r6", 0), ("r7", 0), ("r8", 0), ("r9", 0),
							("r10", 0), ("r11", 0), ("r12", 0), ("r13", 0), ("r14", 0), ("r15", 0), ("r16", 0), ("r17", 0), ("r18", 0), ("r19", 0),
							("r20", 0), ("r21", 0), ("r22", 0), ("r23", 0), ("r24", 0), ("r25", 0), ("r26", 0), ("r27", 0), ("r28", 0), ("r29", 0),
							("r30", 0), ("r31", 0)])

list_FPU_ins = 	[	"ceilf.dl", "ceilf.dul", "ceilf.dw", "ceilf.duw", "ceilf.sl", "ceilf.sul", "ceilf.sw", "ceilf.suw",
					"floorf.dl", "floorf.dul", "floorf.dw", "floorf.duw", "floorf.sl", "floorf.sul", "floorf.sw", "floorf.suw",
					"trncf.dl", "trncf.dul", "trncf.dw", "trncf.duw", "trncf.sl", "trncf.sul", "trncf.sw", "trncf.suw",
					"cvtf.dl", "cvtf.dul", "cvtf.dw", "cvtf.duw", "cvtf.sl", "cvtf.sul", "cvtf.sw", "cvtf.suw",
					"cvtf.ld", "cvtf.uld", "cvtf.ls", "cvtf.uls", "cvtf.wd", "cvtf.uwd", "cvtf.ws", "cvtf.uws",
					"cvtf.ds", "cvtf.sd", "cvtf.sh", "cvtf.hs",
					"roundf.dl", "roundf.dul", "roundf.dw", "roundf.duw", "roundf.sl", "roundf.sul", "roundf.sw", "roundf.suw",
					"absf.d", "negf.d", "sqrtf.d", "absf.s", "negf.s", "sqrtf.s",
					"recipf.d", "rsqrtf.d", "recipf.s", "rsqrtf.s",
					"addf.d", "divf.d", "maxf.d", "minf.d", "mulf.d", "subf.d", "addf.s", "divf.s", "maxf.s", "minf.s", "mulf.s", "subf.s",
					"fmaf.s", "fmsf.s", "fnmaf.s", "fnmsf.s",
					"cmpf.d", "cmpf.d_0x0", "cmpf.s", "cmpf.s_0x0",
					"cmovf.d", "cmovf.s", "trfsr", "trfsr_0x0"]

class FPU_Ins_IndexGR:
	def __init__(self, Ins_list):
		self.map = OrderedDict()
		self.map_equal = OrderedDict()
		for ins in Ins_list:
			self.map[ins] = OrderedDict([	("first_opr", OrderedDict(dict_GrIndex)),
											("second_opr", OrderedDict(dict_GrIndex)),
											("third_opr", OrderedDict(dict_GrIndex))])
			self.map_equal[ins] = 0

	def Update_result(self, name, list_opr):
		if name in self.map:
			index_gr_opr = 0
			key_opr = ["first_opr", "second_opr", "third_opr"]
			set_operand = set()

			for opr in list_opr:
				if opr in dict_GrIndex:
					self.map[name][key_opr[index_gr_opr]][opr] = 1
					index_gr_opr += 1
					set_operand.add(opr)

			if len(set_operand) == 1:
				self.map_equal[name] = 1

	def ExportCSV(self, file_name, action):
		output_file = open(file_name, action)
		writer = csv.writer(output_file)
		header = ["FPU_Ins", "Opr position"] + dict_GrIndex.keys()
		writer.writerow(header)

		for key_ins, val_ins in self.map.items():
			result = [key_ins]
			for key_pos_opr, val_pos_opr in val_ins.items():
				result.append(key_pos_opr)
				for val_gr in val_pos_opr.values():
					result.append(val_gr)
				writer.writerow(result)
				result = ["-"]

		writer.writerow([])
		writer.writerow(["-----", "All Operand are equal", "-----"])
		for key_ins, val_ins in self.map_equal.items():
			writer.writerow([key_ins, val_ins])

		output_file.close()

class FPU_Ins_ValueGR:
	def __init__(self, Ins_list):

def Load_Backup_data():
	global AccumulationFile_GrIndex, AccumulationFile_GrValue, InsFPU_GR_Index_class
	#Load back data from backup file(if exists) before executing script
	if os.path.isfile(AccumulationFile_GrIndex):
		with open(AccumulationFile_GrIndex, 'rb') as file_bk:
			if Enable_test_FPU_GR_index == True:
				InsFPU_GR_Index_class = pickle.load(file_bk)

def Store_Backup_data():
	global AccumulationFile_GrIndex, AccumulationFile_GrValue, InsFPU_GR_Index_class
	#Backup data to a new file between script-executions
	if Enable_test_FPU_GR_index == True:
		with open(AccumulationFile_GrIndex, 'wb') as file_bk:
			pickle.dump(InsFPU_GR_Index_class, file_bk)

def CheckingFPUCoverage(data, prev_data):
	##Correct name of FPU instruction
	if data.InsName in {"cmpf.d", "cmpf.s", "trfsr"} and len(data.Exp) == 0:
		if data.Opr[-1] == "0x0":
			data.InsName += "_0x0"

	if len(data.Exp) == 0 and len(data.Opr) != 0:
		InsFPU_GR_Index_class.Update_result(data.InsName, data.Opr)


#-------------------------------------------------------------------
# ----------------------------- MAIN Function ----------------------
#-------------------------------------------------------------------
start_time = datetime.datetime.now()
print "Start Checking Coverage Instruction_FPU: ", start_time
cforest_log = sys.argv[1:]
database.GR = { 'r0' : 0, 'r1' : 0, 'r2' : 0, 'r3' : 0, 'r4' : 0, 'r5' : 0, 'r6' : 0, 'r7' : 0, 'r8' : 0, 'r9' : 0,
	   			'r10' : 0, 'r11' : 0, 'r12' : 0, 'r13' : 0, 'r14' : 0, 'r15' : 0, 'r16' : 0, 'r17' : 0, 'r18' : 0, 'r19' : 0,
	   			'r20' : 0, 'r21' : 0, 'r22' : 0, 'r23' : 0, 'r24' : 0, 'r25' : 0, 'r26' : 0, 'r27' : 0, 'r28' : 0, 'r29' : 0,
	   			'r30' : 0, 'r31' : 0 }
database.WR = {}
database.SR = {'HVCFG' : 0, 'PSWH' : 0, 'PSW' : 0, 'GMPSW' : 0, 'FPSR' : 0, 'FPCFG' : 0}
				
#-------------Control mode of script--------------
Enable_test_FPU_GR_index = True
Enable_test_FPU_GR_value = False
Enable_test_FPU_type_exception = False

#-------------End control mode of script--------------

if Enable_test_FPU_GR_index == True:
	InsFPU_GR_Index_class = FPU_Ins_IndexGR(list_FPU_ins)

if Enable_test_FPU_GR_value == True:

	list_input_half = list()
	list_input_single = list()
	list_input_double = list()
	list_input_int = list()
	list_input_long = list()
	type_input = {"h": "list_input_half", "s": "list_input_single", "d": "list_input_double", "u": "list_input_int", "l": "list_input_long"}

	for ins in list_FPU_ins:
		if "." in ins:
			raw_name = ins.split(".")
			if raw_name[1][-1] in type_input:
				exec("%s.append(%s)" % (type_input[raw_name[1][-1]], ins))
			

FPU_GR_Index_result_file = "FPU_GR_Index_result_file.csv"
FPU_GR_Value_result_file = "FPU_GR_Value_result_file.csv"

AccumulationFile_GrIndex = 'Data_Accumulation_FPU_GR_Index.bk'
AccumulationFile_GrValue = 'Data_Accumulation_FPU_GR_Value.bk'

Load_Backup_data()
	
for log in cforest_log:
	start_time_log = datetime.datetime.now()
	print "File: ", log, " Start Time: ", start_time_log
	raw_data = database.CollectData(log)
	#Get start and end of random code
	start_line = database.GetIndexStartRandomCode(raw_data)
	end_line = database.GetIndexEndRandomCode(raw_data)

	#database.PrintData(raw_data)		
	for line in range (start_line, end_line):
		CheckingFPUCoverage(raw_data[line], raw_data[line - 1])
	
	del raw_data
	end_time_log = datetime.datetime.now()
	print "Time Lapse: ", (end_time_log - start_time_log)
	
"""
-------------------------------------------------------------------------
----------------------- Handle result file ------------------------------
-------------------------------------------------------------------------
"""
# Export data to CSV file
if Enable_test_FPU_GR_index == True:
	InsFPU_GR_Index_class.ExportCSV(FPU_GR_Index_result_file, 'wb')

Store_Backup_data()

##Limit: Can not detect for checkpoint Cancel HALT/SNOOZE: 549 -> 604
print "End Time: ", datetime.datetime.now()
print "Total Time Consume: ", (datetime.datetime.now() - start_time)