# -------------------------------- HOW TO USE -------------------------------------
# 		python Coverage_Debug.py <Cforest file>
# ---------------------------------------------------------------------------------

import database;
import sys;
import csv;
import re;
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import datetime # support time stamp
import copy
from collections import OrderedDict
import random

# ----------------------------- Private definition -------------------
# Dict to store mode execution status
ModeDict = OrderedDict([("CV", OrderedDict()), ("VS", OrderedDict())])

# ----------------------------- Assisant Function ---------------------
#Object verify
class ValueOfVctChannel:
	def __init__(self, dict_Exp_vct):
		self.map = OrderedDict()
		for key_exp, value_exp in dict_Exp_vct.items():
			self.map[key_exp] = OrderedDict(ModeDict)
			dict_min_mid_max = OrderedDict()
			for pos in ["_min", "_mid", "_max"]:
				key_min_mid_max = "vct/channel_" + str(value_exp[0]) + "_" + str(value_exp[1]) + pos
				dict_min_mid_max[key_min_mid_max] = 0

			for key_mode in self.map[key_exp].keys():
				self.map[key_exp][key_mode] = OrderedDict(dict_min_mid_max)

	def Update_result(self, name, mode, val):
		if name not in self.map.keys():
			return

		if mode == database.Mode.CV:
			str_mode = "CV"
		elif mode == database.Mode.HM or mode == database.Mode.GM:
			str_mode = "VS"
		else:
			return

		for key in self.map[name][str_mode].keys():
			raw_field = key.split("_")
			min_val = int(raw_field[1])
			max_val = int(raw_field[2])
			key_pos_val = raw_field[0] + "_" + raw_field[1] + "_" + raw_field[2]
			break

		if min_val < val < max_val:
			key_pos_val += "_mid"
		elif val == min_val:
			key_pos_val += "_min"
		elif val == max_val:
			key_pos_val += "_max"
		else:
			print "ERROR: Value out of range - min_val = ", min_val, " - max_val = ", max_val, " - val = ", val
			return
		
		self.map[name][str_mode][key_pos_val] = 1

	def ExportCSV(self, file_name, action):
		output_file = open(file_name, action)
		writer = csv.writer(output_file)
		writer.writerow(["EXP/INT", "CV_min", "CV_mid", "CV_max", "VS_min", "VS_mid", "VS_max"])
		for key_exp, value_exp in self.map.items():
			list_result = [key_exp]
			for key_mode, value_mode in value_exp.items():
				for key_pos, value_pos in value_mode.items():
					list_result.append(value_pos) 			
			writer.writerow(list_result)
		output_file.close()

def Load_Backup_data():
	global AccumulationFile_Mode, AccumulationFile_HALT_AccCond, ExpInt_Mode_class, ExpInt_Vct_Channel_class, dict_HALT_AccCond, set_of_HALT
	#Load back data from backup file(if exists) before executing script
	if os.path.isfile(AccumulationFile_Mode):
		with open(AccumulationFile_Mode, 'rb') as file_bk:
			if Enable_test_ExpInt_Mode == True:
				ExpInt_Mode_class = pickle.load(file_bk)
				ExpInt_Vct_Channel_class = pickle.load(file_bk)

	if os.path.isfile(AccumulationFile_HALT_AccCond):
		with open(AccumulationFile_HALT_AccCond, 'rb') as file_bk:
			if Enable_test_ExpInt_HALT_AccCond == True:
				dict_HALT_AccCond = pickle.load(file_bk)
				set_of_HALT = pickle.load(file_bk)

def Store_Backup_data():
	global AccumulationFile_Mode, AccumulationFile_HALT_AccCond, ExpInt_Mode_class, ExpInt_Vct_Channel_class, dict_HALT_AccCond, set_of_HALT
	#Backup data to a new file between script-executions
	if Enable_test_ExpInt_Mode == True:
		with open(AccumulationFile_Mode, 'wb') as file_bk:
			pickle.dump(ExpInt_Mode_class, file_bk)
			pickle.dump(ExpInt_Vct_Channel_class, file_bk)

	if Enable_test_ExpInt_HALT_AccCond == True:
		with open(AccumulationFile_HALT_AccCond, 'wb') as file_bk:		
			pickle.dump(dict_HALT_AccCond, file_bk)
			pickle.dump(set_of_HALT, file_bk)

def Print_debug_log(file_control, data, dict_fixed, list_toggle, checkpoint_name):
	name_list = list()
	for key in dict_fixed.keys():
		name_list.append(key)

	for name in list_toggle:
		name_list.append(name)

	file_control.write("%s \n" % checkpoint_name)
	database.PrintBitCombination(file_control, data, name_list, 0)
	file_control.write("\n\n")

def HandleResult_EI_int(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_GM_EI_int(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_BG_EI_int(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_FE_int(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_GM_FE_int(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_BG_FE_int(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_Syserr_rb(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_Syserr_slave(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_Syserr_save(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_Host_MPU(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def HandleResult_Guest_MPU(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_HALT_AccCond_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

def Type_of_Handler_Address(prev_data):
	psw = prev_data.SR["PSW"] if database.GetMode(prev_data.SR) != database.Mode.GM else prev_data.SR["GMPSW"]
	PSW_EBV = database.GetValueBitRange(psw, 15, 15)
	if PSW_EBV == 0:
		return '_R'
	else:
		return '_E'

def Correct_SysErr_name(name):
	if name == "SYSERR":
		return "SYSERR_slave"
	elif name == "SYSERR_REEXEC":
		return "SYSERR_rb"
	elif name == "SYSERR_RB":
		return "SYSERR_save"
	else:
		print "ERROR: Type of SysErr isn't detected: ", name
		return "SYSERR_ERROR"

def Correct_EI_int_name(data):
	if data.Behavior == 0: ##Direct vector
		return data.Exp[0]
	else:
		return data.Exp[0].replace("INT", "TBL")

def Correct_MPU_exp_name(data, name):
	if data.Exp[2] in {0x98, 0x99, 0x9D}:
		return (name + "_Host")
	elif data.Exp[2] in {0x90, 0x91, 0x95}:
		return (name + "_Guest")
	else:
		print "ERROR: Detect invalid cause code: ", hex(data.Exp[2])
		return name

def INTCFG_EPL(prev_data):
	return database.GetValueBitRange(prev_data.SR["INTCFG"], 1, 1)

def GMCFG_GSYSE_HMP_GMP(prev_data):
	GMCFG_GSYSE = database.GetValueBitRange(prev_data.SR["GMCFG"], 4, 4)
	GMCFG_HMP = database.GetValueBitRange(prev_data.SR["GMCFG"], 1, 1)
	GMCFG_GMP = database.GetValueBitRange(prev_data.SR["GMCFG"], 0, 0)
	return str(GMCFG_GSYSE) + str(GMCFG_HMP) + str(GMCFG_GMP)

def PSWH_GM(prev_data):
	return database.GetValueBitRange(prev_data.SR["PSWH"], 31, 31)

def DIR0_DM(prev_data):
	return database.GetValueBitRange(prev_data.SR["DIR0"], 0, 0)

def PSW_ID_NP_EIMASK(prev_data):
	PSW_ID = database.GetValueBitRange(prev_data.SR["PSW"], 5, 5)
	PSW_NP = database.GetValueBitRange(prev_data.SR["PSW"], 7, 7)
	PSW_EIMASK = database.GetValueBitRange(prev_data.SR["PSW"], 20, 27)

	EIMAK_return_val = {0: '100', 15: '010', 63: '001'}
	EIMASK_val = EIMAK_return_val.get(PSW_EIMASK, '000')

	return str(PSW_ID) + str(PSW_NP) + EIMASK_val

def GMPSW_ID_NP_EIMASK(prev_data):
	GMPSW_ID = database.GetValueBitRange(prev_data.SR["GMPSW"], 5, 5)
	GMPSW_NP = database.GetValueBitRange(prev_data.SR["GMPSW"], 7, 7)
	GMPSW_EIMASK = database.GetValueBitRange(prev_data.SR["GMPSW"], 20, 27)

	list_EIMASK = [0, 15, 63]
	list_return_val = ['100', '010', '001', '000']
	EIMASK_val = list_return_val[list_EIMASK.index(GMPSW_EIMASK)] if GMPSW_EIMASK in list_EIMASK else list_return_val[3]

	return str(GMPSW_ID) + str(GMPSW_NP) + EIMASK_val

def PLMR(prev_data):
	PLMR_PLM = database.GetValueBitRange(prev_data.SR["PLMR"], 0, 7)

	list_PLM = [0, 15, 63]
	list_return_val = ['100', '010', '001', '000']
	PLM_val = list_return_val[list_PLM.index(PLMR_PLM)] if PLMR_PLM in list_PLM else list_return_val[3]

	return PLM_val

def GMPLMR(prev_data):
	GMPLMR_PLM = database.GetValueBitRange(prev_data.SR["GMPLMR"], 0, 7)

	list_PLM = [0, 15, 63]
	list_return_val = ['100', '010', '001', '000']
	PLM_val = list_return_val[list_PLM.index(GMPLMR_PLM)] if GMPLMR_PLM in list_PLM else list_return_val[3]

	return PLM_val

def Collect_Info_Int(key, name, data):
	if data.HasInt == True:
		if "EIINT" in name or "EITBL" in name:
			flag_detect_EI_int = False
			for tup in set_Interrupt:
				if tup[0] == data.PC and tup[1] == name and tup[3] == "assert":
					flag_detect_EI_int = True
					break
			if flag_detect_EI_int == True:
				priority = tup[2]
				list_pri_val = [0, 15, 63]
				list_key_select = ['1100', '1010', '1001', '1000']
				key += list_key_select[list_pri_val.index(priority)] if priority in list_pri_val else list_key_select[3]
			else:
				print "ERROR: Not detect ", name, "- PC: ", hex(data.PC), "- Line: ", data.Line
				key += '1000'
		else:
			key += '1000'
	else:
		key += '0000'

	if len(data.Exp) != 0 and data.Exp[0] == name:
		return (key + '1')
	else:
		return (key + '0')

def Checking_Mode_VctChannel(data, prev_data):
	global str_coprocessor

	if len(data.Exp) != 0:
		##Check mode
		name = data.Exp[0]
		handler_addr = Type_of_Handler_Address(prev_data)
		name += handler_addr

		if data.Exp[0] in {"UCPOP0", "UCPOP1"}:
			name += str_coprocessor
		elif "SYSERR" in data.Exp[0]:
			name = Correct_SysErr_name(data.Exp[0]) + handler_addr
		elif data.Exp[0] in {"EIINT", "GMEIINT"}:
			name = Correct_EI_int_name(data) + handler_addr

		if name in ExpInt_Mode_class.map.keys():
			ExpInt_Mode_class.Update_result(name, database.GetModeAndPrivilege(prev_data.SR))

		##Check vector/channel
		if data.Exp[0] in {"EIINT", "GMEIINT"}:
			data.Exp[0] = Correct_EI_int_name(data)

		flag = False
		if data.Exp[0] in dict_Exp_Name_vct.keys():
			val = int(data.Opr[0], 16)
			flag = True
		elif data.Exp[0] in dict_Exp_Name_channel.keys():
			val = data.Exp[2] & 0xFFFF
			flag = True

		if flag == True:
			ExpInt_Vct_Channel_class.Update_result(data.Exp[0], database.GetMode(prev_data.SR), val)

def Checking_HALT_AccCond(data, prev_data):
	##INTCFG.EPL
	key_cond_check_HALT_AccCond = str(INTCFG_EPL(prev_data))

	##GMCFG.GSYSE + GMCFG.HMP + GMCFG.GMP
	key_cond_check_HALT_AccCond += GMCFG_GSYSE_HMP_GMP(prev_data)

	##PSWH.GM
	key_cond_check_HALT_AccCond += str(PSWH_GM(prev_data))

	##DIR0.DM
	key_cond_check_HALT_AccCond += str(DIR0_DM(prev_data))

	##PSW.ID + PSW.NP + PSW.EIMASK
	key_cond_check_HALT_AccCond += PSW_ID_NP_EIMASK(prev_data)

	##GMPSW.ID + GMPSW.NP + GMPSW.EIMASK
	key_cond_check_HALT_AccCond += GMPSW_ID_NP_EIMASK(prev_data)

	##PLMR
	key_cond_check_HALT_AccCond += PLMR(prev_data)

	##GMPLMR
	key_cond_check_HALT_AccCond += GMPLMR(prev_data)

	##Detect the key of dictionary
	if len(data.Exp) != 0:
		if data.Exp[0] in {"EIINT", "GMEIINT"}:
			data.Exp[0] = Correct_EI_int_name(data, data.Exp[0])
		if "SYSERR" in data.Exp[0]:
			data.Exp[0] = Correct_SysErr_name(data.Exp[0])
		if "MIP" in data.Exp[0] or "MDP" in data.Exp[0]:
			data.Exp[0] = Correct_MPU_exp_name(data, data.Exp[0])
		key_name = str(data.Exp[0])

		if key_name in dict_HALT_AccCond:
			dict_cond_check_HALT_AccCond = dict_HALT_AccCond[key_name]

			##Record status of acceptance condition
			key_cond_check_HALT_AccCond_sub1 = Collect_Info_Int(key_cond_check_HALT_AccCond, key_name, data)

			if len(key_cond_check_HALT_AccCond_sub1) != lengthOfList_HALT_AccCond:
				print "Error: Length of key_cond_check_HALT_AccCond_sub1 is not suitable: key = ", key_cond_check_HALT_AccCond_sub1, " - Expected len: ", lengthOfList_HALT_AccCond, " - Line: ", data.Line
			else:
				dict_cond_check_HALT_AccCond[key_cond_check_HALT_AccCond_sub1] = 1

	if data.HasInt == True:
		for tup in set_Interrupt:
			if data.PC == tup[0] and tup[3] == "assert":
				key_name = tup[1]
			else:
				continue

			if key_name in dict_HALT_AccCond:
				dict_cond_check_HALT_AccCond = dict_HALT_AccCond[key_name]

				##Record status of acceptance condition
				key_cond_check_HALT_AccCond_sub2 = Collect_Info_Int(key_cond_check_HALT_AccCond, key_name, data)
				
				if len(key_cond_check_HALT_AccCond_sub2) != lengthOfList_HALT_AccCond:
					print "Error: Length of key_cond_check_HALT_AccCond_sub2 is not suitable: key = ", key_cond_check_HALT_AccCond_sub2, " - Expected len: ", lengthOfList_HALT_AccCond, " - Line: ", data.Line
				else:
					dict_cond_check_HALT_AccCond[key_cond_check_HALT_AccCond_sub2] = 1

	##Check interrupt pending at HALT
	if data.HasInt == True:
		for tup in set_Interrupt:
			#Correct name of interrupt EITBL -> EIINT
			name = tup[1].replace("TBL", "INT")
			
			if data.PC == tup[0] and tup[3] == "assert":			
				if len(data.Exp) != 0 and data.Exp[0] == name:
					continue
				elif name in dict_pending_Interrupt:
					dict_pending_Interrupt[name] = 1

			if data.PC == tup[0] and tup[3] == "deassert":
				if name in dict_pending_Interrupt:
					dict_pending_Interrupt[name] = 0
	#Erase bit count for pending exception which is accepted  
	elif len(data.Exp) != 0 and ("INT" in data.Exp[0] or "NMI" in data.Exp[0]):
		name = tup[1].replace("TBL", "INT")
		dict_pending_Interrupt[name] = 0

	if data.InsName == "halt":
		#Check mode:
		if database.GetMode(prev_data.SR) == database.Mode.HM:
			int_status = (frozenset(dict_pending_Interrupt.items()), "Host")
		elif database.GetMode(prev_data.SR) == database.Mode.GM:
			int_status = (frozenset(dict_pending_Interrupt.items()), "Guest")
		else:
			int_status = ()

		if len(int_status) != 0:
			set_of_HALT.add(int_status)

def CheckingExpIntCoverage(data, prev_data):
	##Check mode + value of vector/channel	
	if Enable_test_ExpInt_Mode == True:
		Checking_Mode_VctChannel(data, prev_data)

	##Check Cancel HALT + Acceptance condition
	if Enable_test_ExpInt_HALT_AccCond == True:
		Checking_HALT_AccCond(data, prev_data)

#-------------------------------------------------------------------
# ----------------------------- MAIN Function ----------------------
#-------------------------------------------------------------------
start_time = datetime.datetime.now()
print "Start Checking Coverage ExpInt: ", start_time
cforest_log = sys.argv[1:]
database.GR = {}
database.WR = {}
database.SR = {'HVCFG' : 0, 'PSWH' : 0, 'PSW' : 0, 'GMPSW' : 0, 'INTCFG' : 0, 'DIR0' : 0, 'GMCFG' : 0,'PLMR' : 0, 'GMPLMR' : 0}
				
#-------------Control mode of script--------------
Enable_test_ExpInt_Mode = True
Enable_test_ExpInt_HALT_AccCond = False

Enable_debug_HALT_AccCond_log = False
#-------------End control mode of script--------------

if Enable_test_ExpInt_Mode == True:
	ExpInt_name = 	["UCPOP0_R_+FPU", "UCPOP0_E_+FPU", "UCPOP0_R_-FPU", "UCPOP0_E_-FPU", "UCPOP1_R_+FPU", "UCPOP1_E_+FPU", "UCPOP1_R_-FPU", "UCPOP1_E_-FPU", "UCPOP2_R", "UCPOP2_E",
					"RIE_R", "RIE_E", "PIE_R", "PIE_E", "FPE_R", "FPE_E", "FXE_R", "FXE_E", "FETRAP_R", "FETRAP_E", "SYSCALL_R", "SYSCALL_E", "TRAP0_R", "TRAP0_E", "TRAP1_R", "TRAP1_E",
					"SYSERR_slave_R", "SYSERR_slave_E", "SYSERR_rb_R", "SYSERR_rb_E", "SYSERR_save_R", "SYSERR_save_E",
					"LSAB_R", "LSAB_E", "PCB_R", "PCB_E", "AE_R", "AE_E", "DBINT_R", "DBINT_E", "DBNMI_R", "DBNMI_E", "DBTRAP_R", "DBTRAP_E", "MAE_R", "MAE_E", "FENMI_R", "FENMI_E",
					"FEINT_R", "FEINT_E", "EIINT_R", "EIINT_E", "EITBL_R", "EITBL_E", "GMFEINT_R", "GMFEINT_E", "GMEIINT_R", "GMEIINT_E", "GMEITBL_R", "GMEITBL_E", "BGFEINT_R", "BGFEINT_E", "BGEIINT_R", "BGEIINT_E"]

	ExpInt_Mode_class = database.InssExeInMode(ExpInt_name)
	##In case: config is implemented coprocessor
	str_coprocessor = "_+FPU"
	##In case: config isn't implemented coprocessor
	#str_coprocessor = "_-FPU"

	dict_Exp_Name_vct = OrderedDict([		("HVTRAP", 	[0x0,		0xF   ]),
											("FETRAP", 	[0x0,		0xF   ]),
											("SYSCALL", [0x0,  		0xFF  ]),
											("TRAP0",	[0x0, 	 	0xF   ]),
											("TRAP1",	[0x10,	 	0x1F  ])])

	##The channel value can be checked through cause code of exception
	dict_Exp_Name_channel = OrderedDict([	("DBINT", 	[0xB0,		0xBF  ]),
											("FEINT",	[0xF0,		0xFF  ]),
											("EIINT",	[0x1000,  	0x17FF]),
											("EITBL",	[0x1000, 	0x17FF]),
											("GMFEINT",	[0xF0,		0xFF  ]),
											("GMEIINT",	[0x1000,	0x17FF]),
											("GMEITBL",	[0x1000,	0x17FF]),
											("BGFEINT",	[0xD800,	0xD80F]),
											("BGEIINT",	[0xD000,	0xD7FF])])

	dict_Exp_vct_channel = dict_Exp_Name_vct.copy()
	dict_Exp_vct_channel.update(dict_Exp_Name_channel)
	ExpInt_Vct_Channel_class = ValueOfVctChannel(dict_Exp_vct_channel)

if Enable_test_ExpInt_HALT_AccCond == True:
	list_cond_check_HALT_AccCond = ["INTCFG.EPL", "GMCFG.GSYSE", "GMCFG.HMP", "GMCFG.GMP", "PSWH.GM", "DIR0.DM",
									"PSW.ID", "PSW.NP", "PSW.EIMASK = 0", "PSW.EIMASK = 15", "PSW.EIMASK = 63",
									"GMPSW.ID", "GMPSW.NP", "GMPSW.EIMASK = 0", "GMPSW.EIMASK = 15", "GMPSW.EIMASK = 63",
									"PLMR = 0", "PLMR = 15", "PLMR = 63", "GMPLMR = 0", "GMPLMR = 15", "GMPLMR = 63",
									"Int requested", "priority = 0", "priority = 15", "priority = 63", "Exp/Int occured"]
	lengthOfList_HALT_AccCond = len(list_cond_check_HALT_AccCond)
	dict_cond_check_HALT_AccCond = dict()

	list_ExpInt_name = ["EIINT", "EITBL", "GMEIINT", "GMEITBL", "BGEIINT", "FEINT", "GMFEINT", "BGFEINT",
						"SYSERR_rb", "SYSERR_slave", "SYSERR_save", "MIP_Host", "MIP_Guest", "MDP_Host", "MDP_Guest"]

	dict_HALT_AccCond = OrderedDict()
	for key_ExpInt in list_ExpInt_name:
		dict_HALT_AccCond[key_ExpInt] = dict(dict_cond_check_HALT_AccCond)

	dict_pending_Interrupt = {"DBINT": 0, "FENMI": 0, "FEINT": 0, "EIINT": 0, "BGFEINT": 0, "BGEIINT": 0, "GMFEINT": 0, "GMEIINT": 0}
	set_of_HALT = set()

if (Enable_debug_HALT_AccCond_log):
	DebugLog = "Debug_result_HALT_AccCond_log.csv"
	DebugLogControl = open(DebugLog, 'w')

ExpInt_Mode_result_file = "ExpInt_Mode_result_file.csv"
ExpInt_VctChannel_result_file = "ExpInt_VctChannel_result_file.csv"
#ExpInt_HALT_AccCond = "ExpInt_HALT_AccCond.csv"

AccumulationFile_Mode = 'Data_Accumulation_ExpInt_Mode.bk'
AccumulationFile_HALT_AccCond = 'Data_Accumulation_HALT_AccCond.bk'

Load_Backup_data()
	
for log in cforest_log:
	start_time_log = datetime.datetime.now()
	print "File: ", log, " Start Time: ", start_time_log
	raw_data = database.CollectData(log)
	#Get start and end of random code
	start_line = database.GetIndexStartRandomCode(raw_data)
	end_line = database.GetIndexEndRandomCode(raw_data)
	
	if Enable_test_ExpInt_HALT_AccCond == True:
		##Read file python to collect information of requested interrupt
		link_path = os.path.realpath(log)
		file_py_name = database.FindingLogPythonInt(link_path)
		set_Interrupt = database.DetectInterruptRequest(file_py_name)

	#database.PrintData(raw_data)		
	for line in range (start_line, end_line):
		CheckingExpIntCoverage(raw_data[line], raw_data[line - 1])
	
	del raw_data
	end_time_log = datetime.datetime.now()
	print "Time Lapse: ", (end_time_log - start_time_log)
	
"""
-------------------------------------------------------------------------
----------------------- Handle result file ------------------------------
-------------------------------------------------------------------------
"""
# Export data to CSV file
if Enable_test_ExpInt_Mode == True:
	ExpInt_Mode_class.ExportCSV(ExpInt_Mode_result_file, 'wb')
	ExpInt_Vct_Channel_class.ExportCSV(ExpInt_VctChannel_result_file, 'wb')

if Enable_test_ExpInt_HALT_AccCond == True:
	for exp_int_name, dict_cond_check_HALT_AccCond in dict_HALT_AccCond.items():
		Label = "ExpInt AccCond: " + exp_int_name
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		if exp_int_name == "EIINT" or exp_int_name == "EITBL":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "Int requested", "INTCFG.EPL", "PSWH.GM", "PSW.ID", "PSW.NP", "DIR0.DM",
												"priority = 0", "priority = 15", "priority = 63",
												"PSW.EIMASK = 0", "PSW.EIMASK = 15", "PSW.EIMASK = 63",
												"PLMR = 0", "PLMR = 15", "PLMR = 63",
												"Exp/Int occured"]			
			HandleResult_EI_int(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "GMEIINT" or exp_int_name == "GMEITBL":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "Int requested", "INTCFG.EPL", "PSWH.GM", "GMPSW.ID", "GMPSW.NP", "DIR0.DM",
												"priority = 0", "priority = 15", "priority = 63",
												"GMPSW.EIMASK = 0", "GMPSW.EIMASK = 15", "GMPSW.EIMASK = 63",
												"GMPLMR = 0", "GMPLMR = 15", "GMPLMR = 63",
												"Exp/Int occured"]
			HandleResult_GM_EI_int(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "BGEIINT":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "Int requested", "INTCFG.EPL", "PSWH.GM", "PSW.ID", "PSW.NP", "GMPSW.ID", "GMPSW.NP", "DIR0.DM",
												"priority = 0", "priority = 15", "priority = 63",
												"GMPSW.EIMASK = 0", "GMPSW.EIMASK = 15", "GMPSW.EIMASK = 63",
												"GMPLMR = 0", "GMPLMR = 15", "GMPLMR = 63",
												"Exp/Int occured"]
			HandleResult_BG_EI_int(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "FEINT":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "PSWH.GM", "PSW.NP", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_FE_int(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "GMFEINT":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "PSWH.GM", "GMPSW.NP", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_GM_FE_int(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "BGFEINT":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "PSWH.GM", "PSW.ID", "PSW.NP", "GMPSW.NP", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_BG_FE_int(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "SYSERR_rb":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "GMCFG.GSYSE", "PSWH.GM", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_Syserr_rb(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "SYSERR_slave":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "GMCFG.GSYSE", "PSWH.GM", "PSW.NP", "GMPSW.NP", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_Syserr_slave(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif exp_int_name == "SYSERR_save":
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "GMCFG.GSYSE", "PSWH.GM", "GMPSW.ID", "GMPSW.NP", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_Syserr_save(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		elif "Host" in exp_int_name:
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "GMCFG.HMP", "PSWH.GM", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_Host_MPU(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)
		else:
			dict_ExpInt_HALT_AccCond_fixed = OrderedDict()
			list_ExpInt_HALT_AccCond_toggle = [ "GMCFG.GMP", "PSWH.GM", "DIR0.DM",
												"Exp/Int occured"]
			HandleResult_Guest_MPU(dict_cond_check_HALT_AccCond, list_cond_check_HALT_AccCond, dict_ExpInt_HALT_AccCond_fixed, list_ExpInt_HALT_AccCond_toggle, Label)

	DebugLogControl.write("Cancel HALT\n")
	for item in set_of_HALT:
		for obj in item:
			if obj == "Host" or obj == "Guest":
				DebugLogControl.write(obj)
				DebugLogControl.write("\n")
			elif isinstance(obj, frozenset):
				DebugLogControl.write(str(frozenset(obj)))

Store_Backup_data()

##Limit: Can not detect for checkpoint Cancel HALT/SNOOZE: 549 -> 604
print "End Time: ", datetime.datetime.now()
print "Total Time Consume: ", (datetime.datetime.now() - start_time)