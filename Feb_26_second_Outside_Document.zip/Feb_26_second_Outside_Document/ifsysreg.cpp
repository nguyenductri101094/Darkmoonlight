#include "ifsysreg.h"
#include "rtg_cfg.h"
#include "sysreg.h"

ISysReg* ISysReg::New() {

	return new CSysReg();

}


ISysRegSet* ISysRegSet::New() {

	return (new CSysRegSet())->Default();
}


bool ISysRegSet::ParseCsv(std::string file) {
	
    std::basic_ifstream<char>        inputFile(file.data());
    std::istreambuf_iterator<char>   sin(inputFile);
    std::vector<std::string>            rec;

    std::string                      separator(",");
    std::vector<CQuote>              quotes; // Quate鐃淑わ申

	if(inputFile.fail()) {
		MSG_ERROR(0, "profile [%s] not found.\n", file.c_str());
		return false;
	}

	this->Clear();

    while ( CToolFnc::ReadCSV( rec, sin, separator, quotes) ) {
        std::vector<std::string>::iterator i;
        ISysReg* sr = ISysReg::New();
		if (sr->ParseCsvRecord (rec) != true) {
			delete sr;
			return false;
		}
		std::pair<std::map<UI32,ISysReg*>::iterator,bool> result; 
		result = m_setSr.insert(std::pair<UI32,ISysReg*>(sr->GetId(), sr));
		if (result.second != true) {
			delete sr;
			return false;
		}
    }
    
    return true;
}

/**
* @brief Check whether system register cause hazard or not
* @param sr: selID * 32 + regID
* @return true if it cause hazard
*/
bool ISysRegSet::IsHazardedSR(UI32 sr) {
    if (((sr >> 5) == 0x5 && ((sr & 0x1f) < 8 || (sr & 0x1f) > 12))/*MPU SRs*/
        || (sr == (2 * 32) + 15) /* RBCR0 */
        || (sr == (2 * 32) + 17) /* RBNR */
        || (sr == (2 * 32) + 18)  /* RBIP */
        || (sr == (1 * 32) + 0)  /* SPID */
        || (sr == (0 * 32) + 5)  /* PSW */
        || (sr == (1 * 32) + 16)  /* HVCFG */
        || (sr == (3 * 32) + 0)  /* DBGEN*/) {
        return true;
    }
    return false;
}


