#ifndef RTG_APP_H_
#define RTG_APP_H_


#include	"rtg_cfg.h"
#include	"rnd_gen.h"
#include	"ifsim_ctrl.h"
#include	"ifassembler.h"
#include	"asm_src.h"
#include	"msg_log.h"



extern std::shared_ptr<CGeneratorConfig>		g_cfg;		  
extern std::shared_ptr<CGeneratorProfile>		g_prf;		 
extern std::shared_ptr<CGeneratorProfile>		g_uprf;
extern std::unique_ptr<IAssembler>				g_asm;		//!< @brief TODO : Create via interaface.
extern std::unique_ptr<ISysRegSet>				g_srs;		 
extern std::shared_ptr<CAssemblerSourceFile>	g_asf;		 
extern std::unique_ptr<IException>             	g_exp;		//!< @brief 例外関連を管理するクラス
extern std::unique_ptr<IBlockManager>			g_mgr;		//!< @brief TODO : name g_mgr
extern std::unique_ptr<ISimulatorControl>		g_sim;		 
extern std::unique_ptr<ISimulatorHwInfo>		g_hwInfo;

#endif /*RTG_APP_H_*/
