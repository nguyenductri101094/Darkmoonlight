#ifndef IFOPERAND_H_
#define IFOPERAND_H_

#include	"rtg_common.h"
#include	"ifsimulator.h"
#include	"regulation.h"
#include	"ifvalconstraint.h"
#include	"ldd_info.h"

/**
 * @brief	オペランドを抽象化するクラス。
 *			全てのオペランドはこのインターフェースを実装する必要がある。 
 */
class IOperand {
public:
	/**
	 * @brief オペランドの属性を示す。
	 */
	typedef enum {
		OPR_ATTR_GR,		//!< @brief 汎用レジスタ属性				( 0 ->    1)
		OPR_ATTR_VR,		//!< @brief ベクトルレジスタ属性			( 1 ->    2)
		OPR_ATTR_SR,		//!< @brief システムレジスタ属性			( 2 ->    4)
		OPR_ATTR_IMM,		//!< @brief 即値属性					( 3 ->    8)
		OPR_ATTR_DST,		//!< @brief デスティネーションとなる		( 4 ->   16)
		OPR_ATTR_SRC,		//!< @brief ソースとなる					( 5 ->   32)
		OPR_ATTR_IRAM,		//!< @brief 命令アドレスを示す			( 6 ->   64)
		OPR_ATTR_SMEM,		//!< @brief ストアアドレスを示す			( 7 ->  128)
		OPR_ATTR_LMEM,		//!< @brief ロードアドレスを示す			( 8 ->  256)
		OPR_ATTR_ALABEL,	//!< @brief ラベルを絶対アドレス計算する	( 9 ->  512)
		OPR_ATTR_RLABEL,	//!< @brief ラベルを相対アドレス計算する	(10 -> 1024)
		OPR_ATTR_XDEPEND,	//!< @brief 制約が他レジスタに依存する	(11 -> 2048)
		OPR_ATTR_PAIR,		//!< @brief ペアレジスタ					(12 -> 4096)
		OPR_ATTR_LLABEL,	//!< @brief loop用のラベル計算				(13 -> 8192)
		OPR_ATTR_WR,		//!< @brief FPベクトルレジスタ属性			(14 ->16384)
		OPR_ATTR_NUM
	} OPR_ATTR;
	
	typedef enum {
		OPR_VATR_GR			= (1 << OPR_ATTR_GR),		//!< @brief 汎用レジスタ属性				(00000001h)
		OPR_VATR_VR			= (1 << OPR_ATTR_VR),		//!< @brief ベクトルレジスタ属性			(00000002h)
		OPR_VATR_SR			= (1 << OPR_ATTR_SR),		//!< @brief システムレジスタ属性			(00000004h)
		OPR_VATR_IMM		= (1 << OPR_ATTR_IMM),		//!< @brief 即値属性					(00000008h)
		OPR_VATR_DST		= (1 << OPR_ATTR_DST),		//!< @brief デスティネーションとなる		(00000010h)
		OPR_VATR_SRC		= (1 << OPR_ATTR_SRC),		//!< @brief ソースとなる					(00000020h)
		OPR_VATR_IRAM		= (1 << OPR_ATTR_IRAM),		//!< @brief 命令アドレスを示す			(00000040h)
		OPR_VATR_SMEM		= (1 << OPR_ATTR_SMEM),		//!< @brief ストアアドレスを示す			(00000080h)
		OPR_VATR_LMEM		= (1 << OPR_ATTR_LMEM),		//!< @brief ロードアドレスを示す			(00000100h)
		OPR_VATR_ALABEL		= (1 << OPR_ATTR_ALABEL),	//!< @brief ラベルを絶対アドレス計算する	(00000200h)
		OPR_VATR_RLABEL		= (1 << OPR_ATTR_RLABEL),	//!< @brief ラベルを相対アドレス計算する	(00000400h)
		OPR_VATR_XDEPEND	= (1 << OPR_ATTR_XDEPEND),	//!< @brief 制約が他レジスタに依存する	(00000800h)
		OPR_VATR_PAIR		= (1 << OPR_ATTR_PAIR),		//!< @brief ペアレジスタ					(00001000h)
		OPR_VATR_LLABEL		= (1 << OPR_ATTR_LLABEL),	//!< @brief loop用のラベル計算				(00002000h)
		OPR_VATR_WR			= (1 << OPR_ATTR_WR),		//!< @brief FPベクトルレジスタ属性			(00004000h)
		OPR_VATR_NUM
	} OPR_VATR;

	/**
	 * @brief  このオブジェクトを生成します
	 */	
	IOperand() : m_attr(0), m_bFixed(false), m_vConst(nullptr), m_way(0) {}

	/**
	 * @brief  このオブジェクトを生成します
	 * @param  bs 属性を示すビットセット
	 */	
	IOperand(std::bitset<OPR_ATTR_NUM> bs) : m_attr(bs), m_bFixed(false), m_vConst(nullptr), m_way(0) {}

	/**
	 * @brief  このオブジェクトを生成します
	 * @param  bs 属性を示すビットセット
	 * @param  pVC 値の制約オブジェクト
	 */	
	IOperand(std::bitset<OPR_ATTR_NUM> bs, IValConstraint* pVC)
		: m_attr(bs), m_bFixed(false), m_vConst(pVC), m_way(0) {}
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~IOperand() {
		delete m_vConst;
	}

	/**
	 * @brief  オペランドの属性を判定します
	 * @param  a 属性
	 * @return 指定属性にマッチする場合、真を返します
	 */	
	virtual	bool MatchAttr(std::bitset<IOperand::OPR_ATTR_NUM> a) {
		return ((a.to_ulong() & GetAttr().to_ulong()) != 0);
	}

	/**
	 * @brief  オペランドの属性を判定します
	 * @param  a 属性
	 * @return 指定属性にマッチする場合、真を返します
	 */	
	virtual	bool Attr(OPR_ATTR a) {
		return GetAttr()[a];
	}

	/**
	 * @brief  オペランド属性を取得します。
	 * @return オペランド属性
	 */	
	virtual	void SetAttr(OPR_ATTR attr, bool b = true) {
		m_attr.set(attr, b);
	}
	
	/**
	 * @brief  オペランド属性を取得します。
	 * @return オペランド属性
	 */	
	virtual	std::bitset<IOperand::OPR_ATTR_NUM> GetAttr() {
		return m_attr;
	}

	/**
	 * @brief  オペランドの制約を取得する
	 * @return 制約オブジェクト
	 */	
	virtual IValConstraint* GetConstraint() {
		return m_vConst;
	}

	/**
	 * @brief  オペランドの制約を設定する
	 * @param pconst  制約オブジェクト
	 */	
	virtual void SetConstraint(IValConstraint* pconst) {
		delete m_vConst;
		m_vConst = pconst;
	}

	/**
	 * @brief  オペランドの制約を解除する
	 * @param  制約オブジェクト
	 */	
	virtual void RemoveConstraint() {
		delete m_vConst;
		m_vConst = nullptr;
	}
	
	/**
	 * @brief  オペランドのアセンブラコードをフォーマットします(インターフェース)
	 * @return アセンブル文字列
	 */	
	virtual std::string GetCode() = 0;
	
	/**
	 * @brief  オペランドの即値部を上書きします。
	 * @param  val 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual void SetDisp(UI32 d) {};

    virtual UI32 GetDisp() { return 0; }

	/**
	 * @brief Set range of displacement
	 * @param lower/upper limitted value
	 * @return None
	 */
	virtual void SetDispRange(UI32 dh, UI32 dt) {};

	/**
	 * @brief  オペランドのアセンブラコードをフォーマットします(インターフェース)
	 * @return アセンブル文字列
	 */	
	virtual LPCTSTR GetLabel() { 
		return ((m_label.length() == 0) ? nullptr : m_label.c_str());
	}

	/**
	 * @brief  オペランドのアセンブラコードをフォーマットします(インターフェース)
	 * @return アセンブル文字列
	 */	
	virtual IOperand* SetLabel(LPCTSTR lpstr) { 
		if (lpstr && strlen(lpstr)) {
			m_label = lpstr;
		}
		return this;
	}

	/**
	 * @brief  オペランドのアセンブラコードをフォーマットします(インターフェース)
	 * @return アセンブル文字列
	 */	
	virtual IOperand* SetLabel(std::string str) { 
		return SetLabel((LPCTSTR)str.c_str());
	}

	virtual void RemoveLabel(){
		m_label = "";
	}
	
	/**
	 * @brief  ランダム選択によりオペランドの値を固定します
	 * @return このオブジェクト参照
	 */	
	virtual IOperand* Fix() { return this; };

	/**
	 * @brief Re-generate operand value
	 * @return pointer to this object.
	 */
	virtual IOperand* ReFix() {return this;};

	/**
	 * @brief  オペランドの値を上書きします。
	 * @param  index 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Replace(UI32 index) {return false;}

	/**
	 * @brief	This function replace the generating range.
	 * @param	(rh, rt) Generating range.
	 */
    virtual bool SetRange(UI32 rh, UI32 rt) {return false;}

	/**
	 * @brief  オペランドの即値部を上書きします。
	 * @param  val 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool Imm(UI32 val) { return false; }

	/**
	 * @brief  ランダム選択済であるかを取得します。
	 * @return ランダム選択済である場合、真を返す。
	 */	
	virtual bool isFixed() {return m_bFixed;}

	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual operator UI32() {return 0;}
		
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 Idx() {return 0;}

	/**
	 * @brief  wayの値を取得します。
	 * @return way情報を取得
	 */	
	virtual UI32 GetWay() { return m_way ; }

	/**
	 * @brief  wayの値を上書きします。
	 * @param  way 上書きする値
	 * @return 上書き出来た場合に真を返します。
	 */	
	virtual bool SetWay(UI32 way) { m_way = way; return true ; }

	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual UI32 IsGR() {return m_attr[OPR_ATTR_GR];}

	/**
	 *
	 *
	 */
	virtual UI32 IsWR() { return m_attr[OPR_ATTR_WR]; }

	/**
	 * @brief  find register has constraint and register was updated value in simualte part
	 * @return   operand index
	 */
	virtual UI32 GetConstraintBit () {

		UI32 UseOpr = 0;
		if(GetConstraint() != nullptr && Attr(IOperand::OPR_ATTR_GR)){
			UseOpr |= ((Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << Idx());
		}

		return UseOpr;
	}

	/**
	 * @brief find operand need to change in JARL function
	 * @return true if current operand is used in JARL instruction, false if not
	 */
	virtual bool AdjustOprInFunction(UI32 F){
		return false;
	}

	/**
	 * @brief find operand need to change in JARL function
	 * @return true if current operand is used in JARL instruction, false if not
	 */
	virtual bool Align(UI32 F){
		return false;
	}

	/**
	 * @brief  ソースレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */	
	virtual REGFLG GetGrCSrc() {
		return GetConstraint() ? GetGrSrc() : 0;
	}
	
	/**
	 * @brief  ソースレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */	
	virtual REGFLG GetGrSrc(bool regulation = false) {
		REGFLG rf = 0;
		if (Attr(OPR_ATTR_GR) && Attr(OPR_ATTR_SRC)) {
			rf = (Attr(OPR_ATTR_PAIR) ? 3 : 1) << Idx();
		}
		return rf;
	}

	/**
	 * @brief  デスティネーションレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */	
	virtual REGFLG GetGrDst() {
		REGFLG rf = 0;
		if (Attr(OPR_ATTR_GR) && Attr(OPR_ATTR_DST)) {
			rf = (Attr(OPR_ATTR_PAIR) ? 3 : 1) << Idx();
		}
		return rf;
	}
	
	/**
	 * @brief  ソースレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */	
	virtual REGFLG GetWrSrc(bool regulation = false) {
		REGFLG rf = 0;
		if (Attr(OPR_ATTR_WR) && Attr(OPR_ATTR_SRC)) {
			rf = (Attr(OPR_ATTR_PAIR) ? 3 : 1) << Idx();
		}
		return rf;
	}

	/**
	 * @brief  デスティネーションレジスタインデックスを３２ビットフラグ形式で取得する
	 * @return ３２ビットフラグ
	 */	
	virtual REGFLG GetWrDst() {
		REGFLG rf = 0;
		if (Attr(OPR_ATTR_WR) && Attr(OPR_ATTR_DST)) {
			rf = (Attr(OPR_ATTR_PAIR) ? 3 : 1) << Idx();
		}
		return rf;
	}
	

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	           lnk: generate address in link bit area
	 */
	virtual void Regulate(IRegulation* pReg, UI32 lnk) {}
	

	/**
	 * @brief  値制約の補正を行います。
	 * @param  pReg 値制約検証情報
	 */	
	virtual void Regulate(IRegulation* pReg) {
		_ASSERT(pReg);
		_ASSERT(pReg->m_pSim);
		
		//!< 値制約を持たない場合はそのままシミュレーションさせる
		if (m_vConst == nullptr) {
			return;
		}
	
		//!< ランダム成分を確定させる
		(void*)Fix();
		
		//!< シミュレータから現在の値を読む
		UI32 cur;
		if (pReg->m_pSim->ReadGrReg(&cur, (SI32)Idx(), pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		
		//!< 現状が適正値である場合はそのままシミュレーションさせる
		if (m_vConst->IsValid(cur)) {
			return;
		}

		//!< この時点で何らかの補正が必要であることが確定する。
		pReg->ReSim();

		UI64 sv = m_vConst->SelectValue();
		pReg->m_vGr.push_back(std::pair<UI32,UI32>(Idx(),(UI32)sv));
		pReg->ReAsm();
		
		return;	
	}

	/**
	 * @brief get operand of array instruction
	 */
	virtual void GetArrayInsOpr(UI32* srcReg, IOperand** pBaseOpr, IOperand** pSecOpr1, IOperand** pSecOpr2){}


	/**
	* @brief get operand is General Register and the index is not in used list
	* Update content of mUGrR
	* @param mUGrR: <RegIndex, <RegFreq, fixedFlag>>
	*/
	virtual void GetGrRegister(std::map<UI32, std::pair<UI32, bool>> *mUGrR)
	{
		UI32		nGrReg;
		std::map<UI32, std::pair<UI32, bool>>::iterator itr;

		// Check whether the operand is general register
		if(IsGR()){ // COprSP initialized regIdx is 0.
			nGrReg = this->Idx();
			itr = mUGrR->find(nGrReg);

			// Add register as new element if it is not used before yet
			if(itr == mUGrR->end())
				mUGrR->insert(std::pair<UI32, std::pair<UI32, bool>> 
				(nGrReg, std::pair<UI32, bool>(1, false)));
			else
				itr->second.first++;		// Increase register frequence if existed
		}
	}

	/**
	 * @brief replace operand is General Register and the index is not in used list
	 * @param mUsedGrReg: <RegIndex, <RegFreq, fixedFlag>>
	 */
	virtual void ReplaceOprInList(std::map<UI32, std::pair<UI32, bool>> *mUsedGrReg){

		UI32 	nRetry;
		std::map<UI32, std::pair<UI32, bool>>::iterator mItr;

		if(IsGR() && (mUsedGrReg->find(Idx()) == mUsedGrReg->end()))
		{
			// Generate random register from used list.
			mItr = mUsedGrReg->begin();
			std::advance(mItr, g_rnd.GetRange(0U, (UI32)mUsedGrReg->size() - 1));

			nRetry = 0;
			// Try to replace register.
			while(nRetry < mUsedGrReg->size() // Repeat until short of register in list.
				&& ((mItr->second.second == true) // Ignore fixed register.
				||(Replace(mItr->first) == false))) // Replace failed
			{
				mItr = next(mItr);
				if(mItr == mUsedGrReg->end())
					mItr = mUsedGrReg->begin();
				nRetry++;
			}

			/* No suitable register in used list to replace. Add register to list.*/
			if(nRetry == mUsedGrReg->size())
			{
				mUsedGrReg->insert(std::pair<UI32, std::pair<UI32, bool>> 
					(Idx(), std::pair<UI32, bool> (1, false))); // (1, false): Fake for register frequence and fixed register
			}
		}
	}

	virtual bool ReplaceIdxFromList(UI32 reglist) {
        
        std::vector<UI32> vRegList;
        if(this->Attr(IOperand::OPR_ATTR_PAIR)) {
            reglist = reglist & ((reglist & 0xaaaaaaaa) >> 1);
        }
        for(UI32 r = 1; r < 32; r++) {
            if((1 << r) & reglist) 
                vRegList.push_back(r);
            
        }

        std::random_shuffle(vRegList.begin(), vRegList.end(), g_rnd);
        while(vRegList.size()) {
            UI32 reg = vRegList.back();
            if(this->Replace(reg))
                break;
            vRegList.pop_back();
        }

        // Can not replace
        if(vRegList.size() == 0) {
            return false;
        }

        return true;
    }
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual void SetRegVal(SI32 val) {return; }
	
	/**
	 * @brief  オペランドを数値化します。
	 * @return 数値化されたオペランドを取得
	 */	
	virtual SI32 GetRegVal() {return 0;}
	/**
	 * @brief print value in of operand in DEBUG MODE
	 */
	virtual void PrintGetVal(ISimulator* m_pSim, std::stringstream& ss) {}

	/**
	 * @brief print value out of operand in DEBUG MODE
	 */
	virtual void PrintRetVal(ISimulator* m_pSim, std::stringstream& ss) {}

	/**
	 * @brief aline memory data
	 * @param PFETCHSIZE: size data will be align
	 */
	virtual void AlignData(ISimulator* m_pSim, UI32 PFETCHSIZE) {}

	/**
	 * @brief    オペランドのアセンブラコードを取得します（フレンド関数）
	 * @param  s 出力ストリーム
	 * @param  o 出力対象オブジェクト
	 * @return   出力ストリーム
	 */	
	friend	std::ostream& operator<< ( std::ostream& s, IOperand& o ) {
		if (o.GetLabel() != nullptr) {
			s << o.GetLabel();
		}else{
			s << o.GetCode();
		}
		return s;
	}
	
	/**
	 * @brief   Clarify   system register that store mismatch value between CForest and RTL
	 * @return True: System Register has mismatch value
	           False: System Register has not mismatch value
	 */
	virtual bool OprHasMismatch() { return false; }

    virtual UI32 GetBitCount() {
        return 0;
    }

protected:
	std::bitset<IOperand::OPR_ATTR_NUM>		m_attr;		//!< @brief オペランド属性
	bool									m_bFixed;	//!< @brief ランダムセレクトフラグ
	IValConstraint*							m_vConst;	//!< @brief 値の制約(i.e.汎用レジスタであればその値。インデックス値の制約ではない)
	std::string								m_label;
	UI32                                    m_way;      //!< @brief WRegのエレメントチェックフラグ
};

typedef		std::bitset<IOperand::OPR_ATTR_NUM>	BS_OPRATTR;
#endif /*IFOPERAND_H_*/
