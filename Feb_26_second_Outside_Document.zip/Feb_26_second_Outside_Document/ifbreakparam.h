#ifndef IFBREAKPARAM_H_
#define IFBREAKPARAM_H_

#include	"rtg_common.h"

/**
 * @brief 命令に対するブレークポイント設定クラス
 */
struct IBreakParam {
	public:
	/**
	 * @brief 命令に対するブレークポイント設定の属性マクロ名定義
	 */
	enum {
		BREAK_NONE,  //!< @brief ブレーク無し
		BREAK_LDB,   //!< @brief ロードデータブレーク
		BREAK_RMWB,  //!< @brief リードモディファイライトブレーク
		BREAK_RLB,   //!< @brief リレーブレーク
		BREAK_PCB,   //!< @brief プログラムカウンタブレーク
		BREAK_LSAB,  //!< @brief ロードストアアドレスブレーク
		BREAK_SDB,   //!< @brief ストアデータブレーク
		BREAK_AE,    //!< @brief アラインエラー
		BREAK_SS,    //!< @brief シングルステップブレーク
		BREAK_TYPE_NUM,
	};

	IBreakParam() : m_type(BREAK_NONE), m_addr_label(""), m_addr(0), m_data(0), m_addr_mask(0xffffffff), m_data_mask(0xffffffff), m_data_size(0), m_block_label(""), m_block_num(0) {}
	~IBreakParam() {}

	public:
	UI32 m_type; //!< @brief ブレーク種
    std::string m_addr_label; //!< @brief ブレークポイントの対象命令に付与したラベル(PCB用)
	UI32 m_addr; //!< @brief アドレス
	UI32 m_data; //!< @brief データ
	UI32 m_addr_mask; //!< @brief マスク
	UI32 m_data_mask; //!< @brief データマスク
    UI32 m_data_size;
	std::string  m_block_label;
	UI32 m_block_num; //!< @brief コードブロック先頭アドレス
};

#endif
