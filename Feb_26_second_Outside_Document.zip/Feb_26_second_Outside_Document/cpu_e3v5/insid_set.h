#ifndef INSID_SET_H_
#define INSID_SET_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"
#include	"operand.h"
#include	"instruction.h"
#include	"ifinsset.h"

class CInstructionSet : public IInstructionSet
{
public:

	/**
	 * @brief  このオブジェクトを構築します。
	 * @param  乱数発生源
	 */
	 CInstructionSet();

	/**
	 * @brief  このオブジェクトを破棄します。
	 */
	virtual ~CInstructionSet();
	
	/**
	 * @brief  全命令を同じ重みで均等に登録する。
	 */
	virtual void DefaultSet(void);

	/**
	 * @brief　カテゴリ条件に従って命令オブジェクトを構成する
	 * @return 命令オブジェクト
	 */
	virtual UI32 FilterCategory(BS_ICAT mask, BS_ICAT val);
	 	 
	/**
	 * @brief　権限条件に従って命令オブジェクトを構成する
	 * @return 命令オブジェクト
	 */
	virtual UI32 FilterPriviledge(BS_IPRV mask, BS_IPRV val);
	 	 
	/**
	 * @brief　動作条件に従って命令オブジェクトを構成する
	 * @return 命令オブジェクト
	 */
	virtual UI32 FilterBehavior(BS_IBHV mask, BS_IBHV val);
	 	 
	/**
	 * @brief　命令オブジェクトを生成する
	 * @return 命令オブジェクト
	 */
	virtual IInstruction* CreateIns();

	/**
	 * @brief　命令オブジェクトを生成する
	 * @param  ins_id 命令ID
	 * @return 命令オブジェクト
	 */
	virtual IInstruction* CreateIns(INS_ID ins_id);

	/**
	 * @brief　拡張命令オブジェクトを生成する
	 * @param  ins_id 命令ID
	 * @return 命令オブジェクト
	 */
	virtual IInstruction* CreateInsEx(INS_ID ins_id);

	/**
	 * @brief	Prepare instruction for forwarding couple
	 * @param	Instruction id in range of custom instruction
	 * @return	instruction pointer instance of Complex instruction
	 */
	virtual IInstruction* CreateForwardingIns(INS_ID ins_id);

	/**
	 * 拡張命令としてのメモリアクセス命令
 	 * 複合命令の要素となる。
 	 * 
 	 * @param	insid	命令ID
 	 * @param	mr		アクセス対象範囲(mr.first - mr.second)
 	 * @param	basereg	ベースレジスタのインデックス
	 * @param	dsreg	dst/srcレジスタのインデックス
	 */
	virtual IInstruction* CreateLdStInsEx(INS_ID insid, MEMRANGE mr, UI32 basereg, UI32 dsreg1, UI32 dsreg2);
    virtual IInstruction* CreateCAXIInsEx(INS_ID insid, MEMRANGE mr, UI32 basereg, UI32 dsreg1, UI32 dsreg2);
	virtual UI32 SetWeight(std::string str ,UI32 weight_value ) ;

	virtual void SetWeight(UI32 weight_id ,UI32 weight_value ) {
		m_wrIns.Set( weight_id, weight_value );
	}

	virtual LPCTSTR GetKey(UI32 weight_id) ;

	void Clear( void ) {
		m_wrIns.Clear();
		return ;
	}

	void ReCalc( void ) {
		m_wrIns.ReCalc();

		MakeLdIns();
		MakeStIns();
		MakeLsIns();
		MakeCaxiIns();

		return ;
	}

	void Dump( void ) ;

private:
	bool BannedLsIns(INS_ID insid);
	void MakeLdIns();
	void MakeStIns();
	void MakeLsIns();
	void MakeCaxiIns();

public:
	std::pair<UI32,UI32>		m_ldArrayNum;	//!<　@brief 拡張Load命令連続数
	std::pair<UI32,UI32>		m_stArrayNum;	//!<　@brief 拡張Store命令連続数
	std::pair<UI32,UI32>		m_lsArrayNum;	//!<　@brief 拡張Load/Store命令連続数
	std::pair<UI32,UI32>		m_sldArrayNum;	//!<　@brief 拡張Load(Short Format)命令連続数
	std::pair<UI32,UI32>		m_sstArrayNum;	//!<　@brief 拡張Store(Short Format)命令連続数
	std::pair<UI32,UI32>		m_slsArrayNum;	//!<　@brief 拡張Load/Store(Short Format)命令連続数
	std::pair<UI32,UI32>		m_caxiArrayNum;	//!<　@brief 拡張CAXI命令連続数
	std::map<UI32, std::pair<UI32,UI32>>	m_seqInsNum;//!< @brief Range of sequential general instruction
    UI32                        m_nMismatchRegSet;
protected:
	const INS_ID m_nStandardISA = 454;		//@param これより後ろは拡張命令（非ISA）
	CWeightedRandom<INS_ID>		m_ldIns;	//!<　@brief 重みつきLoad命令セレクタ
	CWeightedRandom<INS_ID>		m_stIns;	//!<　@brief 重みつきStore命令セレクタ
	CWeightedRandom<INS_ID>		m_lsIns;	//!<　@brief 重みつきLoad/Store命令セレクタ
	CWeightedRandom<INS_ID>		m_sldIns;	//!<　@brief 重みつきLoad(Short Format)命令セレクタ
	CWeightedRandom<INS_ID>		m_sstIns;	//!<　@brief 重みつきStore(Short Format)命令セレクタ
	CWeightedRandom<INS_ID>		m_slsIns;	//!<　@brief 重みつきLoad/Store(Short Format)命令セレクタ  
	CWeightedRandom<INS_ID>		m_caxiIns;	//!<　@brief 重みつきCAXI命令セレクタ  
};

#endif /*INSID_SET_H_*/
