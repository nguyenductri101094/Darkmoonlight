#include    <thread>
#include    <future>
#include    <condition_variable>
#include <sys/resource.h>
#include    <mutex>
#include    "usr_src.h"
#include	"rtg_cfg.h"
#include	"ifinstruction.h"
#include	"ifinsset.h"
#include	"ifexception.h"
#include	"weight_parser.h"
#include	"ifblk_manager.h"
#include	"codeblock.h"
#include	"assembler.h"
#include	"asm_src.h"
#include	"linker.h"
#include	"ifsim_ctrl.h"
#include	"ifvalconstraint.h"
#include	"insid_set.h"
#include	"ifsysreg.h"
#include	"sim_res.h"
#include    "dcu_manager.h"

#define     STACK_SIZE  8*1024*1024

std::shared_ptr<CGeneratorConfig>		g_cfg;			 
std::shared_ptr<CGeneratorProfile>		g_prf;			 
std::shared_ptr<CGeneratorProfile>		g_uprf;
std::unique_ptr<IAssembler>				g_asm;			
std::unique_ptr<ISysRegSet>				g_srs;			 
std::shared_ptr<CAssemblerSourceFile>	g_asf;			 
std::unique_ptr<IException>             g_exp;			//!< @brief 例外関連を管理するクラス
std::unique_ptr<IBlockManager>			g_mgr;			 
std::unique_ptr<ISimulatorControl>		g_sim;
std::vector< std::pair<MEMRANGE, UI32>> g_vSharedMem;

std::unique_ptr<ISimulatorHwInfo>						g_hwInfo;
std::unique_ptr<CAddressWeight>							g_LoadableAddr;
std::unique_ptr<CAddressWeight>							g_StorableAddr;
std::unique_ptr<CAddressWeight>							g_FetchAddr;
std::unique_ptr<CAddressWeight>							g_RmwAddr;
std::unique_ptr<CAddressWeight>							g_LnkBitAddr;
std::unique_ptr<CAddressWeight>							g_LoadableLnkAddr;
std::unique_ptr<CAddressWeight>							g_StorableLnkAddr;
std::unique_ptr<CAddressWeight>							g_RmwLnkAddr;
std::unique_ptr<CAddressWeight>							g_ExceptionAddr;
std::unique_ptr<CAddressWeight>							g_RegisterBankAddr;
std::unique_ptr<CAddressWeight>							g_CompetitiveAddr;
std::unique_ptr<CBitWeight>  							g_FlagAddr;
std::unique_ptr<TWorkMemory>						    g_wm;			//!< @brief	パタンファイルが使用するワークエリアを定義

static int	frog_init (UI32 peid, int, char**);					//!< @brief	設定ファイルを解析し、生成に必要なデータの準備、初期化を行う
static int	frog_main (UI32 peid);							//!< @brief	パタンファイルの生成処理
static int	set_address_weight(void);					//!< @brief	メモリアドレスの情報を準備するサブルーチン
static int  set_bit_weight(void);
static int	set_user_profile(void);
static int	genarate_main(UI32 peid);						//!< @brief	生成処理
static int	simulate_main(UI32 peid);						//!< @brief	シミュレーション処理
static int	post_simulation (void);						//!< @brief	シミュレーション後処理
static int	output_result(UI32 peid);						//!< @brief	出力処理
static int	show_report(clock_t t);						//!< @brief	生成情報の表示
static int  check_error(void);

static int	gen_pe_context(TBlockConfig* tbc);			
static int	gen_machine_context(TBlockConfig* tbc);		
static int	gen_thread_context(TBlockConfig* tbc);		
static void *frog_thread(void *p);
static std::string get_input(std::string &tmpl, UI32 peid);
static bool flush_header(std::string& stdOutputAsm);
static bool flush_multicore(std::string& stdOutputAsm);
static bool flush_input_files(std::string& filename);

//std::string CLabel::m_prefix("frog_P00");				//!< @brief TODO : 定義位置

std::shared_ptr<CUserSourceFile>		g_usf;
struct thread_param {
    int argc;
    char **argv;
    int ret;
    std::condition_variable *pcvInit;
    std::condition_variable *pcvFinish;
    UI32 peid;
};

/**
 * app main
 * 
 */
int main (int argc, char** argv) {
    std::condition_variable         cvInit;
    std::mutex                      mtxInit;
    std::unique_lock<std::mutex>    lckInit(mtxInit);
    std::condition_variable         cvFinish;
    std::mutex                      mtxFinish;
    std::unique_lock<std::mutex>    lckFinish(mtxFinish);

    // Create thread of FROG generation
    pthread_attr_t attr;
    pthread_t threadId;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
    if(pthread_attr_setstacksize(&attr, STACK_SIZE) != 0) {
        MSG_ERROR(0, "Can not set stacksize for FROG generation thread.\n");
    }
    // parse command line parameters.
    g_cfg = std::make_shared<CGeneratorConfig>();
    if (g_cfg->Parse(argc, argv) != true) {
        return (EXIT_FAILURE);
    }
    g_cfg->RenameOutfile();

    // Output file header
    if (!flush_header(g_cfg->m_strOutputAsm)) {
        MSG_ERROR(0, "File I/O : %s\n", g_cfg->m_strOutputAsm.c_str());
        return (EXIT_FAILURE);
    }

    if (g_cfg->m_vPeId.size() > 1) {
        // output source & linkmap
        if (!flush_multicore(g_cfg->m_strOutputAsm)) {
            MSG_ERROR(0, "File I/O : %s\n", g_cfg->m_strOutputAsm.c_str());
            return (EXIT_FAILURE);
        }
    }

    thread_param param;
    void *thread_status;
    // Create threads for generation
    // Initialize thread params
    param.argc = argc;
    param.argv = argv;
    param.pcvInit = &cvInit;
    param.pcvFinish = &cvFinish;
    param.ret = EXIT_SUCCESS;
    //param.peid = g_cfg->m_vPeId[n];
    if (pthread_create(&threadId, &attr, frog_thread, (void*)&param) != 0) {
        MSG_ERROR(0, "Can not create FROG generation thread.\n");
        exit(EXIT_FAILURE);     // Exit process and terminate async thread
    }

    //Waiting for FROG executing with timeout
    if (cvFinish.wait_for(lckFinish, std::chrono::seconds(g_cfg->m_nTimeout)) == std::cv_status::timeout) {
        MSG_ERROR(0, "FROG generation was timeout.\n");
        exit(EXIT_FAILURE);     // Exit process and terminate async thread
    }

    // Free attribute and wait for the other threads
    pthread_attr_destroy(&attr);
    pthread_join(threadId, &thread_status);

    // Attach input files to assembly (.S) file
    if (!flush_input_files(g_cfg->m_strOutputAsm)) {
        MSG_ERROR(0, "File I/O : %s\n", g_cfg->m_strOutputAsm.c_str());
        return (EXIT_FAILURE);
    }

    // Get return code, then return
    return param.ret;	
}

static void *frog_thread(void *p) {
    int		retCode		= EXIT_SUCCESS;
    clock_t		tm_start	= clock();
    thread_param *pParam = (thread_param *)p;

    for (UI32 n = 0; n < g_cfg->m_vPeId.size(); n++) {
        pParam->peid = g_cfg->m_vPeId[n];   // Temporary until support generating multi-cores simultaneously
        if ((retCode = frog_init(pParam->peid, pParam->argc, pParam->argv)) != EXIT_SUCCESS) {
            break;
        }

        if ((retCode = frog_main(pParam->peid)) != EXIT_SUCCESS) {
            break;
        }

        if ((retCode = show_report(tm_start)) != EXIT_SUCCESS) {
            break;
        }

        // Check error
        if ((retCode = check_error()) != EXIT_SUCCESS) {
            break;
        }
    }

    pParam->ret = retCode;
    pParam->pcvFinish->notify_one();

    pthread_exit(NULL);
    return nullptr;
}

/**
 * setup app
 * 
 */
static int frog_init (UI32 peid, int argc, char** argv)
{
    // Set Work PE
    g_cfg->m_nPeWorkIdx = peid;

	// user source file
	g_usf = std::make_shared<CUserSourceFile>();
    std::string strUserCode(get_input(g_cfg->m_strUsercode, peid));
    g_usf->SetFile(strUserCode);
	
	// parse user profile
	g_uprf = std::make_shared<CGeneratorProfile>();
	if (g_uprf->LoadProfile(g_cfg->m_strUserProfile) != true) {
		return (EXIT_FAILURE);
	}

	// parse master configuration files
	if (g_uprf->LoadMasterFile() != true) {
		return (EXIT_FAILURE);
	}

	// parse profile
	g_prf = std::make_shared<CGeneratorProfile>();
    std::string strProfile(get_input(g_cfg->m_strProfile, peid));
	if (g_prf->LoadProfile(strProfile) != true) {
		return (EXIT_FAILURE);
	}

	// overwirte user's profile
	if (set_user_profile() != EXIT_SUCCESS) {
		return (EXIT_FAILURE);
	}

	// set seed
    UI32 seed = g_cfg->m_nSeed + peid;
    g_rnd.Seed(&seed);
	
	// create output-file
	g_asf = std::make_shared<CAssemblerSourceFile>();

	// initialize assembler
	std::unique_ptr<IAssembler> u_asm(IAssembler::New());
	g_asm = std::move(u_asm);
	g_asm->Init(IAssembler::IASM_LITTLE);

	// weight - meory access 
	if (set_address_weight() != 0 ||
		set_bit_weight() != 0) {
		return (EXIT_FAILURE);
	}

	g_asf->SetAvailableAddress(g_FetchAddr->KeySet(), CLinker::MEM_FREE_ALLOC);
	g_asf->SetAvailableAddress(g_ExceptionAddr->KeySet(), CLinker::MEM_USER_ALLOC);

	// weight - system register
	std::unique_ptr<ISysRegSet> u_srs(ISysRegSet::New());
	g_srs = std::move(u_srs);
    std::string strSrProfile(get_input(g_cfg->m_strSrProfile, peid));
	if (g_srs-> ParseCsv(strSrProfile) != true) {
		return (EXIT_FAILURE);
	}
	
	COprSR::m_pSrSource = g_srs.get();
	
	// weight - exception raise
	std::unique_ptr<IException> u_exp(IException::New());
	g_exp = std::move(u_exp);  
	g_exp->SetWeight(g_prf->GetSectionData("::EXCEPTION_GLOBAL"));
	g_exp->SetWeight(g_prf->GetSectionData("::BREAK_GLOBAL"));
	
	// weight - fpu data type
	g_prf->ConfigFpuSingletype();
	g_prf->ConfigFpuDoubletype();
	
	// initialize source-file & linker
	std::unique_ptr<IBlockManager> u_mgr(IBlockManager::New(nullptr));
	g_mgr = std::move(u_mgr);

	// check simulator initialize file
	if(g_cfg->m_strSimIni.length() == 0) {
		MSG_ERROR(0, "--sim_ini_file (file path) is mandatory.\n");
		return (EXIT_FAILURE);
	}

 	// initialize iss
 	std::unique_ptr<ISimulatorControl> u_sim(ISimulatorControl::New());
 	g_sim = std::move(u_sim);
    std::string strSimIni(get_input(g_cfg->m_strSimIni, peid));
	if(g_sim->Init(strSimIni) != true){
		return (EXIT_FAILURE);
	}

    g_hwInfo = std::make_unique<ISimulatorHwInfo>();
	g_sim->GetHwSpecification(g_hwInfo.get());
	if (g_prf->ParseMachineSetting(&g_cfg->m_mGMs) != true) {
		return (EXIT_FAILURE);
	}
		
	// Set GM num for define back/restore memory
	UI32 maxGPID =  g_cfg->m_mGMs.size() == 0 ? 0:g_cfg->m_mGMs.rbegin()->first;
	g_wm->SetMachine(g_hwInfo->m_htnum, g_hwInfo->m_vmnum, maxGPID);

    // Load MPU information
    CMmList* mpu_infor = g_mgr->GetMPUInfor();
    if (mpu_infor->LoadMpuInfo() == false) {
        return (EXIT_FAILURE);
    }

    if (g_cfg->IsEnableDCU() == true) {
        std::unique_ptr<CDcuManager> dcu = std::make_unique<CDcuManager>();
        if (dcu->DCUMain(argc, argv) == false) {
            return (EXIT_FAILURE);
        }
        g_mgr->SetHandShakeRecord(dcu->m_mHandShakeRecord);
        g_mgr->SetSelfCheckMemRange(dcu->GetSelfCheckMemRange());

        // Initialize DBG_MBINT = 0;
        const UI32 DBG_MBINT = 0xf9012070;
        g_sim->GetSimulator()->PresetMemory(true, 0, DBG_MBINT, 4, 0);
    }


	return (EXIT_SUCCESS);
}


/**
 * frog_main
 * 
 */
static int frog_main (UI32 peid)
{
	// generation
	if (genarate_main(peid)) {
		return (EXIT_FAILURE);
	}

	// simulation
	if (simulate_main(peid)) {
		return (EXIT_FAILURE);
	}
	
	// initial-val, prefetch, verify-code
	if (post_simulation()) {
		return (EXIT_FAILURE);	
	}

	// result
	if (output_result(peid)) {
		return (EXIT_FAILURE);
	}

	return (EXIT_SUCCESS);
}

	
static int genarate_main(UI32 peid) {

	TBlockConfig tbc;
	tbc.InsNum	= g_cfg->m_nINumInBlock;
	tbc.m_pSrSet= g_srs.get();
	tbc.m_bNC	= true;
    tbc.m_PEID = peid;

	MSG_INFO(0, "Generate start by seed %08x.\n", g_cfg->m_nSeed);

    if (g_cfg->m_mGMs.size()) {
        tbc.m_bGM = true;
    }

	// System Context
	gen_pe_context (&tbc);
	
	// Native Context
	gen_machine_context(&tbc);	// (NM + NT)
	
	if (g_prf->IsVmSimulation()) {
		// Virtual Context
		tbc.m_bNC = false;
		HandlerPtr		h_ptr  (g_mgr->GenerateHandler(&tbc));
		frog::for_each( h_ptr, [] (CHandlerBlock* p) {g_asf->AddNode(p);} );

		for (std::pair<UI32, GM_Infor> GMInfor : g_cfg->m_mGMs) {		
			tbc.m_GMID = GMInfor.first;
			CHandlerBlock* p = g_mgr->GenEITBLHandler(&tbc);
			g_asf->AddNode(p);
			gen_machine_context(&tbc);
			
			// Hardware Thread
			//for (tbc.m_HTID = 0/* Base + 1 */; tbc.m_HTID < 1; tbc.m_HTID++) {
				gen_thread_context(&tbc);
			//}
			CPreloadBlock* pPB = g_mgr->GenerateDebugBreakSetUpBlock(&tbc, 30);
			g_asf->AddNode(pPB);
		}
		tbc.m_bNC = true;
	} 

	if (g_asf->Link() != true) {
		MSG_ERROR(0, "Link Error!\n");
		return (EXIT_FAILURE);
	}

	// Update original code size of block for simulation
	std::vector<INode*>& rRcb = g_asf->GetCodeBlock();
	std::for_each (rRcb.begin(), rRcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	// Update original code size for preload code block
	std::vector<INode*>& rPcb = g_asf->GetPreloadBlock();
	std::for_each (rPcb.begin(), rPcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	// Update original code size for handler code block
	std::vector<INode*>& rHcb = g_asf->GetHandlerBlock();
	std::for_each (rHcb.begin(), rHcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	// Update original code size for terminate code block
	std::vector<INode*>& rTcb = g_asf->GetTerminateBlock();
	std::for_each (rTcb.begin(), rTcb.end(), [&](INode* n){
		CCodeBlock* p = static_cast<CCodeBlock*>(n);
		p->m_orgsize = p->GetCodeSize();
	});

	if (g_cfg->m_bVerbose) {
		std::ofstream ofs;
		ofs.open("label.gen");
		g_asf->PrintLabel(ofs);
		ofs.close();
	}

	return (EXIT_SUCCESS);
}


/**
 * PE　proc
 */
static int gen_pe_context (TBlockConfig* tbc) {
	
    char work[32];
    sprintf(work, "P%02d", tbc->m_PEID);

	tbc->m_bSys = true;
	
	// System Reset vector
	VectorPtr 		v_ptr  (g_mgr->GenerateIntVector(tbc));
	frog::for_each( v_ptr, [] (CVectorBlock* p) {g_asf->AddNode(p);} );
	
	UserPtr         u_ptr  (g_mgr->InsertUserCode(work , "uc_boot" , tbc, v_ptr->front()));
	frog::for_each( u_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );

	HandlerPtr h_fix_ptr  (g_mgr->GenerateFixHandlerBlock(tbc));
	frog::for_each( h_fix_ptr, [] (CHandlerBlock* p) {g_asf->AddNode(p);} );

	FunctionPtr		f_ptr(g_mgr->GenerateFunction(tbc));
    frog::for_each(f_ptr, [](CFunctionBlock* p) {g_asf->AddNode(p); });

	PreloadPtr		setup_ptr  (g_mgr->GenerateSetupBlock(tbc));
	frog::for_each( setup_ptr, [] (CPreloadBlock* p) {g_asf->AddNode(p);} );
	tbc->m_bSys = false;
	
	return (EXIT_SUCCESS);
}


/**
 * MACHINE　CODE
 */
static int gen_machine_context (TBlockConfig* tbc) {
	
    char work[32];
	if (tbc->m_bNC == true) {
        sprintf(work, "P%02dNM", tbc->m_PEID);
    } else {
		sprintf(work, "P%02dGM%02d", tbc->m_PEID, tbc->m_GMID);
	}

	VectorPtr 		v_ptr  (g_mgr->GenerateIntVector(tbc));
	frog::for_each( v_ptr, [] (CVectorBlock* p) {g_asf->AddNode(p);} );
	
	
	PreloadPtr		pre_ptr  (g_mgr->GeneratePreload(tbc));
	frog::for_each( pre_ptr, [] (CPreloadBlock* p) {g_asf->AddNode(p);} );

	if (tbc->m_bNC) {
		HandlerPtr		h_ptr  (g_mgr->GenerateHandler(tbc));
		frog::for_each( h_ptr, [] (CHandlerBlock* p) {g_asf->AddNode(p);} );
		CHandlerBlock* pHB = g_mgr->GenEITBLHandler(tbc);
		g_asf->AddNode(pHB);
		UserPtr         u_ptr  (g_mgr->InsertUserCode(work , "uc_preload" , tbc, pre_ptr->front()));
		frog::for_each( u_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
		PreloadPtr		SrInit_ptr  (g_mgr->GenerateSRsInit(tbc));
		frog::for_each( SrInit_ptr, [] (CPreloadBlock* p) {g_asf->AddNode(p);} );
		// Gerarate code for synchronized
		// Run in virtualization support
		if (tbc->m_bGM == true ) {
			SyncPtr s_ptr(g_mgr->GenerateSync(tbc));
			frog::for_each(s_ptr, [] (CSyncBlock* p) { g_asf->AddNode(p); } );
			UserPtr u_Synptr  (g_mgr->InsertUserCode(work , "uc_ht_standby" , tbc, s_ptr->front()));
			frog::for_each( u_Synptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
		}
	}

	//Chain with GM preload
	ProloguePtr		pro_ptr  (g_mgr->GeneratePrologue(tbc));
	frog::for_each( pro_ptr, [] (CPrologueBlock* p) {g_asf->AddNode(p);} );
	
	EpiloguePtr		e_ptr  (g_mgr->GenerateEpilogue(tbc));
	frog::for_each( e_ptr, [] (CEpilogueBlock* p) {g_asf->AddNode(p);} );
	
	if (tbc->m_bNC) {
	    UserPtr         c_ptr  (g_mgr->InsertUserCode(work, "uc_selfcheck_fail" , tbc, e_ptr->back()));
	    frog::for_each( c_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
	}

	TerminatePtr	t_ptr  (g_mgr->GenerateTerminateBlock(tbc));
    frog::for_each( t_ptr, [] (CTerminateBlock* p) {g_asf->AddNode(p);} );

	if (tbc->m_bNC) {
	    UserPtr         c_ptr  (g_mgr->InsertUserCode(work, "uc_terminate" , tbc, t_ptr->front()));
	    frog::for_each( c_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
    }

	// Convention mode.
	if (tbc->m_bGM == false ) {
		tbc->m_bBase = true;
		gen_thread_context(tbc);
	}else{
		// VMSimするときのNT(Random Codeblock)は実質ブランクである
		// VM遷移しVM Randomが終わればHVTRAPでNMode復帰、このとき復帰先はNM::Epilogueである
		g_mgr->ChainBlock(pro_ptr->back(), e_ptr->front());
	}
	
	return (EXIT_SUCCESS);
}


/**
 * Thread　proc
 */
static int gen_thread_context (TBlockConfig* tbc) {
	
    char work[32];
	if (tbc->m_bNC == true) {
        sprintf(work, "P%02dNMNT", tbc->m_PEID);
    } else {
       sprintf(work, "P%02dGM%02dT%02d", tbc->m_PEID, tbc->m_GMID, tbc->m_HTID);
	}

	// gerarate code for synchronized
	SyncPtr s_ptr(g_mgr->GenerateSync(tbc));
	frog::for_each(s_ptr, [] (CSyncBlock* p) { g_asf->AddNode(p); } );
	if (tbc->m_bGM == false) {
		UserPtr u_Synptr  (g_mgr->InsertUserCode(work , "uc_ht_standby" , tbc, s_ptr->front()));
		frog::for_each( u_Synptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );
	}
	// gerarate code for random test
	RandomPtr r_ptr(new RandomSet());
	for (tbc->N = 0; (tbc->N) < (g_cfg->m_nBlockNum); tbc->N++) {
		CCodeBlock* RandomBlock = g_mgr->GenerateRandomBlock(tbc);
        g_mgr->GenerateDCUHandShakeCode(RandomBlock);
		if(tbc->N == 0)
			RandomBlock->AddOpeCode(DBTAG(), 0); //! Mark it as the start of random block #Redmine#65750
		r_ptr->push_back(RandomBlock);
		g_mgr->PresetException(r_ptr->back(), g_exp.get());
	}
	
	// chaining each random block
	RandomSet::iterator i1 = r_ptr->begin();
	RandomSet::iterator i2 = r_ptr->begin();
	while ( ++i2 != r_ptr->end() ) {
		g_mgr->ChainBlock((*i1), (*i2));
		++i1;
	}
	// append random blocks.
	frog::for_each ( r_ptr, [] (CCodeBlock* p) { g_asf->AddNode(p); } );

	// Generating function block for updating MPU config
	FunctionPtr mpuFunc_ptr (g_mgr->GenerateMPUpdate(tbc));
	frog::for_each ( mpuFunc_ptr, [] (CFunctionBlock* p) { g_asf->AddNode(p); } );

	// gerarate code for synchronized
	TeSyncPtr e_ptr(g_mgr->GenerateTeSync(tbc));
	frog::for_each (e_ptr, [] (CTeSyncBlock* p) { g_asf->AddNode(p); } );
	g_mgr->ChainBlock(r_ptr->back(), e_ptr->front());
	
	UserPtr u2_ptr  (g_mgr->InsertUserCode(work , "uc_ht_complete" , tbc, e_ptr->at(1)));
	frog::for_each( u2_ptr, [] (CUserBlock* p) {g_asf->AddNode(p);} );				
	g_mgr->ChainBlock(e_ptr->front(), e_ptr->at(1));

	//Generate code for user block random
	std::vector<std::pair<std::string,UI32>> vUcRndKey;
	g_usf->GetRndKey(vUcRndKey);
	std::vector<std::pair<std::string,UI32>>::iterator itr;
	for(itr = vUcRndKey.begin(); itr != vUcRndKey.end(); itr++){
		g_asf->AddNode(g_mgr->GenerateUserBlock(work, tbc, itr->first));
	}

	// Generate user code for handler
	CCodeBlock *pCB = g_mgr->GenerateUserBlock(work, tbc, "uc_handler");
	if(pCB->GetInstructionNum() > 0)
		g_asf->AddNode(pCB);
	else
		delete pCB;

	return (EXIT_SUCCESS);
}


/**
 * simulate_main
 * 
 */
static int simulate_main (UI32 peid) {
	// place const data 
	std::vector<CCodeBlock*> v;
	g_asf->GetConstTable(v);
	if (g_sim->SetPrimitiveData(v) != true) {
		return (EXIT_FAILURE);
	}
	
	// ISS simulation
	ISimulationParam simparam(g_asf.get(), g_exp.get());
	if (g_sim->Simulation(&simparam) != true) {
		//g_asf->PrintLabel();
		g_asf->Flush(g_cfg->m_strOutputAsm, peid);
		MSG_ERROR(0, "Give up simulation.\n");
		return (EXIT_FAILURE);
	}

	return (EXIT_SUCCESS);
}


/**
 * post_simulation
 * 
 */
static int post_simulation (void) {
	
	TBlockConfig tbc;

	if (g_cfg->m_bFrontRegs) {
		std::vector<INode*>& rCb = g_asf->GetCodeBlock();
		std::for_each (rCb.begin(), rCb.end(), [](INode* node) {
			CCodeBlock* p = static_cast<CCodeBlock*>(node);
			p->FrontLoadRegulation();
		}); 
	}

	// --selfcheck
	if (g_cfg->m_strSelfCheck.length() > 0) {
		// Generate Verifier
		std::vector<INode*>& rEps = g_asf->GetEpilogueBlock(); 
		std::for_each (rEps.begin(), rEps.end(), [&](INode* n){
			CCodeBlock* p = static_cast<CCodeBlock*>(n);
			tbc.m_bNC = true;
			g_mgr->GenVerifier(p, &tbc);
            g_mgr->GenerateDCUSelfCheckCode(p);
		});
	}

	// Fetch line zeroing
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetVectorBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetHandlerBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetPreloadBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetPrologueBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetSyncBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetCodeBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetTeSyncBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetFunctionBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetEpilogueBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetTerminateBlock());
	g_mgr->FetchLineZeroing_AddOpcodeDirectly(g_asf->GetUserBlock());

	// Re-Link
	if (g_asf->Link() != true) {
		MSG_ERROR(0, "Link Error!\n");
		return (EXIT_FAILURE);
	}
	
	if (g_cfg->m_bVerbose) {
		std::ofstream ofs;
		ofs.open("label.sim");
		g_asf->PrintLabel(ofs);
		ofs.close();
	}

	return (EXIT_SUCCESS);
}


/**
 * output_result
 * 
 */
static int output_result (UI32 peid) {
	
	auto f = [](const T_MEMWRRECORD& t) {
#if 0
		if (g_prf->IsInSconst(t.first))	{
			g_asf->SetSconst(t.first, t.second.first, t.second.second);
		}
#else
		if(g_prf->IsValidMem(t.first)) {
			g_asf->SetSconst(t.first, t.second.first, t.second.second);
		}
#endif
	};

    if (g_cfg->m_bPrefAssist) {
    	// generate prefetch code
        std::vector<INode*>& sync = g_asf->GetSyncBlock();
		UI32 nNumberOfFetchBlock = 3; // RedMine #62133
	    for (std::vector<INode*>::iterator itr_s = sync.begin(); itr_s != sync.end(); itr_s++) {
            std::string name = (*itr_s)->GetName();
            UI32 pos = name.find("_PrefetchMode", 0);
            if (pos != 0xffffffff) {
                //置き換え対象となるプリフェッチコードが見付かった場合の処理
                std::string context = name.substr(0,pos);
    	        CSyncBlock * pPF = new CSyncBlock(name);
                g_mgr->AppendPrefetchCode(context, pPF);
                std::vector<INode*>& body = g_asf->GetCodeBlock();
    	        for (std::vector<INode*>::iterator itr_r = body.begin(); itr_r != body.end(); itr_r++) {
					if(nNumberOfFetchBlock == 0)
						break;
                    std::string label = (*itr_r)->GetName();
                    if (label.find(context) == 0) {
                        g_mgr->AppendPrefetchData((*itr_r)->GetAddress(), (*itr_r)->GetCodeSize(), pPF);
						nNumberOfFetchBlock--;
                    } 
    	        }
                g_mgr->AppendPrefetchData(0, 0, pPF);
    	        pPF->SetOutputFlag(true);
    	        pPF->Update();
                // replace prefetch code
    			delete *(itr_s);
    			itr_s = sync.erase(itr_s);          // itr_s = 削除された最終要素の直後を指す
    			itr_s = sync.insert(itr_s, pPF);    // itr_s = 挿入した要素を指す
            }
        }
	}

	// generate preload code by simulation result
	std::vector<T_MEMWRRECORD> mpd;
    std::vector<T_MEMWRRECORD> mpd_sysmem;
	std::vector<T_MEMWRRECORD> mpd_sharemem;
	g_sim->GetSysMemPreset(&mpd_sysmem);
	mpd_sysmem.erase ( std::remove_if(mpd_sysmem.begin(), mpd_sysmem.end(), [](T_MEMWRRECORD &t)->bool {return (!g_prf->IsValidMem(t.first));}), mpd_sysmem.end() );
    //Lambda function that gets memrecords that belongs to shared memory area.
    auto GetShareMem = [] (std::vector<T_MEMWRRECORD> &mpd_sys_mem,std::vector<T_MEMWRRECORD> &mpd_share_mem)
	{
		std::vector<T_MEMWRRECORD>::iterator itr;
		itr = mpd_sys_mem.begin();
		while(itr != mpd_sys_mem.end())
		{
			if(g_prf->IsShareMem(itr->first)){
				std::pair<UI32, UI64> r = std::pair<UI32, UI64> (itr->second.first, itr->second.second);
                mpd_share_mem.push_back(T_MEMWRRECORD(itr->first, r));
				itr = mpd_sys_mem.erase(itr);
			}
			else
				itr++;
		}
	};

    //Lambda function that appends mpd_sysmem to mpd at the beginning if memrecord is not included in mpd.
    auto AppendMemRecord = [](std::vector<T_MEMWRRECORD> &mpd,std::vector<T_MEMWRRECORD> &mpd_sys_mem)
    {
        std::vector<T_MEMWRRECORD>::iterator itr;
        std::vector<T_MEMWRRECORD>::iterator fndItr;
		itr = mpd_sys_mem.begin();
		while(itr != mpd_sys_mem.end())
		{
            fndItr = std::find_if(mpd.begin(), mpd.end(), [&](T_MEMWRRECORD mr)->bool{return (itr->first == mr.first);});
            if(fndItr != mpd.end()){
				itr = mpd_sys_mem.erase(itr);
			}
			else
				itr++;
		}
        mpd.insert(mpd.begin(), mpd_sys_mem.begin() , mpd_sys_mem.end());
    };
	GetShareMem(mpd_sysmem, mpd_sharemem);
	CPreloadBlock* pPB = g_mgr->AppendShareMemPreset(&mpd_sharemem, peid);
	pPB->SetOutputFlag(true);
	pPB->Update();
	g_asf->ReplaceCodeBlock( pPB ) ;

	g_sim->GetMemoryPresetData(&mpd) ;
    AppendMemRecord(mpd, mpd_sysmem);
	
	CPreloadBlock * pPD= g_mgr->AppendMemPresetBlock( &mpd, peid ) ;
	pPD->SetOutputFlag(true);
	pPD->Update();
	g_asf->ReplaceCodeBlock( pPD ) ;

	std::for_each (mpd.begin(), mpd.end(), f);

	printf("\n");
	MSG_INFO (0, "Generate memory init code. Code size = %d\n", pPD->GetCodeSize());
	
	// file header comment	
	//CFileHeader* pFh = new CFileHeader( XSTR(_RTG_APP_REVISION_) "(rev:" XSTR(_RTG_APP_HASHCODE_)")", g_sim->GetVersion().c_str(), RTG_CPU_ISA);
	//pFh->SetParam(g_cfg->CreateHash());
	//g_asf->AddNode(pFh);

	// Re-Link
	if (g_asf->Link() != true) {
		MSG_ERROR(0, "Link Error!\n");
		return (EXIT_FAILURE);
	}

	g_asf->RemoveDispLabel();

	// output source & linkmap
	if (!g_asf->Flush(g_cfg->m_strOutputAsm, peid)) {
		MSG_ERROR(0, "File I/O : %s\n", g_cfg->m_strOutputAsm.c_str());
		return (EXIT_FAILURE);
	}
	g_asf->LinkMap(g_cfg->m_strOutputMap, peid);
	
	return (EXIT_SUCCESS); 
}

int set_address_weight(void) {
	SectionData sd;
	SectionData::iterator sdi;
	MEMADDR start = 0, end = 0, weight=0, lnk=1;
	bool isLoad, isStore, isFetch, isTemp, isCmn, isUserCode, isLnk, isException, isRegBank, isErrorMem, isCompetitive;
	
	auto lambdaCsvParse = [&] (const CsvRow& r) -> int {
      
        isLnk = true ;
		//if (r.size() == 4) {
		//	isLnk = false ;
		//	MSG_WARN(0, "profile format warnning. memory setting need 5 param.\n");
		//} else
		if (r.size() > 6) {
			MSG_ERROR(0, "profile format error. memory setting need < 6 param.\n");
			return -1;
		}
		if (CGeneratorProfile::FindCh(r[0], ":") || CGeneratorProfile::FindCh(r[1], ":")) {
			isLoad = isStore = isFetch = isTemp = isCmn = isUserCode = isException = isRegBank = isErrorMem = isCompetitive = false;
			return 0;
		}
		isLoad	   = CGeneratorProfile::FindCh(r[2], "rR");
		isStore	   = CGeneratorProfile::FindCh(r[2], "wW");
		isFetch	   = CGeneratorProfile::FindCh(r[2], "iI");
		isTemp	   = CGeneratorProfile::FindCh(r[2], "tT");
		isCmn      = CGeneratorProfile::FindCh(r[2], "sS");
		isUserCode = CGeneratorProfile::FindCh(r[2], "uU");
		isException = CGeneratorProfile::FindCh(r[2], "eE");
		isRegBank  = CGeneratorProfile::FindCh(r[2], "bB");	
        isCompetitive = CGeneratorProfile::FindCh(r[2], "cC");
		
		try {
			if( isLnk ) {
				start 	= CToolFnc::AtoI(r[0].c_str());
				end   	= CToolFnc::AtoI(r[1].c_str());
				lnk  	= CToolFnc::AtoI(r[3].c_str());
				weight	= CToolFnc::AtoI(r[4].c_str());
				//! Get mem error atribute
				if(r.size() == 6)
					isErrorMem =( CToolFnc::AtoI(r[5].c_str()) > 0) ? true : false;
				else
					isErrorMem = false;
			} else {
				start 	= CToolFnc::AtoI(r[0].c_str());
				end   	= CToolFnc::AtoI(r[1].c_str());
				weight	= CToolFnc::AtoI(r[3].c_str());
				lnk  	= 1 ;//既存の動作
			}
		}catch (std::invalid_argument e){
			MSG_ERROR(0, "profile format error. address is not numeric.\n");
			return -1;
		}
		return 0;
	};

    g_LoadableAddr          = std::make_unique<CAddressWeight>();
    g_StorableAddr          = std::make_unique<CAddressWeight>();
    g_FetchAddr             = std::make_unique<CAddressWeight>();
    g_RmwAddr               = std::make_unique<CAddressWeight>();
    g_LnkBitAddr            = std::make_unique<CAddressWeight>();
    g_LoadableLnkAddr       = std::make_unique<CAddressWeight>();
    g_StorableLnkAddr       = std::make_unique<CAddressWeight>();
    g_RmwLnkAddr            = std::make_unique<CAddressWeight>();
    g_ExceptionAddr         = std::make_unique<CAddressWeight>();
    g_RegisterBankAddr      = std::make_unique<CAddressWeight>();
    g_CompetitiveAddr       = std::make_unique<CAddressWeight>();
    g_wm                    = std::make_unique<TWorkMemory>();

	sd = g_prf->GetSectionData("::ROM_ADDRESS");
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {

		if (lambdaCsvParse(*sdi) != 0) {
			return (EXIT_FAILURE);
		}
		if (isLoad) {
			g_LoadableAddr->Set(start, end, lnk, weight, isErrorMem);
		}
		if (isStore) {
			MSG_WARN(0, "write accessing to rom is ignored.\n");
			g_StorableAddr->Set(start, end, lnk, weight, isErrorMem);
		}
		if (isLoad && isStore) {
			g_RmwAddr->Set(start, end, lnk, weight, isErrorMem);
		}
		if (isFetch) {
            g_FetchAddr->Set(start, end, lnk, 1, isErrorMem);
		}
		if (isUserCode) {
			g_usf->SetCodeArea(start);
		}
		if (isTemp) {
			MSG_WARN(0, "use rom for temporary.\n");
		}
		if (isCmn) {
			MSG_WARN(0, "use rom for temporary.\n");
		}
		if (isException) {
			g_ExceptionAddr->Set(start, end, lnk, weight, 0);
		}
		if (isRegBank) {
			MSG_WARN(0, "Use rom for register bank.\n");
		}
		if( isLoad || isStore || isFetch || isTemp || isCmn || isUserCode ){
			weight = ( weight == 0 ) ? 1 : weight ;
			g_LnkBitAddr->Set(start, end, lnk, weight, isErrorMem);
		}
        if (isCompetitive) {
            g_CompetitiveAddr->Set(start, end, lnk, 1, isErrorMem);
        }
	}

	sd = g_prf->GetSectionData("::RAM_ADDRESS");
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		if (lambdaCsvParse(*sdi) != 0) {
			return (EXIT_FAILURE);
		}
		if (isLoad) {
			g_LoadableAddr->Set(start, end, lnk, weight, isErrorMem);
			if (lnk)
				g_LoadableLnkAddr->Set(start, end, lnk, weight, isErrorMem);
		}
		if (isStore) {
			g_StorableAddr->Set(start, end, lnk, weight, isErrorMem);
			if (lnk)
				g_StorableLnkAddr->Set(start, end, lnk, weight, isErrorMem);
		}
		if (isLoad && isStore) {
			g_RmwAddr->Set(start, end, lnk, weight, isErrorMem);
			if (lnk)
				g_RmwLnkAddr->Set(start, end, lnk, weight, isErrorMem);
		}
		if (isFetch) {
			MSG_WARN(0, "Instruction may be allocated on data ram.\n");			
			g_FetchAddr->Set(start, end, lnk, 1, isErrorMem);
		}
		if (isTemp) {
			g_wm->SetWorkArea(start, end, 1, 1);
		}
		if (isCmn) {
			g_wm->SetCommonArea(start);
		}
		if (isException) {
			g_ExceptionAddr->Set(start, end, lnk, weight, 0);
		}
        if (isCompetitive) {
            g_CompetitiveAddr->Set(start, end, lnk, 1, isErrorMem);
        }

		const UI32 BankSizeMax = (0x90 << 6);	  // maximum each bank size 0x90 and there 64 banks.
		if (isRegBank) {
			MEMADDR alignedAddr = ((start | 0x0000003f) + 1);	 // upper boundary alignment.
			if (alignedAddr >  end) {
			   MSG_WARN(0, "Invalid setting for register bank (B) area: %x - %x.\n", start, end);
			} else if ((end - alignedAddr) < BankSizeMax) {
				MSG_WARN(0, "Too small memory was set for register bank (B) area: %x - %x.\n", start, end);
			} else {
				g_RegisterBankAddr->Set(alignedAddr + BankSizeMax, end, lnk, weight, 0);
			} 
		}
		if( isLoad || isStore || isFetch || isTemp || isCmn || isUserCode ){
			weight = ( weight == 0 ) ? 1 : weight ;
			g_LnkBitAddr->Set(start, end, lnk, weight, isErrorMem);
		}
	}
	
	// check and set default
	if (g_LoadableAddr->Count() == 0) {
		g_LoadableAddr->Set(0xfe000000, 0xfeffffff, 100);
	}	
	if (g_StorableAddr->Count() == 0) {
		g_StorableAddr->Set(0xfe000000, 0xfeffffff, 100);
	}
	if (g_RmwAddr->Count() == 0) {
		g_RmwAddr->Set(0xfe000000, 0xfeffffff, 100);
	}
	if (g_FetchAddr->Count() == 0) {
		g_FetchAddr->Set(0x00000000, 0x03ffffff, 1);
	}
	g_LoadableAddr->ReCalc();
	g_StorableAddr->ReCalc();
	g_RmwAddr->ReCalc();
	g_FetchAddr->ReCalc();
	g_ExceptionAddr->ReCalc();
	g_RegisterBankAddr->ReCalc();
	g_LoadableLnkAddr->ReCalc();
	g_StorableLnkAddr->ReCalc();
	g_RmwLnkAddr->ReCalc();
	return 0;
}
static int set_bit_weight(void) {
	SectionData sd;
	SectionData::iterator sdi;
	MEMADDR addr1(0), addr2(0), lnk;
	UI8	bit1(0), bit2(0), weight(0);
	bool isLnk, isErrorMem;
	
	auto lambdaCsvParse = [&] (const CsvRow& r) -> int {
		isLnk = true ;
		//if (r.size() == 4) {
		//	isLnk = false ;
		//	MSG_WARN(0, "Profile format warnning. memory setting need 5 param.\n");
		//} else 
		if (r.size() > 6) {
			MSG_ERROR(0, "Profile format error. memory setting need <= 6 param.\n");
			return -1;
		}

		std::string::size_type s = r[0].find(':', 0);
		std::string::size_type e = r[1].find(':', 0);
		if ((s == std::string::npos) && (e == std::string::npos)) {
			addr1 = bit1 = bit2 = weight = 0;
			return 0;
		}
		try {
			if( isLnk ) {
				addr1  = (UI32)CToolFnc::AtoI(r[0].substr(0,  s).c_str());
				bit1   = (UI32)CToolFnc::AtoI(r[0].substr(s + 1).c_str());
				addr2  = (UI32)CToolFnc::AtoI(r[1].substr(0,  e).c_str());
				bit2   = (UI32)CToolFnc::AtoI(r[1].substr(e + 1).c_str());
				lnk    = (UI32)CToolFnc::AtoI(r[3].c_str());
				weight = (UI32)CToolFnc::AtoI(r[4].c_str());
				if(r.size() == 6)
					isErrorMem = ((UI32)CToolFnc::AtoI(r[5].c_str()) > 0) ? true : false;
				else
					isErrorMem = false;
			} else {
				addr1  = (UI32)CToolFnc::AtoI(r[0].substr(0,  s).c_str());
				bit1   = (UI32)CToolFnc::AtoI(r[0].substr(s + 1).c_str());
				addr2  = (UI32)CToolFnc::AtoI(r[1].substr(0,  e).c_str());
				bit2   = (UI32)CToolFnc::AtoI(r[1].substr(e + 1).c_str());
				weight = (UI32)CToolFnc::AtoI(r[3].c_str());
				lnk    = 1;//既存の動作
			}
		} catch (std::invalid_argument ex) {
			MSG_ERROR(0, "Profile format error. address or bit is not numeric.\n");
			return -1;
		}
		return 0;
	};

    g_FlagAddr = std::make_unique<CBitWeight>();
	// ROMについては現状不要(やるならTST1とわけるためにやるがやる価値は無いだろう)
	sd = g_prf->GetSectionData("::RAM_ADDRESS"); 
	for (sdi = sd.begin(); sdi != sd.end(); ++sdi) {
		if (lambdaCsvParse(*sdi) != 0) {
			return (EXIT_FAILURE);
		}
		if (weight == 0) {
			continue;
		}
		// ２バイトにまたがる指定は受け付けないでおく
		if (addr1 != addr2) {
			MSG_ERROR(0, "Bit-weight should be set in a byte. (0x%llx-0x%llx)\n", addr1, addr2);
			return -1;
		}
		if ((bit1 > bit2) || (bit1 > 7) || (bit2 > 7)) {
			MSG_ERROR(0, "Invalid bit value. (0x%llx[%d]-0x%llx[%d])\n", addr1, bit1, addr2, bit2);
			return -1;
		}
		for (UI8 b = bit1; b <= bit2; b++) {
			g_FlagAddr->Set(addr1, b, lnk, weight, isErrorMem);
		}
	}

	g_FlagAddr->ReCalc();
	return 0;
}

static int set_user_profile(void) {

	// Lambda function that overwrites the default setting by user setting
	auto OverwriteProfile = [] (std::string s)
	{
		std::string urfLabel = s;
		SectionData usd;

		urfLabel.insert(2, "OVERWRITE_");
		usd = g_uprf->GetSectionData(urfLabel);
		if (usd.size() > 0) {
			SectionData& sd = g_prf->GetSectionData(s);
			SectionData::iterator sdi, usdi;
			for (usdi = usd.begin(); usdi != usd.end(); usdi++) {
				CsvRow& ur = (*usdi);
				for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
					CsvRow& r = (*sdi);
					if (r[0] == ur[0]) {
						r = ur;
						break;
					}
				}
			}
		}
		return;
	};

	// Lambda function that replaces the default setting by user setting
	auto ReplaceProfile = [] (std::string s)
	{
		std::string urfLabel = s;
		SectionData usd;

		urfLabel.insert(2, "REPLACE_");
		usd = g_uprf->GetSectionData(urfLabel);
		if (usd.size() > 0) {
			SectionData& sd = g_prf->GetSectionData(s);
            if (sd.size() > 0) {
			    sd.clear();
			    sd.insert(sd.begin(), usd.begin(), usd.end());
            } else {
                g_prf->InsSection( s, usd );
            }
		}
	};

	OverwriteProfile("::INSTRUCTION_GLOBAL");
	OverwriteProfile("::EXCEPTION_GLOBAL");

	ReplaceProfile("::MACHINE_SETTING");
	ReplaceProfile("::ROM_ADDRESS");
	ReplaceProfile("::RAM_ADDRESS");
	ReplaceProfile("::MXU_COMMON_AREA");
	ReplaceProfile("::MPU_SETTING");

	return EXIT_SUCCESS;
}

int show_report (clock_t tm_start) {
	
	//---------------------------------------------------------------------------------
	// Reporting
	//---------------------------------------------------------------------------------
	MSG_INFO(0, "%sSuccess to generate pattern.%s\n", COUT_BRIGHT, COUT_RESET);
	MSG_INFO(0, " -> Output file         = %s\n", g_cfg->m_strOutputAsm.c_str());
	MSG_INFO(0, " -> Seed value          = 0x%08X\n", g_cfg->m_nSeed);
	MSG_INFO(0, " -> Num of blocks        = %d\n", g_cfg->m_nBlockNum * g_cfg->m_mGMs.size());
	MSG_INFO(0, " -> Num of instructions = %d\n", g_cfg->m_nBlockNum * g_cfg->m_mGMs.size() * g_cfg->m_nINumInBlock);
	MSG_INFO(0, " -> Run time            = %.3f sec\n", (double)(clock() - tm_start)/CLOCKS_PER_SEC);
	MSG_INFO(0, " -> Exception Report\n");
	g_exp->Print(std::cout);
	return EXIT_SUCCESS;
}

int check_error(void) {
    UI32 ret = EXIT_SUCCESS;
    auto PrintError = [] (CCodeBlock *pCB, IInstruction *pIns, IInstruction *pPrev, std::string&& msg) {
        std::cout << msg << std::endl;
        std::cout << "Block: " << pCB->GetLabel() << std::endl;
		if (pIns != nullptr)
			std::cout << "Instruction: " << pIns->GetOutCode() << "\tLabel: " << pIns->GetLabel() << "\tComment: " << pIns->GetComment() << std::endl;
        if (pPrev != nullptr)
            std::cout << "Previous Ins: " << pPrev->GetOutCode() << "\tLabel: " << pPrev->GetLabel() << "\tComment: " << pPrev->GetComment() << std::endl;
    };

    auto InsAffectInt = [=](IInstruction *pIns) -> UI32 {
        UI32 ins_code = 0;
        if (pIns->GetId() == INS_ID_EI) {
            ins_code = 1; // These instruction need to avoid consecutive both assert and deassert label
        }
        // Low ratio to generate this fail case
        //if (pIns->GetId() == INS_ID_DI) {
        //    ins_code = 2; // These instruction need to avoid assert label 
        //}     
        //if (pIns->GetId() == INS_ID_RESBANK) ins_code = 1;
        //if (pIns->GetId() == INS_ID_LDSR) {
        //    UI32 sr = (UI32)*(pIns->opr(0));
        //    if ((sr == (0 * 32) + 5 /*PSW*/) || (sr == (2 * 32) + 13 /*INTCFG*/) || (sr == (2 * 32) + 14 /*PLMR*/))
        //        ins_code = 5;
        //}
        return ins_code;
    };

    auto IsReadIMSR_ICSR = [](IInstruction *pIns) -> bool {
        if (pIns->GetId() == INS_ID_STSR) {
            UI32 sr = (UI32)*(pIns->opr(0));
            if ((sr == (2 * 32) + 11 /*IMSR*/)
                || (sr == (2 * 32) + 12 /*ICSR*/)) return true;
        }
        return false;
    };

    auto OccuredInt_Exp = [] (IInstruction *pIns) -> bool {
        UI32 causecode = pIns->GetException().first;
        /*if (causecode == 0 || causecode == 0x95 || causecode == 0x9d || causecode == 0x1c
            || (causecode >= 0x1000 && causecode <= 0x17FF) //GMEIINT
            || (causecode >= 0xD000 && causecode <= 0xD7FF) //BGEIINT
            || (causecode >= 0xF0 && causecode <= 0xFF) //GMFEINT
            || (causecode >= 0xD800 && causecode <= 0xD80F) //BGFEINT
            || causecode == 0xE0 || causecode == 0xBF //DBNMI
            || (causecode >= 0xB0 && causecode <= 0xBE)) //DBINT 
            return true;*/
        if (causecode != 0) return true;
        return false;
    };

    auto HasSameTypeInterrupt = [=](IInstruction *pPrev, IInstruction *pIns) -> bool {
        UI32 n = 0;
        IDirective	*pDir;
        UI32 pIns_ei_type = 0, pIns_fe_type = 0, pIns_dbint = 0, pIns_dbnmi = 0;
        UI32 pPrev_ei_type = 0, pPrev_fe_type = 0, pPrev_dbint = 0, pPrev_dbnmi = 0;
        while ((pDir = pIns->GetDirective(n)) != nullptr) {
            CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAs != nullptr) {
                if (pAs->m_name.find("eiint") != std::string::npos || pAs->m_name.find("eitbl") != std::string::npos) pIns_ei_type = 1;
                if (pAs->m_name.find("feint") != std::string::npos) pIns_fe_type = 1;
                if (pAs->m_name.find("dbint") != std::string::npos) pIns_dbint = 1;
                if (pAs->m_name.find("dbnmi") != std::string::npos) pIns_dbnmi = 1;
            }
            n++;
        }
        n = 0;
        while ((pDir = pPrev->GetDirective(n)) != nullptr) {
            CAsyncLabel *pAs = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
            if (pAs != nullptr) {
                if (pAs->m_name.find("eiint") != std::string::npos || pAs->m_name.find("eitbl") != std::string::npos) pPrev_ei_type = 1;
                if (pAs->m_name.find("feint") != std::string::npos) pPrev_fe_type = 1;
                if (pAs->m_name.find("dbint") != std::string::npos) pPrev_dbint = 1;
                if (pAs->m_name.find("dbnmi") != std::string::npos) pPrev_dbnmi = 1;
            }
            n++;
        }
        return ((pIns_ei_type | pPrev_ei_type) || (pIns_fe_type | pPrev_fe_type) || (pIns_dbint | pPrev_dbint) || (pIns_dbnmi | pPrev_dbnmi));
    };

    // Get random codeblock
	std::vector<INode*>& rCb = g_asf->GetCodeBlock();
    std::vector<INode*>::iterator itr;
    //Check consecutive interrupt
    for (itr = rCb.begin(); itr < rCb.end(); itr++) {

        CCodeBlock* p = static_cast<CCodeBlock*>(*itr);
        for (UI32 n = 0; n < p->GetInstructionNum(); n++) {
            IInstruction *pIns = p->at(n);

            // Check async label and (Instruction change interrupt status or reg IMSR) at same instruction
            if ((((InsAffectInt(pIns) == 1) && pIns->HasDeassertAsyncLabel() && pIns->HasAttrPending(IInstruction::IF_PEND_EI))
                || (IsReadIMSR_ICSR(pIns) && pIns->HasDeassertAsyncLabel())
                || (IsReadIMSR_ICSR(pIns) && !OccuredInt_Exp(pIns) && pIns->HasAssertLabel()))
                && pIns->GetValid()) {
                PrintError(p, pIns, nullptr, "Error: Consecutive interrupt request 1");
                ret = EXIT_FAILURE;
                p->Dump();
            }

            // Consecutive - Mismatch with jump instruction
            if (pIns->Behavior(IInstruction::JMP)) {
                std::string TargetJump = pIns->GetJumpTarget();
                if (TargetJump != "") {
                    UI32 TargetAddress = g_asf->SearchAddress(TargetJump);
                    IInstruction* TargetIns = p->Fetch(TargetAddress);
                    if (TargetIns != nullptr 
                        && ((pIns->HasDeassertAsyncLabel() && IsReadIMSR_ICSR(TargetIns))
                            || (pIns->HasAssertLabel() && !OccuredInt_Exp(pIns) && IsReadIMSR_ICSR(TargetIns)))) {
                        PrintError(p, pIns, nullptr, "Error: Consecutive interrupt request 2");
                        ret = EXIT_FAILURE;
                        p->Dump();
                    }
                    if (TargetIns != nullptr
                        && ((pIns->HasAssertLabel() && TargetIns->HasAssertLabel())
                            || (pIns->HasAssertLabel() && TargetIns->HasDeassertAsyncLabel() && HasSameTypeInterrupt(TargetIns, pIns))
                            || (pIns->HasDeassertAsyncLabel() && TargetIns->HasAssertLabel() && HasSameTypeInterrupt(TargetIns, pIns)))) {
                        PrintError(p, pIns, nullptr, "Error: Consecutive interrupt request 3");
                        ret = EXIT_FAILURE;
                        p->Dump();
                    }
                }
            }

            if (n > 0 && pIns->GetValid()) {
                IInstruction *pPrev = p->at(n - 1);
                IInstruction *pTwoInsAgo = (n >= 2) ? p->at(n - 2) : nullptr;
                bool isC2B1First = (pTwoInsAgo != nullptr) ? (pTwoInsAgo->InSequence(IInstruction::IF_SEQ_C2B1) && pTwoInsAgo->GetC2B1Ins() == pPrev) : false;

                //Do not check if previous instruction is Gap code
                if (pPrev->InSequence(IInstruction::IF_SEQ_GAP)) continue;

                // Check: Instruction change interrupt status --> Async label
                if ((InsAffectInt(pPrev) == 1) && pIns->HasDeassertAsyncLabel() && pIns->HasAttrPending(IInstruction::IF_PEND_EI)) {
                    PrintError(p, pIns, pPrev, "Error: Consecutive interrupt request 4");
                    ret = EXIT_FAILURE;
                    p->Dump();
                }
                // Check: Async label --> Read reg IMSR/ICSR
                if ((pPrev->HasDeassertAsyncLabel() && IsReadIMSR_ICSR(pIns))
                    || (pPrev->HasAssertLabel() && !OccuredInt_Exp(pPrev) && IsReadIMSR_ICSR(pIns))) {
                    PrintError(p, pIns, pPrev, "Error: Consecutive interrupt request 5");
                    ret = EXIT_FAILURE;
                    p->Dump();
                }
                // Check: Async label (or Async at 1st C2B1 ins) --> Async label (except: deassert - deassert)
                if (((pPrev->HasAssertLabel() || (pTwoInsAgo != nullptr && isC2B1First && pTwoInsAgo->HasAssertLabel())) && pIns->HasAssertLabel())
                    || ((pPrev->HasDeassertAsyncLabel() || (pTwoInsAgo != nullptr && isC2B1First && pTwoInsAgo->HasDeassertAsyncLabel())) && pIns->HasAssertLabel() && HasSameTypeInterrupt(pPrev, pIns))
                    || ((pPrev->HasAssertLabel() || (pTwoInsAgo != nullptr && isC2B1First && pTwoInsAgo->HasAssertLabel())) && pIns->HasDeassertAsyncLabel() && HasSameTypeInterrupt(pPrev, pIns))){
                    PrintError(p, pIns, pPrev, "Error: Consecutive interrupt request 6");
                    ret = EXIT_FAILURE;
                    p->Dump();
                }
                // Check async label at 2nd instruction in C2B1 couple
                if (pIns->HasAsyncLabel() && pPrev->GetC2B1Ins() == pIns) {
                    PrintError(p, pIns, pPrev, "Error: Consecutive interrupt request 7 - Async label at 2nd instruction in C2B1 couple ");
                    ret = EXIT_FAILURE;
                    p->Dump();
                }
                // Consecutive - Mismatch between RTL and CompRunner when enable cpu_stop. Please refer ticket #92188
                if ((g_cfg->m_cpuStopinTime != 0) && pPrev->GetId() == INS_ID_HALT && pIns->HasDeassertAsyncLabel()) {
                    PrintError(p, pIns, pPrev, "Error: Consecutive interrupt request 8");
                    ret = EXIT_FAILURE;
                    p->Dump();
                }
                
            }
        }
    }

    // Check Overwrite precision
    for (itr = rCb.begin(); itr < rCb.end(); itr++) {
        CCodeBlock* p = static_cast<CCodeBlock*>(*itr);
        if (p->CheckPrecisionOverwrite(p->GetInstructionNum()) != true) {
            PrintError(p, nullptr, nullptr, "Error: Overwrite precision error");
            ret = EXIT_FAILURE;
            p->Dump();
        }
    }

    // Check HALT not correct
    std::vector<INode*>& rTeCb = g_asf->GetTeSyncBlock();
    for (itr = rTeCb.begin(); itr < rTeCb.end(); itr++) {
        CCodeBlock* p = static_cast<CCodeBlock*>(*itr);
        // Check only code block th_end_sync
        if (p->GetLabel().find("th_end_sync_sub") == std::string::npos) {
            UI32 n = 0;
            IInstruction *pIns = p->at(n);
            if (pIns->GetValid() == false) {
                PrintError(p, pIns, nullptr, "Error: HALT not correct");
                ret = EXIT_FAILURE;
            }
        }
    }

    return ret;
}

static std::string get_input(std::string &tmpl, UI32 peid) {
    std::string::size_type idx;
    std::string strRet;
    std::string placeholder = "%peid%";
    if ((idx = tmpl.find(placeholder, 0)) != std::string::npos) {
        std::stringstream ss;
        ss << tmpl.substr(0, idx) << std::setw(2) << std::setfill('0') << peid << tmpl.substr(idx + placeholder.length());
        ss >> strRet;
    } else {
        strRet = tmpl;
    }

    return strRet;
}

static bool flush_multicore(std::string& filename) {
    std::ofstream	ofs(filename.c_str(), (std::ios::out | std::ios::app));
    if (!ofs) {
        return false;
    }

    UI32 pe_max = g_cfg->m_vPeId.back();

    ofs << "FROG_MANYCORE_GEN = 1" << std::endl;
    ofs << "\n\n" << std::endl;
    ofs << "    .global      frog_pe_reset" << std::endl;
    ofs << "    .section    .frog_pe_reset, \"ax\"" << std::endl;
    ofs << "frog_pe_reset:" << std::endl;
    ofs << "    mov              hilo(frog_pe_reset_uc),r3" << std::endl;
    ofs << "    jmp              [r3]" << std::endl;

    for (UI32& i : g_cfg->m_vPeId) {
        if (i == g_cfg->m_vPeId[0])
            ofs << "frog_pe_reset_uc_ret:" << std::endl;
        else
            ofs << "frog_P" << std::setw(2) << std::setfill('0') << i << "_pe_reset_uc_ret:" << std::endl;
    }

    ofs << "	movl             hilo(frog_pe_check) ,r3" << std::endl;
    ofs << "	jmp              [r3]" << std::endl;
    ofs << "\n\n" << std::endl;


    ofs << "    .section    .frog_pe_check, \"ax\"" << std::endl;
    ofs << "frog_pe_check:" << std::endl;
#ifdef _G4MH_
    ofs << "    stsr    0 ,r3, 2               -- PEID" << std::endl;
#elif _E3V5_
    ofs << "    stsr    5 ,r3" << std::endl;
    ofs << "    ori     0x8000 ,r3 ,r3" << std::endl;
    ofs << "    ldsr    r3 ,5               -- PSW.EBV= 1" << std::endl;
    ofs << "" << std::endl;
    ofs << "    stsr    0 ,r3 ,2            -- r3= (HTCFG0 >> 16) & 0x3f" << std::endl;
    ofs << "    shr     16 ,r3" << std::endl;
    ofs << "    andi    0x003f,r3 ,r3" << std::endl;
#endif // _G4MH_
    ofs << "    cmp    " << std::hex << pe_max << ",r3" << std::dec << std::endl;
    ofs << "    bgt    frog_outof_perange" << std::endl;
    ofs << "    mulh   4, r3" << std::endl;

    ofs << "    mov    hilo(frog_via_base), r31" << std::endl;
    ofs << "    add    r31, r3" << std::endl;
    ofs << "    ld.w   0x0[r3], r3" << std::endl;
    ofs << "    ldsr   r3 ,3 ,1               -- Setup EBASE of corresponding PE" << std::endl;
    ofs << "    jmp    [r3]                   -- jump EBASE Address" << std::endl;


    ofs << "frog_outof_perange:" << std::endl;
    ofs << "    halt" << std::endl;
    ofs << "    jr      frog_outof_perange" << std::endl;

    ofs << "frog_via_base:" << std::endl;
    for (UI32 i = 0; i < pe_max + 1; i++)
        ofs << "    .word frog_P" << std::setw(2) << std::setfill('0') << i << "NM_vector_reset" << std::endl;

    ofs << "	nop" << std::endl;
    ofs << "	nop" << std::endl;
    ofs << "	nop" << std::endl;
    ofs << "\n\n\n\n" << std::endl;

    ofs.close();

    return true;
}

static bool flush_input_files(std::string& filename) {
    std::ofstream	ofs(filename.c_str(), (std::ios::out | std::ios::app));
    if (!ofs) {
        return false;
    }
    if (g_cfg->m_bOutputEnFlag) {
        /* Attached configuration file to ASM file */
        ofs << "# ========================================================================" << std::endl;
        ofs << "#  CONFIGURATION FILE (ZIPPED) " << std::endl;
        ofs << "# ------------------------------------------------------------------------" << std::endl;
        ofs << "# To look inside encoded profile/setting files :" << std::endl;
        ofs << "# cat " << filename.c_str() << " | sed 's/^.\\{1\\}//' | uudecode -o /dev/stdout | tar xvzO" << std::endl;
        ofs << "# To get encoded profile/setting files :" << std::endl;
        ofs << "# cat " << filename.c_str() << " | sed 's/^.\\{1\\}//' | uudecode -o /dev/stdout | tar xvzk" << std::endl;
        ofs << "# ========================================================================" << std::endl;
        ofs.close();
        std::string attch_comd;

        attch_comd = "tar -zcf -";
        for (UI32 n = 0; n < g_cfg->m_vPeId.size(); n++) {
            UI32 peid = g_cfg->m_vPeId[n];
            attch_comd += " ";
            attch_comd += get_input(g_cfg->m_strProfile, peid);
            attch_comd += " ";
            attch_comd += get_input(g_cfg->m_strSrProfile, peid);
            attch_comd += " ";
            attch_comd += get_input(g_cfg->m_strSimIni, peid);
            attch_comd += " ";
            attch_comd += get_input(g_cfg->m_strUsercode, peid);
        }

        attch_comd += " | uuencode -m ";
        attch_comd += filename.substr(0, filename.find("S"));
        attch_comd += "tar.gz | sed -e 's/^/#/' >> ";
        attch_comd += filename.c_str();
        system(attch_comd.c_str());

    } else
        ofs.close();
    return true;
}

static bool flush_header(std::string& filename) {
    std::ofstream	ofs(filename.c_str(), (std::ios::out | std::ios::trunc));
    if (!ofs) {
        return false;
    }
    const int Tabs = 16;
    std::string rtgVer = XSTR(_RTG_APP_REVISION_) "(rev:" XSTR(_RTG_APP_HASHCODE_)")";
    std::string simVer = (ISimulatorControl::GetVersion()).c_str();
    std::string targ = RTG_CPU_ISA;
    std::map<std::string, std::string> *pHash = g_cfg->CreateHash();

    time_t timer;
    struct tm *t; /* local */

    timer = time(NULL);
    t = localtime(&timer);
    t->tm_year += 1900;
    t->tm_mon += 1;

    char datestr[256];
    char* week[] = {(char*)"Sun", (char*)"Mon", (char*)"Tue", (char*)"Wed", (char*)"Thu", (char*)"Fri", (char*)"Sat"};
    sprintf(datestr, "%d/%02d/%02d, %s, %02d:%02d:%02d", t->tm_year, t->tm_mon, t->tm_mday, week[t->tm_wday], t->tm_hour, t->tm_min, t->tm_sec);

    ofs << std::left << std::setfill(' ');

    ofs << "# ========================================================================" << std::endl;
    ofs << "#  Random generator - Target : " << targ << std::endl;
    ofs << "# ------------------------------------------------------------------------" << std::endl;
    ofs << "#     " << std::setw(Tabs) << "RTG Revision    " << " = " << rtgVer << std::endl;
    ofs << "#     " << std::setw(Tabs) << "SIM Revision    " << " = " << simVer << std::endl;
    ofs << "#     " << std::setw(Tabs) << "Generate Date   " << " = " << datestr << std::endl;
    ofs << "# -------------------------------------------------------------------------" << std::endl;
    ofs << "#  Parameters:" << std::endl;
    std::map<std::string, std::string>::iterator i;
    for (i = pHash->begin(); i != pHash->end(); i++) {
        ofs << "#     " << std::setw(Tabs) << i->first << " = " << i->second << std::endl;
    }
    ofs << "# ========================================================================" << std::endl;
    ofs << "\n\n" << std::endl;

    delete pHash;

    return true;
}
