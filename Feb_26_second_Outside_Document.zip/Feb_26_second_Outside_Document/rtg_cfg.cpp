#include "rtg_cfg.h"
#include "rnd_gen.h"
#include "ldd_info.h"
#include "ifvalconstraint.h"

#if defined(__GNUC__)
#include	<getopt.h>
#else
ERROR::__NEED_SUPPORTING_GETOPT__
#endif

#include "usr_src.h"
extern std::shared_ptr<CUserSourceFile>		g_usf;

#include	"ifsim_ctrl.h"
extern std::unique_ptr<ISimulatorHwInfo>	g_hwInfo;
extern std::unique_ptr<ISysRegSet>			g_srs;

LPCTCSTR RTG_TARGET	  = XSTR(_RTG_APP_TARGNAME_);		//!< @brief アプリケーション名
LPCTCSTR RTG_APP_REV  = XSTR(_RTG_APP_REVISION_);		//!< @brief アプリケーションリビジョン 
LPCTCSTR RTG_HASHCODE = XSTR(_RTG_APP_HASHCODE_);		//!< @brief アプリケーションハッシュコード
LPCTCSTR RTG_CPU_ISA  = XSTR(_RTG_APP_CPU_ISA_);		//!< @brief ターゲットアーキテクチャ

static const char* const	CMD_NAME_V_SEED			= "seed";
static const char* const	CMD_NAME_V_PEID			= "peid";
static const char* const	CMD_NAME_V_GEN_PE_NUM	= "gen_pe_num";
static const char* const	CMD_NAME_V_PE_WORK_ID	= "pe_work_index";
static const char* const	CMD_NAME_F_SIMINI		= "sim_ini_file";
static const char* const	CMD_NAME_S_SELF_CHECK	= "selfcheck";

// UserCode
static const char* const	CMD_NAME_F_UC           = "usercode";
static const char* const	CMD_NAME_F_WEIGHT_INS	= "gen_profile";
static const char* const	CMD_NAME_F_USER_PROFILE	= "user_profile";
static const char* const	CMD_NAME_F_SR_PROFILE	= "sysreg_file";
static const char* const	CMD_NAME_F_OUTPUT_ASM	= "output_asm_file";
static const char* const	CMD_NAME_B_STATISTICS	= "statistics";
static const char* const	CMD_NAME_V_BLOCK_NUM	= "block_num";
static const char* const	CMD_NAME_V_BLOCK_MIX	= "block_mix";
static const char* const	CMD_NAME_V_FETCH_SIZE	= "fetch_size";
static const char* const	CMD_NAME_V_INUM_IN_BLK	= "inum_in_block";
static const char* const	CMD_NAME_V_MAX_LOOP		= "max_loop";
static const char* const	CMD_NAME_V_MAX_REG_IN_BLK ="max_reg_in_block";
static const char* const	CMD_NAME_V_TIME_OUT		= "time_out";
static const char* const	CMD_NAME_B_REC_CODE		= "rec_code_off";
static const char* const	CMD_NAME_B_PREF			= "pref";
static const char* const	CMD_NAME_B_VERBOSE		= "verbose";
static const char* const	CMD_NAME_B_NFRONT_REGS	= "non_fc";			// HIDDEN
static const char* const	CMD_NAME_Z_VERSION		= "version";
static const char* const	CMD_NAME_B_ENABLE_OUTCFG = "no_config_out";
static const char* const	CMD_NAME_V_CPU_STOP_TIME = "cpu_stop_in_time";
static const char* const	CMD_NAME_Z_HELP			= "help";
static const char* const	CMD_NAME_B_PFSS         = "run_in_pfss";
// Option of DCU
static const char* const	CMD_NAME_B_ENABLE_DCU     = "enable_dcu";
static const char* const	CMD_NAME_V_JTAG_BLOCKNUM  = "Jtag_blockNum";
static const char* const	CMD_NAME_V_JNUM_IN_BLOCK  = "Jnum_in_block";
static const char* const	CMD_NAME_F_DCU_PROFILE    = "dcu_profile";
static const char* const	CMD_NAME_F_DCU_USERCODE   = "dcu_usercode";

bool CGeneratorConfig::Parse(int argc, char** argv, char** env) {

	int			opt;
	extern int	optind;
	extern int	opterr;
	extern int	optopt;
	
	opterr = 0; /* Don't show message in getopt.*/

	/* Retrieve parameters */
    while ((opt = getopt_long(argc, argv, optstr.c_str(), opts, NULL)) != -1) {
        switch ( opt ) {
		case 0x10:	/* seed */
			try {
				m_nSeed = CToolFnc::AtoI(optarg);
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --seed needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --seed \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;

		case 0x11:
			try {
                UI32 peid = CToolFnc::AtoI(optarg);
				if (peid > 63) {
					MSG_ERROR(0, "Invalid param : --peid needs 0-63. (%d)\n", optarg);
					return false;
				}
                m_vPeId.push_back(peid);

			} catch (std::invalid_argument) {
				MSG_ERROR(0, "Invalid param : --peid \"%s\" is not number.\n", optarg);
				return false;
			}
			break;

		case 0x12:
			try {
				m_nSysPeNum	= CToolFnc::AtoI(optarg);
				if ((m_nSysPeNum < 1) || (m_nSysPeNum > 16)) {
					MSG_ERROR(0, "Invalid param : --gen_pe_num needs 1-16. (%d)\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				MSG_ERROR(0, "Invalid param : --gen_pe_num \"%s\" is not number.\n", optarg);
				return false;
			}
			break;

		//case 0x13:
		//	try {
		//		m_nPeWorkIdx = CToolFnc::AtoI(optarg);
		//		if (m_nPeWorkIdx > 15) {
		//			MSG_ERROR(0, "Invalid param : --pe_work_index needs 0-15. (%d)\n", optarg);
		//			return false;
		//		}
		//	} catch (std::invalid_argument) {
		//		MSG_ERROR(0, "Invalid param : --pe_work_index \"%s\" is not number.\n", optarg);
		//		return false;
		//	}
		//	break;
			
		case 0x20:	/* user code file */
			if (strncmp(optarg, "--", 2)==0) {
				MSG_ERROR(0, "Invalid param : --usercode needs parameter.\n", optarg);
				return false;
			}
			m_strUsercode = optarg;
			//g_usf->SetFile(m_strUsercode);
			break;
			
		case 0x30:	/* sim_ini_file */
			if (strncmp(optarg, "--", 2)==0) {
				MSG_ERROR(0, "Invalid param : --sim_ini_file needs parameter.\n", optarg);
				return false;
			}
			m_strSimIni = optarg;
			break;

		case 0x31:	/* weight_ins_file */
			if (strncmp(optarg, "--", 2)==0) {
				MSG_ERROR(0, "Invalid param : --gen_profile needs parameter.\n", optarg);
				return false;
			}
			m_strProfile = optarg;
			break;

		case 0x32:	/* weight_ins_file */
			if (strncmp(optarg, "--", 2)==0) {
				MSG_ERROR(0, "Invalid param : --sysreg_file needs parameter.\n", optarg);
				return false;
			}
			m_strSrProfile = optarg;
			break;
				
		case 0x33:	/* output_asm_file */
			if (strncmp(optarg, "--", 2)==0) {
				MSG_ERROR(0, "Invalid param : --output_asm_file needs parameter.\n", optarg);
				return false;
			}
			m_strOutputAsm = optarg;
			break;
				
		case 0x34:	/* output_asm_file */
			m_bStatistics = true;
 			break;
						
		case 0x40:	/* block_num */
			try {
				if ((m_nBlockNum = CToolFnc::AtoI(optarg)) == 0) {
					MSG_ERROR(0, "Invalid param : --block_num is 0.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --block_num needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --block_num \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;
						
		case 0x41:	/* block_mix */
			try {
				if ((m_nBlockMix = CToolFnc::AtoI(optarg)) > 2) {
					MSG_ERROR(0, "Invalid param : --block_mix is 0-2.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --block_mix needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --block_mix \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;
			
		case 0x42:	/* inum_in_block */
			try {
				if ((m_nINumInBlock = CToolFnc::AtoI(optarg)) == 0) {
					MSG_ERROR(0, "Invalid param : --inum_in_block is 0.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --inum_in_block needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --inum_in_block \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;			
			
		case 0x43:	/* max_loop */
			try {
				if ((m_nMaxLoop = CToolFnc::AtoI(optarg)) < 0) {
					MSG_ERROR(0, "Invalid param : --max_loop is 0 or more.\n", optarg);
					return false;
				}
				if (m_nMaxLoop > 64) {
					MSG_ERROR(0, "Invalid param : --max_loop is too big. (0 - 64)\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --max_loop needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --max_loop \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;	
		case 0x44: /* max_reg_in_block */
			try {
				if((m_nMaxRegInBlock = CToolFnc::AtoI(optarg)) < 0) {
					MSG_ERROR(0, "Invalid param : --max_reg_in_block is not specified \n", optarg);
					return false;
				}
				if(m_nMaxRegInBlock <= 0 || m_nMaxRegInBlock > 32) {
					MSG_ERROR(0, "Invalid param : --max_reg_in_block must be in range (1-32)\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --max_reg_in_block needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --max_reg_in_block \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;
		case 0x45:	/* prefetch */
            m_bPrefAssist = true;
			break;

		case 0x51:	/* selfcheck */
			// and結合で1文字単位でチェックする
			if ((std::strchr(optarg, 'G') == NULL) &&
				(std::strchr(optarg, 'g') == NULL) &&
				(std::strchr(optarg, 'V') == NULL) &&
				(std::strchr(optarg, 'v') == NULL) &&
				(std::strchr(optarg, 'S') == NULL) &&
				(std::strchr(optarg, 's') == NULL) &&
				(std::strchr(optarg, 'M') == NULL) &&
				(std::strchr(optarg, 'm') == NULL) )
			{
				MSG_ERROR(0, "Invalid param : --selfcheck \"%s\" is invalid sub-option.\n", optarg);
				return false;
			}
			m_strSelfCheck = optarg;
			break;

		case 0x52:	/* verbose */
			m_bVerbose = true;
			break;
			
		case 0x53:	/* non front-loading regulation */
			m_bFrontRegs = false;
			break;

		case 0x54:
			m_strUserProfile = optarg;
			break;

		case 0x55:
			try {
				if ((m_nFetchSize = CToolFnc::AtoI(optarg)) == 0) {
					MSG_ERROR(0, "Invalid param : --fetch_size is 0.\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --fetch_size needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --fetch_size \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;	
			
		case 0x56:
			m_bRecCode = false;
			break;

		case 0x57: /* time_out */
			try {
				if((m_nTimeout = CToolFnc::AtoI(optarg)) < 0) {
					MSG_ERROR(0, "Invalid param : --time_out is not specified \n", optarg);
					return false;
				}
				if(m_nTimeout <= 0) {
					MSG_ERROR(0, "Invalid param : --time_out must be a positive number\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --time_out needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --time_out \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;

		case 0x58: /* cpu_stop_in_time*/
			try {
				if((m_cpuStopinTime = CToolFnc::AtoI(optarg)) < 0) {
					MSG_ERROR(0, "Invalid param : --cpu_stop_in_time is not specified \n", optarg);
					return false;
				}
				if(m_cpuStopinTime <= 0) {
					MSG_ERROR(0, "Invalid param : --cpu_stop_in_time must be a positive number\n", optarg);
					return false;
				}
			} catch (std::invalid_argument) {
				if (strncmp(optarg, "--", 2)==0) {
					MSG_ERROR(0, "Invalid param : --cpu_stop_in_time needs parameter.\n", optarg);
				} else {
					MSG_ERROR(0, "Invalid param : --cpu_stop_in_time \"%s\" is not number.\n", optarg);
				}
				return false;
			}
			break;
        case 0x59:
            m_bRunInPFSS = true;
            break;

		case 0x60:
            m_bEnableDcu = true;
            break;
        case 0x61:
        case 0x62:
        case 0x63:
        case 0x64:
            break;

		case 0xFD:
			m_bOutputEnFlag = false;
			break;

		/* Special Case*/
		case ':':
			  MSG_ERROR(0, "Invalid param : %s need argument.\n", argv[optind - 1]);
			  return false;
			  
		case '?':
			  if (optopt) {
			  	MSG_ERROR(0, "Invalid param : %s need argument.\n", argv[optind - 1]);
			  } else {
			  	MSG_ERROR(0, "Unknown param : \"%s\".\n", argv[optind - 1]);
			  }
			  return false;
		case 0xFE:
			PrintVersion(std::cout);
			return false;

		case 0xFF:
        default:
			Usage(std::cout);
			return false;
        }
    }

	if (m_nSeed == 0) {
		m_nSeed  = CUniformedRandom().Get();
	}
	g_rnd.Seed((void*)&m_nSeed); // TODO:乱数系統一

    if (m_vPeId.size() == 0)
        m_vPeId.push_back(0);
    std::sort(m_vPeId.begin(), m_vPeId.end());
    m_nPeWorkIdx = m_vPeId[0];

	return true;
}

void CGeneratorConfig::RenameOutfile() {
	std::string::size_type idx;
	
	std::string placeholder = "%seed%";
	if ((idx = m_strOutputAsm.find(placeholder, 0))!= std::string::npos) {
		std::stringstream ss;
		ss << m_strOutputAsm.substr(0, idx) << std::hex  << std::setw(8) << std::setfill('0') << m_nSeed << m_strOutputAsm.substr(idx + placeholder.length());
		ss >> m_strOutputAsm;
	}
	m_strOutputMap = m_strOutputAsm;
	std::string::size_type pos( m_strOutputMap.rfind('.') );
	if (pos != std::string::npos) {
		m_strOutputMap = m_strOutputMap.substr (0, pos) + ".x";
	}else{
		m_strOutputMap += ".x";
	}
	return;
}

std::ostream& CGeneratorConfig::Print(std::string* str, std::ostream& o) {
	
	static const int align = 20;
	static const std::string header("-- ");
	static const std::string separater(" : ");
	
	if (str != NULL && str->length()) {
		for (int i = 0; ; i++) {
			if (!strcmp(opts[i].name, str->c_str())) {
				return o;
			}
		}
		o << "Unknown parameter : " << str << std::endl;
		return o;
	}

	o << std::setfill(' ') << std::left;
	o << header << std::setw(align) << CMD_NAME_V_SEED << separater << "0x" << std::hex << m_nSeed << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_PEID << separater << m_vPeId[0] << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_GEN_PE_NUM << separater << m_nSysPeNum << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_PE_WORK_ID << separater << m_nPeWorkIdx << std::endl;
	o << header << std::setw(align) << CMD_NAME_F_WEIGHT_INS << separater << m_strProfile << std::endl;
	o << header << std::setw(align) << CMD_NAME_F_USER_PROFILE << separater << m_strUserProfile << std::endl;
	o << header << std::setw(align) << CMD_NAME_B_REC_CODE << separater << m_bRecCode << std::endl;
	o << header << std::setw(align) << CMD_NAME_F_SR_PROFILE << separater << m_strSrProfile << std::endl;
	o << header << std::setw(align) << CMD_NAME_F_OUTPUT_ASM << separater << m_strOutputAsm << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_BLOCK_NUM << separater << std::hex << m_nBlockNum << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_INUM_IN_BLK << separater << std::hex << m_nINumInBlock << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_FETCH_SIZE << separater << std::hex << m_nFetchSize << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_MAX_LOOP << separater << std::hex << m_nMaxLoop << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_MAX_REG_IN_BLK << separater << std::hex << m_nMaxRegInBlock << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_TIME_OUT << separater << std::hex << m_nTimeout << std::endl;
	o << header << std::setw(align) << CMD_NAME_F_UC << separater << g_usf->GetFilePath() << std::endl;
	o << header << std::setw(align) << CMD_NAME_B_PREF << separater << std::hex << m_bPrefAssist << std::endl;
	o << header << std::setw(align) << CMD_NAME_S_SELF_CHECK << separater << m_strSelfCheck << std::endl;
	o << header << std::setw(align) << CMD_NAME_B_VERBOSE << separater << (m_bVerbose?"ON":"OFF") << std::endl;
	o << header << std::setw(align) << CMD_NAME_B_STATISTICS << separater << (m_bStatistics?"ON":"OFF") << std::endl;
	o << header << std::setw(align) << CMD_NAME_B_ENABLE_OUTCFG << separater << (m_bOutputEnFlag?"ON":"OFF") << std::endl;
	o << header << std::setw(align) << CMD_NAME_V_CPU_STOP_TIME << separater << std::hex << m_cpuStopinTime << std::endl;
	//o << header << std::setw(align) << CMD_NAME_B_NFRONT_REGS << separater << (m_bFrontRegs?"ON":"OFF") << std::endl; // HIDDEN
    o << header << std::setw(align) << CMD_NAME_B_PFSS << separater << m_bRunInPFSS << std::endl;
	return o;
}

std::map<std::string,std::string>* CGeneratorConfig::CreateHash( ) {
	
	std::map<std::string,std::string>* phash = new std::map<std::string,std::string>();

	char	buffer[128];
	sprintf(buffer, "%08X", m_nSeed);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_SEED), std::string(buffer)));
    sprintf(buffer, "%d", m_vPeId[0]);
    for (UI32 n = 1; n < m_vPeId.size(); n++) {
        sprintf(&buffer[strlen(buffer)], "\t%d", m_vPeId[n]);
    }
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_PEID), std::string(buffer)));
	sprintf(buffer, "%d", m_nSysPeNum);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_GEN_PE_NUM), std::string(buffer)));
	sprintf(buffer, "%d", m_nPeWorkIdx);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_PE_WORK_ID), std::string(buffer)));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_F_SIMINI), std::string(m_strSimIni)));
	//phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_F_UC), std::string(g_usf->GetFilePath())));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_F_WEIGHT_INS), std::string(m_strProfile)));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_F_USER_PROFILE), std::string(m_strUserProfile)));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_F_SR_PROFILE), std::string(m_strSrProfile)));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_F_OUTPUT_ASM), std::string(m_strOutputAsm)));
	sprintf(buffer, "%d", m_nBlockNum);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_BLOCK_NUM), std::string(buffer)));
	if (m_nBlockMix == 0) sprintf(buffer, "%d (Free generation)", m_nBlockMix);
	else if (m_nBlockMix == 1) sprintf(buffer, "%d (Focus 1 reg)", m_nBlockMix);
	else if (m_nBlockMix == 2) sprintf(buffer, "%d (Interlace 2 reg)", m_nBlockMix);
	else sprintf(buffer, "%d(Free generation)", m_nBlockMix);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_BLOCK_MIX), std::string(buffer)));
	sprintf(buffer, "%d", m_nINumInBlock);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_INUM_IN_BLK), std::string(buffer)));
	sprintf(buffer, "%d", m_nFetchSize);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_FETCH_SIZE), std::string(buffer)));
	sprintf(buffer, "%d", m_nMaxLoop);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_B_REC_CODE), std::string((m_bRecCode) ? "ON" : "OFF")));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_MAX_LOOP), std::string(buffer)));
	sprintf(buffer, "%d", m_nMaxRegInBlock);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_MAX_REG_IN_BLK), std::string(buffer)));
	sprintf(buffer, "%d", m_nTimeout);
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_V_TIME_OUT), std::string(buffer)));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_B_PREF), std::string((m_bPrefAssist) ? "ON" : "OFF")));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_B_VERBOSE), std::string((m_bVerbose) ? "ON" : "OFF")));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_S_SELF_CHECK), std::string(m_strSelfCheck)));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_B_STATISTICS), std::string((m_bStatistics) ? "ON" : "OFF")));
	phash->insert(std::pair<std::string,std::string>(std::string(CMD_NAME_B_ENABLE_OUTCFG), std::string((m_bOutputEnFlag) ? "ON" : "OFF")));
    phash->insert(std::pair<std::string, std::string>(std::string(CMD_NAME_B_PFSS), std::string((m_bRunInPFSS) ? "ON" : "OFF")));

	return phash;
}

void CGeneratorConfig::Usage(std::ostream& o) {

	using namespace std;
	
	cout << endl << COUT_BLUE << COUT_UNDERLINE << "APPS INFO" << COUT_RESET;
	cout << endl << "       " << RTG_TARGET << " with " << RTG_CPU_ISA << " (" << RTG_APP_REV << ")";
	cout << endl;
	
	cout << endl << COUT_BLUE << COUT_UNDERLINE << "USAGE" << COUT_RESET;
	cout << endl << "       " << "Prompt$ > ./" << RTG_TARGET << " [--options [arg] ...]";
	cout << endl;
	
	cout << endl << COUT_BLUE << COUT_UNDERLINE << "OPTIONS" << COUT_RESET;
	cout << endl;
	cout << endl << "  " << COUT_BRIGHT  << "(1) file i/o" << COUT_RESET;
	//--------------"0---------1---------2---------3---------4---------5---------6---------7---------8---------9---------A-
	cout << setfill(' ') << left;
	UI32 tbs = 16;
	cout << endl << "     --" << setw(tbs) << CMD_NAME_F_UC << setw(tbs) << "(file path)" << ": Insert user code.";
	
	cout << endl << "     --" << setw(tbs) << left << CMD_NAME_F_WEIGHT_INS << setw(tbs) << "(file path)" << ": Specify generation profile (instruction, memory, exception...)";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_F_SR_PROFILE << setw(tbs) << "(file path)"<< ": Specify system register setting";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_F_USER_PROFILE << setw(tbs) << "(file path)" << ": Specify user profile file";
	cout << endl;
	cout << endl << "     --" << setw(tbs) << CMD_NAME_B_REC_CODE << setw(tbs) << "(ON/OFF)"<< ": Specify recovery code for jump into unexpected branch target";
	cout << endl;
	cout << endl << "     --" << setw(tbs) << CMD_NAME_F_OUTPUT_ASM << setw(tbs) << "(file path)" << ": Specify output file. Placeholder %seed% for seed value";
	cout << endl;
	cout << endl << "     --" << setw(tbs) << CMD_NAME_B_STATISTICS << setw(tbs) << "(file path)" << ": Specify statistics file.";
	cout << endl;
	
	cout << endl << "  " << COUT_BRIGHT << "(2) genereation config" << COUT_RESET;

	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_PEID << setw(tbs) << "(Number)" <<         ": Specify PEID (0-63). For gereating unique label on multicore mode.";
	//cout << endl << "     --" << setw(tbs) << CMD_NAME_V_GEN_PE_NUM << setw(tbs) << "(Number)" <<   ": Specify Total Number of PE (0-63). For gereating sync-code.";
	//cout << endl << "     --" << setw(tbs) << CMD_NAME_V_PE_WORK_ID << setw(tbs) << "(Number)" <<   ": Specify work buffer id (0-15).";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_SEED << setw(tbs) << "(Number)" <<         ": Specify random seed. Frog automatically set value if given ZERO.";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_BLOCK_NUM << setw(tbs) << "(Number)" <<    ": Number of blocks. (default 16)";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_BLOCK_MIX << setw(tbs) << "(Number)" <<    ": Mix type. 0:free-generation, 1:focus-1reg, 2:interlace-2reg(default). ";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_INUM_IN_BLK << setw(tbs) << "(Number)" <<  ": Number of instruction in block. (default 40)";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_FETCH_SIZE << setw(tbs) << "(Number)" <<	": Size of fetch line. (default 64)";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_MAX_LOOP << setw(tbs) << "(Number)" <<     ": Set max count for loop. (default 3)";
	cout << endl << "	  --" << setw(tbs) << CMD_NAME_V_MAX_REG_IN_BLK << setw(tbs) << "(Number)" << ": Set max register used in each random code block.";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_V_TIME_OUT << setw(tbs) << "(Number)" << ": Set timeout of execution.";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_S_SELF_CHECK << setw(tbs) << "[GSVM]" <<     ": Generate selfcheck code (G:greg, S:sysreg, V:vreg, M:memory).";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_B_PREF << setw(tbs) << "          " <<       ": Generate prefetch code before random simulation.";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_B_VERBOSE << setw(tbs) << "          " <<    ": Save generation log.";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_Z_VERSION << setw(tbs) << "          " <<    ": Version.";
	cout << endl << "     --" << setw(tbs) << CMD_NAME_B_ENABLE_OUTCFG << setw(tbs) << "          " <<    ": Enable Output configuration";
    cout << endl << "     --" << setw(tbs) << CMD_NAME_B_PFSS << setw(tbs) << "          " << ": Specify PFSS environment";
	cout << endl;
	
	cout << endl;

	return;
}

void CGeneratorConfig::PrintVersion(std::ostream& o) {
	o << RTG_TARGET << " with " << RTG_CPU_ISA << " v" << RTG_APP_REV << "(rev: " << RTG_HASHCODE << ")" << std::endl;
}

// static {
const std::string
CGeneratorConfig::optstr("x10:x20:x21:x22:x23:x40:x41:x42:");//"s:w:v:t:e:p:x::i::u:r:o:q:ay:gb::d::f:j:c:k:n:1:mlh\xc0\xc1");

const struct option
CGeneratorConfig::opts[] = {
	{CMD_NAME_V_SEED,   	required_argument, NULL, 0x10},
	{CMD_NAME_V_PEID,       required_argument, NULL, 0x11},
	{CMD_NAME_V_GEN_PE_NUM, required_argument, NULL, 0x12},
	{CMD_NAME_V_PE_WORK_ID, required_argument, NULL, 0x13},
	{CMD_NAME_F_UC, 		required_argument, NULL, 0x20},
	{CMD_NAME_F_SIMINI,		required_argument, NULL, 0x30},
	{CMD_NAME_F_WEIGHT_INS,	required_argument, NULL, 0x31},
	{CMD_NAME_F_SR_PROFILE, required_argument, NULL, 0x32},
	{CMD_NAME_F_OUTPUT_ASM, required_argument, NULL, 0x33},
	{CMD_NAME_B_STATISTICS, no_argument,       NULL, 0x34},
	{CMD_NAME_V_BLOCK_NUM,	required_argument, NULL, 0x40},
	{CMD_NAME_V_BLOCK_MIX,	required_argument, NULL, 0x41},
	{CMD_NAME_V_INUM_IN_BLK,required_argument, NULL, 0x42},
	{CMD_NAME_V_MAX_LOOP,	required_argument, NULL, 0x43},
	{CMD_NAME_V_MAX_REG_IN_BLK, required_argument,NULL,0x44},
	{CMD_NAME_B_PREF,	    no_argument,       NULL, 0x45},
	{CMD_NAME_S_SELF_CHECK, required_argument, NULL, 0x51},
	{CMD_NAME_B_VERBOSE,    no_argument,       NULL, 0x52},
	{CMD_NAME_B_NFRONT_REGS,no_argument,       NULL, 0x53},
	{CMD_NAME_F_USER_PROFILE, required_argument, NULL, 0x54},
	{CMD_NAME_V_FETCH_SIZE,	required_argument, NULL, 0x55},
	{CMD_NAME_B_REC_CODE,	no_argument, NULL, 0x56},
	{CMD_NAME_V_TIME_OUT,	required_argument,   NULL, 0x57},
	{CMD_NAME_V_CPU_STOP_TIME, required_argument, NULL, 0x58}, 
    {CMD_NAME_B_PFSS,	    no_argument,   NULL, 0x59},
    {CMD_NAME_B_ENABLE_DCU,	no_argument,   NULL, 0x60},
    {CMD_NAME_V_JTAG_BLOCKNUM,	required_argument,   NULL, 0x61},
    {CMD_NAME_V_JNUM_IN_BLOCK,	required_argument,   NULL, 0x62},
    {CMD_NAME_F_DCU_PROFILE,	required_argument,   NULL, 0x63},
    {CMD_NAME_F_DCU_USERCODE,	required_argument,   NULL, 0x64},
	{CMD_NAME_B_ENABLE_OUTCFG, no_argument,    NULL, 0xFD},
	{CMD_NAME_Z_VERSION,	no_argument,       NULL, 0xFE},
	{CMD_NAME_Z_HELP,		no_argument,       NULL, 0xFF},
	{NULL, 0, NULL, 0}
};
// } static

////////////////////////////////////////////////////////////////////////////////////////////
// CGeneratorProfile
////////////////////////////////////////////////////////////////////////////////////////////

CGeneratorProfile::~CGeneratorProfile() {
}


bool CGeneratorProfile::IsSectionKey(std::string& str){
	return str.compare(0, 2, "::", 2) == 0;
}


bool CGeneratorProfile::LoadProfile(std::string& filepath) {
	std::ifstream	ifs(filepath);
    const std::string 	separator(",");
    SectionData			secdata;
    
    if(ifs.fail()) {
    	if (filepath.length() == 0) {
    		return true;
    	}else{
    		MSG_ERROR(0, "profile [%s] not found.\n", filepath.c_str());
    	}
    	return false;
    }
    
    // Cvs splitter
    while (ifs.eof() != true) {
    	std::string  line;
    	getline(ifs, line);
    	CsvRow&& row = Split(line, std::string("//"));
    	if (row.empty()) {
    		continue;
    	}
    	line = row[0];
    	row.clear();
    	if ( (row = Split(line, std::string(","))).size() > 0) {
    		secdata.push_back(row);
    	}
    }
    
    // Section distribute
    SectionData::iterator i;
    SectionData part;
    SectionName name("");
    for (i = secdata.begin(); i != secdata.end(); i++) {
    	if (((*i).size()==1) && (IsSectionKey((*i)[0]) == true)) {
   			if ((m_sec.insert( Section(name, part) ).second) != true) {
   				SectionData vpre = m_sec[name];
   				vpre.insert(vpre.end(), part.begin(), part.end());
   				m_sec.erase(name);
   				m_sec.insert( Section(name, vpre) );
   			}
   			part.clear();
   			name = (*i)[0];
    	}else{
    		part.push_back(*i);
    	}
    } 
    if (part.empty() == false) {
  		if ((m_sec.insert( Section(name, part) ).second) != true) {
			SectionData vpre = m_sec[name];
			vpre.insert(vpre.end(), part.begin(), part.end());
			m_sec.erase(name);
			m_sec.insert( Section(name, vpre) );
		}
    }
    
	return true;
}

bool CGeneratorProfile::LoadMasterFile() {
	SectionData sd;
	SectionData::iterator sdi;

	sd = GetSectionData("::INCLUDE");
	if (sd.size() > 0) {
		for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
			CsvRow& r = (*sdi);
			std::string& str = r[1];
			std::string::size_type index = 0;
			while(index < str.length()){
				index = str.find(std::string("${"), index);
				std::string::size_type end_index = str.find(std::string("}"), index);
				if((index != std::string::npos) && (end_index != std::string::npos)){
					std::string item = str.substr(index, end_index-index+1);
					char *env = getenv(item.substr(2, item.length()-3).c_str());
					std::string str_env = "";
					if (env != NULL) {
						str_env = env;
						if (str_env[str_env.length()-1] == '/') {
							str_env.pop_back();
						}
					}
					str.replace(index, item.length(), str_env);
					index += str_env.length();
				}
			}

			if (r[0] == "MASTER_WEIGHT") {
				g_cfg->m_strProfile = r[1];
			}
			else if (r[0] == "MASTER_SREG") {
				g_cfg->m_strSrProfile = r[1];
			}
			else if (r[0] == "MASTER_INI") {
				g_cfg->m_strSimIni = r[1];
			}
		}
	}

	return true;
}

CsvRow CGeneratorProfile::Split(std::string& src, const std::string& key){
    CsvRow v;
    std::string str = src;
    std::string::size_type index = 0;
    while(index < str.length()){
        std::string::size_type oldindex = index;
        index = str.find( key, index);
        if(index != std::string::npos){
            std::string item = str.substr(oldindex, index - oldindex);
            v.push_back(Trim(item));
        }else{
            std::string item = str.substr(oldindex);
            v.push_back(Trim(item));
            break;
        }
        index += key.length();
    }
    return v;
}

bool CGeneratorProfile::FindCh(const std::string& str, const char* ch) {
	return std::strpbrk(str.c_str(), ch);
}

std::string CGeneratorProfile::Trim(const std::string& str) {
    std::string::const_iterator head = str.begin();
    std::string::const_iterator tail = str.end();
    if (str.length() < 1) {   
        return std::string("");
    }

    while (isspace(*head)) {   
        head++;
    }   
    if (head != tail) {   
        do {
            tail--;
        } while (isspace(*tail));
        tail++;
    }
    return std::string(head, tail);
}

SectionData& CGeneratorProfile::GetSectionData(const std::string& s) {
	static SectionData dummy;
	if (m_sec.find(s) != m_sec.end()) {
		return m_sec[s];
	} 
	return dummy;
}

void CGeneratorProfile::InsSection(const SectionName& s, const SectionData& sd) {
    m_sec.insert( Section(s, sd) );
}

//! ＰＥにＶＭ試験が指定されていたら true を返す。
bool CGeneratorProfile::IsVmSimulation () {
	return (g_cfg->m_mGMs.size());
}

//! 指定したＶＭにマルチスレッド試験が指定されていたら true を返す。
bool CGeneratorProfile::IsMtSimulation (UI32 vcid) {
	SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
	
    char work[16];    
    sprintf(work ,"VM#%d" ,vcid);
	std::string _cM (work);

    for (SectionData::iterator i = sd.begin(); i != sd.end(); i++) {
    	std::string contextM	= (*i)[0];          // NM / VM#n  (Native machine / Virtual machine[n])
    	std::transform(contextM.begin(), contextM.end(), contextM.begin(), toupper);
       	if ( contextM == _cM ) {
            if ((*i).size() > 1) {
     	        std::string modeM = (*i)[1];        // ST / MT  (Single thread / Multi thread)
       	        std::transform(modeM.begin(), modeM.end(), modeM.begin(), toupper);
                if (modeM == "MT") {
                    return true ;
                }
        	}
    	}
    }
    return false ;
}

//! 指定したスレッドにユーザモード試験が指定されていたら true を返す。
bool CGeneratorProfile::IsUserMode (bool isGm, UI32 gmid) {
	
    if (isGm == false) {
        SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
        if (sd[0][3] == "UM") return true;
    } else {
        std::map<UI32, GM_Infor>::iterator itr;
        itr = g_cfg->m_mGMs.find(gmid);
        if (itr->second.thread_mode == "UM") return true;
    }
	
	return false;
}

// 指定したＶＭのマスタースレッドの同期待ちおよび終了待ち番号を返す
// （ＶＭのマスタースレッドは重み設定ファイルによるユーザ指定。デフォルト値はベーススレッドの同期待ちおよび終了待ち番号とする。）
UI32 CGeneratorProfile::GetMasterThreadNo (UI32 vcid) {

	SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
	
    char work[16];    
    sprintf(work ,"VM#%d" ,vcid);
	std::string _cM (work);

    UI32 count = 0;
    UI32 baseTh = sd.size();
    for (SectionData::iterator i = sd.begin(); i != sd.end(); i++) {
    	std::string contextM	= (*i)[0];       // NM / VM#n  (Native machine / Virtual machine[n])
    	std::transform(contextM.begin(), contextM.end(), contextM.begin(), toupper);
       	if ( contextM == _cM ) {
            baseTh = std::min(baseTh,count);
            if ((*i).size() >= 5) {
                std::string masterTh = (*i)[4];  // MasterThread  ( FALSE / TRUE )
        	    std::transform(masterTh.begin(), masterTh.end(), masterTh.begin(), toupper);
                if (masterTh == "TRUE") {
                    return count;
                }
        	}
    	}
    	if (contextM.compare(0, 3, "VM#") == 0) {
            count++;
    	}
    }
    if (baseTh == sd.size()) {
        baseTh = 0 ;
    }
    return baseTh ;
}

// 指定したスレッドの同期待ちおよび終了待ち番号を返す
UI32 CGeneratorProfile::GetWaitThreadNo (UI32 htid) {

	SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));

    char work[16];    
    sprintf(work ,"HT#%d" ,htid);
	std::string _cHT (work);
	std::string _cM  ("VM");
	
    UI32 count = 0;
    SectionData::iterator i;
    for (i = sd.begin(); i != sd.end(); i++) {
    	std::string contextM	= (*i)[0]; // NM / VM#n  (Native machine / Virtual machine[n])
    	std::string contextHT	= (*i)[2]; // NT / HT#n  (Native thread / hardware thread[n])
    	std::transform(contextM.begin(), contextM.end(), contextM.begin(), toupper);
    	if (contextM.compare(0, 2, _cM) == 0) {
        	if ( contextHT == _cHT ) {
        		break ;
        	}
            count++;
    	}
    }

    return count ;
}

// 指定したPE中で同期待ち、終了待ちを行なうスレッド数
UI32 CGeneratorProfile::GetWaitThreadNum () {
	
	SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
    
	std::string _cM  ("VM");
	
    UI32 count = 0;
    SectionData::iterator i;
    for (i = sd.begin(); i != sd.end(); i++) {
    	std::string contextM = (*i)[0]; // NM / VM#n  (Native machine / Virtual machine[n])
    	std::transform(contextM.begin(), contextM.end(), contextM.begin(), toupper);
    	if (contextM.compare(0, 2, _cM) == 0) {
            count++;
    	}
    }
    if (count == 0) {
        count = 1;
    }
    
	return count;
}

void CGeneratorProfile::PrintMachineSetting () {
	SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
    SectionData::iterator i;
    
    MSG_ERROR(0, "====================================\n");

    char work[256];
    for (i = sd.begin(); i != sd.end(); i++) {
        UI32 count = 0;
        UI32 j;
        for (j = 0; j < (*i).size() - 1; j++) {
    	    count += sprintf(work+count ,"%s , " , (*i)[j].c_str());
        }
    	count += sprintf(work+count ,"%s" , (*i)[j].c_str());
    	MSG_ERROR(0, "%s\n" , work);
    }
}


class CompMachineSetting {
public:
    bool operator()(std::vector<std::string> p1, std::vector<std::string> p2) {
        UI32 v1 = std::atoi(p1[2].c_str() + 3);
        UI32 v2 = std::atoi(p2[2].c_str() + 3);
        return (v1 < v2) ; 
    }
};


bool CGeneratorProfile::ParseMachineSetting (std::map<UI32, GM_Infor>* GMs) {
	
	SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
    SectionData::iterator i;
    UI32 temp_htid = 0;
    // ThreadContextのチェック
    for (i = sd.begin(); i != sd.end(); i++) {
        std::string contextH = (*i)[2];
        if (contextH != "NT") {
    	    if (contextH.compare(0, 3, "HT#") != 0) {
    		    MSG_ERROR(0, "%s is Illigal.\n", contextH.c_str());
                PrintMachineSetting ();
                return false ;
            }
            temp_htid = std::atoi(contextH.c_str() + 3);
            if (temp_htid == 0) {
                if (contextH.find_first_not_of( "0" , 3 ) != std::string::npos) {
    		        MSG_ERROR(0, "%s is Illigal number.\n", contextH.c_str());
                    PrintMachineSetting ();
                    return false ;
                }
            }
            if (temp_htid >= g_hwInfo->m_htnum) {
    		    MSG_ERROR(0, "%s is Over then HT_NUM (= %d).\n", contextH.c_str() ,g_hwInfo->m_htnum);
                PrintMachineSetting ();
                return false ;
            }
        }
    }

    // ThreadContext順にソート
    std::sort(sd.begin() , sd.end() ,CompMachineSetting());


    GMs->clear();
	UI32 region = 0;
	UI32 master_count = 0;
	std::string contextM, sub_contextM;
    UI32 init_hvcfg = g_srs->GetNcInit(16, 1);

    auto SetMachineSetting = [&](CsvRow data) -> bool {
        GM_Infor gm_infor;
        gm_infor.GMID = std::atoi(data[0].c_str() + 3);
        gm_infor.machine_mode = data[1];
        gm_infor.thread_context = data[2];
        gm_infor.thread_mode = data[3];
        gm_infor.master_thread = (data[4] == "FALSE") ? false : true;
        if (GMs->insert(std::make_pair(gm_infor.GMID, gm_infor)).second == false) {
            return false;
        }
        return true;
    };

    if (sd[0][0] == "CV") {
        if ((init_hvcfg & 0x1) != 0) {
            MSG_ERROR(0, "%s is set when HVCFG.HVE = 1 \n", contextM.c_str());
            PrintMachineSetting();
            return false;
        }
        if (sd[0][3] == "HV") {
            MSG_WARN(0, "Convention mode don't have HV privilege \n");
            sd[0][3] = "SV";
        }
        if (sd.size() > 1) {
            MSG_ERROR(0, " Do not set another machine when set Convention mode");
            PrintMachineSetting();
            return false;
        }
        return true;
    }


	for (i = sd.begin(); i != sd.end(); i++) {
		contextM = (*i)[0];
		sub_contextM = contextM.substr(0,3);

		UI32 temp_gmid = 0;
		std::string temp_threadmode("");
        
        if (sub_contextM == "GM#") {
            if ((init_hvcfg & 0x1) == 0) {
                MSG_ERROR(0, "%s is set when HVCFG.HVE = 0 \n", contextM.c_str());
                PrintMachineSetting();
                return false;
            }

			temp_threadmode = (*i)[3];
			if (temp_threadmode == "HV") {
				MSG_WARN(0, "Guest mode don't have HV privilege \n");
				(*i)[3] = "SV";
			}

			temp_gmid = std::atoi(contextM.c_str() + 3);
			if (temp_gmid >= g_hwInfo->m_gmnum) {
				MSG_ERROR(0, "%s is Over then GM_NUM (= %d) .\n", contextM.c_str(), g_hwInfo->m_gmnum);
				PrintMachineSetting();
				return false;
			}
            if (SetMachineSetting(*i) == false) {
                MSG_ERROR(0, "Duplicate Machine Context %s.\n", contextM.c_str());
                PrintMachineSetting();
            }
		} else {
			MSG_ERROR(0, "%s is Illigal.\n", contextM.c_str());
			PrintMachineSetting();
			return false;
		}

		// MasterThreadの重複設定チェック
		if (((*i).size() > 4) && ((*i)[4] == "TRUE")) {
			master_count++;
			if (master_count > 1) {
				MSG_ERROR(0, "MasterThread is Defined in multiple %s.\n", (*i)[0].c_str());
				PrintMachineSetting();
				return false;
			}
		}
	}
	temp_htid++;
	while (region < 8) {
		region++;
		m_btid[region] = temp_htid;
	}
	return true;
}

/**
*  @brief check memory range from addr to (addr + size) have belong to load memory or not.
*  @return true if it belong to load memory
*/
bool CGeneratorProfile::IsLoadMem(MEMADDR addr, UI32 size) {
    CAddressWeight*	aw = g_LoadableAddr.get();
    std::set<MEMRANGE> memList = aw->KeySet();
    MEMADDR end_addr = addr + size;

    std::set<MEMRANGE>::iterator itr;
    for (itr = memList.begin(); itr != memList.end(); itr++) {
        if (itr->first <= addr && end_addr <= itr->second)
            return true;
    }
    return false;
};


bool CGeneratorProfile::IsInSconst (MEMADDR a) {
	SectionData& sd = GetSectionData(std::string("::ROM_ADDRESS"));
    SectionData::iterator sdi;
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		CsvRow& r = (*sdi);
		MEMADDR start 	= CToolFnc::AtoI(r[0].c_str());
		MEMADDR end   	= CToolFnc::AtoI(r[1].c_str());
		bool	isData	= FindCh (r[2], "rwRW");
		if (isData) {
			if (a >= start && a <=end) {
				return true;
			}
		}
	}
	return false;
}
bool CGeneratorProfile::IsValidMem(MEMADDR addr) {
    const UI32 DBG_MBINT = 0xf9012070;
    if (addr == DBG_MBINT) return true;

	SectionData& sdROM = GetSectionData(std::string("::ROM_ADDRESS"));
    SectionData::iterator sdi;
	for (sdi = sdROM.begin(); sdi != sdROM.end(); sdi++) {
		CsvRow& r = (*sdi);
		MEMADDR start 	= CToolFnc::AtoI(r[0].c_str());
		MEMADDR end   	= CToolFnc::AtoI(r[1].c_str());
		if (addr >= start && addr <=end) {
			return true;
		}
	}

	SectionData& sdRAM = GetSectionData(std::string("::RAM_ADDRESS"));
	for (sdi = sdRAM.begin(); sdi != sdRAM.end(); sdi++) {
		CsvRow& r = (*sdi);
		if(r[0].find(':', 0) == std::string::npos && r[1].find(':', 0) == std::string::npos)
		{
			MEMADDR start 	= CToolFnc::AtoI(r[0].c_str());
			MEMADDR end   	= CToolFnc::AtoI(r[1].c_str());
			if (addr >= start && addr <= end) {
				return true;
			}
		}
	}
	return false;
}
bool CGeneratorProfile::IsShareMem(MEMADDR addr){
	SectionData& sd = GetSectionData(std::string("::RAM_ADDRESS"));
    SectionData::iterator sdi;
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		CsvRow& r = (*sdi);
		bool	isData	= FindCh (r[2], "sS");
		if (isData) {
			if(r[0].find(':', 0) == std::string::npos && r[1].find(':', 0) == std::string::npos)
			{
				MEMADDR start 	= CToolFnc::AtoI(r[0].c_str());
				MEMADDR end   	= CToolFnc::AtoI(r[1].c_str());
				if (addr >= start && addr <= end) 
					return true;
			}
		}
	}
	return false;
}

/**
* @brief check memory has belong to I area or not.
* @return true if addr belong to I area
*/
bool CGeneratorProfile::IsFetchMem(MEMADDR addr) {
    CAddressWeight*	aw = g_FetchAddr.get();
    std::set<MEMRANGE> memList = aw->KeySet();

    std::set<MEMRANGE>::iterator itr;
    for (itr = memList.begin(); itr != memList.end(); itr++) {
        if (itr->first <= addr && addr <= itr->second)
            return true;
    }
    return false;
}
bool CGeneratorProfile::IsCompetitiveMem(MEMADDR addr) {

    CAddressWeight*	aw = g_CompetitiveAddr.get();
    std::set<MEMRANGE> memList = aw->KeySet();

    std::set<MEMRANGE>::iterator itr;
    for (itr = memList.begin(); itr != memList.end(); itr++) {
        if (itr->first <= addr && addr <= itr->second)
            return true;
    }
    return false;
}

bool CGeneratorProfile::IsTempMem(MEMADDR addr){
	SectionData& sd = GetSectionData(std::string("::RAM_ADDRESS"));
    SectionData::iterator sdi;
	for (sdi = sd.begin(); sdi != sd.end(); sdi++) {
		CsvRow& r = (*sdi);
		bool	isData	= FindCh (r[2], "tT");
		if (isData) {
			if(r[0].find(':', 0) == std::string::npos && r[1].find(':', 0) == std::string::npos)
			{
				MEMADDR start 	= CToolFnc::AtoI(r[0].c_str());
				MEMADDR end   	= CToolFnc::AtoI(r[1].c_str());
				if (addr >= start && addr <= end) 
					return true;
			}
		}
	}
	return false;
}

// FPU_S data type
bool CGeneratorProfile::ConfigFpuSingletype() {
	static FpuTypeWeight fpuSingleWeight(&g_rnd);
	SectionData& sd = GetSectionData(std::string("::FPU_SINGLE_DATA_TYPE"));
	CFpuWeightParam *pFPUParam;
	std::vector<CFpuWeightParam*> vFPU;
	
	if (sd.size() == 0) {
		IFpuSingleConstraint::pst_WrType = &fpuSingleWeight;
		IFpuSingleConstraint::vst_FPUParam = vFPU;
		return true;
	}
	
    SectionData::iterator i;	// 1行データ

    // ThreadContextのチェック
    for (i = sd.begin(); i != sd.end(); i++) {
    	CsvRow& r = (*i);
		pFPUParam = new CFpuWeightParam();

        if (r[0] == "+QNaN") {
			pFPUParam->m_exponent_min = 0xff;
			pFPUParam->m_exponent_max = 0xff;
			pFPUParam->m_fraction_min = 0x400000;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-QNaN") {
			pFPUParam->m_exponent_min = 0xff;
			pFPUParam->m_exponent_max = 0xff;
			pFPUParam->m_fraction_min = 0x400000;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+SNaN") {
			pFPUParam->m_exponent_min = 0xff;
			pFPUParam->m_exponent_max = 0xff;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0x3fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-SNaN") {
			pFPUParam->m_exponent_min = 0xff;
			pFPUParam->m_exponent_max = 0xff;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0x3fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+ZERO") {
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-ZERO") {
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+INFINITE") {
			pFPUParam->m_exponent_min = 0xff;
			pFPUParam->m_exponent_max = 0xff;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-INFINITE") {
			pFPUParam->m_exponent_min = 0xff;
			pFPUParam->m_exponent_max = 0xff;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+SUBNORMAL") {
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-SUBNORMAL") {
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+NORMAL") {
			pFPUParam->m_exponent_min = 0x1;
			pFPUParam->m_exponent_max = 0xfe;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-NORMAL") {
			pFPUParam->m_exponent_min = 0x1;
			pFPUParam->m_exponent_max = 0xfe;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else{
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0xff;
        	pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0x7fffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_RANDOM;
        }
		pFPUParam->m_name = r[0];
		pFPUParam->m_id = vFPU.size() + 1;
		pFPUParam->m_weight = CToolFnc::AtoI(r[1].c_str());
		if(r.size() >= 3)
			pFPUParam->m_fraction_and = CToolFnc::AtoI(r[2].c_str());
		if(r.size() >= 4)
			pFPUParam->m_fraction_or = CToolFnc::AtoI(r[3].c_str());
		if(r.size() >= 5)
			pFPUParam->m_exponent_and = CToolFnc::AtoI(r[4].c_str());
		if(r.size() >= 6)
			pFPUParam->m_exponent_or = CToolFnc::AtoI(r[5].c_str());
		if(r.size() >= 7)
			pFPUParam->m_max_noise = CToolFnc::AtoI(r[6].c_str());
		vFPU.push_back(pFPUParam);
    }
	
	fpuSingleWeight.SetWeight(vFPU);
	IFpuSingleConstraint::pst_WrType = &fpuSingleWeight;
	IFpuSingleConstraint::vst_FPUParam = vFPU;
	
	return true;
}


// FPU_D data type
bool CGeneratorProfile::ConfigFpuDoubletype() {
	static FpuTypeWeight fpuDoubleWeight(&g_rnd);
	SectionData& sd = GetSectionData(std::string("::FPU_DOUBLE_DATA_TYPE"));
	CFpuWeightParam *pFPUParam;
	std::vector<CFpuWeightParam*> vFPU;
	
	if (sd.size() == 0) {
		IFpuDoubleConstraint::pst_WrType = &fpuDoubleWeight;
		IFpuDoubleConstraint::vst_FPUParam = vFPU;
		return true;
	}
	
    SectionData::iterator i;	// 1行データ

    // ThreadContextのチェック
	for (i = sd.begin(); i != sd.end(); i++) {
    	CsvRow& r = (*i);
		pFPUParam = new CFpuWeightParam();
		pFPUParam->m_exponent_min = 0;
		pFPUParam->m_exponent_max = 0x7ff;
		pFPUParam->m_exponent_and = 0x7ff;
    	pFPUParam->m_fraction_min = 0;
		pFPUParam->m_fraction_max = 0xfffffffffffff;
		pFPUParam->m_fraction_and = 0xfffffffffffff;

        if (r[0] == "+QNaN") {
			pFPUParam->m_exponent_min = 0x7ff;
			pFPUParam->m_exponent_max = 0x7ff;
			pFPUParam->m_fraction_min = 0x8000000000000;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-QNaN") {   
			pFPUParam->m_exponent_min = 0x7ff;
			pFPUParam->m_exponent_max = 0x7ff;
			pFPUParam->m_fraction_min = 0x8000000000000;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+SNaN") {   
			pFPUParam->m_exponent_min = 0x7ff;
			pFPUParam->m_exponent_max = 0x7ff;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0x7ffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-SNaN") {   
			pFPUParam->m_exponent_min = 0x7ff;
			pFPUParam->m_exponent_max = 0x7ff;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0x7ffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+ZERO") {   
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-ZERO") {   
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+INFINITE") {   
			pFPUParam->m_exponent_min = 0x7ff;
			pFPUParam->m_exponent_max = 0x7ff;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-INFINITE") {   
			pFPUParam->m_exponent_min = 0x7ff;
			pFPUParam->m_exponent_max = 0x7ff;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+SUBNORMAL") {   
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-SUBNORMAL") {   
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0;
			pFPUParam->m_fraction_min = 0x1;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else
        if (r[0] == "+NORMAL") {
			pFPUParam->m_exponent_min = 0x1;
			pFPUParam->m_exponent_max = 0x7fe;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_POSITIVE;
        }else
        if (r[0] == "-NORMAL") {
			pFPUParam->m_exponent_min = 0x1;
			pFPUParam->m_exponent_max = 0x7fe;
			pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_NEGATIVE;
        }else{
			pFPUParam->m_exponent_min = 0;
			pFPUParam->m_exponent_max = 0x7ff;
        	pFPUParam->m_fraction_min = 0;
			pFPUParam->m_fraction_max = 0xfffffffffffff;
			pFPUParam->m_sign = CFpuWeightParam::FPU_RANDOM;
        }
		pFPUParam->m_name = r[0];
		pFPUParam->m_id = vFPU.size() + 1;
		pFPUParam->m_weight = CToolFnc::AtoI(r[1].c_str());
		if(r.size() >= 3)
			pFPUParam->m_fraction_and = CToolFnc::AtoI(r[2].c_str());
		if(r.size() >= 4)
			pFPUParam->m_fraction_or = CToolFnc::AtoI(r[3].c_str());
		if(r.size() >= 5)
			pFPUParam->m_exponent_and = CToolFnc::AtoI(r[4].c_str());
		if(r.size() >= 6)
			pFPUParam->m_exponent_or = CToolFnc::AtoI(r[5].c_str());
		if(r.size() >= 7)
			pFPUParam->m_max_noise = CToolFnc::AtoI(r[6].c_str());
		vFPU.push_back(pFPUParam);
    }

	fpuDoubleWeight.SetWeight(vFPU);
	IFpuDoubleConstraint::pst_WrType = &fpuDoubleWeight;
	IFpuDoubleConstraint::vst_FPUParam = vFPU;

	return true;
}


//for Debug
void CGeneratorProfile::dump(std::ostream& os) {
	SectionMap::iterator s = m_sec.begin();
	while (s != m_sec.end()) {
		if (s->first.length() == 0) {
			os << "[no name]" << std::endl;
		}else{
			os << "[" << s->first << "]" << std::endl;
		}
		SectionData::iterator d = s->second.begin();
		while (d != s->second.end()) {
			CsvRow::iterator c = d->begin();
			if (c != d->end()) {
				os << *c;
				c++;
			}
			for (; c != d->end(); c++) {
				os << ", " << *c;
			}
			os << std::endl;
			d++;
		}
		s++;
	}
}

bool CGeneratorProfile::IsWorkMPURegionByIdx(UI32 region) {
    if (m_is_mpu) {//If MPU is resevred
    	region &= 0x1f;
        UI32 rom_area_gm = m_mpcommon[0] >> 16;
        UI32 ram_area_gm = m_mpcommon[0] & 0xffff;
        UI32 rom_area_hm = m_mpcommon[1] >> 16;
        UI32 ram_area_hm = m_mpcommon[1] & 0xffff;
        UI32 mip_area_gm = m_mpdemand[0] >> 16;
        UI32 mip_area_hm = m_mpdemand[1] >> 16;

        if (region == rom_area_gm || region == ram_area_gm || region == rom_area_hm || region == ram_area_hm || region == mip_area_gm || region == mip_area_hm)
            return true;
    }
	return false;
}

bool CGeneratorProfile::IsConventionalMode() {
    SectionData& sd = GetSectionData(std::string("::MACHINE_SETTING"));
    if (sd[0][0] == "CV") return true;

    return false;
}