#!/usr/bin/env bash
count=0

if [ $# -ne 2 ]; then
	echo "./run_eva.sh (set name) (num of test)"
	exit 1
fi

testset=$1
loopcnt=$2


while [ $count -ne $loopcnt ]; do

    ./run_frog.sh ${testset}
	if [ $? -ne 0 ]; then
		echo "-----------FAIL FAIL FAIL FAIL-----------------"
		count=$(( $count + 1 ))
		continue
	fi

	LATESTFILE="`ls -lt ${testset}/out/*.S | head -n 1 | awk '{print $9}'`"

    ./run_cforest.sh ${testset}
	if [ $? -ne 0 ]; then
		echo "-----------FAIL FAIL FAIL FAIL-----------------"
		exit 1
		count=$(( $count + 1 ))
		continue
	fi
	
	# Check result
	echo "******************RESULT*****************\n"
	# Check whether simulator was terminated
	match="r9=>ffff7ffc r10=>00000010"
	terminate=`egrep "$match" ${testset}/cf_ff.log | wc -l`

	# Check whether there is any error
	match="(ffff7ffc)<=00000000"
	success=`grep "$match" ${testset}/cf_ff.log | wc -l`

	#mem_err=`diff ${testset}/log/cf_ff.log ${testset}/log/cf_00.log | wc -l`
	
	
	# Ignore cache mismatch
	sed '/cache/d' ${testset}/cf_00.log > temp1
	sed '/cache/d' ${testset}/cf_ff.log > temp2
	mem_err=`diff temp1 temp2 | wc -l`
	rm -f temp*
	

	if [ $terminate == 1 ] && [ $success == 1 ] && [ $mem_err == 0 ]; then
		echo "-----------PASS PASS PASS PASS-----------------"
		echo "******************END********************"
		#echo "TM: @(${HEXFILE%.hex})" >>  ${testset}/log/check_hazard.log
		#egrep MIP ${testset}/log/cf_ff.log -B5 -A2 | sed -e '/Break/d' -e '/FEWR/d' -e '/\:\ </d' >> ${testset}/log/check_hazard.log
		ForDel01=`echo "${LATESTFILE}" | sed 's/.S//g'`
        rm -f $ForDel01.*
		
	else 
		echo $terminate, $success, $mem_err
		echo "-----------FAIL FAIL FAIL FAIL-----------------"
		# exit
	fi
	count=$(( $count + 1 ))
done

