#include		"rnd_gen.h"

CMersenneTwister	g_rnd;

/**
 * @brief	32ビット乱数の一様乱数を得る
 * @return	32ビット乱数値
 */
UI32 CUniformedRandom::Get() {
#ifdef USE_CPP11_LIBRARY_
	std::random_device rdev;
	return rdev();
#else
	int		fd = open(m_rndsrc, O_RDONLY);
	UI32	dat;

	if (fd == -1) {
		return (-1);
	}   
	if (read (fd, (char* const)&dat, sizeof(UI32)) != sizeof(UI32)) {
		close(fd);
		return (-1);
	}   
	close(fd);	
    return dat;
#endif
}

/**
 * @brief	32ビット乱数の一様乱数を得る
 * @return	32ビット乱数値
 */
UI32 CUniformedRandom::GetRange(UI32 min, UI32 max) {
#ifdef USE_CPP11_LIBRARY_
	std::random_device rdev;
	return (min < max) ? std::uniform_int_distribution<UI32>(min, max)(rdev) : min;
#else
	return (min >= max) ? min : ((this->Get() % (max + 1 - min)) + min);
#endif
}

