#include "ifsimulator.h"
#include "simulator.h"

ISimulator::ISimulator() {
}

ISimulator::~ISimulator() {
}

ISimulator* ISimulator::New() {

	return new CSimulator();
}
