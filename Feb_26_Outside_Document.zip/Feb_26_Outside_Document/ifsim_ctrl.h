#ifndef IFSIM_CTRL_H_
#define IFSIM_CTRL_H_

#include	"rtg_common.h"
#include	"asm_src.h"
#include	"sim_res.h"
#include	"ifexception.h"
#include	"ifblk_manager.h"


extern std::unique_ptr<TWorkMemory> g_wm;
/**
 * @brief	シミュレーションコンフィギュレーション
 */
struct ISimulationParam
{
public:
	ISimulationParam(): pAsmSrcObj(NULL), pException(NULL) {}
	ISimulationParam(CAssemblerSourceFile* pasf, IException* pExp): pAsmSrcObj(pasf), pException(pExp) {}
	~ISimulationParam(){}
public:
	CAssemblerSourceFile*	pAsmSrcObj;		//!< @brief リンク確認後ファイルオブジェクト
	IException*				pException;
};

/**
 * @brief	ブロックシミュレーションコンフィギュレーション
 */
struct IBlockSimParam
{
public:
	enum {
		BSR_SUCCESS,
		BSR_REASM,
		BSR_ROLLBACK,
		BSR_JUMPING,
		BSR_FATALERROR,
		BSR_EXIT_SUCCESS,
		BSR_RESULT_NUM
	};
	
	IBlockSimParam() : pAsmSrcObj(NULL), pException(NULL), pCodeBlock(NULL), pBreakParam(), result(0), rollback(""), lpc(0), ppc(0), htid(0x80000000), psw(0), bPrevChain(false), bDebugExcep(false), pNotBreakParam() {}
	~IBlockSimParam(){}
public:
	CAssemblerSourceFile*		pAsmSrcObj;		//!< @brief リンク確認後ファイルオブジェクト
	IException*					pException;		//!< @brief 例外情報
	CCodeBlock*					pCodeBlock;		//!< @brief 対象コードブロック
	std::vector<IBreakParam >   pBreakParam[8];    //!< @brief ブレークポイント設定情報
	std::bitset<BSR_RESULT_NUM> result;			//!< @brief シミュレーション結果の情報フラグ群
	std::string					rollback;		//!< @brief ロールバックポイント名。文字列長ゼロの場合は上位でロールバック位置を決める。
	UI32						lpc;			//!< @brief 論理プログラムカウンタ(m_bResult=falseのときは意味が無い)
	UI32						ppc;			//!< @brief 物理プログラムカウンタ(m_bResult=falseのときは意味が無い)
	UI32						htid;			//!< @brief 次に実行するスレッド
	UI32						psw;			//!< @brief 次に実行するスレッドのPSW
	bool                        bPrevChain;     //!< @brief コードブロック間接続命令検出フラグ
    bool                        bDebugExcep;    //!< @brief デバッグ例外中
	std::vector<IBreakParam >   pNotBreakParam[8];	//!< @brief store break AE, SS, RLB 
};

typedef std::bitset<IBlockSimParam::BSR_RESULT_NUM>  BSIM_RESULT;


/**
 * @brief	シミュレータ制御クラス
 */
class ISimulatorControl
{
public:

	/**
	 * @brief  このオブジェクトを生成します。
	 */	
	ISimulatorControl(): m_pSim(NULL) {}
	
	/**
	 * @brief  このオブジェクトを破棄します。
	 */	
	virtual ~ISimulatorControl() {}

	/**
	 * @brief	このオブジェクトを初期化します。
	 * @return	初期化に成功した場合、真を返す。
	 */	
	virtual bool Init(std::string&) = 0;
	
	/**
	 *	@brief シミュレーターからハードウェア情報を得る。
	 */
	virtual bool GetHwSpecification(ISimulatorHwInfo* hwInfo) {
		return m_pSim->GetSimulatorInfo(*hwInfo);
	}

	/**
	 * @brief	シミュレーター参照を取得します。
	 * @return	シミュレーター参照
	 */	
	virtual ISimulator* GetSimPtr() {
		return m_pSim;
	}

	/**
	 * @brief  シミュレーション開始前、再開時に必要な処理を実装します。
	 * @return 成功した場合、真を返します。
	 */
	virtual bool ReadySimulation (ISimulationParam* pSp, IBlockSimParam* pBsp) {
		return true;
	}
	
    /**
     * @brief ブレークポイントの設定と種別選択処理
     */
	virtual UI32 GenerateBreakPointBeforeSetup(IBlockSimParam* p, IInstruction* pIns,CCodeBlock* pBlk);

	/**
	 * @brief ブレークポイント情報の生成処理
	 */
	virtual void GenerateBreakPointSetup(IBlockSimParam* p, IInstruction* pIns,CCodeBlock* pBlk);

	/**
	 * @brief  ブレークポイントコードブロック作成
	 */
	virtual void GenerateBreakPointSetupBlock(IBlockSimParam* bsp);

	
	/**
	 * @brief	ブロック単位でシミュレーションします。
	 * @return	バージョンを示す文字列
	 */	
	virtual bool Simulation(ISimulationParam* pSp);
	
    /**
    *@brief		Check asynchronous label type of pending interrupt and request interrupt. EIINT, GMEIINT, EITBL, GMEITBL are same type
    *@param		event1: pending interrupt
    *@param		event2: request interrupt
    *@return	bool(true: interrupts have same type, false: different type)
    */
    virtual bool CheckSameInterruptType(std::string event1, std::string event2) = 0;

	/**
    *@brief		Check asynchronous label type of pending interrupt and request interrupt. EIINT, GMEIINT, EITBL, GMEITBL are same type
    *@param		event1: pending interrupt
    *@param		event2: request interrupt
    *@return	bool(true: interrupts have same type, false: different type)
    */
    virtual bool CheckSameInterruptType(UI32 intId1, UI32 intId2) = 0;


	virtual UI32 IsMDPexception(MEMADDR start_addr, UI32 size, bool IsLoad, bool IsStore) = 0;

    virtual UI32 IsMIPexception(MEMADDR start_addr, UI32 size) = 0;

    /**
    *@return	true if memory belong to not self check list
    */
    virtual bool IsNotSelfCheckMemory(UI32 address) = 0;

    /**
     * @brief Get Memory Preset Data from the Undo Profile
     *
     * @return Pointer Memory Preset Data Vector
     */
	virtual void GetMemoryPresetData( std::vector<T_MEMWRRECORD > *  buff ) {
		m_pSim->GetMemoryPresetData( buff ) ;
	}
	virtual void GetSysMemPreset(std::vector<T_MEMWRRECORD > *  buff){
		m_pSim->GetSysMemPreset(buff);
	}

    /**
	* @brief Get Memory Writen Data from the Undo Profile
	*
	* @return Pointer of Memory Writen Data Vector
	*/
	virtual void GetMemoryWritenData( std::vector<T_MEMWRRECORD > *  buff ) {
		m_pSim->GetMemoryWritenData( buff ) ;
	}

	virtual bool IsTerminatedVM(UI32 gpid) = 0;

	/**
	* @brief Get LLBit Data from the Undo Profile
	*
	* @return Pointer of LLBit Datan Data Vector
	*/
	virtual void GetLLBitData( std::vector<T_LLBITRECORD > *  buff ) {
		m_pSim->GetLLBitData( buff ) ;
	}

	virtual ISimulator* GetSimulator() { return m_pSim;};

	virtual bool SetPrimitiveData(std::vector<CCodeBlock*>& cdata) {

		if (m_pSim == NULL) {
			return false;	/* simulator not ready */
		}

		for (UI32 v = 0; v < cdata.size(); v++) {
			CCodeBlock* pDb = cdata[v];
			if (pDb->IsLocationCount() != true) {
				return false;	/* Unknown address */
			}
			UI64 baseAddr	= (UI64)pDb->GetAddress();
			UI32 insNum		= pDb->GetInstructionNum();
			UI64 val;
			UI32 offset		= 0;
			for (UI32 i = 0; i < insNum; i++) {
				UI32 len = pDb->at(i)->GetLen();
				val = (UI64)((UI32)*(pDb->at(i)->opr(0)));
				m_pSim->WriteMemory(baseAddr+offset, len, val);
				offset += len;
			}
		}
		
		return true;
	}

protected:

	/**
	 * @brief	ブロック単位でシミュレーションします。
	 * @return	バージョンを示す文字列
	 */	
	virtual bool BlockSimulation(IBlockSimParam* p) = 0;	

public:
	static ISimulatorControl* New();	

    /**
    * @brief	シミュレーターバージョン文字列を取得します。
    * @return	バージョンを示す文字列
    */
    static std::string GetVersion();

    /**
    * @brief	シミュレーターバージョン文字列を取得します。
    * @return	バージョンを示す文字列
    */
    static std::string GetName();

	
protected:
	ISimulator*				m_pSim;			//!< @brief	シミュレーターインスタンス
};
extern std::unique_ptr<CAddressWeight> g_LoadableAddr;
extern std::unique_ptr<CAddressWeight> g_StorableAddr;
extern std::unique_ptr<CAddressWeight> g_RmwAddr;

#endif /*IFSIM_CTRL_H_*/
