#include "asm_src.h"
#include "usr_src.h"

extern std::shared_ptr<CUserSourceFile>		g_usf;
extern std::shared_ptr<CGeneratorProfile>   g_prf;



CAssemblerSourceFile::CAssemblerSourceFile() 
	: m_vHeader(), m_vVector(), m_vHandler(), m_vPreload(), m_vPrologue(), m_vSync(), m_vBody(), m_vTeSync(), m_vEpilogue(), m_vTerminate(), m_vUser(), 
	  m_pLinker(new CLinker()), m_Sconst()
{
}


CAssemblerSourceFile::~CAssemblerSourceFile() {
	std::vector<INode*> va;
	MergeCode(va);
	for (std::vector<INode*>::iterator i = va.begin(); i != va.end(); i++) {
		delete (*i);
	}	
	delete m_pLinker;
}



void CAssemblerSourceFile::GetConstTable(std::vector<CCodeBlock*>& v) {
	std::vector<INode*> va;
	va.insert(va.end(), m_vHeader.begin(), m_vHeader.end());
	MergeCode(va);
	v.clear();	
	for (std::vector<INode*>::iterator i = va.begin(); i != va.end(); i++) {
		CCodeBlock* pcdb = (*i)->GetConstTable();
		if(pcdb != nullptr){
			v.push_back(pcdb);
		}
	}
}



// 
// - 全ブロックに対して処理を行う。
// - ブロックの全命令に対してラベルが振られているかをチェックし
//   そのラベル名とアドレスをハッシュに登録する。
// - コードブロックにロケーションカウンタが明示されていない場合、
//   BlockGAP間隔をとって自動設定する。
//
bool CAssemblerSourceFile::MakeLabelHash() {
	
	std::vector<INode*> va;
	UI32	blockGap;
	UI32	incAddr  = 0;
	
	// array concat
	MergeCode(va);

	// Remove unused allocated memory
	for (std::vector<INode*>::iterator itr = va.begin(); itr != va.end(); itr++) {
		CCodeBlock*		pcb = static_cast<CCodeBlock*>(*itr);
		if(pcb->IsLocationCount() == false && pcb->GetAddress() != 0 && pcb->IsUserAddress() == false) {
			ReleaseBlock(pcb);
		}
	}
		
	// loop for all codeblock in asmfile
	std::vector<INode*>::iterator itr = va.begin();
	while (itr != va.end()) {
		CCodeBlock*		pcb = static_cast<CCodeBlock*>(*itr);
		UI32			insNum = pcb->GetInstructionNum();
		UI32			blockSize = 0;
		UI32			align	= pcb->GetAlign();
		IInstruction*	pins;
		blockGap = pcb->GetBlockGap();
		CLinker::MEM_ATTRIBUTE att = pcb->IsUserAddress() ? CLinker::MEM_USER_ALLOC : CLinker::MEM_FREE_ALLOC;
		
		/* loop for all instruction in codeblock */
		for (UI32 j = 0; j < insNum; j++) {
			pins = pcb->at(j);
			UI32 len = pins->GetLen();
			_ASSERT(len);
			blockSize += len;
 		}

		if (pcb->IsLocationCount()) {
			if(m_pLinker->IsAvailable(pcb->GetAddress(), pcb->GetAddress() + (blockSize/* + blockGap */ - 1), att) == true) {
				// 一旦開始アドレスを決めたものは、その位置を動かさない。blockGapを足すと次のブロック開始位置が不要にずれる。
				if ((m_pLinker->Alloc (pcb->GetAddress(), blockSize/* + blockGap */, att)) != true) {
					if(pcb->IsUserAddress()) {
						pcb->SetUserAddress(false);
						continue;
					}
					MSG_ERROR(0, "fail to allocate 0\"%s\" start at 0x%08X size=%d\n", pcb->GetLabel().c_str(), pcb->GetAddress(), blockSize);
					m_pLinker->Debug();
					PrintLabel();
					return false;
				}
				incAddr = pcb->GetAddress() + blockSize; /* + blockGap; */

				// ラベルとアドレスの解決
				if (pcb->GetLabel().length()) {
					if (m_LHash.insert(std::pair<std::string, UI32>(pcb->GetLabel(), pcb->GetAddress())).second != true){
						MSG_ERROR(0, "Label [%s] is already defined.\n", pcb->GetLabel().c_str());
						return false;
					}
				}
			} else {
				if(m_pLinker->CheckAllocatedSize(pcb->GetAddress(), blockSize) == false) {
					MSG_ERROR(0, "%s overlapped memory of next section[0x%x-0x%x].\n", pcb->GetLabel().c_str(), pcb->GetAddress(), (pcb->GetAddress() + blockSize));
					m_pLinker->Debug();
					PrintLabel();
					return false;

				}
				// ラベルとアドレスの解決
				if (pcb->GetLabel().length()) {
					if (m_LHash.insert(std::pair<std::string, UI32>(pcb->GetLabel(), pcb->GetAddress())).second != true){
						MSG_ERROR(0, "Label [%s] is already defined.\n", pcb->GetLabel().c_str());
						return false;
					}
				}
				incAddr = pcb->GetAddress() + blockSize;
			}
		} else {
			// ロケーションカウンタが指定されていない場合
			MEMADDR newaddr;
            if (pcb->FreeAlloc()) {
                MEMRANGE mr = m_pLinker->GetLocation(att, true);
                incAddr = mr.first;
            } else {
                std::string label = pcb->GetLabel();
                if (dynamic_cast<CVectorBlock*> (pcb) == nullptr) {
                    MEMRANGE mr = m_pLinker->GetLocation(att, false);
                    incAddr = mr.first;
                }
            }

			if ((m_pLinker->AllocSearch/*Auto*/(pcb, &newaddr, blockSize + blockGap, std::pair<MEMADDR,MEMADDR>(incAddr, ~0), align, att)) != true) {
				if(pcb->IsUserAddress()) {
					pcb->SetUserAddress(false);
					continue;
				}
				MSG_ERROR(0, "fail to allocate 1\"%s\" start at 0x%08X size=%d\n", pcb->GetLabel().c_str(), pcb->GetAddress(), blockSize);
				m_pLinker->Debug();
				PrintLabel();
				return false;
			}

			if (newaddr < incAddr && !pcb->FreeAlloc() && !pcb->IsUserAddress()) {
				MSG_WARN(0, "Invalid location counter \"%s\" (Incremental Addr=0x%08X, Block Addr=0x%08X)\n", pcb->GetLabel().c_str(), incAddr, newaddr);
				//m_pLinker->Debug();
				//return false;
			}

			pcb->SetAddress(newaddr);
			// ラベルとアドレスの解決
			if (pcb->GetLabel().length()) {
				if (m_LHash.insert(std::pair<std::string, UI32>(pcb->GetLabel(), newaddr)).second != true) {
					MSG_ERROR(0, "Label [%s] is already defined.\n", pcb->GetLabel().c_str());
					return false;
				}
			}
			if(pcb->IsUserAddress() == false)
				incAddr = newaddr + (blockSize + blockGap);
		}

		/* loop for all instruction in codeblock */
		UI32 baseAddr = pcb->GetAddress();
		for (UI32 j = 0; j < insNum; j++) {
			pins = pcb->at(j);
			for (UI32 k = 0; true; k++) {
				IDirective* pDir = NULL;
				if ((pDir = pins->GetDirective(k)) == NULL) {
					break;
				}
				if (pDir->SetAddress(baseAddr)) {
					m_LHash.insert(std::pair<std::string, UI32>(pDir->GetLabel(), baseAddr));
				}
			}
			baseAddr += pins->GetLen();
		}
		itr++;
	}
	
	return true;
}


// 
// - 指定に対して処理を行う。
// - ブロックの全命令に対してラベルが振られているかをチェックし
//   そのラベル名とアドレスをハッシュを更新する。
// - コードブロックにロケーションカウンタが明示されてい無い場合は失敗する
//
bool CAssemblerSourceFile::MakeLabelHash(CCodeBlock* pCb) {
	
	_ASSERT(pCb);
		
	if (pCb->IsLocationCount() != true) {
		//コードブロックにロケーションカウンタが明示されてい無い場合は失敗する
		return false;
	}

	UI32			insNum = pCb->GetInstructionNum();
	IInstruction*	pins;
	
	/* loop for all instruction in codeblock */
	UI32 baseAddr = pCb->GetAddress();
	for (UI32 j = 0; j < insNum; j++) {
		pins = pCb->at(j);
		for (UI32 k = 0; true; k++) {
			IDirective* pDir = NULL;
			if ((pDir = pins->GetDirective(k)) == NULL) {
				break;
			}
			if (pDir->SetAddress(baseAddr)) {
				std::pair<std::string, UI32>  newLabel(pDir->GetLabel(), baseAddr);
				std::pair < std::map<std::string,UI32>::iterator, bool>  result;
				result = m_LHash.insert(newLabel);
				if (result.second != true) {
					m_LHash.erase (result.first);
					m_LHash.insert(newLabel);
				}
			}
		}
		baseAddr += pins->GetLen();
	}

	return true;
}


bool CAssemblerSourceFile::LabelResolve() {

	std::vector<INode*> va;

	// array concat
	MergeCode(va);

	// For All blocks to resolve label in each blocks.
	for (std::vector<INode*>::iterator itr = va.begin(); itr != va.end(); itr++) {
		CCodeBlock*	pcb = static_cast<CCodeBlock*>(*itr);
		if (LabelResolve(pcb) != true) {
			return false;
		}
	}
	
	return true;
}

SI32 CAssemblerSourceFile::SearchAddress(std::string label){
	// Search label in label map.
	std::map<std::string,UI32>::iterator itr;
	itr = m_LHash.find(label);
	if (itr == m_LHash.end()) {
		// Unknown label.
		MSG_ERROR(0, "Symbol is not defined.\n");
		MSG_ERROR(0, "     Search address of label : %s\n", label.c_str());		
		PrintLabel(std::cout);		
		return 0;
	}else{
		return itr->second;
	}
}

bool CAssemblerSourceFile::LabelResolve(CCodeBlock* pcb) {
	UI32			insNum = pcb->GetInstructionNum();
	
	// For all Ins In Block
	UI32 pc = pcb->GetAddress();
	for (UI32 j = 0; j < insNum; j++) {
		IOperand*	pOpr;
		UI32		len = pcb->at(j)->GetLen(); // 先取り
		for (UI32 k = 0; (pOpr = pcb->at(j)->opr(k)) != NULL; k++) {

		
			// Operand is label to replace effective value.
			if (pOpr->GetLabel() != NULL) {
				
				// Search label in label map.
				std::map<std::string,UI32>::iterator itr;
				itr = m_LHash.find(std::string(pOpr->GetLabel()));
				
				if (itr == m_LHash.end()) {
					// Unknown label.
					MSG_ERROR(0, "Symbol is not defined.\n");
					MSG_ERROR(0, "     Block  Name : %s\n", pcb->GetLabel().c_str());
					MSG_ERROR(0, "     INS    Name : %s\n", pcb->at(j)->GetMne().c_str());
					MSG_ERROR(0, "     Symbol Name : %s\n", pOpr->GetLabel());
					PrintLabel(std::cout);		
					return false;
				}else{
					// Find out the label.
					bool bReplaceResult = false;
					if (pOpr->Attr(IOperand::OPR_ATTR_RLABEL)) {
						// Relative for pc
						//printf("PC:%08X ==> DST:%08x diff(%d)\n", pc, itr->second, (itr->second - pc));
						bReplaceResult = pOpr->Replace (itr->second - pc);
					} else
					if (pOpr->Attr(IOperand::OPR_ATTR_LLABEL)) {
						// loop 命令のラベル計算は特別・・・・正の即値をマイナス値でジャンプする
						FROG_ASSERT(pc >= itr->second);
						bReplaceResult = pOpr->Replace (pc - itr->second);
					}else if(pOpr->Attr(IOperand::OPR_ATTR_ALABEL) ){
						UI32 address = pOpr->GetRegVal();
						address = ((address >> 1) << 1);
						UI32 ndisplacement = (itr->second - address);
						pOpr->SetDisp(ndisplacement);
						bReplaceResult = true;
					} else{
						// Defaultは絶対ラベルにする必要あり
						// Absolute
						bReplaceResult = pOpr->Replace(itr->second);
					}
					// Judge result
					if (bReplaceResult != true) {
						MSG_ERROR(0, "Value cannot replace.\n");
						MSG_ERROR(0, "     Block  Name : %s\n", pcb->GetLabel().c_str());
						MSG_ERROR(0, "     INS    Name : %s, Id:%d\n", pcb->at(j)->GetMne().c_str(),pcb->at(j)->GetId());
						if (pOpr->Attr(IOperand::OPR_ATTR_RLABEL)) {
							MSG_ERROR(0, "     Opr(%d)    <= 0x%08x=(Dst:0x%x, PC:0x%x) labeled ""%s""\n", k, (itr->second - pc), itr->second, pc, pOpr->GetLabel());
						}else{
							MSG_ERROR(0, "     Opr(%d)    <= 0x%08X labeled ""%s""\n", k, itr->second, pOpr->GetLabel());
						}
						//PrintLabel(std::cout);
						return false;
					}
				}
			}
		}
		pc += len;
	}
	pcb->Update();
	
	return true;
}


bool CAssemblerSourceFile::ReplaceCodeBlock(CCodeBlock* pCB) {
	std::string label = pCB->GetLabel();
	if (label.length() < 1) {
		return false;
	}
	auto equal  = [&] (INode* pn) -> bool {
		return (pn->GetName() == label);
	};
	auto repfnc = [&] (std::vector<INode*>& v) -> bool {
		auto itr = std::find_if (v.begin(), v.end(), equal);
		if (itr != v.end()) {
			itr = v.insert(itr, pCB);
			delete *(++itr);
			v.erase(itr);
			return true;
		}
		return false;
	};
	return (repfnc (m_vPrologue) || repfnc (m_vPreload) || repfnc (m_vSync));
}


bool CAssemblerSourceFile::Link() {
	m_LHash.clear();
	return MakeLabelHash() && LabelResolve(); 
}

void CAssemblerSourceFile::RemoveDispLabel() {
	std::vector<INode*> va;

	// array concat
	MergeCode(va);

	// For All blocks to resolve label in each blocks.
	for (std::vector<INode*>::iterator itr = va.begin(); itr != va.end(); itr++) {
		CCodeBlock*	pcb = static_cast<CCodeBlock*>(*itr);
		UI32			insNum = pcb->GetInstructionNum();

		// For all Ins In Block
		for (UI32 j = 0; j < insNum; j++) {
			IOperand*	pOpr;
			for (UI32 k = 0; (pOpr = pcb->at(j)->opr(k)) != NULL; k++) {				
				if ((pOpr->GetLabel() != NULL) && pOpr->Attr(IOperand::OPR_ATTR_ALABEL)) 				
						pOpr->RemoveLabel();
				}
			}	
		}
		
	return;
}

CCodeBlock* CAssemblerSourceFile::Search(UI32 addr) {

	std::vector<INode*> va;
	
	// array concat
	MergeCode(va);	
		
	/* loop for all codeblock in asmfile */
	for (std::vector<INode*>::iterator itr = va.begin(); itr != va.end(); itr++) {
		CCodeBlock*		pcb = static_cast<CCodeBlock*>(*itr);
		UI32			num	= pcb->GetInstructionNum();
		UI32			len = pcb->at(num - 1)->GetLen();
		UI32 head = pcb->GetAddress();
		UI32 tail = head + pcb->GetCodeSize() - len;
		
		_ASSERT(num);
		
		if (addr >= head && addr <= tail) {
			return pcb;
		}
	}
	return NULL;
}


bool CAssemblerSourceFile::Flush(std::string& filename, UI32 peid) {
	
    std::ofstream	ofs;
    ofs.open(filename.c_str(), (std::ios::out | std::ios::app));

	if (!ofs) {
		return false;
	}
	
    std::string prefixLabel = g_mgr->GetPEContext(peid);
    /* Output Source Header */
     std::vector<INode*>::iterator itr = m_vHeader.begin();
    while (itr != m_vHeader.end()) {
       // (*itr)->Print(ofs);
        delete *itr;
        itr++;
    }

	ofs << std::endl;
	ofs << "-------------------------------------    " << std::endl;
	ofs << "-- user code define" << std::endl;
	ofs << "-------------------------------------    " << std::endl;
	ofs << std::endl;
	// REPRASE SETTING
    g_usf->ClearPlaceHolder();
    g_usf->SetPlaceHolder("%FROG_PE%", prefixLabel);
    g_usf->SetPlaceHolder("%CONTEXT%", prefixLabel.substr(prefixLabel.size()-3));
	// OUTPUT USER CODE
    g_usf->GetBody("uc_define" , ofs);


	ofs << std::endl;
	ofs << std::endl;
	ofs << "-------------------------------------    " << std::endl;
	ofs << "-- reset boot" << std::endl;
	ofs << "-------------------------------------    " << std::endl;


	std::vector<INode*> va;
	MergeCode(va);

	
	std::sort(m_Sconst.begin(), m_Sconst.end());
	PresetData::iterator ci = m_Sconst.begin();
	
	for (std::vector<INode*>::iterator i = va.begin(); i != va.end(); i++) {
	
		while (ci != m_Sconst.end()) {
			MEMADDR adr = std::get<0>(*ci);
			if (adr < (*i)->GetAddress()) {
				UI32 	len = std::get<1>(*ci);
				UI64	val = std::get<2>(*ci);
                if (g_LoadableAddr->GetMemError(adr) == true
                    || g_StorableAddr->GetMemError(adr) == true
                    || g_RmwAddr->GetMemError(adr) == true){
                    ci++;
                    continue;
                }
#if 0
				// ORG
				ofs << ".org " << std:: hex << "0x" << adr << std::endl;
#else
				// SECTION
				ofs << "    .section    " << '.' << prefixLabel << "CONST_" << std::hex << std::right << std::setw(8) << std::setfill('0') << adr;
				ofs << ", \"ax\"" << std::endl;
#endif
				if (len == 2) {
					ofs << "    " << std:: hex << ".hword 0x" << val << std::endl;
				}else
				if (len == 4) {
					ofs << "    " << std:: hex << ".word  0x" << val << std::endl;
				}else
				if (len == 8) {
					ofs << "    " << std:: hex << ".dword 0x" << val << std::endl;
				}
				ci++;
			}else{
				break;
			}
		}
		(*i)->Print (ofs);
	}
	
	for ( ; ci != m_Sconst.end(); ci++) {
		MEMADDR adr = std::get<0>(*ci);
		UI32 	len = std::get<1>(*ci);
		UI64	val = std::get<2>(*ci);

        if (g_LoadableAddr->GetMemError(adr) == true
            || g_StorableAddr->GetMemError(adr) == true
            || g_RmwAddr->GetMemError(adr) == true) {
            ci++;
            continue;
        }
#if 0
		// ORG
		ofs << ".org " << std:: hex << "0x" << adr << std::endl;
#else
		// SECTION
		ofs << "    .section    " << '.' << prefixLabel << "CONST_" << std::hex << std::right << std::setw(8) << std::setfill('0') << adr;
		ofs << ", \"ax\"" << std::endl;
#endif
		if (len == 2) {
			ofs << "    " << std:: hex << ".short 0x" << val << std::endl;
		}else
		if (len == 4) {
			ofs << "    " << std:: hex << ".word 0x" << val << std::endl;
		}else
		if (len == 8) {
			ofs << "    " << std:: hex << ".dword 0x" << val << std::endl;
		}
	}
	

	if (g_usf->IsSetCodeArea()) {
		ofs << std::endl;
		ofs << "-------------------------------------    " << std::endl;
		ofs << "-- user handler code " << std::endl;
		ofs << "-------------------------------------    " << std::endl;
		ofs << std::endl;
		// REPRASE SETTING
	    g_usf->ClearPlaceHolder();
	    g_usf->SetPlaceHolder("%FROG_PE%", prefixLabel);
        g_usf->SetPlaceHolder("%CONTEXT%", prefixLabel.substr(prefixLabel.size()-3));
		// OUTPUT USER CODE
	    g_usf->GetBody("uc_handler" , ofs);
	}

	/* Output Source Footer */
	std::ifstream ifs(g_cfg->m_strUserProfile);
	if(!ifs.fail()) {
		ofs << "# ========================================================================" << std::endl;
		ofs << "#  User's Configuration" << std::endl;
		ofs << "# ------------------------------------------------------------------------" << std::endl;
		while (ifs.eof() != true) {
			std::string line;
			getline(ifs, line);
			if (line.find("MASTER_WEIGHT") != std::string::npos) {
				ofs << "#	MASTER_WEIGHT,	" << g_cfg->m_strProfile << std::endl;
			} else if (line.find("MASTER_SREG") != std::string::npos) {
				ofs << "#	MASTER_SREG,	" << g_cfg->m_strSrProfile << std::endl;
			} else if (line.find("MASTER_INI") != std::string::npos) {
				ofs << "#	MASTER_INI,		" << g_cfg->m_strSimIni << std::endl;
			} else {
				ofs << "# " << line << std::endl;
			}
		}
		ofs << "# ========================================================================" << std::endl;
	}
	if(g_cfg->m_bOutputEnFlag && g_cfg->m_vPeId.size() <= 1) {
		/* Attached configuration file to ASM file */
		ofs << "# ========================================================================" << std::endl;
		ofs << "#  CONFIGURATION FILE (ZIPPED) " << std::endl;
		ofs << "# ------------------------------------------------------------------------" << std::endl;
		ofs << "# To look inside encoded profile/setting files :" << std::endl;
		ofs << "# cat " << filename.c_str() << " | sed 's/^.\\{2\\}//' | uudecode -o /dev/stdout | tar xvzO" << std::endl;
		ofs << "# To get encoded profile/setting files :" << std::endl;
		ofs << "# cat " << filename.c_str() << " | sed 's/^.\\{2\\}//' | uudecode -o /dev/stdout | tar xvzk" << std::endl;
		ofs << "# ========================================================================" << std::endl;
		ofs.close();
		std::string attch_comd;

		attch_comd  = "tar -zcf - ";
		attch_comd += g_cfg->m_strProfile.c_str() ;
		attch_comd += " ";
		attch_comd += g_cfg->m_strSrProfile.c_str(); 
		attch_comd += " ";
		attch_comd += g_cfg->m_strSimIni.c_str(); 
		attch_comd += " ";
		attch_comd += g_cfg->m_strUsercode.c_str(); 
		attch_comd += " | uuencode -m ";
		attch_comd += filename.substr(0,filename.find("S"));
		attch_comd += "tar.gz | sed -e 's/^/##/' >> ";
		attch_comd += filename.c_str();
		system(attch_comd.c_str());
	
	}	
	else ofs.close();
	return true;
}


bool CAssemblerSourceFile::LinkMap(std::string& filename, UI32 peid) {

    std::ofstream	ofs;
    if (peid == g_cfg->m_vPeId[0]) {
        ofs.open(filename.c_str(), (std::ios::out | std::ios::trunc));
    } else {
        ofs.open(filename.c_str(), (std::ios::out | std::ios::app));
    }

	if (!ofs) {
		return false;
	}
	
    std::string prefixLabel = g_mgr->GetPEContext(peid);
	std::vector<INode*> va;
	MergeCode(va);
	
    if (g_cfg->m_vPeId.size() == 1 || peid == g_cfg->m_vPeId[0]) {
        ofs << "OUTPUT_FORMAT(""" << "\"elf32-v850\"" << """)" << std::endl;
        ofs << "OUTPUT_ARCH(" << "v850e" << ")" << std::endl;
        if (g_cfg->m_vPeId.size() > 1)
            ofs << "ENTRY(" << "frog_pe_reset" << ")" << std::endl;
        else
            ofs << "ENTRY(" << prefixLabel << "_pe_reset" << ")" << std::endl;
        ofs << std::endl;
        ofs << "SECTIONS" << std::endl;
        ofs << "{" << std::endl;
    }

    //
    // コードブロックが配置されているアドレスを元にセクション情報をリンカ定義ファイルに
    // 出力するとともにFROGが使用したコード領域の終端を求めます。
    //
	for (std::vector<INode*>::iterator i = va.begin(); i != va.end(); i++) {
		(*i)->PrintLink (ofs);
	}

    //
    // リードオンリーデータを配置する。
    //
	PresetData::iterator ci;
	for (ci = m_Sconst.begin(); ci != m_Sconst.end(); ci++) {
		MEMADDR adr = std::get<0>(*ci);
		std::stringstream ss;
		std::string dummylabel;

        if (g_LoadableAddr->GetMemError(adr) == true
            || g_StorableAddr->GetMemError(adr) == true
            || g_RmwAddr->GetMemError(adr) == true) {
            ci++;
            continue;
        }
		ss << prefixLabel << "CONST_"<< std::hex << std::right << std::setw(8) << std::setfill('0') << adr;
		ss >> dummylabel;
		ofs << "    " << "." << dummylabel << "    0x" << std::hex << std::right << std::setw(8) << std::setfill('0') << adr << " : {" << std::endl;
		ofs << "        * (." << dummylabel << ")" << std::endl;
		ofs << "    }" << std::endl;
	}

    //
    // ユーザコード領域が指定されていれば指定されたアドレスにセクションを配置する。
    //
    if (g_usf->IsSetCodeArea()) {
		MEMADDR adr = g_usf->GetCodeArea() ;
        ofs << "    " << '.' << prefixLabel << "_usercode_area";
   	    ofs << "    0x" << std::right << std::hex << std::setw(8) << std::setfill('0') << adr << ':'  << " {" << std::endl ; 
	    ofs << "    " << "    " << "* (." << prefixLabel << "_usercode_area)" << std::endl;
	    ofs << "    " << '}' << std::endl;
	    ofs << std::endl;
    }
    
    if (g_cfg->m_vPeId.size() == 1 || peid == g_cfg->m_vPeId.back()) {
        ofs << "}" << std::endl;
    }
	
	ofs.close();
	return true;
}


void CAssemblerSourceFile::MergeCode(std::vector<INode*>& va) {
	//va.insert(va.end(), m_vHeader.begin(), m_vHeader.end());
	va.insert(va.end(), m_vVector.begin(), m_vVector.end());
	va.insert(va.end(), m_vHandler.begin(), m_vHandler.end());
	va.insert(va.end(), m_vSync.begin(), m_vSync.end());
	va.insert(va.end(), m_vTerminate.begin(), m_vTerminate.end());
    va.insert(va.end(), m_vPreload.begin(), m_vPreload.end());
	va.insert(va.end(), m_vPrologue.begin(), m_vPrologue.end());
    va.insert(va.end(), m_vFunction.begin(), m_vFunction.end());
	va.insert(va.end(), m_vBody.begin(), m_vBody.end());
	va.insert(va.end(), m_vTeSync.begin(),m_vTeSync.end());
	va.insert(va.end(), m_vEpilogue.begin(), m_vEpilogue.end());
	va.insert(va.end(), m_vUser.begin(), m_vUser.end());
}


void CAssemblerSourceFile::PrintLabel(std::ostream& os) {
    
    std::map<UI32, std::string> tmp;
    std::map<std::string,UI32>::iterator itr;
    for (itr = m_LHash.begin(); itr != m_LHash.end(); itr++) {
        tmp.insert(std::pair<UI32,std::string>(itr->second,itr->first));
    }   

#if 0   
    //os << "--------------- Label address -----------------" << std::endl;
    MSG_INFO(0,"   Address   <=>  Label name\n");
    std::map<UI32,std::string>::iterator rti;
    for (rti = tmp.begin(); rti != tmp.end(); rti++) {
        MSG_INFO(0," 0x%08X  <=>  %s\n", rti->first, rti->second.c_str());
    }
#else
    os << "   Address   <=>  Label name" << std::endl;
    std::map<UI32,std::string>::iterator rti;
    for (rti = tmp.begin(); rti != tmp.end(); rti++) {
        os << " 0x" << std::hex << std::setw(8) << std::setfill('0') << rti->first << "  <=>  " << rti->second << std::endl;
    }   
#endif
}

bool CAssemblerSourceFile::IsExecutedAddress(UI32 addr) {

    std::vector<INode*> va;
    MergeCode(va);

    /* loop for all codeblock in asmfile */
    //!< Check and merge random codeblock which is allocated.
    for (std::vector<INode*>::iterator itr = va.begin(); itr != va.end(); itr++) {
        CCodeBlock*		pcb = static_cast<CCodeBlock*>(*itr);
        UI32			num = pcb->GetInstructionNum();
        UI32			len = pcb->at(num - 1)->GetLen();
        UI32 head = pcb->GetAddress();
        UI32 tail = head + pcb->GetCodeSize() - len;

        if (addr >= head && addr <= tail) {
            return pcb->IsAllocated();
        }
    }
    // TODO by check no code in addr
    return false;
}

