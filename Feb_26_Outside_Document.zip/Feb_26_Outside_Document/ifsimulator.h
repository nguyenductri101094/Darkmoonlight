#ifndef IFSIMULATOR_H_
#define IFSIMULATOR_H_

#include    "rtg_common.h"
#include	"sim_res.h"
#include    "ifexception.h"

/* Error Infomation code */
#define		ERR_CLEAN					(0x00)	/*!< エラーの無い状態 */
#define		ERR_NOT_INITIALIZED			(0x01)  /*!< gcs_initialize_simulator_ex() または gcs_initialize_simulator() を呼ぶ前にシミュレータを使おうとした. */
#define		ERR_STEP					(0x02)	/*!< Error on executing operation in ISS. */
#define		ERR_INVALID_TCID			(0x10)
#define		ERR_INVALID_REGISTER		(0x11)  
#define		ERR_INVALID_OTHER_PARAM		(0x12)
#define		ERR_INVALID_CONTEXT			(0x13)	/*!< NOT Native or VM Context */
#define		ERR_INVALID_VCID			(0x14)
#define		ERR_THREAD_NOT_LINKED		(0x20)	/*!< Can't VC reg if thread isn't assosiated VM */
#define		ERR_THREAD_IS_HALT			(0x21)	/*!< Thread is halt or suspend. */
#define		ERR_THREAD_CANT_EXEC		(0x22)	/*!< Native is operating */
#define		ERR_ISS_MEMORY				(0x50)	/*!< ILLIGAL_PARAM/ADDR_UNDEF/READONLY/NO_OBJ/OTHER */
#define		ERR_LLBIT_LOCK				(0x51)	/*!< Other thread locking address  */
#define		ERR_LLBIT_MAX			    (0x52)	/*!< This thread is locking another address */
#define		ERR_MMU_DISABLED			(0x90)	/*!< MMUを搭載していない　*/
#define		ERR_MMU_PV					(0x91)	/*!< アクセスするとアクセス権違反で例外が発生する */
#define		ERR_MMU_ME					(0x92)	/*!< アクセスするとTLB多重違反で例外が発生する */
#define		ERR_MMU_PB					(0x93)	/*!< アクセスするとTLB境界違反で例外が発生する */
#define		ERR_MMU_NP					(0x94)	/*!< アクセスするとTLB次ページ違反で例外が発生する */
#define		ERR_MMU_VOID				(0x95)	/*!< アクセスするとTLB次ページ違反で例外が発生する */
#define		ERR_ALLOCATE_MEMORY			(0xF0)

/**
 * @brief ステップ実行結果情報クラス
 */
class ISimulatorStepResp{
public:
    ISimulatorStepResp(): pc(0), exception(0) {}
    ~ISimulatorStepResp(){}
public:
    UI32 pc ;			//!< プログラムカウンタ値
    UI32 exception ;	//!< 例外発生情報
};

/**
 * @brief シミュレータのプロパティー
 */
class ISimulatorHwInfo{
public:
	ISimulatorHwInfo(): m_gmnum(0), m_vmnum(0), m_htnum(0), m_mpnum(0), m_tlbnum(0), m_bpnum(0), m_smallpage(false) {}
    ~ISimulatorHwInfo(){}
public:
	UI32 m_gmnum;		//!< Number of GMs installed in the simulator
	UI32 m_vmnum;		//!< シミュレータに搭載しているＶＭ数
	UI32 m_htnum;		//!< シミュレータに搭載しているＨＴ数
	UI32 m_mpnum;		//!< シミュレータに搭載しているメモリ保護領域数（０の時、MPU非搭載）
	UI32 m_tlbnum;		//!< シミュレータに搭載しているTLBエントリー数（０の時、MMU非搭載）
	UI32 m_bpnum;		//!< シミュレータに搭載しているブレークポイントチャネル数
	bool m_smallpage;	//!< シミュレータに搭載しているMMU最小ページサイズ（true:1k Byte / false:4k Byte）
} ;


typedef enum {
	 MXU_RES_V			//!< アクセス可能区間
	,MXU_RES_NP			//!< アクセス可能かつページ終端でMMU次ページ違反が発生する区間
	,MXU_RES_PRIV		//!< 特権違反区間
	,MXU_RES_VOID		//!< 試験領域が無い区間
	,MXU_RES_ME			//!< TLB多重一致区間
} eMXU_STATUS ;

typedef enum {
	 MXU_ACC_READ
	,MXU_ACC_WRITE
	,MXU_ACC_FETCH
	,MXU_ACC_RMW		//!< リードとライトの両方可能であることを要求
	,MXU_ACC_DONTCARE	//!< アクセス権限をチェックしない
} eMXU_ACCESS_TYPE ;

/**
 * @brief メモリ保護区間情報クラス
 */
class CSegmentStatus {
public:
	CSegmentStatus( UI32 addr , UI64 size , UI32 status , UI32 priv , UI32 asid , bool global , bool hvc , UI32 min , UI64 paddr )
		: m_nAddr(addr)
		, m_nSize(size)
		, m_bValid(false)
		, m_nStatus(status)
		, m_nPriv(priv)
		, m_nAsid(asid)
		, m_bGlobal(global)
		, m_bHVC(hvc)
		, m_nMinPage(min)
		, m_nPAddr(paddr)
		{}
	~CSegmentStatus(){}
	
	bool Valid (UI32 addr, UI32 size, bool bPermit) {
		if (IsIncludeArea(m_nAddr, m_nSize, addr, size) != true) {
			return false;
		}
		return m_bValid == bPermit;
	}

private:
	bool IsIncludeArea (UI32 parent, UI32 parent_size, UI32 child, UI32 child_size) {
		UI32 pend = (parent + parent_size - ((parent_size==0)?0:1));
		UI32 cend = (child  + child_size  - ((child_size==0)?0:1));
		return ((child >= parent) && (child <= pend) && (cend >= parent) && (cend <= pend));
	}
	
public:
	UI32 m_nAddr ;		//!< 区間先頭アドレス
	UI64 m_nSize ;		//!< 区間サイズ（Byte）
	bool m_bValid ;		//!< true:アクセス可能区間 , false:アクセス不可区間
	UI32 m_nStatus ;	//!< eMXU_STATUS で定義。
	UI32 m_nPriv ;		//!< 区間が有している権限　bit[5:0] is { SX ,SW ,SR ,UX ,UW ,UR }
	UI32 m_nAsid ;		
	bool m_bGlobal ;	
	bool m_bHVC ;		
	UI32 m_nMinPage ;	//!< 最小ページサイズ（Byte）
	UI64 m_nPAddr ;		//!< 物理アドレス
};



/**
 * @brief メモリ保護区間情報リストクラス
 */
class CSegmentList {
public:
	
	CSegmentList() : m_ac(), m_begin_adr(0), m_end_adr(0), m_psw(0), m_pswh(0), m_dir0(0), m_asid(0), m_dirty(true)  {
		m_SegmentList.clear() ;
	}
	
	~CSegmentList() {
		Clear();
	}
	
	
	/**
	 * @brief	試験区間情報リストに区間情報を追加する
	 */
	void Set( UI32 addr , UI64 size , UI32 status , UI32 priv=0 , UI32 asid=0 , bool global=false ,bool hvc=false , UI32 min=0 , UI64 paddr=0 ) {
		m_SegmentList.push_back(new CSegmentStatus( addr , size , status , priv , asid , global ,hvc , min ,paddr)) ;
	}

	
	/**
	 * @brief	試験区間情報リストが現在のシミュレータの状態と違っている可能性があるかを問い合わせる。
	 */
	bool isDirty() {
		return (m_dirty) ;
	}
	
	/**
	 * @brief	試験区間情報リストが現在のシミュレータの状態と違った可能性があることを通知する。
	 */
	void SetDirty() {
		m_dirty= true ;
		return ;
	}

	/**
	 * @brief	試験区間情報リストのアクセス許可情報を参照して、指定されたアクセス条件に応じたValid情報とStatus情報に更新する
	 */
	void MakeStatus( bool isUM ,eMXU_ACCESS_TYPE ac ) {
		CSegmentStatus * pre_item= NULL ;
		std::vector<CSegmentStatus*>::iterator itr;
		for (itr = m_SegmentList.begin(); itr != m_SegmentList.end(); itr++) {
			CSegmentStatus * item= *itr ;
			if((item->m_nStatus == MXU_RES_V)||(item->m_nStatus == MXU_RES_PRIV)) {
				UI32 priv= item->m_nPriv ;

				UI32 priv_2= (ac == MXU_ACC_READ )    ? (priv & 0x09) :
							 (ac == MXU_ACC_WRITE)    ? (priv & 0x12) :
							 (ac == MXU_ACC_FETCH)    ? (priv & 0x24) :
							 (ac == MXU_ACC_DONTCARE) ? (priv & 0x3f) :
							 (ac == MXU_ACC_RMW  )    ? (priv & 0x1b) : 0 ;

				UI32 priv_3= (isUM) ? (priv_2 & 0x07) : ((priv_2 & 0x38) >> 3) ;

				item->m_bValid= (ac == MXU_ACC_RMW) ? (priv_3 == 3) : (priv_3 != 0) ;

				item->m_nStatus=(item->m_bValid   ) ? MXU_RES_V :		// アクセス可能区間 
													  MXU_RES_PRIV ;	// カバーしているメモリ保護領域はあるが所望のアクセス権限が無い。
			} else {
				item->m_bValid= false ;
			}
			if (item->m_nMinPage != 0) {
				if ((ac == MXU_ACC_FETCH)&&(item->m_bValid == false)&&(pre_item != NULL)&&(pre_item->m_bValid == true)) {
					pre_item->m_nStatus= MXU_RES_NP ;
				}
				pre_item= item ;
			}
		}

		return ;
	}

	/**
	 * @brief	メモリ保護区間情報リストからアクセス可能／不可能（引数vで指定）な区間のみを、vsetで指定されるベクタに書き写す。
	 */
	UI32 FilterSegmentList(std::vector<CSegmentStatus*>& vset, bool v) {
		std::vector<CSegmentStatus*>::iterator itr;
		for (itr = m_SegmentList.begin(); itr != m_SegmentList.end(); itr++) {
			if ((*itr)->m_bValid == v) {
				vset.push_back(*itr);
			}
		}
		return vset.size();
	}


	/**
	 * @brief	メモリ保護区間情報リストからアクセス可能／不可能（引数vで指定）な区間のみを、vsetで指定されるベクタに書き写す。
	 */
	bool IsAdjustable(bool v, UI32 size) {
		std::vector<CSegmentStatus*>::iterator itr;
		for (itr = m_SegmentList.begin(); itr != m_SegmentList.end(); itr++) {
			if ( ((*itr)->m_bValid == v) && ((*itr)->m_nSize >= size) ) {
				return true;
			}
		}
		return false;
	}


	/**
	 * @brief	メモリ保護区間情報リスト中に、指定された範囲を含む区間が存在していれば true を返す。
	 */
	bool Valid( UI32 addr , UI32 size, bool bPermit) {
		std::vector<CSegmentStatus*>::iterator itr;
		for (itr = m_SegmentList.begin(); itr != m_SegmentList.end(); itr++) {
			if ((*itr)->Valid(addr, size, bPermit)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @brief	メモリ保護区間情報リストに区間情報を全消去する
	 */
	void Clear() {
		std::vector<CSegmentStatus*>::iterator itr;
		for (itr = m_SegmentList.begin(); itr != m_SegmentList.end(); itr++) {
			delete *itr;
		}
		m_SegmentList.clear();
	}
	
	/**
	 * @brief	メモリ保護区間情報リストを標準出力に表示する
	 */
 	void Dump() {
		CSegmentStatus * seg ;
		std::vector<CSegmentStatus*>::iterator itr;
		UI32 i= 0 ;
		for (itr = m_SegmentList.begin(); itr != m_SegmentList.end(); itr++) {
			seg= *itr ;
			if (seg->m_nMinPage != 0) {
				printf("SEGMENT%02d ADDR:0x%08x size:0x%016llx valid=%d status=%s priv=0x%08x asid=0x%04x G=%d HVC=%d MIN_PAGE=%d paddr=0x%016llx\n" ,i
						,seg->m_nAddr ,seg->m_nSize ,seg->m_bValid 
						,(seg->m_nStatus == MXU_RES_VOID) ? "Void  " : 
						 (seg->m_nStatus == MXU_RES_PRIV) ? "Prvlg " :
						 (seg->m_nStatus == MXU_RES_ME  ) ? "MultE " :
						 (seg->m_nStatus == MXU_RES_NP  ) ? "NxtPg " :
						 (seg->m_nStatus == MXU_RES_V   ) ? "Valid " : "Unknwn "
						,seg->m_nPriv ,seg->m_nAsid ,seg->m_bGlobal ,seg->m_bHVC
						,seg->m_nMinPage ,seg->m_nPAddr
						) ; 
			} else {
				printf("SEGMENT%02d ADDR:0x%08x size:0x%016llx valid=%d status=%s priv=0x%08x\n" ,i ,seg->m_nAddr ,seg->m_nSize ,seg->m_bValid
						,(seg->m_nStatus == MXU_RES_VOID) ? "Void  " : 
						 (seg->m_nStatus == MXU_RES_PRIV) ? "Prvlg " :
						 (seg->m_nStatus == MXU_RES_V   ) ? "Valid " : "Unknwn "
						,seg->m_nPriv
						) ; 
			}
			i++ ;
		}
	}

public:
	eMXU_ACCESS_TYPE m_ac ;	
	UI32 	m_begin_adr ; 	//保持している区間リストを作成する際に用いたリスト開始アドレス
	UI32 	m_end_adr ;  	//保持している区間リストを作成する際に用いたリスト最終アドレス
	UI32 	m_psw ;			//保持している区間リストを作成する際に用いたPSW値
    UI32    m_pswh;
	UI32 	m_dir0 ;		//保持している区間リストを作成する際に用いたDIR0値
	UI32 	m_asid ;		//保持している区間リストを作成する際に用いたASID値
	bool 	m_dirty ;		//保持している区間リストが信頼出来ない状態にある場合に true。

protected:
	std::vector<CSegmentStatus*> m_SegmentList ;	// 区間リスト
};



/**
 * @brief シミュレーターインターフェース
 */
class ISimulator {
public:
    /**
     * @brief  このオブジェクトを構築します。
     */ 
    ISimulator() ;
    
    /**
     * @brief  このオブジェクトを破棄します。
     */ 
    virtual ~ISimulator() ;

    /**
     * @brief インスタンスを初期化します。
     * @param ini     : パスを含む初期設定ファイル名を指定。
     */
    virtual bool Init(std::string& ini) = 0 ;

    /**
     * @brief シミュレータ名を表す文字列を取得
     *
     * @return シミュレータ名
     */
    virtual std::string GetName( void ) = 0 ;

    /**
     * @brief シミュレータのレビジョンを表す文字列を取得
     *
     * @return レビジョン文字列
     */
    virtual std::string GetSimulatorVersion( void ) = 0 ;

    /**
     * @brief シミュレータの搭載情報を取得
     *
     * @return isError
     */
	virtual bool GetSimulatorInfo(ISimulatorHwInfo &info) = 0 ;

    /**
     * @brief １命令をステップ実行します。
     * @param   htid         [in]   ステップするスレッドＩＤ
     * @param   address      [in]   メモリにライトし、実行するアドレス
     * @param   response     [out]  実行結果情報格納先クラスの先頭アドレス（結果不要ならばNULL指定可）
     * @note
     * \nエラー情報： GetErrorInfo()で取得可
     * \n ERR_NOT_INITIALIZED     : Simulator is not initialized.
     * \n ERR_INVALID_TCID        : Thread id is 0-63
     * \n ERR_THREAD_NOT_LINKED   : Thread isn't associated with vm.
     * \n ERR_THREAD_CANT_EXEC    : Native is operating
     * \n ERR_THREAD_IS_HALT      : Thread is halt or suspend.
     * \n ERR_STEP                : Error on executing operation in ISS.
     * \n ERR_CLEAN               : エラーが無い状態。戻り値が false の場合はこの値となる。
     * \n 上記以外                 : 内部エラー
     */
    virtual bool Step(SI32 htid ,UI64 address, ISimulatorStepResp * response) = 0 ;

    /**
     * @brief 巻戻しポイントの作成
     *
     * @param   point_id     [in]  巻戻しポイントをラベル文字列で設定
     */
    virtual bool CreateChkPoint(std::string point_id) = 0 ;

    /**
     * @brief 設定ポイントまでの巻戻し
     *
     * @param   point_id     [in]  巻戻しポイントをラベル文字列で指定
     */
    virtual bool Rollback(std::string point_id) = 0 ;

	/**
	 * @brief	Rollback execution of a instruction
	 * @return	Rollback is successfull or not
	 */
	virtual bool Rollback() = 0 ;

    /**
     * @brief メモリにデータをライトします。
     *
     * @param   address      [in]  メモリにライトし、実行するアドレス
     * @param   size         [in]  メモリにライトするサイズ
     * @param   val          [in]  メモリにライトするデータの先頭アドレス
     * @return isSUCCESS
     */
    virtual bool WriteMemory( UI64 address, SI32 size , UI64 val ) = 0 ;

    /**
     * @brief 指定アドレスが未使用であれば初期値データをライトします。
     *
	 * @param   isNC 　       [in]  取得先がネイテイブマシン
	 * @param   htid 　       [in]  取得先が仮想マシンの場合のスレッドＩＤ
     * @param   address       [in]  メモリにライトし、実行するアドレス
     * @param   size          [in]  メモリにライトするサイズ
     * @param   val           [in]  メモリにライトするデータの先頭アドレス
     * @return isSUCCESS
     */
    virtual bool PresetMemory( bool isNC ,UI32 htid , UI64 address, SI32 size , UI64 val, bool flag = false) = 0 ;

    /**
     * @brief メモリのデータをリードします。
     *
     * @param   address      [in]  リードアドレス
     * @param   size         [in]  リードサイズ
     * @param   *val         [out] リードデータの格納アドレス
     * @return isError
     */
    virtual bool ReadMemory( UI64 address , SI32 size , UI64 * val  ) = 0 ;

    /**
     * @brief システム・レジスタ値の読み出し（ネイティブ・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @return isSUCCESS
     */
    virtual bool ReadNcReg(UI32 * value , SI32 regID , SI32 selID ) = 0 ;

    /**
     * @brief システム・レジスタ値の読み出し（スレッド・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isSUCCESS
     */
    virtual bool ReadTcReg(UI32 * value , SI32 regID , SI32 selID , SI32 tcid ) = 0 ;

	/**
     * @brief システム・レジスタ値の読み出し（ネイティブ・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @return isError
     */
    virtual bool WriteNcReg(UI32 value , SI32 regID , SI32 selID ) = 0;

	 /**
     * @brief システム・レジスタ値の読み出し（スレッド・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool WriteTcReg(UI32 value , SI32 regID , SI32 selID , SI32 htid ) = 0;

    /**
     * @brief システム・レジスタ値の読み出し（仮想マシン・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @param  vcid          [in]  仮想マシン・コンテキスト番号
     * @return isSUCCESS
     */
    virtual bool ReadVcReg(UI32 * value , SI32 regID , SI32 selID , SI32 vcid ) = 0 ;

    /**
     * @brief プログラムカウンタの読み出し
     *
     * @param  value         [out] 結果格納アドレス
     * @param  tcid          [in]  スレッド・コンテキスト番号（省略時はNC:PC値を返す）
     * @return isSUCCESS
     */
    virtual bool ReadPC(UI32 * value ,SI32 tcid ) = 0 ;
    virtual bool ReadPC(UI32 * value ) = 0 ;

    /**
     * @brief 汎用レジスタ値の読み出し
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isSUCCESS
     */
    virtual bool ReadGrReg(UI32 * value , SI32 regID  , SI32 tcid ) = 0 ;

	/**
     * @brief Use to read system Register
     *
     * @param  value         [out] read value from system register.
     * @param  registerName  [in]  System register name.
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
	virtual bool ReadSysRegister(UI32 * value, std::string registerName , SI32 tcid ) = 0;

    /**
     * @brief FP-SIMDレジスタ値の読み出し
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool ReadWrReg(__uint128_t * value , SI32 regID , SI32 tcid ) = 0 ;
    /**
     * @brief ベクトルレジスタ値の読み出し
     *
     * This function can read value from system register without privilege.
     * To access General, Vector and PC, use existing interface.
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isSUCCESS
     */
    virtual bool ReadVeReg(UI64 * value , SI32 regID , SI32 tcid ) = 0 ;

    /**
     * @brief エラー詳細情報の取得
     *
     * @param  value         [out] 結果格納アドレス
     * @return isSUCCESS
     */
    virtual bool GetErrorInfo(UI32 * value ) = 0 ;


    /**
     * @brief Screen Dump Register
     *
     * @param  tcid          [in] Thread ID(0-63).
     */
    virtual bool DumpTcReg( SI32 tcid ) = 0 ;

    /**
     * @brief Get Memory Preset Data from the Undo Profile
     *
     * @return Pointer Memory Preset Data Vector
     */
	virtual void GetMemoryPresetData( std::vector<T_MEMWRRECORD > *  buff ) = 0 ;

    /**
     * @brief Get Memory Writen Data from the Undo Profile
     *
     * @return Pointer of Memory Writen Data Vector
     */
	virtual void GetMemoryWritenData( std::vector<T_MEMWRRECORD > * buff ) = 0 ;

	 /**
     * @brief LLBit Data from the Undo Profile
     *
     * @return Pointer of LLBit Data Vector
     */
	virtual void GetLLBitData( std::vector<T_LLBITRECORD > * buff ) = 0 ;

	/**
	 * @brief	Send a interrupt request to simulator
	 * @ptid	Physical thread ID of current machine
	 * @name	Interrupt name
	 * @channel	Interrupt channel
	 * @priority	Interrupt priority incase of user interrupt (EIINT and EITBL).
	 * @causecode	Cause code in case of SYSERR
	 */
	virtual void RequestInterrupt(UI32 ptid, UI32 intId, std::string name, UI32 channel, UI32 priority, UI32 causecode, UI32 gpid) = 0;

	/**
	 * @brief	Clear a interrupt request in simulator
	 * @ptid	Physical thread ID of current machine
	 * @name	Interrupt name
	 */
	virtual void ClearInterrupt(UI32 ptid, UI32 eventId, std::string name) = 0;

	/**
	 * 仮想アドレス-物理アドレス 変換処理インタフェース
	 *
	 * @param  isNC       [in]  取得先がネイテイブマシン
	 * @param  htid       [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @param  vaddr      [in]  仮想アドレス
	 * @param  length     [in]  データサイズ（1:バイトアクセス、2;ハーフワードアクセス、4:ワードアクセス、8:ダブルワードアクセス。それ以外の指定は不可）
	 * @param  ac         [out] アクセス種別
	 * @param  *paddr1    [out] 物理アドレス１
	 * @param  *length1   [out] 物理アドレス１レングス
	 * @param  *paddr2    [out] 物理アドレス２
	 * @param  *length2   [out] 物理アドレス２レングス
	 * @return isError 
	 *         GCSIF_ERR_NOT_INITIALIZED       : Simulator is not initialized.
	 *         GCSIF_ERR_INVALID_OTHER_PARAM   : Parameter "index" should be 0~63.
	 *         GCSIF_ERR_MMU_DISABLED          : TLB I/F Disabled on MPU mode
	 *         GCSIF_SUCCESS                   : Successful
	 */
	virtual bool MmuTransferAddr( bool isNC , UI32 htid , UI32 vaddr , UI64 length , eMXU_ACCESS_TYPE ac , UI64  *paddr1 , UI64 *length1 , UI64 *paddr2 , UI64 *length2) = 0 ;

	/**
	 * メモリ保護区間情報リストの取得処理
	 *
	 * シミュレータの現行設定における、始端アドレスから終端アドレスまでのメモリ保護状態のリストを取得する。
	 *
	 * @param  *result    [out] メモリ保護区間情報リストへのポインタ
	 * @param  begin_adr  [in]  始端アドレス
	 * @param  end_adr    [in]  終端アドレス
	 * @param  ac         [in]  アクセス種別(リード／ライト／実行）
	 * @param  htid       [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @param  isNC       [in]  取得先がネイテイブマシン
	 * @return isError 
	 */
	virtual bool GetSegmentList(CSegmentList* &result , UI32 begin_adr , UI32 end_adr , eMXU_ACCESS_TYPE ac , UI32 htid , bool isNC ) = 0 ;

	/**
	 * メモリ保護区間情報リストの取得処理
	 *
	 * シミュレータの現行設定における、始端アドレスから終端アドレスまでのメモリ保護状態のリストを取得する。
	 *
	 * @param  *result    [out] メモリ保護区間情報リストへのポインタ
	 * @param  begin_adr  [in]  始端アドレス
	 * @param  end_adr    [in]  終端アドレス
	 * @param  ac         [in]  アクセス種別(リード／ライト／実行）
	 * @param  htid       [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @return isError 
	 */
	virtual bool GetSegmentList(CSegmentList* &result , UI32 begin_adr , UI32 end_adr , eMXU_ACCESS_TYPE ac , UI32 htid ) = 0 ;

	/**
	 * 直近に実行した命令で行なったメモリデータアクセスの記録を取得する
	 *
	 * @param  read1_write0 [out]  True:リードアクセス  false:ライトアクセス 
	 * @param  addr         [out]  アクセスアドレス
	 * @param  byte         [out]  データバイト数
	 * @return isValid
	 */
	virtual bool PopMemAccessLog(UI32 &read1_write0 , UI64 &addr , UI32 &byte ) = 0 ;

	/**
	 * @brief set m_itrDataAccessInStep equal firt element of m_DataAccessInStep
	 *	Assign value for m_itrDataAccessInStep before get m_DataAccessInStep element.
	 * @param	index of memory in memory log
	 * @return	True: if index is valid, otherwise, false
	 */
	virtual bool SetMemVariable(UI32 idx) = 0;

	/**
	 * 直近に実行した命令で行なったメモリデータアクセスの記録を取得する
	 *
	 * @param  read1_write0 [out]  True:リードアクセス  false:ライトアクセス 
	 * @param  addr         [out]  アクセスアドレス
	 * @param  byte         [out]  データバイト数
	 * @param  value        [out]  アクセスデータ
	 * @return isValid
	 */
	virtual bool EachMemAccessLog(UI32 &read1_write0 , UI64 &addr , UI32 &byte , UI64 &value ) = 0 ;

	/**
	 * 直近に実行した命令によるメモリデータアクセス回数を取得する
	 *
	 * @return メモリデータアクセス回数
	 */
	virtual UI32 SizeMemAccessLog(void) = 0 ;
	
	/**
     * @brief Set memory accessed by operation code block to preset.
     * @addr: Memory address
	 * @size: Initialize size
	 * @value: Initialized value.
     * @return 
     */
	virtual void SetSysMemPreset(UI64 addr, UI32 size, UI64 value) = 0;

	/**
     * @brief Get memory accessed by operation block.
     *
     * @return Pointer of Memory Writen Data Vector
     */
	virtual void GetSysMemPreset(std::vector<T_MEMWRRECORD > * buff) = 0;
        
    virtual bool IsNativeMachine (void) = 0;

    /**
    * @brief Check memory range from addr to addr + size whether it has preset yet
    * @return true if memory range do not preset
    */
    virtual bool IsInitMemory(UI64 addr, UI32 size) = 0;

    /**
    * @brief find memory has size which do not preset memory
    * @return start address of the memory area
    */
    virtual MEMADDR FindVacantMemory(UI32 size, UI64 align) = 0;

    /**
    * @brief Get value of MPLA register correspond to entry
    */
    virtual UI32 GetMPLA(UI32 entry) = 0;

    /**
    * @brief Get value of MPUA register correspond to entry
    */
    virtual UI32 GetMPUA(UI32 entry) = 0;

    /**
    * @brief Get value of MPAT register correspond to entry
    */
    virtual UI32 GetMPAT(UI32 entry) = 0;

    /**
    * @brief Set value of MPLA register correspond to entry
    */
    virtual void SetMPLA(UI32 entry, UI32 value) = 0;

    /**
    * @brief Set value of MPUA register correspond to entry
    */
    virtual void SetMPUA(UI32 entry, UI32 value) = 0;

    /**
    * @brief Set value of MPAT register correspond to entry
    */
    virtual void SetMPAT(UI32 entry, UI32 value) = 0;

    /**
    * @brief Get value of MPM register
    */
    virtual UI32 GetMPM() = 0;

    virtual UI32 GetMPCFG() = 0;

    virtual UI32 GetSPID() = 0;

    virtual UI32 GetSPID_MPIDn() = 0;

    virtual UI32 GetMPBK() = 0;

    virtual UI32 GetPSW() = 0;

    virtual UI32 GetHVCFG() = 0;

    virtual void SetMPM(UI32 value) = 0;

    virtual void SetMPCFG(UI32 value) = 0;

    virtual void SetSPID_MPIDn(UI32 value) = 0;

    virtual void SetMPBK(UI32 value) = 0;

    virtual void SetPSW(UI32 value) = 0;

    virtual void SetHVCFG(UI32 value) = 0;
    /**
    * @brief Get cause code of current exception
    */
    virtual UI32 GetCauseCode() = 0;

public:
    static ISimulator* New();
};


#endif /*ISIMULATOR_H_*/
