#ifndef ADR_SELECTOR_H_
#define ADR_SELECTOR_H_

#include	"rtg_common.h"
#include	"ifvalconstraint.h"
#include	"ifsimulator.h"


/**
 * @brief	Addressセレクタ
 */
class CAddressSelector : public IValConstraint
{
public:

	/**
	 * @brief  このオブジェクトを生成します
	 */	
	CAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<IValConstraint::CONSTRAINT_TYPE_NUM> bs)
		: IValConstraint (min, max, mask, size, bs), m_pSegList(NULL), m_nAccessedMin(min), m_nAccessedMax(max) {}
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~CAddressSelector(){}
	
	
	/**
	 * @brief  メモリ情報（アクセス権限）の情報を設定します。
	 * @param  pSL セグメントテーブル
	 */
	virtual void SetSegmentList(CSegmentList* pSL) {
		m_pSegList = pSL;
	}
	
	virtual bool IsLock() {
		return m_pSegList != nullptr;
	}

	/**
	 * @brief  指定値が制約に適合するかを検証します
	 * @param  val 検証値
	 * @return 適合する場合真を返す。
	 */
	virtual bool IsValid(UI64 val);
	
	/**
	 * @brief  制約に適合する目標を得る
	 * @return 適合値を返す。
	 */
	virtual UI64 SelectValue();

	/**
	 * @brief Set range for allocated memory
	 * @param nMin lower boundary value
	 * @param nMax upper boundary value
	 * @return None
	 */
	virtual void SetRange(UI64 nMin, UI64 nMax) {
		m_nAccessedMin = nMin;
		m_nAccessedMax = nMax;
	}
	
	/**
	 * @brief virtual function was using for specify base class and derived class in inheritance tree
	 * @return true for class need to adjust memmory. Each derived class will return different value.
	 */
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM){
		if (GetType(IValConstraint::FETCH)) {
			*atype = MXU_ACC_FETCH;
			_ASSERT(0);
		}else{
			if (GetType(IValConstraint::LOAD_MEMORY)) {
				if (OprAtt_SMEM) {
                    *aw = *(g_RmwAddr.get()); // copy
					*atype = MXU_ACC_RMW;
				}else{
                    *aw = *(g_LoadableAddr.get()); // copy
					*atype = MXU_ACC_READ;
				}
			}else{
				if (GetType(IValConstraint::STORE_MEMORY)) {
					if (OprAtt_LMEM) {
                        *aw = *(g_RmwAddr.get()); // copy
						*atype = MXU_ACC_RMW;
					}else{
                        *aw = *(g_StorableAddr.get()); // copy
						*atype = MXU_ACC_WRITE;
					}
				}
			}
		}
		return true;
	}

	/**
	 * @brief virtual function was using for specify base class and derived class in inheritance tree
	 * @return true for class need to adjust memmory. Each derived class will return different value.
	 */
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM, UI32 lnk){
		if (GetType(IValConstraint::FETCH)) {
			*atype = MXU_ACC_FETCH;
			_ASSERT(0);
		}else{
			if (GetType(IValConstraint::LOAD_MEMORY)) {
				if (OprAtt_SMEM) {
					*aw = *(g_RmwLnkAddr.get()); // copy
					*atype = MXU_ACC_RMW;
				}else{
					*aw = *(g_LoadableLnkAddr.get()); // copy
					*atype = MXU_ACC_READ;
				}
			}else{
				if (GetType(IValConstraint::STORE_MEMORY)) {
					if (OprAtt_LMEM) {
						*aw = *(g_RmwLnkAddr.get()); // copy
						*atype = MXU_ACC_RMW;
					}else{
						*aw = *(g_StorableLnkAddr.get()); // copy
						*atype = MXU_ACC_WRITE;
					}
				}
			}
		}
		if (GetType(IValConstraint::ACCESS_RANGE)) {
			std::set<MEMRANGE> ks = aw->KeySet();
			std::set<MEMRANGE>::iterator itr = ks.begin();
			while (itr != ks.end()) {
				MEMRANGE mr = *itr;
				if(mr.second < m_nAccessedMin) {
					aw->Delete(mr);
				}
				if(mr.first > m_nAccessedMax) {
					aw->Delete(mr);
				}
				itr++;
			}
		}

		return true;
	}

	/**
	 * @brief デバッグ用
	 */	
	virtual void Dump (std::ostream& os = std::cout) {
		IValConstraint::Dump(os);
		os << "--------------------------------" << std::endl;
		m_pSegList->Dump();
	}
			
protected:
	CSegmentList*	m_pSegList;
	UI64			m_nAccessedMin;
	UI64			m_nAccessedMax;
};



/**
 * @brief	LOAD
 */
class CLoadAddressSelector : public CAddressSelector {

public:

	/**
	 * @brief  このオブジェクトを生成します
	 * 
	 */	
	CLoadAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size)
	 : CAddressSelector(min, max, mask, size, (UI32)(1 << IValConstraint::LOAD_MEMORY)), m_pAddrTable(g_LoadableAddr.get())
	{
	}


	/**
	 * @brief  このオブジェクトを生成します
	 */	
	CLoadAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<IValConstraint::CONSTRAINT_TYPE_NUM> bs)
	 : CAddressSelector(min, max, mask, size, (bs.to_ulong() | (1 << IValConstraint::LOAD_MEMORY)) ), m_pAddrTable(g_LoadableAddr.get()) {}
	
	/**
	* @brief virtual function was using for specify base class and derived class in inheritance tree
	* @return true for class need to adjust memmory. Each derived class will return different value.
	*/
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM){
			// Mismatch PC can cause mismatch value in Fetch memory
		if (OprAtt_SMEM) {
			*aw = *(g_RmwAddr.get()); // copy
			*atype = MXU_ACC_RMW;
		}else{
			*aw = *(g_LoadableAddr.get()); // copy
			*atype = MXU_ACC_READ;
		}

		// RedMine 60238#note-17: Decide to generate 10% data memory and 90% fetch memory..
		if (GetType(IValConstraint::FETCH) && g_rnd.GetRange(0, 10) != 0) {
			*aw = *(g_FetchAddr.get()); // copy
		}

		return true;
	}

	/**
	* @brief virtual function was using for specify base class and derived class in inheritance tree
	* @return true for class need to adjust memmory. Each derived class will return different value.
	*/
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM, UI32 lnk){
		if (OprAtt_SMEM) {
			*aw = *(g_RmwLnkAddr.get()); // copy
			*atype = MXU_ACC_RMW;
		}else{
			*aw = *(g_LoadableLnkAddr.get()); // copy
			*atype = MXU_ACC_READ;
		}
		return true;
	}

	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~CLoadAddressSelector(){}

protected:
	CAddressWeight*	m_pAddrTable;
};



/**
 * @brief	STORE
 */
class CStoreAddressSelector : public CAddressSelector {
public:
	
	/**
	 * @brief  このオブジェクトを生成します
	 */	
	CStoreAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size)
	 : CAddressSelector(min, max, mask, size, (UI32)(1 << IValConstraint::STORE_MEMORY)) {}


	/**
	 * @brief  このオブジェクトを生成します
	 */	
	CStoreAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<IValConstraint::CONSTRAINT_TYPE_NUM> bs)
	 : CAddressSelector(min, max, mask, size, (UI32)(bs.to_ulong() | (1 << IValConstraint::STORE_MEMORY)) ) {}
	
	/**
	* @brief virtual function was using for specify base class and derived class in inheritance tree
	* @return true for class need to adjust memmory. Each derived class will return different value.
	*/
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM){
		if (OprAtt_LMEM) {
			*aw = *(g_RmwAddr.get()); // copy
			*atype = MXU_ACC_RMW;
		}else{
			*aw = *(g_StorableAddr.get()); // copy
			*atype = MXU_ACC_WRITE;
		}

		if (GetType(IValConstraint::ACCESS_RANGE)) {
			std::set<MEMRANGE> ks = aw->KeySet();
			std::set<MEMRANGE>::iterator itr = ks.begin();
			while (itr != ks.end()) {
				MEMRANGE mr = *itr;
				if(mr.second < m_nAccessedMin) {
					aw->Delete(mr);
				}
				if(mr.first > m_nAccessedMax) {
					aw->Delete(mr);
				}
				itr++;
			}
		}
		return true;
	}


	/**
	* @brief virtual function was using for specify base class and derived class in inheritance tree
	* @return true for class need to adjust memmory. Each derived class will return different value.
	*/
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM, UI32 lnk){
		if (OprAtt_LMEM) {
			*aw = *(g_RmwLnkAddr.get()); // copy
			*atype = MXU_ACC_RMW;
		}else{
			*aw = *(g_StorableLnkAddr.get()); // copy
			*atype = MXU_ACC_WRITE;
		}
		return true;
	}

	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~CStoreAddressSelector(){}
};


/**
 * @brief	Read & Write
 */
class CRmwAddressSelector : public CAddressSelector {
public:
	
	/**
	 * @brief  このオブジェクトを生成します
	 */	
	CRmwAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size)
	 : CAddressSelector(min, max, mask, size, (UI32)(1 << IValConstraint::STORE_MEMORY)|(1 << IValConstraint::LOAD_MEMORY)) {}


	/**
	 * @brief  このオブジェクトを生成します
	 */	
	CRmwAddressSelector(UI64 min, UI64 max, UI64 mask, UI32 size, std::bitset<IValConstraint::CONSTRAINT_TYPE_NUM> bs)
	 : CAddressSelector(min, max, mask, size, (UI32)(bs.to_ulong() | (1 << IValConstraint::STORE_MEMORY) | (1 << IValConstraint::LOAD_MEMORY)) ) {}
	
	/**
	* @brief virtual function was using for specify base class and derived class in inheritance tree
	* @return true for class need to adjust memmory. Each derived class will return different value.
	*/
	bool GetMemmoryArea(CAddressWeight* aw, eMXU_ACCESS_TYPE* atype, bool OprAtt_SMEM, bool OprAtt_LMEM){
		if (OprAtt_SMEM) {
			*aw = *(g_RmwAddr.get()); // copy
			*atype = MXU_ACC_RMW;
		}else{
			*aw = *(g_LoadableAddr.get()); // copy
			*atype = MXU_ACC_READ;
		}
		if (GetType(IValConstraint::ACCESS_RANGE)) {
			std::set<MEMRANGE> ks = aw->KeySet();
			std::set<MEMRANGE>::iterator itr = ks.begin();
			while (itr != ks.end()) {
				MEMRANGE mr = *itr;
				if(mr.second < m_nAccessedMin) {
					aw->Delete(mr);
				}
				if(mr.first > m_nAccessedMax) {
					aw->Delete(mr);
				}
				itr++;
			}
			aw->Dump();
		}
		return true;
	}
	
	/**
	 * @brief  このオブジェクトを破棄します
	 */	
	virtual ~CRmwAddressSelector(){}
};

#endif /*ADR_SELECTOR_H_*/
