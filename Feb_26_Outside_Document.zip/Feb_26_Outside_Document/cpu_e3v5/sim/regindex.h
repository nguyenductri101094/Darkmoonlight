#include <string>
#include <map>
typedef unsigned int uint32_t;

#include <string>
#include <map>

#define        SHARE_NO        1
#define        SHARE_NC        2
#define        SHARE_VC        4
#define        SHARE_TC        8

enum E_REGIDX_REGTYPE {
    REGIDX_TYPE_GENERAL = 0,
    REGIDX_TYPE_VECTOR,
    REGIDX_TYPE_SYSTEM,
    REGIDX_TYPE_SPECIAL,
};

class CRegisterProfile
{
public:
    CRegisterProfile (uint32_t p1, uint32_t p2, std::string p3, uint32_t p4, uint32_t p5, uint32_t p6, uint32_t p7, uint32_t p8, uint32_t p9);
    CRegisterProfile (){};
    uint32_t        m_bank;
    uint32_t        m_regno;
    std::string        m_Name;
    uint32_t        m_type;
    uint32_t        m_context;
    uint32_t        m_privilege;
    uint32_t        m_init;
    uint32_t        m_mask;
    uint32_t        m_maskldsr;
};

class CRegisterIndex
{
public:
    CRegisterIndex();
    CRegisterProfile* Find(std::string name);
    CRegisterProfile* Find(const char* name);
    void CreateHashTable();
    void Set (
    uint32_t    bank,
    uint32_t    regno,
    const char* name,
    uint32_t     type, 
    uint32_t     context, 
    uint32_t     privlege, 
    uint32_t     ini, 
    uint32_t     mask, 
    uint32_t     maskldsr);
    std::map<std::string, CRegisterProfile> m_map;
};
