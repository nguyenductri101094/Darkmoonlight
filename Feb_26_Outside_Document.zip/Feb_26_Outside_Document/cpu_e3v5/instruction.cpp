// -------------------------------------
// This file was automatically generated
//     by "./mk_isaimpl.pl"
//     on  Wed Nov 21 13:29:28 2012
// -------------------------------------

#include "instruction.h"
#include "asm_src.h"

extern std::shared_ptr<CAssemblerSourceFile>	g_asf;

/////////////////////////////////////////////////////////
// List12BitOrder for operand "list12" in prepare/dispse
// - convert order of list12 defined architecture to gas. 
// - param  list12 (arc)
// - return list12 (gas)
/////////////////////////////////////////////////////////
static UI32 List12BitOrder(UI32 list12) {
	UI32 ordered = 0;
	ordered |= ((list12 >> 27) & 1) <<  0; //  0b r20
	ordered |= ((list12 >> 26) & 1) <<  1; //  1b r21
	ordered |= ((list12 >> 25) & 1) <<  2; //  2b r22
	ordered |= ((list12 >> 24) & 1) <<  3; //  3b r23
	ordered |= ((list12 >> 31) & 1) <<  4; //  4b r24
	ordered |= ((list12 >> 30) & 1) <<  5; //  5b r25
	ordered |= ((list12 >> 29) & 1) <<  6; //  6b r26
	ordered |= ((list12 >> 28) & 1) <<  7; //  7b r27
	ordered |= ((list12 >> 23) & 1) <<  8; //  8b r28
	ordered |= ((list12 >> 22) & 1) <<  9; //  9b r29
	ordered |= ((list12 >>  0) & 1) << 10; // 10b r30
	ordered |= ((list12 >> 21) & 1) << 11; // 11b r31	
	return ordered;
}

/////////////////////////////////////////////////////////
// InsID :: 1
// Class :: add
/////////////////////////////////////////////////////////
const UI32			CIns_1_add::m_id = 1;
const std::string	CIns_1_add::m_mne("add");
const UI32			CIns_1_add::m_numop = 2;
const BS_IPRV		CIns_1_add::m_priviledge(0x0);
const BS_ICAT		CIns_1_add::m_category(0x0);
const BS_IBHV		CIns_1_add::m_behavior(0x0);
const UI32          CIns_1_add::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);


/////////////////////////////////////////////////////////
// InsID :: 2
// Class :: add
/////////////////////////////////////////////////////////
const UI32			CIns_2_add::m_id = 2;
const std::string	CIns_2_add::m_mne("add");
const UI32			CIns_2_add::m_numop = 2;
const BS_IPRV		CIns_2_add::m_priviledge(0x0);
const BS_ICAT		CIns_2_add::m_category(0x0);
const BS_IBHV		CIns_2_add::m_behavior(0x0);
const UI32          CIns_2_add::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 3
// Class :: addi
/////////////////////////////////////////////////////////
const UI32			CIns_3_addi::m_id = 3;
const std::string	CIns_3_addi::m_mne("addi");
const UI32			CIns_3_addi::m_numop = 3;
const BS_IPRV		CIns_3_addi::m_priviledge(0x0);
const BS_ICAT		CIns_3_addi::m_category(0x0);
const BS_IBHV		CIns_3_addi::m_behavior(0x0);
const UI32          CIns_3_addi::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 4
// Class :: adf
/////////////////////////////////////////////////////////
std::string CIns_4_adf::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << val;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	ss << ", " << opr(3)->GetCode();
	return ss.str();
}

const UI32			CIns_4_adf::m_id = 4;
const std::string	CIns_4_adf::m_mne("adf");
const UI32			CIns_4_adf::m_numop = 4;
const BS_IPRV		CIns_4_adf::m_priviledge(0x0);
const BS_ICAT		CIns_4_adf::m_category(0x0);
const BS_IBHV		CIns_4_adf::m_behavior(0x0);
const UI32          CIns_4_adf::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 5
// Class :: and
/////////////////////////////////////////////////////////
const UI32			CIns_5_and::m_id = 5;
const std::string	CIns_5_and::m_mne("and");
const UI32			CIns_5_and::m_numop = 2;
const BS_IPRV		CIns_5_and::m_priviledge(0x0);
const BS_ICAT		CIns_5_and::m_category(0x0);
const BS_IBHV		CIns_5_and::m_behavior(0x0);
const UI32          CIns_5_and::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 6
// Class :: andi
/////////////////////////////////////////////////////////
const UI32			CIns_6_andi::m_id = 6;
const std::string	CIns_6_andi::m_mne("andi");
const UI32			CIns_6_andi::m_numop = 3;
const BS_IPRV		CIns_6_andi::m_priviledge(0x0);
const BS_ICAT		CIns_6_andi::m_category(0x0);
const BS_IBHV		CIns_6_andi::m_behavior(0x0);
const UI32          CIns_6_andi::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 7
// Class :: bc
/////////////////////////////////////////////////////////
const UI32			CIns_7_bc::m_id = 7;
const std::string	CIns_7_bc::m_mne("bc");
const UI32			CIns_7_bc::m_numop = 1;
const BS_IPRV		CIns_7_bc::m_priviledge(0x0);
const BS_ICAT		CIns_7_bc::m_category(0x0);
const BS_IBHV		CIns_7_bc::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 8
// Class :: be
/////////////////////////////////////////////////////////
const UI32			CIns_8_be::m_id = 8;
const std::string	CIns_8_be::m_mne("be");
const UI32			CIns_8_be::m_numop = 1;
const BS_IPRV		CIns_8_be::m_priviledge(0x0);
const BS_ICAT		CIns_8_be::m_category(0x0);
const BS_IBHV		CIns_8_be::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 9
// Class :: bf
/////////////////////////////////////////////////////////
const UI32			CIns_9_bf::m_id = 9;
const std::string	CIns_9_bf::m_mne("bf");
const UI32			CIns_9_bf::m_numop = 1;
const BS_IPRV		CIns_9_bf::m_priviledge(0x0);
const BS_ICAT		CIns_9_bf::m_category(0x0);
const BS_IBHV		CIns_9_bf::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 10
// Class :: bge
/////////////////////////////////////////////////////////
const UI32			CIns_10_bge::m_id = 10;
const std::string	CIns_10_bge::m_mne("bge");
const UI32			CIns_10_bge::m_numop = 1;
const BS_IPRV		CIns_10_bge::m_priviledge(0x0);
const BS_ICAT		CIns_10_bge::m_category(0x0);
const BS_IBHV		CIns_10_bge::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 11
// Class :: bgt
/////////////////////////////////////////////////////////
const UI32			CIns_11_bgt::m_id = 11;
const std::string	CIns_11_bgt::m_mne("bgt");
const UI32			CIns_11_bgt::m_numop = 1;
const BS_IPRV		CIns_11_bgt::m_priviledge(0x0);
const BS_ICAT		CIns_11_bgt::m_category(0x0);
const BS_IBHV		CIns_11_bgt::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 12
// Class :: bh
/////////////////////////////////////////////////////////
const UI32			CIns_12_bh::m_id = 12;
const std::string	CIns_12_bh::m_mne("bh");
const UI32			CIns_12_bh::m_numop = 1;
const BS_IPRV		CIns_12_bh::m_priviledge(0x0);
const BS_ICAT		CIns_12_bh::m_category(0x0);
const BS_IBHV		CIns_12_bh::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 13
// Class :: ble
/////////////////////////////////////////////////////////
const UI32			CIns_13_ble::m_id = 13;
const std::string	CIns_13_ble::m_mne("ble");
const UI32			CIns_13_ble::m_numop = 1;
const BS_IPRV		CIns_13_ble::m_priviledge(0x0);
const BS_ICAT		CIns_13_ble::m_category(0x0);
const BS_IBHV		CIns_13_ble::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 14
// Class :: bl
/////////////////////////////////////////////////////////
const UI32			CIns_14_bl::m_id = 14;
const std::string	CIns_14_bl::m_mne("bl");
const UI32			CIns_14_bl::m_numop = 1;
const BS_IPRV		CIns_14_bl::m_priviledge(0x0);
const BS_ICAT		CIns_14_bl::m_category(0x0);
const BS_IBHV		CIns_14_bl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 15
// Class :: blt
/////////////////////////////////////////////////////////
const UI32			CIns_15_blt::m_id = 15;
const std::string	CIns_15_blt::m_mne("blt");
const UI32			CIns_15_blt::m_numop = 1;
const BS_IPRV		CIns_15_blt::m_priviledge(0x0);
const BS_ICAT		CIns_15_blt::m_category(0x0);
const BS_IBHV		CIns_15_blt::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 16
// Class :: bn
/////////////////////////////////////////////////////////
const UI32			CIns_16_bn::m_id = 16;
const std::string	CIns_16_bn::m_mne("bn");
const UI32			CIns_16_bn::m_numop = 1;
const BS_IPRV		CIns_16_bn::m_priviledge(0x0);
const BS_ICAT		CIns_16_bn::m_category(0x0);
const BS_IBHV		CIns_16_bn::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 17
// Class :: bnc
/////////////////////////////////////////////////////////
const UI32			CIns_17_bnc::m_id = 17;
const std::string	CIns_17_bnc::m_mne("bnc");
const UI32			CIns_17_bnc::m_numop = 1;
const BS_IPRV		CIns_17_bnc::m_priviledge(0x0);
const BS_ICAT		CIns_17_bnc::m_category(0x0);
const BS_IBHV		CIns_17_bnc::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 18
// Class :: bne
/////////////////////////////////////////////////////////
const UI32			CIns_18_bne::m_id = 18;
const std::string	CIns_18_bne::m_mne("bne");
const UI32			CIns_18_bne::m_numop = 1;
const BS_IPRV		CIns_18_bne::m_priviledge(0x0);
const BS_ICAT		CIns_18_bne::m_category(0x0);
const BS_IBHV		CIns_18_bne::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 19
// Class :: bnh
/////////////////////////////////////////////////////////
const UI32			CIns_19_bnh::m_id = 19;
const std::string	CIns_19_bnh::m_mne("bnh");
const UI32			CIns_19_bnh::m_numop = 1;
const BS_IPRV		CIns_19_bnh::m_priviledge(0x0);
const BS_ICAT		CIns_19_bnh::m_category(0x0);
const BS_IBHV		CIns_19_bnh::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 20
// Class :: bnl
/////////////////////////////////////////////////////////
const UI32			CIns_20_bnl::m_id = 20;
const std::string	CIns_20_bnl::m_mne("bnl");
const UI32			CIns_20_bnl::m_numop = 1;
const BS_IPRV		CIns_20_bnl::m_priviledge(0x0);
const BS_ICAT		CIns_20_bnl::m_category(0x0);
const BS_IBHV		CIns_20_bnl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 21
// Class :: bnv
/////////////////////////////////////////////////////////
const UI32			CIns_21_bnv::m_id = 21;
const std::string	CIns_21_bnv::m_mne("bnv");
const UI32			CIns_21_bnv::m_numop = 1;
const BS_IPRV		CIns_21_bnv::m_priviledge(0x0);
const BS_ICAT		CIns_21_bnv::m_category(0x0);
const BS_IBHV		CIns_21_bnv::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 22
// Class :: bnz
/////////////////////////////////////////////////////////
const UI32			CIns_22_bnz::m_id = 22;
const std::string	CIns_22_bnz::m_mne("bnz");
const UI32			CIns_22_bnz::m_numop = 1;
const BS_IPRV		CIns_22_bnz::m_priviledge(0x0);
const BS_ICAT		CIns_22_bnz::m_category(0x0);
const BS_IBHV		CIns_22_bnz::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 23
// Class :: bp
/////////////////////////////////////////////////////////
const UI32			CIns_23_bp::m_id = 23;
const std::string	CIns_23_bp::m_mne("bp");
const UI32			CIns_23_bp::m_numop = 1;
const BS_IPRV		CIns_23_bp::m_priviledge(0x0);
const BS_ICAT		CIns_23_bp::m_category(0x0);
const BS_IBHV		CIns_23_bp::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 24
// Class :: br
/////////////////////////////////////////////////////////
const UI32			CIns_24_br::m_id = 24;
const std::string	CIns_24_br::m_mne("br");
const UI32			CIns_24_br::m_numop = 1;
const BS_IPRV		CIns_24_br::m_priviledge(0x0);
const BS_ICAT		CIns_24_br::m_category(0x0);
const BS_IBHV		CIns_24_br::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 25
// Class :: bsa
/////////////////////////////////////////////////////////
const UI32			CIns_25_bsa::m_id = 25;
const std::string	CIns_25_bsa::m_mne("bsa");
const UI32			CIns_25_bsa::m_numop = 1;
const BS_IPRV		CIns_25_bsa::m_priviledge(0x0);
const BS_ICAT		CIns_25_bsa::m_category(0x0);
const BS_IBHV		CIns_25_bsa::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 26
// Class :: bt
/////////////////////////////////////////////////////////
const UI32			CIns_26_bt::m_id = 26;
const std::string	CIns_26_bt::m_mne("bt");
const UI32			CIns_26_bt::m_numop = 1;
const BS_IPRV		CIns_26_bt::m_priviledge(0x0);
const BS_ICAT		CIns_26_bt::m_category(0x0);
const BS_IBHV		CIns_26_bt::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 27
// Class :: bv
/////////////////////////////////////////////////////////
const UI32			CIns_27_bv::m_id = 27;
const std::string	CIns_27_bv::m_mne("bv");
const UI32			CIns_27_bv::m_numop = 1;
const BS_IPRV		CIns_27_bv::m_priviledge(0x0);
const BS_ICAT		CIns_27_bv::m_category(0x0);
const BS_IBHV		CIns_27_bv::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 28
// Class :: bz
/////////////////////////////////////////////////////////
const UI32			CIns_28_bz::m_id = 28;
const std::string	CIns_28_bz::m_mne("bz");
const UI32			CIns_28_bz::m_numop = 1;
const BS_IPRV		CIns_28_bz::m_priviledge(0x0);
const BS_ICAT		CIns_28_bz::m_category(0x0);
const BS_IBHV		CIns_28_bz::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 29
// Class :: bc
/////////////////////////////////////////////////////////
std::string CIns_29_bc::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};
const UI32			CIns_29_bc::m_id = 29;
const std::string	CIns_29_bc::m_mne("bc");
const UI32			CIns_29_bc::m_numop = 1;
const BS_IPRV		CIns_29_bc::m_priviledge(0x0);
const BS_ICAT		CIns_29_bc::m_category(0x0);
const BS_IBHV		CIns_29_bc::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 30
// Class :: be
/////////////////////////////////////////////////////////
std::string CIns_30_be::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() :( opr(0)->GetLabel()) );
	}
	return ss.str();
};
const UI32			CIns_30_be::m_id = 30;
const std::string	CIns_30_be::m_mne("be");
const UI32			CIns_30_be::m_numop = 1;
const BS_IPRV		CIns_30_be::m_priviledge(0x0);
const BS_ICAT		CIns_30_be::m_category(0x0);
const BS_IBHV		CIns_30_be::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 31
// Class :: bf
/////////////////////////////////////////////////////////
std::string CIns_31_bf::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_31_bf::m_id = 31;
const std::string	CIns_31_bf::m_mne("bf");
const UI32			CIns_31_bf::m_numop = 1;
const BS_IPRV		CIns_31_bf::m_priviledge(0x0);
const BS_ICAT		CIns_31_bf::m_category(0x0);
const BS_IBHV		CIns_31_bf::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 32
// Class :: bge
/////////////////////////////////////////////////////////
std::string CIns_32_bge::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_32_bge::m_id = 32;
const std::string	CIns_32_bge::m_mne("bge");
const UI32			CIns_32_bge::m_numop = 1;
const BS_IPRV		CIns_32_bge::m_priviledge(0x0);
const BS_ICAT		CIns_32_bge::m_category(0x0);
const BS_IBHV		CIns_32_bge::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 33
// Class :: bgt
/////////////////////////////////////////////////////////
std::string CIns_33_bgt::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_33_bgt::m_id = 33;
const std::string	CIns_33_bgt::m_mne("bgt");
const UI32			CIns_33_bgt::m_numop = 1;
const BS_IPRV		CIns_33_bgt::m_priviledge(0x0);
const BS_ICAT		CIns_33_bgt::m_category(0x0);
const BS_IBHV		CIns_33_bgt::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 34
// Class :: bh
/////////////////////////////////////////////////////////
std::string CIns_34_bh::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_34_bh::m_id = 34;
const std::string	CIns_34_bh::m_mne("bh");
const UI32			CIns_34_bh::m_numop = 1;
const BS_IPRV		CIns_34_bh::m_priviledge(0x0);
const BS_ICAT		CIns_34_bh::m_category(0x0);
const BS_IBHV		CIns_34_bh::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 35
// Class :: ble
/////////////////////////////////////////////////////////
std::string CIns_35_ble::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() :( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_35_ble::m_id = 35;
const std::string	CIns_35_ble::m_mne("ble");
const UI32			CIns_35_ble::m_numop = 1;
const BS_IPRV		CIns_35_ble::m_priviledge(0x0);
const BS_ICAT		CIns_35_ble::m_category(0x0);
const BS_IBHV		CIns_35_ble::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 36
// Class :: bl
/////////////////////////////////////////////////////////
std::string CIns_36_bl::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_36_bl::m_id = 36;
const std::string	CIns_36_bl::m_mne("bl");
const UI32			CIns_36_bl::m_numop = 1;
const BS_IPRV		CIns_36_bl::m_priviledge(0x0);
const BS_ICAT		CIns_36_bl::m_category(0x0);
const BS_IBHV		CIns_36_bl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 37
// Class :: blt
/////////////////////////////////////////////////////////
std::string CIns_37_blt::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_37_blt::m_id = 37;
const std::string	CIns_37_blt::m_mne("blt");
const UI32			CIns_37_blt::m_numop = 1;
const BS_IPRV		CIns_37_blt::m_priviledge(0x0);
const BS_ICAT		CIns_37_blt::m_category(0x0);
const BS_IBHV		CIns_37_blt::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 38
// Class :: bn
/////////////////////////////////////////////////////////
std::string CIns_38_bn::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_38_bn::m_id = 38;
const std::string	CIns_38_bn::m_mne("bn");
const UI32			CIns_38_bn::m_numop = 1;
const BS_IPRV		CIns_38_bn::m_priviledge(0x0);
const BS_ICAT		CIns_38_bn::m_category(0x0);
const BS_IBHV		CIns_38_bn::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 39
// Class :: bnc
/////////////////////////////////////////////////////////
std::string CIns_39_bnc::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_39_bnc::m_id = 39;
const std::string	CIns_39_bnc::m_mne("bnc");
const UI32			CIns_39_bnc::m_numop = 1;
const BS_IPRV		CIns_39_bnc::m_priviledge(0x0);
const BS_ICAT		CIns_39_bnc::m_category(0x0);
const BS_IBHV		CIns_39_bnc::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 40
// Class :: bne
/////////////////////////////////////////////////////////
std::string CIns_40_bne::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_40_bne::m_id = 40;
const std::string	CIns_40_bne::m_mne("bne");
const UI32			CIns_40_bne::m_numop = 1;
const BS_IPRV		CIns_40_bne::m_priviledge(0x0);
const BS_ICAT		CIns_40_bne::m_category(0x0);
const BS_IBHV		CIns_40_bne::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 41
// Class :: bnh
/////////////////////////////////////////////////////////
std::string CIns_41_bnh::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_41_bnh::m_id = 41;
const std::string	CIns_41_bnh::m_mne("bnh");
const UI32			CIns_41_bnh::m_numop = 1;
const BS_IPRV		CIns_41_bnh::m_priviledge(0x0);
const BS_ICAT		CIns_41_bnh::m_category(0x0);
const BS_IBHV		CIns_41_bnh::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 42
// Class :: bnl
/////////////////////////////////////////////////////////
std::string CIns_42_bnl::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_42_bnl::m_id = 42;
const std::string	CIns_42_bnl::m_mne("bnl");
const UI32			CIns_42_bnl::m_numop = 1;
const BS_IPRV		CIns_42_bnl::m_priviledge(0x0);
const BS_ICAT		CIns_42_bnl::m_category(0x0);
const BS_IBHV		CIns_42_bnl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 43
// Class :: bnv
/////////////////////////////////////////////////////////
std::string CIns_43_bnv::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_43_bnv::m_id = 43;
const std::string	CIns_43_bnv::m_mne("bnv");
const UI32			CIns_43_bnv::m_numop = 1;
const BS_IPRV		CIns_43_bnv::m_priviledge(0x0);
const BS_ICAT		CIns_43_bnv::m_category(0x0);
const BS_IBHV		CIns_43_bnv::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 44
// Class :: bnz
/////////////////////////////////////////////////////////
std::string CIns_44_bnz::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_44_bnz::m_id = 44;
const std::string	CIns_44_bnz::m_mne("bnz");
const UI32			CIns_44_bnz::m_numop = 1;
const BS_IPRV		CIns_44_bnz::m_priviledge(0x0);
const BS_ICAT		CIns_44_bnz::m_category(0x0);
const BS_IBHV		CIns_44_bnz::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 45
// Class :: bp
/////////////////////////////////////////////////////////
std::string CIns_45_bp::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_45_bp::m_id = 45;
const std::string	CIns_45_bp::m_mne("bp");
const UI32			CIns_45_bp::m_numop = 1;
const BS_IPRV		CIns_45_bp::m_priviledge(0x0);
const BS_ICAT		CIns_45_bp::m_category(0x0);
const BS_IBHV		CIns_45_bp::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 46
// Class :: bsa
/////////////////////////////////////////////////////////
std::string CIns_46_bsa::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_46_bsa::m_id = 46;
const std::string	CIns_46_bsa::m_mne("bsa");
const UI32			CIns_46_bsa::m_numop = 1;
const BS_IPRV		CIns_46_bsa::m_priviledge(0x0);
const BS_ICAT		CIns_46_bsa::m_category(0x0);
const BS_IBHV		CIns_46_bsa::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 47
// Class :: bt
/////////////////////////////////////////////////////////
std::string CIns_47_bt::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_47_bt::m_id = 47;
const std::string	CIns_47_bt::m_mne("bt");
const UI32			CIns_47_bt::m_numop = 1;
const BS_IPRV		CIns_47_bt::m_priviledge(0x0);
const BS_ICAT		CIns_47_bt::m_category(0x0);
const BS_IBHV		CIns_47_bt::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 48
// Class :: bv
/////////////////////////////////////////////////////////
std::string CIns_48_bv::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_48_bv::m_id = 48;
const std::string	CIns_48_bv::m_mne("bv");
const UI32			CIns_48_bv::m_numop = 1;
const BS_IPRV		CIns_48_bv::m_priviledge(0x0);
const BS_ICAT		CIns_48_bv::m_category(0x0);
const BS_IBHV		CIns_48_bv::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 49
// Class :: bz
/////////////////////////////////////////////////////////
std::string CIns_49_bz::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne()+"17";
	if (num > 0) {
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	}
	return ss.str();
};

const UI32			CIns_49_bz::m_id = 49;
const std::string	CIns_49_bz::m_mne("bz");
const UI32			CIns_49_bz::m_numop = 1;
const BS_IPRV		CIns_49_bz::m_priviledge(0x0);
const BS_ICAT		CIns_49_bz::m_category(0x0);
const BS_IBHV		CIns_49_bz::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 50
// Class :: bins
/////////////////////////////////////////////////////////
UI32 CIns_50_bins::Assemble(UI64* n) {

	UI32 pos	= *opr(1);	// lsb = pos
	UI32 width	= *opr(2);	// msb = pos + width - 1

	while ((width + pos - 1) > 31) {
		pos--;
	}
	opr(1)->Replace(pos);
	return IInstruction::Assemble(n);
}

const UI32			CIns_50_bins::m_id = 50;
const std::string	CIns_50_bins::m_mne("bins");
const UI32			CIns_50_bins::m_numop = 4;
const BS_IPRV		CIns_50_bins::m_priviledge(0x0);
const BS_ICAT		CIns_50_bins::m_category(0x0);
const BS_IBHV		CIns_50_bins::m_behavior(0x0);
const UI32          CIns_50_bins::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 51
// Class :: bsh
/////////////////////////////////////////////////////////
const UI32			CIns_51_bsh::m_id = 51;
const std::string	CIns_51_bsh::m_mne("bsh");
const UI32			CIns_51_bsh::m_numop = 2;
const BS_IPRV		CIns_51_bsh::m_priviledge(0x0);
const BS_ICAT		CIns_51_bsh::m_category(0x0);
const BS_IBHV		CIns_51_bsh::m_behavior(0x0);
const UI32          CIns_51_bsh::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 52
// Class :: bsw
/////////////////////////////////////////////////////////
const UI32			CIns_52_bsw::m_id = 52;
const std::string	CIns_52_bsw::m_mne("bsw");
const UI32			CIns_52_bsw::m_numop = 2;
const BS_IPRV		CIns_52_bsw::m_priviledge(0x0);
const BS_ICAT		CIns_52_bsw::m_category(0x0);
const BS_IBHV		CIns_52_bsw::m_behavior(0x0);
const UI32          CIns_52_bsw::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 53
// Class :: callt
/////////////////////////////////////////////////////////

void CIns_53_callt::Regulate(IRegulation* pReg) {
    IInstruction::Regulate(pReg);

    if (pReg->Pass()) {
        UI32 entry = (UI32)*(opr(0));
        UI32 CTBP = 0;
        pReg->m_pSim->ReadSysRegister(&CTBP, "CTBP", pReg->m_ht);

        if (g_sim->IsMDPexception(CTBP + entry * 2, 2, true, false) != NO_ERROR) {
            this->SetException(0x91, 0x90);
        }
    }
}
const UI32			CIns_53_callt::m_id = 53;
const std::string	CIns_53_callt::m_mne("callt");
const UI32			CIns_53_callt::m_numop = 1;
const BS_IPRV		CIns_53_callt::m_priviledge(0x0);
const BS_ICAT		CIns_53_callt::m_category(0x0);
const BS_IBHV		CIns_53_callt::m_behavior(0xc01);



/////////////////////////////////////////////////////////
// InsID :: 54
// Class :: caxi
/////////////////////////////////////////////////////////
const UI32			CIns_54_caxi::m_id = 54;
const std::string	CIns_54_caxi::m_mne("caxi");
const UI32			CIns_54_caxi::m_numop = 3;
const BS_IPRV		CIns_54_caxi::m_priviledge(0x0);
const BS_ICAT		CIns_54_caxi::m_category(0x0);
const BS_IBHV		CIns_54_caxi::m_behavior(0x3);
const UI32          CIns_54_caxi::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 55
// Class :: cll
/////////////////////////////////////////////////////////
const UI32			CIns_55_cll::m_id = 55;
const std::string	CIns_55_cll::m_mne("cll");
const UI32			CIns_55_cll::m_numop = 0;
const BS_IPRV		CIns_55_cll::m_priviledge(0x0);
const BS_ICAT		CIns_55_cll::m_category(0x8);
const BS_IBHV		CIns_55_cll::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 56
// Class :: clr1
/////////////////////////////////////////////////////////
const UI32			CIns_56_clr1::m_id = 56;
const std::string	CIns_56_clr1::m_mne("clr1");
const UI32			CIns_56_clr1::m_numop = 2;
const BS_IPRV		CIns_56_clr1::m_priviledge(0x0);
const BS_ICAT		CIns_56_clr1::m_category(0x0);
const BS_IBHV		CIns_56_clr1::m_behavior(0x3);
const UI32          CIns_56_clr1::m_flag(INS_FLG_Z);


void CIns_56_clr1::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	
	if (this->opr(1)->GetConstraint() != NULL) {
		IInstruction::Regulate(pReg);
	}
}

/////////////////////////////////////////////////////////
// InsID :: 57
// Class :: clr1
/////////////////////////////////////////////////////////
const UI32			CIns_57_clr1::m_id = 57;
const std::string	CIns_57_clr1::m_mne("clr1");
const UI32			CIns_57_clr1::m_numop = 2;
const BS_IPRV		CIns_57_clr1::m_priviledge(0x0);
const BS_ICAT		CIns_57_clr1::m_category(0x0);
const BS_IBHV		CIns_57_clr1::m_behavior(0x3);
const UI32          CIns_57_clr1::m_flag(INS_FLG_Z);



/////////////////////////////////////////////////////////
// InsID :: 58
// Class :: cmov
/////////////////////////////////////////////////////////
std::string CIns_58_cmov::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;

	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << val;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	ss << ", " << opr(3)->GetCode();
	return ss.str();
}

const UI32			CIns_58_cmov::m_id = 58;
const std::string	CIns_58_cmov::m_mne("cmov");
const UI32			CIns_58_cmov::m_numop = 4;
const BS_IPRV		CIns_58_cmov::m_priviledge(0x0);
const BS_ICAT		CIns_58_cmov::m_category(0x0);
const BS_IBHV		CIns_58_cmov::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 59
// Class :: cmov
/////////////////////////////////////////////////////////
std::string CIns_59_cmov::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;

	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << val;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	ss << ", " << opr(3)->GetCode();
	return ss.str();
}

const UI32			CIns_59_cmov::m_id = 59;
const std::string	CIns_59_cmov::m_mne("cmov");
const UI32			CIns_59_cmov::m_numop = 4;
const BS_IPRV		CIns_59_cmov::m_priviledge(0x0);
const BS_ICAT		CIns_59_cmov::m_category(0x0);
const BS_IBHV		CIns_59_cmov::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 60
// Class :: cmp
/////////////////////////////////////////////////////////
const UI32			CIns_60_cmp::m_id = 60;
const std::string	CIns_60_cmp::m_mne("cmp");
const UI32			CIns_60_cmp::m_numop = 2;
const BS_IPRV		CIns_60_cmp::m_priviledge(0x0);
const BS_ICAT		CIns_60_cmp::m_category(0x0);
const BS_IBHV		CIns_60_cmp::m_behavior(0x0);
const UI32          CIns_60_cmp::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 61
// Class :: cmp
/////////////////////////////////////////////////////////
const UI32			CIns_61_cmp::m_id = 61;
const std::string	CIns_61_cmp::m_mne("cmp");
const UI32			CIns_61_cmp::m_numop = 2;
const BS_IPRV		CIns_61_cmp::m_priviledge(0x0);
const BS_ICAT		CIns_61_cmp::m_category(0x0);
const BS_IBHV		CIns_61_cmp::m_behavior(0x0);
const UI32          CIns_61_cmp::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 62
// Class :: ctret
/////////////////////////////////////////////////////////
const UI32			CIns_62_ctret::m_id = 62;
const std::string	CIns_62_ctret::m_mne("ctret");
const UI32			CIns_62_ctret::m_numop = 0;
const BS_IPRV		CIns_62_ctret::m_priviledge(0x0);
const BS_ICAT		CIns_62_ctret::m_category(0x0);
const BS_IBHV		CIns_62_ctret::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 63
// Class :: di
/////////////////////////////////////////////////////////
const UI32			CIns_63_di::m_id = 63;
const std::string	CIns_63_di::m_mne("di");
const UI32			CIns_63_di::m_numop = 0;
const BS_IPRV		CIns_63_di::m_priviledge(0x8);
const BS_ICAT		CIns_63_di::m_category(0x0);
const BS_IBHV		CIns_63_di::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 64
// Class :: dispose
/////////////////////////////////////////////////////////
std::string CIns_64_dispose::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	
	UI32 lst12 = List12BitOrder((UI32)*opr(1));
	ss << ' ' << opr(0)->GetCode();
	ss << ',' << "0x" << std::hex << lst12;
	
	return ss.str();
}

void CIns_64_dispose::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(0);
	IInstruction::Regulate(pReg);
}

REGFLG CIns_64_dispose::GetGrSrc() {
	return 0x00000008U; // SP is rw
}

REGFLG CIns_64_dispose::GetGrDst() {
	UI32 lst12 = List12BitOrder((UI32)*opr(1));
	lst12 = (lst12 << 20) | 0x00000008U; // SP is rw
	return lst12;
}

const UI32			CIns_64_dispose::m_id = 64;
const std::string	CIns_64_dispose::m_mne("dispose");
const UI32			CIns_64_dispose::m_numop = 2;
const BS_IPRV		CIns_64_dispose::m_priviledge(0x0);
const BS_ICAT		CIns_64_dispose::m_category(0x0);
const BS_IBHV		CIns_64_dispose::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 65
// Class :: dispose
/////////////////////////////////////////////////////////
std::string CIns_65_dispose::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	
	UI32 lst12 = List12BitOrder((UI32)*opr(1));
	ss << ' ' << opr(0)->GetCode();
	ss << ',' << "0x" << std::hex << lst12;
	ss << ',' << opr(2)->GetCode();
	
	return ss.str();
}

void CIns_65_dispose::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(0);
	if (this->opr(2)->Idx() != 3) 
		IInstruction::Regulate(pReg);

    if (pReg->Pass()) {
        //!< Checking valid jump address.
        std::string sDisposeTarget = this->GetJumpTarget();
        std::vector<IInstruction*> &pNeedIns = this->GetInsNeed();
        std::vector<IInstruction*>::iterator itr;
        UI32 address = 0;
        UI32 nJump_Address = 0;
        bool bHasLabel = false;

        if (sDisposeTarget.size() != 0) {
            nJump_Address = g_asf->SearchAddress(sDisposeTarget);
            //!< Check every Ins to find label jump target.
            for (itr = pNeedIns.begin(); itr != pNeedIns.end(); itr++) {
                IOperand*	pOpr;
                UI32 k = 0;
                for (k = 0; (pOpr = (*itr)->opr(k)) != NULL; k++) {
                    // Operand is label to replace effective value.
                    if (pOpr->GetLabel() != nullptr) {
                        if (pOpr->GetLabel() == sDisposeTarget) {
                            address = UI32(*pOpr);
                            this->ClearInsNeed();
                            bHasLabel = true;
                            break;
                        }
                    }
                }
                if (k < ((*itr)->GetOpNum())) {
                    break;
                }
            }
            //!< Read jump address from simulator
            if (bHasLabel) {
                if (pReg->m_pSim->ReadGrReg(&nJump_Address, (SI32)this->opr(2)->Idx(), pReg->m_ht) != true) {
                    std::runtime_error excep("Simulator error : Read GR");
                    throw excep;
                }
            }

            UI32 srcReg = GetGrSrc();			// Source Register: the register which store jump destination and r3
            UI32 dstReg = GetGrDst();
            if (((srcReg & dstReg) & 0xfffffff7) != 0) {
                UI32 regCount = 0;
                UI32 jmpStrAdr = 0U;// just a template for avoid non initialize
                UI32 PSIZE = 4;		//Memory size to preset: 4
                UI64 cmpVal = 0U;

                //Read r3 for stack pointer value
                if (pReg->m_pSim->ReadGrReg(&jmpStrAdr, 3, pReg->m_ht) != true) {
                    std::runtime_error excep("Simulator error : Read GR");
                    throw excep;
                }
                jmpStrAdr &= 0xfffffffc;		//Align address

                //Count the number of register in list 12 that higher and will be loaded before reg
                for (UI32 i = (1 + opr(2)->Idx()); i <= 31; i++) {
                    regCount += ((dstReg & (1 << i)) > 0);
                }

                // Load addr: sp + Imm << 2 + number of Register which are loaded before
                jmpStrAdr += ((*opr(0)) * 4) + regCount * 4;

                if ((nJump_Address != 0U) && (jmpStrAdr != 0U)) {
                    pReg->m_pSim->PresetMemory(true, 0, jmpStrAdr, PSIZE, nJump_Address);
                    pReg->m_pSim->ReadMemory(jmpStrAdr, PSIZE, &cmpVal);
                }
                // Load addr: sp + Imm << 2 + number of Register which are loaded before
                if ((cmpVal & 0x00000000ffffffff) != (UI64)nJump_Address) { // Skip write memory, do not generate reg in list12	
                    IRandom* pRand = new CMersenneTwister();
                    opr(2)->Replace(pRand->GetRange(4U, 19U));
                    pReg->ReSim();
                    pReg->ReAsm();
                }

            } else if ((!bHasLabel) || (nJump_Address != address)) {
                // This adjust value will be orver write by Mov32P in RegulateValueContrain function.
                pReg->m_vGr.push_back(std::pair<UI32, UI32>((UI32)this->opr(2)->Idx(), (UI32)nJump_Address));
                pReg->ReSim();
                pReg->ReAsm();
            } else {
                // Do nothing
            }
        }
    }
}

REGFLG CIns_65_dispose::GetGrSrc() {
	UI32 jmpreg = opr(2)->Idx();
	return 0x00000008U | (1 << jmpreg); // SP is rw
}

REGFLG CIns_65_dispose::GetGrDst() {
	UI32 lst12 = List12BitOrder((UI32)*opr(1));
	
	lst12 = (lst12 << 20) | 0x00000008U; // SP is rw
	return lst12 ;
}

IInstruction * CIns_65_dispose:: Fix() {
	//UI32 srcReg, dstReg;
	IRandom* pRand = new CMersenneTwister();
	UI32 num = GetOpNum();

	//	Fix the operands
	for (UI32 i = 0; i < num; i++) {
		opr(i)->Fix();
	}

	// Set low value to imm (reduce adjustment code for jumping by r3( for more information, please refer to CBlockManager::ChainBcondSequence function))
	if (opr(2)->Idx() == 3){
		opr(0)->Replace(pRand->GetRange(0U, 32U));
	}
	delete pRand;
	return this;
}

const UI32			CIns_65_dispose::m_id = 65;
const std::string	CIns_65_dispose::m_mne("dispose");
const UI32			CIns_65_dispose::m_numop = 3;
const BS_IPRV		CIns_65_dispose::m_priviledge(0x0);
const BS_ICAT		CIns_65_dispose::m_category(0x0);
const BS_IBHV		CIns_65_dispose::m_behavior(0x401);



/////////////////////////////////////////////////////////
// InsID :: 66
// Class :: div
/////////////////////////////////////////////////////////
const UI32			CIns_66_div::m_id = 66;
const std::string	CIns_66_div::m_mne("div");
const UI32			CIns_66_div::m_numop = 3;
const BS_IPRV		CIns_66_div::m_priviledge(0x0);
const BS_ICAT		CIns_66_div::m_category(0x0);
const BS_IBHV		CIns_66_div::m_behavior(0x0);
const UI32          CIns_66_div::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 67
// Class :: divh
/////////////////////////////////////////////////////////
const UI32			CIns_67_divh::m_id = 67;
const std::string	CIns_67_divh::m_mne("divh");
const UI32			CIns_67_divh::m_numop = 2;
const BS_IPRV		CIns_67_divh::m_priviledge(0x0);
const BS_ICAT		CIns_67_divh::m_category(0x0);
const BS_IBHV		CIns_67_divh::m_behavior(0x0);
const UI32          CIns_67_divh::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 68
// Class :: divh
/////////////////////////////////////////////////////////
const UI32			CIns_68_divh::m_id = 68;
const std::string	CIns_68_divh::m_mne("divh");
const UI32			CIns_68_divh::m_numop = 3;
const BS_IPRV		CIns_68_divh::m_priviledge(0x0);
const BS_ICAT		CIns_68_divh::m_category(0x0);
const BS_IBHV		CIns_68_divh::m_behavior(0x0);
const UI32          CIns_68_divh::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 69
// Class :: divhu
/////////////////////////////////////////////////////////
const UI32			CIns_69_divhu::m_id = 69;
const std::string	CIns_69_divhu::m_mne("divhu");
const UI32			CIns_69_divhu::m_numop = 3;
const BS_IPRV		CIns_69_divhu::m_priviledge(0x0);
const BS_ICAT		CIns_69_divhu::m_category(0x0);
const BS_IBHV		CIns_69_divhu::m_behavior(0x0);
const UI32          CIns_69_divhu::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 70
// Class :: divq
/////////////////////////////////////////////////////////
const UI32			CIns_70_divq::m_id = 70;
const std::string	CIns_70_divq::m_mne("divq");
const UI32			CIns_70_divq::m_numop = 3;
const BS_IPRV		CIns_70_divq::m_priviledge(0x0);
const BS_ICAT		CIns_70_divq::m_category(0x0);
const BS_IBHV		CIns_70_divq::m_behavior(0x0);
const UI32          CIns_70_divq::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 71
// Class :: divqu
/////////////////////////////////////////////////////////
const UI32			CIns_71_divqu::m_id = 71;
const std::string	CIns_71_divqu::m_mne("divqu");
const UI32			CIns_71_divqu::m_numop = 3;
const BS_IPRV		CIns_71_divqu::m_priviledge(0x0);
const BS_ICAT		CIns_71_divqu::m_category(0x0);
const BS_IBHV		CIns_71_divqu::m_behavior(0x0);
const UI32          CIns_71_divqu::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 72
// Class :: divu
/////////////////////////////////////////////////////////
const UI32			CIns_72_divu::m_id = 72;
const std::string	CIns_72_divu::m_mne("divu");
const UI32			CIns_72_divu::m_numop = 3;
const BS_IPRV		CIns_72_divu::m_priviledge(0x0);
const BS_ICAT		CIns_72_divu::m_category(0x0);
const BS_IBHV		CIns_72_divu::m_behavior(0x0);
const UI32          CIns_72_divu::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 73
// Class :: ei
/////////////////////////////////////////////////////////
const UI32			CIns_73_ei::m_id = 73;
const std::string	CIns_73_ei::m_mne("ei");
const UI32			CIns_73_ei::m_numop = 0;
const BS_IPRV		CIns_73_ei::m_priviledge(0x0);
const BS_ICAT		CIns_73_ei::m_category(0x0);
const BS_IBHV		CIns_73_ei::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 74
// Class :: eiret
/////////////////////////////////////////////////////////
const UI32			CIns_74_eiret::m_id = 74;
const std::string	CIns_74_eiret::m_mne("eiret");
const UI32			CIns_74_eiret::m_numop = 0;
const BS_IPRV		CIns_74_eiret::m_priviledge(0x8);
const BS_ICAT		CIns_74_eiret::m_category(0x0);
const BS_IBHV		CIns_74_eiret::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 75
// Class :: feret
/////////////////////////////////////////////////////////
const UI32			CIns_75_feret::m_id = 75;
const std::string	CIns_75_feret::m_mne("feret");
const UI32			CIns_75_feret::m_numop = 0;
const BS_IPRV		CIns_75_feret::m_priviledge(0x8);
const BS_ICAT		CIns_75_feret::m_category(0x0);
const BS_IBHV		CIns_75_feret::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 76
// Class :: fetrap
/////////////////////////////////////////////////////////
const UI32			CIns_76_fetrap::m_id = 76;
const std::string	CIns_76_fetrap::m_mne("fetrap");
const UI32			CIns_76_fetrap::m_numop = 1;
const BS_IPRV		CIns_76_fetrap::m_priviledge(0x0);
const BS_ICAT		CIns_76_fetrap::m_category(0x0);
const BS_IBHV		CIns_76_fetrap::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 77
// Class :: halt
/////////////////////////////////////////////////////////
const UI32			CIns_77_halt::m_id = 77;
const std::string	CIns_77_halt::m_mne("halt");
const UI32			CIns_77_halt::m_numop = 0;
const BS_IPRV		CIns_77_halt::m_priviledge(0x8);
const BS_ICAT		CIns_77_halt::m_category(0x80);
const BS_IBHV		CIns_77_halt::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 78
// Class :: hsh
/////////////////////////////////////////////////////////
const UI32			CIns_78_hsh::m_id = 78;
const std::string	CIns_78_hsh::m_mne("hsh");
const UI32			CIns_78_hsh::m_numop = 2;
const BS_IPRV		CIns_78_hsh::m_priviledge(0x0);
const BS_ICAT		CIns_78_hsh::m_category(0x0);
const BS_IBHV		CIns_78_hsh::m_behavior(0x0);
const UI32          CIns_78_hsh::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 79
// Class :: hsw
/////////////////////////////////////////////////////////
const UI32			CIns_79_hsw::m_id = 79;
const std::string	CIns_79_hsw::m_mne("hsw");
const UI32			CIns_79_hsw::m_numop = 2;
const BS_IPRV		CIns_79_hsw::m_priviledge(0x0);
const BS_ICAT		CIns_79_hsw::m_category(0x0);
const BS_IBHV		CIns_79_hsw::m_behavior(0x0);
const UI32          CIns_79_hsw::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 80
// Class :: jarl
/////////////////////////////////////////////////////////
std::string CIns_80_jarl::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << "jarl22";
	ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	ss << ',' << ((opr(1)->GetLabel() == NULL) ? opr(1)->GetCode() : ( opr(1)->GetLabel()) );
	return ss.str();
}

const UI32			CIns_80_jarl::m_id = 80;
const std::string	CIns_80_jarl::m_mne("jarl");
const UI32			CIns_80_jarl::m_numop = 2;
const BS_IPRV		CIns_80_jarl::m_priviledge(0x0);
const BS_ICAT		CIns_80_jarl::m_category(0x0);
const BS_IBHV		CIns_80_jarl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 81
// Class :: jarl
/////////////////////////////////////////////////////////
std::string CIns_81_jarl::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << "jarl32";
	ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	ss << ',' << ((opr(1)->GetLabel() == NULL) ? opr(1)->GetCode() : ( opr(1)->GetLabel()) );
	return ss.str();
}

UI32 CIns_81_jarl::Assemble(UI64* n) {
	
	// get value
	UI32 reg1	= opr(1)->Idx();
	UI32 disp32	= *opr(0);
	
	// check
	if (reg1 == 0) {
		return 0;
	}
	if (disp32 & 1) {
		return 0;
	}
	
	//coding
	*n  = 0x00000000000002E0;
	*n |= reg1;
	*n |= ((UI64)disp32<<16);
		
	return 6;
}

const UI32			CIns_81_jarl::m_id = 81;
const std::string	CIns_81_jarl::m_mne("jarl");
const UI32			CIns_81_jarl::m_numop = 2;
const BS_IPRV		CIns_81_jarl::m_priviledge(0x0);
const BS_ICAT		CIns_81_jarl::m_category(0x0);
const BS_IBHV		CIns_81_jarl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 82
// Class :: jarl
/////////////////////////////////////////////////////////

void CIns_82_jarl::Regulate(IRegulation* pReg) {

	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(0);
	//!< Checking valid jump address.
	std::string sJmpTarget = this->GetJumpTarget();	
	std::vector<IInstruction*>::iterator itr;
	UI32 address = 0 ;
	UI32 nJump_Address = 0;
	if (sJmpTarget.size() != 0) {
		//!< Find label jump target.
		nJump_Address = g_asf->SearchAddress(sJmpTarget);

		//!< Read jump address from simulator
		if (pReg->m_pSim->ReadGrReg(&address, (SI32)this->opr(0)->Idx(), pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}

		if(address != nJump_Address) {
			pReg->m_vGr.push_back(std::pair<UI32,UI32>(this->opr(0)->Idx(), (UI32)nJump_Address));
			pReg->ReSim();
			pReg->ReAsm();
		}
	}
}

const UI32			CIns_82_jarl::m_id = 82;
const std::string	CIns_82_jarl::m_mne("jarl");
const UI32			CIns_82_jarl::m_numop = 2;
const BS_IPRV		CIns_82_jarl::m_priviledge(0x0);
const BS_ICAT		CIns_82_jarl::m_category(0x0);
const BS_IBHV		CIns_82_jarl::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 83
// Class :: jmp
/////////////////////////////////////////////////////////

void CIns_83_jmp::Regulate(IRegulation* pReg) {

	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(0);
	//!< Checking valid jump address.
	std::string sJmpTarget = this->GetJumpTarget();	
	std::vector<IInstruction*>::iterator itr;
	UI32 address = 0 ;
	UI32 nJump_Address = 0;
    UI32 PC = 0;
    pReg->m_pSim->ReadPC(&PC);
	if (sJmpTarget.size() != 0) {
		//!< Find label jump target.
		nJump_Address = g_asf->SearchAddress(sJmpTarget);

		//!< Read jump address from simulator
		if (pReg->m_pSim->ReadGrReg(&address, (SI32)this->opr(0)->Idx(), pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		if(address != nJump_Address) {
			pReg->m_vGr.push_back(std::pair<UI32,UI32>(this->opr(0)->Idx(), (UI32)nJump_Address));
			pReg->ReSim();
			pReg->ReAsm();
		}
	}
}

const UI32			CIns_83_jmp::m_id = 83;
const std::string	CIns_83_jmp::m_mne("jmp");
const UI32			CIns_83_jmp::m_numop = 1;
const BS_IPRV		CIns_83_jmp::m_priviledge(0x0);
const BS_ICAT		CIns_83_jmp::m_category(0x0);
const BS_IBHV		CIns_83_jmp::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 84
// Class :: jmp
/////////////////////////////////////////////////////////
void CIns_84_jmp::Regulate(IRegulation* pReg) {

	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(0);
	//!< Checking valid jump address.
	std::string sJmpTarget = this->GetJumpTarget();	
	std::vector<IInstruction*>::iterator itr;
	UI32 address = 0 ;
	UI32 nJump_Address = 0;
	if (sJmpTarget.size() != 0) {
		//!< Find label jump target.
		nJump_Address = g_asf->SearchAddress(sJmpTarget);

		//!< Read jump address from simulator
		if (pReg->m_pSim->ReadGrReg(&address, (SI32)this->opr(0)->Idx(), pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		this->opr(0)->SetRegVal(address);
		address = ((address >> 1) << 1);
        UI32 ndisplacement = (nJump_Address - address);
        this->opr(0)->SetDisp(ndisplacement);
        pReg->ReSim();
        pReg->ReAsm();
        // [FROG]TODO: It will be risk
        this->SetJumpTargetLabel("");
        if (pReg->IsForce()) {
            pReg->m_vGr.push_back(std::pair<UI32, UI32>(this->opr(0)->Idx(), (UI32)address));
        }
    }
}



const UI32			CIns_84_jmp::m_id = 84;
const std::string	CIns_84_jmp::m_mne("jmp");
const UI32			CIns_84_jmp::m_numop = 1;
const BS_IPRV		CIns_84_jmp::m_priviledge(0x0);
const BS_ICAT		CIns_84_jmp::m_category(0x0);
const BS_IBHV		CIns_84_jmp::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 85
// Class :: jr
/////////////////////////////////////////////////////////
std::string CIns_85_jr::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << "jr22";
	ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	return ss.str();
}

const UI32			CIns_85_jr::m_id = 85;
const std::string	CIns_85_jr::m_mne("jr");
const UI32			CIns_85_jr::m_numop = 1;
const BS_IPRV		CIns_85_jr::m_priviledge(0x0);
const BS_ICAT		CIns_85_jr::m_category(0x0);
const BS_IBHV		CIns_85_jr::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 86
// Class :: jr
/////////////////////////////////////////////////////////
std::string CIns_86_jr::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << "jr32";
	ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : ( opr(0)->GetLabel()) );
	return ss.str();
}

UI32 CIns_86_jr::Assemble(UI64* n) {
	
	// get value
	UI32 disp32	= *opr(0);
	
	// check
	if (disp32 & 1) {
		return 0;
	}
	
	//coding
	*n  = 0x00000000000002E0;
	*n |= ((UI64)disp32<<16);
		
	return 6;
}

const UI32			CIns_86_jr::m_id = 86;
const std::string	CIns_86_jr::m_mne("jr");
const UI32			CIns_86_jr::m_numop = 1;
const BS_IPRV		CIns_86_jr::m_priviledge(0x0);
const BS_ICAT		CIns_86_jr::m_category(0x0);
const BS_IBHV		CIns_86_jr::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 87
// Class :: ld.b
/////////////////////////////////////////////////////////
const UI32			CIns_87_ld_b::m_id = 87;
const std::string	CIns_87_ld_b::m_mne("ld.b");
const UI32			CIns_87_ld_b::m_numop = 2;
const BS_IPRV		CIns_87_ld_b::m_priviledge(0x0);
const BS_ICAT		CIns_87_ld_b::m_category(0x0);
const BS_IBHV		CIns_87_ld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 88
// Class :: ld.b
/////////////////////////////////////////////////////////
const UI32			CIns_88_ld_b::m_id = 88;
const std::string	CIns_88_ld_b::m_mne("ld.b");
const UI32			CIns_88_ld_b::m_numop = 2;
const BS_IPRV		CIns_88_ld_b::m_priviledge(0x0);
const BS_ICAT		CIns_88_ld_b::m_category(0x0);
const BS_IBHV		CIns_88_ld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 89
// Class :: ld.bu
/////////////////////////////////////////////////////////
const UI32			CIns_89_ld_bu::m_id = 89;
const std::string	CIns_89_ld_bu::m_mne("ld.bu");
const UI32			CIns_89_ld_bu::m_numop = 2;
const BS_IPRV		CIns_89_ld_bu::m_priviledge(0x0);
const BS_ICAT		CIns_89_ld_bu::m_category(0x0);
const BS_IBHV		CIns_89_ld_bu::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 90
// Class :: ld.bu
/////////////////////////////////////////////////////////
const UI32			CIns_90_ld_bu::m_id = 90;
const std::string	CIns_90_ld_bu::m_mne("ld.bu");
const UI32			CIns_90_ld_bu::m_numop = 2;
const BS_IPRV		CIns_90_ld_bu::m_priviledge(0x0);
const BS_ICAT		CIns_90_ld_bu::m_category(0x0);
const BS_IBHV		CIns_90_ld_bu::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 91
// Class :: ld.dw
/////////////////////////////////////////////////////////
const UI32			CIns_91_ld_dw::m_id = 91;
const std::string	CIns_91_ld_dw::m_mne("ld.dw");
const UI32			CIns_91_ld_dw::m_numop = 2;
const BS_IPRV		CIns_91_ld_dw::m_priviledge(0x0);
const BS_ICAT		CIns_91_ld_dw::m_category(0x0);
const BS_IBHV		CIns_91_ld_dw::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 92
// Class :: ld.h
/////////////////////////////////////////////////////////
const UI32			CIns_92_ld_h::m_id = 92;
const std::string	CIns_92_ld_h::m_mne("ld.h");
const UI32			CIns_92_ld_h::m_numop = 2;
const BS_IPRV		CIns_92_ld_h::m_priviledge(0x0);
const BS_ICAT		CIns_92_ld_h::m_category(0x0);
const BS_IBHV		CIns_92_ld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 93
// Class :: ld.h
/////////////////////////////////////////////////////////
const UI32			CIns_93_ld_h::m_id = 93;
const std::string	CIns_93_ld_h::m_mne("ld.h");
const UI32			CIns_93_ld_h::m_numop = 2;
const BS_IPRV		CIns_93_ld_h::m_priviledge(0x0);
const BS_ICAT		CIns_93_ld_h::m_category(0x0);
const BS_IBHV		CIns_93_ld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 94
// Class :: ld.hu
/////////////////////////////////////////////////////////
const UI32			CIns_94_ld_hu::m_id = 94;
const std::string	CIns_94_ld_hu::m_mne("ld.hu");
const UI32			CIns_94_ld_hu::m_numop = 2;
const BS_IPRV		CIns_94_ld_hu::m_priviledge(0x0);
const BS_ICAT		CIns_94_ld_hu::m_category(0x0);
const BS_IBHV		CIns_94_ld_hu::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 95
// Class :: ld.hu
/////////////////////////////////////////////////////////
const UI32			CIns_95_ld_hu::m_id = 95;
const std::string	CIns_95_ld_hu::m_mne("ld.hu");
const UI32			CIns_95_ld_hu::m_numop = 2;
const BS_IPRV		CIns_95_ld_hu::m_priviledge(0x0);
const BS_ICAT		CIns_95_ld_hu::m_category(0x0);
const BS_IBHV		CIns_95_ld_hu::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 96
// Class :: ld.w
/////////////////////////////////////////////////////////
const UI32			CIns_96_ld_w::m_id = 96;
const std::string	CIns_96_ld_w::m_mne("ld.w");
const UI32			CIns_96_ld_w::m_numop = 2;
const BS_IPRV		CIns_96_ld_w::m_priviledge(0x0);
const BS_ICAT		CIns_96_ld_w::m_category(0x0);
const BS_IBHV		CIns_96_ld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 97
// Class :: ld.w
/////////////////////////////////////////////////////////
const UI32			CIns_97_ld_w::m_id = 97;
const std::string	CIns_97_ld_w::m_mne("ld.w");
const UI32			CIns_97_ld_w::m_numop = 2;
const BS_IPRV		CIns_97_ld_w::m_priviledge(0x0);
const BS_ICAT		CIns_97_ld_w::m_category(0x0);
const BS_IBHV		CIns_97_ld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 98
// Class :: ldl.w
/////////////////////////////////////////////////////////
const UI32			CIns_98_ldl_w::m_id = 98;
const std::string	CIns_98_ldl_w::m_mne("ldl.w");
const UI32			CIns_98_ldl_w::m_numop = 2;
const BS_IPRV		CIns_98_ldl_w::m_priviledge(0x0);
const BS_ICAT		CIns_98_ldl_w::m_category(0x0);
const BS_IBHV		CIns_98_ldl_w::m_behavior(0x1);

void CIns_98_ldl_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	IOperand* poprAddr = opr(0);
	FROG_ASSERT(poprAddr);
	UI32 lnk = 1;
	poprAddr->Regulate(pReg, lnk);

	IOperand* popr = opr(1);
	FROG_ASSERT(popr);
	popr->Regulate(pReg);

}


/////////////////////////////////////////////////////////
// InsID :: 99
// Class :: ldsr
/////////////////////////////////////////////////////////
std::string CIns_99_ldsr::GetCode() {
	UI32 sr = (UI32)*opr(1);
	std::stringstream ss;
	
	ss << "ldsr " << opr(0)->GetCode();
	ss << ", sr" << (sr & 0x1f);
	//ss << ", " << (sr & 0x1f);
	if (sr >> 5) {
		ss << ", sel" << (sr >> 5);
		//ss << ", " << (sr >> 5);
	}
	
	return ss.str();
}

std::string CIns_99_ldsr::GetOutCode() {
	UI32 sr = (UI32)*opr(1);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << "ldsr " << opr(0)->GetCode();
	ss << ", " << (sr & 0x1f);
	if (sr >> 5) {
		ss << ", " << (sr >> 5);
	}
	
	return ss.str();
}

const UI32			CIns_99_ldsr::m_id = 99;
const std::string	CIns_99_ldsr::m_mne("ldsr");
const UI32			CIns_99_ldsr::m_numop = 2;
const BS_IPRV		CIns_99_ldsr::m_priviledge(0x0);
const BS_ICAT		CIns_99_ldsr::m_category(0x0);
const BS_IBHV		CIns_99_ldsr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 100
// Class :: loop
/////////////////////////////////////////////////////////
std::string CIns_100_loop::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	if (num > 1) {
		ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
		ss << ' ' << ((opr(0)->GetLabel() == NULL) ? opr(0)->GetCode() : opr(0)->GetLabel());
		ss << "," << ((opr(1)->GetLabel() == NULL) ? opr(1)->GetCode() :  opr(1)->GetLabel());
	}
	return ss.str();
};

const UI32			CIns_100_loop::m_id = 100;
const std::string	CIns_100_loop::m_mne("loop");
const UI32			CIns_100_loop::m_numop = 2;
const BS_IPRV		CIns_100_loop::m_priviledge(0x0);
const BS_ICAT		CIns_100_loop::m_category(0x0);
const BS_IBHV		CIns_100_loop::m_behavior(0x400);
const UI32          CIns_100_loop::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 101
// Class :: mac
/////////////////////////////////////////////////////////
const UI32			CIns_101_mac::m_id = 101;
const std::string	CIns_101_mac::m_mne("mac");
const UI32			CIns_101_mac::m_numop = 4;
const BS_IPRV		CIns_101_mac::m_priviledge(0x0);
const BS_ICAT		CIns_101_mac::m_category(0x0);
const BS_IBHV		CIns_101_mac::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 102
// Class :: macu
/////////////////////////////////////////////////////////
const UI32			CIns_102_macu::m_id = 102;
const std::string	CIns_102_macu::m_mne("macu");
const UI32			CIns_102_macu::m_numop = 4;
const BS_IPRV		CIns_102_macu::m_priviledge(0x0);
const BS_ICAT		CIns_102_macu::m_category(0x0);
const BS_IBHV		CIns_102_macu::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 103
// Class :: mov
/////////////////////////////////////////////////////////
const UI32			CIns_103_mov::m_id = 103;
const std::string	CIns_103_mov::m_mne("mov");
const UI32			CIns_103_mov::m_numop = 2;
const BS_IPRV		CIns_103_mov::m_priviledge(0x0);
const BS_ICAT		CIns_103_mov::m_category(0x0);
const BS_IBHV		CIns_103_mov::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 104
// Class :: mov
/////////////////////////////////////////////////////////
const UI32			CIns_104_mov::m_id = 104;
const std::string	CIns_104_mov::m_mne("mov");
const UI32			CIns_104_mov::m_numop = 2;
const BS_IPRV		CIns_104_mov::m_priviledge(0x0);
const BS_ICAT		CIns_104_mov::m_category(0x0);
const BS_IBHV		CIns_104_mov::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 105
// Class :: mov
/////////////////////////////////////////////////////////
std::string CIns_105_mov::GetOutCode() {
	std::stringstream ss;
	UI32 num = GetOpNum();
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	if (num > 0) {
		
		if (opr(0)->GetLabel() == NULL) {
			ss << " hilo(" << opr(0)->GetCode() << ") " ;
		} else {
			ss << " hilo(" << opr(0)->GetLabel() << ") " ;
		}
		if (num > 1) {
			ss << ',' << ((opr(1)->GetLabel() == NULL) ? opr(1)->GetCode() : opr(1)->GetLabel());
		}
	}
	return ss.str();
}

UI32 CIns_105_mov::Assemble(UI64* n) {
	
	// get value
	UI32 imm32	= *opr(0);
	UI32 reg1	= opr(1)->Idx();
	
	// check
	// -- this instruction format has no constraint
	
	//coding
	*n  = 0x0000000000000620;
	*n |= reg1;
	*n |= ((UI64)imm32<<16);
		
	return 6;
}

const UI32			CIns_105_mov::m_id = 105;
const std::string	CIns_105_mov::m_mne("mov");
const UI32			CIns_105_mov::m_numop = 2;
const BS_IPRV		CIns_105_mov::m_priviledge(0x0);
const BS_ICAT		CIns_105_mov::m_category(0x0);
const BS_IBHV		CIns_105_mov::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 106
// Class :: movea
/////////////////////////////////////////////////////////
const UI32			CIns_106_movea::m_id = 106;
const std::string	CIns_106_movea::m_mne("movea");
const UI32			CIns_106_movea::m_numop = 3;
const BS_IPRV		CIns_106_movea::m_priviledge(0x0);
const BS_ICAT		CIns_106_movea::m_category(0x0);
const BS_IBHV		CIns_106_movea::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 107
// Class :: movhi
/////////////////////////////////////////////////////////
const UI32			CIns_107_movhi::m_id = 107;
const std::string	CIns_107_movhi::m_mne("movhi");
const UI32			CIns_107_movhi::m_numop = 3;
const BS_IPRV		CIns_107_movhi::m_priviledge(0x0);
const BS_ICAT		CIns_107_movhi::m_category(0x0);
const BS_IBHV		CIns_107_movhi::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 108
// Class :: mul
/////////////////////////////////////////////////////////
const UI32			CIns_108_mul::m_id = 108;
const std::string	CIns_108_mul::m_mne("mul");
const UI32			CIns_108_mul::m_numop = 3;
const BS_IPRV		CIns_108_mul::m_priviledge(0x0);
const BS_ICAT		CIns_108_mul::m_category(0x0);
const BS_IBHV		CIns_108_mul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 109
// Class :: mul
/////////////////////////////////////////////////////////
const UI32			CIns_109_mul::m_id = 109;
const std::string	CIns_109_mul::m_mne("mul");
const UI32			CIns_109_mul::m_numop = 3;
const BS_IPRV		CIns_109_mul::m_priviledge(0x0);
const BS_ICAT		CIns_109_mul::m_category(0x0);
const BS_IBHV		CIns_109_mul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 110
// Class :: mulh
/////////////////////////////////////////////////////////
const UI32			CIns_110_mulh::m_id = 110;
const std::string	CIns_110_mulh::m_mne("mulh");
const UI32			CIns_110_mulh::m_numop = 2;
const BS_IPRV		CIns_110_mulh::m_priviledge(0x0);
const BS_ICAT		CIns_110_mulh::m_category(0x0);
const BS_IBHV		CIns_110_mulh::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 111
// Class :: mulh
/////////////////////////////////////////////////////////
const UI32			CIns_111_mulh::m_id = 111;
const std::string	CIns_111_mulh::m_mne("mulh");
const UI32			CIns_111_mulh::m_numop = 2;
const BS_IPRV		CIns_111_mulh::m_priviledge(0x0);
const BS_ICAT		CIns_111_mulh::m_category(0x0);
const BS_IBHV		CIns_111_mulh::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 112
// Class :: mulhi
/////////////////////////////////////////////////////////
const UI32			CIns_112_mulhi::m_id = 112;
const std::string	CIns_112_mulhi::m_mne("mulhi");
const UI32			CIns_112_mulhi::m_numop = 3;
const BS_IPRV		CIns_112_mulhi::m_priviledge(0x0);
const BS_ICAT		CIns_112_mulhi::m_category(0x0);
const BS_IBHV		CIns_112_mulhi::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 113
// Class :: mulu
/////////////////////////////////////////////////////////
const UI32			CIns_113_mulu::m_id = 113;
const std::string	CIns_113_mulu::m_mne("mulu");
const UI32			CIns_113_mulu::m_numop = 3;
const BS_IPRV		CIns_113_mulu::m_priviledge(0x0);
const BS_ICAT		CIns_113_mulu::m_category(0x0);
const BS_IBHV		CIns_113_mulu::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 114
// Class :: mulu
/////////////////////////////////////////////////////////
const UI32			CIns_114_mulu::m_id = 114;
const std::string	CIns_114_mulu::m_mne("mulu");
const UI32			CIns_114_mulu::m_numop = 3;
const BS_IPRV		CIns_114_mulu::m_priviledge(0x0);
const BS_ICAT		CIns_114_mulu::m_category(0x0);
const BS_IBHV		CIns_114_mulu::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 115
// Class :: nop
/////////////////////////////////////////////////////////
const UI32			CIns_115_nop::m_id = 115;
const std::string	CIns_115_nop::m_mne("nop");
const UI32			CIns_115_nop::m_numop = 0;
const BS_IPRV		CIns_115_nop::m_priviledge(0x0);
const BS_ICAT		CIns_115_nop::m_category(0x0);
const BS_IBHV		CIns_115_nop::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 116
// Class :: not
/////////////////////////////////////////////////////////
const UI32			CIns_116_not::m_id = 116;
const std::string	CIns_116_not::m_mne("not");
const UI32			CIns_116_not::m_numop = 2;
const BS_IPRV		CIns_116_not::m_priviledge(0x0);
const BS_ICAT		CIns_116_not::m_category(0x0);
const BS_IBHV		CIns_116_not::m_behavior(0x0);
const UI32          CIns_116_not::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 117
// Class :: not1
/////////////////////////////////////////////////////////
const UI32			CIns_117_not1::m_id = 117;
const std::string	CIns_117_not1::m_mne("not1");
const UI32			CIns_117_not1::m_numop = 2;
const BS_IPRV		CIns_117_not1::m_priviledge(0x0);
const BS_ICAT		CIns_117_not1::m_category(0x0);
const BS_IBHV		CIns_117_not1::m_behavior(0x3);
const UI32          CIns_117_not1::m_flag(INS_FLG_Z);

void CIns_117_not1::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	
	if (this->opr(1)->GetConstraint() != NULL) {
		IInstruction::Regulate(pReg);
	}
}


/////////////////////////////////////////////////////////
// InsID :: 118
// Class :: not1
/////////////////////////////////////////////////////////
const UI32			CIns_118_not1::m_id = 118;
const std::string	CIns_118_not1::m_mne("not1");
const UI32			CIns_118_not1::m_numop = 2;
const BS_IPRV		CIns_118_not1::m_priviledge(0x0);
const BS_ICAT		CIns_118_not1::m_category(0x0);
const BS_IBHV		CIns_118_not1::m_behavior(0x3);
const UI32          CIns_118_not1::m_flag(INS_FLG_Z);



/////////////////////////////////////////////////////////
// InsID :: 119
// Class :: or
/////////////////////////////////////////////////////////
const UI32			CIns_119_or::m_id = 119;
const std::string	CIns_119_or::m_mne("or");
const UI32			CIns_119_or::m_numop = 2;
const BS_IPRV		CIns_119_or::m_priviledge(0x0);
const BS_ICAT		CIns_119_or::m_category(0x0);
const BS_IBHV		CIns_119_or::m_behavior(0x0);
const UI32          CIns_119_or::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 120
// Class :: ori
/////////////////////////////////////////////////////////
const UI32			CIns_120_ori::m_id = 120;
const std::string	CIns_120_ori::m_mne("ori");
const UI32			CIns_120_ori::m_numop = 3;
const BS_IPRV		CIns_120_ori::m_priviledge(0x0);
const BS_ICAT		CIns_120_ori::m_category(0x0);
const BS_IBHV		CIns_120_ori::m_behavior(0x0);
const UI32          CIns_120_ori::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 121
// Class :: popsp
/////////////////////////////////////////////////////////
std::string CIns_121_popsp::GetCode() {
	return std::string("popsp " + opr(0)->GetCode()+ "-" + opr(1)->GetCode());
}

void CIns_121_popsp::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(1);
	IInstruction::Regulate(pReg);
}

REGFLG CIns_121_popsp::GetGrSrc() {
	
	return (1 << 3); // SP is rw

// rh > rtの時、（必要なさそうな気もするが）一生懸命補正している
// rh > rhであってもSPは参照されることにする（補正され書き換わる可能性がある、ループ命令内の処理に影響）
// アーキテクチャに照らせば以下が正しい
//
//	UI32	rh	= opr(0)->Idx();
//	UI32	rt	= opr(1)->Idx();
//	if (rh <= rt) {
//		return (1 << 3); // SP is rw
//	}
//	return 0;
}

REGFLG CIns_121_popsp::GetGrDst() {
	UI32	rh	= opr(0)->Idx();
	UI32	rt	= opr(1)->Idx();
	REGFLG	flg	= 0;
	
	if (rh <= rt) {
		for (UI32 r = rh; r <= rt; r++) {
			flg |= (1 << r);
		}
		flg |= (1<<3); // SP
	}
	return flg ;
}

const UI32			CIns_121_popsp::m_id = 121;
const std::string	CIns_121_popsp::m_mne("popsp");
const UI32			CIns_121_popsp::m_numop = 2;
const BS_IPRV		CIns_121_popsp::m_priviledge(0x0);
const BS_ICAT		CIns_121_popsp::m_category(0x0);
const BS_IBHV		CIns_121_popsp::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 122
// Class :: prepare
/////////////////////////////////////////////////////////
std::string CIns_122_prepare::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	ss << ' ' << "0x" << std::hex << lst12;
	ss << ',' << opr(1)->GetCode();
	
	return ss.str();
}

REGFLG CIns_122_prepare::GetGrSrc() {
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	lst12 = (lst12 << 20) | 0x00000008U; // SP is rw
	return lst12 ;
}

REGFLG CIns_122_prepare::GetGrDst() {
	return 0x00000008U; // SP is rw
}

const UI32			CIns_122_prepare::m_id = 122;
const std::string	CIns_122_prepare::m_mne("prepare");
const UI32			CIns_122_prepare::m_numop = 2;
const BS_IPRV		CIns_122_prepare::m_priviledge(0x0);
const BS_ICAT		CIns_122_prepare::m_category(0x0);
const BS_IBHV		CIns_122_prepare::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 123
// Class :: prepare
/////////////////////////////////////////////////////////
std::string CIns_123_prepare::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	ss << ' ' << "0x" << std::hex << lst12;
	ss << ',' << opr(1)->GetCode();
	ss << ',' << opr(2)->GetCode();
	
	return ss.str();
}

REGFLG CIns_123_prepare::GetGrSrc() {
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	lst12 = (lst12 << 20) | (1 << 3); // SP is rw
	return lst12 ;
}

REGFLG CIns_123_prepare::GetGrDst() {
	return (1 << 30) | (1 << 3); // SP is rw, EP is dst
}

const UI32			CIns_123_prepare::m_id = 123;
const std::string	CIns_123_prepare::m_mne("prepare");
const UI32			CIns_123_prepare::m_numop = 3;
const BS_IPRV		CIns_123_prepare::m_priviledge(0x0);
const BS_ICAT		CIns_123_prepare::m_category(0x0);
const BS_IBHV		CIns_123_prepare::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 124
// Class :: prepare
/////////////////////////////////////////////////////////
std::string CIns_124_prepare::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	
	SI16 val = (SI16)(UI32)*opr(2);
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	ss << ' ' << "0x" << std::hex << lst12;
	ss << ',' << opr(1)->GetCode();
	if (IsImmShift) {  // Support imm with shift.
		ss << "," << std::dec << val << " << 16";
	} else { // Support imm without shift.
		ss << ", lo(" << std::dec << val << ")";
	}

	return ss.str();
}

std::string CIns_124_prepare::GetCode() {
	std::stringstream ss;

	ss << std::setw(2) << std::left << std::setfill(' ') << GetMne();
	ss << ' ' << opr(0)->GetCode();
	ss << ',' << opr(1)->GetCode();
	if (IsImmShift) {  // Support imm with shift.
		ss << ',' << opr(2)->GetCode() << " << 16" ;
	} else { // Support imm without shift.
	   ss << ',' << opr(2)->GetCode();
	}
	return ss.str();
}

UI32 CIns_124_prepare::Assemble(UI64* n) {
	
	FROG_ASSERT( opr(0) && opr(1) && opr(2) );
	
	// get value
	UI32 list12	= *opr(0);
	UI32 imm5	= *opr(1);
	UI16 imm16	= *opr(2);
	
	// check
	// -- this instruction format has no constraint
	
	//coding
	if (IsImmShift) {  // Support imm with shift.
		//coding
		*n  = 0x0000000000030780;
		*n |= 0x0000000000100000; //ff
		*n |= (UI64)list12;
		*n |= ((UI64)imm5 << 1);
		*n |= ((UI64)imm16<<32);
	} else {  // Support imm without shift.
	   	*n  = 0x0000000000030780;
		*n |= 0x0000000000080000; //ff
		*n |= (UI64)list12;
		*n |= ((UI64)imm5 << 1);
		*n |= ((UI64)imm16<<32);
	}
		
	return 6;
}

REGFLG CIns_124_prepare::GetGrSrc() {
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	lst12 = (lst12 << 20) | (1 << 3); // SP is rw
	return lst12 ;
}

REGFLG CIns_124_prepare::GetGrDst() {
	return (1 << 30) | (1 << 3); // SP is rw, EP is dst
}

const UI32			CIns_124_prepare::m_id = 124;
const std::string	CIns_124_prepare::m_mne("prepare");
const UI32			CIns_124_prepare::m_numop = 3;
const BS_IPRV		CIns_124_prepare::m_priviledge(0x0);
const BS_ICAT		CIns_124_prepare::m_category(0x0);
const BS_IBHV		CIns_124_prepare::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 125
// Class :: prepare
/////////////////////////////////////////////////////////
std::string CIns_125_prepare::GetOutCode() {
	std::stringstream ss;
	ss << std::setw(16) << std::left << std::setfill(' ') << GetMne();
	
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	ss << ' ' << "0x" << std::hex << lst12;
	ss << ',' << opr(1)->GetCode();
	
	//UI32 val = (UI32)*opr(2);
	/*if ((val & 0xffff) == 0xffff) {
		opr(2)->Replace(~val);
	}
	if (val & 0xffff) {*/
	ss << ", hilo(" << opr(2)->GetCode() << ")";
	/*}else{
		ss << ", hi(" << opr(2)->GetCode() << ")";
	}*/

	return ss.str();
}

UI32 CIns_125_prepare::Assemble(UI64* n) {
	
	FROG_ASSERT( opr(0) && opr(1) && opr(2) );
	
	// get value
	UI32 list12	= *opr(0);
	UI32 imm5	= *opr(1);
	UI32 imm32	= *opr(2);
	bool bPinch = false;		// economy coding length 8->6
	
	// check
	if (((imm32 & 0xffff) == 0) && (opr(2)->Replace(imm32>>16))) {
		bPinch = true;
		imm32 = *opr(2);
	}
	
	//coding
	*n  = 0x0000000000030780;
	*n |= (bPinch ? (0x00100000) : (0x00180000)); // ff
	*n |= (UI64)list12;
	*n |= ((UI64)imm5 << 1);
	*n |= ((UI64)imm32<<32);
		
	return bPinch ? 6 : 8;
}

REGFLG CIns_125_prepare::GetGrSrc() {
	UI32 lst12 = List12BitOrder((UI32)*opr(0));
	lst12 = (lst12 << 20) | (1 << 3); // SP is rw
	return lst12 ;
}

REGFLG CIns_125_prepare::GetGrDst() {
	return (1 << 30) | (1 << 3); // SP is rw, EP is dst
}

const UI32			CIns_125_prepare::m_id = 125;
const std::string	CIns_125_prepare::m_mne("prepare");
const UI32			CIns_125_prepare::m_numop = 3;
const BS_IPRV		CIns_125_prepare::m_priviledge(0x0);
const BS_ICAT		CIns_125_prepare::m_category(0x0);
const BS_IBHV		CIns_125_prepare::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 126
// Class :: pushsp
/////////////////////////////////////////////////////////
std::string CIns_126_pushsp::GetCode() {
	return std::string("pushsp " + opr(0)->GetCode()+ "-" + opr(1)->GetCode());
}

void CIns_126_pushsp::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	if (this->opr(0)->GetConstraint() != NULL) {
		pReg->m_depends	= opr(1);
		IInstruction::Regulate(pReg);
	}	
}

REGFLG CIns_126_pushsp::GetGrSrc() {
	UI32	rh	= opr(0)->Idx();
	UI32	rt	= opr(1)->Idx();
	REGFLG	flg	= 0;
	
	if (rh <= rt) {
		for (UI32 r = rh; r <= rt; r++) {
			flg |= (1 << r);
		}
		flg |= (1<<3); // SP
	}
	
	// アーキテクチャに照らせば以下は不要
	// rh > rtの時、（必要なさそうな気もするが）一生懸命補正している
	// rh > rhであってもSPは参照されることにする（補正され書き換わる可能性がある、ループ命令内の処理に影響）
	flg |= (1<<3); // SP
	
	return flg ;
}

REGFLG CIns_126_pushsp::GetGrDst() {
	UI32	rh	= opr(0)->Idx();
	UI32	rt	= opr(1)->Idx();
	if (rh <= rt) {
		return (1 << 3); // SP is rw, EP is dst
	}
	return 0;
}

const UI32			CIns_126_pushsp::m_id = 126;
const std::string	CIns_126_pushsp::m_mne("pushsp");
const UI32			CIns_126_pushsp::m_numop = 2;
const BS_IPRV		CIns_126_pushsp::m_priviledge(0x0);
const BS_ICAT		CIns_126_pushsp::m_category(0x0);
const BS_IBHV		CIns_126_pushsp::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 127
// Class :: rie
/////////////////////////////////////////////////////////
const UI32			CIns_127_rie::m_id = 127;
const std::string	CIns_127_rie::m_mne("rie");
const UI32			CIns_127_rie::m_numop = 0;
const BS_IPRV		CIns_127_rie::m_priviledge(0x0);
const BS_ICAT		CIns_127_rie::m_category(0x0);
const BS_IBHV		CIns_127_rie::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 128
// Class :: rie
/////////////////////////////////////////////////////////
const UI32			CIns_128_rie::m_id = 128;
const std::string	CIns_128_rie::m_mne("rie");
const UI32			CIns_128_rie::m_numop = 2;
const BS_IPRV		CIns_128_rie::m_priviledge(0x0);
const BS_ICAT		CIns_128_rie::m_category(0x0);
const BS_IBHV		CIns_128_rie::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 129
// Class :: rotl
/////////////////////////////////////////////////////////
const UI32			CIns_129_rotl::m_id = 129;
const std::string	CIns_129_rotl::m_mne("rotl");
const UI32			CIns_129_rotl::m_numop = 3;
const BS_IPRV		CIns_129_rotl::m_priviledge(0x0);
const BS_ICAT		CIns_129_rotl::m_category(0x0);
const BS_IBHV		CIns_129_rotl::m_behavior(0x0);
const UI32          CIns_129_rotl::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 130
// Class :: rotl
/////////////////////////////////////////////////////////
const UI32			CIns_130_rotl::m_id = 130;
const std::string	CIns_130_rotl::m_mne("rotl");
const UI32			CIns_130_rotl::m_numop = 3;
const BS_IPRV		CIns_130_rotl::m_priviledge(0x0);
const BS_ICAT		CIns_130_rotl::m_category(0x0);
const BS_IBHV		CIns_130_rotl::m_behavior(0x0);
const UI32          CIns_130_rotl::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 131
// Class :: sar
/////////////////////////////////////////////////////////
const UI32			CIns_131_sar::m_id = 131;
const std::string	CIns_131_sar::m_mne("sar");
const UI32			CIns_131_sar::m_numop = 2;
const BS_IPRV		CIns_131_sar::m_priviledge(0x0);
const BS_ICAT		CIns_131_sar::m_category(0x0);
const BS_IBHV		CIns_131_sar::m_behavior(0x0);
const UI32          CIns_131_sar::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 132
// Class :: sar
/////////////////////////////////////////////////////////
const UI32			CIns_132_sar::m_id = 132;
const std::string	CIns_132_sar::m_mne("sar");
const UI32			CIns_132_sar::m_numop = 2;
const BS_IPRV		CIns_132_sar::m_priviledge(0x0);
const BS_ICAT		CIns_132_sar::m_category(0x0);
const BS_IBHV		CIns_132_sar::m_behavior(0x0);
const UI32          CIns_132_sar::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 133
// Class :: sar
/////////////////////////////////////////////////////////
const UI32			CIns_133_sar::m_id = 133;
const std::string	CIns_133_sar::m_mne("sar");
const UI32			CIns_133_sar::m_numop = 3;
const BS_IPRV		CIns_133_sar::m_priviledge(0x0);
const BS_ICAT		CIns_133_sar::m_category(0x0);
const BS_IBHV		CIns_133_sar::m_behavior(0x0);
const UI32          CIns_133_sar::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 134
// Class :: sasf
/////////////////////////////////////////////////////////
std::string CIns_134_sasf::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << val;
	ss << ", " << opr(1)->GetCode();
	return ss.str();
}

const UI32			CIns_134_sasf::m_id = 134;
const std::string	CIns_134_sasf::m_mne("sasf");
const UI32			CIns_134_sasf::m_numop = 2;
const BS_IPRV		CIns_134_sasf::m_priviledge(0x0);
const BS_ICAT		CIns_134_sasf::m_category(0x0);
const BS_IBHV		CIns_134_sasf::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 135
// Class :: satadd
/////////////////////////////////////////////////////////
const UI32			CIns_135_satadd::m_id = 135;
const std::string	CIns_135_satadd::m_mne("satadd");
const UI32			CIns_135_satadd::m_numop = 2;
const BS_IPRV		CIns_135_satadd::m_priviledge(0x0);
const BS_ICAT		CIns_135_satadd::m_category(0x0);
const BS_IBHV		CIns_135_satadd::m_behavior(0x0);
const UI32          CIns_135_satadd::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 136
// Class :: satadd
/////////////////////////////////////////////////////////
const UI32			CIns_136_satadd::m_id = 136;
const std::string	CIns_136_satadd::m_mne("satadd");
const UI32			CIns_136_satadd::m_numop = 2;
const BS_IPRV		CIns_136_satadd::m_priviledge(0x0);
const BS_ICAT		CIns_136_satadd::m_category(0x0);
const BS_IBHV		CIns_136_satadd::m_behavior(0x0);
const UI32          CIns_136_satadd::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 137
// Class :: satadd
/////////////////////////////////////////////////////////
const UI32			CIns_137_satadd::m_id = 137;
const std::string	CIns_137_satadd::m_mne("satadd");
const UI32			CIns_137_satadd::m_numop = 3;
const BS_IPRV		CIns_137_satadd::m_priviledge(0x0);
const BS_ICAT		CIns_137_satadd::m_category(0x0);
const BS_IBHV		CIns_137_satadd::m_behavior(0x0);
const UI32          CIns_137_satadd::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 138
// Class :: satsub
/////////////////////////////////////////////////////////
const UI32			CIns_138_satsub::m_id = 138;
const std::string	CIns_138_satsub::m_mne("satsub");
const UI32			CIns_138_satsub::m_numop = 2;
const BS_IPRV		CIns_138_satsub::m_priviledge(0x0);
const BS_ICAT		CIns_138_satsub::m_category(0x0);
const BS_IBHV		CIns_138_satsub::m_behavior(0x0);
const UI32          CIns_138_satsub::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 139
// Class :: satsub
/////////////////////////////////////////////////////////
const UI32			CIns_139_satsub::m_id = 139;
const std::string	CIns_139_satsub::m_mne("satsub");
const UI32			CIns_139_satsub::m_numop = 3;
const BS_IPRV		CIns_139_satsub::m_priviledge(0x0);
const BS_ICAT		CIns_139_satsub::m_category(0x0);
const BS_IBHV		CIns_139_satsub::m_behavior(0x0);
const UI32          CIns_139_satsub::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 140
// Class :: satsubi
/////////////////////////////////////////////////////////
const UI32			CIns_140_satsubi::m_id = 140;
const std::string	CIns_140_satsubi::m_mne("satsubi");
const UI32			CIns_140_satsubi::m_numop = 3;
const BS_IPRV		CIns_140_satsubi::m_priviledge(0x0);
const BS_ICAT		CIns_140_satsubi::m_category(0x0);
const BS_IBHV		CIns_140_satsubi::m_behavior(0x0);
const UI32          CIns_140_satsubi::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 141
// Class :: satsubr
/////////////////////////////////////////////////////////
const UI32			CIns_141_satsubr::m_id = 141;
const std::string	CIns_141_satsubr::m_mne("satsubr");
const UI32			CIns_141_satsubr::m_numop = 2;
const BS_IPRV		CIns_141_satsubr::m_priviledge(0x0);
const BS_ICAT		CIns_141_satsubr::m_category(0x0);
const BS_IBHV		CIns_141_satsubr::m_behavior(0x0);
const UI32          CIns_141_satsubr::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY|INS_FLG_SAT);



/////////////////////////////////////////////////////////
// InsID :: 142
// Class :: sbf
/////////////////////////////////////////////////////////
std::string CIns_142_sbf::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << val;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	ss << ", " << opr(3)->GetCode();
	return ss.str();
}

const UI32			CIns_142_sbf::m_id = 142;
const std::string	CIns_142_sbf::m_mne("sbf");
const UI32			CIns_142_sbf::m_numop = 4;
const BS_IPRV		CIns_142_sbf::m_priviledge(0x0);
const BS_ICAT		CIns_142_sbf::m_category(0x0);
const BS_IBHV		CIns_142_sbf::m_behavior(0x0);
const UI32          CIns_142_sbf::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 143
// Class :: sch0l
/////////////////////////////////////////////////////////
const UI32			CIns_143_sch0l::m_id = 143;
const std::string	CIns_143_sch0l::m_mne("sch0l");
const UI32			CIns_143_sch0l::m_numop = 2;
const BS_IPRV		CIns_143_sch0l::m_priviledge(0x0);
const BS_ICAT		CIns_143_sch0l::m_category(0x0);
const BS_IBHV		CIns_143_sch0l::m_behavior(0x0);
const UI32          CIns_143_sch0l::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 144
// Class :: sch0r
/////////////////////////////////////////////////////////
const UI32			CIns_144_sch0r::m_id = 144;
const std::string	CIns_144_sch0r::m_mne("sch0r");
const UI32			CIns_144_sch0r::m_numop = 2;
const BS_IPRV		CIns_144_sch0r::m_priviledge(0x0);
const BS_ICAT		CIns_144_sch0r::m_category(0x0);
const BS_IBHV		CIns_144_sch0r::m_behavior(0x0);
const UI32          CIns_144_sch0r::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 145
// Class :: sch1l
/////////////////////////////////////////////////////////
const UI32			CIns_145_sch1l::m_id = 145;
const std::string	CIns_145_sch1l::m_mne("sch1l");
const UI32			CIns_145_sch1l::m_numop = 2;
const BS_IPRV		CIns_145_sch1l::m_priviledge(0x0);
const BS_ICAT		CIns_145_sch1l::m_category(0x0);
const BS_IBHV		CIns_145_sch1l::m_behavior(0x0);
const UI32          CIns_145_sch1l::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 146
// Class :: sch1r
/////////////////////////////////////////////////////////
const UI32			CIns_146_sch1r::m_id = 146;
const std::string	CIns_146_sch1r::m_mne("sch1r");
const UI32			CIns_146_sch1r::m_numop = 2;
const BS_IPRV		CIns_146_sch1r::m_priviledge(0x0);
const BS_ICAT		CIns_146_sch1r::m_category(0x0);
const BS_IBHV		CIns_146_sch1r::m_behavior(0x0);
const UI32          CIns_146_sch1r::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 147
// Class :: set1
/////////////////////////////////////////////////////////
const UI32			CIns_147_set1::m_id = 147;
const std::string	CIns_147_set1::m_mne("set1");
const UI32			CIns_147_set1::m_numop = 2;
const BS_IPRV		CIns_147_set1::m_priviledge(0x0);
const BS_ICAT		CIns_147_set1::m_category(0x0);
const BS_IBHV		CIns_147_set1::m_behavior(0x3);
const UI32          CIns_147_set1::m_flag(INS_FLG_Z);

void CIns_147_set1::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	
	if (this->opr(1)->GetConstraint() != NULL) {
		IInstruction::Regulate(pReg);
	}
}

/////////////////////////////////////////////////////////
// InsID :: 148
// Class :: set1
/////////////////////////////////////////////////////////
const UI32			CIns_148_set1::m_id = 148;
const std::string	CIns_148_set1::m_mne("set1");
const UI32			CIns_148_set1::m_numop = 2;
const BS_IPRV		CIns_148_set1::m_priviledge(0x0);
const BS_ICAT		CIns_148_set1::m_category(0x0);
const BS_IBHV		CIns_148_set1::m_behavior(0x3);
const UI32          CIns_148_set1::m_flag(INS_FLG_Z);



/////////////////////////////////////////////////////////
// InsID :: 149
// Class :: setf
/////////////////////////////////////////////////////////
std::string CIns_149_setf::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << val;
	ss << ", " << opr(1)->GetCode();
	return ss.str();
}

const UI32			CIns_149_setf::m_id = 149;
const std::string	CIns_149_setf::m_mne("setf");
const UI32			CIns_149_setf::m_numop = 2;
const BS_IPRV		CIns_149_setf::m_priviledge(0x0);
const BS_ICAT		CIns_149_setf::m_category(0x0);
const BS_IBHV		CIns_149_setf::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 150
// Class :: shl
/////////////////////////////////////////////////////////
const UI32			CIns_150_shl::m_id = 150;
const std::string	CIns_150_shl::m_mne("shl");
const UI32			CIns_150_shl::m_numop = 2;
const BS_IPRV		CIns_150_shl::m_priviledge(0x0);
const BS_ICAT		CIns_150_shl::m_category(0x0);
const BS_IBHV		CIns_150_shl::m_behavior(0x0);
const UI32          CIns_150_shl::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 151
// Class :: shl
/////////////////////////////////////////////////////////
const UI32			CIns_151_shl::m_id = 151;
const std::string	CIns_151_shl::m_mne("shl");
const UI32			CIns_151_shl::m_numop = 2;
const BS_IPRV		CIns_151_shl::m_priviledge(0x0);
const BS_ICAT		CIns_151_shl::m_category(0x0);
const BS_IBHV		CIns_151_shl::m_behavior(0x0);
const UI32          CIns_151_shl::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 152
// Class :: shl
/////////////////////////////////////////////////////////
const UI32			CIns_152_shl::m_id = 152;
const std::string	CIns_152_shl::m_mne("shl");
const UI32			CIns_152_shl::m_numop = 3;
const BS_IPRV		CIns_152_shl::m_priviledge(0x0);
const BS_ICAT		CIns_152_shl::m_category(0x0);
const BS_IBHV		CIns_152_shl::m_behavior(0x0);
const UI32          CIns_152_shl::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 153
// Class :: shr
/////////////////////////////////////////////////////////
const UI32			CIns_153_shr::m_id = 153;
const std::string	CIns_153_shr::m_mne("shr");
const UI32			CIns_153_shr::m_numop = 2;
const BS_IPRV		CIns_153_shr::m_priviledge(0x0);
const BS_ICAT		CIns_153_shr::m_category(0x0);
const BS_IBHV		CIns_153_shr::m_behavior(0x0);
const UI32          CIns_153_shr::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 154
// Class :: shr
/////////////////////////////////////////////////////////
const UI32			CIns_154_shr::m_id = 154;
const std::string	CIns_154_shr::m_mne("shr");
const UI32			CIns_154_shr::m_numop = 2;
const BS_IPRV		CIns_154_shr::m_priviledge(0x0);
const BS_ICAT		CIns_154_shr::m_category(0x0);
const BS_IBHV		CIns_154_shr::m_behavior(0x0);
const UI32          CIns_154_shr::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 155
// Class :: shr
/////////////////////////////////////////////////////////
const UI32			CIns_155_shr::m_id = 155;
const std::string	CIns_155_shr::m_mne("shr");
const UI32			CIns_155_shr::m_numop = 3;
const BS_IPRV		CIns_155_shr::m_priviledge(0x0);
const BS_ICAT		CIns_155_shr::m_category(0x0);
const BS_IBHV		CIns_155_shr::m_behavior(0x0);
const UI32          CIns_155_shr::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 156
// Class :: sld.b
/////////////////////////////////////////////////////////
const UI32			CIns_156_sld_b::m_id = 156;
const std::string	CIns_156_sld_b::m_mne("sld.b");
const UI32			CIns_156_sld_b::m_numop = 2;
const BS_IPRV		CIns_156_sld_b::m_priviledge(0x0);
const BS_ICAT		CIns_156_sld_b::m_category(0x0);
const BS_IBHV		CIns_156_sld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 157
// Class :: sld.bu
/////////////////////////////////////////////////////////
const UI32			CIns_157_sld_bu::m_id = 157;
const std::string	CIns_157_sld_bu::m_mne("sld.bu");
const UI32			CIns_157_sld_bu::m_numop = 2;
const BS_IPRV		CIns_157_sld_bu::m_priviledge(0x0);
const BS_ICAT		CIns_157_sld_bu::m_category(0x0);
const BS_IBHV		CIns_157_sld_bu::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 158
// Class :: sld.h
/////////////////////////////////////////////////////////
const UI32			CIns_158_sld_h::m_id = 158;
const std::string	CIns_158_sld_h::m_mne("sld.h");
const UI32			CIns_158_sld_h::m_numop = 2;
const BS_IPRV		CIns_158_sld_h::m_priviledge(0x0);
const BS_ICAT		CIns_158_sld_h::m_category(0x0);
const BS_IBHV		CIns_158_sld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 159
// Class :: sld.hu
/////////////////////////////////////////////////////////
const UI32			CIns_159_sld_hu::m_id = 159;
const std::string	CIns_159_sld_hu::m_mne("sld.hu");
const UI32			CIns_159_sld_hu::m_numop = 2;
const BS_IPRV		CIns_159_sld_hu::m_priviledge(0x0);
const BS_ICAT		CIns_159_sld_hu::m_category(0x0);
const BS_IBHV		CIns_159_sld_hu::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 160
// Class :: sld.w
/////////////////////////////////////////////////////////
const UI32			CIns_160_sld_w::m_id = 160;
const std::string	CIns_160_sld_w::m_mne("sld.w");
const UI32			CIns_160_sld_w::m_numop = 2;
const BS_IPRV		CIns_160_sld_w::m_priviledge(0x0);
const BS_ICAT		CIns_160_sld_w::m_category(0x0);
const BS_IBHV		CIns_160_sld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 161
// Class :: snooze
/////////////////////////////////////////////////////////
const UI32			CIns_161_snooze::m_id = 161;
const std::string	CIns_161_snooze::m_mne("snooze");
const UI32			CIns_161_snooze::m_numop = 0;
const BS_IPRV		CIns_161_snooze::m_priviledge(0x0);
const BS_ICAT		CIns_161_snooze::m_category(0x0);
const BS_IBHV		CIns_161_snooze::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 162
// Class :: sst.b
/////////////////////////////////////////////////////////
const UI32			CIns_162_sst_b::m_id = 162;
const std::string	CIns_162_sst_b::m_mne("sst.b");
const UI32			CIns_162_sst_b::m_numop = 2;
const BS_IPRV		CIns_162_sst_b::m_priviledge(0x0);
const BS_ICAT		CIns_162_sst_b::m_category(0x0);
const BS_IBHV		CIns_162_sst_b::m_behavior(0x2);


void CIns_162_sst_b::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	
	if (this->opr(1)->GetConstraint() != NULL) {
		IInstruction::Regulate(pReg);
	}
}



/////////////////////////////////////////////////////////
// InsID :: 163
// Class :: sst.h
/////////////////////////////////////////////////////////
const UI32			CIns_163_sst_h::m_id = 163;
const std::string	CIns_163_sst_h::m_mne("sst.h");
const UI32			CIns_163_sst_h::m_numop = 2;
const BS_IPRV		CIns_163_sst_h::m_priviledge(0x0);
const BS_ICAT		CIns_163_sst_h::m_category(0x0);
const BS_IBHV		CIns_163_sst_h::m_behavior(0x2);

void CIns_163_sst_h::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	
	if (this->opr(1)->GetConstraint() != NULL) {
		IInstruction::Regulate(pReg);
	}
}


/////////////////////////////////////////////////////////
// InsID :: 164
// Class :: sst.w
/////////////////////////////////////////////////////////
const UI32			CIns_164_sst_w::m_id = 164;
const std::string	CIns_164_sst_w::m_mne("sst.w");
const UI32			CIns_164_sst_w::m_numop = 2;
const BS_IPRV		CIns_164_sst_w::m_priviledge(0x0);
const BS_ICAT		CIns_164_sst_w::m_category(0x0);
const BS_IBHV		CIns_164_sst_w::m_behavior(0x2);

void CIns_164_sst_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	
	if (this->opr(1)->GetConstraint() != NULL) {
		IInstruction::Regulate(pReg);
	}
}


/////////////////////////////////////////////////////////
// InsID :: 165
// Class :: st.b
/////////////////////////////////////////////////////////
const UI32			CIns_165_st_b::m_id = 165;
const std::string	CIns_165_st_b::m_mne("st.b");
const UI32			CIns_165_st_b::m_numop = 2;
const BS_IPRV		CIns_165_st_b::m_priviledge(0x0);
const BS_ICAT		CIns_165_st_b::m_category(0x0);
const BS_IBHV		CIns_165_st_b::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 166
// Class :: st.b
/////////////////////////////////////////////////////////
const UI32			CIns_166_st_b::m_id = 166;
const std::string	CIns_166_st_b::m_mne("st.b");
const UI32			CIns_166_st_b::m_numop = 2;
const BS_IPRV		CIns_166_st_b::m_priviledge(0x0);
const BS_ICAT		CIns_166_st_b::m_category(0x0);
const BS_IBHV		CIns_166_st_b::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 167
// Class :: st.dw
/////////////////////////////////////////////////////////
const UI32			CIns_167_st_dw::m_id = 167;
const std::string	CIns_167_st_dw::m_mne("st.dw");
const UI32			CIns_167_st_dw::m_numop = 2;
const BS_IPRV		CIns_167_st_dw::m_priviledge(0x0);
const BS_ICAT		CIns_167_st_dw::m_category(0x0);
const BS_IBHV		CIns_167_st_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 168
// Class :: st.h
/////////////////////////////////////////////////////////
const UI32			CIns_168_st_h::m_id = 168;
const std::string	CIns_168_st_h::m_mne("st.h");
const UI32			CIns_168_st_h::m_numop = 2;
const BS_IPRV		CIns_168_st_h::m_priviledge(0x0);
const BS_ICAT		CIns_168_st_h::m_category(0x0);
const BS_IBHV		CIns_168_st_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 169
// Class :: st.h
/////////////////////////////////////////////////////////
const UI32			CIns_169_st_h::m_id = 169;
const std::string	CIns_169_st_h::m_mne("st.h");
const UI32			CIns_169_st_h::m_numop = 2;
const BS_IPRV		CIns_169_st_h::m_priviledge(0x0);
const BS_ICAT		CIns_169_st_h::m_category(0x0);
const BS_IBHV		CIns_169_st_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 170
// Class :: st.w
/////////////////////////////////////////////////////////
const UI32			CIns_170_st_w::m_id = 170;
const std::string	CIns_170_st_w::m_mne("st.w");
const UI32			CIns_170_st_w::m_numop = 2;
const BS_IPRV		CIns_170_st_w::m_priviledge(0x0);
const BS_ICAT		CIns_170_st_w::m_category(0x0);
const BS_IBHV		CIns_170_st_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 171
// Class :: st.w
/////////////////////////////////////////////////////////
const UI32			CIns_171_st_w::m_id = 171;
const std::string	CIns_171_st_w::m_mne("st.w");
const UI32			CIns_171_st_w::m_numop = 2;
const BS_IPRV		CIns_171_st_w::m_priviledge(0x0);
const BS_ICAT		CIns_171_st_w::m_category(0x0);
const BS_IBHV		CIns_171_st_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 172
// Class :: stc.w
/////////////////////////////////////////////////////////
const UI32			CIns_172_stc_w::m_id = 172;
const std::string	CIns_172_stc_w::m_mne("stc.w");
const UI32			CIns_172_stc_w::m_numop = 2;
const BS_IPRV		CIns_172_stc_w::m_priviledge(0x0);
const BS_ICAT		CIns_172_stc_w::m_category(0x0);
const BS_IBHV		CIns_172_stc_w::m_behavior(0x2);

void CIns_172_stc_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	IOperand* popr = opr(0);
	FROG_ASSERT(popr);
	popr->Regulate(pReg);

	IOperand* poprAddr = opr(1);
	FROG_ASSERT(poprAddr);
	UI32 lnk = 1;
	poprAddr->Regulate(pReg, lnk);

}


/////////////////////////////////////////////////////////
// InsID :: 173
// Class :: stsr
/////////////////////////////////////////////////////////
std::string CIns_173_stsr::GetCode() {
	UI32 sr = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << "stsr " << "sr" << (sr & 0x1f) ;
	ss << ", " << opr(1)->GetCode();
	ss << ", sel" << (sr >> 5);
	
	return ss.str();
}

std::string CIns_173_stsr::GetOutCode() {
	UI32 sr = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << "stsr " <<  (sr & 0x1f) ;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << (sr >> 5);
	
	return ss.str();
}

const UI32			CIns_173_stsr::m_id = 173;
const std::string	CIns_173_stsr::m_mne("stsr");
const UI32			CIns_173_stsr::m_numop = 2;
const BS_IPRV		CIns_173_stsr::m_priviledge(0x0);
const BS_ICAT		CIns_173_stsr::m_category(0x0);
const BS_IBHV		CIns_173_stsr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 174
// Class :: sub
/////////////////////////////////////////////////////////
const UI32			CIns_174_sub::m_id = 174;
const std::string	CIns_174_sub::m_mne("sub");
const UI32			CIns_174_sub::m_numop = 2;
const BS_IPRV		CIns_174_sub::m_priviledge(0x0);
const BS_ICAT		CIns_174_sub::m_category(0x0);
const BS_IBHV		CIns_174_sub::m_behavior(0x0);
const UI32          CIns_174_sub::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 175
// Class :: subr
/////////////////////////////////////////////////////////
const UI32			CIns_175_subr::m_id = 175;
const std::string	CIns_175_subr::m_mne("subr");
const UI32			CIns_175_subr::m_numop = 2;
const BS_IPRV		CIns_175_subr::m_priviledge(0x0);
const BS_ICAT		CIns_175_subr::m_category(0x0);
const BS_IBHV		CIns_175_subr::m_behavior(0x0);
const UI32          CIns_175_subr::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV|INS_FLG_CY);



/////////////////////////////////////////////////////////
// InsID :: 176
// Class :: switch
/////////////////////////////////////////////////////////

void CIns_176_switch::Regulate(IRegulation* pReg) {
    IInstruction::Regulate(pReg);

    if (pReg->Pass()) {
        UI32 RegVal = 0, reg = this->opr(0)->Idx();
        UI32 PC = 0;
        pReg->m_pSim->ReadPC(&PC);
        pReg->m_pSim->ReadGrReg(&RegVal, reg, pReg->m_ht);

        if (g_sim->IsMDPexception(PC + 2 + RegVal * 2, 2, true, false) != NO_ERROR) {
            this->SetException(0x91, 0x90);
        }
    }
}
const UI32			CIns_176_switch::m_id = 176;
const std::string	CIns_176_switch::m_mne("switch");
const UI32			CIns_176_switch::m_numop = 1;
const BS_IPRV		CIns_176_switch::m_priviledge(0x0);
const BS_ICAT		CIns_176_switch::m_category(0x0);
const BS_IBHV		CIns_176_switch::m_behavior(0x401);



/////////////////////////////////////////////////////////
// InsID :: 177
// Class :: sxb
/////////////////////////////////////////////////////////
const UI32			CIns_177_sxb::m_id = 177;
const std::string	CIns_177_sxb::m_mne("sxb");
const UI32			CIns_177_sxb::m_numop = 1;
const BS_IPRV		CIns_177_sxb::m_priviledge(0x0);
const BS_ICAT		CIns_177_sxb::m_category(0x0);
const BS_IBHV		CIns_177_sxb::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 178
// Class :: sxh
/////////////////////////////////////////////////////////
const UI32			CIns_178_sxh::m_id = 178;
const std::string	CIns_178_sxh::m_mne("sxh");
const UI32			CIns_178_sxh::m_numop = 1;
const BS_IPRV		CIns_178_sxh::m_priviledge(0x0);
const BS_ICAT		CIns_178_sxh::m_category(0x0);
const BS_IBHV		CIns_178_sxh::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 179
// Class :: synce
/////////////////////////////////////////////////////////
const UI32			CIns_179_synce::m_id = 179;
const std::string	CIns_179_synce::m_mne("synce");
const UI32			CIns_179_synce::m_numop = 0;
const BS_IPRV		CIns_179_synce::m_priviledge(0x0);
const BS_ICAT		CIns_179_synce::m_category(0x0);
const BS_IBHV		CIns_179_synce::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 180
// Class :: synci
/////////////////////////////////////////////////////////
const UI32			CIns_180_synci::m_id = 180;
const std::string	CIns_180_synci::m_mne("synci");
const UI32			CIns_180_synci::m_numop = 0;
const BS_IPRV		CIns_180_synci::m_priviledge(0x0);
const BS_ICAT		CIns_180_synci::m_category(0x0);
const BS_IBHV		CIns_180_synci::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 181
// Class :: syncm
/////////////////////////////////////////////////////////
const UI32			CIns_181_syncm::m_id = 181;
const std::string	CIns_181_syncm::m_mne("syncm");
const UI32			CIns_181_syncm::m_numop = 0;
const BS_IPRV		CIns_181_syncm::m_priviledge(0x0);
const BS_ICAT		CIns_181_syncm::m_category(0x0);
const BS_IBHV		CIns_181_syncm::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 182
// Class :: syncp
/////////////////////////////////////////////////////////
const UI32			CIns_182_syncp::m_id = 182;
const std::string	CIns_182_syncp::m_mne("syncp");
const UI32			CIns_182_syncp::m_numop = 0;
const BS_IPRV		CIns_182_syncp::m_priviledge(0x0);
const BS_ICAT		CIns_182_syncp::m_category(0x0);
const BS_IBHV		CIns_182_syncp::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 183
// Class :: syscall
/////////////////////////////////////////////////////////

void CIns_183_syscall::Regulate(IRegulation* pReg) {
    IInstruction::Regulate(pReg);

    if (pReg->Pass()) {
        UI32 entry = (UI32)*(opr(0));
        UI32 SCCFG = 0, SCBP = 0;

        pReg->m_pSim->ReadSysRegister(&SCCFG, "SCCFG", pReg->m_ht);
        pReg->m_pSim->ReadSysRegister(&SCBP, "SCBP", pReg->m_ht);

        if (SCCFG < entry) entry = 0;
        // if entry was accessed, do not allow accessing again
        if (g_sim->IsMDPexception(SCBP + entry * 4, 4, true, false) != NO_ERROR) {
            this->SetException(0x91, 0x90);
        }
    }
}


const UI32			CIns_183_syscall::m_id = 183;
const std::string	CIns_183_syscall::m_mne("syscall");
const UI32			CIns_183_syscall::m_numop = 1;
const BS_IPRV		CIns_183_syscall::m_priviledge(0x0);
const BS_ICAT		CIns_183_syscall::m_category(0x0);
const BS_IBHV		CIns_183_syscall::m_behavior(0xc01);



/////////////////////////////////////////////////////////
// InsID :: 184
// Class :: trap
/////////////////////////////////////////////////////////
const UI32			CIns_184_trap::m_id = 184;
const std::string	CIns_184_trap::m_mne("trap");
const UI32			CIns_184_trap::m_numop = 1;
const BS_IPRV		CIns_184_trap::m_priviledge(0x0);
const BS_ICAT		CIns_184_trap::m_category(0x0);
const BS_IBHV		CIns_184_trap::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 185
// Class :: tst
/////////////////////////////////////////////////////////
const UI32			CIns_185_tst::m_id = 185;
const std::string	CIns_185_tst::m_mne("tst");
const UI32			CIns_185_tst::m_numop = 2;
const BS_IPRV		CIns_185_tst::m_priviledge(0x0);
const BS_ICAT		CIns_185_tst::m_category(0x0);
const BS_IBHV		CIns_185_tst::m_behavior(0x0);
const UI32          CIns_185_tst::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 186
// Class :: tst1
/////////////////////////////////////////////////////////
const UI32			CIns_186_tst1::m_id = 186;
const std::string	CIns_186_tst1::m_mne("tst1");
const UI32			CIns_186_tst1::m_numop = 2;
const BS_IPRV		CIns_186_tst1::m_priviledge(0x0);
const BS_ICAT		CIns_186_tst1::m_category(0x0);
const BS_IBHV		CIns_186_tst1::m_behavior(0x1); // Load only
const UI32          CIns_186_tst1::m_flag(INS_FLG_Z);



/////////////////////////////////////////////////////////
// InsID :: 187
// Class :: tst1
/////////////////////////////////////////////////////////
const UI32			CIns_187_tst1::m_id = 187;
const std::string	CIns_187_tst1::m_mne("tst1");
const UI32			CIns_187_tst1::m_numop = 2;
const BS_IPRV		CIns_187_tst1::m_priviledge(0x0);
const BS_ICAT		CIns_187_tst1::m_category(0x0);
const BS_IBHV		CIns_187_tst1::m_behavior(0x1); // Load only
const UI32          CIns_187_tst1::m_flag(INS_FLG_Z);



/////////////////////////////////////////////////////////
// InsID :: 188
// Class :: xor
/////////////////////////////////////////////////////////
const UI32			CIns_188_xor::m_id = 188;
const std::string	CIns_188_xor::m_mne("xor");
const UI32			CIns_188_xor::m_numop = 2;
const BS_IPRV		CIns_188_xor::m_priviledge(0x0);
const BS_ICAT		CIns_188_xor::m_category(0x0);
const BS_IBHV		CIns_188_xor::m_behavior(0x0);
const UI32          CIns_188_xor::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 189
// Class :: xori
/////////////////////////////////////////////////////////
const UI32			CIns_189_xori::m_id = 189;
const std::string	CIns_189_xori::m_mne("xori");
const UI32			CIns_189_xori::m_numop = 3;
const BS_IPRV		CIns_189_xori::m_priviledge(0x0);
const BS_ICAT		CIns_189_xori::m_category(0x0);
const BS_IBHV		CIns_189_xori::m_behavior(0x0);
const UI32          CIns_189_xori::m_flag(INS_FLG_Z|INS_FLG_S|INS_FLG_OV);



/////////////////////////////////////////////////////////
// InsID :: 190
// Class :: zxb
/////////////////////////////////////////////////////////
const UI32			CIns_190_zxb::m_id = 190;
const std::string	CIns_190_zxb::m_mne("zxb");
const UI32			CIns_190_zxb::m_numop = 1;
const BS_IPRV		CIns_190_zxb::m_priviledge(0x0);
const BS_ICAT		CIns_190_zxb::m_category(0x0);
const BS_IBHV		CIns_190_zxb::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 191
// Class :: zxh
/////////////////////////////////////////////////////////
const UI32			CIns_191_zxh::m_id = 191;
const std::string	CIns_191_zxh::m_mne("zxh");
const UI32			CIns_191_zxh::m_numop = 1;
const BS_IPRV		CIns_191_zxh::m_priviledge(0x0);
const BS_ICAT		CIns_191_zxh::m_category(0x0);
const BS_IBHV		CIns_191_zxh::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 192
// Class :: hvcall
/////////////////////////////////////////////////////////
const UI32			CIns_192_hvcall::m_id = 192;
const std::string	CIns_192_hvcall::m_mne("hvcall");
const UI32			CIns_192_hvcall::m_numop = 1;
const BS_IPRV		CIns_192_hvcall::m_priviledge(0x8);
const BS_ICAT		CIns_192_hvcall::m_category(0x0);
const BS_IBHV		CIns_192_hvcall::m_behavior(0xc01);



/////////////////////////////////////////////////////////
// InsID :: 193
// Class :: hvtrap
/////////////////////////////////////////////////////////
const UI32			CIns_193_hvtrap::m_id = 193;
const std::string	CIns_193_hvtrap::m_mne("hvtrap");
const UI32			CIns_193_hvtrap::m_numop = 1;
const BS_IPRV		CIns_193_hvtrap::m_priviledge(0x8);
const BS_ICAT		CIns_193_hvtrap::m_category(0x0);
const BS_IBHV		CIns_193_hvtrap::m_behavior(0xc00);

void CIns_193_hvtrap::Regulate(IRegulation* pReg){
	UI32 vec5 = (UI32) *(this->opr(0));
	UI32 pswh = 0, curgpid = 0;
	pReg->m_pSim->ReadSysRegister(&pswh, "PSWH", pReg->m_ht);
	curgpid = (pswh & 0x700) >> 8;
	//Case cause code is same with current virtual machine
	//Next VM is already terminated
	if(g_mgr->GetWeightSet()->GetWeight(INS_CID_CHANGE_VMACHINE) > 0 && (vec5 < 0x8)
		&& (curgpid == vec5 || g_sim->IsTerminatedVM(vec5) == true)){
		pReg->GiveUp();
	}
}

/////////////////////////////////////////////////////////
// InsID :: 194
// Class :: ldvc.sr
/////////////////////////////////////////////////////////
std::string CIns_194_ldvc_sr::GetCode() {
	UI32 sr = (UI32)*opr(1);
	std::stringstream ss;
	
	ss << "ldvc.sr " << opr(0)->GetCode();
	ss << ", sr" << (sr & 0x1f);
	ss << ", sel" << (sr >> 5);
	
	return ss.str();
}

std::string CIns_194_ldvc_sr::GetOutCode() {
	UI32 sr = (UI32)*opr(1);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << "ldvc.sr " << opr(0)->GetCode();
	ss << ", " << (sr & 0x1f);
	ss << ", " << (sr >> 5);
	
	return ss.str();
}

const UI32			CIns_194_ldvc_sr::m_id = 194;
const std::string	CIns_194_ldvc_sr::m_mne("ldvc.sr");
const UI32			CIns_194_ldvc_sr::m_numop = 2;
const BS_IPRV		CIns_194_ldvc_sr::m_priviledge(0x10);
const BS_ICAT		CIns_194_ldvc_sr::m_category(0x0);
const BS_IBHV		CIns_194_ldvc_sr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 195
// Class :: stvc.sr
/////////////////////////////////////////////////////////
std::string CIns_195_stvc_sr::GetCode() {
	UI32 sr = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << "stvc.sr " << "sr" << (sr & 0x1f) ;
	ss << ", " << opr(1)->GetCode();
	ss << ", sel" << (sr >> 5);
	
	return ss.str();
}

std::string CIns_195_stvc_sr::GetOutCode() {
	UI32 sr = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << "stvc.sr " << (sr & 0x1f) ;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << (sr >> 5);
	
	return ss.str();
}

const UI32			CIns_195_stvc_sr::m_id = 195;
const std::string	CIns_195_stvc_sr::m_mne("stvc.sr");
const UI32			CIns_195_stvc_sr::m_numop = 2;
const BS_IPRV		CIns_195_stvc_sr::m_priviledge(0x10);
const BS_ICAT		CIns_195_stvc_sr::m_category(0x0);
const BS_IBHV		CIns_195_stvc_sr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 196
// Class :: dst
/////////////////////////////////////////////////////////
const UI32			CIns_196_dst::m_id = 196;
const std::string	CIns_196_dst::m_mne("dst");
const UI32			CIns_196_dst::m_numop = 0;
const BS_IPRV		CIns_196_dst::m_priviledge(0x8);
const BS_ICAT		CIns_196_dst::m_category(0x0);
const BS_IBHV		CIns_196_dst::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 197
// Class :: est
/////////////////////////////////////////////////////////
const UI32			CIns_197_est::m_id = 197;
const std::string	CIns_197_est::m_mne("est");
const UI32			CIns_197_est::m_numop = 0;
const BS_IPRV		CIns_197_est::m_priviledge(0x8);
const BS_ICAT		CIns_197_est::m_category(0x0);
const BS_IBHV		CIns_197_est::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 198
// Class :: ldtc.gr
/////////////////////////////////////////////////////////
const UI32			CIns_198_ldtc_gr::m_id = 198;
const std::string	CIns_198_ldtc_gr::m_mne("ldtc.gr");
const UI32			CIns_198_ldtc_gr::m_numop = 2;
const BS_IPRV		CIns_198_ldtc_gr::m_priviledge(0x8);
const BS_ICAT		CIns_198_ldtc_gr::m_category(0x0);
const BS_IBHV		CIns_198_ldtc_gr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 199
// Class :: ldtc.vr
/////////////////////////////////////////////////////////
const UI32			CIns_199_ldtc_vr::m_id = 199;
const std::string	CIns_199_ldtc_vr::m_mne("ldtc.vr");
const UI32			CIns_199_ldtc_vr::m_numop = 2;
const BS_IPRV		CIns_199_ldtc_vr::m_priviledge(0x8);
const BS_ICAT		CIns_199_ldtc_vr::m_category(0x0);
const BS_IBHV		CIns_199_ldtc_vr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 200
// Class :: ldtc.pc
/////////////////////////////////////////////////////////
const UI32			CIns_200_ldtc_pc::m_id = 200;
const std::string	CIns_200_ldtc_pc::m_mne("ldtc.pc");
const UI32			CIns_200_ldtc_pc::m_numop = 1;
const BS_IPRV		CIns_200_ldtc_pc::m_priviledge(0x8);
const BS_ICAT		CIns_200_ldtc_pc::m_category(0x0);
const BS_IBHV		CIns_200_ldtc_pc::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 201
// Class :: ldtc.sr
/////////////////////////////////////////////////////////
std::string CIns_201_ldtc_sr::GetCode() {
	UI32 sr = (UI32)*opr(1);
	std::stringstream ss;
	
	ss << "ldtc.sr " << opr(0)->GetCode();
	ss << ", sr" << (sr & 0x1f);
	ss << ", sel" << (sr >> 5);
	return ss.str();
}

std::string CIns_201_ldtc_sr::GetOutCode() {
	UI32 sr = (UI32)*opr(1);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << "ldtc.sr " << opr(0)->GetCode();
	ss << ", " << (sr & 0x1f);
	ss << ", " << (sr >> 5);
	return ss.str();
}

const UI32			CIns_201_ldtc_sr::m_id = 201;
const std::string	CIns_201_ldtc_sr::m_mne("ldtc.sr");
const UI32			CIns_201_ldtc_sr::m_numop = 2;
const BS_IPRV		CIns_201_ldtc_sr::m_priviledge(0x8);
const BS_ICAT		CIns_201_ldtc_sr::m_category(0x0);
const BS_IBHV		CIns_201_ldtc_sr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 202
// Class :: sttc.gr
/////////////////////////////////////////////////////////
const UI32			CIns_202_sttc_gr::m_id = 202;
const std::string	CIns_202_sttc_gr::m_mne("sttc.gr");
const UI32			CIns_202_sttc_gr::m_numop = 2;
const BS_IPRV		CIns_202_sttc_gr::m_priviledge(0x8);
const BS_ICAT		CIns_202_sttc_gr::m_category(0x0);
const BS_IBHV		CIns_202_sttc_gr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 203
// Class :: sttc.vr
/////////////////////////////////////////////////////////
const UI32			CIns_203_sttc_vr::m_id = 203;
const std::string	CIns_203_sttc_vr::m_mne("sttc.vr");
const UI32			CIns_203_sttc_vr::m_numop = 2;
const BS_IPRV		CIns_203_sttc_vr::m_priviledge(0x8);
const BS_ICAT		CIns_203_sttc_vr::m_category(0x0);
const BS_IBHV		CIns_203_sttc_vr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 204
// Class :: sttc.pc
/////////////////////////////////////////////////////////
const UI32			CIns_204_sttc_pc::m_id = 204;
const std::string	CIns_204_sttc_pc::m_mne("sttc.pc");
const UI32			CIns_204_sttc_pc::m_numop = 1;
const BS_IPRV		CIns_204_sttc_pc::m_priviledge(0x8);
const BS_ICAT		CIns_204_sttc_pc::m_category(0x0);
const BS_IBHV		CIns_204_sttc_pc::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 205
// Class :: sttc.sr
/////////////////////////////////////////////////////////
std::string CIns_205_sttc_sr::GetCode() {
	UI32 sr = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << "sttc.sr " << "sr" << (sr & 0x1f) ;
	ss << ", " << opr(1)->GetCode();
	ss << ", sel" << (sr >> 5);
	
	return ss.str();
}

std::string CIns_205_sttc_sr::GetOutCode() {
	UI32 sr = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << "sttc.sr " << (sr & 0x1f) ;
	ss << ", " << opr(1)->GetCode();
	ss << ", " << (sr >> 5);
	
	return ss.str();
}

const UI32			CIns_205_sttc_sr::m_id = 205;
const std::string	CIns_205_sttc_sr::m_mne("sttc.sr");
const UI32			CIns_205_sttc_sr::m_numop = 2;
const BS_IPRV		CIns_205_sttc_sr::m_priviledge(0x8);
const BS_ICAT		CIns_205_sttc_sr::m_category(0x0);
const BS_IBHV		CIns_205_sttc_sr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 206
// Class :: cache
/////////////////////////////////////////////////////////

void CIns_206_cache::Regulate(IRegulation* pReg) {
    IInstruction::Regulate(pReg);

    if (pReg->Pass()) {
        UI32 RegVal = 0;
        std::string cacheop = this->opr(0)->GetCode();
        UI32 reg = this->opr(1)->Idx();

        pReg->m_pSim->ReadGrReg(&RegVal, (SI32)reg, pReg->m_ht);

        if (cacheop == "CHBII" && g_sim->IsMDPexception(RegVal - 0x20, 0x40, true, false) != NO_ERROR) {
            this->SetException(0x91, 0x90);
        }
    }
}
const UI32			CIns_206_cache::m_id = 206;
const std::string	CIns_206_cache::m_mne("cache");
const UI32			CIns_206_cache::m_numop = 2;
const BS_IPRV		CIns_206_cache::m_priviledge(0x0);
const BS_ICAT		CIns_206_cache::m_category(0x8);
const BS_IBHV		CIns_206_cache::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 207
// Class :: pref
/////////////////////////////////////////////////////////
const UI32			CIns_207_pref::m_id = 207;
const std::string	CIns_207_pref::m_mne("pref");
const UI32			CIns_207_pref::m_numop = 2;
const BS_IPRV		CIns_207_pref::m_priviledge(0x0);
const BS_ICAT		CIns_207_pref::m_category(0x8);
const BS_IBHV		CIns_207_pref::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 208
// Class :: tlbai
/////////////////////////////////////////////////////////
const UI32			CIns_208_tlbai::m_id = 208;
const std::string	CIns_208_tlbai::m_mne("tlbai");
const UI32			CIns_208_tlbai::m_numop = 0;
const BS_IPRV		CIns_208_tlbai::m_priviledge(0x8);
const BS_ICAT		CIns_208_tlbai::m_category(0x20);
const BS_IBHV		CIns_208_tlbai::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 209
// Class :: tlbr
/////////////////////////////////////////////////////////
const UI32			CIns_209_tlbr::m_id = 209;
const std::string	CIns_209_tlbr::m_mne("tlbr");
const UI32			CIns_209_tlbr::m_numop = 0;
const BS_IPRV		CIns_209_tlbr::m_priviledge(0x10);
const BS_ICAT		CIns_209_tlbr::m_category(0x20);
const BS_IBHV		CIns_209_tlbr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 210
// Class :: tlbs
/////////////////////////////////////////////////////////
const UI32			CIns_210_tlbs::m_id = 210;
const std::string	CIns_210_tlbs::m_mne("tlbs");
const UI32			CIns_210_tlbs::m_numop = 0;
const BS_IPRV		CIns_210_tlbs::m_priviledge(0x10);
const BS_ICAT		CIns_210_tlbs::m_category(0x20);
const BS_IBHV		CIns_210_tlbs::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 211
// Class :: tlbvi
/////////////////////////////////////////////////////////
const UI32			CIns_211_tlbvi::m_id = 211;
const std::string	CIns_211_tlbvi::m_mne("tlbvi");
const UI32			CIns_211_tlbvi::m_numop = 0;
const BS_IPRV		CIns_211_tlbvi::m_priviledge(0x8);
const BS_ICAT		CIns_211_tlbvi::m_category(0x20);
const BS_IBHV		CIns_211_tlbvi::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 212
// Class :: tlbw
/////////////////////////////////////////////////////////
const UI32			CIns_212_tlbw::m_id = 212;
const std::string	CIns_212_tlbw::m_mne("tlbw");
const UI32			CIns_212_tlbw::m_numop = 0;
const BS_IPRV		CIns_212_tlbw::m_priviledge(0x10);
const BS_ICAT		CIns_212_tlbw::m_category(0x20);
const BS_IBHV		CIns_212_tlbw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 213
// Class :: dbcp
/////////////////////////////////////////////////////////
const UI32			CIns_213_dbcp::m_id = 213;
const std::string	CIns_213_dbcp::m_mne("dbcp");
const UI32			CIns_213_dbcp::m_numop = 0;
const BS_IPRV		CIns_213_dbcp::m_priviledge(0x0);
const BS_ICAT		CIns_213_dbcp::m_category(0x40);
const BS_IBHV		CIns_213_dbcp::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 214
// Class :: dbhvtrap
/////////////////////////////////////////////////////////
const UI32			CIns_214_dbhvtrap::m_id = 214;
const std::string	CIns_214_dbhvtrap::m_mne("dbhvtrap");
const UI32			CIns_214_dbhvtrap::m_numop = 0;
const BS_IPRV		CIns_214_dbhvtrap::m_priviledge(0x0);
const BS_ICAT		CIns_214_dbhvtrap::m_category(0x40);
const BS_IBHV		CIns_214_dbhvtrap::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 215
// Class :: dbpush
/////////////////////////////////////////////////////////
std::string CIns_215_dbpush::GetCode() {
	return std::string("dbpush " + opr(0)->GetCode()+ "-" + opr(1)->GetCode());
}

void CIns_215_dbpush::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(1);
//	IInstruction::Regulate(pReg);
}

const UI32			CIns_215_dbpush::m_id = 215;
const std::string	CIns_215_dbpush::m_mne("dbpush");
const UI32			CIns_215_dbpush::m_numop = 2;
const BS_IPRV		CIns_215_dbpush::m_priviledge(0x0);
const BS_ICAT		CIns_215_dbpush::m_category(0x40);
const BS_IBHV		CIns_215_dbpush::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 216
// Class :: dbret
/////////////////////////////////////////////////////////
const UI32			CIns_216_dbret::m_id = 216;
const std::string	CIns_216_dbret::m_mne("dbret");
const UI32			CIns_216_dbret::m_numop = 0;
const BS_IPRV		CIns_216_dbret::m_priviledge(0x20);
const BS_ICAT		CIns_216_dbret::m_category(0x40);
const BS_IBHV		CIns_216_dbret::m_behavior(0x400);



/////////////////////////////////////////////////////////
// InsID :: 217
// Class :: dbtag
/////////////////////////////////////////////////////////
const UI32			CIns_217_dbtag::m_id = 217;
const std::string	CIns_217_dbtag::m_mne("dbtag");
const UI32			CIns_217_dbtag::m_numop = 1;
const BS_IPRV		CIns_217_dbtag::m_priviledge(0x0);
const BS_ICAT		CIns_217_dbtag::m_category(0x40);
const BS_IBHV		CIns_217_dbtag::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 218
// Class :: dbtrap
/////////////////////////////////////////////////////////
const UI32			CIns_218_dbtrap::m_id = 218;
const std::string	CIns_218_dbtrap::m_mne("dbtrap");
const UI32			CIns_218_dbtrap::m_numop = 0;
const BS_IPRV		CIns_218_dbtrap::m_priviledge(0x0);
const BS_ICAT		CIns_218_dbtrap::m_category(0x40);
const BS_IBHV		CIns_218_dbtrap::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 219
// Class :: rmtrap
/////////////////////////////////////////////////////////
const UI32			CIns_219_rmtrap::m_id = 219;
const std::string	CIns_219_rmtrap::m_mne("rmtrap");
const UI32			CIns_219_rmtrap::m_numop = 0;
const BS_IPRV		CIns_219_rmtrap::m_priviledge(0x0);
const BS_ICAT		CIns_219_rmtrap::m_category(0x40);
const BS_IBHV		CIns_219_rmtrap::m_behavior(0xc00);



/////////////////////////////////////////////////////////
// InsID :: 220
// Class :: absf.d
/////////////////////////////////////////////////////////
const UI32			CIns_220_absf_d::m_id = 220;
const std::string	CIns_220_absf_d::m_mne("absf.d");
const UI32			CIns_220_absf_d::m_numop = 2;
const BS_IPRV		CIns_220_absf_d::m_priviledge(0x1);
const BS_ICAT		CIns_220_absf_d::m_category(0x2);
const BS_IBHV		CIns_220_absf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 221
// Class :: absf.s
/////////////////////////////////////////////////////////
const UI32			CIns_221_absf_s::m_id = 221;
const std::string	CIns_221_absf_s::m_mne("absf.s");
const UI32			CIns_221_absf_s::m_numop = 2;
const BS_IPRV		CIns_221_absf_s::m_priviledge(0x1);
const BS_ICAT		CIns_221_absf_s::m_category(0x1);
const BS_IBHV		CIns_221_absf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 222
// Class :: addf.d
/////////////////////////////////////////////////////////
const UI32			CIns_222_addf_d::m_id = 222;
const std::string	CIns_222_addf_d::m_mne("addf.d");
const UI32			CIns_222_addf_d::m_numop = 3;
const BS_IPRV		CIns_222_addf_d::m_priviledge(0x1);
const BS_ICAT		CIns_222_addf_d::m_category(0x2);
const BS_IBHV		CIns_222_addf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 223
// Class :: addf.s
/////////////////////////////////////////////////////////
const UI32			CIns_223_addf_s::m_id = 223;
const std::string	CIns_223_addf_s::m_mne("addf.s");
const UI32			CIns_223_addf_s::m_numop = 3;
const BS_IPRV		CIns_223_addf_s::m_priviledge(0x1);
const BS_ICAT		CIns_223_addf_s::m_category(0x1);
const BS_IBHV		CIns_223_addf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 224
// Class :: ceilf.dl
/////////////////////////////////////////////////////////
const UI32			CIns_224_ceilf_dl::m_id = 224;
const std::string	CIns_224_ceilf_dl::m_mne("ceilf.dl");
const UI32			CIns_224_ceilf_dl::m_numop = 2;
const BS_IPRV		CIns_224_ceilf_dl::m_priviledge(0x1);
const BS_ICAT		CIns_224_ceilf_dl::m_category(0x2);
const BS_IBHV		CIns_224_ceilf_dl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 225
// Class :: ceilf.dul
/////////////////////////////////////////////////////////
const UI32			CIns_225_ceilf_dul::m_id = 225;
const std::string	CIns_225_ceilf_dul::m_mne("ceilf.dul");
const UI32			CIns_225_ceilf_dul::m_numop = 2;
const BS_IPRV		CIns_225_ceilf_dul::m_priviledge(0x1);
const BS_ICAT		CIns_225_ceilf_dul::m_category(0x2);
const BS_IBHV		CIns_225_ceilf_dul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 226
// Class :: ceilf.duw
/////////////////////////////////////////////////////////
const UI32			CIns_226_ceilf_duw::m_id = 226;
const std::string	CIns_226_ceilf_duw::m_mne("ceilf.duw");
const UI32			CIns_226_ceilf_duw::m_numop = 2;
const BS_IPRV		CIns_226_ceilf_duw::m_priviledge(0x1);
const BS_ICAT		CIns_226_ceilf_duw::m_category(0x2);
const BS_IBHV		CIns_226_ceilf_duw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 227
// Class :: ceilf.dw
/////////////////////////////////////////////////////////
const UI32			CIns_227_ceilf_dw::m_id = 227;
const std::string	CIns_227_ceilf_dw::m_mne("ceilf.dw");
const UI32			CIns_227_ceilf_dw::m_numop = 2;
const BS_IPRV		CIns_227_ceilf_dw::m_priviledge(0x1);
const BS_ICAT		CIns_227_ceilf_dw::m_category(0x2);
const BS_IBHV		CIns_227_ceilf_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 228
// Class :: ceilf.sl
/////////////////////////////////////////////////////////
const UI32			CIns_228_ceilf_sl::m_id = 228;
const std::string	CIns_228_ceilf_sl::m_mne("ceilf.sl");
const UI32			CIns_228_ceilf_sl::m_numop = 2;
const BS_IPRV		CIns_228_ceilf_sl::m_priviledge(0x1);
const BS_ICAT		CIns_228_ceilf_sl::m_category(0x2);
const BS_IBHV		CIns_228_ceilf_sl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 229
// Class :: ceilf.sul
/////////////////////////////////////////////////////////
const UI32			CIns_229_ceilf_sul::m_id = 229;
const std::string	CIns_229_ceilf_sul::m_mne("ceilf.sul");
const UI32			CIns_229_ceilf_sul::m_numop = 2;
const BS_IPRV		CIns_229_ceilf_sul::m_priviledge(0x1);
const BS_ICAT		CIns_229_ceilf_sul::m_category(0x2);
const BS_IBHV		CIns_229_ceilf_sul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 230
// Class :: ceilf.suw
/////////////////////////////////////////////////////////
const UI32			CIns_230_ceilf_suw::m_id = 230;
const std::string	CIns_230_ceilf_suw::m_mne("ceilf.suw");
const UI32			CIns_230_ceilf_suw::m_numop = 2;
const BS_IPRV		CIns_230_ceilf_suw::m_priviledge(0x1);
const BS_ICAT		CIns_230_ceilf_suw::m_category(0x1);
const BS_IBHV		CIns_230_ceilf_suw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 231
// Class :: ceilf.sw
/////////////////////////////////////////////////////////
const UI32			CIns_231_ceilf_sw::m_id = 231;
const std::string	CIns_231_ceilf_sw::m_mne("ceilf.sw");
const UI32			CIns_231_ceilf_sw::m_numop = 2;
const BS_IPRV		CIns_231_ceilf_sw::m_priviledge(0x1);
const BS_ICAT		CIns_231_ceilf_sw::m_category(0x1);
const BS_IBHV		CIns_231_ceilf_sw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 232
// Class :: cmovf.d
/////////////////////////////////////////////////////////
const UI32			CIns_232_cmovf_d::m_id = 232;
const std::string	CIns_232_cmovf_d::m_mne("cmovf.d");
const UI32			CIns_232_cmovf_d::m_numop = 4;
const BS_IPRV		CIns_232_cmovf_d::m_priviledge(0x1);
const BS_ICAT		CIns_232_cmovf_d::m_category(0x2);
const BS_IBHV		CIns_232_cmovf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 233
// Class :: cmovf.s
/////////////////////////////////////////////////////////
const UI32			CIns_233_cmovf_s::m_id = 233;
const std::string	CIns_233_cmovf_s::m_mne("cmovf.s");
const UI32			CIns_233_cmovf_s::m_numop = 4;
const BS_IPRV		CIns_233_cmovf_s::m_priviledge(0x1);
const BS_ICAT		CIns_233_cmovf_s::m_category(0x1);
const BS_IBHV		CIns_233_cmovf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 234
// Class :: cmpf.d
/////////////////////////////////////////////////////////
std::string CIns_234_cmpf_d::GetOutCode() {
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << (UI32)*opr(0);	// fcond
	ss << ", " << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	ss << ", " << opr(3)->GetCode();
	
	return ss.str();
}

const UI32			CIns_234_cmpf_d::m_id = 234;
const std::string	CIns_234_cmpf_d::m_mne("cmpf.d");
const UI32			CIns_234_cmpf_d::m_numop = 4;
const BS_IPRV		CIns_234_cmpf_d::m_priviledge(0x1);
const BS_ICAT		CIns_234_cmpf_d::m_category(0x2);
const BS_IBHV		CIns_234_cmpf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 235
// Class :: cmpf.s
/////////////////////////////////////////////////////////
std::string CIns_235_cmpf_s::GetOutCode() {
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << (UI32)*opr(0);	// fcond
	ss << ", " << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	ss << ", " << opr(3)->GetCode();
	
	return ss.str();
}

const UI32			CIns_235_cmpf_s::m_id = 235;
const std::string	CIns_235_cmpf_s::m_mne("cmpf.s");
const UI32			CIns_235_cmpf_s::m_numop = 4;
const BS_IPRV		CIns_235_cmpf_s::m_priviledge(0x1);
const BS_ICAT		CIns_235_cmpf_s::m_category(0x1);
const BS_IBHV		CIns_235_cmpf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 236
// Class :: cvtf.dl
/////////////////////////////////////////////////////////
const UI32			CIns_236_cvtf_dl::m_id = 236;
const std::string	CIns_236_cvtf_dl::m_mne("cvtf.dl");
const UI32			CIns_236_cvtf_dl::m_numop = 2;
const BS_IPRV		CIns_236_cvtf_dl::m_priviledge(0x1);
const BS_ICAT		CIns_236_cvtf_dl::m_category(0x2);
const BS_IBHV		CIns_236_cvtf_dl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 237
// Class :: cvtf.ds
/////////////////////////////////////////////////////////
const UI32			CIns_237_cvtf_ds::m_id = 237;
const std::string	CIns_237_cvtf_ds::m_mne("cvtf.ds");
const UI32			CIns_237_cvtf_ds::m_numop = 2;
const BS_IPRV		CIns_237_cvtf_ds::m_priviledge(0x1);
const BS_ICAT		CIns_237_cvtf_ds::m_category(0x2);
const BS_IBHV		CIns_237_cvtf_ds::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 238
// Class :: cvtf.dul
/////////////////////////////////////////////////////////
const UI32			CIns_238_cvtf_dul::m_id = 238;
const std::string	CIns_238_cvtf_dul::m_mne("cvtf.dul");
const UI32			CIns_238_cvtf_dul::m_numop = 2;
const BS_IPRV		CIns_238_cvtf_dul::m_priviledge(0x1);
const BS_ICAT		CIns_238_cvtf_dul::m_category(0x2);
const BS_IBHV		CIns_238_cvtf_dul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 239
// Class :: cvtf.duw
/////////////////////////////////////////////////////////
const UI32			CIns_239_cvtf_duw::m_id = 239;
const std::string	CIns_239_cvtf_duw::m_mne("cvtf.duw");
const UI32			CIns_239_cvtf_duw::m_numop = 2;
const BS_IPRV		CIns_239_cvtf_duw::m_priviledge(0x1);
const BS_ICAT		CIns_239_cvtf_duw::m_category(0x2);
const BS_IBHV		CIns_239_cvtf_duw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 240
// Class :: cvtf.dw
/////////////////////////////////////////////////////////
const UI32			CIns_240_cvtf_dw::m_id = 240;
const std::string	CIns_240_cvtf_dw::m_mne("cvtf.dw");
const UI32			CIns_240_cvtf_dw::m_numop = 2;
const BS_IPRV		CIns_240_cvtf_dw::m_priviledge(0x1);
const BS_ICAT		CIns_240_cvtf_dw::m_category(0x2);
const BS_IBHV		CIns_240_cvtf_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 241
// Class :: cvtf.hs
/////////////////////////////////////////////////////////
const UI32			CIns_241_cvtf_hs::m_id = 241;
const std::string	CIns_241_cvtf_hs::m_mne("cvtf.hs");
const UI32			CIns_241_cvtf_hs::m_numop = 2;
const BS_IPRV		CIns_241_cvtf_hs::m_priviledge(0x1);
const BS_ICAT		CIns_241_cvtf_hs::m_category(0x1);
const BS_IBHV		CIns_241_cvtf_hs::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 242
// Class :: cvtf.ld
/////////////////////////////////////////////////////////
const UI32			CIns_242_cvtf_ld::m_id = 242;
const std::string	CIns_242_cvtf_ld::m_mne("cvtf.ld");
const UI32			CIns_242_cvtf_ld::m_numop = 2;
const BS_IPRV		CIns_242_cvtf_ld::m_priviledge(0x1);
const BS_ICAT		CIns_242_cvtf_ld::m_category(0x2);
const BS_IBHV		CIns_242_cvtf_ld::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 243
// Class :: cvtf.ls
/////////////////////////////////////////////////////////
const UI32			CIns_243_cvtf_ls::m_id = 243;
const std::string	CIns_243_cvtf_ls::m_mne("cvtf.ls");
const UI32			CIns_243_cvtf_ls::m_numop = 2;
const BS_IPRV		CIns_243_cvtf_ls::m_priviledge(0x1);
const BS_ICAT		CIns_243_cvtf_ls::m_category(0x2);
const BS_IBHV		CIns_243_cvtf_ls::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 244
// Class :: cvtf.sd
/////////////////////////////////////////////////////////
const UI32			CIns_244_cvtf_sd::m_id = 244;
const std::string	CIns_244_cvtf_sd::m_mne("cvtf.sd");
const UI32			CIns_244_cvtf_sd::m_numop = 2;
const BS_IPRV		CIns_244_cvtf_sd::m_priviledge(0x1);
const BS_ICAT		CIns_244_cvtf_sd::m_category(0x2);
const BS_IBHV		CIns_244_cvtf_sd::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 245
// Class :: cvtf.sl
/////////////////////////////////////////////////////////
const UI32			CIns_245_cvtf_sl::m_id = 245;
const std::string	CIns_245_cvtf_sl::m_mne("cvtf.sl");
const UI32			CIns_245_cvtf_sl::m_numop = 2;
const BS_IPRV		CIns_245_cvtf_sl::m_priviledge(0x1);
const BS_ICAT		CIns_245_cvtf_sl::m_category(0x2);
const BS_IBHV		CIns_245_cvtf_sl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 246
// Class :: cvtf.sh
/////////////////////////////////////////////////////////
const UI32			CIns_246_cvtf_sh::m_id = 246;
const std::string	CIns_246_cvtf_sh::m_mne("cvtf.sh");
const UI32			CIns_246_cvtf_sh::m_numop = 2;
const BS_IPRV		CIns_246_cvtf_sh::m_priviledge(0x1);
const BS_ICAT		CIns_246_cvtf_sh::m_category(0x1);
const BS_IBHV		CIns_246_cvtf_sh::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 247
// Class :: cvtf.sul
/////////////////////////////////////////////////////////
const UI32			CIns_247_cvtf_sul::m_id = 247;
const std::string	CIns_247_cvtf_sul::m_mne("cvtf.sul");
const UI32			CIns_247_cvtf_sul::m_numop = 2;
const BS_IPRV		CIns_247_cvtf_sul::m_priviledge(0x1);
const BS_ICAT		CIns_247_cvtf_sul::m_category(0x2);
const BS_IBHV		CIns_247_cvtf_sul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 248
// Class :: cvtf.suw
/////////////////////////////////////////////////////////
const UI32			CIns_248_cvtf_suw::m_id = 248;
const std::string	CIns_248_cvtf_suw::m_mne("cvtf.suw");
const UI32			CIns_248_cvtf_suw::m_numop = 2;
const BS_IPRV		CIns_248_cvtf_suw::m_priviledge(0x1);
const BS_ICAT		CIns_248_cvtf_suw::m_category(0x1);
const BS_IBHV		CIns_248_cvtf_suw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 249
// Class :: cvtf.sw
/////////////////////////////////////////////////////////
const UI32			CIns_249_cvtf_sw::m_id = 249;
const std::string	CIns_249_cvtf_sw::m_mne("cvtf.sw");
const UI32			CIns_249_cvtf_sw::m_numop = 2;
const BS_IPRV		CIns_249_cvtf_sw::m_priviledge(0x1);
const BS_ICAT		CIns_249_cvtf_sw::m_category(0x1);
const BS_IBHV		CIns_249_cvtf_sw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 250
// Class :: cvtf.uld
/////////////////////////////////////////////////////////
const UI32			CIns_250_cvtf_uld::m_id = 250;
const std::string	CIns_250_cvtf_uld::m_mne("cvtf.uld");
const UI32			CIns_250_cvtf_uld::m_numop = 2;
const BS_IPRV		CIns_250_cvtf_uld::m_priviledge(0x1);
const BS_ICAT		CIns_250_cvtf_uld::m_category(0x2);
const BS_IBHV		CIns_250_cvtf_uld::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 251
// Class :: cvtf.uls
/////////////////////////////////////////////////////////
const UI32			CIns_251_cvtf_uls::m_id = 251;
const std::string	CIns_251_cvtf_uls::m_mne("cvtf.uls");
const UI32			CIns_251_cvtf_uls::m_numop = 2;
const BS_IPRV		CIns_251_cvtf_uls::m_priviledge(0x1);
const BS_ICAT		CIns_251_cvtf_uls::m_category(0x2);
const BS_IBHV		CIns_251_cvtf_uls::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 252
// Class :: cvtf.uwd
/////////////////////////////////////////////////////////
const UI32			CIns_252_cvtf_uwd::m_id = 252;
const std::string	CIns_252_cvtf_uwd::m_mne("cvtf.uwd");
const UI32			CIns_252_cvtf_uwd::m_numop = 2;
const BS_IPRV		CIns_252_cvtf_uwd::m_priviledge(0x1);
const BS_ICAT		CIns_252_cvtf_uwd::m_category(0x2);
const BS_IBHV		CIns_252_cvtf_uwd::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 253
// Class :: cvtf.uws
/////////////////////////////////////////////////////////
const UI32			CIns_253_cvtf_uws::m_id = 253;
const std::string	CIns_253_cvtf_uws::m_mne("cvtf.uws");
const UI32			CIns_253_cvtf_uws::m_numop = 2;
const BS_IPRV		CIns_253_cvtf_uws::m_priviledge(0x1);
const BS_ICAT		CIns_253_cvtf_uws::m_category(0x1);
const BS_IBHV		CIns_253_cvtf_uws::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 254
// Class :: cvtf.wd
/////////////////////////////////////////////////////////
const UI32			CIns_254_cvtf_wd::m_id = 254;
const std::string	CIns_254_cvtf_wd::m_mne("cvtf.wd");
const UI32			CIns_254_cvtf_wd::m_numop = 2;
const BS_IPRV		CIns_254_cvtf_wd::m_priviledge(0x1);
const BS_ICAT		CIns_254_cvtf_wd::m_category(0x2);
const BS_IBHV		CIns_254_cvtf_wd::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 255
// Class :: cvtf.ws
/////////////////////////////////////////////////////////
const UI32			CIns_255_cvtf_ws::m_id = 255;
const std::string	CIns_255_cvtf_ws::m_mne("cvtf.ws");
const UI32			CIns_255_cvtf_ws::m_numop = 2;
const BS_IPRV		CIns_255_cvtf_ws::m_priviledge(0x1);
const BS_ICAT		CIns_255_cvtf_ws::m_category(0x1);
const BS_IBHV		CIns_255_cvtf_ws::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 256
// Class :: divf.d
/////////////////////////////////////////////////////////
const UI32			CIns_256_divf_d::m_id = 256;
const std::string	CIns_256_divf_d::m_mne("divf.d");
const UI32			CIns_256_divf_d::m_numop = 3;
const BS_IPRV		CIns_256_divf_d::m_priviledge(0x1);
const BS_ICAT		CIns_256_divf_d::m_category(0x2);
const BS_IBHV		CIns_256_divf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 257
// Class :: divf.s
/////////////////////////////////////////////////////////
const UI32			CIns_257_divf_s::m_id = 257;
const std::string	CIns_257_divf_s::m_mne("divf.s");
const UI32			CIns_257_divf_s::m_numop = 3;
const BS_IPRV		CIns_257_divf_s::m_priviledge(0x1);
const BS_ICAT		CIns_257_divf_s::m_category(0x1);
const BS_IBHV		CIns_257_divf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 258
// Class :: floorf.dl
/////////////////////////////////////////////////////////
const UI32			CIns_258_floorf_dl::m_id = 258;
const std::string	CIns_258_floorf_dl::m_mne("floorf.dl");
const UI32			CIns_258_floorf_dl::m_numop = 2;
const BS_IPRV		CIns_258_floorf_dl::m_priviledge(0x1);
const BS_ICAT		CIns_258_floorf_dl::m_category(0x2);
const BS_IBHV		CIns_258_floorf_dl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 259
// Class :: floorf.dul
/////////////////////////////////////////////////////////
const UI32			CIns_259_floorf_dul::m_id = 259;
const std::string	CIns_259_floorf_dul::m_mne("floorf.dul");
const UI32			CIns_259_floorf_dul::m_numop = 2;
const BS_IPRV		CIns_259_floorf_dul::m_priviledge(0x1);
const BS_ICAT		CIns_259_floorf_dul::m_category(0x2);
const BS_IBHV		CIns_259_floorf_dul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 260
// Class :: floorf.duw
/////////////////////////////////////////////////////////
const UI32			CIns_260_floorf_duw::m_id = 260;
const std::string	CIns_260_floorf_duw::m_mne("floorf.duw");
const UI32			CIns_260_floorf_duw::m_numop = 2;
const BS_IPRV		CIns_260_floorf_duw::m_priviledge(0x1);
const BS_ICAT		CIns_260_floorf_duw::m_category(0x2);
const BS_IBHV		CIns_260_floorf_duw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 261
// Class :: floorf.dw
/////////////////////////////////////////////////////////
const UI32			CIns_261_floorf_dw::m_id = 261;
const std::string	CIns_261_floorf_dw::m_mne("floorf.dw");
const UI32			CIns_261_floorf_dw::m_numop = 2;
const BS_IPRV		CIns_261_floorf_dw::m_priviledge(0x1);
const BS_ICAT		CIns_261_floorf_dw::m_category(0x2);
const BS_IBHV		CIns_261_floorf_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 262
// Class :: floorf.sl
/////////////////////////////////////////////////////////
const UI32			CIns_262_floorf_sl::m_id = 262;
const std::string	CIns_262_floorf_sl::m_mne("floorf.sl");
const UI32			CIns_262_floorf_sl::m_numop = 2;
const BS_IPRV		CIns_262_floorf_sl::m_priviledge(0x1);
const BS_ICAT		CIns_262_floorf_sl::m_category(0x2);
const BS_IBHV		CIns_262_floorf_sl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 263
// Class :: floorf.sul
/////////////////////////////////////////////////////////
const UI32			CIns_263_floorf_sul::m_id = 263;
const std::string	CIns_263_floorf_sul::m_mne("floorf.sul");
const UI32			CIns_263_floorf_sul::m_numop = 2;
const BS_IPRV		CIns_263_floorf_sul::m_priviledge(0x1);
const BS_ICAT		CIns_263_floorf_sul::m_category(0x2);
const BS_IBHV		CIns_263_floorf_sul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 264
// Class :: floorf.suw
/////////////////////////////////////////////////////////
const UI32			CIns_264_floorf_suw::m_id = 264;
const std::string	CIns_264_floorf_suw::m_mne("floorf.suw");
const UI32			CIns_264_floorf_suw::m_numop = 2;
const BS_IPRV		CIns_264_floorf_suw::m_priviledge(0x1);
const BS_ICAT		CIns_264_floorf_suw::m_category(0x1);
const BS_IBHV		CIns_264_floorf_suw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 265
// Class :: floorf.sw
/////////////////////////////////////////////////////////
const UI32			CIns_265_floorf_sw::m_id = 265;
const std::string	CIns_265_floorf_sw::m_mne("floorf.sw");
const UI32			CIns_265_floorf_sw::m_numop = 2;
const BS_IPRV		CIns_265_floorf_sw::m_priviledge(0x1);
const BS_ICAT		CIns_265_floorf_sw::m_category(0x1);
const BS_IBHV		CIns_265_floorf_sw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 266
// Class :: fmaf.s
/////////////////////////////////////////////////////////
const UI32			CIns_266_fmaf_s::m_id = 266;
const std::string	CIns_266_fmaf_s::m_mne("fmaf.s");
const UI32			CIns_266_fmaf_s::m_numop = 3;
const BS_IPRV		CIns_266_fmaf_s::m_priviledge(0x1);
const BS_ICAT		CIns_266_fmaf_s::m_category(0x1);
const BS_IBHV		CIns_266_fmaf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 267
// Class :: fmsf.s
/////////////////////////////////////////////////////////
const UI32			CIns_267_fmsf_s::m_id = 267;
const std::string	CIns_267_fmsf_s::m_mne("fmsf.s");
const UI32			CIns_267_fmsf_s::m_numop = 3;
const BS_IPRV		CIns_267_fmsf_s::m_priviledge(0x1);
const BS_ICAT		CIns_267_fmsf_s::m_category(0x1);
const BS_IBHV		CIns_267_fmsf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 268
// Class :: fnmaf.s
/////////////////////////////////////////////////////////
const UI32			CIns_268_fnmaf_s::m_id = 268;
const std::string	CIns_268_fnmaf_s::m_mne("fnmaf.s");
const UI32			CIns_268_fnmaf_s::m_numop = 3;
const BS_IPRV		CIns_268_fnmaf_s::m_priviledge(0x1);
const BS_ICAT		CIns_268_fnmaf_s::m_category(0x1);
const BS_IBHV		CIns_268_fnmaf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 269
// Class :: fnmsf.s
/////////////////////////////////////////////////////////
const UI32			CIns_269_fnmsf_s::m_id = 269;
const std::string	CIns_269_fnmsf_s::m_mne("fnmsf.s");
const UI32			CIns_269_fnmsf_s::m_numop = 3;
const BS_IPRV		CIns_269_fnmsf_s::m_priviledge(0x1);
const BS_ICAT		CIns_269_fnmsf_s::m_category(0x1);
const BS_IBHV		CIns_269_fnmsf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 270
// Class :: maddf.s
/////////////////////////////////////////////////////////
const UI32			CIns_270_maddf_s::m_id = 270;
const std::string	CIns_270_maddf_s::m_mne("maddf.s");
const UI32			CIns_270_maddf_s::m_numop = 4;
const BS_IPRV		CIns_270_maddf_s::m_priviledge(0x1);
const BS_ICAT		CIns_270_maddf_s::m_category(0x1);
const BS_IBHV		CIns_270_maddf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 271
// Class :: maxf.d
/////////////////////////////////////////////////////////
const UI32			CIns_271_maxf_d::m_id = 271;
const std::string	CIns_271_maxf_d::m_mne("maxf.d");
const UI32			CIns_271_maxf_d::m_numop = 3;
const BS_IPRV		CIns_271_maxf_d::m_priviledge(0x1);
const BS_ICAT		CIns_271_maxf_d::m_category(0x2);
const BS_IBHV		CIns_271_maxf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 272
// Class :: maxf.s
/////////////////////////////////////////////////////////
const UI32			CIns_272_maxf_s::m_id = 272;
const std::string	CIns_272_maxf_s::m_mne("maxf.s");
const UI32			CIns_272_maxf_s::m_numop = 3;
const BS_IPRV		CIns_272_maxf_s::m_priviledge(0x1);
const BS_ICAT		CIns_272_maxf_s::m_category(0x1);
const BS_IBHV		CIns_272_maxf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 273
// Class :: minf.d
/////////////////////////////////////////////////////////
const UI32			CIns_273_minf_d::m_id = 273;
const std::string	CIns_273_minf_d::m_mne("minf.d");
const UI32			CIns_273_minf_d::m_numop = 3;
const BS_IPRV		CIns_273_minf_d::m_priviledge(0x1);
const BS_ICAT		CIns_273_minf_d::m_category(0x2);
const BS_IBHV		CIns_273_minf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 274
// Class :: minf.s
/////////////////////////////////////////////////////////
const UI32			CIns_274_minf_s::m_id = 274;
const std::string	CIns_274_minf_s::m_mne("minf.s");
const UI32			CIns_274_minf_s::m_numop = 3;
const BS_IPRV		CIns_274_minf_s::m_priviledge(0x1);
const BS_ICAT		CIns_274_minf_s::m_category(0x1);
const BS_IBHV		CIns_274_minf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 275
// Class :: msubf.s
/////////////////////////////////////////////////////////
const UI32			CIns_275_msubf_s::m_id = 275;
const std::string	CIns_275_msubf_s::m_mne("msubf.s");
const UI32			CIns_275_msubf_s::m_numop = 4;
const BS_IPRV		CIns_275_msubf_s::m_priviledge(0x1);
const BS_ICAT		CIns_275_msubf_s::m_category(0x1);
const BS_IBHV		CIns_275_msubf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 276
// Class :: mulf.d
/////////////////////////////////////////////////////////
const UI32			CIns_276_mulf_d::m_id = 276;
const std::string	CIns_276_mulf_d::m_mne("mulf.d");
const UI32			CIns_276_mulf_d::m_numop = 3;
const BS_IPRV		CIns_276_mulf_d::m_priviledge(0x1);
const BS_ICAT		CIns_276_mulf_d::m_category(0x2);
const BS_IBHV		CIns_276_mulf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 277
// Class :: mulf.s
/////////////////////////////////////////////////////////
const UI32			CIns_277_mulf_s::m_id = 277;
const std::string	CIns_277_mulf_s::m_mne("mulf.s");
const UI32			CIns_277_mulf_s::m_numop = 3;
const BS_IPRV		CIns_277_mulf_s::m_priviledge(0x1);
const BS_ICAT		CIns_277_mulf_s::m_category(0x1);
const BS_IBHV		CIns_277_mulf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 278
// Class :: negf.d
/////////////////////////////////////////////////////////
const UI32			CIns_278_negf_d::m_id = 278;
const std::string	CIns_278_negf_d::m_mne("negf.d");
const UI32			CIns_278_negf_d::m_numop = 2;
const BS_IPRV		CIns_278_negf_d::m_priviledge(0x1);
const BS_ICAT		CIns_278_negf_d::m_category(0x2);
const BS_IBHV		CIns_278_negf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 279
// Class :: negf.s
/////////////////////////////////////////////////////////
const UI32			CIns_279_negf_s::m_id = 279;
const std::string	CIns_279_negf_s::m_mne("negf.s");
const UI32			CIns_279_negf_s::m_numop = 2;
const BS_IPRV		CIns_279_negf_s::m_priviledge(0x1);
const BS_ICAT		CIns_279_negf_s::m_category(0x1);
const BS_IBHV		CIns_279_negf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 280
// Class :: nmaddf.s
/////////////////////////////////////////////////////////
const UI32			CIns_280_nmaddf_s::m_id = 280;
const std::string	CIns_280_nmaddf_s::m_mne("nmaddf.s");
const UI32			CIns_280_nmaddf_s::m_numop = 4;
const BS_IPRV		CIns_280_nmaddf_s::m_priviledge(0x1);
const BS_ICAT		CIns_280_nmaddf_s::m_category(0x1);
const BS_IBHV		CIns_280_nmaddf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 281
// Class :: nmsubf.s
/////////////////////////////////////////////////////////
const UI32			CIns_281_nmsubf_s::m_id = 281;
const std::string	CIns_281_nmsubf_s::m_mne("nmsubf.s");
const UI32			CIns_281_nmsubf_s::m_numop = 4;
const BS_IPRV		CIns_281_nmsubf_s::m_priviledge(0x1);
const BS_ICAT		CIns_281_nmsubf_s::m_category(0x1);
const BS_IBHV		CIns_281_nmsubf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 282
// Class :: recipf.d
/////////////////////////////////////////////////////////
const UI32			CIns_282_recipf_d::m_id = 282;
const std::string	CIns_282_recipf_d::m_mne("recipf.d");
const UI32			CIns_282_recipf_d::m_numop = 2;
const BS_IPRV		CIns_282_recipf_d::m_priviledge(0x1);
const BS_ICAT		CIns_282_recipf_d::m_category(0x2);
const BS_IBHV		CIns_282_recipf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 283
// Class :: recipf.s
/////////////////////////////////////////////////////////
const UI32			CIns_283_recipf_s::m_id = 283;
const std::string	CIns_283_recipf_s::m_mne("recipf.s");
const UI32			CIns_283_recipf_s::m_numop = 2;
const BS_IPRV		CIns_283_recipf_s::m_priviledge(0x1);
const BS_ICAT		CIns_283_recipf_s::m_category(0x1);
const BS_IBHV		CIns_283_recipf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 284
// Class :: roundf.dl
/////////////////////////////////////////////////////////
const UI32			CIns_284_roundf_dl::m_id = 284;
const std::string	CIns_284_roundf_dl::m_mne("roundf.dl");
const UI32			CIns_284_roundf_dl::m_numop = 2;
const BS_IPRV		CIns_284_roundf_dl::m_priviledge(0x1);
const BS_ICAT		CIns_284_roundf_dl::m_category(0x2);
const BS_IBHV		CIns_284_roundf_dl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 285
// Class :: roundf.dul
/////////////////////////////////////////////////////////
const UI32			CIns_285_roundf_dul::m_id = 285;
const std::string	CIns_285_roundf_dul::m_mne("roundf.dul");
const UI32			CIns_285_roundf_dul::m_numop = 2;
const BS_IPRV		CIns_285_roundf_dul::m_priviledge(0x1);
const BS_ICAT		CIns_285_roundf_dul::m_category(0x2);
const BS_IBHV		CIns_285_roundf_dul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 286
// Class :: roundf.duw
/////////////////////////////////////////////////////////
const UI32			CIns_286_roundf_duw::m_id = 286;
const std::string	CIns_286_roundf_duw::m_mne("roundf.duw");
const UI32			CIns_286_roundf_duw::m_numop = 2;
const BS_IPRV		CIns_286_roundf_duw::m_priviledge(0x1);
const BS_ICAT		CIns_286_roundf_duw::m_category(0x2);
const BS_IBHV		CIns_286_roundf_duw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 287
// Class :: roundf.dw
/////////////////////////////////////////////////////////
const UI32			CIns_287_roundf_dw::m_id = 287;
const std::string	CIns_287_roundf_dw::m_mne("roundf.dw");
const UI32			CIns_287_roundf_dw::m_numop = 2;
const BS_IPRV		CIns_287_roundf_dw::m_priviledge(0x1);
const BS_ICAT		CIns_287_roundf_dw::m_category(0x2);
const BS_IBHV		CIns_287_roundf_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 288
// Class :: roundf.sl
/////////////////////////////////////////////////////////
const UI32			CIns_288_roundf_sl::m_id = 288;
const std::string	CIns_288_roundf_sl::m_mne("roundf.sl");
const UI32			CIns_288_roundf_sl::m_numop = 2;
const BS_IPRV		CIns_288_roundf_sl::m_priviledge(0x1);
const BS_ICAT		CIns_288_roundf_sl::m_category(0x2);
const BS_IBHV		CIns_288_roundf_sl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 289
// Class :: roundf.sul
/////////////////////////////////////////////////////////
const UI32			CIns_289_roundf_sul::m_id = 289;
const std::string	CIns_289_roundf_sul::m_mne("roundf.sul");
const UI32			CIns_289_roundf_sul::m_numop = 2;
const BS_IPRV		CIns_289_roundf_sul::m_priviledge(0x1);
const BS_ICAT		CIns_289_roundf_sul::m_category(0x2);
const BS_IBHV		CIns_289_roundf_sul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 290
// Class :: roundf.suw
/////////////////////////////////////////////////////////
const UI32			CIns_290_roundf_suw::m_id = 290;
const std::string	CIns_290_roundf_suw::m_mne("roundf.suw");
const UI32			CIns_290_roundf_suw::m_numop = 2;
const BS_IPRV		CIns_290_roundf_suw::m_priviledge(0x1);
const BS_ICAT		CIns_290_roundf_suw::m_category(0x1);
const BS_IBHV		CIns_290_roundf_suw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 291
// Class :: roundf.sw
/////////////////////////////////////////////////////////
const UI32			CIns_291_roundf_sw::m_id = 291;
const std::string	CIns_291_roundf_sw::m_mne("roundf.sw");
const UI32			CIns_291_roundf_sw::m_numop = 2;
const BS_IPRV		CIns_291_roundf_sw::m_priviledge(0x1);
const BS_ICAT		CIns_291_roundf_sw::m_category(0x1);
const BS_IBHV		CIns_291_roundf_sw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 292
// Class :: rsqrtf.d
/////////////////////////////////////////////////////////
const UI32			CIns_292_rsqrtf_d::m_id = 292;
const std::string	CIns_292_rsqrtf_d::m_mne("rsqrtf.d");
const UI32			CIns_292_rsqrtf_d::m_numop = 2;
const BS_IPRV		CIns_292_rsqrtf_d::m_priviledge(0x1);
const BS_ICAT		CIns_292_rsqrtf_d::m_category(0x2);
const BS_IBHV		CIns_292_rsqrtf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 293
// Class :: rsqrtf.s
/////////////////////////////////////////////////////////
const UI32			CIns_293_rsqrtf_s::m_id = 293;
const std::string	CIns_293_rsqrtf_s::m_mne("rsqrtf.s");
const UI32			CIns_293_rsqrtf_s::m_numop = 2;
const BS_IPRV		CIns_293_rsqrtf_s::m_priviledge(0x1);
const BS_ICAT		CIns_293_rsqrtf_s::m_category(0x1);
const BS_IBHV		CIns_293_rsqrtf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 294
// Class :: sqrtf.d
/////////////////////////////////////////////////////////
const UI32			CIns_294_sqrtf_d::m_id = 294;
const std::string	CIns_294_sqrtf_d::m_mne("sqrtf.d");
const UI32			CIns_294_sqrtf_d::m_numop = 2;
const BS_IPRV		CIns_294_sqrtf_d::m_priviledge(0x1);
const BS_ICAT		CIns_294_sqrtf_d::m_category(0x2);
const BS_IBHV		CIns_294_sqrtf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 295
// Class :: sqrtf.s
/////////////////////////////////////////////////////////
const UI32			CIns_295_sqrtf_s::m_id = 295;
const std::string	CIns_295_sqrtf_s::m_mne("sqrtf.s");
const UI32			CIns_295_sqrtf_s::m_numop = 2;
const BS_IPRV		CIns_295_sqrtf_s::m_priviledge(0x1);
const BS_ICAT		CIns_295_sqrtf_s::m_category(0x1);
const BS_IBHV		CIns_295_sqrtf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 296
// Class :: subf.d
/////////////////////////////////////////////////////////
const UI32			CIns_296_subf_d::m_id = 296;
const std::string	CIns_296_subf_d::m_mne("subf.d");
const UI32			CIns_296_subf_d::m_numop = 3;
const BS_IPRV		CIns_296_subf_d::m_priviledge(0x1);
const BS_ICAT		CIns_296_subf_d::m_category(0x2);
const BS_IBHV		CIns_296_subf_d::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 297
// Class :: subf.s
/////////////////////////////////////////////////////////
const UI32			CIns_297_subf_s::m_id = 297;
const std::string	CIns_297_subf_s::m_mne("subf.s");
const UI32			CIns_297_subf_s::m_numop = 3;
const BS_IPRV		CIns_297_subf_s::m_priviledge(0x1);
const BS_ICAT		CIns_297_subf_s::m_category(0x1);
const BS_IBHV		CIns_297_subf_s::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 298
// Class :: trfsr
/////////////////////////////////////////////////////////
std::string CIns_298_trfsr::GetOutCode() {
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << (UI32)*opr(0);
	
	return ss.str();
}

const UI32			CIns_298_trfsr::m_id = 298;
const std::string	CIns_298_trfsr::m_mne("trfsr");
const UI32			CIns_298_trfsr::m_numop = 1;
const BS_IPRV		CIns_298_trfsr::m_priviledge(0x1);
const BS_ICAT		CIns_298_trfsr::m_category(0x1);
const BS_IBHV		CIns_298_trfsr::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 299
// Class :: trncf.dl
/////////////////////////////////////////////////////////
const UI32			CIns_299_trncf_dl::m_id = 299;
const std::string	CIns_299_trncf_dl::m_mne("trncf.dl");
const UI32			CIns_299_trncf_dl::m_numop = 2;
const BS_IPRV		CIns_299_trncf_dl::m_priviledge(0x1);
const BS_ICAT		CIns_299_trncf_dl::m_category(0x2);
const BS_IBHV		CIns_299_trncf_dl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 300
// Class :: trncf.dul
/////////////////////////////////////////////////////////
const UI32			CIns_300_trncf_dul::m_id = 300;
const std::string	CIns_300_trncf_dul::m_mne("trncf.dul");
const UI32			CIns_300_trncf_dul::m_numop = 2;
const BS_IPRV		CIns_300_trncf_dul::m_priviledge(0x1);
const BS_ICAT		CIns_300_trncf_dul::m_category(0x2);
const BS_IBHV		CIns_300_trncf_dul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 301
// Class :: trncf.duw
/////////////////////////////////////////////////////////
const UI32			CIns_301_trncf_duw::m_id = 301;
const std::string	CIns_301_trncf_duw::m_mne("trncf.duw");
const UI32			CIns_301_trncf_duw::m_numop = 2;
const BS_IPRV		CIns_301_trncf_duw::m_priviledge(0x1);
const BS_ICAT		CIns_301_trncf_duw::m_category(0x2);
const BS_IBHV		CIns_301_trncf_duw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 302
// Class :: trncf.dw
/////////////////////////////////////////////////////////
const UI32			CIns_302_trncf_dw::m_id = 302;
const std::string	CIns_302_trncf_dw::m_mne("trncf.dw");
const UI32			CIns_302_trncf_dw::m_numop = 2;
const BS_IPRV		CIns_302_trncf_dw::m_priviledge(0x1);
const BS_ICAT		CIns_302_trncf_dw::m_category(0x2);
const BS_IBHV		CIns_302_trncf_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 303
// Class :: trncf.sl
/////////////////////////////////////////////////////////
const UI32			CIns_303_trncf_sl::m_id = 303;
const std::string	CIns_303_trncf_sl::m_mne("trncf.sl");
const UI32			CIns_303_trncf_sl::m_numop = 2;
const BS_IPRV		CIns_303_trncf_sl::m_priviledge(0x1);
const BS_ICAT		CIns_303_trncf_sl::m_category(0x2);
const BS_IBHV		CIns_303_trncf_sl::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 304
// Class :: trncf.sul
/////////////////////////////////////////////////////////
const UI32			CIns_304_trncf_sul::m_id = 304;
const std::string	CIns_304_trncf_sul::m_mne("trncf.sul");
const UI32			CIns_304_trncf_sul::m_numop = 2;
const BS_IPRV		CIns_304_trncf_sul::m_priviledge(0x1);
const BS_ICAT		CIns_304_trncf_sul::m_category(0x2);
const BS_IBHV		CIns_304_trncf_sul::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 305
// Class :: trncf.suw
/////////////////////////////////////////////////////////
const UI32			CIns_305_trncf_suw::m_id = 305;
const std::string	CIns_305_trncf_suw::m_mne("trncf.suw");
const UI32			CIns_305_trncf_suw::m_numop = 2;
const BS_IPRV		CIns_305_trncf_suw::m_priviledge(0x1);
const BS_ICAT		CIns_305_trncf_suw::m_category(0x1);
const BS_IBHV		CIns_305_trncf_suw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 306
// Class :: trncf.sw
/////////////////////////////////////////////////////////
const UI32			CIns_306_trncf_sw::m_id = 306;
const std::string	CIns_306_trncf_sw::m_mne("trncf.sw");
const UI32			CIns_306_trncf_sw::m_numop = 2;
const BS_IPRV		CIns_306_trncf_sw::m_priviledge(0x1);
const BS_ICAT		CIns_306_trncf_sw::m_category(0x1);
const BS_IBHV		CIns_306_trncf_sw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 307
// Class :: cnvq15q30
/////////////////////////////////////////////////////////
const UI32			CIns_307_cnvq15q30::m_id = 307;
const std::string	CIns_307_cnvq15q30::m_mne("cnvq15q30");
const UI32			CIns_307_cnvq15q30::m_numop = 2;
const BS_IPRV		CIns_307_cnvq15q30::m_priviledge(0x2);
const BS_ICAT		CIns_307_cnvq15q30::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_307_cnvq15q30::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 308
// Class :: cnvq30q15
/////////////////////////////////////////////////////////
const UI32			CIns_308_cnvq30q15::m_id = 308;
const std::string	CIns_308_cnvq30q15::m_mne("cnvq30q15");
const UI32			CIns_308_cnvq30q15::m_numop = 2;
const BS_IPRV		CIns_308_cnvq30q15::m_priviledge(0x2);
const BS_ICAT		CIns_308_cnvq30q15::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_308_cnvq30q15::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 309
// Class :: cnvq31q62
/////////////////////////////////////////////////////////
const UI32			CIns_309_cnvq31q62::m_id = 309;
const std::string	CIns_309_cnvq31q62::m_mne("cnvq31q62");
const UI32			CIns_309_cnvq31q62::m_numop = 2;
const BS_IPRV		CIns_309_cnvq31q62::m_priviledge(0x2);
const BS_ICAT		CIns_309_cnvq31q62::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_309_cnvq31q62::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 310
// Class :: cnvq62q31
/////////////////////////////////////////////////////////
const UI32			CIns_310_cnvq62q31::m_id = 310;
const std::string	CIns_310_cnvq62q31::m_mne("cnvq62q31");
const UI32			CIns_310_cnvq62q31::m_numop = 2;
const BS_IPRV		CIns_310_cnvq62q31::m_priviledge(0x2);
const BS_ICAT		CIns_310_cnvq62q31::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_310_cnvq62q31::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 311
// Class :: dup.h
/////////////////////////////////////////////////////////
const UI32			CIns_311_dup_h::m_id = 311;
const std::string	CIns_311_dup_h::m_mne("dup.h");
const UI32			CIns_311_dup_h::m_numop = 3;
const BS_IPRV		CIns_311_dup_h::m_priviledge(0x2);
const BS_ICAT		CIns_311_dup_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_311_dup_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 312
// Class :: dup.w
/////////////////////////////////////////////////////////
const UI32			CIns_312_dup_w::m_id = 312;
const std::string	CIns_312_dup_w::m_mne("dup.w");
const UI32			CIns_312_dup_w::m_numop = 3;
const BS_IPRV		CIns_312_dup_w::m_priviledge(0x2);
const BS_ICAT		CIns_312_dup_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_312_dup_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 313
// Class :: expq31
/////////////////////////////////////////////////////////
const UI32			CIns_313_expq31::m_id = 313;
const std::string	CIns_313_expq31::m_mne("expq31");
const UI32			CIns_313_expq31::m_numop = 2;
const BS_IPRV		CIns_313_expq31::m_priviledge(0x2);
const BS_ICAT		CIns_313_expq31::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_313_expq31::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 314
// Class :: modadd
/////////////////////////////////////////////////////////
const UI32			CIns_314_modadd::m_id = 314;
const std::string	CIns_314_modadd::m_mne("modadd");
const UI32			CIns_314_modadd::m_numop = 1;
const BS_IPRV		CIns_314_modadd::m_priviledge(0x2);
const BS_ICAT		CIns_314_modadd::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_314_modadd::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 315
// Class :: mov.dw
/////////////////////////////////////////////////////////
const UI32			CIns_315_mov_dw::m_id = 315;
const std::string	CIns_315_mov_dw::m_mne("mov.dw");
const UI32			CIns_315_mov_dw::m_numop = 2;
const BS_IPRV		CIns_315_mov_dw::m_priviledge(0x2);
const BS_ICAT		CIns_315_mov_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_315_mov_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 316
// Class :: mov.dw
/////////////////////////////////////////////////////////
const UI32			CIns_316_mov_dw::m_id = 316;
const std::string	CIns_316_mov_dw::m_mne("mov.dw");
const UI32			CIns_316_mov_dw::m_numop = 2;
const BS_IPRV		CIns_316_mov_dw::m_priviledge(0x2);
const BS_ICAT		CIns_316_mov_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_316_mov_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 317
// Class :: mov.h
/////////////////////////////////////////////////////////
const UI32			CIns_317_mov_h::m_id = 317;
const std::string	CIns_317_mov_h::m_mne("mov.h");
const UI32			CIns_317_mov_h::m_numop = 3;
const BS_IPRV		CIns_317_mov_h::m_priviledge(0x2);
const BS_ICAT		CIns_317_mov_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_317_mov_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 318
// Class :: mov.w
/////////////////////////////////////////////////////////
const UI32			CIns_318_mov_w::m_id = 318;
const std::string	CIns_318_mov_w::m_mne("mov.w");
const UI32			CIns_318_mov_w::m_numop = 3;
const BS_IPRV		CIns_318_mov_w::m_priviledge(0x2);
const BS_ICAT		CIns_318_mov_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_318_mov_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 319
// Class :: mov.w
/////////////////////////////////////////////////////////
const UI32			CIns_319_mov_w::m_id = 319;
const std::string	CIns_319_mov_w::m_mne("mov.w");
const UI32			CIns_319_mov_w::m_numop = 3;
const BS_IPRV		CIns_319_mov_w::m_priviledge(0x2);
const BS_ICAT		CIns_319_mov_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_319_mov_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 320
// Class :: mov.w
/////////////////////////////////////////////////////////
const UI32			CIns_320_mov_w::m_id = 320;
const std::string	CIns_320_mov_w::m_mne("mov.w");
const UI32			CIns_320_mov_w::m_numop = 3;
const BS_IPRV		CIns_320_mov_w::m_priviledge(0x2);
const BS_ICAT		CIns_320_mov_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_320_mov_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 321
// Class :: pki16i32
/////////////////////////////////////////////////////////
const UI32			CIns_321_pki16i32::m_id = 321;
const std::string	CIns_321_pki16i32::m_mne("pki16i32");
const UI32			CIns_321_pki16i32::m_numop = 3;
const BS_IPRV		CIns_321_pki16i32::m_priviledge(0x2);
const BS_ICAT		CIns_321_pki16i32::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_321_pki16i32::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 322
// Class :: pki16ui8
/////////////////////////////////////////////////////////
const UI32			CIns_322_pki16ui8::m_id = 322;
const std::string	CIns_322_pki16ui8::m_mne("pki16ui8");
const UI32			CIns_322_pki16ui8::m_numop = 3;
const BS_IPRV		CIns_322_pki16ui8::m_priviledge(0x2);
const BS_ICAT		CIns_322_pki16ui8::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_322_pki16ui8::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 323
// Class :: pki32i16
/////////////////////////////////////////////////////////
const UI32			CIns_323_pki32i16::m_id = 323;
const std::string	CIns_323_pki32i16::m_mne("pki32i16");
const UI32			CIns_323_pki32i16::m_numop = 3;
const BS_IPRV		CIns_323_pki32i16::m_priviledge(0x2);
const BS_ICAT		CIns_323_pki32i16::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_323_pki32i16::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 324
// Class :: pki64i32
/////////////////////////////////////////////////////////
const UI32			CIns_324_pki64i32::m_id = 324;
const std::string	CIns_324_pki64i32::m_mne("pki64i32");
const UI32			CIns_324_pki64i32::m_numop = 3;
const BS_IPRV		CIns_324_pki64i32::m_priviledge(0x2);
const BS_ICAT		CIns_324_pki64i32::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_324_pki64i32::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 325
// Class :: pkq15q31
/////////////////////////////////////////////////////////
const UI32			CIns_325_pkq15q31::m_id = 325;
const std::string	CIns_325_pkq15q31::m_mne("pkq15q31");
const UI32			CIns_325_pkq15q31::m_numop = 3;
const BS_IPRV		CIns_325_pkq15q31::m_priviledge(0x2);
const BS_ICAT		CIns_325_pkq15q31::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_325_pkq15q31::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 326
// Class :: pkq30q31
/////////////////////////////////////////////////////////
const UI32			CIns_326_pkq30q31::m_id = 326;
const std::string	CIns_326_pkq30q31::m_mne("pkq30q31");
const UI32			CIns_326_pkq30q31::m_numop = 3;
const BS_IPRV		CIns_326_pkq30q31::m_priviledge(0x2);
const BS_ICAT		CIns_326_pkq30q31::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_326_pkq30q31::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 327
// Class :: pkq31q15
/////////////////////////////////////////////////////////
const UI32			CIns_327_pkq31q15::m_id = 327;
const std::string	CIns_327_pkq31q15::m_mne("pkq31q15");
const UI32			CIns_327_pkq31q15::m_numop = 3;
const BS_IPRV		CIns_327_pkq31q15::m_priviledge(0x2);
const BS_ICAT		CIns_327_pkq31q15::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_327_pkq31q15::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 328
// Class :: pkui8i16
/////////////////////////////////////////////////////////
const UI32			CIns_328_pkui8i16::m_id = 328;
const std::string	CIns_328_pkui8i16::m_mne("pkui8i16");
const UI32			CIns_328_pkui8i16::m_numop = 3;
const BS_IPRV		CIns_328_pkui8i16::m_priviledge(0x2);
const BS_ICAT		CIns_328_pkui8i16::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_328_pkui8i16::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 329
// Class :: vabs.h
/////////////////////////////////////////////////////////
const UI32			CIns_329_vabs_h::m_id = 329;
const std::string	CIns_329_vabs_h::m_mne("vabs.h");
const UI32			CIns_329_vabs_h::m_numop = 2;
const BS_IPRV		CIns_329_vabs_h::m_priviledge(0x2);
const BS_ICAT		CIns_329_vabs_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_329_vabs_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 330
// Class :: vabs.w
/////////////////////////////////////////////////////////
const UI32			CIns_330_vabs_w::m_id = 330;
const std::string	CIns_330_vabs_w::m_mne("vabs.w");
const UI32			CIns_330_vabs_w::m_numop = 2;
const BS_IPRV		CIns_330_vabs_w::m_priviledge(0x2);
const BS_ICAT		CIns_330_vabs_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_330_vabs_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 331
// Class :: vadd.dw
/////////////////////////////////////////////////////////
const UI32			CIns_331_vadd_dw::m_id = 331;
const std::string	CIns_331_vadd_dw::m_mne("vadd.dw");
const UI32			CIns_331_vadd_dw::m_numop = 3;
const BS_IPRV		CIns_331_vadd_dw::m_priviledge(0x2);
const BS_ICAT		CIns_331_vadd_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_331_vadd_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 332
// Class :: vadd.h
/////////////////////////////////////////////////////////
const UI32			CIns_332_vadd_h::m_id = 332;
const std::string	CIns_332_vadd_h::m_mne("vadd.h");
const UI32			CIns_332_vadd_h::m_numop = 3;
const BS_IPRV		CIns_332_vadd_h::m_priviledge(0x2);
const BS_ICAT		CIns_332_vadd_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_332_vadd_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 333
// Class :: vadd.w
/////////////////////////////////////////////////////////
const UI32			CIns_333_vadd_w::m_id = 333;
const std::string	CIns_333_vadd_w::m_mne("vadd.w");
const UI32			CIns_333_vadd_w::m_numop = 3;
const BS_IPRV		CIns_333_vadd_w::m_priviledge(0x2);
const BS_ICAT		CIns_333_vadd_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_333_vadd_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 334
// Class :: vadds.h
/////////////////////////////////////////////////////////
const UI32			CIns_334_vadds_h::m_id = 334;
const std::string	CIns_334_vadds_h::m_mne("vadds.h");
const UI32			CIns_334_vadds_h::m_numop = 3;
const BS_IPRV		CIns_334_vadds_h::m_priviledge(0x2);
const BS_ICAT		CIns_334_vadds_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_334_vadds_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 335
// Class :: vadds.w
/////////////////////////////////////////////////////////
const UI32			CIns_335_vadds_w::m_id = 335;
const std::string	CIns_335_vadds_w::m_mne("vadds.w");
const UI32			CIns_335_vadds_w::m_numop = 3;
const BS_IPRV		CIns_335_vadds_w::m_priviledge(0x2);
const BS_ICAT		CIns_335_vadds_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_335_vadds_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 336
// Class :: vaddsat.h
/////////////////////////////////////////////////////////
const UI32			CIns_336_vaddsat_h::m_id = 336;
const std::string	CIns_336_vaddsat_h::m_mne("vaddsat.h");
const UI32			CIns_336_vaddsat_h::m_numop = 3;
const BS_IPRV		CIns_336_vaddsat_h::m_priviledge(0x2);
const BS_ICAT		CIns_336_vaddsat_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_336_vaddsat_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 337
// Class :: vaddsat.w
/////////////////////////////////////////////////////////
const UI32			CIns_337_vaddsat_w::m_id = 337;
const std::string	CIns_337_vaddsat_w::m_mne("vaddsat.w");
const UI32			CIns_337_vaddsat_w::m_numop = 3;
const BS_IPRV		CIns_337_vaddsat_w::m_priviledge(0x2);
const BS_ICAT		CIns_337_vaddsat_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_337_vaddsat_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 338
// Class :: vand
/////////////////////////////////////////////////////////
const UI32			CIns_338_vand::m_id = 338;
const std::string	CIns_338_vand::m_mne("vand");
const UI32			CIns_338_vand::m_numop = 3;
const BS_IPRV		CIns_338_vand::m_priviledge(0x2);
const BS_ICAT		CIns_338_vand::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_338_vand::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 339
// Class :: vbiq.h
/////////////////////////////////////////////////////////
const UI32			CIns_339_vbiq_h::m_id = 339;
const std::string	CIns_339_vbiq_h::m_mne("vbiq.h");
const UI32			CIns_339_vbiq_h::m_numop = 3;
const BS_IPRV		CIns_339_vbiq_h::m_priviledge(0x2);
const BS_ICAT		CIns_339_vbiq_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_339_vbiq_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 340
// Class :: vbswap.dw
/////////////////////////////////////////////////////////
const UI32			CIns_340_vbswap_dw::m_id = 340;
const std::string	CIns_340_vbswap_dw::m_mne("vbswap.dw");
const UI32			CIns_340_vbswap_dw::m_numop = 2;
const BS_IPRV		CIns_340_vbswap_dw::m_priviledge(0x2);
const BS_ICAT		CIns_340_vbswap_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_340_vbswap_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 341
// Class :: vbswap.h
/////////////////////////////////////////////////////////
const UI32			CIns_341_vbswap_h::m_id = 341;
const std::string	CIns_341_vbswap_h::m_mne("vbswap.h");
const UI32			CIns_341_vbswap_h::m_numop = 2;
const BS_IPRV		CIns_341_vbswap_h::m_priviledge(0x2);
const BS_ICAT		CIns_341_vbswap_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_341_vbswap_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 342
// Class :: vbswap.w
/////////////////////////////////////////////////////////
const UI32			CIns_342_vbswap_w::m_id = 342;
const std::string	CIns_342_vbswap_w::m_mne("vbswap.w");
const UI32			CIns_342_vbswap_w::m_numop = 2;
const BS_IPRV		CIns_342_vbswap_w::m_priviledge(0x2);
const BS_ICAT		CIns_342_vbswap_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_342_vbswap_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 343
// Class :: vcalc.h
/////////////////////////////////////////////////////////
const UI32			CIns_343_vcalc_h::m_id = 343;
const std::string	CIns_343_vcalc_h::m_mne("vcalc.h");
const UI32			CIns_343_vcalc_h::m_numop = 4;
const BS_IPRV		CIns_343_vcalc_h::m_priviledge(0x2);
const BS_ICAT		CIns_343_vcalc_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_343_vcalc_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 344
// Class :: vcalc.w
/////////////////////////////////////////////////////////
const UI32			CIns_344_vcalc_w::m_id = 344;
const std::string	CIns_344_vcalc_w::m_mne("vcalc.w");
const UI32			CIns_344_vcalc_w::m_numop = 4;
const BS_IPRV		CIns_344_vcalc_w::m_priviledge(0x2);
const BS_ICAT		CIns_344_vcalc_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_344_vcalc_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 345
// Class :: vcmov
/////////////////////////////////////////////////////////
const UI32			CIns_345_vcmov::m_id = 345;
const std::string	CIns_345_vcmov::m_mne("vcmov");
const UI32			CIns_345_vcmov::m_numop = 4;
const BS_IPRV		CIns_345_vcmov::m_priviledge(0x2);
const BS_ICAT		CIns_345_vcmov::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_345_vcmov::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 346
// Class :: vcmpeq.h
/////////////////////////////////////////////////////////
const UI32			CIns_346_vcmpeq_h::m_id = 346;
const std::string	CIns_346_vcmpeq_h::m_mne("vcmpeq.h");
const UI32			CIns_346_vcmpeq_h::m_numop = 3;
const BS_IPRV		CIns_346_vcmpeq_h::m_priviledge(0x2);
const BS_ICAT		CIns_346_vcmpeq_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_346_vcmpeq_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 347
// Class :: vcmpeq.w
/////////////////////////////////////////////////////////
const UI32			CIns_347_vcmpeq_w::m_id = 347;
const std::string	CIns_347_vcmpeq_w::m_mne("vcmpeq.w");
const UI32			CIns_347_vcmpeq_w::m_numop = 3;
const BS_IPRV		CIns_347_vcmpeq_w::m_priviledge(0x2);
const BS_ICAT		CIns_347_vcmpeq_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_347_vcmpeq_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 348
// Class :: vcmple.h
/////////////////////////////////////////////////////////
const UI32			CIns_348_vcmple_h::m_id = 348;
const std::string	CIns_348_vcmple_h::m_mne("vcmple.h");
const UI32			CIns_348_vcmple_h::m_numop = 3;
const BS_IPRV		CIns_348_vcmple_h::m_priviledge(0x2);
const BS_ICAT		CIns_348_vcmple_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_348_vcmple_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 349
// Class :: vcmple.w
/////////////////////////////////////////////////////////
const UI32			CIns_349_vcmple_w::m_id = 349;
const std::string	CIns_349_vcmple_w::m_mne("vcmple.w");
const UI32			CIns_349_vcmple_w::m_numop = 3;
const BS_IPRV		CIns_349_vcmple_w::m_priviledge(0x2);
const BS_ICAT		CIns_349_vcmple_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_349_vcmple_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 350
// Class :: vcmplt.h
/////////////////////////////////////////////////////////
const UI32			CIns_350_vcmplt_h::m_id = 350;
const std::string	CIns_350_vcmplt_h::m_mne("vcmplt.h");
const UI32			CIns_350_vcmplt_h::m_numop = 3;
const BS_IPRV		CIns_350_vcmplt_h::m_priviledge(0x2);
const BS_ICAT		CIns_350_vcmplt_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_350_vcmplt_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 351
// Class :: vcmplt.w
/////////////////////////////////////////////////////////
const UI32			CIns_351_vcmplt_w::m_id = 351;
const std::string	CIns_351_vcmplt_w::m_mne("vcmplt.w");
const UI32			CIns_351_vcmplt_w::m_numop = 3;
const BS_IPRV		CIns_351_vcmplt_w::m_priviledge(0x2);
const BS_ICAT		CIns_351_vcmplt_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_351_vcmplt_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 352
// Class :: vcmpne.h
/////////////////////////////////////////////////////////
const UI32			CIns_352_vcmpne_h::m_id = 352;
const std::string	CIns_352_vcmpne_h::m_mne("vcmpne.h");
const UI32			CIns_352_vcmpne_h::m_numop = 3;
const BS_IPRV		CIns_352_vcmpne_h::m_priviledge(0x2);
const BS_ICAT		CIns_352_vcmpne_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_352_vcmpne_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 353
// Class :: vcmpne.w
/////////////////////////////////////////////////////////
const UI32			CIns_353_vcmpne_w::m_id = 353;
const std::string	CIns_353_vcmpne_w::m_mne("vcmpne.w");
const UI32			CIns_353_vcmpne_w::m_numop = 3;
const BS_IPRV		CIns_353_vcmpne_w::m_priviledge(0x2);
const BS_ICAT		CIns_353_vcmpne_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_353_vcmpne_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 354
// Class :: vconcat.b
/////////////////////////////////////////////////////////
const UI32			CIns_354_vconcat_b::m_id = 354;
const std::string	CIns_354_vconcat_b::m_mne("vconcat.b");
const UI32			CIns_354_vconcat_b::m_numop = 4;
const BS_IPRV		CIns_354_vconcat_b::m_priviledge(0x2);
const BS_ICAT		CIns_354_vconcat_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_354_vconcat_b::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 355
// Class :: vitlv.h
/////////////////////////////////////////////////////////
const UI32			CIns_355_vitlv_h::m_id = 355;
const std::string	CIns_355_vitlv_h::m_mne("vitlv.h");
const UI32			CIns_355_vitlv_h::m_numop = 2;
const BS_IPRV		CIns_355_vitlv_h::m_priviledge(0x2);
const BS_ICAT		CIns_355_vitlv_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_355_vitlv_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 356
// Class :: vitlv.w
/////////////////////////////////////////////////////////
const UI32			CIns_356_vitlv_w::m_id = 356;
const std::string	CIns_356_vitlv_w::m_mne("vitlv.w");
const UI32			CIns_356_vitlv_w::m_numop = 2;
const BS_IPRV		CIns_356_vitlv_w::m_priviledge(0x2);
const BS_ICAT		CIns_356_vitlv_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_356_vitlv_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 357
// Class :: vitlvhw.h
/////////////////////////////////////////////////////////
const UI32			CIns_357_vitlvhw_h::m_id = 357;
const std::string	CIns_357_vitlvhw_h::m_mne("vitlvhw.h");
const UI32			CIns_357_vitlvhw_h::m_numop = 2;
const BS_IPRV		CIns_357_vitlvhw_h::m_priviledge(0x2);
const BS_ICAT		CIns_357_vitlvhw_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_357_vitlvhw_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 358
// Class :: vitlvwh.h
/////////////////////////////////////////////////////////
const UI32			CIns_358_vitlvwh_h::m_id = 358;
const std::string	CIns_358_vitlvwh_h::m_mne("vitlvwh.h");
const UI32			CIns_358_vitlvwh_h::m_numop = 2;
const BS_IPRV		CIns_358_vitlvwh_h::m_priviledge(0x2);
const BS_ICAT		CIns_358_vitlvwh_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_358_vitlvwh_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 359
// Class :: vld.b
/////////////////////////////////////////////////////////
const UI32			CIns_359_vld_b::m_id = 359;
const std::string	CIns_359_vld_b::m_mne("vld.b");
const UI32			CIns_359_vld_b::m_numop = 2;
const BS_IPRV		CIns_359_vld_b::m_priviledge(0x2);
const BS_ICAT		CIns_359_vld_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_359_vld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 360
// Class :: vld.b
/////////////////////////////////////////////////////////
const UI32			CIns_360_vld_b::m_id = 360;
const std::string	CIns_360_vld_b::m_mne("vld.b");
const UI32			CIns_360_vld_b::m_numop = 2;
const BS_IPRV		CIns_360_vld_b::m_priviledge(0x2);
const BS_ICAT		CIns_360_vld_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_360_vld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 361
// Class :: vld.b
/////////////////////////////////////////////////////////
const UI32			CIns_361_vld_b::m_id = 361;
const std::string	CIns_361_vld_b::m_mne("vld.b");
const UI32			CIns_361_vld_b::m_numop = 3;
const BS_IPRV		CIns_361_vld_b::m_priviledge(0x2);
const BS_ICAT		CIns_361_vld_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_361_vld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 362
// Class :: vld.b
/////////////////////////////////////////////////////////
void CIns_362_vld_b::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(1);
	//IInstruction::Regulate(pReg); TODO:鐃緒申鐃緒申鐃緒申鐃緒申
	
	// 鐃銃ワ申鐃准ワ申鐃宿につわ申鐃緒申鐃緒申鐃緒申鐃緒申鐃緒申鐃獣ワ申鐃淑ワ申鐃所ア鐃緒申鐃緒申鐃緒申鐃緒申
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_362_vld_b::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}

const UI32			CIns_362_vld_b::m_id = 362;
const std::string	CIns_362_vld_b::m_mne("vld.b");
const UI32			CIns_362_vld_b::m_numop = 3;
const BS_IPRV		CIns_362_vld_b::m_priviledge(0x2);
const BS_ICAT		CIns_362_vld_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_362_vld_b::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 363
// Class :: vld.dw
/////////////////////////////////////////////////////////
const UI32			CIns_363_vld_dw::m_id = 363;
const std::string	CIns_363_vld_dw::m_mne("vld.dw");
const UI32			CIns_363_vld_dw::m_numop = 2;
const BS_IPRV		CIns_363_vld_dw::m_priviledge(0x2);
const BS_ICAT		CIns_363_vld_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_363_vld_dw::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 364
// Class :: vld.dw
/////////////////////////////////////////////////////////
const UI32			CIns_364_vld_dw::m_id = 364;
const std::string	CIns_364_vld_dw::m_mne("vld.dw");
const UI32			CIns_364_vld_dw::m_numop = 2;
const BS_IPRV		CIns_364_vld_dw::m_priviledge(0x2);
const BS_ICAT		CIns_364_vld_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_364_vld_dw::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 365
// Class :: vld.dw
/////////////////////////////////////////////////////////
const UI32			CIns_365_vld_dw::m_id = 365;
const std::string	CIns_365_vld_dw::m_mne("vld.dw");
const UI32			CIns_365_vld_dw::m_numop = 3;
const BS_IPRV		CIns_365_vld_dw::m_priviledge(0x2);
const BS_ICAT		CIns_365_vld_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_365_vld_dw::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 366
// Class :: vld.dw
/////////////////////////////////////////////////////////
void CIns_366_vld_dw::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(1);
	//IInstruction::Regulate(pReg); TODO:鐃緒申鐃緒申鐃緒申鐃緒申
	
	// 鐃銃ワ申鐃准ワ申鐃宿につわ申鐃緒申鐃緒申鐃緒申鐃緒申鐃緒申鐃獣ワ申鐃淑ワ申鐃所ア鐃緒申鐃緒申鐃緒申鐃緒申
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_366_vld_dw::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}

const UI32			CIns_366_vld_dw::m_id = 366;
const std::string	CIns_366_vld_dw::m_mne("vld.dw");
const UI32			CIns_366_vld_dw::m_numop = 3;
const BS_IPRV		CIns_366_vld_dw::m_priviledge(0x2);
const BS_ICAT		CIns_366_vld_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_366_vld_dw::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 367
// Class :: vld.dw
/////////////////////////////////////////////////////////
const UI32			CIns_367_vld_dw::m_id = 367;
const std::string	CIns_367_vld_dw::m_mne("vld.dw");
const UI32			CIns_367_vld_dw::m_numop = 2;
const BS_IPRV		CIns_367_vld_dw::m_priviledge(0x2);
const BS_ICAT		CIns_367_vld_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_367_vld_dw::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 368
// Class :: vld.h
/////////////////////////////////////////////////////////
const UI32			CIns_368_vld_h::m_id = 368;
const std::string	CIns_368_vld_h::m_mne("vld.h");
const UI32			CIns_368_vld_h::m_numop = 2;
const BS_IPRV		CIns_368_vld_h::m_priviledge(0x2);
const BS_ICAT		CIns_368_vld_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_368_vld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 369
// Class :: vld.h
/////////////////////////////////////////////////////////
const UI32			CIns_369_vld_h::m_id = 369;
const std::string	CIns_369_vld_h::m_mne("vld.h");
const UI32			CIns_369_vld_h::m_numop = 2;
const BS_IPRV		CIns_369_vld_h::m_priviledge(0x2);
const BS_ICAT		CIns_369_vld_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_369_vld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 370
// Class :: vld.h
/////////////////////////////////////////////////////////
const UI32			CIns_370_vld_h::m_id = 370;
const std::string	CIns_370_vld_h::m_mne("vld.h");
const UI32			CIns_370_vld_h::m_numop = 3;
const BS_IPRV		CIns_370_vld_h::m_priviledge(0x2);
const BS_ICAT		CIns_370_vld_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_370_vld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 371
// Class :: vld.h
/////////////////////////////////////////////////////////
void CIns_371_vld_h::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(1);
	//IInstruction::Regulate(pReg); TODO:鐃緒申鐃緒申鐃緒申鐃緒申
	
	// 鐃銃ワ申鐃准ワ申鐃宿につわ申鐃緒申鐃緒申鐃緒申鐃緒申鐃緒申鐃獣ワ申鐃淑ワ申鐃所ア鐃緒申鐃緒申鐃緒申鐃緒申
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_371_vld_h::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	
	return UseOpr;
}

const UI32			CIns_371_vld_h::m_id = 371;
const std::string	CIns_371_vld_h::m_mne("vld.h");
const UI32			CIns_371_vld_h::m_numop = 3;
const BS_IPRV		CIns_371_vld_h::m_priviledge(0x2);
const BS_ICAT		CIns_371_vld_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_371_vld_h::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 372
// Class :: vld.w
/////////////////////////////////////////////////////////
const UI32			CIns_372_vld_w::m_id = 372;
const std::string	CIns_372_vld_w::m_mne("vld.w");
const UI32			CIns_372_vld_w::m_numop = 2;
const BS_IPRV		CIns_372_vld_w::m_priviledge(0x2);
const BS_ICAT		CIns_372_vld_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_372_vld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 373
// Class :: vld.w
/////////////////////////////////////////////////////////
const UI32			CIns_373_vld_w::m_id = 373;
const std::string	CIns_373_vld_w::m_mne("vld.w");
const UI32			CIns_373_vld_w::m_numop = 2;
const BS_IPRV		CIns_373_vld_w::m_priviledge(0x2);
const BS_ICAT		CIns_373_vld_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_373_vld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 374
// Class :: vld.w
/////////////////////////////////////////////////////////
const UI32			CIns_374_vld_w::m_id = 374;
const std::string	CIns_374_vld_w::m_mne("vld.w");
const UI32			CIns_374_vld_w::m_numop = 3;
const BS_IPRV		CIns_374_vld_w::m_priviledge(0x2);
const BS_ICAT		CIns_374_vld_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_374_vld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 375
// Class :: vld.w
/////////////////////////////////////////////////////////
void CIns_375_vld_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(1);
	//IInstruction::Regulate(pReg); TODO:鐃緒申鐃緒申鐃緒申鐃緒申
	
	// 鐃銃ワ申鐃准ワ申鐃宿につわ申鐃緒申鐃緒申鐃緒申鐃緒申鐃緒申鐃獣ワ申鐃淑ワ申鐃所ア鐃緒申鐃緒申鐃緒申鐃緒申
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_375_vld_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}


const UI32			CIns_375_vld_w::m_id = 375;
const std::string	CIns_375_vld_w::m_mne("vld.w");
const UI32			CIns_375_vld_w::m_numop = 3;
const BS_IPRV		CIns_375_vld_w::m_priviledge(0x2);
const BS_ICAT		CIns_375_vld_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_375_vld_w::m_behavior(0x1);



/////////////////////////////////////////////////////////
// InsID :: 376
// Class :: vmadrn.h
/////////////////////////////////////////////////////////
const UI32			CIns_376_vmadrn_h::m_id = 376;
const std::string	CIns_376_vmadrn_h::m_mne("vmadrn.h");
const UI32			CIns_376_vmadrn_h::m_numop = 3;
const BS_IPRV		CIns_376_vmadrn_h::m_priviledge(0x2);
const BS_ICAT		CIns_376_vmadrn_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_376_vmadrn_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 377
// Class :: vmadrn.w
/////////////////////////////////////////////////////////
const UI32			CIns_377_vmadrn_w::m_id = 377;
const std::string	CIns_377_vmadrn_w::m_mne("vmadrn.w");
const UI32			CIns_377_vmadrn_w::m_numop = 3;
const BS_IPRV		CIns_377_vmadrn_w::m_priviledge(0x2);
const BS_ICAT		CIns_377_vmadrn_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_377_vmadrn_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 378
// Class :: vmadsat.h
/////////////////////////////////////////////////////////
const UI32			CIns_378_vmadsat_h::m_id = 378;
const std::string	CIns_378_vmadsat_h::m_mne("vmadsat.h");
const UI32			CIns_378_vmadsat_h::m_numop = 3;
const BS_IPRV		CIns_378_vmadsat_h::m_priviledge(0x2);
const BS_ICAT		CIns_378_vmadsat_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_378_vmadsat_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 379
// Class :: vmadsat.w
/////////////////////////////////////////////////////////
const UI32			CIns_379_vmadsat_w::m_id = 379;
const std::string	CIns_379_vmadsat_w::m_mne("vmadsat.w");
const UI32			CIns_379_vmadsat_w::m_numop = 3;
const BS_IPRV		CIns_379_vmadsat_w::m_priviledge(0x2);
const BS_ICAT		CIns_379_vmadsat_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_379_vmadsat_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 380
// Class :: vmaxge.h
/////////////////////////////////////////////////////////
const UI32			CIns_380_vmaxge_h::m_id = 380;
const std::string	CIns_380_vmaxge_h::m_mne("vmaxge.h");
const UI32			CIns_380_vmaxge_h::m_numop = 3;
const BS_IPRV		CIns_380_vmaxge_h::m_priviledge(0x2);
const BS_ICAT		CIns_380_vmaxge_h::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_380_vmaxge_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 381
// Class :: vmaxge.w
/////////////////////////////////////////////////////////
const UI32			CIns_381_vmaxge_w::m_id = 381;
const std::string	CIns_381_vmaxge_w::m_mne("vmaxge.w");
const UI32			CIns_381_vmaxge_w::m_numop = 3;
const BS_IPRV		CIns_381_vmaxge_w::m_priviledge(0x2);
const BS_ICAT		CIns_381_vmaxge_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_381_vmaxge_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 382
// Class :: vmaxgt.h
/////////////////////////////////////////////////////////
const UI32			CIns_382_vmaxgt_h::m_id = 382;
const std::string	CIns_382_vmaxgt_h::m_mne("vmaxgt.h");
const UI32			CIns_382_vmaxgt_h::m_numop = 3;
const BS_IPRV		CIns_382_vmaxgt_h::m_priviledge(0x2);
const BS_ICAT		CIns_382_vmaxgt_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_382_vmaxgt_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 383
// Class :: vmaxgt.w
/////////////////////////////////////////////////////////
const UI32			CIns_383_vmaxgt_w::m_id = 383;
const std::string	CIns_383_vmaxgt_w::m_mne("vmaxgt.w");
const UI32			CIns_383_vmaxgt_w::m_numop = 3;
const BS_IPRV		CIns_383_vmaxgt_w::m_priviledge(0x2);
const BS_ICAT		CIns_383_vmaxgt_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_383_vmaxgt_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 384
// Class :: vminle.h
/////////////////////////////////////////////////////////
const UI32			CIns_384_vminle_h::m_id = 384;
const std::string	CIns_384_vminle_h::m_mne("vminle.h");
const UI32			CIns_384_vminle_h::m_numop = 3;
const BS_IPRV		CIns_384_vminle_h::m_priviledge(0x2);
const BS_ICAT		CIns_384_vminle_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_384_vminle_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 385
// Class :: vminle.w
/////////////////////////////////////////////////////////
const UI32			CIns_385_vminle_w::m_id = 385;
const std::string	CIns_385_vminle_w::m_mne("vminle.w");
const UI32			CIns_385_vminle_w::m_numop = 3;
const BS_IPRV		CIns_385_vminle_w::m_priviledge(0x2);
const BS_ICAT		CIns_385_vminle_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_385_vminle_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 386
// Class :: vminlt.h
/////////////////////////////////////////////////////////
const UI32			CIns_386_vminlt_h::m_id = 386;
const std::string	CIns_386_vminlt_h::m_mne("vminlt.h");
const UI32			CIns_386_vminlt_h::m_numop = 3;
const BS_IPRV		CIns_386_vminlt_h::m_priviledge(0x2);
const BS_ICAT		CIns_386_vminlt_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_386_vminlt_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 387
// Class :: vminlt.w
/////////////////////////////////////////////////////////
const UI32			CIns_387_vminlt_w::m_id = 387;
const std::string	CIns_387_vminlt_w::m_mne("vminlt.w");
const UI32			CIns_387_vminlt_w::m_numop = 3;
const BS_IPRV		CIns_387_vminlt_w::m_priviledge(0x2);
const BS_ICAT		CIns_387_vminlt_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_387_vminlt_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 388
// Class :: vmsum.h
/////////////////////////////////////////////////////////
const UI32			CIns_388_vmsum_h::m_id = 388;
const std::string	CIns_388_vmsum_h::m_mne("vmsum.h");
const UI32			CIns_388_vmsum_h::m_numop = 3;
const BS_IPRV		CIns_388_vmsum_h::m_priviledge(0x2);
const BS_ICAT		CIns_388_vmsum_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_388_vmsum_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 389
// Class :: vmsum.w
/////////////////////////////////////////////////////////
const UI32			CIns_389_vmsum_w::m_id = 389;
const std::string	CIns_389_vmsum_w::m_mne("vmsum.w");
const UI32			CIns_389_vmsum_w::m_numop = 3;
const BS_IPRV		CIns_389_vmsum_w::m_priviledge(0x2);
const BS_ICAT		CIns_389_vmsum_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_389_vmsum_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 390
// Class :: vmsumad.h
/////////////////////////////////////////////////////////
const UI32			CIns_390_vmsumad_h::m_id = 390;
const std::string	CIns_390_vmsumad_h::m_mne("vmsumad.h");
const UI32			CIns_390_vmsumad_h::m_numop = 3;
const BS_IPRV		CIns_390_vmsumad_h::m_priviledge(0x2);
const BS_ICAT		CIns_390_vmsumad_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_390_vmsumad_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 391
// Class :: vmsumad.w
/////////////////////////////////////////////////////////
const UI32			CIns_391_vmsumad_w::m_id = 391;
const std::string	CIns_391_vmsumad_w::m_mne("vmsumad.w");
const UI32			CIns_391_vmsumad_w::m_numop = 3;
const BS_IPRV		CIns_391_vmsumad_w::m_priviledge(0x2);
const BS_ICAT		CIns_391_vmsumad_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_391_vmsumad_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 392
// Class :: vmsumadim.h
/////////////////////////////////////////////////////////
const UI32			CIns_392_vmsumadim_h::m_id = 392;
const std::string	CIns_392_vmsumadim_h::m_mne("vmsumadim.h");
const UI32			CIns_392_vmsumadim_h::m_numop = 3;
const BS_IPRV		CIns_392_vmsumadim_h::m_priviledge(0x2);
const BS_ICAT		CIns_392_vmsumadim_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_392_vmsumadim_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 393
// Class :: vmsumadim.w
/////////////////////////////////////////////////////////
const UI32			CIns_393_vmsumadim_w::m_id = 393;
const std::string	CIns_393_vmsumadim_w::m_mne("vmsumadim.w");
const UI32			CIns_393_vmsumadim_w::m_numop = 3;
const BS_IPRV		CIns_393_vmsumadim_w::m_priviledge(0x2);
const BS_ICAT		CIns_393_vmsumadim_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_393_vmsumadim_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 394
// Class :: vmsumadre.h
/////////////////////////////////////////////////////////
const UI32			CIns_394_vmsumadre_h::m_id = 394;
const std::string	CIns_394_vmsumadre_h::m_mne("vmsumadre.h");
const UI32			CIns_394_vmsumadre_h::m_numop = 3;
const BS_IPRV		CIns_394_vmsumadre_h::m_priviledge(0x2);
const BS_ICAT		CIns_394_vmsumadre_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_394_vmsumadre_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 395
// Class :: vmsumadre.w
/////////////////////////////////////////////////////////
const UI32			CIns_395_vmsumadre_w::m_id = 395;
const std::string	CIns_395_vmsumadre_w::m_mne("vmsumadre.w");
const UI32			CIns_395_vmsumadre_w::m_numop = 3;
const BS_IPRV		CIns_395_vmsumadre_w::m_priviledge(0x2);
const BS_ICAT		CIns_395_vmsumadre_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_395_vmsumadre_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 396
// Class :: vmsumadrn.h
/////////////////////////////////////////////////////////
const UI32			CIns_396_vmsumadrn_h::m_id = 396;
const std::string	CIns_396_vmsumadrn_h::m_mne("vmsumadrn.h");
const UI32			CIns_396_vmsumadrn_h::m_numop = 3;
const BS_IPRV		CIns_396_vmsumadrn_h::m_priviledge(0x2);
const BS_ICAT		CIns_396_vmsumadrn_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_396_vmsumadrn_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 397
// Class :: vmsumadrn.w
/////////////////////////////////////////////////////////
const UI32			CIns_397_vmsumadrn_w::m_id = 397;
const std::string	CIns_397_vmsumadrn_w::m_mne("vmsumadrn.w");
const UI32			CIns_397_vmsumadrn_w::m_numop = 3;
const BS_IPRV		CIns_397_vmsumadrn_w::m_priviledge(0x2);
const BS_ICAT		CIns_397_vmsumadrn_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_397_vmsumadrn_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 398
// Class :: vmul.h
/////////////////////////////////////////////////////////
const UI32			CIns_398_vmul_h::m_id = 398;
const std::string	CIns_398_vmul_h::m_mne("vmul.h");
const UI32			CIns_398_vmul_h::m_numop = 3;
const BS_IPRV		CIns_398_vmul_h::m_priviledge(0x2);
const BS_ICAT		CIns_398_vmul_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_398_vmul_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 399
// Class :: vmul.w
/////////////////////////////////////////////////////////
const UI32			CIns_399_vmul_w::m_id = 399;
const std::string	CIns_399_vmul_w::m_mne("vmul.w");
const UI32			CIns_399_vmul_w::m_numop = 3;
const BS_IPRV		CIns_399_vmul_w::m_priviledge(0x2);
const BS_ICAT		CIns_399_vmul_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_399_vmul_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 400
// Class :: vmulcx.h
/////////////////////////////////////////////////////////
const UI32			CIns_400_vmulcx_h::m_id = 400;
const std::string	CIns_400_vmulcx_h::m_mne("vmulcx.h");
const UI32			CIns_400_vmulcx_h::m_numop = 3;
const BS_IPRV		CIns_400_vmulcx_h::m_priviledge(0x2);
const BS_ICAT		CIns_400_vmulcx_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_400_vmulcx_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 401
// Class :: vmulcx.w
/////////////////////////////////////////////////////////
const UI32			CIns_401_vmulcx_w::m_id = 401;
const std::string	CIns_401_vmulcx_w::m_mne("vmulcx.w");
const UI32			CIns_401_vmulcx_w::m_numop = 3;
const BS_IPRV		CIns_401_vmulcx_w::m_priviledge(0x2);
const BS_ICAT		CIns_401_vmulcx_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_401_vmulcx_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 402
// Class :: vmult.h
/////////////////////////////////////////////////////////
const UI32			CIns_402_vmult_h::m_id = 402;
const std::string	CIns_402_vmult_h::m_mne("vmult.h");
const UI32			CIns_402_vmult_h::m_numop = 3;
const BS_IPRV		CIns_402_vmult_h::m_priviledge(0x2);
const BS_ICAT		CIns_402_vmult_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_402_vmult_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 403
// Class :: vmult.w
/////////////////////////////////////////////////////////
const UI32			CIns_403_vmult_w::m_id = 403;
const std::string	CIns_403_vmult_w::m_mne("vmult.w");
const UI32			CIns_403_vmult_w::m_numop = 3;
const BS_IPRV		CIns_403_vmult_w::m_priviledge(0x2);
const BS_ICAT		CIns_403_vmult_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_403_vmult_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 404
// Class :: vneg.h
/////////////////////////////////////////////////////////
const UI32			CIns_404_vneg_h::m_id = 404;
const std::string	CIns_404_vneg_h::m_mne("vneg.h");
const UI32			CIns_404_vneg_h::m_numop = 2;
const BS_IPRV		CIns_404_vneg_h::m_priviledge(0x2);
const BS_ICAT		CIns_404_vneg_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_404_vneg_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 405
// Class :: vneg.w
/////////////////////////////////////////////////////////
const UI32			CIns_405_vneg_w::m_id = 405;
const std::string	CIns_405_vneg_w::m_mne("vneg.w");
const UI32			CIns_405_vneg_w::m_numop = 2;
const BS_IPRV		CIns_405_vneg_w::m_priviledge(0x2);
const BS_ICAT		CIns_405_vneg_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_405_vneg_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 406
// Class :: vnot
/////////////////////////////////////////////////////////
const UI32			CIns_406_vnot::m_id = 406;
const std::string	CIns_406_vnot::m_mne("vnot");
const UI32			CIns_406_vnot::m_numop = 2;
const BS_IPRV		CIns_406_vnot::m_priviledge(0x2);
const BS_ICAT		CIns_406_vnot::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_406_vnot::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 407
// Class :: vor
/////////////////////////////////////////////////////////
const UI32			CIns_407_vor::m_id = 407;
const std::string	CIns_407_vor::m_mne("vor");
const UI32			CIns_407_vor::m_numop = 3;
const BS_IPRV		CIns_407_vor::m_priviledge(0x2);
const BS_ICAT		CIns_407_vor::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_407_vor::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 408
// Class :: vsar.dw
/////////////////////////////////////////////////////////
const UI32			CIns_408_vsar_dw::m_id = 408;
const std::string	CIns_408_vsar_dw::m_mne("vsar.dw");
const UI32			CIns_408_vsar_dw::m_numop = 3;
const BS_IPRV		CIns_408_vsar_dw::m_priviledge(0x2);
const BS_ICAT		CIns_408_vsar_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_408_vsar_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 409
// Class :: vsar.dw
/////////////////////////////////////////////////////////
const UI32			CIns_409_vsar_dw::m_id = 409;
const std::string	CIns_409_vsar_dw::m_mne("vsar.dw");
const UI32			CIns_409_vsar_dw::m_numop = 3;
const BS_IPRV		CIns_409_vsar_dw::m_priviledge(0x2);
const BS_ICAT		CIns_409_vsar_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_409_vsar_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 410
// Class :: vsar.h
/////////////////////////////////////////////////////////
const UI32			CIns_410_vsar_h::m_id = 410;
const std::string	CIns_410_vsar_h::m_mne("vsar.h");
const UI32			CIns_410_vsar_h::m_numop = 3;
const BS_IPRV		CIns_410_vsar_h::m_priviledge(0x2);
const BS_ICAT		CIns_410_vsar_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_410_vsar_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 411
// Class :: vsar.h
/////////////////////////////////////////////////////////
const UI32			CIns_411_vsar_h::m_id = 411;
const std::string	CIns_411_vsar_h::m_mne("vsar.h");
const UI32			CIns_411_vsar_h::m_numop = 3;
const BS_IPRV		CIns_411_vsar_h::m_priviledge(0x2);
const BS_ICAT		CIns_411_vsar_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_411_vsar_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 412
// Class :: vsar.w
/////////////////////////////////////////////////////////
const UI32			CIns_412_vsar_w::m_id = 412;
const std::string	CIns_412_vsar_w::m_mne("vsar.w");
const UI32			CIns_412_vsar_w::m_numop = 3;
const BS_IPRV		CIns_412_vsar_w::m_priviledge(0x2);
const BS_ICAT		CIns_412_vsar_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_412_vsar_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 413
// Class :: vsar.w
/////////////////////////////////////////////////////////
const UI32			CIns_413_vsar_w::m_id = 413;
const std::string	CIns_413_vsar_w::m_mne("vsar.w");
const UI32			CIns_413_vsar_w::m_numop = 3;
const BS_IPRV		CIns_413_vsar_w::m_priviledge(0x2);
const BS_ICAT		CIns_413_vsar_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_413_vsar_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 414
// Class :: vshl.dw
/////////////////////////////////////////////////////////
const UI32			CIns_414_vshl_dw::m_id = 414;
const std::string	CIns_414_vshl_dw::m_mne("vshl.dw");
const UI32			CIns_414_vshl_dw::m_numop = 3;
const BS_IPRV		CIns_414_vshl_dw::m_priviledge(0x2);
const BS_ICAT		CIns_414_vshl_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_414_vshl_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 415
// Class :: vshl.dw
/////////////////////////////////////////////////////////
const UI32			CIns_415_vshl_dw::m_id = 415;
const std::string	CIns_415_vshl_dw::m_mne("vshl.dw");
const UI32			CIns_415_vshl_dw::m_numop = 3;
const BS_IPRV		CIns_415_vshl_dw::m_priviledge(0x2);
const BS_ICAT		CIns_415_vshl_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_415_vshl_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 416
// Class :: vshl.h
/////////////////////////////////////////////////////////
const UI32			CIns_416_vshl_h::m_id = 416;
const std::string	CIns_416_vshl_h::m_mne("vshl.h");
const UI32			CIns_416_vshl_h::m_numop = 3;
const BS_IPRV		CIns_416_vshl_h::m_priviledge(0x2);
const BS_ICAT		CIns_416_vshl_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_416_vshl_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 417
// Class :: vshl.h
/////////////////////////////////////////////////////////
const UI32			CIns_417_vshl_h::m_id = 417;
const std::string	CIns_417_vshl_h::m_mne("vshl.h");
const UI32			CIns_417_vshl_h::m_numop = 3;
const BS_IPRV		CIns_417_vshl_h::m_priviledge(0x2);
const BS_ICAT		CIns_417_vshl_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_417_vshl_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 418
// Class :: vshl.w
/////////////////////////////////////////////////////////
const UI32			CIns_418_vshl_w::m_id = 418;
const std::string	CIns_418_vshl_w::m_mne("vshl.w");
const UI32			CIns_418_vshl_w::m_numop = 3;
const BS_IPRV		CIns_418_vshl_w::m_priviledge(0x2);
const BS_ICAT		CIns_418_vshl_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_418_vshl_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 419
// Class :: vshl.w
/////////////////////////////////////////////////////////
const UI32			CIns_419_vshl_w::m_id = 419;
const std::string	CIns_419_vshl_w::m_mne("vshl.w");
const UI32			CIns_419_vshl_w::m_numop = 3;
const BS_IPRV		CIns_419_vshl_w::m_priviledge(0x2);
const BS_ICAT		CIns_419_vshl_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_419_vshl_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 420
// Class :: vshr.dw
/////////////////////////////////////////////////////////
const UI32			CIns_420_vshr_dw::m_id = 420;
const std::string	CIns_420_vshr_dw::m_mne("vshr.dw");
const UI32			CIns_420_vshr_dw::m_numop = 3;
const BS_IPRV		CIns_420_vshr_dw::m_priviledge(0x2);
const BS_ICAT		CIns_420_vshr_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_420_vshr_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 421
// Class :: vshr.dw
/////////////////////////////////////////////////////////
const UI32			CIns_421_vshr_dw::m_id = 421;
const std::string	CIns_421_vshr_dw::m_mne("vshr.dw");
const UI32			CIns_421_vshr_dw::m_numop = 3;
const BS_IPRV		CIns_421_vshr_dw::m_priviledge(0x2);
const BS_ICAT		CIns_421_vshr_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_421_vshr_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 422
// Class :: vshr.h
/////////////////////////////////////////////////////////
const UI32			CIns_422_vshr_h::m_id = 422;
const std::string	CIns_422_vshr_h::m_mne("vshr.h");
const UI32			CIns_422_vshr_h::m_numop = 3;
const BS_IPRV		CIns_422_vshr_h::m_priviledge(0x2);
const BS_ICAT		CIns_422_vshr_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_422_vshr_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 423
// Class :: vshr.h
/////////////////////////////////////////////////////////
const UI32			CIns_423_vshr_h::m_id = 423;
const std::string	CIns_423_vshr_h::m_mne("vshr.h");
const UI32			CIns_423_vshr_h::m_numop = 3;
const BS_IPRV		CIns_423_vshr_h::m_priviledge(0x2);
const BS_ICAT		CIns_423_vshr_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_423_vshr_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 424
// Class :: vshr.w
/////////////////////////////////////////////////////////
const UI32			CIns_424_vshr_w::m_id = 424;
const std::string	CIns_424_vshr_w::m_mne("vshr.w");
const UI32			CIns_424_vshr_w::m_numop = 3;
const BS_IPRV		CIns_424_vshr_w::m_priviledge(0x2);
const BS_ICAT		CIns_424_vshr_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_424_vshr_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 425
// Class :: vshr.w
/////////////////////////////////////////////////////////
const UI32			CIns_425_vshr_w::m_id = 425;
const std::string	CIns_425_vshr_w::m_mne("vshr.w");
const UI32			CIns_425_vshr_w::m_numop = 3;
const BS_IPRV		CIns_425_vshr_w::m_priviledge(0x2);
const BS_ICAT		CIns_425_vshr_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_425_vshr_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 426
// Class :: vshufl.b
/////////////////////////////////////////////////////////
const UI32			CIns_426_vshufl_b::m_id = 426;
const std::string	CIns_426_vshufl_b::m_mne("vshufl.b");
const UI32			CIns_426_vshufl_b::m_numop = 3;
const BS_IPRV		CIns_426_vshufl_b::m_priviledge(0x2);
const BS_ICAT		CIns_426_vshufl_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_426_vshufl_b::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 427
// Class :: vst.b
/////////////////////////////////////////////////////////
const UI32			CIns_427_vst_b::m_id = 427;
const std::string	CIns_427_vst_b::m_mne("vst.b");
const UI32			CIns_427_vst_b::m_numop = 2;
const BS_IPRV		CIns_427_vst_b::m_priviledge(0x2);
const BS_ICAT		CIns_427_vst_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_427_vst_b::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 428
// Class :: vst.b
/////////////////////////////////////////////////////////
const UI32			CIns_428_vst_b::m_id = 428;
const std::string	CIns_428_vst_b::m_mne("vst.b");
const UI32			CIns_428_vst_b::m_numop = 2;
const BS_IPRV		CIns_428_vst_b::m_priviledge(0x2);
const BS_ICAT		CIns_428_vst_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_428_vst_b::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 429
// Class :: vst.b
/////////////////////////////////////////////////////////
const UI32			CIns_429_vst_b::m_id = 429;
const std::string	CIns_429_vst_b::m_mne("vst.b");
const UI32			CIns_429_vst_b::m_numop = 3;
const BS_IPRV		CIns_429_vst_b::m_priviledge(0x2);
const BS_ICAT		CIns_429_vst_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_429_vst_b::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 430
// Class :: vst.b
/////////////////////////////////////////////////////////
void CIns_430_vst_b::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_430_vst_b::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

const UI32			CIns_430_vst_b::m_id = 430;
const std::string	CIns_430_vst_b::m_mne("vst.b");
const UI32			CIns_430_vst_b::m_numop = 3;
const BS_IPRV		CIns_430_vst_b::m_priviledge(0x2);
const BS_ICAT		CIns_430_vst_b::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_430_vst_b::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 431
// Class :: vst.dw
/////////////////////////////////////////////////////////
const UI32			CIns_431_vst_dw::m_id = 431;
const std::string	CIns_431_vst_dw::m_mne("vst.dw");
const UI32			CIns_431_vst_dw::m_numop = 2;
const BS_IPRV		CIns_431_vst_dw::m_priviledge(0x2);
const BS_ICAT		CIns_431_vst_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_431_vst_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 432
// Class :: vst.dw
/////////////////////////////////////////////////////////
const UI32			CIns_432_vst_dw::m_id = 432;
const std::string	CIns_432_vst_dw::m_mne("vst.dw");
const UI32			CIns_432_vst_dw::m_numop = 2;
const BS_IPRV		CIns_432_vst_dw::m_priviledge(0x2);
const BS_ICAT		CIns_432_vst_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_432_vst_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 433
// Class :: vst.dw
/////////////////////////////////////////////////////////
const UI32			CIns_433_vst_dw::m_id = 433;
const std::string	CIns_433_vst_dw::m_mne("vst.dw");
const UI32			CIns_433_vst_dw::m_numop = 3;
const BS_IPRV		CIns_433_vst_dw::m_priviledge(0x2);
const BS_ICAT		CIns_433_vst_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_433_vst_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 434
// Class :: vst.dw
/////////////////////////////////////////////////////////
void CIns_434_vst_dw::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_434_vst_dw::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

bool CIns_434_vst_dw::RTypeVerify(){

	if(opr(1)->Idx() != opr(2)->Idx())
		return false;
	else{
		UI32 reg2 = opr(2)->Idx();
		for (UI32 i = 2; i < 32; i+=2) {
			if (opr(2)->Replace((reg2 + i) & 0x1f)) {
				break;
			}
		}
		FROG_ASSERT (opr(1)->Idx() != opr(2)->Idx());
	}
	return true;
}

const UI32			CIns_434_vst_dw::m_id = 434;
const std::string	CIns_434_vst_dw::m_mne("vst.dw");
const UI32			CIns_434_vst_dw::m_numop = 3;
const BS_IPRV		CIns_434_vst_dw::m_priviledge(0x2);
const BS_ICAT		CIns_434_vst_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_434_vst_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 435
// Class :: vst.dw
/////////////////////////////////////////////////////////
void CIns_435_vst_dw::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_435_vst_dw::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

const UI32			CIns_435_vst_dw::m_id = 435;
const std::string	CIns_435_vst_dw::m_mne("vst.dw");
const UI32			CIns_435_vst_dw::m_numop = 3;
const BS_IPRV		CIns_435_vst_dw::m_priviledge(0x2);
const BS_ICAT		CIns_435_vst_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_435_vst_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 436
// Class :: vst.dw
/////////////////////////////////////////////////////////
const UI32			CIns_436_vst_dw::m_id = 436;
const std::string	CIns_436_vst_dw::m_mne("vst.dw");
const UI32			CIns_436_vst_dw::m_numop = 2;
const BS_IPRV		CIns_436_vst_dw::m_priviledge(0x2);
const BS_ICAT		CIns_436_vst_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_436_vst_dw::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 437
// Class :: vst.h
/////////////////////////////////////////////////////////
const UI32			CIns_437_vst_h::m_id = 437;
const std::string	CIns_437_vst_h::m_mne("vst.h");
const UI32			CIns_437_vst_h::m_numop = 2;
const BS_IPRV		CIns_437_vst_h::m_priviledge(0x2);
const BS_ICAT		CIns_437_vst_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_437_vst_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 438
// Class :: vst.h
/////////////////////////////////////////////////////////
const UI32			CIns_438_vst_h::m_id = 438;
const std::string	CIns_438_vst_h::m_mne("vst.h");
const UI32			CIns_438_vst_h::m_numop = 2;
const BS_IPRV		CIns_438_vst_h::m_priviledge(0x2);
const BS_ICAT		CIns_438_vst_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_438_vst_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 439
// Class :: vst.h
/////////////////////////////////////////////////////////
const UI32			CIns_439_vst_h::m_id = 439;
const std::string	CIns_439_vst_h::m_mne("vst.h");
const UI32			CIns_439_vst_h::m_numop = 3;
const BS_IPRV		CIns_439_vst_h::m_priviledge(0x2);
const BS_ICAT		CIns_439_vst_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_439_vst_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 440
// Class :: vst.h
/////////////////////////////////////////////////////////
void CIns_440_vst_h::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_440_vst_h::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}


bool CIns_440_vst_h::RTypeVerify(){

	if(opr(1)->Idx() != opr(2)->Idx())
		return false;
	else{
		UI32 reg2 = opr(2)->Idx();
		for (UI32 i = 2; i < 32; i+=2) {
			if (opr(2)->Replace((reg2 + i) & 0x1f)) {
				break;
			}
		}
		FROG_ASSERT (opr(1)->Idx() != opr(2)->Idx());
	}
	return true;
}

const UI32			CIns_440_vst_h::m_id = 440;
const std::string	CIns_440_vst_h::m_mne("vst.h");
const UI32			CIns_440_vst_h::m_numop = 3;
const BS_IPRV		CIns_440_vst_h::m_priviledge(0x2);
const BS_ICAT		CIns_440_vst_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_440_vst_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 441
// Class :: vst.h
/////////////////////////////////////////////////////////
void CIns_441_vst_h::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_441_vst_h::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

const UI32			CIns_441_vst_h::m_id = 441;
const std::string	CIns_441_vst_h::m_mne("vst.h");
const UI32			CIns_441_vst_h::m_numop = 3;
const BS_IPRV		CIns_441_vst_h::m_priviledge(0x2);
const BS_ICAT		CIns_441_vst_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_441_vst_h::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 442
// Class :: vst.w
/////////////////////////////////////////////////////////
const UI32			CIns_442_vst_w::m_id = 442;
const std::string	CIns_442_vst_w::m_mne("vst.w");
const UI32			CIns_442_vst_w::m_numop = 2;
const BS_IPRV		CIns_442_vst_w::m_priviledge(0x2);
const BS_ICAT		CIns_442_vst_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_442_vst_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 443
// Class :: vst.w
/////////////////////////////////////////////////////////
const UI32			CIns_443_vst_w::m_id = 443;
const std::string	CIns_443_vst_w::m_mne("vst.w");
const UI32			CIns_443_vst_w::m_numop = 2;
const BS_IPRV		CIns_443_vst_w::m_priviledge(0x2);
const BS_ICAT		CIns_443_vst_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_443_vst_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 444
// Class :: vst.w
/////////////////////////////////////////////////////////
const UI32			CIns_444_vst_w::m_id = 444;
const std::string	CIns_444_vst_w::m_mne("vst.w");
const UI32			CIns_444_vst_w::m_numop = 3;
const BS_IPRV		CIns_444_vst_w::m_priviledge(0x2);
const BS_ICAT		CIns_444_vst_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_444_vst_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 445
// Class :: vst.w
/////////////////////////////////////////////////////////
void CIns_445_vst_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_445_vst_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}


bool CIns_445_vst_w::RTypeVerify(){

	if(opr(1)->Idx() != opr(2)->Idx())
		return false;
	else{
		UI32 reg2 = opr(2)->Idx();
		for (UI32 i = 2; i < 32; i+=2) {
			if (opr(2)->Replace((reg2 + i) & 0x1f)) {
				break;
			}
		}
		FROG_ASSERT (opr(1)->Idx() != opr(2)->Idx());
	}
	return true;
}
const UI32			CIns_445_vst_w::m_id = 445;
const std::string	CIns_445_vst_w::m_mne("vst.w");
const UI32			CIns_445_vst_w::m_numop = 3;
const BS_IPRV		CIns_445_vst_w::m_priviledge(0x2);
const BS_ICAT		CIns_445_vst_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_445_vst_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 446
// Class :: vst.w
/////////////////////////////////////////////////////////
void CIns_446_vst_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	pReg->m_depends	= opr(2);
	for (UI32 i = 0; i < GetOpNum(); i++) {
		IOperand* popr = opr(i); 
		FROG_ASSERT(popr);
		popr->Regulate(pReg);
	}
}

UI32 CIns_446_vst_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

const UI32			CIns_446_vst_w::m_id = 446;
const std::string	CIns_446_vst_w::m_mne("vst.w");
const UI32			CIns_446_vst_w::m_numop = 3;
const BS_IPRV		CIns_446_vst_w::m_priviledge(0x2);
const BS_ICAT		CIns_446_vst_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_446_vst_w::m_behavior(0x2);



/////////////////////////////////////////////////////////
// InsID :: 447
// Class :: vsub.dw
/////////////////////////////////////////////////////////
const UI32			CIns_447_vsub_dw::m_id = 447;
const std::string	CIns_447_vsub_dw::m_mne("vsub.dw");
const UI32			CIns_447_vsub_dw::m_numop = 3;
const BS_IPRV		CIns_447_vsub_dw::m_priviledge(0x2);
const BS_ICAT		CIns_447_vsub_dw::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_447_vsub_dw::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 448
// Class :: vsub.h
/////////////////////////////////////////////////////////
const UI32			CIns_448_vsub_h::m_id = 448;
const std::string	CIns_448_vsub_h::m_mne("vsub.h");
const UI32			CIns_448_vsub_h::m_numop = 3;
const BS_IPRV		CIns_448_vsub_h::m_priviledge(0x2);
const BS_ICAT		CIns_448_vsub_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_448_vsub_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 449
// Class :: vsub.w
/////////////////////////////////////////////////////////
const UI32			CIns_449_vsub_w::m_id = 449;
const std::string	CIns_449_vsub_w::m_mne("vsub.w");
const UI32			CIns_449_vsub_w::m_numop = 3;
const BS_IPRV		CIns_449_vsub_w::m_priviledge(0x2);
const BS_ICAT		CIns_449_vsub_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_449_vsub_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 450
// Class :: vsubs.h
/////////////////////////////////////////////////////////
const UI32			CIns_450_vsubs_h::m_id = 450;
const std::string	CIns_450_vsubs_h::m_mne("vsubs.h");
const UI32			CIns_450_vsubs_h::m_numop = 3;
const BS_IPRV		CIns_450_vsubs_h::m_priviledge(0x2);
const BS_ICAT		CIns_450_vsubs_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_450_vsubs_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 451
// Class :: vsubs.w
/////////////////////////////////////////////////////////
const UI32			CIns_451_vsubs_w::m_id = 451;
const std::string	CIns_451_vsubs_w::m_mne("vsubs.w");
const UI32			CIns_451_vsubs_w::m_numop = 3;
const BS_IPRV		CIns_451_vsubs_w::m_priviledge(0x2);
const BS_ICAT		CIns_451_vsubs_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_451_vsubs_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 452
// Class :: vsubsat.h
/////////////////////////////////////////////////////////
const UI32			CIns_452_vsubsat_h::m_id = 452;
const std::string	CIns_452_vsubsat_h::m_mne("vsubsat.h");
const UI32			CIns_452_vsubsat_h::m_numop = 3;
const BS_IPRV		CIns_452_vsubsat_h::m_priviledge(0x2);
const BS_ICAT		CIns_452_vsubsat_h::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_452_vsubsat_h::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 453
// Class :: vsubsat.w
/////////////////////////////////////////////////////////
const UI32			CIns_453_vsubsat_w::m_id = 453;
const std::string	CIns_453_vsubsat_w::m_mne("vsubsat.w");
const UI32			CIns_453_vsubsat_w::m_numop = 3;
const BS_IPRV		CIns_453_vsubsat_w::m_priviledge(0x2);
const BS_ICAT		CIns_453_vsubsat_w::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_453_vsubsat_w::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 454
// Class :: vxor
/////////////////////////////////////////////////////////
const UI32			CIns_454_vxor::m_id = 454;
const std::string	CIns_454_vxor::m_mne("vxor");
const UI32			CIns_454_vxor::m_numop = 3;
const BS_IPRV		CIns_454_vxor::m_priviledge(0x2);
const BS_ICAT		CIns_454_vxor::m_category(1 << IInstruction::IF_INS_CAT2);
const BS_IBHV		CIns_454_vxor::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 455
// Class :: .word
/////////////////////////////////////////////////////////
UI32 CIns_455__word::Assemble(UI64* n) {
	// TODO: Implementation yourself here.
	*n = (UI64)(UI32)(*opr(0));
	return 4;
}

std::string CIns_455__word::GetOutCode() {
	UI32 val = (UI32)*opr(0);
	std::stringstream ss;
	
	ss << std::setw(17) << std::left << std::setfill(' ') << m_mne;
	ss << std::hex << "0x" << val;
	return ss.str();
}

const std::string	CIns_455__word::m_mne(".word");
const UI32			CIns_455__word::m_numop = 1;
const BS_IPRV		CIns_455__word::m_priviledge(0x0);
const BS_ICAT		CIns_455__word::m_category(0x180);
const BS_IBHV		CIns_455__word::m_behavior(0x0);



/////////////////////////////////////////////////////////
// InsID :: 456
// Class :: .short
/////////////////////////////////////////////////////////
UI32 CIns_456__short::Assemble(UI64* n) {
	// TODO: Implementation yourself here.
	*n = (UI64)(UI32)(*opr(0));
	return 2;
}

const UI32			CIns_456__short::m_id = 456;
const std::string	CIns_456__short::m_mne(".hword");
const UI32			CIns_456__short::m_numop = 1;
const BS_IPRV		CIns_456__short::m_priviledge(0x0);
const BS_ICAT		CIns_456__short::m_category(0x180);
const BS_IBHV		CIns_456__short::m_behavior(0x0);

//-----------------------------------------------------//
// FP-SIMD
//-----------------------------------------------------//
/////////////////////////////////////////////////////////
// InsID :: 457
// Class :: cmovf.w4
/////////////////////////////////////////////////////////
const UI32			CIns_457_cmovf_w4::m_id = 457;
const std::string	CIns_457_cmovf_w4::m_mne("cmovf.w4");
const UI32			CIns_457_cmovf_w4::m_numop = 4;
const BS_IPRV		CIns_457_cmovf_w4::m_priviledge(0x2);
const BS_ICAT		CIns_457_cmovf_w4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_457_cmovf_w4::m_behavior(0x4000);


/////////////////////////////////////////////////////////
// InsID :: 458
// Class :: movv.w2
/////////////////////////////////////////////////////////
const UI32			CIns_458_movv_w2::m_id = 458;
const std::string	CIns_458_movv_w2::m_mne("movv.w2");
const UI32			CIns_458_movv_w2::m_numop = 2;
const BS_IPRV		CIns_458_movv_w2::m_priviledge(0x2);
const BS_ICAT		CIns_458_movv_w2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_458_movv_w2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 459
// Class :: movv.w4
/////////////////////////////////////////////////////////
const UI32			CIns_459_movv_w4::m_id = 459;
const std::string	CIns_459_movv_w4::m_mne("movv.w4");
const UI32			CIns_459_movv_w4::m_numop = 2;
const BS_IPRV		CIns_459_movv_w4::m_priviledge(0x2);
const BS_ICAT		CIns_459_movv_w4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_459_movv_w4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 460
// Class :: movvg.w
/////////////////////////////////////////////////////////
const UI32			CIns_460_movvg_w::m_id = 460;
const std::string	CIns_460_movvg_w::m_mne("movvg.w");
const UI32			CIns_460_movvg_w::m_numop = 3;
const BS_IPRV		CIns_460_movvg_w::m_priviledge(0x2);
const BS_ICAT		CIns_460_movvg_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_460_movvg_w::m_behavior(0x4016);
#if 0
void CIns_460_movvg_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	//!< ランダム成分を確定させる
	opr(1)->Fix();
	
	// Half時のWR補正
	if( ! CheckMPX4Full() ){
		CheckHalfWrReg(pReg, opr(1) );
	}

}
#endif

/////////////////////////////////////////////////////////
// InsID :: 461
// Class :: movvi
/////////////////////////////////////////////////////////
const UI32			CIns_461_movvi::m_id = 461;
const std::string	CIns_461_movvi::m_mne("movvi");
const UI32			CIns_461_movvi::m_numop = 3;
const BS_IPRV		CIns_461_movvi::m_priviledge(0x2);
const BS_ICAT		CIns_461_movvi::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_461_movvi::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 462
// Class :: flpv.s2
/////////////////////////////////////////////////////////
const UI32			CIns_462_flpv_s2::m_id = 462;
const std::string	CIns_462_flpv_s2::m_mne("flpv.s2");
const UI32			CIns_462_flpv_s2::m_numop = 3;
const BS_IPRV		CIns_462_flpv_s2::m_priviledge(0x2);
const BS_ICAT		CIns_462_flpv_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_462_flpv_s2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 463
// Class :: flpv.s4
/////////////////////////////////////////////////////////
const UI32			CIns_463_flpv_s4::m_id = 463;
const std::string	CIns_463_flpv_s4::m_mne("flpv.s4");
const UI32			CIns_463_flpv_s4::m_numop = 3;
const BS_IPRV		CIns_463_flpv_s4::m_priviledge(0x2);
const BS_ICAT		CIns_463_flpv_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_463_flpv_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 464
// Class :: shflv.w2
/////////////////////////////////////////////////////////
const UI32			CIns_464_shflv_w2::m_id = 464;
const std::string	CIns_464_shflv_w2::m_mne("shflv.w2");
const UI32			CIns_464_shflv_w2::m_numop = 4;
const BS_IPRV		CIns_464_shflv_w2::m_priviledge(0x2);
const BS_ICAT		CIns_464_shflv_w2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_464_shflv_w2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 465
// Class :: shflv.w4
/////////////////////////////////////////////////////////
const UI32			CIns_465_shflv_w4::m_id = 465;
const std::string	CIns_465_shflv_w4::m_mne("shflv.w4");
const UI32			CIns_465_shflv_w4::m_numop = 4;
const BS_IPRV		CIns_465_shflv_w4::m_priviledge(0x2);
const BS_ICAT		CIns_465_shflv_w4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_465_shflv_w4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 466
// Class :: ldv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_466_ldv_dw::m_id = 466;
const std::string	CIns_466_ldv_dw::m_mne("ldv.dw");
const UI32			CIns_466_ldv_dw::m_numop = 3;
const BS_IPRV		CIns_466_ldv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_466_ldv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_466_ldv_dw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 467
// Class :: ldv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_467_ldv_dw::m_id = 467;
const std::string	CIns_467_ldv_dw::m_mne("ldv.dw");
const UI32			CIns_467_ldv_dw::m_numop = 3;
const BS_IPRV		CIns_467_ldv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_467_ldv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_467_ldv_dw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 468
// Class :: ldv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_468_ldv_dw::m_id = 468;
const std::string	CIns_468_ldv_dw::m_mne("ldv.dw");
const UI32			CIns_468_ldv_dw::m_numop = 3;
const BS_IPRV		CIns_468_ldv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_468_ldv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_468_ldv_dw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 469
// Class :: ldv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_469_ldv_dw::m_id = 469;
const std::string	CIns_469_ldv_dw::m_mne("ldv.dw");
const UI32			CIns_469_ldv_dw::m_numop = 3;
const BS_IPRV		CIns_469_ldv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_469_ldv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_469_ldv_dw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 470
// Class :: ldv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_470_ldv_qw::m_id = 470;
const std::string	CIns_470_ldv_qw::m_mne("ldv.qw");
const UI32			CIns_470_ldv_qw::m_numop = 2;
const BS_IPRV		CIns_470_ldv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_470_ldv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_470_ldv_qw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 471
// Class :: ldv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_471_ldv_qw::m_id = 471;
const std::string	CIns_471_ldv_qw::m_mne("ldv.qw");
const UI32			CIns_471_ldv_qw::m_numop = 2;
const BS_IPRV		CIns_471_ldv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_471_ldv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_471_ldv_qw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 472
// Class :: ldv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_472_ldv_qw::m_id = 472;
const std::string	CIns_472_ldv_qw::m_mne("ldv.qw");
const UI32			CIns_472_ldv_qw::m_numop = 2;
const BS_IPRV		CIns_472_ldv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_472_ldv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_472_ldv_qw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 473
// Class :: ldv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_473_ldv_qw::m_id = 473;
const std::string	CIns_473_ldv_qw::m_mne("ldv.qw");
const UI32			CIns_473_ldv_qw::m_numop = 2;
const BS_IPRV		CIns_473_ldv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_473_ldv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_473_ldv_qw::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 474
// Class :: ldv.w
/////////////////////////////////////////////////////////
const UI32			CIns_474_ldv_w::m_id = 474;
const std::string	CIns_474_ldv_w::m_mne("ldv.w");
const UI32			CIns_474_ldv_w::m_numop = 3;
const BS_IPRV		CIns_474_ldv_w::m_priviledge(0x2);
const BS_ICAT		CIns_474_ldv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_474_ldv_w::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 475
// Class :: ldv.w
/////////////////////////////////////////////////////////
const UI32			CIns_475_ldv_w::m_id = 475;
const std::string	CIns_475_ldv_w::m_mne("ldv.w");
const UI32			CIns_475_ldv_w::m_numop = 3;
const BS_IPRV		CIns_475_ldv_w::m_priviledge(0x2);
const BS_ICAT		CIns_475_ldv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_475_ldv_w::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 476
// Class :: ldv.w
/////////////////////////////////////////////////////////
const UI32			CIns_476_ldv_w::m_id = 476;
const std::string	CIns_476_ldv_w::m_mne("ldv.w");
const UI32			CIns_476_ldv_w::m_numop = 3;
const BS_IPRV		CIns_476_ldv_w::m_priviledge(0x2);
const BS_ICAT		CIns_476_ldv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_476_ldv_w::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 477
// Class :: ldv.w
/////////////////////////////////////////////////////////
const UI32			CIns_477_ldv_w::m_id = 477;
const std::string	CIns_477_ldv_w::m_mne("ldv.w");
const UI32			CIns_477_ldv_w::m_numop = 3;
const BS_IPRV		CIns_477_ldv_w::m_priviledge(0x2);
const BS_ICAT		CIns_477_ldv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_477_ldv_w::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 478
// Class :: ldvgtr2.w
/////////////////////////////////////////////////////////
const UI32			CIns_478_ldvgtr2_w::m_id = 478;
const std::string	CIns_478_ldvgtr2_w::m_mne("ldvgtr2.w");
const UI32			CIns_478_ldvgtr2_w::m_numop = 3;
const BS_IPRV		CIns_478_ldvgtr2_w::m_priviledge(0x2);
const BS_ICAT		CIns_478_ldvgtr2_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_478_ldvgtr2_w::m_behavior(0x2016);
void CIns_478_ldvgtr2_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

    UI32 reg0 = opr(0)->Idx();
    UI32 reg1 = opr(1)->Idx();
    if( reg0 == reg1 ) {
        UI32 r = g_rnd.GetRange(reg0+1,reg0+30);
        if( r > 31 ) {
            r = r - 31;
        }
        opr(1)->Replace(r);
    }

	pReg->m_depends	= opr(1);
	IOperand* popr = opr(0); 
	FROG_ASSERT(popr);
	popr->Regulate(pReg);
}

UI32 CIns_478_ldvgtr2_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 479
// Class :: ldvgtr4.w
/////////////////////////////////////////////////////////
const UI32			CIns_479_ldvgtr4_w::m_id = 479;
const std::string	CIns_479_ldvgtr4_w::m_mne("ldvgtr4.w");
const UI32			CIns_479_ldvgtr4_w::m_numop = 3;
const BS_IPRV		CIns_479_ldvgtr4_w::m_priviledge(0x2);
const BS_ICAT		CIns_479_ldvgtr4_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_479_ldvgtr4_w::m_behavior(0x4016);
void CIns_479_ldvgtr4_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

    UI32 reg0 = opr(0)->Idx();
    UI32 reg1 = opr(1)->Idx();
    if( reg0 == reg1 ) {
        UI32 r = g_rnd.GetRange(reg0+1,reg0+30);
        if( r > 31 ) {
            r = r - 31;
        }
        opr(1)->Replace(r);
    }

	pReg->m_depends	= opr(1);
	IOperand* popr = opr(0); 
	FROG_ASSERT(popr);
	popr->Regulate(pReg);
}

UI32 CIns_479_ldvgtr4_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}


/////////////////////////////////////////////////////////
// InsID :: 480
// Class :: ldvpgtr2.w
/////////////////////////////////////////////////////////
const UI32			CIns_480_ldvpgtr2_w::m_id = 480;
const std::string	CIns_480_ldvpgtr2_w::m_mne("ldvpgtr2.w");
const UI32			CIns_480_ldvpgtr2_w::m_numop = 3;
const BS_IPRV		CIns_480_ldvpgtr2_w::m_priviledge(0x2);
const BS_ICAT		CIns_480_ldvpgtr2_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_480_ldvpgtr2_w::m_behavior(0x2016);
void CIns_480_ldvpgtr2_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

    UI32 reg0 = opr(0)->Idx();
    UI32 reg1 = opr(1)->Idx();
    if( reg0 == reg1 ) {
        UI32 r = g_rnd.GetRange(reg0+1,reg0+30);
        if( r > 31 ) {
            r = r - 31;
        }
        opr(1)->Replace(r);
    }

	pReg->m_depends	= opr(1);
	IOperand* popr = opr(0); 
	FROG_ASSERT(popr);
	popr->Regulate(pReg);
}

UI32 CIns_480_ldvpgtr2_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 481
// Class :: ldvpgtr4.w
/////////////////////////////////////////////////////////
const UI32			CIns_481_ldvpgtr4_w::m_id = 481;
const std::string	CIns_481_ldvpgtr4_w::m_mne("ldvpgtr4.w");
const UI32			CIns_481_ldvpgtr4_w::m_numop = 3;
const BS_IPRV		CIns_481_ldvpgtr4_w::m_priviledge(0x2);
const BS_ICAT		CIns_481_ldvpgtr4_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_481_ldvpgtr4_w::m_behavior(0x4016);
void CIns_481_ldvpgtr4_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

    UI32 reg0 = opr(0)->Idx();
    UI32 reg1 = opr(1)->Idx();
    if( reg0 == reg1 ) {
        UI32 r = g_rnd.GetRange(reg0+1,reg0+30);
        if( r > 31 ) {
            r = r - 31;
        }
        opr(1)->Replace(r);
    }

	pReg->m_depends	= opr(1);
	IOperand* popr = opr(0); 
	FROG_ASSERT(popr);
	popr->Regulate(pReg);
}

UI32 CIns_481_ldvpgtr4_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(0)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(0)->Idx());
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 482
// Class :: ldvz.h1
/////////////////////////////////////////////////////////
const UI32			CIns_482_ldvz_h1::m_id = 482;
const std::string	CIns_482_ldvz_h1::m_mne("ldvz.h1");
const UI32			CIns_482_ldvz_h1::m_numop = 2;
const BS_IPRV		CIns_482_ldvz_h1::m_priviledge(0x2);
const BS_ICAT		CIns_482_ldvz_h1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_482_ldvz_h1::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 483
// Class :: ldvz.h2
/////////////////////////////////////////////////////////
const UI32			CIns_483_ldvz_h2::m_id = 483;
const std::string	CIns_483_ldvz_h2::m_mne("ldvz.h2");
const UI32			CIns_483_ldvz_h2::m_numop = 2;
const BS_IPRV		CIns_483_ldvz_h2::m_priviledge(0x2);
const BS_ICAT		CIns_483_ldvz_h2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_483_ldvz_h2::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 484
// Class :: ldvz.h4
/////////////////////////////////////////////////////////
const UI32			CIns_484_ldvz_h4::m_id = 484;
const std::string	CIns_484_ldvz_h4::m_mne("ldvz.h4");
const UI32			CIns_484_ldvz_h4::m_numop = 2;
const BS_IPRV		CIns_484_ldvz_h4::m_priviledge(0x2);
const BS_ICAT		CIns_484_ldvz_h4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_484_ldvz_h4::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 485
// Class :: ldvz.h1
/////////////////////////////////////////////////////////
const UI32			CIns_485_ldvz_h1::m_id = 485;
const std::string	CIns_485_ldvz_h1::m_mne("ldvz.h1");
const UI32			CIns_485_ldvz_h1::m_numop = 2;
const BS_IPRV		CIns_485_ldvz_h1::m_priviledge(0x2);
const BS_ICAT		CIns_485_ldvz_h1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_485_ldvz_h1::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 486
// Class :: ldvz.h2
/////////////////////////////////////////////////////////
const UI32			CIns_486_ldvz_h2::m_id = 486;
const std::string	CIns_486_ldvz_h2::m_mne("ldvz.h2");
const UI32			CIns_486_ldvz_h2::m_numop = 2;
const BS_IPRV		CIns_486_ldvz_h2::m_priviledge(0x2);
const BS_ICAT		CIns_486_ldvz_h2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_486_ldvz_h2::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 487
// Class :: ldvz.h4
/////////////////////////////////////////////////////////
const UI32			CIns_487_ldvz_h4::m_id = 487;
const std::string	CIns_487_ldvz_h4::m_mne("ldvz.h4");
const UI32			CIns_487_ldvz_h4::m_numop = 2;
const BS_IPRV		CIns_487_ldvz_h4::m_priviledge(0x2);
const BS_ICAT		CIns_487_ldvz_h4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_487_ldvz_h4::m_behavior(0x4001);

/////////////////////////////////////////////////////////
// InsID :: 488
// Class :: stv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_488_stv_dw::m_id = 488;
const std::string	CIns_488_stv_dw::m_mne("stv.dw");
const UI32			CIns_488_stv_dw::m_numop = 3;
const BS_IPRV		CIns_488_stv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_488_stv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_488_stv_dw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 489
// Class :: stv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_489_stv_dw::m_id = 489;
const std::string	CIns_489_stv_dw::m_mne("stv.dw");
const UI32			CIns_489_stv_dw::m_numop = 3;
const BS_IPRV		CIns_489_stv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_489_stv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_489_stv_dw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 490
// Class :: stv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_490_stv_dw::m_id = 490;
const std::string	CIns_490_stv_dw::m_mne("stv.dw");
const UI32			CIns_490_stv_dw::m_numop = 3;
const BS_IPRV		CIns_490_stv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_490_stv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_490_stv_dw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 491
// Class :: stv.dw
/////////////////////////////////////////////////////////
const UI32			CIns_491_stv_dw::m_id = 491;
const std::string	CIns_491_stv_dw::m_mne("stv.dw");
const UI32			CIns_491_stv_dw::m_numop = 3;
const BS_IPRV		CIns_491_stv_dw::m_priviledge(0x2);
const BS_ICAT		CIns_491_stv_dw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_491_stv_dw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 492
// Class :: stv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_492_stv_qw::m_id = 492;
const std::string	CIns_492_stv_qw::m_mne("stv.qw");
const UI32			CIns_492_stv_qw::m_numop = 2;
const BS_IPRV		CIns_492_stv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_492_stv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_492_stv_qw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 493
// Class :: stv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_493_stv_qw::m_id = 493;
const std::string	CIns_493_stv_qw::m_mne("stv.qw");
const UI32			CIns_493_stv_qw::m_numop = 2;
const BS_IPRV		CIns_493_stv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_493_stv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_493_stv_qw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 494
// Class :: stv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_494_stv_qw::m_id = 494;
const std::string	CIns_494_stv_qw::m_mne("stv.qw");
const UI32			CIns_494_stv_qw::m_numop = 2;
const BS_IPRV		CIns_494_stv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_494_stv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_494_stv_qw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 495
// Class :: stv.qw
/////////////////////////////////////////////////////////
const UI32			CIns_495_stv_qw::m_id = 495;
const std::string	CIns_495_stv_qw::m_mne("stv.qw");
const UI32			CIns_495_stv_qw::m_numop = 2;
const BS_IPRV		CIns_495_stv_qw::m_priviledge(0x2);
const BS_ICAT		CIns_495_stv_qw::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_495_stv_qw::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 496
// Class :: stv.w
/////////////////////////////////////////////////////////
const UI32			CIns_496_stv_w::m_id = 496;
const std::string	CIns_496_stv_w::m_mne("stv.w");
const UI32			CIns_496_stv_w::m_numop = 3;
const BS_IPRV		CIns_496_stv_w::m_priviledge(0x2);
const BS_ICAT		CIns_496_stv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_496_stv_w::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 497
// Class :: stv.w
/////////////////////////////////////////////////////////
const UI32			CIns_497_stv_w::m_id = 497;
const std::string	CIns_497_stv_w::m_mne("stv.w");
const UI32			CIns_497_stv_w::m_numop = 3;
const BS_IPRV		CIns_497_stv_w::m_priviledge(0x2);
const BS_ICAT		CIns_497_stv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_497_stv_w::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 498
// Class :: stv.w
/////////////////////////////////////////////////////////
const UI32			CIns_498_stv_w::m_id = 498;
const std::string	CIns_498_stv_w::m_mne("stv.w");
const UI32			CIns_498_stv_w::m_numop = 3;
const BS_IPRV		CIns_498_stv_w::m_priviledge(0x2);
const BS_ICAT		CIns_498_stv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_498_stv_w::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 499
// Class :: stv.w
/////////////////////////////////////////////////////////
const UI32			CIns_499_stv_w::m_id = 499;
const std::string	CIns_499_stv_w::m_mne("stv.w");
const UI32			CIns_499_stv_w::m_numop = 3;
const BS_IPRV		CIns_499_stv_w::m_priviledge(0x2);
const BS_ICAT		CIns_499_stv_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_499_stv_w::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 500
// Class :: stvpsct2.w
/////////////////////////////////////////////////////////
const UI32			CIns_500_stvpsct2_w::m_id = 500;
const std::string	CIns_500_stvpsct2_w::m_mne("stvpsct2.w");
const UI32			CIns_500_stvpsct2_w::m_numop = 3;
const BS_IPRV		CIns_500_stvpsct2_w::m_priviledge(0x2);
const BS_ICAT		CIns_500_stvpsct2_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_500_stvpsct2_w::m_behavior(0x2016);
void CIns_500_stvpsct2_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	//!< ランダム成分を確定させる
	opr(1)->Fix();
	opr(2)->Fix();
	
	// Load protection info
	SCorrection(pReg, opr(1), opr(2) ,2);

}

UI32 CIns_500_stvpsct2_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 501
// Class :: stvpsct4.w
/////////////////////////////////////////////////////////
const UI32			CIns_501_stvpsct4_w::m_id = 501;
const std::string	CIns_501_stvpsct4_w::m_mne("stvpsct4.w");
const UI32			CIns_501_stvpsct4_w::m_numop = 3;
const BS_IPRV		CIns_501_stvpsct4_w::m_priviledge(0x2);
const BS_ICAT		CIns_501_stvpsct4_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_501_stvpsct4_w::m_behavior(0x4016);
void CIns_501_stvpsct4_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	//!< ランダム成分を確定させる
	opr(1)->Fix();
	opr(2)->Fix();
	
	// Load protection info
	SCorrection(pReg, opr(1), opr(2) ,4);

}

UI32 CIns_501_stvpsct4_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 502
// Class :: stvsct2.w
/////////////////////////////////////////////////////////
const UI32			CIns_502_stvsct2_w::m_id = 502;
const std::string	CIns_502_stvsct2_w::m_mne("stvsct2.w");
const UI32			CIns_502_stvsct2_w::m_numop = 3;
const BS_IPRV		CIns_502_stvsct2_w::m_priviledge(0x2);
const BS_ICAT		CIns_502_stvsct2_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_502_stvsct2_w::m_behavior(0x2016);
void CIns_502_stvsct2_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	//!< ランダム成分を確定させる
	opr(1)->Fix();
	opr(2)->Fix();
	
	// Load protection info
	SCorrection(pReg, opr(1), opr(2) ,2);

}

UI32 CIns_502_stvsct2_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 503
// Class :: stvsct4.w
/////////////////////////////////////////////////////////
const UI32			CIns_503_stvsct4_w::m_id = 503;
const std::string	CIns_503_stvsct4_w::m_mne("stvsct4.w");
const UI32			CIns_503_stvsct4_w::m_numop = 3;
const BS_IPRV		CIns_503_stvsct4_w::m_priviledge(0x2);
const BS_ICAT		CIns_503_stvsct4_w::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_503_stvsct4_w::m_behavior(0x4016);
void CIns_503_stvsct4_w::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);

	//!< ランダム成分を確定させる
	opr(1)->Fix();
	opr(2)->Fix();
	
	// Load protection info
	SCorrection(pReg, opr(1), opr(2) ,4);

}

UI32 CIns_503_stvsct4_w::GetConstraintBit() {

	UI32 UseOpr = 0;
	UseOpr |= (opr(1)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(1)->Idx());
	UseOpr |= (opr(2)->Attr(IOperand::OPR_ATTR_PAIR) ? 3 : 1) << (opr(2)->Idx());

	return UseOpr;
}

/////////////////////////////////////////////////////////
// InsID :: 504
// Class :: stvz.h1
/////////////////////////////////////////////////////////
const UI32			CIns_504_stvz_h1::m_id = 504;
const std::string	CIns_504_stvz_h1::m_mne("stvz.h1");
const UI32			CIns_504_stvz_h1::m_numop = 2;
const BS_IPRV		CIns_504_stvz_h1::m_priviledge(0x2);
const BS_ICAT		CIns_504_stvz_h1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_504_stvz_h1::m_behavior(0x1016);

/////////////////////////////////////////////////////////
// InsID :: 505
// Class :: stvz.h2
/////////////////////////////////////////////////////////
const UI32			CIns_505_stvz_h2::m_id = 505;
const std::string	CIns_505_stvz_h2::m_mne("stvz.h2");
const UI32			CIns_505_stvz_h2::m_numop = 2;
const BS_IPRV		CIns_505_stvz_h2::m_priviledge(0x2);
const BS_ICAT		CIns_505_stvz_h2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_505_stvz_h2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 506
// Class :: stvz.h4
/////////////////////////////////////////////////////////
const UI32			CIns_506_stvz_h4::m_id = 506;
const std::string	CIns_506_stvz_h4::m_mne("stvz.h4");
const UI32			CIns_506_stvz_h4::m_numop = 2;
const BS_IPRV		CIns_506_stvz_h4::m_priviledge(0x2);
const BS_ICAT		CIns_506_stvz_h4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_506_stvz_h4::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 507
// Class :: stvz.h1
/////////////////////////////////////////////////////////
const UI32			CIns_507_stvz_h1::m_id = 507;
const std::string	CIns_507_stvz_h1::m_mne("stvz.h1");
const UI32			CIns_507_stvz_h1::m_numop = 2;
const BS_IPRV		CIns_507_stvz_h1::m_priviledge(0x2);
const BS_ICAT		CIns_507_stvz_h1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_507_stvz_h1::m_behavior(0x1016);

/////////////////////////////////////////////////////////
// InsID :: 508
// Class :: stvz.h2
/////////////////////////////////////////////////////////
const UI32			CIns_508_stvz_h2::m_id = 508;
const std::string	CIns_508_stvz_h2::m_mne("stvz.h2");
const UI32			CIns_508_stvz_h2::m_numop = 2;
const BS_IPRV		CIns_508_stvz_h2::m_priviledge(0x2);
const BS_ICAT		CIns_508_stvz_h2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_508_stvz_h2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 509
// Class :: stvz.h4
/////////////////////////////////////////////////////////
const UI32			CIns_509_stvz_h4::m_id = 509;
const std::string	CIns_509_stvz_h4::m_mne("stvz.h4");
const UI32			CIns_509_stvz_h4::m_numop = 2;
const BS_IPRV		CIns_509_stvz_h4::m_priviledge(0x2);
const BS_ICAT		CIns_509_stvz_h4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_509_stvz_h4::m_behavior(0x4002);

/////////////////////////////////////////////////////////
// InsID :: 510
// Class :: cmov.w1
/////////////////////////////////////////////////////////
const UI32			CIns_510_cmov_w1::m_id = 510;
const std::string	CIns_510_cmov_w1::m_mne("cmov.w1");
const UI32			CIns_510_cmov_w1::m_numop = 4;
const BS_IPRV		CIns_510_cmov_w1::m_priviledge(0x2);
const BS_ICAT		CIns_510_cmov_w1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_510_cmov_w1::m_behavior(0x1016);

/////////////////////////////////////////////////////////
// InsID :: 511
// Class :: cmov.w2
/////////////////////////////////////////////////////////
const UI32			CIns_511_cmov_w2::m_id = 511;
const std::string	CIns_511_cmov_w2::m_mne("cmov.w2");
const UI32			CIns_511_cmov_w2::m_numop = 4;
const BS_IPRV		CIns_511_cmov_w2::m_priviledge(0x2);
const BS_ICAT		CIns_511_cmov_w2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_511_cmov_w2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 512
// Class :: cmov.w4
/////////////////////////////////////////////////////////
const UI32			CIns_512_cmov_w4::m_id = 512;
const std::string	CIns_512_cmov_w4::m_mne("cmov.w4");
const UI32			CIns_512_cmov_w4::m_numop = 4;
const BS_IPRV		CIns_512_cmov_w4::m_priviledge(0x2);
const BS_ICAT		CIns_512_cmov_w4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_512_cmov_w4::m_behavior(0x4016);

/////////////////////////////////////////////////////////
// InsID :: 513
// Class :: trfsrv.w2
/////////////////////////////////////////////////////////
const UI32			CIns_513_trfsrv_w2::m_id = 513;
const std::string	CIns_513_trfsrv_w2::m_mne("trfsrv.w2");
const UI32			CIns_513_trfsrv_w2::m_numop = 2;
const BS_IPRV		CIns_513_trfsrv_w2::m_priviledge(0x2);
const BS_ICAT		CIns_513_trfsrv_w2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_513_trfsrv_w2::m_behavior(0x2016);

/////////////////////////////////////////////////////////
// InsID :: 514
// Class :: trfsrv.w4
/////////////////////////////////////////////////////////
const UI32			CIns_514_trfsrv_w4::m_id = 514;
const std::string	CIns_514_trfsrv_w4::m_mne("trfsrv.w4");
const UI32			CIns_514_trfsrv_w4::m_numop = 2;
const BS_IPRV		CIns_514_trfsrv_w4::m_priviledge(0x2);
const BS_ICAT		CIns_514_trfsrv_w4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_514_trfsrv_w4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 515
// Class :: absf.s1
/////////////////////////////////////////////////////////
const UI32		CIns_515_absf_s1::m_id = 515;
const std::string	CIns_515_absf_s1::m_mne("absf.s1");
const UI32		CIns_515_absf_s1::m_numop = 2;
const BS_IPRV		CIns_515_absf_s1::m_priviledge(0x2);
const BS_ICAT		CIns_515_absf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_515_absf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 516
// Class :: absf.s2
/////////////////////////////////////////////////////////
const UI32		CIns_516_absf_s2::m_id = 516;
const std::string	CIns_516_absf_s2::m_mne("absf.s2");
const UI32		CIns_516_absf_s2::m_numop = 2;
const BS_IPRV		CIns_516_absf_s2::m_priviledge(0x2);
const BS_ICAT		CIns_516_absf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_516_absf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 517
// Class :: absf.s4
/////////////////////////////////////////////////////////
const UI32		CIns_517_absf_s4::m_id = 517;
const std::string	CIns_517_absf_s4::m_mne("absf.s4");
const UI32		CIns_517_absf_s4::m_numop = 2;
const BS_IPRV		CIns_517_absf_s4::m_priviledge(0x2);
const BS_ICAT		CIns_517_absf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_517_absf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 518
// Class :: addf.s1
/////////////////////////////////////////////////////////
const UI32		CIns_518_addf_s1::m_id = 518;
const std::string	CIns_518_addf_s1::m_mne("addf.s1");
const UI32		CIns_518_addf_s1::m_numop = 3;
const BS_IPRV		CIns_518_addf_s1::m_priviledge(0x2);
const BS_ICAT		CIns_518_addf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_518_addf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 519
// Class :: addf.s2
/////////////////////////////////////////////////////////
const UI32		CIns_519_addf_s2::m_id = 519;
const std::string	CIns_519_addf_s2::m_mne("addf.s2");
const UI32		CIns_519_addf_s2::m_numop = 3;
const BS_IPRV		CIns_519_addf_s2::m_priviledge(0x2);
const BS_ICAT		CIns_519_addf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_519_addf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 520
// Class :: addf.s4
/////////////////////////////////////////////////////////
const UI32		CIns_520_addf_s4::m_id = 520;
const std::string	CIns_520_addf_s4::m_mne("addf.s4");
const UI32		CIns_520_addf_s4::m_numop = 3;
const BS_IPRV		CIns_520_addf_s4::m_priviledge(0x2);
const BS_ICAT		CIns_520_addf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_520_addf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 521
// Class :: divf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_521_divf_s1::m_id = 521;
const std::string       CIns_521_divf_s1::m_mne("divf.s1");
const UI32              CIns_521_divf_s1::m_numop = 3;
const BS_IPRV           CIns_521_divf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_521_divf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_521_divf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 522
// Class :: divf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_522_divf_s2::m_id = 522;
const std::string       CIns_522_divf_s2::m_mne("divf.s2");
const UI32              CIns_522_divf_s2::m_numop = 3;
const BS_IPRV           CIns_522_divf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_522_divf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_522_divf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 523
// Class :: divf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_523_divf_s4::m_id = 523;
const std::string       CIns_523_divf_s4::m_mne("divf.s4");
const UI32              CIns_523_divf_s4::m_numop = 3;
const BS_IPRV           CIns_523_divf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_523_divf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_523_divf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 524
// Class :: maxf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_524_maxf_s1::m_id = 524;
const std::string       CIns_524_maxf_s1::m_mne("maxf.s1");
const UI32              CIns_524_maxf_s1::m_numop = 3;
const BS_IPRV           CIns_524_maxf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_524_maxf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_524_maxf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 525
// Class :: maxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_525_maxf_s2::m_id = 525;
const std::string       CIns_525_maxf_s2::m_mne("maxf.s2");
const UI32              CIns_525_maxf_s2::m_numop = 3;
const BS_IPRV           CIns_525_maxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_525_maxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_525_maxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 526
// Class :: maxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_526_maxf_s4::m_id = 526;
const std::string       CIns_526_maxf_s4::m_mne("maxf.s4");
const UI32              CIns_526_maxf_s4::m_numop = 3;
const BS_IPRV           CIns_526_maxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_526_maxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_526_maxf_s4::m_behavior(0x4000);


/////////////////////////////////////////////////////////
// InsID :: 527
// Class :: minf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_527_minf_s1::m_id = 527;
const std::string       CIns_527_minf_s1::m_mne("minf.s1");
const UI32              CIns_527_minf_s1::m_numop = 3;
const BS_IPRV           CIns_527_minf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_527_minf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_527_minf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 528
// Class :: minf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_528_minf_s2::m_id = 528;
const std::string       CIns_528_minf_s2::m_mne("minf.s2");
const UI32              CIns_528_minf_s2::m_numop = 3;
const BS_IPRV           CIns_528_minf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_528_minf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_528_minf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 529
// Class :: minf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_529_minf_s4::m_id = 529;
const std::string       CIns_529_minf_s4::m_mne("minf.s4");
const UI32              CIns_529_minf_s4::m_numop = 3;
const BS_IPRV           CIns_529_minf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_529_minf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_529_minf_s4::m_behavior(0x4000);
 
/////////////////////////////////////////////////////////
// InsID :: 530
// Class :: mulf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_530_mulf_s1::m_id = 530;
const std::string       CIns_530_mulf_s1::m_mne("mulf.s1");
const UI32              CIns_530_mulf_s1::m_numop = 3;
const BS_IPRV           CIns_530_mulf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_530_mulf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_530_mulf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 531
// Class :: mulf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_531_mulf_s2::m_id = 531;
const std::string       CIns_531_mulf_s2::m_mne("mulf.s2");
const UI32              CIns_531_mulf_s2::m_numop = 3;
const BS_IPRV           CIns_531_mulf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_531_mulf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_531_mulf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 532
// Class :: mulf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_532_mulf_s4::m_id = 532;
const std::string       CIns_532_mulf_s4::m_mne("mulf.s4");
const UI32              CIns_532_mulf_s4::m_numop = 3;
const BS_IPRV           CIns_532_mulf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_532_mulf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_532_mulf_s4::m_behavior(0x4000);


/////////////////////////////////////////////////////////
// InsID :: 533
// Class :: negf.s1
/////////////////////////////////////////////////////////
const UI32		CIns_533_negf_s1::m_id = 533;
const std::string	CIns_533_negf_s1::m_mne("negf.s1");
const UI32		CIns_533_negf_s1::m_numop = 2;
const BS_IPRV		CIns_533_negf_s1::m_priviledge(0x2);
const BS_ICAT		CIns_533_negf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_533_negf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 534
// Class :: negf.s2
/////////////////////////////////////////////////////////
const UI32		CIns_534_negf_s2::m_id = 534;
const std::string	CIns_534_negf_s2::m_mne("negf.s2");
const UI32		CIns_534_negf_s2::m_numop = 2;
const BS_IPRV		CIns_534_negf_s2::m_priviledge(0x2);
const BS_ICAT		CIns_534_negf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_534_negf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 535
// Class :: negf.s4
/////////////////////////////////////////////////////////
const UI32		CIns_535_negf_s4::m_id = 535;
const std::string	CIns_535_negf_s4::m_mne("negf.s4");
const UI32		CIns_535_negf_s4::m_numop = 2;
const BS_IPRV		CIns_535_negf_s4::m_priviledge(0x2);
const BS_ICAT		CIns_535_negf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_535_negf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 536
// Class :: recipf.s1
/////////////////////////////////////////////////////////
const UI32		CIns_536_recipf_s1::m_id = 536;
const std::string	CIns_536_recipf_s1::m_mne("recipf.s1");
const UI32		CIns_536_recipf_s1::m_numop = 2;
const BS_IPRV		CIns_536_recipf_s1::m_priviledge(0x2);
const BS_ICAT		CIns_536_recipf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_536_recipf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 537
// Class :: recipf.s2
/////////////////////////////////////////////////////////
const UI32		CIns_537_recipf_s2::m_id = 537;
const std::string	CIns_537_recipf_s2::m_mne("recipf.s2");
const UI32		CIns_537_recipf_s2::m_numop = 2;
const BS_IPRV		CIns_537_recipf_s2::m_priviledge(0x2);
const BS_ICAT		CIns_537_recipf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_537_recipf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 538
// Class :: recipf.s4
/////////////////////////////////////////////////////////
const UI32		CIns_538_recipf_s4::m_id = 538;
const std::string	CIns_538_recipf_s4::m_mne("recipf.s4");
const UI32		CIns_538_recipf_s4::m_numop = 2;
const BS_IPRV		CIns_538_recipf_s4::m_priviledge(0x2);
const BS_ICAT		CIns_538_recipf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_538_recipf_s4::m_behavior(0x4000);


/////////////////////////////////////////////////////////
// InsID :: 539
// Class :: rsqrtf.s1
/////////////////////////////////////////////////////////
const UI32		CIns_539_rsqrtf_s1::m_id = 539;
const std::string	CIns_539_rsqrtf_s1::m_mne("rsqrtf.s1");
const UI32		CIns_539_rsqrtf_s1::m_numop = 2;
const BS_IPRV		CIns_539_rsqrtf_s1::m_priviledge(0x2);
const BS_ICAT		CIns_539_rsqrtf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_539_rsqrtf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 540
// Class :: rsqrtf.s2
/////////////////////////////////////////////////////////
const UI32		CIns_540_rsqrtf_s2::m_id = 540;
const std::string	CIns_540_rsqrtf_s2::m_mne("rsqrtf.s2");
const UI32		CIns_540_rsqrtf_s2::m_numop = 2;
const BS_IPRV		CIns_540_rsqrtf_s2::m_priviledge(0x2);
const BS_ICAT		CIns_540_rsqrtf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_540_rsqrtf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 541
// Class :: rsqrtf.s4
/////////////////////////////////////////////////////////
const UI32		CIns_541_rsqrtf_s4::m_id = 541;
const std::string	CIns_541_rsqrtf_s4::m_mne("rsqrtf.s4");
const UI32		CIns_541_rsqrtf_s4::m_numop = 2;
const BS_IPRV		CIns_541_rsqrtf_s4::m_priviledge(0x2);
const BS_ICAT		CIns_541_rsqrtf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_541_rsqrtf_s4::m_behavior(0x4000);


/////////////////////////////////////////////////////////
// InsID :: 542
// Class :: sqrtf.s1
/////////////////////////////////////////////////////////
const UI32		CIns_542_sqrtf_s1::m_id = 542;
const std::string	CIns_542_sqrtf_s1::m_mne("sqrtf.s1");
const UI32		CIns_542_sqrtf_s1::m_numop = 2;
const BS_IPRV		CIns_542_sqrtf_s1::m_priviledge(0x2);
const BS_ICAT		CIns_542_sqrtf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_542_sqrtf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 543
// Class :: sqrtf.s2
/////////////////////////////////////////////////////////
const UI32		CIns_543_sqrtf_s2::m_id = 543;
const std::string	CIns_543_sqrtf_s2::m_mne("sqrtf.s2");
const UI32		CIns_543_sqrtf_s2::m_numop = 2;
const BS_IPRV		CIns_543_sqrtf_s2::m_priviledge(0x2);
const BS_ICAT		CIns_543_sqrtf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_543_sqrtf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 544
// Class :: sqrtf.s4
/////////////////////////////////////////////////////////
const UI32		CIns_544_sqrtf_s4::m_id = 544;
const std::string	CIns_544_sqrtf_s4::m_mne("sqrtf.s4");
const UI32		CIns_544_sqrtf_s4::m_numop = 2;
const BS_IPRV		CIns_544_sqrtf_s4::m_priviledge(0x2);
const BS_ICAT		CIns_544_sqrtf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_544_sqrtf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 545
// Class :: subf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_545_subf_s1::m_id = 545;
const std::string       CIns_545_subf_s1::m_mne("subf.s1");
const UI32              CIns_545_subf_s1::m_numop = 3;
const BS_IPRV           CIns_545_subf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_545_subf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_545_subf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 546
// Class :: subf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_546_subf_s2::m_id = 546;
const std::string       CIns_546_subf_s2::m_mne("subf.s2");
const UI32              CIns_546_subf_s2::m_numop = 3;
const BS_IPRV           CIns_546_subf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_546_subf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_546_subf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 547
// Class :: subf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_547_subf_s4::m_id = 547;
const std::string       CIns_547_subf_s4::m_mne("subf.s4");
const UI32              CIns_547_subf_s4::m_numop = 3;
const BS_IPRV           CIns_547_subf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_547_subf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_547_subf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 548
// Class :: fmaf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_548_fmaf_s1::m_id = 548;
const std::string       CIns_548_fmaf_s1::m_mne("fmaf.s1");
const UI32              CIns_548_fmaf_s1::m_numop = 3;
const BS_IPRV           CIns_548_fmaf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_548_fmaf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_548_fmaf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 549
// Class :: fmaf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_549_fmaf_s2::m_id = 549;
const std::string       CIns_549_fmaf_s2::m_mne("fmaf.s2");
const UI32              CIns_549_fmaf_s2::m_numop = 3;
const BS_IPRV           CIns_549_fmaf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_549_fmaf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_549_fmaf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 550
// Class :: fmaf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_550_fmaf_s4::m_id = 550;
const std::string       CIns_550_fmaf_s4::m_mne("fmaf.s4");
const UI32              CIns_550_fmaf_s4::m_numop = 3;
const BS_IPRV           CIns_550_fmaf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_550_fmaf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_550_fmaf_s4::m_behavior(0x4000);


/////////////////////////////////////////////////////////
// InsID :: 551
// Class :: fmsf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_551_fmsf_s1::m_id = 551;
const std::string       CIns_551_fmsf_s1::m_mne("fmsf.s1");
const UI32              CIns_551_fmsf_s1::m_numop = 3;
const BS_IPRV           CIns_551_fmsf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_551_fmsf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_551_fmsf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 552
// Class :: fmsf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_552_fmsf_s2::m_id = 552;
const std::string       CIns_552_fmsf_s2::m_mne("fmsf.s2");
const UI32              CIns_552_fmsf_s2::m_numop = 3;
const BS_IPRV           CIns_552_fmsf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_552_fmsf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_552_fmsf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 553
// Class :: fmsf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_553_fmsf_s4::m_id = 553;
const std::string       CIns_553_fmsf_s4::m_mne("fmsf.s4");
const UI32              CIns_553_fmsf_s4::m_numop = 3;
const BS_IPRV           CIns_553_fmsf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_553_fmsf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_553_fmsf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 554
// Class :: fnmaf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_554_fnmaf_s1::m_id = 554;
const std::string       CIns_554_fnmaf_s1::m_mne("fnmaf.s1");
const UI32              CIns_554_fnmaf_s1::m_numop = 3;
const BS_IPRV           CIns_554_fnmaf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_554_fnmaf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_554_fnmaf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 555
// Class :: fnmaf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_555_fnmaf_s2::m_id = 555;
const std::string       CIns_555_fnmaf_s2::m_mne("fnmaf.s2");
const UI32              CIns_555_fnmaf_s2::m_numop = 3;
const BS_IPRV           CIns_555_fnmaf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_555_fnmaf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_555_fnmaf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 556
// Class :: fnmaf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_556_fnmaf_s4::m_id = 556;
const std::string       CIns_556_fnmaf_s4::m_mne("fnmaf.s4");
const UI32              CIns_556_fnmaf_s4::m_numop = 3;
const BS_IPRV           CIns_556_fnmaf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_556_fnmaf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_556_fnmaf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 557
// Class :: fnmsf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_557_fnmsf_s1::m_id = 557;
const std::string       CIns_557_fnmsf_s1::m_mne("fnmsf.s1");
const UI32              CIns_557_fnmsf_s1::m_numop = 3;
const BS_IPRV           CIns_557_fnmsf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_557_fnmsf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_557_fnmsf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 558
// Class :: fnmsf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_558_fnmsf_s2::m_id = 558;
const std::string       CIns_558_fnmsf_s2::m_mne("fnmsf.s2");
const UI32              CIns_558_fnmsf_s2::m_numop = 3;
const BS_IPRV           CIns_558_fnmsf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_558_fnmsf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_558_fnmsf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 559
// Class :: fnmsf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_559_fnmsf_s4::m_id = 559;
const std::string       CIns_559_fnmsf_s4::m_mne("fnmsf.s4");
const UI32              CIns_559_fnmsf_s4::m_numop = 3;
const BS_IPRV           CIns_559_fnmsf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_559_fnmsf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_559_fnmsf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 560
// Class :: addsubf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_560_addsubf_s2::m_id = 560;
const std::string       CIns_560_addsubf_s2::m_mne("addsubf.s2");
const UI32              CIns_560_addsubf_s2::m_numop = 3;
const BS_IPRV           CIns_560_addsubf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_560_addsubf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_560_addsubf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 561
// Class :: addsubf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_561_addsubf_s4::m_id = 561;
const std::string       CIns_561_addsubf_s4::m_mne("addsubf.s4");
const UI32              CIns_561_addsubf_s4::m_numop = 3;
const BS_IPRV           CIns_561_addsubf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_561_addsubf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_561_addsubf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 562
// Class :: addsubnf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_562_addsubnf_s2::m_id = 562;
const std::string       CIns_562_addsubnf_s2::m_mne("addsubnf.s2");
const UI32              CIns_562_addsubnf_s2::m_numop = 3;
const BS_IPRV           CIns_562_addsubnf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_562_addsubnf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_562_addsubnf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 563
// Class :: addsubnf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_563_addsubnf_s4::m_id = 563;
const std::string       CIns_563_addsubnf_s4::m_mne("addsubnf.s4");
const UI32              CIns_563_addsubnf_s4::m_numop = 3;
const BS_IPRV           CIns_563_addsubnf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_563_addsubnf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_563_addsubnf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 564
// Class :: subaddf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_564_subaddf_s2::m_id = 564;
const std::string       CIns_564_subaddf_s2::m_mne("subaddf.s2");
const UI32              CIns_564_subaddf_s2::m_numop = 3;
const BS_IPRV           CIns_564_subaddf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_564_subaddf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_564_subaddf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 565
// Class :: subaddf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_565_subaddf_s4::m_id = 565;
const std::string       CIns_565_subaddf_s4::m_mne("subaddf.s4");
const UI32              CIns_565_subaddf_s4::m_numop = 3;
const BS_IPRV           CIns_565_subaddf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_565_subaddf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_565_subaddf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 566
// Class :: subaddnf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_566_subaddnf_s2::m_id = 566;
const std::string       CIns_566_subaddnf_s2::m_mne("subaddnf.s2");
const UI32              CIns_566_subaddnf_s2::m_numop = 3;
const BS_IPRV           CIns_566_subaddnf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_566_subaddnf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_566_subaddnf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 567
// Class :: subaddnf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_567_subaddnf_s4::m_id = 567;
const std::string       CIns_567_subaddnf_s4::m_mne("subaddnf.s4");
const UI32              CIns_567_subaddnf_s4::m_numop = 3;
const BS_IPRV           CIns_567_subaddnf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_567_subaddnf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_567_subaddnf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 568
// Class :: addxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_568_addxf_s2::m_id = 568;
const std::string       CIns_568_addxf_s2::m_mne("addxf.s2");
const UI32              CIns_568_addxf_s2::m_numop = 3;
const BS_IPRV           CIns_568_addxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_568_addxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_568_addxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 569
// Class :: addxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_569_addxf_s4::m_id = 569;
const std::string       CIns_569_addxf_s4::m_mne("addxf.s4");
const UI32              CIns_569_addxf_s4::m_numop = 3;
const BS_IPRV           CIns_569_addxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_569_addxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_569_addxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 570
// Class :: mulxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_570_mulxf_s2::m_id = 570;
const std::string       CIns_570_mulxf_s2::m_mne("mulxf.s2");
const UI32              CIns_570_mulxf_s2::m_numop = 3;
const BS_IPRV           CIns_570_mulxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_570_mulxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_570_mulxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 571
// Class :: mulxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_571_mulxf_s4::m_id = 571;
const std::string       CIns_571_mulxf_s4::m_mne("mulxf.s4");
const UI32              CIns_571_mulxf_s4::m_numop = 3;
const BS_IPRV           CIns_571_mulxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_571_mulxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_571_mulxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 572
// Class :: subxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_572_subxf_s2::m_id = 572;
const std::string       CIns_572_subxf_s2::m_mne("subxf.s2");
const UI32              CIns_572_subxf_s2::m_numop = 3;
const BS_IPRV           CIns_572_subxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_572_subxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_572_subxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 573
// Class :: subxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_573_subxf_s4::m_id = 573;
const std::string       CIns_573_subxf_s4::m_mne("subxf.s4");
const UI32              CIns_573_subxf_s4::m_numop = 3;
const BS_IPRV           CIns_573_subxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_573_subxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_573_subxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 574
// Class :: addsubnxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_574_addsubnxf_s2::m_id = 574;
const std::string       CIns_574_addsubnxf_s2::m_mne("addsubnxf.s2");
const UI32              CIns_574_addsubnxf_s2::m_numop = 3;
const BS_IPRV           CIns_574_addsubnxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_574_addsubnxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_574_addsubnxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 575
// Class :: addsubnxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_575_addsubnxf_s4::m_id = 575;
const std::string       CIns_575_addsubnxf_s4::m_mne("addsubnxf.s4");
const UI32              CIns_575_addsubnxf_s4::m_numop = 3;
const BS_IPRV           CIns_575_addsubnxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_575_addsubnxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_575_addsubnxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 576
// Class :: addsubxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_576_addsubxf_s2::m_id = 576;
const std::string       CIns_576_addsubxf_s2::m_mne("addsubxf.s2");
const UI32              CIns_576_addsubxf_s2::m_numop = 3;
const BS_IPRV           CIns_576_addsubxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_576_addsubxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_576_addsubxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 577
// Class :: addsubxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_577_addsubxf_s4::m_id = 577;
const std::string       CIns_577_addsubxf_s4::m_mne("addsubxf.s4");
const UI32              CIns_577_addsubxf_s4::m_numop = 3;
const BS_IPRV           CIns_577_addsubxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_577_addsubxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_577_addsubxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 578
// Class :: subaddnxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_578_subaddnxf_s2::m_id = 578;
const std::string       CIns_578_subaddnxf_s2::m_mne("subaddnxf.s2");
const UI32              CIns_578_subaddnxf_s2::m_numop = 3;
const BS_IPRV           CIns_578_subaddnxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_578_subaddnxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_578_subaddnxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 579
// Class :: subaddnxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_579_subaddnxf_s4::m_id = 579;
const std::string       CIns_579_subaddnxf_s4::m_mne("subaddnxf.s4");
const UI32              CIns_579_subaddnxf_s4::m_numop = 3;
const BS_IPRV           CIns_579_subaddnxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_579_subaddnxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_579_subaddnxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 580
// Class :: subaddxf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_580_subaddxf_s2::m_id = 580;
const std::string       CIns_580_subaddxf_s2::m_mne("subaddxf.s2");
const UI32              CIns_580_subaddxf_s2::m_numop = 3;
const BS_IPRV           CIns_580_subaddxf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_580_subaddxf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_580_subaddxf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 581
// Class :: subaddxf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_581_subaddxf_s4::m_id = 581;
const std::string       CIns_581_subaddxf_s4::m_mne("subaddxf.s4");
const UI32              CIns_581_subaddxf_s4::m_numop = 3;
const BS_IPRV           CIns_581_subaddxf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_581_subaddxf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_581_subaddxf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 582
// Class :: addrf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_582_addrf_s2::m_id = 582;
const std::string       CIns_582_addrf_s2::m_mne("addrf.s2");
const UI32              CIns_582_addrf_s2::m_numop = 3;
const BS_IPRV           CIns_582_addrf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_582_addrf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_582_addrf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 583
// Class :: addrf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_583_addrf_s4::m_id = 583;
const std::string       CIns_583_addrf_s4::m_mne("addrf.s4");
const UI32              CIns_583_addrf_s4::m_numop = 3;
const BS_IPRV           CIns_583_addrf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_583_addrf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_583_addrf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 584
// Class :: maxrf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_584_maxrf_s2::m_id = 584;
const std::string       CIns_584_maxrf_s2::m_mne("maxrf.s2");
const UI32              CIns_584_maxrf_s2::m_numop = 3;
const BS_IPRV           CIns_584_maxrf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_584_maxrf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_584_maxrf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 585
// Class :: maxrf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_585_maxrf_s4::m_id = 585;
const std::string       CIns_585_maxrf_s4::m_mne("maxrf.s4");
const UI32              CIns_585_maxrf_s4::m_numop = 3;
const BS_IPRV           CIns_585_maxrf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_585_maxrf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_585_maxrf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 586
// Class :: minrf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_586_minrf_s2::m_id = 586;
const std::string       CIns_586_minrf_s2::m_mne("minrf.s2");
const UI32              CIns_586_minrf_s2::m_numop = 3;
const BS_IPRV           CIns_586_minrf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_586_minrf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_586_minrf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 587
// Class :: minrf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_587_minrf_s4::m_id = 587;
const std::string       CIns_587_minrf_s4::m_mne("minrf.s4");
const UI32              CIns_587_minrf_s4::m_numop = 3;
const BS_IPRV           CIns_587_minrf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_587_minrf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_587_minrf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 588
// Class :: mulrf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_588_mulrf_s2::m_id = 588;
const std::string       CIns_588_mulrf_s2::m_mne("mulrf.s2");
const UI32              CIns_588_mulrf_s2::m_numop = 3;
const BS_IPRV           CIns_588_mulrf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_588_mulrf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_588_mulrf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 589
// Class :: mulrf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_589_mulrf_s4::m_id = 589;
const std::string       CIns_589_mulrf_s4::m_mne("mulrf.s4");
const UI32              CIns_589_mulrf_s4::m_numop = 3;
const BS_IPRV           CIns_589_mulrf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_589_mulrf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_589_mulrf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 590
// Class :: subrf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_590_subrf_s2::m_id = 590;
const std::string       CIns_590_subrf_s2::m_mne("subrf.s2");
const UI32              CIns_590_subrf_s2::m_numop = 3;
const BS_IPRV           CIns_590_subrf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_590_subrf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_590_subrf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 591
// Class :: subrf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_591_subrf_s4::m_id = 591;
const std::string       CIns_591_subrf_s4::m_mne("subrf.s4");
const UI32              CIns_591_subrf_s4::m_numop = 3;
const BS_IPRV           CIns_591_subrf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_591_subrf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_591_subrf_s4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 592
// Class :: ceilf.suw1
/////////////////////////////////////////////////////////
const UI32		CIns_592_ceilf_suw1::m_id = 592;
const std::string	CIns_592_ceilf_suw1::m_mne("ceilf.suw1");
const UI32		CIns_592_ceilf_suw1::m_numop = 2;
const BS_IPRV		CIns_592_ceilf_suw1::m_priviledge(0x2);
const BS_ICAT		CIns_592_ceilf_suw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_592_ceilf_suw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 593
// Class :: ceilf.suw2
/////////////////////////////////////////////////////////
const UI32		CIns_593_ceilf_suw2::m_id = 593;
const std::string	CIns_593_ceilf_suw2::m_mne("ceilf.suw2");
const UI32		CIns_593_ceilf_suw2::m_numop = 2;
const BS_IPRV		CIns_593_ceilf_suw2::m_priviledge(0x2);
const BS_ICAT		CIns_593_ceilf_suw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_593_ceilf_suw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 594
// Class :: ceilf.suw4
/////////////////////////////////////////////////////////
const UI32		CIns_594_ceilf_suw4::m_id = 594;
const std::string	CIns_594_ceilf_suw4::m_mne("ceilf.suw4");
const UI32		CIns_594_ceilf_suw4::m_numop = 2;
const BS_IPRV		CIns_594_ceilf_suw4::m_priviledge(0x2);
const BS_ICAT		CIns_594_ceilf_suw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_594_ceilf_suw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 595
// Class :: ceilf.sw1
/////////////////////////////////////////////////////////
const UI32		CIns_595_ceilf_sw1::m_id = 595;
const std::string	CIns_595_ceilf_sw1::m_mne("ceilf.sw1");
const UI32		CIns_595_ceilf_sw1::m_numop = 2;
const BS_IPRV		CIns_595_ceilf_sw1::m_priviledge(0x2);
const BS_ICAT		CIns_595_ceilf_sw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_595_ceilf_sw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 596
// Class :: ceilf.sw2
/////////////////////////////////////////////////////////
const UI32		CIns_596_ceilf_sw2::m_id = 596;
const std::string	CIns_596_ceilf_sw2::m_mne("ceilf.sw2");
const UI32			CIns_596_ceilf_sw2::m_numop = 2;
const BS_IPRV		CIns_596_ceilf_sw2::m_priviledge(0x2);
const BS_ICAT		CIns_596_ceilf_sw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_596_ceilf_sw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 597
// Class :: ceilf.sw4
/////////////////////////////////////////////////////////
const UI32		CIns_597_ceilf_sw4::m_id = 597;
const std::string	CIns_597_ceilf_sw4::m_mne("ceilf.sw4");
const UI32		CIns_597_ceilf_sw4::m_numop = 2;
const BS_IPRV		CIns_597_ceilf_sw4::m_priviledge(0x2);
const BS_ICAT		CIns_597_ceilf_sw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_597_ceilf_sw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 598
// Class :: cvtf.hs1
/////////////////////////////////////////////////////////
const UI32		CIns_598_cvtf_hs1::m_id = 598;
const std::string	CIns_598_cvtf_hs1::m_mne("cvtf.hs1");
const UI32		CIns_598_cvtf_hs1::m_numop = 2;
const BS_IPRV		CIns_598_cvtf_hs1::m_priviledge(0x2);
const BS_ICAT		CIns_598_cvtf_hs1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_598_cvtf_hs1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 599
// Class :: cvtf.hs2
/////////////////////////////////////////////////////////
const UI32		CIns_599_cvtf_hs2::m_id = 599;
const std::string	CIns_599_cvtf_hs2::m_mne("cvtf.hs2");
const UI32		CIns_599_cvtf_hs2::m_numop = 2;
const BS_IPRV		CIns_599_cvtf_hs2::m_priviledge(0x2);
const BS_ICAT		CIns_599_cvtf_hs2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_599_cvtf_hs2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 600
// Class :: cvtf.hs4
/////////////////////////////////////////////////////////
const UI32		CIns_600_cvtf_hs4::m_id = 600;
const std::string	CIns_600_cvtf_hs4::m_mne("cvtf.hs4");
const UI32		CIns_600_cvtf_hs4::m_numop = 2;
const BS_IPRV		CIns_600_cvtf_hs4::m_priviledge(0x2);
const BS_ICAT		CIns_600_cvtf_hs4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_600_cvtf_hs4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 601
// Class :: cvtf.sh1
/////////////////////////////////////////////////////////
const UI32		CIns_601_cvtf_sh1::m_id = 601;
const std::string	CIns_601_cvtf_sh1::m_mne("cvtf.sh1");
const UI32		CIns_601_cvtf_sh1::m_numop = 2;
const BS_IPRV		CIns_601_cvtf_sh1::m_priviledge(0x2);
const BS_ICAT		CIns_601_cvtf_sh1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_601_cvtf_sh1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 602
// Class :: cvtf.sh2
/////////////////////////////////////////////////////////
const UI32		CIns_602_cvtf_sh2::m_id = 602;
const std::string	CIns_602_cvtf_sh2::m_mne("cvtf.sh2");
const UI32		CIns_602_cvtf_sh2::m_numop = 2;
const BS_IPRV		CIns_602_cvtf_sh2::m_priviledge(0x2);
const BS_ICAT		CIns_602_cvtf_sh2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_602_cvtf_sh2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 603
// Class :: cvtf.sh4
/////////////////////////////////////////////////////////
const UI32		CIns_603_cvtf_sh4::m_id = 603;
const std::string	CIns_603_cvtf_sh4::m_mne("cvtf.sh4");
const UI32		CIns_603_cvtf_sh4::m_numop = 2;
const BS_IPRV		CIns_603_cvtf_sh4::m_priviledge(0x2);
const BS_ICAT		CIns_603_cvtf_sh4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_603_cvtf_sh4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 604
// Class :: cvtf.suw1
/////////////////////////////////////////////////////////
const UI32		CIns_604_cvtf_suw1::m_id = 604;
const std::string	CIns_604_cvtf_suw1::m_mne("cvtf.suw1");
const UI32		CIns_604_cvtf_suw1::m_numop = 2;
const BS_IPRV		CIns_604_cvtf_suw1::m_priviledge(0x2);
const BS_ICAT		CIns_604_cvtf_suw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_604_cvtf_suw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 605
// Class :: cvtf.suw2
/////////////////////////////////////////////////////////
const UI32		CIns_605_cvtf_suw2::m_id = 605;
const std::string	CIns_605_cvtf_suw2::m_mne("cvtf.suw2");
const UI32		CIns_605_cvtf_suw2::m_numop = 2;
const BS_IPRV		CIns_605_cvtf_suw2::m_priviledge(0x2);
const BS_ICAT		CIns_605_cvtf_suw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_605_cvtf_suw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 606
// Class :: cvtf.suw4
/////////////////////////////////////////////////////////
const UI32		CIns_606_cvtf_suw4::m_id = 606;
const std::string	CIns_606_cvtf_suw4::m_mne("cvtf.suw4");
const UI32		CIns_606_cvtf_suw4::m_numop = 2;
const BS_IPRV		CIns_606_cvtf_suw4::m_priviledge(0x2);
const BS_ICAT		CIns_606_cvtf_suw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_606_cvtf_suw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 607
// Class :: cvtf.sw1
/////////////////////////////////////////////////////////
const UI32		CIns_607_cvtf_sw1::m_id = 607;
const std::string	CIns_607_cvtf_sw1::m_mne("cvtf.sw1");
const UI32		CIns_607_cvtf_sw1::m_numop = 2;
const BS_IPRV		CIns_607_cvtf_sw1::m_priviledge(0x2);
const BS_ICAT		CIns_607_cvtf_sw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_607_cvtf_sw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 608
// Class :: cvtf.sw2
/////////////////////////////////////////////////////////
const UI32		CIns_608_cvtf_sw2::m_id = 608;
const std::string	CIns_608_cvtf_sw2::m_mne("cvtf.sw2");
const UI32		CIns_608_cvtf_sw2::m_numop = 2;
const BS_IPRV		CIns_608_cvtf_sw2::m_priviledge(0x2);
const BS_ICAT		CIns_608_cvtf_sw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_608_cvtf_sw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 609
// Class :: cvtf.sw4
/////////////////////////////////////////////////////////
const UI32		CIns_609_cvtf_sw4::m_id = 609;
const std::string	CIns_609_cvtf_sw4::m_mne("cvtf.sw4");
const UI32		CIns_609_cvtf_sw4::m_numop = 2;
const BS_IPRV		CIns_609_cvtf_sw4::m_priviledge(0x2);
const BS_ICAT		CIns_609_cvtf_sw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_609_cvtf_sw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 610
// Class :: cvtf.uws1
/////////////////////////////////////////////////////////
const UI32		CIns_610_cvtf_uws1::m_id = 610;
const std::string	CIns_610_cvtf_uws1::m_mne("cvtf.uws1");
const UI32		CIns_610_cvtf_uws1::m_numop = 2;
const BS_IPRV		CIns_610_cvtf_uws1::m_priviledge(0x2);
const BS_ICAT		CIns_610_cvtf_uws1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_610_cvtf_uws1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 611
// Class :: cvtf.uws2
/////////////////////////////////////////////////////////
const UI32		CIns_611_cvtf_uws2::m_id = 611;
const std::string	CIns_611_cvtf_uws2::m_mne("cvtf.uws2");
const UI32		CIns_611_cvtf_uws2::m_numop = 2;
const BS_IPRV		CIns_611_cvtf_uws2::m_priviledge(0x2);
const BS_ICAT		CIns_611_cvtf_uws2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_611_cvtf_uws2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 612
// Class :: cvtf.uws4
/////////////////////////////////////////////////////////
const UI32		CIns_612_cvtf_uws4::m_id = 612;
const std::string	CIns_612_cvtf_uws4::m_mne("cvtf.uws4");
const UI32		CIns_612_cvtf_uws4::m_numop = 2;
const BS_IPRV		CIns_612_cvtf_uws4::m_priviledge(0x2);
const BS_ICAT		CIns_612_cvtf_uws4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_612_cvtf_uws4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 613
// Class :: cvtf.ws1
/////////////////////////////////////////////////////////
const UI32		CIns_613_cvtf_ws1::m_id = 613;
const std::string	CIns_613_cvtf_ws1::m_mne("cvtf.ws1");
const UI32		CIns_613_cvtf_ws1::m_numop = 2;
const BS_IPRV		CIns_613_cvtf_ws1::m_priviledge(0x2);
const BS_ICAT		CIns_613_cvtf_ws1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_613_cvtf_ws1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 614
// Class :: cvtf.ws2
/////////////////////////////////////////////////////////
const UI32		CIns_614_cvtf_ws2::m_id = 614;
const std::string	CIns_614_cvtf_ws2::m_mne("cvtf.ws2");
const UI32		CIns_614_cvtf_ws2::m_numop = 2;
const BS_IPRV		CIns_614_cvtf_ws2::m_priviledge(0x2);
const BS_ICAT		CIns_614_cvtf_ws2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_614_cvtf_ws2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 615
// Class :: cvtf.ws4
/////////////////////////////////////////////////////////
const UI32		CIns_615_cvtf_ws4::m_id = 615;
const std::string	CIns_615_cvtf_ws4::m_mne("cvtf.ws4");
const UI32		CIns_615_cvtf_ws4::m_numop = 2;
const BS_IPRV		CIns_615_cvtf_ws4::m_priviledge(0x2);
const BS_ICAT		CIns_615_cvtf_ws4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_615_cvtf_ws4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 616
// Class :: floorf.suw1
/////////////////////////////////////////////////////////
const UI32		CIns_616_floorf_suw1::m_id = 616;
const std::string	CIns_616_floorf_suw1::m_mne("floorf.suw1");
const UI32		CIns_616_floorf_suw1::m_numop = 2;
const BS_IPRV		CIns_616_floorf_suw1::m_priviledge(0x2);
const BS_ICAT		CIns_616_floorf_suw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_616_floorf_suw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 617
// Class :: floorf.suw2
/////////////////////////////////////////////////////////
const UI32		CIns_617_floorf_suw2::m_id = 617;
const std::string	CIns_617_floorf_suw2::m_mne("floorf.suw2");
const UI32		CIns_617_floorf_suw2::m_numop = 2;
const BS_IPRV		CIns_617_floorf_suw2::m_priviledge(0x2);
const BS_ICAT		CIns_617_floorf_suw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_617_floorf_suw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 618
// Class :: floorf.suw4
/////////////////////////////////////////////////////////
const UI32		CIns_618_floorf_suw4::m_id = 618;
const std::string	CIns_618_floorf_suw4::m_mne("floorf.suw4");
const UI32		CIns_618_floorf_suw4::m_numop = 2;
const BS_IPRV		CIns_618_floorf_suw4::m_priviledge(0x2);
const BS_ICAT		CIns_618_floorf_suw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_618_floorf_suw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 619
// Class :: floorf.sw1
/////////////////////////////////////////////////////////
const UI32		CIns_619_floorf_sw1::m_id = 619;
const std::string	CIns_619_floorf_sw1::m_mne("floorf.sw1");
const UI32		CIns_619_floorf_sw1::m_numop = 2;
const BS_IPRV		CIns_619_floorf_sw1::m_priviledge(0x2);
const BS_ICAT		CIns_619_floorf_sw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_619_floorf_sw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 620
// Class :: floorf.sw2
/////////////////////////////////////////////////////////
const UI32		CIns_620_floorf_sw2::m_id = 620;
const std::string	CIns_620_floorf_sw2::m_mne("floorf.sw2");
const UI32		CIns_620_floorf_sw2::m_numop = 2;
const BS_IPRV		CIns_620_floorf_sw2::m_priviledge(0x2);
const BS_ICAT		CIns_620_floorf_sw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_620_floorf_sw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 621
// Class :: floorf.sw4
/////////////////////////////////////////////////////////
const UI32		CIns_621_floorf_sw4::m_id = 621;
const std::string	CIns_621_floorf_sw4::m_mne("floorf.sw4");
const UI32		CIns_621_floorf_sw4::m_numop = 2;
const BS_IPRV		CIns_621_floorf_sw4::m_priviledge(0x2);
const BS_ICAT		CIns_621_floorf_sw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_621_floorf_sw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 622
// Class :: roundf.suw1
/////////////////////////////////////////////////////////
const UI32		CIns_622_roundf_suw1::m_id = 622;
const std::string	CIns_622_roundf_suw1::m_mne("roundf.suw1");
const UI32		CIns_622_roundf_suw1::m_numop = 2;
const BS_IPRV		CIns_622_roundf_suw1::m_priviledge(0x2);
const BS_ICAT		CIns_622_roundf_suw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_622_roundf_suw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 623
// Class :: roundf.suw2
/////////////////////////////////////////////////////////
const UI32		CIns_623_roundf_suw2::m_id = 623;
const std::string	CIns_623_roundf_suw2::m_mne("roundf.suw2");
const UI32		CIns_623_roundf_suw2::m_numop = 2;
const BS_IPRV		CIns_623_roundf_suw2::m_priviledge(0x2);
const BS_ICAT		CIns_623_roundf_suw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_623_roundf_suw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 624
// Class :: roundf.suw4
/////////////////////////////////////////////////////////
const UI32		CIns_624_roundf_suw4::m_id = 624;
const std::string	CIns_624_roundf_suw4::m_mne("roundf.suw4");
const UI32		CIns_624_roundf_suw4::m_numop = 2;
const BS_IPRV		CIns_624_roundf_suw4::m_priviledge(0x2);
const BS_ICAT		CIns_624_roundf_suw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_624_roundf_suw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 625
// Class :: roundf.sw1
/////////////////////////////////////////////////////////
const UI32		CIns_625_roundf_sw1::m_id = 625;
const std::string	CIns_625_roundf_sw1::m_mne("roundf.sw1");
const UI32		CIns_625_roundf_sw1::m_numop = 2;
const BS_IPRV		CIns_625_roundf_sw1::m_priviledge(0x2);
const BS_ICAT		CIns_625_roundf_sw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_625_roundf_sw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 626
// Class :: roundf.sw2
/////////////////////////////////////////////////////////
const UI32		CIns_626_roundf_sw2::m_id = 626;
const std::string	CIns_626_roundf_sw2::m_mne("roundf.sw2");
const UI32		CIns_626_roundf_sw2::m_numop = 2;
const BS_IPRV		CIns_626_roundf_sw2::m_priviledge(0x2);
const BS_ICAT		CIns_626_roundf_sw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_626_roundf_sw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 627
// Class :: roundf.sw4
/////////////////////////////////////////////////////////
const UI32		CIns_627_roundf_sw4::m_id = 627;
const std::string	CIns_627_roundf_sw4::m_mne("roundf.sw4");
const UI32		CIns_627_roundf_sw4::m_numop = 2;
const BS_IPRV		CIns_627_roundf_sw4::m_priviledge(0x2);
const BS_ICAT		CIns_627_roundf_sw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_627_roundf_sw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 628
// Class :: trncf.suw1
/////////////////////////////////////////////////////////
const UI32		CIns_628_trncf_suw1::m_id = 628;
const std::string	CIns_628_trncf_suw1::m_mne("trncf.suw1");
const UI32		CIns_628_trncf_suw1::m_numop = 2;
const BS_IPRV		CIns_628_trncf_suw1::m_priviledge(0x2);
const BS_ICAT		CIns_628_trncf_suw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_628_trncf_suw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 629
// Class :: trncf.suw2
/////////////////////////////////////////////////////////
const UI32		CIns_629_trncf_suw2::m_id = 629;
const std::string	CIns_629_trncf_suw2::m_mne("trncf.suw2");
const UI32		CIns_629_trncf_suw2::m_numop = 2;
const BS_IPRV		CIns_629_trncf_suw2::m_priviledge(0x2);
const BS_ICAT		CIns_629_trncf_suw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_629_trncf_suw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 630
// Class :: trncf.suw4
/////////////////////////////////////////////////////////
const UI32		CIns_630_trncf_suw4::m_id = 630;
const std::string	CIns_630_trncf_suw4::m_mne("trncf.suw4");
const UI32		CIns_630_trncf_suw4::m_numop = 2;
const BS_IPRV		CIns_630_trncf_suw4::m_priviledge(0x2);
const BS_ICAT		CIns_630_trncf_suw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_630_trncf_suw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 631
// Class :: trncf.sw1
/////////////////////////////////////////////////////////
const UI32		CIns_631_trncf_sw1::m_id = 631;
const std::string	CIns_631_trncf_sw1::m_mne("trncf.sw1");
const UI32		CIns_631_trncf_sw1::m_numop = 2;
const BS_IPRV		CIns_631_trncf_sw1::m_priviledge(0x2);
const BS_ICAT		CIns_631_trncf_sw1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_631_trncf_sw1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 632
// Class :: trncf.sw2
/////////////////////////////////////////////////////////
const UI32		CIns_632_trncf_sw2::m_id = 632;
const std::string	CIns_632_trncf_sw2::m_mne("trncf.sw2");
const UI32		CIns_632_trncf_sw2::m_numop = 2;
const BS_IPRV		CIns_632_trncf_sw2::m_priviledge(0x2);
const BS_ICAT		CIns_632_trncf_sw2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_632_trncf_sw2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 633
// Class :: trncf.sw4
/////////////////////////////////////////////////////////
const UI32		CIns_633_trncf_sw4::m_id = 633;
const std::string	CIns_633_trncf_sw4::m_mne("trncf.sw4");
const UI32		CIns_633_trncf_sw4::m_numop = 2;
const BS_IPRV		CIns_633_trncf_sw4::m_priviledge(0x2);
const BS_ICAT		CIns_633_trncf_sw4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV		CIns_633_trncf_sw4::m_behavior(0x4000);

/////////////////////////////////////////////////////////
// InsID :: 634
// Class :: cmpf.s1
/////////////////////////////////////////////////////////
const UI32              CIns_634_cmpf_s1::m_id = 634;
const std::string       CIns_634_cmpf_s1::m_mne("cmpf.s1");
const UI32              CIns_634_cmpf_s1::m_numop = 3;
const BS_IPRV           CIns_634_cmpf_s1::m_priviledge(0x2);
const BS_ICAT           CIns_634_cmpf_s1::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_634_cmpf_s1::m_behavior(0x1000);

/////////////////////////////////////////////////////////
// InsID :: 635
// Class :: cmpf.s2
/////////////////////////////////////////////////////////
const UI32              CIns_635_cmpf_s2::m_id = 635;
const std::string       CIns_635_cmpf_s2::m_mne("cmpf.s2");
const UI32              CIns_635_cmpf_s2::m_numop = 3;
const BS_IPRV           CIns_635_cmpf_s2::m_priviledge(0x2);
const BS_ICAT           CIns_635_cmpf_s2::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_635_cmpf_s2::m_behavior(0x2000);

/////////////////////////////////////////////////////////
// InsID :: 636
// Class :: cmpf.s4
/////////////////////////////////////////////////////////
const UI32              CIns_636_cmpf_s4::m_id = 636;
const std::string       CIns_636_cmpf_s4::m_mne("cmpf.s4");
const UI32              CIns_636_cmpf_s4::m_numop = 3;
const BS_IPRV           CIns_636_cmpf_s4::m_priviledge(0x2);
const BS_ICAT           CIns_636_cmpf_s4::m_category((1 << IInstruction::IF_INS_CAT0) | (1 << IInstruction::IF_INS_CAT2));
const BS_IBHV           CIns_636_cmpf_s4::m_behavior(0x4000);

void SCorrection(IRegulation* r, IOperand* opr1,  IOperand* opr2 , UI32 size) {

	//!< シミュレータから現在の値を読む
	UI32 cur1;
	UI32 cur2;

	UI32 reg1 = opr1->Idx() ;
	UI32 reg2 = opr2->Idx() ;
	IValConstraint* m_vConst  = opr1->GetConstraint(); 
	//IValConstraint* m_vConst2 = opr2->GetConstraint(); 
	IRandom* m_pRand = &g_rnd  ;


	if (r->m_pSim->ReadGrReg(&cur1, (SI32)reg1, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	if (r->m_pSim->ReadGrReg(&cur2, (SI32)reg2, (SI32)0) != true) {
		std::runtime_error excep("Simulator error : Read GR");
		throw excep;
	}
	UI64 sv = m_vConst==NULL ? (UI64)4 : (UI64)(m_vConst->m_nSzm) ;
#ifdef DBGMODE
	printf(" now size        : 0x%x\n", size) ;
	printf(" now reg1(reg%-2d) : 0x%016x\n", reg1, cur1) ;
	printf(" now reg2(reg%-2d) : 0x%016x\n", reg2, cur2) ;
	printf(" now reg1 + reg2 : 0x%016llx\n", (UI64)(cur1)+(UI64)(cur2)) ;
#endif
	if ( m_vConst==NULL ){
		return ;
	}

	//!< 現状が適正値である場合はそのままシミュレーションさせる
	if( size == 4){
		if ( (m_vConst->IsValid((UI64)cur1 + (UI64)cur2*3) ) &&
			 (m_vConst->IsValid((UI64)cur1 + (UI64)cur2*2) ) &&
			 (m_vConst->IsValid((UI64)cur1 + (UI64)cur2)   ) &&
			 (m_vConst->IsValid((UI64)cur1)) 
		   ) {
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur1+(cur2*3), sv));
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur1+(cur2*2), sv));
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur1+cur2,     sv));
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur1,          sv));
			return;
		}
	} else
	if( size == 2){
		if ( (m_vConst->IsValid((UI64)cur1 + (UI64)cur2)) &&
			 (m_vConst->IsValid((UI64)cur1)) 
		   ) {
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur1+cur2,     sv));
			r->m_vEa.push_back(std::pair<UI32,UI32>(cur1,          sv));
			return;
		}
	}

	//!< reg1番号 == reg2番号は補正しきれない為レジスタ番号を変更する 
	if( (reg1 == reg2) || reg1==0 ){
		UI32 makeReg = reg1 ;
		while( true ){
			makeReg = m_pRand->GetRange(1,31) ;
#ifdef DBGMODE
			printf(" makeReg : %d\n", makeReg) ;
#endif
			if( (makeReg != reg2) && (opr1->Replace(makeReg)==true) ){
				break ;
			}
		}
		SCorrection(r, opr1, opr2, size) ;
		return ;
	}

		
	UI32 M  = m_vConst ? m_vConst->m_nMsk : 0;			// アラインマスク(i.e. M=0ならミスアラインが発生しないバイトアクセス)
	UI32 U  = m_vConst ? m_vConst->m_nUnA : 0;			// アラインされた値に足す値（強制的なアンアラインドアクセス　i.e.U=0ならアラインアクセスを意味する）
	UI32 mx = m_vConst ? (UI64)((m_vConst->m_nMax+1 >= m_vConst->m_nSzm) ? (m_vConst->m_nMax-m_vConst->m_nSzm+1):0) : 0;    // 符号計算の為
	UI32 mn = m_vConst ? (UI64)m_vConst->m_nMin : 0;	// 符号計算の為

 	//!< 目標値取得
 	if (m_vConst != NULL) {
 		sv = ((m_vConst->SelectValue()) & ~M) + U ; 
 		//sv = ((m_vConst2->SelectValue()) & ~M) + U ; 
 	}
#ifdef DBGMODE
	printf(" mask    M: 0x%02x\n", M) ;
	printf(" unMask  U: 0x%02x\n", U) ;
	printf(" max    mx: 0x%08x\n", mx) ;
	printf(" min    mn: 0x%08x\n", mn) ;
#endif
	UI32 val1 = ((UI64)m_pRand->GetRange(mn, mx) & ~M) + U; // reg1目標値
	UI32 val2e = 0 ;
	UI32 val2 = 0 ;
	if( reg2!=0 ){
		if( size == 4 ){
			val2e = ((UI64)m_pRand->GetRange(val1, mx) & ~M) + U ; //reg2最終目標値
			val2 = ((val2e-val1) / 4) & ~M ;
#ifdef DBGMODE
			printf(" now reg1 + reg2 * 0 : 0x%08x\n", val1+(val2*0)) ;
			printf(" now reg1 + reg2 * 1 : 0x%08x\n", val1+(val2*1)) ;
			printf(" now reg1 + reg2 * 2 : 0x%08x\n", val1+(val2*2)) ;
			printf(" now reg1 + reg2 * 3 : 0x%08x\n", val1+(val2*3)) ;
			printf(" now reg1 + reg2 * 4 : 0x%08x\n", val1+(val2*4)) ;
#endif
		} else
		if( size == 2 ){
			val2e = ((UI64)m_pRand->GetRange(val1, mx) & ~M) + U ; //reg2最終目標値
			val2 = (val2e-val1) / 2  & ~M;
#ifdef DBGMODE
			printf(" now reg1 + reg2 * 0 : 0x%08x\n", val1+(val2*0)) ;
			printf(" now reg1 + reg2 * 1 : 0x%08x\n", val1+(val2*1)) ;
			printf(" now reg1 + reg2 * 2 : 0x%08x\n", val1+(val2*2)) ;
#endif
		}
#ifdef DBGMODE
		printf(" now  val1 : %08x\n", val1) ;
		printf(" now  val2 : %08x\n", val2) ;
#endif
		r->m_vGr.push_back(std::pair<UI32,UI32>(reg1, val1));
		r->m_vGr.push_back(std::pair<UI32,UI32>(reg2, val2));
	} else 
	if( reg2==0 ){
#ifdef DBGMODE
		printf(" now  val1 : %08x\n", val1) ;
		printf(" now  val2 : %08x\n", val2) ;
#endif
        r->m_vGr.push_back(std::pair<UI32,UI32>(reg1, val1));
	}

	return ;
}

/////////////////////////////////////////////////////////
// InsID :: 637
// Class :: ld.b 
/////////////////////////////////////////////////////////
const UI32          CIns_637_ld_b_inc::m_id = 637;
const std::string   CIns_637_ld_b_inc::m_mne("ld.b");
const UI32          CIns_637_ld_b_inc::m_numop = 2;
const BS_IPRV       CIns_637_ld_b_inc::m_priviledge(0x0);
const BS_ICAT       CIns_637_ld_b_inc::m_category(0x0);
const BS_IBHV       CIns_637_ld_b_inc::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 638
// Class :: ld.b 
/////////////////////////////////////////////////////////
const UI32          CIns_638_ld_b_dec::m_id = 638;
const std::string   CIns_638_ld_b_dec::m_mne("ld.b");
const UI32          CIns_638_ld_b_dec::m_numop = 2;
const BS_IPRV       CIns_638_ld_b_dec::m_priviledge(0x0);
const BS_ICAT		CIns_638_ld_b_dec::m_category(0x0);
const BS_IBHV       CIns_638_ld_b_dec::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 639
// Class :: ld.bu 
/////////////////////////////////////////////////////////
const UI32          CIns_639_ld_bu_inc::m_id = 639;
const std::string   CIns_639_ld_bu_inc::m_mne("ld.bu");
const UI32          CIns_639_ld_bu_inc::m_numop = 2;
const BS_IPRV       CIns_639_ld_bu_inc::m_priviledge(0x0);
const BS_ICAT       CIns_639_ld_bu_inc::m_category(0x0);
const BS_IBHV       CIns_639_ld_bu_inc::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 640
// Class :: ld.bu 
/////////////////////////////////////////////////////////
const UI32          CIns_640_ld_bu_dec::m_id = 640;
const std::string   CIns_640_ld_bu_dec::m_mne("ld.bu");
const UI32          CIns_640_ld_bu_dec::m_numop = 2;
const BS_IPRV       CIns_640_ld_bu_dec::m_priviledge(0x0);
const BS_ICAT       CIns_640_ld_bu_dec::m_category(0x0);
const BS_IBHV       CIns_640_ld_bu_dec::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 641
// Class :: ld.h 
/////////////////////////////////////////////////////////
const UI32          CIns_641_ld_h_inc::m_id = 641;
const std::string   CIns_641_ld_h_inc::m_mne("ld.h");
const UI32          CIns_641_ld_h_inc::m_numop = 2;
const BS_IPRV       CIns_641_ld_h_inc::m_priviledge(0x0);
const BS_ICAT       CIns_641_ld_h_inc::m_category(0x0);
const BS_IBHV       CIns_641_ld_h_inc::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 642
// Class :: ld.h 
/////////////////////////////////////////////////////////
const UI32          CIns_642_ld_h_dec::m_id = 642;
const std::string   CIns_642_ld_h_dec::m_mne("ld.h");
const UI32          CIns_642_ld_h_dec::m_numop = 2;
const BS_IPRV       CIns_642_ld_h_dec::m_priviledge(0x0);
const BS_ICAT       CIns_642_ld_h_dec::m_category(0x0);
const BS_IBHV       CIns_642_ld_h_dec::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 643
// Class :: ld.hu 
/////////////////////////////////////////////////////////
const UI32          CIns_643_ld_hu_inc::m_id = 643;
const std::string   CIns_643_ld_hu_inc::m_mne("ld.hu");
const UI32          CIns_643_ld_hu_inc::m_numop = 2;
const BS_IPRV       CIns_643_ld_hu_inc::m_priviledge(0x0);
const BS_ICAT       CIns_643_ld_hu_inc::m_category(0x0);
const BS_IBHV       CIns_643_ld_hu_inc::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 644
// Class :: ld.hu 
/////////////////////////////////////////////////////////
const UI32          CIns_644_ld_hu_dec::m_id = 644;
const std::string   CIns_644_ld_hu_dec::m_mne("ld.hu");
const UI32          CIns_644_ld_hu_dec::m_numop = 2;
const BS_IPRV       CIns_644_ld_hu_dec::m_priviledge(0x0);
const BS_ICAT       CIns_644_ld_hu_dec::m_category(0x0);
const BS_IBHV       CIns_644_ld_hu_dec::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 645
// Class :: ld.w 
/////////////////////////////////////////////////////////
const UI32          CIns_645_ld_w_inc::m_id = 645;
const std::string   CIns_645_ld_w_inc::m_mne("ld.w");
const UI32          CIns_645_ld_w_inc::m_numop = 2;
const BS_IPRV       CIns_645_ld_w_inc::m_priviledge(0x0);
const BS_ICAT       CIns_645_ld_w_inc::m_category(0x0);
const BS_IBHV       CIns_645_ld_w_inc::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 646
// Class :: ld.w 
/////////////////////////////////////////////////////////
const UI32          CIns_646_ld_w_dec::m_id = 646;
const std::string   CIns_646_ld_w_dec::m_mne("ld.w");
const UI32          CIns_646_ld_w_dec::m_numop = 2;
const BS_IPRV       CIns_646_ld_w_dec::m_priviledge(0x0);
const BS_ICAT       CIns_646_ld_w_dec::m_category(0x0);
const BS_IBHV       CIns_646_ld_w_dec::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 647
// Class :: ld.w 
/////////////////////////////////////////////////////////
const UI32          CIns_647_ld_dw_inc::m_id = 647;
const std::string   CIns_647_ld_dw_inc::m_mne("ld.dw");
const UI32          CIns_647_ld_dw_inc::m_numop = 2;
const BS_IPRV       CIns_647_ld_dw_inc::m_priviledge(0x0);
const BS_ICAT       CIns_647_ld_dw_inc::m_category(0x0);
const BS_IBHV       CIns_647_ld_dw_inc::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 648
// Class :: ld.w 
/////////////////////////////////////////////////////////
const UI32          CIns_648_ld_dw_dec::m_id = 648;
const std::string   CIns_648_ld_dw_dec::m_mne("ld.dw");
const UI32          CIns_648_ld_dw_dec::m_numop = 2;
const BS_IPRV       CIns_648_ld_dw_dec::m_priviledge(0x0);
const BS_ICAT       CIns_648_ld_dw_dec::m_category(0x0);
const BS_IBHV       CIns_648_ld_dw_dec::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 649
// Class :: st.b
/////////////////////////////////////////////////////////
const UI32          CIns_649_st_b_inc::m_id = 649;
const std::string   CIns_649_st_b_inc::m_mne("st.b");
const UI32          CIns_649_st_b_inc::m_numop = 2;
const BS_IPRV       CIns_649_st_b_inc::m_priviledge(0x0);
const BS_ICAT       CIns_649_st_b_inc::m_category(0x0);
const BS_IBHV       CIns_649_st_b_inc::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 650
// Class :: st.b 
/////////////////////////////////////////////////////////
const UI32          CIns_650_st_b_dec::m_id = 650;
const std::string   CIns_650_st_b_dec::m_mne("st.b");
const UI32          CIns_650_st_b_dec::m_numop = 2;
const BS_IPRV       CIns_650_st_b_dec::m_priviledge(0x0);
const BS_ICAT       CIns_650_st_b_dec::m_category(0x0);
const BS_IBHV       CIns_650_st_b_dec::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 651
// Class :: st.h
/////////////////////////////////////////////////////////
const UI32          CIns_651_st_h_inc::m_id = 651;
const std::string   CIns_651_st_h_inc::m_mne("st.h");
const UI32          CIns_651_st_h_inc::m_numop = 2;
const BS_IPRV       CIns_651_st_h_inc::m_priviledge(0x0);
const BS_ICAT       CIns_651_st_h_inc::m_category(0x0);
const BS_IBHV       CIns_651_st_h_inc::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 652
// Class :: st.h 
/////////////////////////////////////////////////////////
const UI32          CIns_652_st_h_dec::m_id = 652;
const std::string   CIns_652_st_h_dec::m_mne("st.h");
const UI32          CIns_652_st_h_dec::m_numop = 2;
const BS_IPRV       CIns_652_st_h_dec::m_priviledge(0x0);
const BS_ICAT       CIns_652_st_h_dec::m_category(0x0);
const BS_IBHV       CIns_652_st_h_dec::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 653
// Class :: st.w 
/////////////////////////////////////////////////////////
const UI32          CIns_653_st_w_inc::m_id = 653;
const std::string   CIns_653_st_w_inc::m_mne("st.w");
const UI32          CIns_653_st_w_inc::m_numop = 2;
const BS_IPRV       CIns_653_st_w_inc::m_priviledge(0x0);
const BS_ICAT       CIns_653_st_w_inc::m_category(0x0);
const BS_IBHV       CIns_653_st_w_inc::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 654
// Class :: st.w 
/////////////////////////////////////////////////////////
const UI32          CIns_654_st_w_dec::m_id = 654;
const std::string   CIns_654_st_w_dec::m_mne("st.w");
const UI32          CIns_654_st_w_dec::m_numop = 2;
const BS_IPRV       CIns_654_st_w_dec::m_priviledge(0x0);
const BS_ICAT       CIns_654_st_w_dec::m_category(0x0);
const BS_IBHV       CIns_654_st_w_dec::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 655
// Class :: st.dw 
/////////////////////////////////////////////////////////
const UI32          CIns_655_st_dw_inc::m_id = 655;
const std::string   CIns_655_st_dw_inc::m_mne("st.dw");
const UI32          CIns_655_st_dw_inc::m_numop = 2;
const BS_IPRV       CIns_655_st_dw_inc::m_priviledge(0x0);
const BS_ICAT       CIns_655_st_dw_inc::m_category(0x0);
const BS_IBHV       CIns_655_st_dw_inc::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 656
// Class :: st.dw 
/////////////////////////////////////////////////////////
const UI32          CIns_656_st_dw_dec::m_id = 656;
const std::string   CIns_656_st_dw_dec::m_mne("st.dw");
const UI32          CIns_656_st_dw_dec::m_numop = 2;
const BS_IPRV       CIns_656_st_dw_dec::m_priviledge(0x0);
const BS_ICAT       CIns_656_st_dw_dec::m_category(0x0);
const BS_IBHV       CIns_656_st_dw_dec::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 657
// Class :: clip.b 
/////////////////////////////////////////////////////////
const UI32          CIns_657_clip_b::m_id = 657;
const std::string   CIns_657_clip_b::m_mne("clip.b");
const UI32          CIns_657_clip_b::m_numop = 2;
const BS_IPRV       CIns_657_clip_b::m_priviledge(0x0);
const BS_ICAT       CIns_657_clip_b::m_category(0x0);
const BS_IBHV       CIns_657_clip_b::m_behavior(0x0);
/////////////////////////////////////////////////////////
// InsID :: 658
// Class :: clip.bu 
/////////////////////////////////////////////////////////
const UI32          CIns_658_clip_bu::m_id = 658;
const std::string   CIns_658_clip_bu::m_mne("clip.bu");
const UI32          CIns_658_clip_bu::m_numop = 2;
const BS_IPRV       CIns_658_clip_bu::m_priviledge(0x0);
const BS_ICAT       CIns_658_clip_bu::m_category(0x0);
const BS_IBHV       CIns_658_clip_bu::m_behavior(0x0);
/////////////////////////////////////////////////////////
// InsID :: 659
// Class :: clip.h 
/////////////////////////////////////////////////////////
const UI32          CIns_659_clip_h::m_id = 659;
const std::string   CIns_659_clip_h::m_mne("clip.h");
const UI32          CIns_659_clip_h::m_numop = 2;
const BS_IPRV       CIns_659_clip_h::m_priviledge(0x0);
const BS_ICAT       CIns_659_clip_h::m_category(0x0);
const BS_IBHV       CIns_659_clip_h::m_behavior(0x0);
/////////////////////////////////////////////////////////
// InsID :: 660
// Class :: clip.hu
/////////////////////////////////////////////////////////
const UI32          CIns_660_clip_hu::m_id = 660;
const std::string   CIns_660_clip_hu::m_mne("clip.hu");
const UI32          CIns_660_clip_hu::m_numop = 2;
const BS_IPRV       CIns_660_clip_hu::m_priviledge(0x0);
const BS_ICAT       CIns_660_clip_hu::m_category(0x0);
const BS_IBHV       CIns_660_clip_hu::m_behavior(0x0);
/////////////////////////////////////////////////////////
// InsID :: 661
// Class :: ldl.bu
/////////////////////////////////////////////////////////
const UI32			CIns_661_ldl_bu::m_id = 661;
const std::string	CIns_661_ldl_bu::m_mne("ldl.bu");
const UI32			CIns_661_ldl_bu::m_numop = 2;
const BS_IPRV		CIns_661_ldl_bu::m_priviledge(0x0);
const BS_ICAT		CIns_661_ldl_bu::m_category(0x0);
const BS_IBHV		CIns_661_ldl_bu::m_behavior(0x1);

/////////////////////////////////////////////////////////
// InsID :: 662
// Class :: ldl.hu
/////////////////////////////////////////////////////////
const UI32			CIns_662_ldl_hu::m_id = 662;
const std::string	CIns_662_ldl_hu::m_mne("ldl.hu");
const UI32			CIns_662_ldl_hu::m_numop = 2;
const BS_IPRV		CIns_662_ldl_hu::m_priviledge(0x0);
const BS_ICAT		CIns_662_ldl_hu::m_category(0x0);
const BS_IBHV		CIns_662_ldl_hu::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 663
// Class :: ldl.dw
/////////////////////////////////////////////////////////
const UI32			CIns_663_ldl_dw::m_id = 663;
const std::string	CIns_663_ldl_dw::m_mne("ldl.dw");
const UI32			CIns_663_ldl_dw::m_numop = 2;
const BS_IPRV		CIns_663_ldl_dw::m_priviledge(0x0);
const BS_ICAT		CIns_663_ldl_dw::m_category(0x0);
const BS_IBHV		CIns_663_ldl_dw::m_behavior(0x1);
/////////////////////////////////////////////////////////
// InsID :: 664
// Class :: stc.b
/////////////////////////////////////////////////////////
const UI32			CIns_664_stc_b::m_id = 664;
const std::string	CIns_664_stc_b::m_mne("stc.b");
const UI32			CIns_664_stc_b::m_numop = 2;
const BS_IPRV		CIns_664_stc_b::m_priviledge(0x0);
const BS_ICAT		CIns_664_stc_b::m_category(0x0);
const BS_IBHV		CIns_664_stc_b::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 665
// Class :: stc.h
/////////////////////////////////////////////////////////
const UI32			CIns_665_stc_h::m_id = 665;
const std::string	CIns_665_stc_h::m_mne("stc.h");
const UI32			CIns_665_stc_h::m_numop = 2;
const BS_IPRV		CIns_665_stc_h::m_priviledge(0x0);
const BS_ICAT		CIns_665_stc_h::m_category(0x0);
const BS_IBHV		CIns_665_stc_h::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 666
// Class :: stc.dw
/////////////////////////////////////////////////////////
const UI32			CIns_666_stc_dw::m_id = 666;
const std::string	CIns_666_stc_dw::m_mne("stc.dw");
const UI32			CIns_666_stc_dw::m_numop = 2;
const BS_IPRV		CIns_666_stc_dw::m_priviledge(0x0);
const BS_ICAT		CIns_666_stc_dw::m_category(0x0);
const BS_IBHV		CIns_666_stc_dw::m_behavior(0x2);
/////////////////////////////////////////////////////////
// InsID :: 667
// Class :: resbank
/////////////////////////////////////////////////////////
const UI32		    CIns_667_resbank::m_id = 667;
const std::string	CIns_667_resbank::m_mne("resbank");
const UI32		    CIns_667_resbank::m_numop =0;
const BS_IPRV		CIns_667_resbank::m_priviledge(0x8);
const BS_ICAT		CIns_667_resbank::m_category(0x0);
const BS_IBHV		CIns_667_resbank::m_behavior(0x01);

void CIns_667_resbank::Regulate(IRegulation* pReg) {
	FROG_ASSERT(pReg);
	FROG_ASSERT(pReg->m_pSim);
	UI32 RBIP=0;
	UI32 RBNR=0;
	UI32 RBCR0=0;
	//System will be updated by resbank instruction.
	UI32 FPSR=0;
	UI32 EIIC=0;
	UI32 EIPSW=0;
	UI32 EIPC=0;

    auto IsSV = [=]() {
        UI32 psw = 0, pswh = 0;
        pReg->m_pSim->ReadNcReg(&pswh, 15, 0);
        if ((pswh & 0x80000000) != 0) {
            pReg->m_pSim->ReadNcReg(&psw, 5, 9);	//GMPSW
        } else {
            pReg->m_pSim->ReadNcReg(&psw, 5, 0);  //PSW
        }
        return ((psw & 0x40000000) == 0);
    };

	// Reading RBIP value from CFOREST. 
	if (!(this->IsRegulate()) && IsSV()) {
		if (pReg->m_pSim->ReadSysRegister(&RBIP, "RBIP", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		// Reading RBNR value from CFOREST.
		if (pReg->m_pSim->ReadSysRegister(&RBNR, "RBNR", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}

        	// SYSERR will occur. Do not need to preset memory
        	if(RBNR == 0) {
        	    this->SetRegulate(true);
        	    return;
        	}

		// Reading RBRC0 value from CFOREST.
		if (pReg->m_pSim->ReadSysRegister(&RBCR0, "RBCR0", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		//!< Reading system register is updated by resbank
		if (pReg->m_pSim->ReadSysRegister(&FPSR, "FPSR", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		// Reading EIIC value from CFOREST.
		if (pReg->m_pSim->ReadSysRegister(&EIIC, "EIIC", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		// Reading EIPSW value from CFOREST.
		if (pReg->m_pSim->ReadSysRegister(&EIPSW, "EIPSW", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
		// Reading EIPC value from CFOREST.
		if (pReg->m_pSim->ReadSysRegister(&EIPC, "EIPC", pReg->m_ht) != true) {
			std::runtime_error excep("Simulator error : Read GR");
			throw excep;
		}
	 
		const UI32 SaveMode0 = 96;
		const UI32 SaveMode1 = 144;
		const UI32 PSIZE = 4;
		UI32 current=0;
		UI32 startAddress;
		// Calculating range of init memory.
		if ((RBCR0>>16)==0){
			startAddress = RBIP - SaveMode0*RBNR;
			current = 20;
		} else  {
			startAddress = RBIP - SaveMode1*RBNR;
			current = 32;
		}

		while (current > 0) {
			pReg->m_vEa.push_back(std::pair<UI32,UI32>(startAddress, 4));
			startAddress += 4;
			current--;
		}
		//!< Preset system register. 
		pReg->m_pSim->PresetMemory(true ,0 ,startAddress, PSIZE, (FPSR & 0xffffffff));
		startAddress += 4;
		pReg->m_pSim->PresetMemory(true ,0 ,startAddress, PSIZE, (EIIC & 0xffffffff));
		startAddress += 4;
		pReg->m_pSim->PresetMemory(true ,0 ,startAddress, PSIZE, (EIPSW & 0xffffffff));
		startAddress += 4;
		pReg->m_pSim->PresetMemory(true ,0 ,startAddress, PSIZE, (EIPC & 0xffffffff));
		this->SetRegulate(true);
	}
}
/////////////////////////////////////////////////////////
// InsID :: 668
// Class :: stm.gsr
/////////////////////////////////////////////////////////
const UI32		CIns_668_stm_gsr::m_id = 668;
const std::string	CIns_668_stm_gsr::m_mne("stm.gsr");
const UI32		CIns_668_stm_gsr::m_numop =1;
const BS_IPRV		CIns_668_stm_gsr::m_priviledge(0x8);//HV priviledge
const BS_ICAT		CIns_668_stm_gsr::m_category(0x8);//MPU
const BS_IBHV		CIns_668_stm_gsr::m_behavior(0x2);//Store memory


/////////////////////////////////////////////////////////
// InsID :: 669
// Class :: stm.mp
/////////////////////////////////////////////////////////
std::string CIns_669_stm_mp::GetCode() {
	std::stringstream ss;
	
	ss << "stm.mp " << opr(0)->GetCode();
	ss << "-" << opr(1)->GetCode();
	ss << ", " << opr(2)->GetCode();
	return ss.str();
}
const UI32			CIns_669_stm_mp::m_id = 669;
const std::string	CIns_669_stm_mp::m_mne("stm.mp");
const UI32			CIns_669_stm_mp::m_numop =3;
const BS_IPRV		CIns_669_stm_mp::m_priviledge(0xC);//HV and SV priviledge
const BS_ICAT		CIns_669_stm_mp::m_category(0x8);//MPU
const BS_IBHV		CIns_669_stm_mp::m_behavior(0x2);//Store memory

void CIns_669_stm_mp::Regulate(IRegulation* pReg) {
    UI32 rh = this->opr(0)->Idx();
    UI32 rt = this->opr(1)->Idx();

    if (rh <= rt) {
        // Calculate size of instruction
        if (this->opr(2)->GetConstraint()) {
            UI32 Ins_size = (rt - rh + 1) * 4 * 3;
            this->opr(2)->GetConstraint()->SetSize(Ins_size);
        }
        IInstruction::Regulate(pReg);// Call original regulation
    }
}

/////////////////////////////////////////////////////////
// InsID :: 670
// Class :: ldm.gsr
/////////////////////////////////////////////////////////
const UI32			CIns_670_ldm_gsr::m_id = 670;
const std::string	CIns_670_ldm_gsr::m_mne("ldm.gsr");
const UI32			CIns_670_ldm_gsr::m_numop =1;
const BS_IPRV		CIns_670_ldm_gsr::m_priviledge(0x8);//HV priviledge
const BS_ICAT		CIns_670_ldm_gsr::m_category(0x8);//MPU
const BS_IBHV		CIns_670_ldm_gsr::m_behavior(0x1);//Load memory

void CIns_670_ldm_gsr::Regulate(IRegulation* pReg) {
    FROG_ASSERT(pReg);
    FROG_ASSERT(pReg->m_pSim);

    UI32 nStart_Address = 0;//start address of memory area is stored system register value
    const UI32 PSIZE = 4;

    IInstruction::Regulate(pReg);//Call original regulation

    if (pReg->Pass()) {
        pReg->m_pSim->ReadGrReg(&nStart_Address, (SI32)this->opr(0)->Idx(), pReg->m_ht);
        if (!this->opr(0)->GetConstraint()->InRange(nStart_Address)) {// if value of general register is not regulated sucessfully
            pReg->ReSim();
            pReg->ReAsm();
            return;
        }
        std::vector< std::pair<std::string, UI32> > lst_updated_sysreg;//first: system register name, second: offset addr
        std::vector< std::pair<std::string, UI32> >::iterator itr;
        nStart_Address &= 0xFFFFFFFC;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("FPSR", nStart_Address));
        nStart_Address += 8;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("CTPC", nStart_Address));
        nStart_Address += 8;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("CTBP", nStart_Address));
        nStart_Address += 12;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("SCBP", nStart_Address));
        nStart_Address += 4;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("RBCR0", nStart_Address));
        nStart_Address += 4;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("RBCR1", nStart_Address));
        nStart_Address += 4;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("RBNR", nStart_Address));
        nStart_Address += 4;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("RBIP", nStart_Address));
        nStart_Address += 20;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("MPIDX", nStart_Address));
        nStart_Address += 4;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("GMEIPC", nStart_Address));
        nStart_Address += 16;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("GMPSW", nStart_Address));
        nStart_Address += 28;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("GMEBASE", nStart_Address));
        nStart_Address += 4;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("GMINTBP", nStart_Address));
        nStart_Address += 16;
        lst_updated_sysreg.push_back(std::pair<std::string, UI32>("GMMPM", nStart_Address));

        for (itr = lst_updated_sysreg.begin(); itr != lst_updated_sysreg.end(); itr++) {
            std::string reg_name = itr->first;
            UI32 offset_addr = itr->second;
            UI32 reg_value = 0;
            UI64 mem_value = 0;
            if (pReg->m_pSim->ReadSysRegister(&reg_value, reg_name, pReg->m_ht) != true) {
                std::runtime_error excep("Simulator error : Read GR");
                throw excep;
            }
            // Preset system register. 
            pReg->m_pSim->PresetMemory(true, 0, offset_addr, PSIZE, reg_value);

            pReg->m_pSim->ReadMemory(offset_addr, PSIZE, &mem_value);
            if (reg_value != mem_value) {//Confirm whether memory is preset sucessfully
                pReg->GiveUp();
                return;
            }
        }
    }
}


/////////////////////////////////////////////////////////
// InsID :: 671
// Class :: ldm.mp
/////////////////////////////////////////////////////////
std::string CIns_671_ldm_mp::GetCode() {
	std::stringstream ss;
	
	ss << "ldm.mp " << opr(0)->GetCode();
	ss << ", " << opr(1)->GetCode();
	ss << "-" << opr(2)->GetCode();
	return ss.str();
}

const UI32		    CIns_671_ldm_mp::m_id = 671;
const std::string	CIns_671_ldm_mp::m_mne("ldm.mp");
const UI32		    CIns_671_ldm_mp::m_numop = 3;
const BS_IPRV		CIns_671_ldm_mp::m_priviledge(0xC);//HV and SV
const BS_ICAT		CIns_671_ldm_mp::m_category(0x8);//ICAT_MPU
const BS_IBHV		CIns_671_ldm_mp::m_behavior(0x1);//LOAD_MEMORY

void CIns_671_ldm_mp::Regulate(IRegulation* pReg) {
    FROG_ASSERT(pReg);
    FROG_ASSERT(pReg->m_pSim);
    UI32 rh = this->opr(1)->Idx();
    UI32 rt = this->opr(2)->Idx();
    UI32 PC_LDM_MP = 0, PC_SYNCI = 0;
    pReg->m_pSim->ReadPC(&PC_LDM_MP);
    PC_SYNCI = PC_LDM_MP + 4;
   
    if (rh <= rt) {
        IValConstraint* constraint = this->opr(0)->GetConstraint();
        UI32 idx = 0;
        UI32 nStart_Address = 0;
        const UI32 PSIZE = 4U;
      
        // Start address of memory area is stored MPLA, MPUA, MPAT register value
        pReg->m_pSim->ReadGrReg(&nStart_Address, (SI32)this->opr(0)->Idx(), pReg->m_ht);
        nStart_Address &= 0xFFFFFFFC;

        if (constraint != nullptr && constraint->m_bIsChangeSize == false) {
            // Conventional and guest mode use m_mpdemand[0] together
            UI32 mdp_operand = g_prf->m_mpdemand[0] & 0x1f;
            UI32 mdp_operand_hm = g_prf->m_mpdemand[1] & 0x1f;
            std::map<UI32, UI32> RandomList;
            std::map<UI32, UI32>::iterator itr;

            // Get area to random range for LDM.MP
            if (mdp_operand != 0) RandomList.insert(std::make_pair(0, mdp_operand - 1));
            if (mdp_operand_hm != 0) {
                RandomList.insert(std::make_pair(mdp_operand + 1, mdp_operand_hm - 1));
                if (mdp_operand_hm != g_hwInfo->m_mpnum - 1) RandomList.insert(std::make_pair(mdp_operand_hm + 1, g_hwInfo->m_mpnum - 1));
            } else if (mdp_operand != g_hwInfo->m_mpnum - 1) {
                RandomList.insert(std::make_pair(mdp_operand + 1, g_hwInfo->m_mpnum - 1));
            }

            do {
                idx = g_rnd.GetRange((UI32)0, RandomList.size() - 1);
                itr = RandomList.begin();
                std::advance(itr, idx);
            } while (itr->first > itr->second);
            // Random new range for LDM.MP
            rh = g_rnd.GetRange(itr->first, itr->second);
            rt = g_rnd.GetRange(rh, itr->second);
            // Set new range
            this->opr(1)->Replace(rh);
            this->opr(2)->Replace(rt);
            // Calculate size of instruction
            UI32 Ins_size = (rt - rh + 1) * 4 * 3;
            constraint->SetSize(Ins_size);
            constraint->m_bIsChangeSize = true;
        }
        IInstruction::Regulate(pReg);// Call original regulation

        if (pReg->Pass()) {
            // Remove the instruction in case of MPU protect at LDM.MP but do not protect at SYNCI
            if (g_sim->IsMIPexception(PC_LDM_MP, 4) == NO_ERROR && g_sim->IsMIPexception(PC_SYNCI, 2) != NO_ERROR) {
                pReg->GiveUp();
                return;
            }

            UI32 mip_area_gm = g_prf->m_mpdemand[0] >> 16;
            UI32 mip_area_hm = g_prf->m_mpdemand[1] >> 16;

            if (g_sim->IsMIPexception(PC_LDM_MP, 4) != NO_ERROR &&
                ((rh <= mip_area_gm && mip_area_gm <= rt) || (rh <= mip_area_hm && mip_area_hm <= rt)) ) {
                pReg->GiveUp();
                return;
            }

            UI32 nStart_Address_first_entry = nStart_Address;
            UI32 nEnd_Address_last_entry = nStart_Address_first_entry + (rt - rh + 1) * (3 * 4);
            // Preset memory for Rom, Ram area if it into range of LDM.MP
            for (idx = rh; idx <= rt; idx++) {             
                UI32 mpla = pReg->m_pSim->GetMPLA(idx);
                UI32 mpua = pReg->m_pSim->GetMPUA(idx) | 0x3;
                UI32 mpat = pReg->m_pSim->GetMPAT(idx);

                if (g_prf->IsWorkMPURegionByIdx(idx) || (mpla <= PC_SYNCI && PC_SYNCI <= mpua) || !(nEnd_Address_last_entry < mpla && nStart_Address_first_entry > mpua)) {
                    // if memory area has already preset, remove the instruction
                    if (pReg->m_pSim->IsInitMemory(nStart_Address, 3 * 4) == false) {
                        pReg->GiveUp();
                        return;
                    }

                    pReg->m_pSim->PresetMemory(true, pReg->m_ht, nStart_Address, PSIZE, mpla);
                    pReg->m_pSim->PresetMemory(true, pReg->m_ht, nStart_Address + 4, PSIZE, mpua);
                    pReg->m_pSim->PresetMemory(true, pReg->m_ht, nStart_Address + 8, PSIZE, mpat);
                }
                nStart_Address += (3 * 4); // each entry has three register MPLA, MPUA, MPAT
            }
        }
    }
}
