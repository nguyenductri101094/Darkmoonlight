#ifndef EXCEPTION_H_
#define EXCEPTION_H_

#include "ifexception.h"
#include "ifbreakparam.h"

class CException : public IException
{
public:
	CException();
	virtual ~CException();

	/**
	 * @brief セットアップが必要な場合、このインターフェースを実装します。
	 */
	virtual IException* Setup();		
	

	/**
	 * @brief	指定された例外要因コードに対応する文字列を返します。
	 * @param	code 例外要因コード値
	 * @return	例外名文字列
	 */
	virtual UI32 GetWeight(UI32 key) {
		return IException::GetWeight(key);
	}

	/**
	 * @brief	Get Exception id by name
	 * @param	exception name
	 * @return	exception id
	 */
	virtual UI32 GetKey(std::string name) {
		return IException::GetKey(name);
	}
	
	/**
	 * @brief	指定された例外要因コードに対応する文字列を返します。
	 * @param	code 例外要因コード値
	 * @return	例外名文字列
	 */
	virtual IExceptionConfig* GetConfig(UI32 key) {
		return IException::GetConfig(key);
	}	
	
	/**
	 * @brief	例外情報をクリアします
	 */
	virtual void Clear() {
		std::map <UI32,IExceptionConfig*>::iterator i;
		for (i = m_mapExcep.begin(); i != m_mapExcep.end(); i++) {
			delete i->second;
		}
		m_mapExcep.clear();
	}

	/**
	 * @brief	設定された確率から例外の発生を許可するかどうかを決定します。
	 * @param	code 例外要因コード値
	 * @return	許可する場合、真を返します。
	 */
	virtual bool RaiseException(UI32 key) {
		return IException::RaiseException(key);
	}
	
	/**
	 * @brief	設定された確率から例外の発生を許可するかどうかを決定します。
	 * @param	code 例外要因コード値
	 * @return	許可する場合、真を返します。
	 */
	virtual bool AccesptException(UI32 key) {
		return IException::AccesptException(key);
	}

	/**
	 * @brief	設定された確率から例外の発生を許可するかどうかを決定します。
	 * @param	code 例外要因コード値
	 * @return	許可する場合、真を返します。
	 */
	virtual void CountUp(UI32 key) {
		IException::CountUp(key);
	}

    /**
     * @brief 重み考慮BPAMの値取得
     * @return BPAMの値 UI32
     */
    virtual UI32 GetBPAM() {
        return IException::GetBPAM();
    }

    /**
     * @brief 重み考慮BPDMの値取得
     * @return BPDMの値 UI32
     */
    virtual UI32 GetBPDM() {
        return IException::GetBPDM();
    }

	/**
	 * @brief ブレークの発生頻度を取得する 
     * @retrun パーセンテージの値(0-100)
	 */
	virtual UI32 GetBreakPointWeight() {
        return IException::GetBreakPointWeight();
    }

    /**
     * @brief ブレーク種決定
     */
    virtual UI32 GetBreakType() {
        return IException::GetBreakType();
    }

	/**
     * @brief Get channel in sequential break
     */
	virtual void GetChannelInSequential(UI32* SQ0, UI32* SQ1) {
		IException::GetChannelInSequential(SQ0, SQ1);
	}

	/**
	 * @brief チャネル数を返す
	 */
	virtual UI32 GetNumOfChannels() {
		return IException::GetNumOfChannels();
	}

    /**
     * @brief チャネル設定処理
     */
	virtual void SetChannel(UI32* bpc, UI32* addr_mask, UI32* data_mask) {
		return IException::SetChannel(bpc, addr_mask, data_mask);
	}
    /**
     * @brief 重み考慮BPC.GEの値取得
     * @return BPC.GEの値 UI32(0-7)
     */
    virtual UI32 GetBPC_GE() {
        return IException::GetBPC_GE();
    }

    /**
     * @brief 重み考慮BPC.TYの値取得
     * @return BPC.TYの値 UI32(0-7)
     */
    virtual UI32 GetBPC_TY() {
        return IException::GetBPC_TY();
    }

	/** 
	 * @brief Retrieve list of exception that can cause exception with specified code
	 * @param exception cause code
	 * @return list of exception config
	 */
	virtual std::vector<IExceptionConfig*> GetConfigByCode (UI32 code) {
		return IException::GetConfigByCode(code);
	}
};

#endif /*EXCEPTION_H_*/
