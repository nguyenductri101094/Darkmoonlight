from sys import argv

script, filename = argv

f_in = open(filename , 'r');
f_out = open("MPU_coverage.log",'w')

addr = set()
readfile = list()

for line in f_in:
	line = line.split()
	readfile.append(line)
	
for line in readfile:
	for attr in line:
		if "MEA" in attr:
			attr = attr[5:]
			addr.add(attr)
		
addr = sorted(addr)

for i in addr:
	f_out.write(i)
	f_out.write('\n')

f_in.close()
f_out.close()
			