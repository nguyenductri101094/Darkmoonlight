Usage: 											
 ./weightfile_checker.py --input_file_path  <file_name>   --peid pe_num1 pe_num2  >   log.txt 											

 --help: To get help message about usage. 
 --input_file_path  <file_name> : Specify path and file name will be check.   
 --peid pe_num1 pe_num2  : Identify name of profile will be check in multi-core(Can not specify)											
If not specify 	--input_file_path  <file_name> default folder will be apply to check.
									
Default:											
 --input_file_path  sample/*.profile  											
											
Example 											
In sample there are pe00.wt, pe01.wt, pe02.wt, pe03.wt, sample.profile, sample1.profile, sreg.profile.	
										
./weightfile_checker.py --input_file_path  sample/*.profile  > log.txt											
>> Weight file will check only  weight file sample.profile,  sample1.profile 											
./weightfile_checker.py --input_file_path  sample/sample.profile  > log.txt											
>> Weight file will check only sample.profile											
./weightfile_checker.py --input_file_path  sample/pe??.wt --peid 01 02  > log.txt											
 >> Weight file will check only pe01.wt and pe02.wt											
