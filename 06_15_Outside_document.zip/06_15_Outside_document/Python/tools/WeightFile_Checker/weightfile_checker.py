#! /usr/bin/python
# -*- coding: utf-8 -*-
import sys;
import os
import os.path
import re;
from subprocess import Popen, PIPE
import random;
import glob;
import array
import copy
import pdb
mxu_common = [];
inst_csv = [];
exp_csv = [];
machine_setting_list = [];
rom_address = [];
ram_address = [];
mpu_setting = [];
fpu_single_data = [];
fpu_double_data = [];
list_config = [];
default_path = "sample/*.profile";
input_file_path = [];
pe_list = [];
ram_list = [];
rom_list = [];
pe_name = [];
att = "";
bit = False;
att_I = False;
# TODO:
# HT_NUM = 16; 
# VM_NUM = 16; 

f_r1 = 0;

# Get command parameter
def get_arg():
    global input_file_path;
    argvs = sys.argv;
    num = 0;
    arg_sw = 0;
    for i in argvs:
        num = num + 1;
        if num == 1 :
            continue;
        if len(i) > 1 and i[0:2] == "--" :
            arg_tmp = 0;
            if i == "--input_file_path"     : arg_tmp = 1;
            if i == "--peid"                : arg_tmp = 2;
            if i == "--help" or i == "--h"  : help_message();
            else: arg_sw = arg_tmp;
            continue;
        else:
            if len(i) > 0 and i[0:1] == "-" :
                arg_tmp = 0;
                if i == "-h" or i == "-help"   : help_message();
                if arg_tmp == 0 : arg_sw = 9;
                else: arg_sw = arg_tmp;
                continue;

        if arg_sw == 1 :
            if not os.path.exists(sys.argv[num -1]):
                print "SYSTEM_ERROR: File %s is not found!"%(argvs[num - 1]);
                sys.exit();
            input_file_path.append(i) ;

        if arg_sw == 2:
            pe_list.append(i);

    if len(pe_list) > 0:
        for pe in pe_list:
            for file in input_file_path:
                if pe in file:
                    pe_name.append(file) ;
            if len(pe_name) == 0:   
                print "SYSTEM_ERROR: File %s is not found in input files!"%(pe); 
                sys.exit();
        input_file_path = pe_name;
  
    if len(input_file_path) == 0:
        print "\n*********SYSTEM_MESSAGE: Not specify --input_file_path <file_name>*****************";
        print "Executing all file with extension .profile in default folder './sample'\n";
        input_file_path.append(default_path);
        return; 
def help_message():
    print "**********************************************************************";
    print "\nusage:  ./weightfile_checker.py --input_file_path  <file_name>";
    print " Specification extension or file name: ";
    print "     Add Option --peid pe_number1 pe_number2 to limmited file to check";
    print " Default file ./sample/*.profile\n";
    print "**********************************************************************";
    sys.exit();

# Check decimal number
def Is_num(s):
    try:
        int(s);
        return True;
    except ValueError:
        return False ;

# Check hecxan
def Is_hex(s):
    try:
        int(s,16);
        return True;
    except ValueError:
        return False ;

# ::INSTRUCTION
def check_instruction(ins_name):
    for i in range(len(ins_name)) :
        error = 0;
        if Is_num(ins_name[i][1]) == False:
            print "WARNING ::INSTRUCTION_GLOBAL:ratio %s is wrong value."% (ins_name[i][1]);
            error = error + 1;
        else: 
            ratio = int(ins_name[i][1]);
            if ratio < 0 or ratio > 65536 :
                print "WARNING ::INSTRUCTION_GLOBAL: ratio %s is out of range."% (ins_name[i][1]);
                error = error + 1;

        if len(ins_name[i]) > 2 :
            for j in range(2, len(ins_name[i])):
                if Is_num(ins_name[i][j]) == False :
                    print "WARNING ::INSTRUCTION_GLOBAL:sequencial %s is wrong value "%(ins_name[i][j]);
                    error = error + 1;
                else:
                    if int(ins_name[i][j]) > 64 or int(ins_name[i][j]) < 0 :
                        print "WARNING ::INSTRUCTION_GLOBAL: sequencial %s is out of range "%(ins_name[i][j]) ;
                        error = error + 1;
        if error > 0:
            print "%s" %(ins_name[i]);

# ::EXCEPTION
def check_exception(excp_csv):
    for i in range(len(excp_csv)) :
        if Is_num(excp_csv[i][1]) == False:
            print "WARNING ::EXCEPTION_GLOBAL: ratio %s is wrong value."%(excp_csv[i][1]);
            print "%s" % (excp_csv[i]); 
        else :
            if int(excp_csv[i][1]) > 100 or int(excp_csv[i][1]) < 0:
                print "WARNING ::EXCEPTION_GLOBAL: ratio %s is out of range."%(excp_csv[i][1]);
                print "%s" % (excp_csv[i]);


# ::MACHINE_SETTING
def check_machine_setting( machine_setting) :
    if len(machine_setting) == 0:
        print "WARNING ::MACHINE_SETTING: Not specify setting for machine ";
    else:
        if len(machine_setting) > 1:
            print "WARNING ::MACHINE_SETTING: Multi setting for machine " ;
            for i in range(len(machine_setting)) :
                print "%s " % (machine_setting[i]);

    # Thread Context
    for i in range(len(machine_setting_list)) :
        error = 0;
        contextH = machine_setting_list[i][2];
        if contextH != "NT" :
            if contextH[0:3] != "HT#" :
                print "ERROR ::MACHINE_SETTING: %s is Illigal." % (contextH) ;
                error = error + 1;
            else:
                htid = int(contextH[3:], 0);
                if htid != 0: 
                    print "ERROR ::MACHINE_SETTING: Not support multi-thread";
                    error = error + 1;

                # TODO: Check htid in range
                # if htid > HT_NUM :
                    # print "ERROR ::MACHINE_SETTING: %s is Over then HT_NUM (= %d).\n" % (contextH, HT_NUM) ;

    # Sort machine setting by ThreadContext
        no_master_thread = 0;
        old_vmid = 0;
        old_htid = 0;
        cur_vmid = 0;
        cur_htid = 0;
        machine_mode = machine_setting_list[i][1];
        if machine_mode != "MT" and machine_mode != "ST":
            print "ERROR ::MACHINE_SETTING: %s is Illigal." % (machine_mode) ;
            error = error + 1;
        thread_mode = machine_setting_list[i][3];
        if thread_mode != "UM" and thread_mode != "SV":
            print "ERROR ::MACHINE_SETTING: %s is Illigal." % (thread_mode) ;
            error = error + 1;
        contextM = machine_setting_list[i][0];
        if contextM != "NM" :
            if contextM[0:3] != "VM#" :
                print "ERROR ::MACHINE_SETTING: %s is Illigal." % (contextM) ;
                error = error + 1;
            vmid = int(contextM[3:], 0);
            # TODO: Check vmid in range?
            # if vmid > VM_NUM : 
                # print "ERROR ::MACHINE_SETTING: %s is Over then VM_NUM (= %d) .\n" % (contextM, VM_NUM);
                # continue;

            # old_htid = cur_htid;
            # cur_vmid = int(contextM[3:], 0);
            # cur_htid = int(machine_setting_list[i][2][3:], 0);
            # if cur_vmid < old_vmid :
                # print "ERROR ::MACHINE_SETTING: \"VM#%d\" of HT#%d is greater than \"VM#%d\" of HT#%d.\n" % (old_vmid, old_htid, cur_vmid, cur_htid);
                # continue;

            # if cur_vmid > old_vmid :
                # no_master_thread = 0;
                # old_vmid = cur_vmid;
        if error > 0:
            print "%s" %(machine_setting_list[i]);

#Check overlap memory in single mode
def check_overlap(start, end, i, address):
    global att;
    if address == 'rom_address': section_name = '::ROM_ADDRESS';
    else: section_name = '::RAM_ADDRESS';
    address.sort( key=lambda x: int(x[0], 16)) ;
    for j in range(i+1,len(address)):
        csv_rom = address[j]; 
        new_start = int(csv_rom[0], 16);
        new_end = int(csv_rom[1], 16);
        new_att = csv_rom[2].upper();
        if new_start < end :
            if att == new_att:
                print "WARNING %s: Overlap %s area between 0x%08x-0x%08x and 0x%08x -0x%08x " % (section_name, att, new_start, new_end, start, end);
            else : 
                if att in "RW" and new_att in "RW":
                    print "WARNING %s: Overlap %s and %s area between 0x%08x-0x%08x and 0x%08x -0x%08x " % (section_name, new_att, att, new_start, new_end, start, end);
                else:
                    print "ERROR %s: Overlap %s and %s area between 0x%08x-0x%08x (%s) and 0x%08x -0x%08x (%s)" % (section_name, new_att, att, new_start, new_end, new_att, start, end, att);


# ::ROM_ADDRESS
def check_rom_address(rom_address) :
    global att;
    global att_I;
    rom_address.sort( key=lambda x: int(x[0], 16)) ;
    start_addr = -1; # Dummy value
    end_addr = -1; # Dummy value
    new_start_addr = 0;
    new_end_addr = 0;
    new_att = '';
    area_I = 1;
    
    # Check ROM_ADDRESS is not specified
    if len(rom_address) == 0 :
        print "ERROR ::ROM_ADDRESS: Not be specified";
        return;
    
    for i in range(len(rom_address)) :
        csv = rom_address[i];
        error = 0;
        # Check invalid attribute
        att = csv[2].upper();
        if att not in ("IUTSRW") or len(att) > 2:
            print "ERROR ::ROM_ADDRESS: Invalid attribute (%s)" % (csv[2]);
            error = error + 1;
        else:
            if len(att) == 2 and att not in ("RW", "WR") :
                print "ERROR ::ROM_ADDRESS: Invalid attribute (%s)" % (csv[2]);
                error = error + 1;

        #Check first "I" area
        if att == 'I'and area_I == 1 and att_I == False:
            if int(csv[1],16) < 0x000003ff or int(csv[0],16) != 0x00000000:
                print "ERROR ::ROM_ADDRESS: The first 'I' area is invalid";
                att_I = True;
                error = error + 1;
            area_I = area_I + 1;

        # Check invalid ratio
        if Is_num(csv[4]) == False:
            print "ERROR ::ROM_ADDRESS: Invalid ratio (%s)" % (csv[4]);
            error = error + 1;

        # Check invalid access to ROM
        if 'W' in att :
            print "WARNING ::ROM_ADDRESS: Write access to ROM (%s)" % (csv[2]);
        if att in ("ST") :
            print "WARNING ::ROM_ADDRESS: Use ROM for temporary (%s)" % (csv[2]);

        # Check LNK value
        if csv[3] not in ('0','1') :
            print "ERROR ::ROM_ADDRESS: Invalid LNK value (%s)" % (csv[3]);
            error = error + 1;
        if error > 0:
            print "%s" %(csv);

        # Check overlap
        start_addr = int(csv[0], 16);
        end_addr = int(csv[1], 16);
        check_overlap(start_addr, end_addr, i, rom_address);

# ::RAM_ADDRESS
def check_ram_address(elements) :
    global att_I;
    ram_address.sort( key=lambda x: int(x[0], 16)) ;
    start_addr = -1; # Dummy value
    end_addr = -1; # Dummy value
    new_start_addr = 0;
    new_end_addr = 0;
    new_att = '';
    att_list = [];
    area_I = 1;
    RmW_flag = 0; # Check RmW memory area
    
    if len(elements) == 0 :
        print "ERROR ::RAM_ADDRESS: Not be specified";
        return;
    
    for i in range(len(elements)) :
        csv = elements[i];
        error = 0;

        # Check invalid attribute
        att = csv[2].upper();
        att_list.append(att);
        if len(att) == 2 :
            if att not in ("RW", "WR") :
                print "ERROR ::RAM_ADDRESS: Invalid attribute (%s)" % (csv[2]);
                error = error + 1;
            else :
                RmW_flag = 1;
        else :
            if len(att) > 1 or att not in ("IUTSRW") :
                print "ERROR ::RAM_ADDRESS: Invalid attribute (%s)" % (csv[2]);
                error = error + 1;
           
        #Check first "I" area
        if att == 'I'and area_I == 1 and att_I == False:
            if int(csv[1],16) < 0x000003ff or int(csv[0],16) != 0x00000000:
                print "ERROR ::RAM_ADDRESS: The first 'I' area is invalid";
                att_I = True;
                error = error + 1;
            area_I = area_I + 1;

        # Check invalid ratio
        if Is_num(csv[4]) == False:
            print "ERROR ::RAM_ADDRESS: Invalid ratio (%s)" % (csv);
            error = error + 1;

        # Check LNK value
        if csv[3] not in ('0','1') :
            print "ERROR ::RAM_ADDRESS: Invalid LNK value (%s)" % (csv[3]);
            error = error + 1;

        if error > 0:
            print "%s" %(csv);
        # Check overlap
        start_addr = int(csv[0], 16);
        end_addr = int(csv[1], 16);
        check_overlap(start_addr, end_addr, i, ram_address);

    # Check specify attribute "S", "T" in RAM
    if "S" not in att_list :
        print "ERROR ::RAM_ADDRESS: Not specify attribute \"S\" in RAM ";
    if "T" not in att_list:
        print "WARNING ::RAM_ADDRESS: Not specify attribute \"T\" in RAM ";
    if RmW_flag == 0:
        print "WARNING ::RAM_ADDRESS: Not specify RmW memory";
        
        if "W" not in att_list:
            print "WARNING ::RAM_ADDRESS: Not specify attribute \"W\" in RAM ";
        if "R" not in att_list:
            print "WARNING ::RAM_ADDRESS: Not specify attribute \"R\" in RAM ";

# ::MXU_COMMON_AREA
def check_mxu_common(mxu_common_area) :
    # Check redundant MXU config
    if(len(mxu_common_area) > 1) :
        print "WARNING ::MXU_COMMON_AREA: More config for MXU. Only the first config will be applied";
    
    for i in range(len(mxu_common_area)) :
        belong_rom = False;
        belong_ram = False;
        error = 0;
        rom_start = mxu_common_area[i][0];
        rom_end = rom_start + mxu_common_area[i][1];
        ram_start = mxu_common_area[i][2];
        ram_end = ram_start + mxu_common_area[i][3];
        if rom_start >= ram_start and rom_start <= ram_end :
            print "ERROR ::MXU_COMMON_AREA: Overlap ROM RAM area %s" % (mxu_common_area[i]);
        if ram_start >= rom_start and ram_start <= rom_end : 
            print "ERROR ::MXU_COMMON_AREA: Overlap ROM RAM area %s" % (mxu_common_area[i]);

        #Check memory belong to ROM-RAM
        rom_address.sort( key=lambda x: int(x[0], 16)) ;
        for row in range(len(rom_address)):
            rom_add = rom_address[row];
            if rom_start >= rom_add[0] and rom_end <= rom_add[1]:
                belong_rom = True;
                break;
            
        ram_address.sort( key=lambda x: int(x[0], 16)) ;
        for row in range(len(ram_address)):
            ram_add = ram_address[row];
            if ram_start >= ram_add[0] and ram_end <= ram_add[1]:
                belong_ram = True;
                break;

        if belong_rom == False:
            print "WARNING ::MXU_COMMON_AREA: ROM memory %s %s does not belong to ROM_ADRRESS" %(mxu_common_area[i][0], mxu_common_area[i][1]);
            error = error + 1;
        if belong_ram == False:
            print "WARNING ::MXU_COMMON_AREA: RAM memory %s %s does not belong to RAM_ADRRESS" %(mxu_common_area[i][2], mxu_common_area[i][3]);
            error = error + 1;
        if error > 0:
            print "%s" %(mxu_common_area[i]);

# ::MPU_SETTING
def check_mpu_setting(elements) :
    if len(elements) > 0:
        error = 0;
        for i in range(len(elements)) :
            mpu_config = elements[i];
            machine_context = mpu_config[0].upper();
            if len(machine_context) == 2 :
                if machine_context[0:2] != 'NM':
                    print "ERROR ::MPU_SETTING: %s Invalid value" %(machine_context);
                    error = 1; 
            else:        
                if machine_context[0:3] != 'VM#':
                    print "WARNING ::MPU_SETTING: %s Invalid value" %(machine_context);
                    error = 1;
            ASID = mpu_config[1];
            if len (ASID) > 7 and ASID[0:7] != 'random#':
                if Is_hex(ASID) == False:
                    print "WARNING ::MPU_SETTING: %s Invalid value" %(ASID);
                    error = 1;
            STATUS = mpu_config[2];
            if STATUS not in ("disable","enable",""):
                print "WARNING ::MPU_SETTING: %s Invalid value" %(STATUS);
                error = 1;
            GLOBAL = mpu_config[7];
            if GLOBAL not in ("01"):
                print "WARNING ::MPU_SETTING: %s Invalid value" %(GLOBAL);
                error = 1;
            Acc_per = mpu_config[8];
            if GLOBAL not in ("01"):
                print "WARNING ::MPU_SETTING: %s Invalid value" %(Acc_per);
                error = 1;
            if error > 0:
                print "%s" %(mpu_config);

# ::FPU_SINGLE_DATA_TYPE
def check_fpu_single_data(elements) :
    for i in range(len(elements)) :
        if elements[i][0] == "RANDOM" and elements[i][1] > 0 :
            print "WARNING ::FPU_SINGLE_DATA_TYPE: Set %s. Ignore remain setting" % (elements[i]);

# ::FPU_DOUBLE_DATA_TYPE
def check_fpu_double_data(elements) :
    for i in range(len(elements)) :
        if elements[i][0] == "RANDOM" and elements[i][1] > 0 :
            print "WARNING ::FPU_DOUBLE_DATA_TYPE: Set %s. Ignore remain setting" % (elements[i]);
            
def check_combination(): 
    # Specify bit weight for custom instruction
    global bit;
    for i in range(len(inst_csv)):
        if inst_csv[i][0] in key_bit_manipulation and inst_csv[i][1] > 0:
            bit_ins = True;
            break;
        else :
            bit_ins = False;
    if bit_ins == True and bit == False:
        print "WARNING ::RAM_ADDRESS: Not specify bit weight for custom instruction"

    # Overlap ROM-RAM 
    for i in range(len(rom_address)):
        memory_address.append(rom_address[i]);
    for i in range(len(ram_address)):
        if ram_address[i] in memory_address:
            print "WARNING: Memory area %s is defined in ROM and RAM" %(ram_address[i]);
        else:
            memory_address.append(ram_address[i]); 

    memory_address.sort( key=lambda x: int(x[0], 16)) ;
    for i in range(len(memory_address)):
        row = memory_address[i];
        start_add = int(row[0], 16);
        end_add = int(row[1], 16);
        if row in rom_address:
            mem_area = "ROM";
        else:
            mem_area = "RAM";
        for j in range(i+1,len(memory_address)):
            mem_add = memory_address[j]; 
            new_start_add = int(mem_add[0], 16);
            new_end_add = int(mem_add[1], 16);
            if mem_add in rom_address:
                new_mem_area = "ROM";
            else:
                new_mem_area = "RAM";
            if new_start_add <= end_add and new_mem_area != mem_area:
                print "ERROR: Overlap between ROM - RAM 0x%08x-0x%08x and 0x%08x -0x%08x " % (start_add, end_add, new_start_add, new_end_add);

    # Check R/W memory size
    valid_mem_att_list = [];
    for memIdx in range(len(memory_address)):
        start_addr = int(memory_address[memIdx][0], 16);
        end_addr = int(memory_address[memIdx][1], 16);
        att = memory_address[memIdx][2].upper();
        if end_addr - start_addr >= 128 :
            valid_mem_att_list.append(att);
    if "RW" not in valid_mem_att_list and "WR" not in valid_mem_att_list :
        print "WARNING: RmW memory is too small or not be specified"
        if "R" not in valid_mem_att_list :
            print "WARNING: READ memory is too small or not be specified"
        if "W" not in valid_mem_att_list :
            print "WARNING: WRITE memory is too small or not be specified"
    
    # Link bit ROM-RAM
    link = False;
    for i in range(len(rom_address)):
        if Is_num(rom_address[i][3]) == True and int(rom_address[i][3]) == 1 :
            link = True;
            break;
    for i in range(len(ram_address)):
        if Is_num(ram_address[i][3]) == True and int(ram_address[i][3]) == 1 :
            link = True;
            break;
    for i in range(len(inst_csv)):
        if inst_csv[i][0] == "Ins_172_stc_w" or inst_csv[i][0] == "Ins_098_ldl_w":
            if int(inst_csv[i][1]) > 0 and link == False :
                print "WARNING: Set \"Ins_172_stc_w\",\"Ins_098_ldl_w\" but not set lnk in ROM, RAM" 
                break;

    # Mismatch between MPU and MXU
    if len(mpu_setting) > 0 and len(mxu_common) == 0 :
        print "ERROR ::MXU_COMMON_AREA: Set MPU_SETTING but not specify MXU_COMMON_AREA"
    
    # Instruction memory area is not protected
    for mxuIdx in range(len(mxu_common)) :
        mxu_rom_start = int(mxu_common[mxuIdx][0], 16);
        mxu_rom_end    = int(mxu_common[mxuIdx][1], 16);
        for memIdx in range(len(memory_address)):
            fetch_start = int(memory_address[memIdx][0], 16);
            fetch_end = int(memory_address[memIdx][1], 16);
            att = memory_address[memIdx][2]
            if att == "I" and (mxu_rom_start > fetch_start or mxu_rom_end < fetch_end) :
                print "WARNING ::MXU_COMMON_AREA: Instruction area (0x%08x - 0x%08x) is not protected" % (fetch_start, fetch_end);

    # No specify memory protected for Exp_MIP and Exp_MDP
    area = len(mxu_common);
    for i in range(len(exp_csv)):
            if exp_csv[i][0] == "Exp_MDP" and int(exp_csv[i][1]) > 0 and area < 1:
                print "WARNING ::MXU_COMMON_AREA: Set Exp_MDP but not specify memory protected";
            if exp_csv[i][0] == "Exp_MIP" and int(exp_csv[i][1]) > 0 and area < 1:
                print "WARNING ::MXU_COMMON_AREA: Set Exp_MIP but not specify memory protected";

    # Mismatch machine context between MPU_SETTING and MACHINE_SETTING
    if len(machine_setting_list) > 0 and len(mpu_setting) > 0:
        last_machine_config = len(machine_setting_list) - 1;
        last_mpu_config = len(mpu_setting) - 1;
        machine_context = machine_setting_list[last_machine_config][0];
        if machine_context != mpu_setting[last_mpu_config][0]:
            print "ERROR ::MPU_SETTING: Missmatch machine setting between ::MACHINE_SETTING and ::MPU_SETTING "
            print "%s" % (machine_setting_list[last_machine_config]);
            print "%s" % (mpu_setting[last_mpu_config]);

# Check overlap memory in multi-core
def check_pe_overlap(section_name):
    global ram_list;
    global rom_list;
    if section_name == "ROM_ADDRESS": address = rom_list;
    else: address = ram_list;
    for pe in range(len(address)):
        ram_pe = address[pe];
        for row in range(len(ram_pe)):
            start_add = ram_pe[row][0];
            end_add = ram_pe[row][1]; 
            for next_pe in range(pe+1, len(address)):
                ram_next_pe = address[next_pe];
                for next_pe_row in range(len(ram_next_pe)):
                    new_start_add = ram_next_pe[next_pe_row][0];
                    new_end_add = ram_next_pe[next_pe_row][1];
                    if new_start_add <= start_add and start_add <= new_end_add:
                        print "ERROR MULTI-CORE1 : Overlap %s between PE%d and PE%d" %(section_name, pe, next_pe);
                        print "%s" % (ram_pe[row]);
                        print "%s" % (ram_next_pe[next_pe_row]);
                        continue;
                    if start_add <= new_start_add and new_start_add <= end_add:
                        print "ERROR MULTI-CORE2 : Overlap %s between PE%d and PE%d" %(section_name, pe, next_pe);
                        print "%s" % (ram_pe[row]);
                        print "%s" % (ram_next_pe[next_pe_row]);
                        continue;
# Multi core 
def check_multi_pe() :
    att_S = [];
    global ram_list;
    global rom_list;
    
    #Check common area "S" for PEn
    for i in range(len(list_config)) :
        pe_config = list_config[i];
        ram_sec = pe_config[4];
        rom_list.append(pe_config[3]);
        ram_pe = [];
        for j in range(len(ram_sec)) :
            ram_data = ram_sec[j];
            att = ram_data[2].upper();
            if att == 'S':
                att_S.append(ram_data);
            else:
                if att in ("IUTRW"):
                    ram_pe.append(ram_data);
        ram_list.append(ram_pe);

    if len(att_S) > 1:
        ram_att_S = att_S[0];
        for i in range(len(att_S)) :
            if att_S[i] != ram_att_S:
                print "ERROR MULTI-CORE: Area 'S' in ram is not common for multi PE";
                print "%s" % att_S[i];
                print "%s" % ram_att_S;
                break;
  
    #Check overlap ROM_ADDRESS between PEn
    check_pe_overlap("ROM_ADDRESS");

    #Check overlap RAM_ADDRESS between PEn
    check_pe_overlap("RAM_ADDRESS");

def memory_parse (elements, address_name) :
    global ram_address;
    global rom_address;
    global bit;
    address_list = [];
    if address_name == "::RAM_ADDRESS": address_list = ram_address;
    else: address_list = rom_address;
    if len(elements) != 5 :
        print "ERROR %s: %s is wrong format." % (address_name, elements);
        return;
    else:
        # Check memory specify bit weight 
        for i in range(len(elements[0])):
            if elements[0][i] == ":" :
                bit_start = i - 1;
                bit = True;
                break;
            else:
                bit = False;
                bit_start = len(elements[0]);
        for i in range(len(elements[1])):
            if elements[1][i] == ":" :
                bit_end = i - 1;
                bit = True;
                break;
            else:
                bit = False;
                bit_end = len(elements[1]);
        
        if Is_hex(elements[0][0:bit_start]) == False or Is_hex(elements[1][0:bit_end]) == False or elements[0] > elements[1]:
            print "ERROR %s: \"%s\" %s is invalid value." % (address_name, elements[0][0:bit_start],elements[1][0:bit_end]);
            print "%s" %(elements);
            return;
        if bit == True: return;
        for i in range(len(address_list)):
            if elements[0] == address_list[i][0] and elements[1] == address_list[i][1] and elements[2] != address_list[i][2] :
                print "ERROR %s: Redefine attribute for memory %s - %s" %(address_name, address_list[i][0], address_list[i][1]);
                print "%s" %(elements);
                print "%s" %(address_list[i]);
                break;
        if elements in address_list:
            print "WARNING %s: \"%s\" is duplicate." % (address_name, elements);
            address_list.remove(elements);
        address_list.append(elements);
    
def read_data(file_name):
 
    tag_sw = 0; 
    f_r1 = open(file_name , 'r');
    for line in f_r1:
        line = line.strip(" \t\n");
        if len(line) == 0 :
            continue;
        if line[0:2] == "//" :
            continue;

        element = line.split('//');
        element = element[0].split(',');
        for i in range(len(element)) :
            element[i] = element[i].strip() ;
        if element[0][0:2] == "::" :
            tag_sw = 0;
            if element[0] == "::INSTRUCTION_GLOBAL"          : tag_sw = 1; continue;
            if element[0] == "::EXCEPTION_GLOBAL"            : tag_sw = 2; continue;
            if element[0] == "::MACHINE_SETTING"             : tag_sw = 3; continue;
            if element[0] == "::ROM_ADDRESS"                 : tag_sw = 4; continue;
            if element[0] == "::RAM_ADDRESS"                 : tag_sw = 5; continue;
            if element[0] == "::MXU_COMMON_AREA"             : tag_sw = 6; continue;
            if element[0] == "::MPU_SETTING"                 : tag_sw = 7; continue;
            if element[0] == "::FPU_SINGLE_DATA_TYPE"        : tag_sw = 8; continue;
            if element[0] == "::FPU_DOUBLE_DATA_TYPE"        : tag_sw = 9; continue;

        if tag_sw == 0 and len(element) > 10:
            print "ERROR: File %s is not weight file\n" % (file_name);
            f_r1.close();
            return False;

        if tag_sw == 1 : # INSTRUCTION_GLOBAL
            global inst_csv;
            if len(element) != 2 and len(element) != 4 :
                print "WARNING ::INSTRUCTION_GLOBAL: wrong format %d field." % (len(element));
                print "%s" % (element);
                continue;

            if element[0] not in key_inst and element[0] not in key_bit_manipulation:
                print "WARNING ::INSTRUCTION_GLOBAL: \"%s\" is not found." % (element[0]);
                continue;
            else:
                for i in range(len(inst_csv)) :
                    if element[0] == inst_csv[i][0]:
                        print "WARNING ::INSTRUCTION_GLOBAL: \"%s\" is duplicate." % (element[0]);
                        inst_csv.remove(inst_csv[i]);
                        break;
                inst_csv.append(element);
            continue;

        if tag_sw == 2 : # EXCEPTION_GLOBAL
            if len(element) != 2 :
                print "ERROR ::EXCEPTION_GLOBAL: %s is wrong format." % ( element);
                continue;
            if element[0] not in key_exception :
                print "WARNING ::EXCEPTION_GLOBAL: \"%s\" is not found." % ( element[0]); 
            else:
                for i in range(len(exp_csv)) :
                    if element[0] == exp_csv[i][0]:
                        print "WARNING ::EXCEPTION_GLOBAL WARNING: \"%s\" is duplicate." % (element[0]);
                        exp_csv.remove(exp_csv[i]);
                        break;
                exp_csv.append(element); 
            continue;

        if tag_sw == 3 : # MACHINE_SETTING
            if len(element) != 5:
                print "ERROR ::MACHINE_SETTING: %s is wrong format." % (element);
                continue;
            if element in machine_setting_list:
                print "WARNING ::MACHINE_SETTING: duplicate." ;
                machine_setting_list.remove(element);
                print "%s" % ( element);
            machine_setting_list.append(element);
            continue;

        if tag_sw == 4 : # ROM_ADDRESS
            memory_parse (element, '::ROM_ADDRESS');
            continue;

        if tag_sw == 5 : # RAM_ADDRESS
            memory_parse (element, '::RAM_ADDRESS');
            continue;

        if tag_sw == 6 : # MXU_COMMON_AREA
            if len(element) != 4 :
                print "ERROR ::MXU_COMMON_AREA: %s is wrong format." % (element);
                continue;
            else:
                for i in range(len(element)):
                    if Is_hex(element[i]) == False:
                        print "ERROR ::MXU_COMMON_AREA: \"%s\" is invalid value." % (element[i]);
                        print "%s" %(element);
                if element in mxu_common:
                    print "ERROR ::MXU_COMMON_AREA:%s is duplicate."% ( element);
                    mxu_common.remove(element);
                mxu_common.append(element);
            continue;

        if tag_sw == 7 : # MPU_SETTING
            if len(element) < 1 :
                print "ERROR ::MPU_SETTING: %s is wrong format." % ( element);
                continue;
            if element in mpu_setting:
                print "WARNING ::MPU_SETTING %s is duplicate." %(element);
                mpu_setting.remove(element);
            mpu_setting.append(element);
            continue;

        if tag_sw == 8 : # FPU_SINGLE_DATA_TYPE
            if len(element) != 2 :
                print "ERROR ::FPU_SINGLE_DATA_TYPE: %s is wrong format.\n" % (element);
                continue;
            if element[0] not in key_fpu_operand :
                print "ERROR::FPU_SINGLE_DATA_TYPE: %s is not found" % (element[0]);
                continue;
            if Is_num(element[1]) == False:
                print "ERROR::FPU_SINGLE_DATA_TYPE: %s is invalid value" % (element);
                continue;
            for i in range(len(fpu_single_data)):
                if element[0] == fpu_single_data[i][0]:
                    print "WARNING::FPU_SINGLE_DATA_TYPE: %s is duplicate" % (element[0]);
                    break;
            fpu_single_data.append(element);
            continue;

        if tag_sw == 9 : # FPU_DOUBLE_DATA_TYPE
            if len(element) != 2 :
                print "ERROR ::FPU_DOUBLE_DATA_TYPE: %s is wrong format.\n" % (element);
                continue;
            if element[0] not in key_fpu_operand :
                print "ERROR ::FPU_DOUBLE_DATA_TYPE: %s is not found" % (element[0]);
                continue;
            if Is_num(element[1]) == False:
                print "ERROR::FPU_DOUBLE_DATA_TYPE: %s is invalid value" % (element);
                continue;
            if element[0] in fpu_double_data:
                print "WARNING::FPU_DOUBLE_DATA_TYPE: %s is duplicate" % (element[0]);
            fpu_double_data.append(element);
            continue;

    # Save data of multi core
    if '.wt' in file_name: 
        pe_config = [];
        pe_config.append(inst_csv);
        pe_config.append(exp_csv);
        pe_config.append(machine_setting_list);
        pe_config.append(rom_address);
        pe_config.append(ram_address);
        pe_config.append(mxu_common);
        pe_config.append(mpu_setting);
        pe_config.append(fpu_single_data);
        pe_config.append(fpu_double_data);

        list_config.append(pe_config);

    f_r1.close();

key_inst = [
    "Ins_001_add"          ,"Ins_002_add"          ,"Ins_003_addi"         ,"Ins_004_adf"          
    ,"Ins_005_and"          ,"Ins_006_andi"         ,"Ins_007_bc"           ,"Ins_008_be"           
    ,"Ins_009_bf"           ,"Ins_010_bge"          ,"Ins_011_bgt"          ,"Ins_012_bh"           
    ,"Ins_013_ble"          ,"Ins_014_bl"           ,"Ins_015_blt"          ,"Ins_016_bn"           
    ,"Ins_017_bnc"          ,"Ins_018_bne"          ,"Ins_019_bnh"          ,"Ins_020_bnl"          
    ,"Ins_021_bnv"          ,"Ins_022_bnz"          ,"Ins_023_bp"           ,"Ins_024_br"           
    ,"Ins_025_bsa"          ,"Ins_026_bt"           ,"Ins_027_bv"           ,"Ins_028_bz"           
    ,"Ins_029_bc"           ,"Ins_030_be"           ,"Ins_031_bf"           ,"Ins_032_bge"          
    ,"Ins_033_bgt"          ,"Ins_034_bh"           ,"Ins_035_ble"          ,"Ins_036_bl"           
    ,"Ins_037_blt"          ,"Ins_038_bn"           ,"Ins_039_bnc"          ,"Ins_040_bne"          
    ,"Ins_041_bnh"          ,"Ins_042_bnl"          ,"Ins_043_bnv"          ,"Ins_044_bnz"          
    ,"Ins_045_bp"           ,"Ins_046_bsa"          ,"Ins_047_bt"           ,"Ins_048_bv"           
    ,"Ins_049_bz"           ,"Ins_050_bins"         ,"Ins_051_bsh"          ,"Ins_052_bsw"          
    ,"Ins_053_callt"        ,"Ins_054_caxi"         ,"Ins_055_cll"          ,"Ins_056_clr1"         
    ,"Ins_057_clr1"         ,"Ins_058_cmov"         ,"Ins_059_cmov"         ,"Ins_060_cmp"          
    ,"Ins_061_cmp"          ,"Ins_062_ctret"        ,"Ins_063_di"           ,"Ins_064_dispose"      
    ,"Ins_065_dispose"      ,"Ins_066_div"          ,"Ins_067_divh"         ,"Ins_068_divh"         
    ,"Ins_069_divhu"        ,"Ins_070_divq"         ,"Ins_071_divqu"        ,"Ins_072_divu"         
    ,"Ins_073_ei"           ,"Ins_074_eiret"        ,"Ins_075_feret"        ,"Ins_076_fetrap"       
    ,"Ins_077_halt"         ,"Ins_078_hsh"          ,"Ins_079_hsw"          ,"Ins_080_jarl"         
    ,"Ins_081_jarl"         ,"Ins_082_jarl"         ,"Ins_083_jmp"          ,"Ins_084_jmp"          
    ,"Ins_085_jr"           ,"Ins_086_jr"           ,"Ins_087_ld_b"         ,"Ins_088_ld_b"         
    ,"Ins_089_ld_bu"        ,"Ins_090_ld_bu"        ,"Ins_091_ld_dw"        ,"Ins_092_ld_h"         
    ,"Ins_093_ld_h"         ,"Ins_094_ld_hu"        ,"Ins_095_ld_hu"        ,"Ins_096_ld_w"         
    ,"Ins_097_ld_w"         ,"Ins_098_ldl_w"        ,"Ins_099_ldsr"         ,"Ins_100_loop"         
    ,"Ins_101_mac"          ,"Ins_102_macu"         ,"Ins_103_mov"          ,"Ins_104_mov"          
    ,"Ins_105_mov"          ,"Ins_106_movea"        ,"Ins_107_movhi"        ,"Ins_108_mul"          
    ,"Ins_109_mul"          ,"Ins_110_mulh"         ,"Ins_111_mulh"         ,"Ins_112_mulhi"        
    ,"Ins_113_mulu"         ,"Ins_114_mulu"         ,"Ins_115_nop"          ,"Ins_116_not"          
    ,"Ins_117_not1"         ,"Ins_118_not1"         ,"Ins_119_or"           ,"Ins_120_ori"          
    ,"Ins_121_popsp"        ,"Ins_122_prepare"      ,"Ins_123_prepare"      ,"Ins_124_prepare"      
    ,"Ins_125_prepare"      ,"Ins_126_pushsp"       ,"Ins_127_rie"          ,"Ins_128_rie"          
    ,"Ins_129_rotl"         ,"Ins_130_rotl"         ,"Ins_131_sar"          ,"Ins_132_sar"          
    ,"Ins_133_sar"          ,"Ins_134_sasf"         ,"Ins_135_satadd"       ,"Ins_136_satadd"       
    ,"Ins_137_satadd"       ,"Ins_138_satsub"       ,"Ins_139_satsub"       ,"Ins_140_satsubi"      
    ,"Ins_141_satsubr"      ,"Ins_142_sbf"          ,"Ins_143_sch0l"        ,"Ins_144_sch0r"        
    ,"Ins_145_sch1l"        ,"Ins_146_sch1r"        ,"Ins_147_set1"         ,"Ins_148_set1"         
    ,"Ins_149_setf"         ,"Ins_150_shl"          ,"Ins_151_shl"          ,"Ins_152_shl"          
    ,"Ins_153_shr"          ,"Ins_154_shr"          ,"Ins_155_shr"          ,"Ins_156_sld_b"        
    ,"Ins_157_sld_bu"       ,"Ins_158_sld_h"        ,"Ins_159_sld_hu"       ,"Ins_160_sld_w"        
    ,"Ins_161_snooze"       ,"Ins_162_sst_b"        ,"Ins_163_sst_h"        ,"Ins_164_sst_w"        
    ,"Ins_165_st_b"         ,"Ins_166_st_b"         ,"Ins_167_st_dw"        ,"Ins_168_st_h"         
    ,"Ins_169_st_h"         ,"Ins_170_st_w"         ,"Ins_171_st_w"         ,"Ins_172_stc_w"        
    ,"Ins_173_stsr"         ,"Ins_174_sub"          ,"Ins_175_subr"         ,"Ins_176_switch"       
    ,"Ins_177_sxb"          ,"Ins_178_sxh"          ,"Ins_179_synce"        ,"Ins_180_synci"        
    ,"Ins_181_syncm"        ,"Ins_182_syncp"        ,"Ins_183_syscall"      ,"Ins_184_trap"         
    ,"Ins_185_tst"          ,"Ins_186_tst1"         ,"Ins_187_tst1"         ,"Ins_188_xor"          
    ,"Ins_189_xori"         ,"Ins_190_zxb"          ,"Ins_191_zxh"          ,"Ins_192_hvcall"       
    ,"Ins_193_hvtrap"       ,"Ins_194_ldvc_sr"      ,"Ins_195_stvc_sr"      ,"Ins_196_dst"          
    ,"Ins_197_est"          ,"Ins_198_ldtc_gr"      ,"Ins_199_ldtc_vr"      ,"Ins_200_ldtc_pc"      
    ,"Ins_201_ldtc_sr"      ,"Ins_202_sttc_gr"      ,"Ins_203_sttc_vr"      ,"Ins_204_sttc_pc"      
    ,"Ins_205_sttc_sr"      ,"Ins_206_cache"        ,"Ins_207_pref"         ,"Ins_208_tlbai"        
    ,"Ins_209_tlbr"         ,"Ins_210_tlbs"         ,"Ins_211_tlbvi"        ,"Ins_212_tlbw"         
    ,"Ins_213_dbcp"         ,"Ins_214_dbhvtrap"     ,"Ins_215_dbpush"       ,"Ins_216_dbret"        
    ,"Ins_217_dbtag"        ,"Ins_218_dbtrap"       ,"Ins_219_rmtrap"       ,"Ins_220_absf_d"       
    ,"Ins_221_absf_s"       ,"Ins_222_addf_d"       ,"Ins_223_addf_s"       ,"Ins_224_ceilf_dl"     
    ,"Ins_225_ceilf_dul"    ,"Ins_226_ceilf_duw"    ,"Ins_227_ceilf_dw"     ,"Ins_228_ceilf_sl"     
    ,"Ins_229_ceilf_sul"    ,"Ins_230_ceilf_suw"    ,"Ins_231_ceilf_sw"     ,"Ins_232_cmovf_d"      
    ,"Ins_233_cmovf_s"      ,"Ins_234_cmpf_d"       ,"Ins_235_cmpf_s"       ,"Ins_236_cvtf_dl"      
    ,"Ins_237_cvtf_ds"      ,"Ins_238_cvtf_dul"     ,"Ins_239_cvtf_duw"     ,"Ins_240_cvtf_dw"      
    ,"Ins_241_cvtf_hs"      ,"Ins_242_cvtf_ld"      ,"Ins_243_cvtf_ls"      ,"Ins_244_cvtf_sd"      
    ,"Ins_245_cvtf_sl"      ,"Ins_246_cvtf_sh"      ,"Ins_247_cvtf_sul"     ,"Ins_248_cvtf_suw"     
    ,"Ins_249_cvtf_sw"      ,"Ins_250_cvtf_uld"     ,"Ins_251_cvtf_uls"     ,"Ins_252_cvtf_uwd"     
    ,"Ins_253_cvtf_uws"     ,"Ins_254_cvtf_wd"      ,"Ins_255_cvtf_ws"      ,"Ins_256_divf_d"       
    ,"Ins_257_divf_s"       ,"Ins_258_floorf_dl"    ,"Ins_259_floorf_dul"   ,"Ins_260_floorf_duw"   
    ,"Ins_261_floorf_dw"    ,"Ins_262_floorf_sl"    ,"Ins_263_floorf_sul"   ,"Ins_264_floorf_suw"   
    ,"Ins_265_floorf_sw"    ,"Ins_266_fmaf_s"       ,"Ins_267_fmsf_s"       ,"Ins_268_fnmaf_s"      
    ,"Ins_269_fnmsf_s"      ,"Ins_270_maddf_s"      ,"Ins_271_maxf_d"       ,"Ins_272_maxf_s"       
    ,"Ins_273_minf_d"       ,"Ins_274_minf_s"       ,"Ins_275_msubf_s"      ,"Ins_276_mulf_d"       
    ,"Ins_277_mulf_s"       ,"Ins_278_negf_d"       ,"Ins_279_negf_s"       ,"Ins_280_nmaddf_s"     
    ,"Ins_281_nmsubf_s"     ,"Ins_282_recipf_d"     ,"Ins_283_recipf_s"     ,"Ins_284_roundf_dl"    
    ,"Ins_285_roundf_dul"   ,"Ins_286_roundf_duw"   ,"Ins_287_roundf_dw"    ,"Ins_288_roundf_sl"    
    ,"Ins_289_roundf_sul"   ,"Ins_290_roundf_suw"   ,"Ins_291_roundf_sw"    ,"Ins_292_rsqrtf_d"     
    ,"Ins_293_rsqrtf_s"     ,"Ins_294_sqrtf_d"      ,"Ins_295_sqrtf_s"      ,"Ins_296_subf_d"       
    ,"Ins_297_subf_s"       ,"Ins_298_trfsr"        ,"Ins_299_trncf_dl"     ,"Ins_300_trncf_dul"    
    ,"Ins_301_trncf_duw"    ,"Ins_302_trncf_dw"     ,"Ins_303_trncf_sl"     ,"Ins_304_trncf_sul"    
    ,"Ins_305_trncf_suw"    ,"Ins_306_trncf_sw"     ,"Ins_307_cnvq15q30"    ,"Ins_308_cnvq30q15"    
    ,"Ins_309_cnvq31q62"    ,"Ins_310_cnvq62q31"    ,"Ins_311_dup_h"        ,"Ins_312_dup_w"        
    ,"Ins_313_expq31"       ,"Ins_314_modadd"       ,"Ins_315_mov_dw"       ,"Ins_316_mov_dw"       
    ,"Ins_317_mov_h"        ,"Ins_318_mov_w"        ,"Ins_319_mov_w"        ,"Ins_320_mov_w"        
    ,"Ins_321_pki16i32"     ,"Ins_322_pki16ui8"     ,"Ins_323_pki32i16"     ,"Ins_324_pki64i32"     
    ,"Ins_325_pkq15q31"     ,"Ins_326_pkq30q31"     ,"Ins_327_pkq31q15"     ,"Ins_328_pkui8i16"     
    ,"Ins_329_vabs_h"       ,"Ins_330_vabs_w"       ,"Ins_331_vadd_dw"      ,"Ins_332_vadd_h"       
    ,"Ins_333_vadd_w"       ,"Ins_334_vadds_h"      ,"Ins_335_vadds_w"      ,"Ins_336_vaddsat_h"    
    ,"Ins_337_vaddsat_w"    ,"Ins_338_vand"         ,"Ins_339_vbiq_h"       ,"Ins_340_vbswap_dw"    
    ,"Ins_341_vbswap_h"     ,"Ins_342_vbswap_w"     ,"Ins_343_vcalc_h"      ,"Ins_344_vcalc_w"      
    ,"Ins_345_vcmov"        ,"Ins_346_vcmpeq_h"     ,"Ins_347_vcmpeq_w"     ,"Ins_348_vcmple_h"     
    ,"Ins_349_vcmple_w"     ,"Ins_350_vcmplt_h"     ,"Ins_351_vcmplt_w"     ,"Ins_352_vcmpne_h"     
    ,"Ins_353_vcmpne_w"     ,"Ins_354_vconcat_b"    ,"Ins_355_vitlv_h"      ,"Ins_356_vitlv_w"      
    ,"Ins_357_vitlvhw_h"    ,"Ins_358_vitlvwh_h"    ,"Ins_359_vld_b"        ,"Ins_360_vld_b"        
    ,"Ins_361_vld_b"        ,"Ins_362_vld_b"        ,"Ins_363_vld_dw"       ,"Ins_364_vld_dw"       
    ,"Ins_365_vld_dw"       ,"Ins_366_vld_dw"       ,"Ins_367_vld_dw"       ,"Ins_368_vld_h"        
    ,"Ins_369_vld_h"        ,"Ins_370_vld_h"        ,"Ins_371_vld_h"        ,"Ins_372_vld_w"        
    ,"Ins_373_vld_w"        ,"Ins_374_vld_w"        ,"Ins_375_vld_w"        ,"Ins_376_vmadrn_h"     
    ,"Ins_377_vmadrn_w"     ,"Ins_378_vmadsat_h"    ,"Ins_379_vmadsat_w"    ,"Ins_380_vmaxge_h"     
    ,"Ins_381_vmaxge_w"     ,"Ins_382_vmaxgt_h"     ,"Ins_383_vmaxgt_w"     ,"Ins_384_vminle_h"     
    ,"Ins_385_vminle_w"     ,"Ins_386_vminlt_h"     ,"Ins_387_vminlt_w"     ,"Ins_388_vmsum_h"      
    ,"Ins_389_vmsum_w"      ,"Ins_390_vmsumad_h"    ,"Ins_391_vmsumad_w"    ,"Ins_392_vmsumadim_h"  
    ,"Ins_393_vmsumadim_w"  ,"Ins_394_vmsumadre_h"  ,"Ins_395_vmsumadre_w"  ,"Ins_396_vmsumadrn_h"  
    ,"Ins_397_vmsumadrn_w"  ,"Ins_398_vmul_h"       ,"Ins_399_vmul_w"       ,"Ins_400_vmulcx_h"     
    ,"Ins_401_vmulcx_w"     ,"Ins_402_vmult_h"      ,"Ins_403_vmult_w"      ,"Ins_404_vneg_h"       
    ,"Ins_405_vneg_w"       ,"Ins_406_vnot"         ,"Ins_407_vor"          ,"Ins_408_vsar_dw"      
    ,"Ins_409_vsar_dw"      ,"Ins_410_vsar_h"       ,"Ins_411_vsar_h"       ,"Ins_412_vsar_w"       
    ,"Ins_413_vsar_w"       ,"Ins_414_vshl_dw"      ,"Ins_415_vshl_dw"      ,"Ins_416_vshl_h"       
    ,"Ins_417_vshl_h"       ,"Ins_418_vshl_w"       ,"Ins_419_vshl_w"       ,"Ins_420_vshr_dw"      
    ,"Ins_421_vshr_dw"      ,"Ins_422_vshr_h"       ,"Ins_423_vshr_h"       ,"Ins_424_vshr_w"       
    ,"Ins_425_vshr_w"       ,"Ins_426_vshufl_b"     ,"Ins_427_vst_b"        ,"Ins_428_vst_b"        
    ,"Ins_429_vst_b"        ,"Ins_430_vst_b"        ,"Ins_431_vst_dw"       ,"Ins_432_vst_dw"       
    ,"Ins_433_vst_dw"       ,"Ins_434_vst_dw"       ,"Ins_435_vst_dw"       ,"Ins_436_vst_dw"       
    ,"Ins_437_vst_h"        ,"Ins_438_vst_h"        ,"Ins_439_vst_h"        ,"Ins_440_vst_h"        
    ,"Ins_441_vst_h"        ,"Ins_442_vst_w"        ,"Ins_443_vst_w"        ,"Ins_444_vst_w"        
    ,"Ins_445_vst_w"        ,"Ins_446_vst_w"        ,"Ins_447_vsub_dw"      ,"Ins_448_vsub_h"       
    ,"Ins_449_vsub_w"       ,"Ins_450_vsubs_h"      ,"Ins_451_vsubs_w"      ,"Ins_452_vsubsat_h"    
    ,"Ins_453_vsubsat_w"    ,"Ins_454_vxor"         ,"Ins_455__word"        ,"Ins_456__short"   
    ,"Ins_C465_pref_I"      ,"Ins_C466_ld_array"    ,"Ins_C467_st_array"    ,"Ins_C468_ls_array"
    ,"Ins_C469_sld_array"   ,"Ins_C470_sst_array"   ,"Ins_C471_sls_array"   ,"Ins_C472_caxi_array"
    ,"Ins_C473_mpu_update"];

key_bit_manipulation = [ "Ins_C457_clr1"        ,"Ins_C458_clr1"        ,"Ins_C459_not1"        ,"Ins_C460_not1"
                   ,"Ins_C461_set1"        ,"Ins_C462_set1"        ,"Ins_C463_tst1"        ,"Ins_C464_tst1" ];
key_fpu_operand = [ "RANDOM","+QNaN","-QNaN","+SNaN","-SNaN","+ZERO","-ZERO","+INFINITE","-INFINITE","+SUBNORMAL","-SUBNORMAL","+NORMAL","-NORMAL" ];

key_exception = [
    "Exp_DTLBE",    "Exp_EIINT",    "Exp_FEINT",    "Exp_FENMI",    "Exp_FETRAP",   "Exp_FPI",      "Exp_FPP",      "Exp_HVCALL",
    "Exp_HVTRAP",   "Exp_ITLBE",    "Exp_MAE",      "Exp_MDP",      "Exp_MIP",      "Exp_PIE",      "Exp_SYSCALL",  "Exp_SYSERR",
    "Exp_TRAP0",    "Exp_TRAP1",    "Exp_UCPOP(0)", "Exp_UCPOP(1)", "Exp_UCPOP(2)", "Exp_DBHVTRAP", "Exp_DBINT",    "Exp_DBNMI",
    "Exp_DBTRAP",   "Exp_LDB/RMWDB","Exp_PCB/LSAB/SDB/AE","Exp_RLB","Exp_RMINT","Exp_RMTRAP","Exp_SS","Exp_RIE"
    ] ;

################################
# Main operation
################################
abspath = os.path.abspath(os.path.dirname(__file__));
get_arg();

input_file_multi = [];
# Execute all files with extend .profile and .wt in input folder

for i in range(len(input_file_path)):
    for input_file in glob.glob(input_file_path[i]) :
        if 'wt' in input_file:
            input_file_multi.append(input_file);

        # Refresh variable
        mxu_common = [];
        inst_csv = [];
        exp_csv = [];
        machine_setting_list = [];
        memory_address = [];
        rom_address = [];
        ram_address = [];
        mpu_setting = [];
        fpu_single_data = [];
        fpu_double_data = [];
        mem_area_buff = [];

        #Read data
        print "\n.....Checking file %s...... " %(input_file);
        if read_data( input_file ) == False:
            continue;

        #Check section 
        check_instruction( inst_csv);
        check_exception( exp_csv);
        check_machine_setting( machine_setting_list);
        check_rom_address( rom_address);
        check_ram_address( ram_address);
        check_mxu_common( mxu_common);
        check_mpu_setting( mpu_setting);
        check_fpu_single_data( fpu_single_data);
        check_fpu_double_data( fpu_double_data);

        #Check combination 
        
        check_combination();

#Support multi core 
if len(input_file_multi) > 1:
    print "\n.....Checking multi-core...... " ;
    check_multi_pe();
sys.exit(0)
