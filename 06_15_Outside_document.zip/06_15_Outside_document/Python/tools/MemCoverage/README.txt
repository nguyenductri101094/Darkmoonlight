

1. Purpose
This tool was used for checking FROG access memory in G4MH1.1
Redmine #81278
2. Back ground
Object:To estimate the address map coverage because PFSS logic does not have cover sva like CPU core.

Target Spec:
Outputs scoreboards of Each PE each scoreboards include the sum of number of access to each address area /each access

3. How to use:
python FROG_access_Mem --input_file input_file -- output_file output_name