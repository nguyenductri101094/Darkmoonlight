#!/opt/python2.7/bin/python
import os
import sys
import os.path
import glob
import re
import operator
from operator import itemgetter

#Global Variable
peList = []
Fetch = dict()
RW = dict()
LDMem = dict()
LDLMem = dict()
STMem = dict()
STCMem = dict()
RWMem = dict()
FMemElement = []
RWMemElement = []

#Variable use to clarify instruction type
MneReadMem = []
MneWriteMem = []
ouputFileName = 'FROGCoverage.txt'
# Struct: Name, start address, end address 
Mem_List = [['FL_OL0','00000000','002FFFFF'], ['FL_OL1','00300000','005FFFFF'],['FL_OL2','00600000','007FFFFF']
			 ,['FL_OL3','00800000','008FFFFF'],['FL_OL4','00900000','00BFFFFF'],['FL_OL5','00C00000','00DFFFFF']
			 ,['FL_OL6','00E00000','00FFFFFF'],['FL_OL7','02000000','022FFFFF'],['FL_OL8','02300000','025FFFFF']
			 ,['FL_OL9','02600000','027FFFFF'],['FL_NOL0','04000000','042FFFFF'],['FL_NOL1','04300000','045FFFFF']
			 ,['FL_NOL2','04600000','047FFFFF'],['FL_NOL3','04800000','048FFFFF'],['FL_NOL4','04900000','04BFFFFF']
			 ,['FL_NOL5','04C00000','04DFFFFF'],['FLNOL_6','04E00000','04FFFFFF'],['FLNOL7','06000000','062FFFFF']
			 ,['FLNOL8','06300000','065FFFFF'],['FLNOL_9','06600000','067FFFFF'],['LRAM2_1','FD200000','FD20FFFF']
			 ,['LRAM2_0','FD400000','FD40FFFF'],['LRAM1_1','FD600000','FD60FFFF'],['LRAM1_0','FD800000','FD80FFFF']
			 ,['LRAM0_1','FDA00000','FDA0FFFF'],['LRAM0_0','FDC00000','FDC0FFFF'],['CRAM0','FE000000','FE07FFFF']
			 ,['CRAM1','FE080000','FE0DFFFF'],['CRAM2','FE0E0000','FE0FFFFF'],['CRAM3','FE100000','FE17FFFF']
			 ,['CRAM4','FE180000','FE19FFFF']]
		
input_file_path=[]
f_r1 = 0;

# Get command parameter
def get_arg():
	global input_file_path;
	argvs = sys.argv;
	num = 0;
	arg_sw = 0;
	for i in argvs:
		num = num + 1;
		if num == 1 :
			continue;
		
		if len(i) > 1 and i[0:2] == "--" :
			arg_tmp = 0;

			if i == "--input_file"		: arg_tmp = 1;
			else:
				if i == "--output_file"		: arg_tmp = 2
				else:
					arg_sw = arg_tmp;
			continue;
		else:
			if len(i) > 0 and i[0:1] == "-" :
				arg_tmp = 0;
				if i == "-h" or i == "-help"   : help_message();
				if arg_tmp == 0 : arg_sw = 9;
			else: arg_sw = arg_tmp;

		if arg_sw == 1 :
			if not os.path.exists(sys.argv[num -1]):
				print "SYSTEM_ERROR: File %s is not found!"%(argvs[num - 1]);
				sys.exit();
			input_file_path.append(i) ;
			
		if arg_sw == 2 :
			global ouputFileName
			ouputFileName = i

	if len(input_file_path) == 0:
		print "\n*********SYSTEM_MESSAGE: Not specify --input_file_path <file_name>*****************";
		return;
		
def help_message():
	print "**********************************************************************";
	print "\nusage:	 FROG_access_Mem.py --input_file  <file_name>  --output_file <file_name>";
	print " Specification extension or file name: ";
	print "**********************************************************************";
	sys.exit();	   
	
# Define not count instruction here
# Remove unnecessary code
def removeInfoline(cforestLog):
	output = []
	StartHander = False
	for line in cforestLog:
		if '<All' not in line and 'Error' not in line and "<Exception" not in line and 'Warning' not in line and 'P' == line[0] and "<New" not in line and "Break" not in line:
			output.append(line)
			# print "%s !"%(line);
	return output

# Get name of instruction
def GetPeid (line):
	peid=line.split(':')[0]
	return peid
	
# Get pc from line
# For calculating fetch occurrence 
def GetPc (line):
	pc = line.split(' ')[3]
	return pc

# Get name of instruction
def GetMne (line):
	Mne=line.split(' ')[5]
	MneType=Mne.split('.')[0]
	return MneType

# Is Read memory
def AccessReadMem(line):
	if ")=>" in line:
		return True
	return False
	
# Is Read memory
def AccessWriteMem(line):
	if ")<=" in line:
		return True
	return False
		
#Get memory in line
def GetMem(line):
	memAccessed=[]
	#Get operation of instruction
	line = line.split(' ');
	opr = line[5:]
	for mem in opr:
		if ')<=' in mem or ')=>' in mem:
			mem = mem.partition('(')[-1].rpartition(')')[0]
			memAccessed.append(mem)
	 
	return memAccessed
	
#Get memory area name base on address
def GetAreaName(addr):
	addr = int(addr, 16);
	for mem in Mem_List:
		# print " %s : %s : %s "%(addr, mem[1], mem[2])
		if addr >= int(mem[1], 16) and addr <= int(mem[2], 16):
			return mem[0]
	else:
		return 'None'
# Get all area name in PE
def GetPEarea ():
	area = []
	for mem in Mem_List:
		area.append(mem[0])
	return area
	
#Parse draw data
def CollectAccessMem (drawData, pelist, fmem, rwmem):
	#Check behaviour access memory
	for element in drawData:
		accessMem = []
		#struct <peid, area name>
		FLine = []
		#struct <peid, Mne, area name1, area name 2 ...>
		RWLine = []
		#Reformat 1 space
		element = re.sub(' +',' ', element)
		#Get peid
		pe = GetPeid(element)
		if pe not in pelist:
			pelist.append(pe)
			RW[pe] = []
			LDMem[pe] = []
			LDLMem[pe] = []
			STMem[pe] = []
			STCMem[pe] = []
			RWMem[pe] = []
			
		FLine.append(pe)
		#Get pc
		pc = GetPc(element)
		area = GetAreaName(pc)
		FLine.append(area)
		fmem.append(FLine);
		#print " %s"%(FLine)
		if AccessReadMem(element) == True or AccessWriteMem(element) == True:
			accessMem = GetMem(element)
			Mne = GetMne(element)
			# Collect accessed area
			for addr in accessMem:
				area = GetAreaName(addr)
				#print " %s : %s : %s : %s : %s"%(peId, pc, Mne, area, addr)
				if area != 'None':
					RWLine.append(area)
			if len(RWLine) > 0:
				#Collect Mne to clarify instruction type
				if AccessReadMem(element) == True and AccessWriteMem(element) == True:
					RWMem[pe].append(RWLine)
					continue
					
				if AccessReadMem(element) == True and 'ldl' in Mne:
					LDLMem[pe].append(RWLine)
					continue
					
				if AccessReadMem(element) == True:
					LDMem[pe].append(RWLine)
					continue
					
				if AccessWriteMem(element) == True and 'stc' in Mne:
					STCMem[pe].append(RWLine)
					continue
					
				if AccessWriteMem(element) == True:
					STMem[pe].append(RWLine)
					continue
				
# Format output for IFU coverage
def IFUOutputFormat(peList):
	FetchFucn = dict()
	# Sort by id pe0-pe1-pe2...
	peList =  sorted(peList, key = lambda x: x[1])

	# Initialize output 
	for pe in peList:
		#List format <pattern accessed area name, occurrence>
		FetchFucn[pe] = []
		AreaNameList = GetPEarea()
		# Output format
		for area in AreaNameList:
			FLine = []
			FLine.append(area)
			# Not count FL_NOL area for IFU coverage 
			if 'FL_NOL' in area:
				FLine.append('-')
			else:
				FLine.append(int(0))
			FetchFucn[pe].append(FLine)
	return FetchFucn
	
#Count IFU coverage
def CountIFUCoverage(Fetch, data):
	for element in data:
		pe = element[0]
		area = element[1]
		for intiArea in Fetch[pe]:
			if intiArea[0] == area and intiArea[1] != '-':
				intiArea[1] = int(intiArea[1] + 1)
				
#Store data in dict
def StoreInDict (LDlist, LDLlist, STlist, STClist, RWlist):

	for pe in peList:
		RW[pe].append(LDlist[pe])
		RW[pe].append(LDLlist[pe])
		RW[pe].append(STlist[pe])
		RW[pe].append(STClist[pe])
		RW[pe].append(RWlist[pe])
	
	# for pe in peList:
		# print '%s: RW[%s]: %s '%(len (RW[pe]), pe, RW[pe])
	return RW

def CountFreq(list):
	trace = []
	AreaFreq = []
	for mem in list:
		# Collect same element in list
		if mem not in trace:
			elem = []
			trace.append(mem)
			elem.append(mem)
			freq = list.count(mem)
			elem.append(freq)
			AreaFreq.append(elem)
	return AreaFreq
	
# Count Occurrence
def CountOccurrence(pelist, RWDict):
	RWTemp = dict()
	AreaNameList = GetPEarea()
	for pe in pelist:
		RWTemp[pe] = []
		for element in RWDict[pe]:
			MemFreq = []
			#Collect same memory in list
			for mem in element:
				#print'%s: mem: %s    len: %s'%(pe, mem, len(mem))
				AFreq = CountFreq(mem)
				for memfreq in AFreq:
					MemFreq.append(memfreq)
					
			MemFreqTemp = []
			for area in AreaNameList:
				val = 0
				elem = []
				for peArea in MemFreq:
					if area == peArea[0]:
						val = val + int(peArea[1])
				elem.append(area)
				elem.append(val)

				MemFreqTemp.append(elem)

			RWTemp[pe].append(MemFreqTemp)

	return RWTemp

#Function to write data to txt file
def print_table():

	f = open(ouputFileName,'w')
	headers = []
	# Add information into header
	headers.append('PEn')
	headers.append('Area')
	headers.append('IFU')
	headers.append('LD')
	headers.append('LDL')
	headers.append('ST')
	headers.append('STC')
	headers.append('RmW')
	
	# Write header
	f.write( ''.join(column.rjust(10) for column in headers))
	f.write('\n')
	AreaNameList = GetPEarea()
	for pe in peList:
		for area in AreaNameList:
			peAcc = []
			peAcc.append(pe)
			peAcc.append(area)
			for elem in Fetch[pe]:
				if area == elem[0]:
					peAcc.append(elem[1])
			for element in RW[pe]:
				# print' ele: '%(element)
				for PEArea in element:
					if PEArea[0] == area:
						peAcc.append(PEArea[1])
			f.write('\n')
			f.write( ''.join(str(column).rjust(10) for column in peAcc))
		
	f.close()
################################
# Main operation
################################
abspath = os.path.abspath(os.path.dirname(__file__))
get_arg()

########## Begin Analyse Draw Data ###########
for i in range(len(input_file_path)):
	for file in glob.glob(input_file_path[i]) :
		cff_log = []	
		f_r1 = open(file , 'r');
		#Convert to list
		for line in f_r1:
			line = line.strip()
			cff_log.append(line)

		# Remove unnecessary code
		cforestLog = removeInfoline(cff_log)
		#Check behaviour access memory
		CollectAccessMem(cforestLog, peList, FMemElement, RWMemElement)
########## Finish Analyse Draw Data ###########

########## IFU start ###########
# Format output for IFU coverage
Fetch = IFUOutputFormat(peList)

#Collect date of each pe in peList
# Count pattern fetch mem
CountIFUCoverage(Fetch, FMemElement)
########## IFU end ###########

########## LFU start ###########
# Count pattern read/write mem
RW = StoreInDict(LDMem, LDLMem, STMem, STCMem, RWMem)
RW = CountOccurrence(peList, RW)

# Write output
print_table()

f_r1.close();
sys.exit(0)



