awk '

BEGIN { 
	FS=","
} 
{ 
	if ( ($1 !~ /11/) || ($2 < 16) || ($2 > 23) ) { 
		print $0
	} 
}
END {print "Done"}
 
' $1/sreg.profile > $1/sreg2.profile