./delete_sreg.sh g4mh20_cv_001_async_event_Consistency/
./insert_sreg.sh g4mh20_cv_001_async_event_Consistency/
./correct_privilege.sh g4mh20_cv_001_async_event_Consistency/

./delete_sreg.sh g4mh20_cv_002_break_Consistency/
./insert_sreg.sh g4mh20_cv_002_break_Consistency/
./correct_privilege.sh g4mh20_cv_002_break_Consistency/

./delete_sreg.sh g4mh20_cv_003_exception_Consistency/
./insert_sreg.sh g4mh20_cv_003_exception_Consistency/
./correct_privilege.sh g4mh20_cv_003_exception_Consistency/

./delete_sreg.sh g4mh20_cv_004_mpu_Consistency/
./insert_sreg.sh g4mh20_cv_004_mpu_Consistency/
./correct_privilege.sh g4mh20_cv_004_mpu_Consistency/

./delete_sreg.sh g4mh20_cv_005_NewInsG4MH20_Consistency/
./insert_sreg.sh g4mh20_cv_005_NewInsG4MH20_Consistency/
./correct_privilege.sh g4mh20_cv_005_NewInsG4MH20_Consistency/

./delete_sreg.sh g4mh20_cv_006_ins_loop_pref_changemode_Consistency/
./insert_sreg.sh g4mh20_cv_006_ins_loop_pref_changemode_Consistency/
./correct_privilege.sh g4mh20_cv_006_ins_loop_pref_changemode_Consistency/

./delete_sreg.sh g4mh20_cv_007_combination_Consistency/
./insert_sreg.sh g4mh20_cv_007_combination_Consistency/
./correct_privilege.sh g4mh20_cv_007_combination_Consistency/

./delete_sreg.sh g4mh20_hv_001_async_event_Consistency/
./insert_sreg.sh g4mh20_hv_001_async_event_Consistency/
./correct_privilege.sh g4mh20_hv_001_async_event_Consistency/

./delete_sreg.sh g4mh20_hv_002_async_event_multicycle_ins_Consistency/
./insert_sreg.sh g4mh20_hv_002_async_event_multicycle_ins_Consistency/
./correct_privilege.sh g4mh20_hv_002_async_event_multicycle_ins_Consistency/

./delete_sreg.sh g4mh20_hv_003_async_event_vs_exception_all_Consistency/
./insert_sreg.sh g4mh20_hv_003_async_event_vs_exception_all_Consistency/
./correct_privilege.sh g4mh20_hv_003_async_event_vs_exception_all_Consistency/

./delete_sreg.sh g4mh20_hv_004_exception_all_no_brk_Consistency/
./insert_sreg.sh g4mh20_hv_004_exception_all_no_brk_Consistency/
./correct_privilege.sh g4mh20_hv_004_exception_all_no_brk_Consistency/

./delete_sreg.sh g4mh20_hv_005_exception_all_no_brk_vs_multicycle_ins_Consistency/
./insert_sreg.sh g4mh20_hv_005_exception_all_no_brk_vs_multicycle_ins_Consistency/
./correct_privilege.sh g4mh20_hv_005_exception_all_no_brk_vs_multicycle_ins_Consistency/

./delete_sreg.sh g4mh20_hv_006_exception_all_Consistency/
./insert_sreg.sh g4mh20_hv_006_exception_all_Consistency/
./correct_privilege.sh g4mh20_hv_006_exception_all_Consistency/

./delete_sreg.sh g4mh20_hv_007_exception_all_vs_multicycle_instruction_Consistency/
./insert_sreg.sh g4mh20_hv_007_exception_all_vs_multicycle_instruction_Consistency/
./correct_privilege.sh g4mh20_hv_007_exception_all_vs_multicycle_instruction_Consistency/

./delete_sreg.sh g4mh20_hv_008_rb_Consistency/
./insert_sreg.sh g4mh20_hv_008_rb_Consistency/
./correct_privilege.sh g4mh20_hv_008_rb_Consistency/

./delete_sreg.sh g4mh20_hv_009_break_pcb_Consistency/
./insert_sreg.sh g4mh20_hv_009_break_pcb_Consistency/
./correct_privilege.sh g4mh20_hv_009_break_pcb_Consistency/

./delete_sreg.sh g4mh20_hv_010_break_lsab_Consistency/
./insert_sreg.sh g4mh20_hv_010_break_lsab_Consistency/
./correct_privilege.sh g4mh20_hv_010_break_lsab_Consistency/

./delete_sreg.sh g4mh20_hv_011_break_ae_Consistency/
./insert_sreg.sh g4mh20_hv_011_break_ae_Consistency/
./correct_privilege.sh g4mh20_hv_011_break_ae_Consistency/

./delete_sreg.sh g4mh20_hv_012_break_sequential_Consistency/
./insert_sreg.sh g4mh20_hv_012_break_sequential_Consistency/
./correct_privilege.sh g4mh20_hv_012_break_sequential_Consistency/

./delete_sreg.sh g4mh20_hv_013_break_all_type_Consistency/
./insert_sreg.sh g4mh20_hv_013_break_all_type_Consistency/
./correct_privilege.sh g4mh20_hv_013_break_all_type_Consistency/

./delete_sreg.sh g4mh20_hv_014_ins_sample_Consistency/
./insert_sreg.sh g4mh20_hv_014_ins_sample_Consistency/
./correct_privilege.sh g4mh20_hv_014_ins_sample_Consistency/

./delete_sreg.sh g4mh20_hv_015_ins_fpsimd_Consistency/
./insert_sreg.sh g4mh20_hv_015_ins_fpsimd_Consistency/
./correct_privilege.sh g4mh20_hv_015_ins_fpsimd_Consistency/

./delete_sreg.sh g4mh20_hv_016_ins_exclusive_access_Consistency/
./insert_sreg.sh g4mh20_hv_016_ins_exclusive_access_Consistency/
./correct_privilege.sh g4mh20_hv_016_ins_exclusive_access_Consistency/

./delete_sreg.sh g4mh20_hv_017_ins_c2b1_Consistency/
./insert_sreg.sh g4mh20_hv_017_ins_c2b1_Consistency/
./correct_privilege.sh g4mh20_hv_017_ins_c2b1_Consistency/

./delete_sreg.sh g4mh20_hv_018_ins_multicycle_Consistency/
./insert_sreg.sh g4mh20_hv_018_ins_multicycle_Consistency/
./correct_privilege.sh g4mh20_hv_018_ins_multicycle_Consistency/

./delete_sreg.sh g4mh20_hv_019_fetch_rom_Consistency/
./insert_sreg.sh g4mh20_hv_019_fetch_rom_Consistency/
./correct_privilege.sh g4mh20_hv_019_fetch_rom_Consistency/

./delete_sreg.sh g4mh20_hv_020_fetch_vci_Consistency/
./insert_sreg.sh g4mh20_hv_020_fetch_vci_Consistency/
./correct_privilege.sh g4mh20_hv_020_fetch_vci_Consistency/

./delete_sreg.sh g4mh20_hv_021_fetch_rom__l1ram_l2ram_vci_Consistency/
./insert_sreg.sh g4mh20_hv_021_fetch_rom__l1ram_l2ram_vci_Consistency/
./correct_privilege.sh g4mh20_hv_021_fetch_rom__l1ram_l2ram_vci_Consistency/

./delete_sreg.sh g4mh20_hv_023_cb_cont_ld_st_Consistency/
./insert_sreg.sh g4mh20_hv_023_cb_cont_ld_st_Consistency/
./correct_privilege.sh g4mh20_hv_023_cb_cont_ld_st_Consistency/

./delete_sreg.sh g4mh20_hv_022_sequential_jmp_Consistency/
./insert_sreg.sh g4mh20_hv_022_sequential_jmp_Consistency/
./correct_privilege.sh g4mh20_hv_022_sequential_jmp_Consistency/

./delete_sreg.sh g4mh20_hv_024_cb_eiint_tbl_vs_mdp_lsab_Consistency/
./insert_sreg.sh g4mh20_hv_024_cb_eiint_tbl_vs_mdp_lsab_Consistency/
./correct_privilege.sh g4mh20_hv_024_cb_eiint_tbl_vs_mdp_lsab_Consistency/

./delete_sreg.sh g4mh20_hv_025_ins_loop_prefetch_changemode_Consistency/
./insert_sreg.sh g4mh20_hv_025_ins_loop_prefetch_changemode_Consistency/
./correct_privilege.sh g4mh20_hv_025_ins_loop_prefetch_changemode_Consistency/

./delete_sreg.sh g4mh20_hv_026_combination_all_Consistency/
./insert_sreg.sh g4mh20_hv_026_combination_all_Consistency/
./correct_privilege.sh g4mh20_hv_026_combination_all_Consistency/