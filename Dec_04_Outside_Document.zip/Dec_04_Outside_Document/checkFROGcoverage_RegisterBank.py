# ----------------------------------------------- HOW TO EXECUTE SCRIPT -----------------------------------------
#					 			python checkFROGcoverage_RegisterBank.py "log_files saving path"
# 					EXAMPLE1: python checkFROGcoverage_RegisterBank.py *.log ==> scan all log_files in dir
#
# 	EXAMPLE2: python checkFROGcoverage_RegisterBank.py ../dir1/dir2/cf_ff_RSEED=0x00ba3fc7.log ==> scan exact log_file
# ---------------------------------------------------------------------------------------------------------------

# -------------------------------- NOTE -------------------------------------------
# EIINT - Direct Vector Method 			=>		EIINT			Direct Vector Method
# EIINT - Table Reference Method BE = 1	=>		EIINT_RB		Auto save
# EIINT - Table Reference Method BE = 0 =>  	EIINT_TBL		Table reference
# ---------------------------------------------------------------------------------
import sys
import database
import copy
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import datetime # support time stamp
import collections;	# support create dict has order

# -------------------------------- DEFINE VARIABLE -------------------------------------
InputFileName = sys.argv[1:]
AccumulationFile = 'RB_data_accumulation.pk'

_ModeMap = {database.Mode.CV:0, database.Mode.GM:0}
_ModeMapandPrivilege = {database.Mode.CV_SV:0, database.Mode.CV_UM:0, database.Mode.GM_SV:0, database.Mode.GM_UM:0, \
							database.Mode.HM_HV:0, database.Mode.HM_UM:0}
RB_priority = collections.OrderedDict()
for i in range(0, 16): RB_priority[i] = dict(_ModeMap)

Resbank_inMode = {'MD0': dict(_ModeMapandPrivilege), 'MD1': dict(_ModeMapandPrivilege)}
RBNR_BN_exceeding = {'MD0: TBL without RB': dict(_ModeMap), 'MD0: DV': dict(_ModeMap), 'MD1: TBL without RB': dict(_ModeMap), \
							'MD1: DV': dict(_ModeMap)}
Sequential_EIINT_RB = {'MD0': dict(_ModeMap), 'MD1': dict(_ModeMap)}

RB_priority_disable_DV = copy.deepcopy(RB_priority)
RB_priority_disable_TBL = copy.deepcopy(RB_priority)
RB_priority_disable_TBL_pri = copy.deepcopy(RB_priority)

RB_priority_RB_enable_BN_MD0 = copy.deepcopy(RB_priority)
RB_priority_RB_enable_BE_BN_MD0 = copy.deepcopy(RB_priority)
RB_priority_RB_enable_NC_BE_BN_MD0 = copy.deepcopy(RB_priority)

RB_priority_RB_enable_BN_MD1 = copy.deepcopy(RB_priority)
RB_priority_RB_enable_BE_BN_MD1 = copy.deepcopy(RB_priority)
RB_priority_RB_enable_NC_BE_BN_MD1 = copy.deepcopy(RB_priority)

RB_priority_MDP_CV_SV_or_GM_SV = copy.deepcopy(RB_priority)
RB_priority_MDP_CV_UM_or_GM_UM = copy.deepcopy(RB_priority)

RB_priority_LSAB_CV_SV_or_GM_SV = copy.deepcopy(RB_priority)
RB_priority_LSAB_CV_UM_or_GM_UM = copy.deepcopy(RB_priority)

RB_priority_MDP_LSAB_CV_SV_or_GM_SV = copy.deepcopy(RB_priority)
RB_priority_MDP_LSAB_CV_UM_or_GM_UM = copy.deepcopy(RB_priority)

#Load back data from backup file(if exists) before executing script
if os.path.isfile(AccumulationFile):
	with open(AccumulationFile, 'rb') as file_in:
		RB_priority_disable_DV = pickle.load(file_in)
		RB_priority_disable_TBL = pickle.load(file_in)
		RB_priority_disable_TBL_pri = pickle.load(file_in)

		RB_priority_RB_enable_BN_MD0 = pickle.load(file_in)
		RB_priority_RB_enable_BE_BN_MD0 = pickle.load(file_in)
		RB_priority_RB_enable_NC_BE_BN_MD0 = pickle.load(file_in)

		RB_priority_RB_enable_BN_MD1 = pickle.load(file_in)
		RB_priority_RB_enable_BE_BN_MD1 = pickle.load(file_in)
		RB_priority_RB_enable_NC_BE_BN_MD1 = pickle.load(file_in)

		RB_priority_MDP_CV_SV_or_GM_SV = pickle.load(file_in)
		RB_priority_MDP_CV_UM_or_GM_UM = pickle.load(file_in)

		Resbank_inMode = pickle.load(file_in)
		RBNR_BN_exceeding = pickle.load(file_in)
		Sequential_EIINT_RB = pickle.load(file_in)
# ---------------------------------- FUNCTION ----------------------------------------
def CheckingEIINT(prev_line, curr_line, next_line):
	# value of target registers/bits
	RBCR0_BE = database.GetValueBitRange(curr_line.SR['RBCR0'], 0, 15)
	RBCR0_MD = database.GetValueBitRange(curr_line.SR['RBCR0'], 16, 16)
	RBCR1_NC = database.GetValueBitRange(curr_line.SR['RBCR1'], 0, 15)
	RBNR_BN = database.GetValueBitRange(curr_line.SR['RBNR'], 0, 5)
	INTCFG_ULNR = database.GetValueBitRange(curr_line.SR['INTCFG'], 16, 23)
	# print hex(RBCR0_BE), RBCR0_MD, RBCR1_NC, RBNR_BN, INTCFG_ULNR
	curr_mode = database.GetModeAndPrivilege(prev_line.SR)

	column = database.GetMode(prev_line.SR)
	# if current line has xxEIINT
	if "EIINT" in curr_line.InsName:
		# check Interrupt priority
		priority = checkIntPriority(curr_line)
		""" 1. Conventional mode """
		""" 2. Virtualization Mode (GUEST) """
		""" Main Item: RBCR0.BE control """
		# change target Interrupt name to EIINT, EIINT_TBL, EIINT_RB
		intType = database.ConvertIntName(curr_line.Exp[0], curr_line.Behavior)
		# print "priority: ", priority, "- intType: ", intType

		# if current line has EIINT Interrupt
		if "EIINT" == curr_line.Exp[0] and 0 <= priority <= 15:
				""" Sub Item: Disable register banking """
				# """ if RBCR1.NC[15:0] = 16'h0 """
				if 0 == RBCR1_NC:
					if "EIINT_TBL" == intType:						# Table reference
						if 0 == (RBCR0_BE >> priority) | 0xfffffffe:
							RB_priority_disable_TBL_pri[priority][column] = "Table Reference"
							# print "CP 33 - 48: Disable - EIINT - Table Reference Method and individual priority: %s" % priority

					# """ if RBCR0.BE[15:0] = 16'h0 && RBCR1.NC[15:0] = 16'h0 """
					if 0 == RBCR0_BE:
						if "EIINT" == intType:						# Direct Vector
							# print "CP 1 - 16: Disable - EIINT - Direct Vector Method: %s" % priority
							RB_priority_disable_DV[priority][column] = "Direct Vector"

						elif "EIINT_TBL" == intType:				# Table reference
							# print "CP 17 - 32: Disable - EIINT - Table Reference Method: %s" % priority
							RB_priority_disable_TBL[priority][column] = "Table Reference"

				""" Sub Item: Enable Register banking """
				if RBNR_BN < INTCFG_ULNR:
				# """ if "RBNR.BN < INCFG.ULNR && RBCR0.MD = 0" """
					if 0 == RBCR0_MD:
						if "EIINT_RB" == intType:						# Auto save
							if 1 == (RBCR0_BE >> priority) & 0x01:
								# print "CP 113 - CP 128: Enable - EIINT - Auto save - MD0: %s" % priority
								RB_priority_RB_enable_BN_MD0[priority][column] = "Auto save"

						# """ if "RBCR0.BE[15:0] = 0xFFFF  && RBNR.BN < INCFG.ULNR && RBCR0.MD = 0" """
						if 0xffff == RBCR0_BE:
							if "EIINT_RB" == intType:				# Auto save
								# print "CP 81 - CP 96: Enable - EIINT - Auto save - MD0 - RBCR0.BE: %s" % priority
								RB_priority_RB_enable_BE_BN_MD0[priority][column] = "Auto save"

							""" Main Item: Combination """
							""" Sub Item: Sequential EIINT Auto-save """
							# """ RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR(Not overlapped) """
							# """ check if 2 consecutive EIINT - Table Reference Method && RBCR0.MD = 0 """
							nextintType = database.ConvertIntName(next_line.Exp[0], next_line.Behavior)
							if 0 != len(next_line.Exp) and "EIINT_RB" == nextintType:
								print "\nCP 269: Combination: Sequential EIINT Auto-save (RBCR0.MD = 0):  : line = %d - curr_mode = %s" % (curr_line.Line, curr_mode)
								Sequential_EIINT_RB["MD0"][column] = "Yes"

							# """ if "RBCR1.NC[15:0] = 16'h0 && RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR && RBCR0.MD = 0" """
							if 0 == RBCR1_NC:
								if "EIINT" == intType:				# Direct Vector Method
									# print "CP 49 - CP 64: Enable - EIINT - Direct Vector Method - MD0 - RBCR0.BE - RBCR1.NC: %s" % priority
									RB_priority_RB_enable_NC_BE_BN_MD0[priority][column] = "Direct Vector"

					elif 1 == RBCR0_MD:
					# """ if "RBNR.BN < INCFG.ULNR && RBCR0.MD = 1" """
						if "EIINT" == intType:						# Auto save
							if 1 == (RBCR0_BE >> priority) & 0x01:
								RB_priority_RB_enable_BN_MD1[priority][column] = "Auto save"
								print "CP 129 - 144: Enable - EIINT - Auto save - MD1: %s" % priority

						# """ if "RBCR0.BE[15:0] = 0xFFFF  && RBNR.BN < INCFG.ULNR && RBCR0.MD = 1" """
						if 0xffff == RBCR0_BE:
							if "EIINT_RB" == intType:				# Auto save
								# print "CP 97 - 112: Enable - EIINT - Auto save - MD1 - RBCR0.BE: %s" % priority
								RB_priority_RB_enable_BE_BN_MD1[priority][column] = "Auto save"

							""" Main Item: Combination """
							""" Sub Item: Sequential EIINT Auto-save """
							# """ RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR(Not overlapped) """
							# """ check if 2 consecutive EIINT - Table Reference Method && RBCR0.MD = 1 """
							nextintType = database.ConvertIntName(next_line.Exp[0], next_line.Behavior)
							if 0 != len(next_line.Exp) and "EIINT_RB" == nextintType:
								print "\nCP 270: Combination: Sequential EIINT Auto-save (RBCR0.MD = 1):  : line = %d - curr_mode = %s" % (curr_line.Line, curr_mode)
								Sequential_EIINT_RB["MD1"][column] = "Yes"

							# """ if "RBCR1.NC[15:0] = 16'h0 && RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR && RBCR0.MD = 1" """
							if 0 == RBCR1_NC:
								if "EIINT" == intType:				# Direct Vector
									print "CP 65 - 80: Enable - EIINT - Direct Vector Method - MD1 - RBCR0.BE - RBCR1.NC: %s" % priority
									RB_priority_RB_enable_NC_BE_BN_MD1[priority][column] = "Direct Vector"

				elif RBNR_BN >= INTCFG_ULNR:
					""" Main Item: Exception/Interrupt in EIINT autosave """
					""" Sub Item: RBNR.BN value exceeding """
					# """ RBNR.BN >= INTCFG.ULNR && EIINT - Table Reference Method not using register bank """
					# """ RBNR.BN >= INTCFG.ULNR && EIINT - Direct Vector Method """
					# print "CP 150, 151, 156, 157: RBNR.BN value exceeding: %s" % intType
					if 0 == RBCR0_MD:
						if "EIINT_TBL" == intType:				# Table Reference
							RBNR_BN_exceeding["MD0: TBL without RB"][column] = "Table Reference"
						elif "EIINT" == intType:				# Direct Vector
							RBNR_BN_exceeding["MD0: DV"][column] = "Direct Vector"
					elif 1 == RBCR0_MD:
						if "EIINT_TBL" == intType:				# Table Reference
							RBNR_BN_exceeding["MD1: TBL without RB"][column] = "Table Reference"
						elif "EIINT" == intType:				# Direct Vector
							RBNR_BN_exceeding["MD1: DV"][column] = "Direct Vector"

		elif "MDP" == curr_line.Exp[0]:
			""" Sub Item: MDP """
			# """ in CV::SV mode RBCR0.BE[15:0] = 0xFFFF  && RBNR.BN < INCFG.ULNR && MDP at Auto-save operation """
			if 0xffff == RBCR0_BE and RBNR_BN < INTCFG_ULNR:
				if database.Mode.CV_SV == curr_mode or database.Mode.GM_SV == curr_mode:
					if "EIINT_RB" == intType:					# Auto save
						# print "CP 158 - 173: MDP in CV_SV/GM_SV - EIINT - Auto save - MD1: %s" % priority
						RB_priority_MDP_CV_SV_or_GM_SV[priority][column] = "Auto save"
				# """ in CV::UM mode RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR && MDP at Auto-save operation """
				elif database.Mode.CV_UM == curr_mode or database.Mode.GM_UM == curr_mode:
					if "EIINT_RB" == intType:					# Auto save
						# print "CP 174 - 189: MDP in CV_UM/GM_UM - EIINT - Auto save - MD1: %s" % priority
						RB_priority_MDP_CV_UM_or_GM_UM[priority][column] = "Auto save"

				""" Main Item: Exception/Interrupt in EIINT autosave """
				""" Sub Item: MDP + LSAB """
				# """ in CV::SV mode RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR && MDP and LSAB at Auto-save operation at the same time """
				# """ LSAB first, MDP later """
				# Auto save + prev-line is dbret and Exception Cause List by 0xB6
				if "EIINT_RB" == intType and prev_line.Insname == dbret and prev_line.SR[DBIC] == "0xB6":
					if database.Mode.CV_SV == curr_mode or database.Mode.GM_SV == curr_mode:
						print "CP 238 - 253: MDP + LSAB in CV_SV/GM_SV - EIINT - Table Reference Method - MDP (2nd) at Priority: %s" % priority
						RB_priority_MDP_LSAB_CV_SV_or_GM_SV[priority][column] = "LSAB-MDP"
					elif database.Mode.CV_UM == curr_mode or database.Mode.GM_UM == curr_mode:
						print "CP 238 - 253: MDP + LSAB in CV_UM/GM_UM - EIINT - Table Reference Method - MDP (2nd) at Priority: %s" % priority
						RB_priority_MDP_LSAB_CV_UM_or_GM_UM[priority][column] = "LSAB-MDP"

		elif "LSAB" == curr_line.Exp[0]:
			""" Sub Item: LSAB """
			if 0xffff == RBCR0_BE and RBNR_BN < INTCFG_ULNR:
				# """ in CV::SV mode RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR && LSAB at Auto-save operation """
				if database.Mode.CV_SV == curr_mode or database.Mode.GM_SV == curr_mode:
					if "EIINT_RB" == intType:					# Auto save
						# print "CP 190 - 205: LSAB in CV_SV/GM_SV - EIINT - Auto save - MD1: %s" % priority
						RB_priority_LSAB_CV_SV_or_GM_SV[priority][column] = "Auto save"
				# """ in CV::UM mode RBCR0.BE[15:0] = 0xFFFF  && RBNR.BN < INCFG.ULNR && MDP at Auto-save operation """
				elif database.Mode.CV_UM == curr_mode or database.Mode.GM_UM == curr_mode:
					if "EIINT_RB" == intType:					# Auto save
						# print "CP 206 - 221: LSAB in CV_UM/GM_UM - EIINT - Auto save - MD1: %s" % priority
						RB_priority_LSAB_CV_UM_or_GM_UM[priority][column] = "Auto save"

		""" Main Item: Exception/Interrupt in EIINT autosave """
		""" Sequential exceptions """
		# """ in CV::SV mode RBCR0.BE[15:0] = 0xFFFF && RBNR.BN < INCFG.ULNR """

		if "resbank" == curr_line.InsName:
			""" Main Item: Resbank """
			""" Sub Item: Return saved context """
			# """ RBCR0.BE[15:0] = 0xFFFF  && RBNR.BN < INCFG.ULNR """
			if RBNR_BN < INTCFG_ULNR and 0xffff == RBCR0_BE:
				print "CP 145-148 + CP 433-440: Resbank get executed in target mode: %s" % curr_mode
				if 0 == RBCR0_MD:
					Resbank_inMode["MD0"][curr_mode] = "Yes"
				elif 1 == RBCR0_MD:
					Resbank_inMode["MD1"][curr_mode] = "Yes"

# -------------------------------- SUB FUNCTION -------------------------------------
""" check priority of current interrupt """
def checkIntPriority(curr_line):
	if curr_line.HasInt == True:
		for tup in set_Interrupt:
			# if tup[0] == curr_line.PC and tup[1] == name and tup[3] == "assert":
			if tup[0] == curr_line.PC:
				priority = int(tup[2])
				# print "NOTE: detect Interrupt: ", tup[1], " - PC: ", hex(curr_line.PC), "- Line: ", curr_line.Line
				return priority
	else:
		print "ERROR: Not detect Interrupt at - PC: ", hex(curr_line.PC), "- Line: ", curr_line.Line
		return ''

def PrintDictToFile(file_control, dict_data, msg):
	""" Print data that has structure is dictionaty to file """
	# print msg
	file_control.write("\n ** " + msg + " **" + "," + "CV mode" + "," + "GM Mode\n")
	for key, value in dict_data.items():
		output = (str(key)).rjust(15) + ',' + str(value[database.Mode.CV]).rjust(10) + ',' + str(value[database.Mode.GM]).rjust(10) + '\n'
		file_control.write(output)

def PrintPriorityDictToFile(file_control, dict_data, msg):
	""" Print data that has structure is dictionaty to file """
	# print msg
	file_control.write("\n ** " + msg + " **" + "," + "CV mode" + "," + "GM Mode\n")
	for key, value in dict_data.items():
		output = ("Priority " + str(key)).rjust(15) + ',' + str(value[database.Mode.CV]).rjust(10) + ',' + str(value[database.Mode.GM]).rjust(10) + '\n'
		file_control.write(output)

def PrintModeDictToFile(file_control, dict_data, msg):
	""" Print data that has structure is dictionaty to file """
	# print msg
	file_control.write("\n ** " + msg + " **" + "," + "CV_SV mode" + "," + "CV_UM Mode" + "," + "GM_SV mode" + "," + "GM_UM Mode" + "," + "HM_HV mode" + "," + "HM_UM Mode" + "\n")
	for key, value in dict_data.items():
		output = (str(key)).rjust(15) + ',' + str(value[database.Mode.CV_SV]).rjust(10) + ',' + str(value[database.Mode.CV_UM]).rjust(10) + ',' + str(value[database.Mode.GM_SV]).rjust(10) + ',' + str(value[database.Mode.GM_UM]).rjust(10) + ',' + str(value[database.Mode.HM_HV]).rjust(10) + ',' + str(value[database.Mode.HM_UM]).rjust(10) + '\n'
		file_control.write(output)

""" def IsFull(dict_data):
	countA = 0
	countB = 0
	for value in dict_data.values():
		if value[0] != 0: countA += 1
		if value[1] != 0: countB += 1
	if countA == len(dict_data) and countB == len(dict_data):
		print "countA = %d : countB = %d : len(dict_data) = %d" % (countA, countB, len(dict_data))
		print "dict_data is FULL"
		return True
	else: return False """
# -------------------------------- MAIN PROCESS -------------------------------------

# Scan all cforest log files in current Working directory to make data-base-files
log_num = 1
for cforest_log in InputFileName:
	print "No.: ", log_num, "File: ", cforest_log, " Time: ", datetime.datetime.now()
	raw_data_list = database.CollectData(cforest_log)
	raw_data_list = database.CorrectLineInfor(raw_data_list)
	#database.PrintData(raw_data_list)

	##Read file python to collect information of requested interrupt
	link_path = os.path.realpath(cforest_log)
	file_py_name = database.FindingLogPythonInt(link_path)
	set_Interrupt = database.DetectInterruptRequest(file_py_name)
	# print set_Interrupt

	for n in range(1, len(raw_data_list)-1):
		CheckingEIINT(raw_data_list[n-1], raw_data_list[n], raw_data_list[n+1])
	log_num += 1
	del raw_data_list

f = open('output.csv', 'wb')
PrintPriorityDictToFile(f, RB_priority_disable_DV, "Disable Register banking - EIINT - Direct Vector Method (CP 01-16 + CP 289-304)")
PrintPriorityDictToFile(f, RB_priority_disable_TBL, "Disable Register banking - EIINT - Table Reference Method (CP 17-32 + CP 305-320)")
PrintPriorityDictToFile(f, RB_priority_disable_TBL_pri, "Disable Register banking - EIINT - Direct Vector Method and individual priority (CP 33-48 + CP 321-336)")

PrintPriorityDictToFile(f, RB_priority_RB_enable_BN_MD0, "Enable Register banking - Auto save - MD0 (CP 113-128 + CP 401-416)")
PrintPriorityDictToFile(f, RB_priority_RB_enable_BE_BN_MD0, "Enable Register banking - Auto save - MD0 - RBCR0.BE (CP 81-96 + CP 369-384)")
PrintPriorityDictToFile(f, RB_priority_RB_enable_NC_BE_BN_MD0, "Enable Register banking - EIINT - Direct Vector Method - MD0 - RBCR0.BE - RBCR1.NC (CP 49-64 + CP 337-352)")

PrintPriorityDictToFile(f, RB_priority_RB_enable_BN_MD1, "Enable Register banking - Auto save - MD1 (CP 129-144 + CP 417-432)")
PrintPriorityDictToFile(f, RB_priority_RB_enable_BE_BN_MD1, "Enable Register banking - Auto save - MD1 - RBCR0.BE (CP 97-112 + CP 385-400)")
PrintPriorityDictToFile(f, RB_priority_RB_enable_NC_BE_BN_MD1, "Enable Register banking - EIINT - Direct Vector Method - MD1 - RBCR0.BE - RBCR1.NC (CP 65-80 + CP 353-368)")

PrintPriorityDictToFile(f, RB_priority_MDP_CV_SV_or_GM_SV, "MDP - EIINT - Auto save in CV_SV/GM_SV (CP 158-173 + CP 450-465)")
PrintPriorityDictToFile(f, RB_priority_MDP_CV_UM_or_GM_UM, "MDP - EIINT - Auto save in CV_UM/GM_UM (CP 174-189 + CP 466-481)")

PrintPriorityDictToFile(f, RB_priority_LSAB_CV_SV_or_GM_SV, "LSAB - EIINT - Auto save in CV_SV/GM_SV (CP 190-205 + CP 482-497)")
PrintPriorityDictToFile(f, RB_priority_LSAB_CV_UM_or_GM_UM, "LSAB - EIINT - Auto save in CV_UM/GM_UM (CP 206-221 + CP 498-513)")

PrintPriorityDictToFile(f, RB_priority_MDP_LSAB_CV_SV_or_GM_SV, "LSAB + MDP - EIINT - Auto save in CV_SV/GM_SV (CP 222-237 + CP 514-529)")
PrintPriorityDictToFile(f, RB_priority_MDP_LSAB_CV_UM_or_GM_UM, "LSAB + MDP - EIINT - Auto save in CV_UM/GM_UM (CP 228-253 + CP 530-545)")

PrintModeDictToFile(f, Resbank_inMode, "Resbank - Return saved context - MD1 (CP 145-148 + CP 433-440)")
PrintDictToFile(f, RBNR_BN_exceeding, "Exception/Interrupt in EIINT autosave - RBNR.BN value exceeding (CP 150-157 + CP 442-449)")
PrintDictToFile(f, Sequential_EIINT_RB, "Combination - Sequential EIINT Auto-save (CP 269-270 + CP 561-562)")
f.close()

#Backup data to a new file between script-executions
with open(AccumulationFile, 'wb') as file_bk:
	pickle.dump(RB_priority_disable_DV, file_bk)
	pickle.dump(RB_priority_disable_TBL, file_bk)
	pickle.dump(RB_priority_disable_TBL_pri, file_bk)

	pickle.dump(RB_priority_RB_enable_BN_MD0, file_bk)
	pickle.dump(RB_priority_RB_enable_BE_BN_MD0, file_bk)
	pickle.dump(RB_priority_RB_enable_NC_BE_BN_MD0, file_bk)

	pickle.dump(RB_priority_RB_enable_BN_MD1, file_bk)
	pickle.dump(RB_priority_RB_enable_BE_BN_MD1, file_bk)
	pickle.dump(RB_priority_RB_enable_NC_BE_BN_MD1, file_bk)

	pickle.dump(RB_priority_MDP_CV_SV_or_GM_SV, file_bk)
	pickle.dump(RB_priority_MDP_CV_UM_or_GM_UM, file_bk)

	pickle.dump(RB_priority_LSAB_CV_SV_or_GM_SV, file_bk)
	pickle.dump(RB_priority_LSAB_CV_UM_or_GM_UM, file_bk)

	pickle.dump(RB_priority_MDP_LSAB_CV_SV_or_GM_SV, file_bk)
	pickle.dump(RB_priority_MDP_LSAB_CV_UM_or_GM_UM, file_bk)

	pickle.dump(Resbank_inMode, file_bk)
	pickle.dump(RBNR_BN_exceeding, file_bk)
	pickle.dump(Sequential_EIINT_RB, file_bk)
