# -------------------------------- HOW TO USE -------------------------------------
# 		import database;
# ---------------------------------------------------------------------------------


import sys;
import csv;
import re;
import copy;
import collections;	# support create dict has order

#---------------------------------------------------- Instruction Behavior Definition ----------------------------------------------
class InsBehavior:
	LD = 1
	ST = 2
	LD_ST = 3

#---------------------------------------------------- Mode Definition ----------------------------------------------
class Mode:
	CV 	  = 1	# Conventional mode
	CV_SV = 2	# SV privilege in Conventional mode
	CV_UM = 3	# UM privilege in Conventional mode
	HM    = 4	# Host mode
	HM_HV = 5	# HV privilege in Host mode
	HM_UM = 6	# UM privilege in Host mode
	GM    = 7	# Guest mode
	GM_SV = 8	# SV privilege in Guest mode
	GM_UM = 9	# UM privilege in Guest mode
	DM	  = 10	# Debug mode
	DM_SV = 11	# SV privilege in Debug mode in Conventional mode
	DM_HV = 12	# HV privilege in Host mode in Debug mode

# Dict to store mode execution status
ModeMap = {Mode.CV_SV:0, Mode.CV_UM:0, Mode.HM_HV:0, Mode.HM_UM:0, Mode.GM_SV:0, Mode.GM_UM:0, Mode.DM_SV:0, Mode.DM_HV:0}

# Object which contains all available opcodes of cache/pref instructions
class InssExeInMode:
	def __init__(self, Ins_List):
		self.map = collections.OrderedDict()
		for ins in Ins_List:
			self.map[ins] = dict(ModeMap)

	def Update_result(self, _name, _mode):
		self.map[_name][_mode] = 1

	def show(self):
		print '%10s  %10s  %10s  %10s  %10s  %10s  %10s  %10s  %10s' %("INS", "CV::SV", "CV::UM", "HOST::HV", "HOST::UM", "GUEST::SV", "GUEST::UM", "DEBUG_SV", "DEBUG_HV")
		print "-----------------------------------------------------------------------------------"
		for key, value in self.map.items():
			print '%10s  %10s  %10s  %10s  %10s  %10s  %10s  %10s  %10s' % (key, value[Mode.CV_SV], value[Mode.CV_UM],\
			value[Mode.HM_HV], value[Mode.HM_UM], value[Mode.GM_SV], value[Mode.GM_UM], value[Mode.DM_SV], value[Mode.DM_HV])
		print "-----------------------------------------------------------------------------------"

	def ExportCSV(self, _outfile_name, _mode):
		output_file = open(_outfile_name, _mode)
		writer = csv.writer(output_file)
		writer.writerow(["INS", "CV::SV", "CV::UM", "HOST::HV", "HOST::UM", "GUEST::SV", "GUEST::UM", "DEBUG_SV", "DEBUG_HV"])
		for key, value in self.map.items():
			writer.writerow([key, value[Mode.CV_SV], value[Mode.CV_UM], value[Mode.HM_HV], value[Mode.HM_UM],\
			value[Mode.GM_SV], value[Mode.GM_UM], value[Mode.DM_SV], value[Mode.DM_HV]])
		output_file.close()

	def IsFull(self):
		def ExeInsFull(mode_map):
			for key in mode_map.keys():
				if key != Mode.DM_SV and key != Mode.DM_HV and mode_map[key] == 0:
					return False
			return True

		for value in self.map.values():
			if not ExeInsFull(value):
				return False
		return True

#---------------------------------------------------- General register ----------------------------------------------
GR = dict()

# GR = { 'r0' : 0, 'r1' : 0, 'r2' : 0, 'r3' : 0, 'r4' : 0, 'r5' : 0, 'r6' : 0, 'r7' : 0, 'r8' : 0, 'r9' : 0,
	   # 'r10' : 0, 'r11' : 0, 'r12' : 0, 'r13' : 0, 'r14' : 0, 'r15' : 0, 'r16' : 0, 'r17' : 0, 'r18' : 0, 'r19' : 0,
	   # 'r20' : 0, 'r21' : 0, 'r22' : 0, 'r23' : 0, 'r24' : 0, 'r25' : 0, 'r26' : 0, 'r27' : 0, 'r28' : 0, 'r29' : 0,
	   # 'r30' : 0, 'r31' : 0 }

#---------------------------------------------------- Wire register --------------------------------------------------
WR = dict()

# WR = { 'wr0' : '0', 'wr1' : '0', 'wr2' : '0', 'wr3' : '0', 'wr4' : '0', 'wr5' : '0', 'wr6' : '0', 'wr7' : '0', 'wr8' : '0', 'wr9' : '0',
	   # 'wr10' : '0', 'wr11' : '0', 'wr12' : '0', 'wr13' : '0', 'wr14' : '0', 'wr15' : '0', 'wr16' : '0', 'wr17' : '0', 'wr18' : '0', 'wr19' : '0',
	   # 'wr20' : '0', 'wr21' : '0', 'wr22' : '0', 'wr23' : '0', 'wr24' : '0', 'wr25' : '0', 'wr26' : '0', 'wr27' : '0', 'wr28' : '0', 'wr29' : '0',
	   # 'wr30' : '0', 'wr31' : '0' }

#---------------------------------------------------- MPU Entry -----------------------------------------------------
MPLA = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
MPUA = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
MPAT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

#---------------------------------------------------- Debug Channel ---------------------------------------------------
BPC = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
BPAV = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
BPAM = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


#---------------------------------------------------- Exception and Interrupt ----------------------------------------
#EXPlist = {}
# key = address
# value = name

# --------- Update list -----------
# if key in EXPlist:
	# EXPlist[key].append( value )
# else:
	# EXPlist[key] = [value]

#---------------------------------------------------- System register -------------------------------------------------

SR = { 'EIPC': 0, 'EIPSW' : 0, 'FEPC' : 0, 'FEPSW' : 0, 'PSW' : 0, 'FPSR' : 0, 'FPEPC' : 0, 'FPST' : 0, 'FPCC' : 0, 'FPCFG' : 0, 'EIIC' : 0, 'FEIC' : 0, 'PSWH' : 0, 'CTPC' : 0, 'CTPSW' : 0, 'EIPSWH' : 0, 'FEPSWH' : 0, 'CTBP' : 0, 'SNZCFG' : 0, 'EIWR' : 0, 'FEWR' : 0,
	   'SPID' : 0, 'SPIDLIST' : 0, 'RBASE' : 0, 'EBASE' : 0, 'INTBP' : 0, 'MCTL' : 0, 'PID' : 0, 'FPIPR' : 0, 'SVLOCK' : 0, 'SCCFG' : 0, 'SCBP' : 0, 'HVCFG' : 0, 'GMCFG' : 0, 'HVSB' : 0,
	   'PEID' : 0, 'BMID' : 0, 'MEA' : 0, 'MEI' : 0, 'ISPR' : 0, 'IMSR' : 0, 'ICSR' : 0, 'INTCFG' : 0, 'PLMR' : 0, 'RBCR0' : 0, 'RBCR1' : 0, 'RBNR' : 0, 'RBIP' : 0,
	   'DBGEN' : 0, 'DBPSWH' : 0, 'DBSPC' : 0, 'DBIC' : 0, 'DBPC' : 0, 'DBPSW' : 0, 'DIR0' : 0, 'DIR1' : 0, 'BPC' : 0, 'BPAV' : 0, 'BPAM' : 0, 'DBCFG' : 0, 'DBWR' : 0,
	   'ICTAGL' : 0, 'ICTAGH' : 0, 'ICDATL' : 0, 'ICDATH' : 0, 'ICCTRL' : 0, 'ICCFG' : 0, 'ICERR' : 0,
	   'MPM' : 0, 'MPCFG' : 0, 'MCA' : 0, 'MCS' : 0, 'MCC' : 0, 'MCR' : 0, 'MCI' : 0, 'MPIDX' : 0, 'MPBK' : 0, 'MPLA' : 0, 'MPUA' : 0, 'MPAT' : 0, 'MPID0' : 0, 'MPID1' : 0, 'MPID2' : 0, 'MPID3' : 0, 'MPID4' : 0, 'MPID5' : 0, 'MPID6' : 0, 'MPID7' : 0,
	   'GMEIPC' : 0, 'GMEIPSW' : 0, 'GMFEPC' : 0, 'GMFEPSW' : 0, 'GMPSW' : 0, 'GMMEA' : 0, 'GMMEI' : 0, 'GMEIIC' : 0, 'GMFEIC' : 0, 'GMSPID' : 0, 'GMSPIDLIST' : 0, 'GMEBASE' : 0, 'GMINTBP' : 0, 'GMINTCFG' : 0, 'GMPLMR' : 0, 'GMSVLOCK' : 0, 'GMMPM' : 0, 'GMEIWR' : 0, 'GMFEWR' : 0, 'GMPEID' : 0,
	   'FXSR' : 0, 'FXST' : 0, 'FXINFO' : 0, 'FXCFG' : 0, 'FXXC' : 0, 'FXXP' : 0,
	   'TSCOUNTL' : 0, 'TSCOUNTH' : 0, 'TSCTRL' : 0, 'PMUMCTRL' : 0, 'PMGMCTRL' : 0,
	   'LSTEST0' : 0, 'LSTEST1' : 0, 'LSCFG' : 0, 'ICBKEY' : 0, 'IFCR' : 0, 'IFCR1' : 0, 'BRPCTRL0' : 0, 'BRPCTRL1' : 0, 'BRPCFG' : 0, 'BRPACTRL' : 0, 'BRPDATA' : 0,
	   'DCBKEY' : 0, 'LSUCR' : 0, 'LSULNK0' : 0, 'LSULNK1' : 0, 'L1RLCR' : 0, 'L1RLNK0' : 0, 'L1RLNK1' : 0, 'L1RCFG' : 0, 'DECFG' : 0, 'DECTRL' : 0, 'DEVDS' : 0, 'RDBCR' : 0, 'RDBACR' : 0, 'RDBATAG' : 0, 'RDBADAT0' : 0, 'RDBADAT1' : 0, 'RDBADAT2' : 0, 'RDBADAT3' : 0, 'RDBSTAT' : 0,
	   'PMCTRL0' : 0, 'PMCTRL1' : 0, 'PMCTRL2' : 0, 'PMCTRL3' : 0, 'PMCTRL4' : 0, 'PMCTRL5' : 0, 'PMCTRL6' : 0, 'PMCTRL7' : 0, 'PMCOUNT0' : 0, 'PMCOUNT1' : 0, 'PMCOUNT2' : 0, 'PMCOUNT3' : 0, 'PMCOUNT4' : 0, 'PMCOUNT5' : 0, 'PMCOUNT6' : 0, 'PMCOUNT7' : 0,
	   'PMSUBCND0' : 0, 'PMSUBCND1' : 0, 'PMSUBCND2' : 0, 'PMSUBCND3' : 0, 'PMSUBCND4' : 0, 'PMSUBCND5' : 0, 'PMSUBCND6' : 0, 'PMSUBCND7' : 0 }

SR = { 'HVCFG' : 0, 'PSWH' : 0, 'PSW' : 0, 'GMPSW' : 0, 'DIR0' : 0}

#---------------------------------------------------- List instruction have not operand ------------------------------------
InsNotOpr = set(['resbank', 'di', 'ei', 'dbtrap', 'dbcp', 'nop', 'feret', 'eiret', 'ctret', 'dbret', 'synci', 'syncp', 'syncm', 'synce', 'snooze', 'halt', 'cll', '0'])

LoadObj = {'EIINT', 'GMEIINT', 'callt', 'cache', 'pref', 'dispose', 'disposej', 'ld.b', 'ld.b+', 'ld.b-', 'ld.b23', 'ld.bu', 'ld.bu+', 'ld.bu-', 'ld.bu23', 'ld.dw',
		   'ld.h', 'ld.h+', 'ld.h-', 'ld.h23', 'ld.hu', 'ld.hu+', 'ld.hu-', 'ld.hu23', 'ld.w', 'ld.w+', 'ld.w-', 'ld.w23', 'ldl.bu', 'ldl.hu', 'ldl.w',
		   'ldm.gsr', 'ldm.mp', 'ldv.dw', 'ldv.qw', 'ldv.w', 'ldvz.h4', 'popsp', 'resbank', 'sld.b', 'sld.bu', 'sld.h', 'sld.hu', 'sld.w', 'switch', 'syscall', 'tst1', 'tst1b'}

StoreObj = {'EIINT', 'GMEIINT', 'prepare', 'prepare16', 'prepare16hi', 'prepare32', 'preparesp', 'pushsp', 'sst.b', 'sst.h', 'sst.w', 'st.b', 'st.b+', 'st.b-', 'st.b23',
			'st.dw', 'st.h', 'st.h+', 'st.h-', 'st.h23', 'st.w', 'st.w+', 'st.w-', 'st.w23', 'stc.b', 'stc.h', 'stc.w', 'stm.gsr', 'stm.mp', 'stv.dw', 'stv.qw', 'stv.w', 'stvz.h4'}

LoadStoreObj = {'caxi', 'clr1', 'clr1r', 'not1', 'not1r', 'set1', 'set1r'}


#---------------------------------------------------------- Declare database -----------------------------------------------
class Data:
	def __init__(self):
		self.Line = 0	# line of Cforest log
		self.PC = 0 # PC
		self.Opcode = '' # Opcode of instruction
		self.InsName = '' # name of instruction
		self.Opr = list() # List of operand of instruction
		self.Behavior = 0 # 0: common instruction; 1: Load Ins; 2: Store Ins; 3: Load/Store Ins
		self.memAddr = list() # list of access memory addree in case of load/store instruction
		self.SR = dict() # value of system register
		self.GR = dict() # value of General register
		self.WR = dict() # value of Wire register
		self.MPLA = list() # store 32 value of MPLA
		self.MPUA = list() # store 32 value of MPUA
		self.MPAT = list() # store 32 value of MPAT
		self.BPC = list()  # store value of debug control channel
		self.BPAV = list()  # store value of debug address channel
		self.BPAM = list()  # store value of debug mask channel
		self.LLBIT = 0 # If there is a link bit at address LLBIT = 1 and vice versa
		self.HasInt	= False # True if It has request interrupt at line (assert or de-assert) and vice versa
		self.Exp = list() # Exception information at line include: Name, Address, Cause code

	#Export data to file
	def ExportData(data, file_control):
		data_write = ''

		data_write = 'PC: ' + hex(data.PC)
		file_control.write( data_write )

		data_write = ' -- Opcode: ' + data.Opcode
		file_control.write( data_write )

		data_write = ' -- Ins: ' + data.InsName
		file_control.write( data_write )

		if len(data.Opr) != 0:
			data_write = ''
			file_control.write( ' -- Operand: ' )
			for opr in data.Opr:
				data_write += opr + ' '
			file_control.write( data_write )

		if data.Behavior == InsBehavior.LD:
			file_control.write( ' -- Load Ins ' )
		if data.Behavior == InsBehavior.ST:
			file_control.write( ' -- Store Ins ' )
		if data.Behavior == InsBehavior.LD_ST:
			file_control.write( ' -- Load/Store Ins ' )

		if data.HasInt == True:
			data_write = ' -- Interrupt request'
			file_control.write( data_write )

		file_control.write('\n')

		if len(data.memAddr) != 0:
			data_write = ''
			file_control.write( 'MemAddAccess: ' )
			for mem in data.memAddr:
				data_write += hex(mem) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		data_write = ''
		file_control.write( 'SystemRegister: ' )
		for key, value in data.SR.items():
			data_write += key + '=' + hex(value) + ' '
		file_control.write( data_write )
		file_control.write('\n')

		if len(data.GR) != 0:
			data_write = ''
			file_control.write( 'GeneralRegister: ' )
			for key, value in data.GR.items():
				data_write += key + '=' + hex(value) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.WR) != 0:
			data_write = ''
			file_control.write( 'WireRegister: ' )
			for key, value in data.WR.items():
				data_write += key + '=' + value + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.MPLA) != 0:
			data_write = ''
			for n in range(len(data.MPLA)):
				data_write += 'MPLA' + str(n) + '=' + hex(data.MPLA[n]) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.MPUA) != 0:
			data_write = ''
			for n in range(len(data.MPUA)):
				data_write += 'MPUA' + str(n) + '=' + hex(data.MPUA[n]) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.MPAT) != 0:
			data_write = ''
			for n in range(len(data.MPAT)):
				data_write += 'MPAT' + str(n) + '=' + hex(data.MPAT[n]) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.BPC) != 0:
			data_write = ''
			for n in range(len(data.BPC)):
				data_write += 'BPC' + str(n) + '=' + hex(data.BPC[n]) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.BPAV) != 0:
			data_write = ''
			for n in range(len(data.BPAV)):
				data_write += 'BPAV' + str(n) + '=' + hex(data.BPAV[n]) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.BPAM) != 0:
			data_write = ''
			for n in range(len(data.BPAM)):
				data_write += 'BPAM' + str(n) + '=' + hex(data.BPAM[n]) + ' '
			file_control.write( data_write )
			file_control.write('\n')

		if data.LLBIT != 0:
			data_write = 'LLBIT = ' + hex(data.LLBIT)
			file_control.write( data_write )
			file_control.write('\n')

		if len(data.Exp) != 0:
			file_control.write( 'Exception: ' )
			data_write = data.Exp[0] + ' -- Address: ' + hex(data.Exp[1]) + ' -- Cause code: ' + hex(data.Exp[2])
			file_control.write( data_write )
			file_control.write('\n')

#-------------------------------------------------------- PUBLIC FUNCTION --------------------------------------------------------
def FindingLogPythonInt(link_path):
	##Read file python to collect information of requested interrupt
	##How to use:
	##	for log in folder_log_Cforest:
	##		link_path = os.path.realpath(log)
	##		file_py_name = database.FindingLogPythonInt(link_path)
	##		set_Interrupt = database.DetectInterruptRequest(file_py_name)
	##Note: Tree directories:
	##				folder_log_Cforest
	##		_______________|_____________
	##		|			|				|
	##	cf_ff=0.log	cf_ff=1.log		log_python
	##							_______|_________
	##							|				|
	##						  0.py 		       1.py

	file_cf_name = link_path.split("/")[-1]
	seed_num = file_cf_name.split("=")[1].split(".")[0].split("x")[1]
	file_py_name = link_path.replace(file_cf_name, "") + "log_python/" + seed_num + ".py"
	return file_py_name

def DetectInterruptRequest(file_name):
	file_python_control = open(file_name, 'r')
	file_python_content = file_python_control.readlines()
	result = set()

	for n in range(0, len(file_python_content)):
		line = file_python_content[n]
		pc_addr = 0
		name_Int = ""
		priority = 0
		async_type = ""
		if "set_event" in line or "set_clear_event" in line:
			 fields = line.split("(")
			 contents = fields[1].split(",")
			 pc_addr = int(contents[0], 16)
			 name_Int = contents[1].strip('"').upper()

			 if "set_event" in line and ("EIINT" in name_Int or "EITBL" in name_Int):
			 	priority = int(contents[3], 16)

			 if "set_event" in line:
			 	async_type = "assert"
			 elif "set_clear_event" in line:
			 	async_type = "deassert"

			 tup = (pc_addr, name_Int, priority, async_type)
			 result.add(tup)

	#return set of tuple: (PC, Name of Interrupt, priority, Type of asynchronous label)
	return result

def ConvertIntName(int_name, behavior):
	""" Function support determine type of interrupt based on behavior """
	""" You need to call function CorrectLineInfor before this function"""
	if int_name not in {'EIINT', 'GMEIINT'}:
		return int_name

	if behavior == InsBehavior.LD:
		int_name += '_TBL'
	elif behavior == InsBehavior.LD_ST:
		int_name += '_RB'

	return int_name

# def IsHandler(prev_line, InHanler):
	# """ Function support detect instruction in handler"""
	# """ Return True if current insturction in handler and vice versa """
	# return_hanler = {'eiret', 'feret', 'dbret'}
	# if prev_line.Exp and prev_line.Exp[0] != 'SYSCALL':
		# InHanler = True
	# elif prev_line.InsName in return_hanler:
		# InHanler = False

	# return InHanler

def IsHandler(prev_line, InHanler):
	""" Function support detect instruction in handler"""
	""" Return True if current insturction in handler and vice versa """
	if 'exp' not in IsHandler.__dict__:
		IsHandler.exp = list()
		IsHandler.return_ins = {'eiret', 'feret', 'dbret'}
		IsHandler.return_exp = {'MDP': 'feret', 'MIP': 'feret', 'SYSERR': 'feret', 'SYSERR_RB': 'feret',
								'SYSERR_REEXEC': 'feret', 'RIE': 'feret', 'UCPOP0': 'feret', 'UCPOP1': 'feret',
								'UCPOP2': 'feret','PIE': 'feret', 'MAE': 'feret', 'FETRAP': 'feret', 'FENMI': 'feret',
								'FEINT': 'feret', 'GMFEINT': 'feret', 'MDP(EIINT)': 'feret', 'MDP(GMEIINT)': 'feret',

							    'HVTRAP': 'eiret', 'FPE': 'eiret', 'FXE': 'eiret', 'TRAP0': 'eiret',
								'TRAP1': 'eiret', 'EIINT': 'eiret', 'GMEIINT': 'eiret',
							    'BGEIINT': 'eiret', 'BGFEINT': 'eiret',

							    'DBTRAP': 'dbret', 'AE': 'dbret', 'LSAB': 'dbret', 'PCB': 'dbret',
								'DBNMI': 'dbret', 'DBINT': 'dbret'}

	if prev_line.Exp and prev_line.Exp[0] != 'SYSCALL':
		IsHandler.exp.append(prev_line.Exp[0])
		InHanler = True
	elif prev_line.InsName in IsHandler.return_ins:
		if IsHandler.exp and IsHandler.return_exp[IsHandler.exp[-1]] == prev_line.InsName:
			del IsHandler.exp[-1]

		if not IsHandler.exp:
			InHanler = False

	return InHanler

def CollectC2B1Pos(data, start, end):
	set_1st_C2B1_ins_before_Bcond = {"cmp", "cmp5", "add", "add5", "sub", "subr", "tst", "and", "xor", "or", "shr5", "sar5", "shl5"}
	set_Bcond9 = {"bc9", "be9", "bge9", "bgt9", "bh9", "bl9", "ble9", "blt9", "bn9", "bnc9", "bne9", "bnh9", "bnl9", "bnv9", "bnz9", "bp9", "bsa9", "bv9", "bz9", "br"}
	set_Bcond17 = {"bc17", "be17", "bge17", "bgt17", "bh17", "bl17", "ble17", "blt17", "bn17", "bnc17", "bne17", "bnh17", "bnl17", "bnv17", "bnz17", "bp17", "bsa17", "bv17", "bz17"}
	set_mov = {"movr", "mov5"}
	set_2nd_C2B1_ins_after_mov = {"add", "add5", "sub", "subr", "and", "xor", "or", "shr5", "sar5", "shl5"}
	break_exp = {"PCB"}
	START_POS = 100
	result = dict()
	for n in range (start, end):
		tup = ()
		line = data[n]
		prev_line = data[n-1]
		m = n - START_POS
		exception = 0

		if (line.InsName in set_1st_C2B1_ins_before_Bcond or line.InsName in set_mov) and len(line.Exp) == 0:
			if prev_line.InsName == "dbret" and prev_line.SR["DBIC"] == 0xB5:
				while not (data[m].PC == line.PC and len(data[m].Exp) != 0 and data[m].Exp[0] in break_exp):
					m = m - 1
			else:
				m = n

			##Do not record data[m].Line because Line number can be duplicated by exception/interrupt, so the index isn't correct
			tup = (m,)

			next_line = data[n+1]

			if ((line.InsName in set_1st_C2B1_ins_before_Bcond and (next_line.InsName in set_Bcond9 or next_line.InsName in set_Bcond17))
				or (line.InsName in set_mov and next_line.InsName in set_2nd_C2B1_ins_after_mov)):
				if len(next_line.Exp) != 0:	exception = 1
				tup = tup + (n + 1, exception)
			else:
				continue

			if line.InsName in set_1st_C2B1_ins_before_Bcond:
				if (next_line.InsName in set_Bcond9):
					key = line.InsName + "_Bcond9"
				else:
					key = line.InsName + "_Bcond17"
			else:
				key = line.InsName + "_" + next_line.InsName

			if key not in result:
				result[key] = set()

			result[key].add(tup)

	return result

def CorrectLineInfor(data):
	""" Correct behavior, memory address, instruction name for instruction was MDP/LSAB/PCB exception """
	START_POS = 50
	special_exp = {'MDP', 'MDP(EIINT)', 'MDP(GMEIINT)', 'LSAB', 'PCB', 'AE'}

	n = 0
	while n < len(data):
		line = data[n]
		if len(line.Exp) != 0 and line.Exp[0] in special_exp:
			m = n + START_POS
			while not (data[m].PC == line.PC and (len(data[m].Exp) == 0 or data[m].Exp[0] not in special_exp)):
				m += 1

			if line.InsName in {'stc.b', 'stc.h', 'stc.w'}:
				line.Behavior = InsBehavior.ST
				line.memAddr  = [line.Exp[1]]

			else:
				line.Behavior = data[m].Behavior
				line.memAddr  = list(data[m].memAddr)

			line.InsName  = data[m].InsName

			n += START_POS
		else:
			n += 1

	return data

def GetIndexStartRandomCode(data):
	""" Find posiotion start random code """
	for n in range(len(data)):
		if data[n].InsName == 'dbtag':
			if data[n-1].InsName == 'eiret':
				return n
			else:
				return n - 1 # In case of there is an ajustment code before dbtag

def GetIndexEndRandomCode(data):
	""" Find posiotion end random code """
	for n in range(len(data) - 1, 0, -1):
		if data[n].InsName == 'dbtag':
				return n

def ConvertInsHasSpecialOpr(ins_name, operand):
	""" Function to convert instruction load/store to increase/decrease """
	temp_operand = list(operand)
	if 'st.' in ins_name or 'ld.' in ins_name:
		for i in range(len(temp_operand)):
			Opr = temp_operand[i]
			if Opr[-1] in {'+', '-'}:
				ins_name += Opr[-1]
				temp_operand[i] = temp_operand[i][:-1]
				break;
	return ins_name, temp_operand

def GetMode(_SR):
	""" Get mode at current position """
	hvcfg_hve = GetValueBitRange(_SR['HVCFG'],0,0)
	pswh_gm = GetValueBitRange(_SR['PSWH'],31,31)
	dir0_dm = GetValueBitRange(_SR['DIR0'],0,0)

	if dir0_dm == 1: return Mode.DM

	if hvcfg_hve == 0:
		return Mode.CV
	else:
		if pswh_gm == 0:
			return Mode.HM
		else:
			return Mode.GM

def GetModeAndPrivilege(_SR):
	""" Get mode and privilege of current position """
	hvcfg_hve = GetValueBitRange(_SR['HVCFG'],0,0)
	pswh_gm = GetValueBitRange(_SR['PSWH'],31,31)
	psw_um = GetValueBitRange(_SR['PSW'],30,30)
	gmpsw_um = GetValueBitRange(_SR['GMPSW'],30,30)
	dir0_dm = GetValueBitRange(_SR['DIR0'],0,0)

	if hvcfg_hve == 0:
		if dir0_dm == 1: return Mode.DM_SV
		else:
			if psw_um == 0:	return Mode.CV_SV
			else: return Mode.CV_UM
	else:
		if dir0_dm == 1: return Mode.DM_HV
		else:
			if pswh_gm == 0:
				if psw_um == 0: return Mode.HM_HV
				else: return Mode.HM_UM
			else:
				if gmpsw_um == 0: return Mode.GM_SV
				else: return Mode.GM_UM

def FilterBitCombination(data, list_name_data, dict_name_fixed, list_name_toggle):
	""" Filter bit combination (start pos is 0) at dict_name_fixed {name: value} and toggle name list"""

	result = collections.OrderedDict()

	if len(data) != 0 and len(list_name_data) != len(data.keys()[0]):
		print "ERROR: List name of data must be same size with key of data. Should use function CreateBinMatrix to create data"
		print data.keys()[0]
		return result

	if len(dict_name_fixed) != 0:
		if (len(list_name_toggle) + len(dict_name_fixed)) > len(list_name_data):
			print "ERROR: All key of dict_name_fixed and element of list_name_toggle must be in list_name_data"
			return result
	else:
		if len(list_name_toggle) > len(list_name_data):
			print "ERROR: All element of list_name_toggle must be in list_name_data"
			return result

	list_pos_toggle = [None] * len(list_name_toggle)
	k = 0
	for n in range (len(list_name_toggle)):
		for m in range (len(list_name_data)):
			if (list_name_toggle[n] == list_name_data[m]):
				list_pos_toggle[k] = m
				k += 1
				break

	dict_pos_fixed = collections.OrderedDict()
	for k, v in dict_name_fixed.items():
		for m in range (len(list_name_data)):
			if k == list_name_data[m]:
				dict_pos_fixed[m] = v
				break

	for key, value in data.items():
		flag = False
		for k, v in dict_pos_fixed.items():
			if key[k] != v:
				flag = True
				break;
		if flag == True:
			continue;

		new_key = ''.join(val for val in dict_pos_fixed.values())
		for pos in list_pos_toggle:
			new_key += key[pos]

		result[new_key] = value | result.setdefault(new_key, value)

	if len(result) != 0 and len(dict_name_fixed) + len(list_name_toggle) != len(result.keys()[0]):
		print "ERROR: Input data length and output doesn't equal"
		print "list_name_data: ", list_name_data
		print "dict_name_fixed: ", dict_name_fixed
		print "list_name_toggle: ", list_name_toggle

	return result

def CreateBinMatrix(list_bit_sreg):
	""" Create data structure support check system register combination """
	dict_bit_sreg = collections.OrderedDict()
	size = len(list_bit_sreg)
	numb_of_case = 2**size

	for n in range (0, numb_of_case):
		bit = bin(n)
		bit_str = str(bit).replace("0b", "").zfill(size)
		dict_bit_sreg[bit_str] = 0

	return dict_bit_sreg

def GetSRbitCombination(sr_list, sr_data, comb_result):
	""" Get combination value of list system register """
	""" format sr_list = [sr1 name, bit, sr2 name, bit, ...]
		sr name (string): name of system register
		bit (interger): bit combination
		----------------------- How to use --------------------------
		PSW_MPM_name = ['PSW.UM', 'MPM.MPE']
		PSW_MPM_bit = ['PSW', 30, 'MPM', 0]
		PSW_MPM_comb =  {'00': 0, '01': 0, '10': 0, '11': 0} or PSW_MPM_comb = CreateBinMatrix(PSW_MPM_name)
		for n in range(len(raw_data_list)):
			raw_data = raw_data_list[n]
			PSW_MPM_comb = database.GetSRbitCombination(PSW_MPM_bit, raw_data.SR, PSW_MPM_comb)

		database.PrintSRbitCombination(f, PSW_MPM_comb, PSW_MPM_name)
		--------------------------------------------------------------
	"""

	if len(sr_list) % 2 != 0:
		print "ERROR: input function GetSRcombination() is wrong"
		return
	n = 0
	key = ''
	while n < len(sr_list):
		name = sr_list[n]
		bit = sr_list[n + 1]
		val = GetValueBitRange(sr_data[name], bit, bit)
		key += str(val)
		n += 2

	comb_result[key] = 1

	return comb_result

def PrintBitCombination(file_control, data, name_list, length = 10):
	""" Print data of check point for system register combination to file """
	# eg_data_2bit =  {'00': 0, '01': 0, '10': 0, '11': 0}
	# eg_data_3bit = { '000': 0, '001': 0, '010': 0, '011': 0, '100': 0, '101': 0, '110': 0, '111': 0 }
	# eg_data_4bit = {'0000': 0, '0001': 0, '0010': 0, '0011': 0, '0100': 0, '0101': 0, '0110': 0, '0111': 0, '1000': 0, '1001': 0, '1010': 0, '1011': 0, '1100': 0, '1101': 0, '1110': 0, '1111': 0}

	if len(data) != 0 and len(data.keys()[0]) != len(name_list):
		print "ERROR: key of data and sr_name_list must same size"
		return

	new_list = list(name_list)
	new_list.append('Value')
	file_control.write(','.join(column.rjust(length) for column in new_list))
	file_control.write('\n')

	for key, value in data.items():
		output = ','.join(column.rjust(length) for column in key)
		output = output + ',' + str(value).rjust(length)
		file_control.write(output)
		file_control.write('\n')

def merge_two_dicts(x, y):
	"""z becomes a merged dictionary with values from y replacing those from x """
	z = x.copy()   # start with x's keys and values
	z.update(y)    # modifies z with y's keys and values & returns None
	return z

def GetValueBitRange(number, start, end):
	"""  Get value from specific bit range (start and end) of number """
	number_bit_range = end - start + 1
	mask = 2**number_bit_range - 1
	result = (number >> start) & mask
	return result

def CollectData(FileName):
	""" Collect necessary data from Cforest log line by line """
	file_control = open(FileName, 'r')
	file_content = file_control.readlines()
	result = list()
	is_enable_MPU = False
	is_enable_DEBUG = False
	link_bit = 0
	int_status = False
	exp_addr = 0
	exp_name = ''
	exp_cause_code = 0

	for n in range(2, len(file_content)):
		# if n == 10000:
			# break;

		line = file_content[n]

		if 'Warning' in line or 'Error' in line or 'Info' in line or 'Exception' in line or 'Break' in line or '<All' in line or '<New' in line or 'ms_pe' in line or 'Invalid' in line :
			# Detect interrupt
			int_status = GetInterruptRequest(line, int_status)
			# Get LLBIT
			link_bit = GetLLBIT(line, link_bit)
			# Exception Information
			exp_addr = GetExceptionAddr(line, exp_addr)
			exp_name, exp_cause_code = GetExpNameAndCauseCode(line, exp_name, exp_cause_code)
			continue

		line = line.split()
		# Initialize data
		line_data = Data()
		accessMemflag = 0 # 1: load; 2: store
		is_enable_GR = False
		is_enable_WR = False
		# Collect PC, Instruction name and operand (if any)
		line_data.Line = int(line[1])
		line_data.PC = int(line[3], 16)
		line_data.Opcode = line[4]
		line_data.InsName = line[5]
		if line_data.InsName not in InsNotOpr:
			line_data.Opr = ParseOperand(line[6])
			line = line[7:]
		else:
			line = line[6:]
		# Get LLBIT infomation
		line_data.LLBIT = link_bit
		# Get status of Interrupt
		if int_status == True:
			line_data.HasInt = True
			int_status = False
		# Get Exception/Interrupt infomation
		if len(exp_name) != 0:
			if exp_addr == 0:
				exp_addr = line_data.PC
			line_data.Exp = [exp_name, exp_addr, exp_cause_code]
			exp_addr = 0
			exp_name = ''
			exp_cause_code = 0

		for field in line:
			if '=>' in field:
				fields = field.split('=>')
				accessMemflag = InsBehavior.LD
			elif '<=' in field:
				fields = field.split('<=')
				accessMemflag = InsBehavior.ST

			obj = fields[0]
			value = fields[1]
			if len(value) <= 16:
				value = int(value, 16)
			# Collect update data to GR, WR, SR, Memory address
			if obj in GR:
				GR[obj] = value
				is_enable_GR = True
			elif obj in WR:
				WR[obj] = value
				is_enable_WR = True
			elif GetMPUentry(obj, value) == True:
				is_enable_MPU = True
				# print "[DEBUG] GetMPUentry: obj = ", obj, " - value = ", value, "\n"
				#add value for MPLA, MPUA, MPAT
				SR[obj] = value
			elif GetDebugChannel(obj, value) == True:
				is_enable_DEBUG = True
				#add value for BPC, BPAV, BPAM
				# print "[DEBUG] GetDebugChannel: obj = ", obj, " - value = ", value, "\n"
				SR[obj] = value
			elif obj in SR:
				SR[obj] = value
			elif ParsePSWflagbit(obj, value) == True:
				continue;
			elif ')' in obj:
				mem_addr = obj.lstrip('(').rstrip(')')
				mem_addr = int(mem_addr, 16)
				line_data.memAddr.append(mem_addr)

				if line_data.Behavior == 0:
					line_data.Behavior = accessMemflag
				elif line_data.Behavior != accessMemflag:
					line_data.Behavior = InsBehavior.LD_ST


		line_data.SR = dict(SR)
		if is_enable_GR == True:
			line_data.GR = dict(GR)
		if is_enable_WR == True:
			line_data.WR = dict(WR)
		if is_enable_MPU == True:
			line_data.MPLA = list(MPLA)
			line_data.MPUA = list(MPUA)
			line_data.MPAT = list(MPAT)
		if is_enable_DEBUG == True:
			line_data.BPC = list(BPC)
			line_data.BPAV = list(BPAV)
			line_data.BPAM = list(BPAM)

		result.append(line_data)

	file_control.close()
	return result

def PrintData(database):
	""" output database to file """
	OutputFileName = "out.log"
	OutputFileControl = open(OutputFileName, 'w')

	for n in range(len(database)):
		data = database[n]
		data_write = '----------------- line '  + str(data.Line) + ' ------------------------ \n'
		OutputFileControl.write( data_write )
		data.ExportData(OutputFileControl)

#-------------------------------------------------------- PRIVATE FUNCTION --------------------------------------------------------
def ParseOperand(str):
	""" Parse operand from string operand """
	str = str.replace('[', ',')
	str = str.replace(']', '')
	if 'e' in str: str = str.replace('-', ',')
	result = list()

	opr = str.split(',')
	for item in opr:
		if item:
			result.append(item)
	return result

def GetMPUentry(str, value):
	""" get value of MPLA, MPUA, MPAT from log file"""

	mpu_entry = set(['MPLA', 'MPUA', 'MPAT'])
	obj = str[:4]
	if obj in mpu_entry and obj in SR:
		if obj == 'MPLA' or obj == 'MPUA':
			value &= 0xFFFFFFFC
		entry = str[4:]
		if len(entry) != 0:
			entry = int(entry)
		else:
			entry = SR['MPIDX'] & 0x1F

		exec('%s[%d] = %d' % (obj, entry, value))
		return True

	return False

def GetDebugChannel(str, value):
	""" get value of BPCn from log file"""

	debug_channel = set(['BPAV', 'BPAM'])
	obj = str[:4]

	if 'BPC' in str[:3] and 'BPC' in SR:
		channel = str[3:]
		if len(channel) != 0:
			channel = int(channel)
		else:
			channel = GetValueBitRange(SR['DIR1'], 4, 7)	# DIR1.CSL
			if channel > 11: channel = 0

		BPC[channel] = value
		return True
	elif obj in debug_channel and obj in SR:
		channel = str[4:]
		if len(channel) != 0:
			channel = int(channel)
		else:
			channel = GetValueBitRange(SR['DIR1'], 4, 7)	# DIR1.CSL
			if channel > 11: channel = 0

		exec('%s[%d] = %d' % (obj, channel, value))
		return True

	return False

def ParsePSWflagbit(str, value):
	""" update PSW/GMPSW base on flag bit"""

	switch_mask = {
		'um': 0xBFFFFFF, 		# bit 30
		'eimask': 0xFC0FFFFF, 	# bit 20-25
		'np': 0xFFFFFF7F, 		# bit 7
		'ep': 0xFFFFFFBF, 		# bit 6
		'id': 0xFFFFFFDF,  		# bit 5
		'sat': 0xFFFFFFEF,  	# bit 4
		'cy': 0xFFFFFFF7, 		# bit 3
		'ov': 0xFFFFFFFB, 		# bit 2
		's': 0xFFFFFFFD, 		# bit 1
		'z': 0xFFFFFFFE 		# bit 0
		}

	mask = switch_mask.get(str, 0)
	if mask != 0:
		switch_value = {
			'um': (value << 30), 		# bit 30
			'eimask': (value << 20), 	# bit 20-25
			'np': (value << 7), 		# bit 7
			'ep': (value << 6), 		# bit 6
			'id': (value << 5),  		# bit 5
			'sat': (value << 4), 		# bit 4
			'cy': (value << 3), 		# bit 3
			'ov': (value << 2), 		# bit 2
			's': (value << 1), 			# bit 1
			'z': (value << 0) 			# bit 0
			}
		value = switch_value.get(str, 0)

		if GetValueBitRange(SR['PSWH'], 31, 31) == 0:	# PSWH.GM
			SR['PSW'] = (SR['PSW'] & mask) | value
		else:
			SR['GMPSW'] = (SR['GMPSW'] & mask) | value
		return True

	return False

def GetLLBIT(line, link_bit):
	""" Get LLBIT information """
	if 'Link' in line:
		if 'created' in line:
			link_bit = line.split()[4]
			link_bit = link_bit.rstrip(',')
			link_bit = int(link_bit, 16)
		elif 'deleted' in line:
			link_bit = 0

	return link_bit

def GetInterruptRequest(line, int_status):
	""" Function support check whether It has interrupt request at line or not """
	if "Before execution" in line:
		int_status = True

	return int_status

def GetExceptionAddr(line, exp_addr):
	""" Get address that cause exception/interrupt """
	if 'Error' in line:
		if 'Memory' in line:
			# Get MPU and MAE exception address
			exp_addr = line.split()[4]
			exp_addr = exp_addr.rstrip('>')
			exp_addr = int(exp_addr, 16)

		elif 'Alignment' in line:
			# Get Debug AE exception address
			exp_addr = line.split()[3]
			exp_addr = exp_addr.rstrip('>')
			exp_addr = int(exp_addr, 16)
	elif "Break: ch" in line and 'canceled' not in line:
		# Get Debug PCB and LSAB exception address
		exp_addr = line.split()[5]
		exp_addr = exp_addr.rstrip('>')
		exp_addr = int(exp_addr, 16)
	elif "Before execution" in line:
		# Get interrupt address
		exp_addr = line.split()[6]
		exp_addr = exp_addr.rstrip('>')
		exp_addr = int(exp_addr, 16)

	return exp_addr

def GetExpNameAndCauseCode(line, exp_name, cause_code):
	""" Get exception/interrupt name and cause code"""
	if 'Exception' in line:
		lines = line.split()
		exp_name = lines[2]

		cause_code = lines[7].rstrip('>')
		cause_code = int(cause_code, 16)

	return exp_name, cause_code

#-------------------------------------------------------- Debug Code --------------------------------------------------------
# inputFileName = sys.argv[1]
# database = CollectData(inputFileName)
# PrintData(database)