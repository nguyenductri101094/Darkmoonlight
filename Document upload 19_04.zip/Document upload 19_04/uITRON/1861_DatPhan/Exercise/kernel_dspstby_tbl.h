/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_dspstby_tbl.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_DSPSTBY_TBL_H
#define _HIOS_KERNEL_DSPSTBY_TBL_H

/****************************************************************************/
/*          DSPSTBY_INITBL (ROM/hidef)                                      */
/****************************************************************************/
#pragma pack 4

typedef struct dspstby_initbl {
        UW     stbcr_adr;               /* STBCR address                    */
#ifdef _SH4ALDSP
        UW     stbcr_setbits;           /* STBCR set data                   */
        UW     stbcr_clrbits;           /* STBCR clear data                 */
#else
        UB     stbcr_setbits;           /* STBCR set data                   */
        UB     stbcr_clrbits;           /* STBCR clear data                 */
        UH     stbcr_rsv;               /* (Rsv)                            */
#endif
} DSPSTBY_INITBL;

#pragma unpack
#endif
