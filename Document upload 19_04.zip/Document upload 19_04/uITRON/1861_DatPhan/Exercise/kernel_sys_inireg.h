/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_sys_inireg.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_SYS_INIREG_H
#define _HIOS_KERNEL_SYS_INIREG_H

/*-------------------- Indicator for INI??? table --------------------------*/
#define INDI_INI		0x26494e49		/* Indicator "&INI"					*/
#define INDI_END		0x26454e49		/* Indicator "&ENI"					*/

/*------------------ Initial registration macro indicator ------------------*/
#define INDI_CRE_TSK	(-3)			/* _INI_CRE_TSK indicator			*/
#define INDI_CRE_SEM	(-9)			/* _INI_CRE_SEM indicator			*/
#define INDI_CRE_FLG	(-11)			/* _INI_CRE_FLG indicator			*/
#define INDI_CRE_MBX	(-13)			/* _INI_CRE_MBX indicator			*/
#define INDI_CRE_MBF	(-15)			/* _INI_CRE_MBF indicator			*/
#define INDI_CRE_MPL	(-17)			/* _INI_CRE_MPL indicator			*/
#define INDI_CRE_MPF	(-19)			/* _INI_CRE_MPF indicator			*/
#define INDI_CRE_CYC	(-21)			/* _INI_CRE_CYC indicator			*/
#define INDI_CRE_ALM	(-23)			/* _INI_CRE_ALM indicator			*/
#define INDI_DEF_SVC	(-25)			/* _INI_DEF_SVC indicator			*/
#define INDI_VSCR_TSK	(-29)			/* _INI_VSCR_TSK indicator			*/
#define INDI_DEF_TEX	(-31)			/* _INI_DEF_TEX indicator			*/
#define INDI_CRE_DTQ	(-33)			/* _INI_CRE_DTQ indicator			*/
#define INDI_CRE_MTX	(-35)			/* _INI_CRE_MTX indicator			*/
#define INDI_DEF_OVR	(-37)			/* _INI_DEF_OVR indicator			*/
#define INDI_DEF_INH	(-39)			/* _INI_DEF_INH indicator			*/
#define INDI_DEF_EXC	(-41)			/* _INI_DEF_EXC indicator			*/
#define INDI_VDEF_TRP	(-43)			/* _INI_VDEF_TRP indicator			*/

#pragma pack 4
/****************************************************************************/
/*			INITSK (ROM/hisetup,hibuild) (CRE_TSK,VSCR_TSK)					*/
/****************************************************************************/
typedef struct	initsk	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CTSK	in_t_ctsk;				/* T_CTSK packet					*/
} INITSK;

/****************************************************************************/
/*			INISEM (ROM/hisetup,hibuild) (CRE_SEM)							*/
/****************************************************************************/
typedef struct	inisem	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CSEM	in_t_csem;				/* T_CSEM packet					*/
} INISEM;

/****************************************************************************/
/*			INIFLG (ROM/hisetup,hibuild) (CRE_FLG)							*/
/****************************************************************************/
typedef struct	iniflg	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CFLG	in_t_cflg;				/* T_CFLG packet					*/
} INIFLG;

/****************************************************************************/
/*			INIMBX (ROM/hisetup,hibuild) (CRE_MBX)							*/
/****************************************************************************/
typedef struct	inimbx	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CMBX	in_t_cmbx;				/* T_CMBX packet					*/
} INIMBX;

/****************************************************************************/
/*			INIMBF (ROM/hisetup,hibuild) (CRE_MBF)							*/
/****************************************************************************/
typedef struct	inimbf	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CMBF	in_t_cmbf;				/* T_CMBF packet					*/
} INIMBF;

/****************************************************************************/
/*			INIMPL (ROM/hisetup,hibuild) (CRE_MPL)							*/
/****************************************************************************/
#if ((VTCFG_NEWMPL) == 0)
typedef struct	inimpl	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CMPL	in_t_cmpl;				/* T_CMPL packet					*/
		VP		in_rsv1;				/* reserved							*/
		UINT	in_rsv2;				/* reserved							*/
		UINT	in_rsv3;				/* reserved							*/
} INIMPL;
#else
typedef struct    inimpl    {
		UH		in_indicator; 			/* Indicator 						*/
		ID		in_id;					/* ID								*/
		T_CMPL	in_t_cmpl;				/* T_CMPL packet					*/
} INIMPL;
#endif

/****************************************************************************/
/*			INIMPF (ROM/hisetup,hibuild) (CRE_MPF)							*/
/****************************************************************************/
#if ((VTCFG_MPFMANAGE) == 0)
typedef struct	inimpf	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CMPF	in_t_cmpf;				/* T_CMPF packet					*/
        VP      in_rsv;                 /* reserved                         */
} INIMPF;
#else
typedef struct  inimpf  {
        UH      in_indicator;           /* Indicator                        */
        ID      in_id;                  /* ID                               */
        T_CMPF  in_t_cmpf;              /* T_CMPF packet                    */
} INIMPF;
#endif

/****************************************************************************/
/*			INICYC (ROM/hisetup,hibuild) (CRE_CYC)							*/
/****************************************************************************/
typedef struct	inicyc	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CCYC	in_t_ccyc;				/* T_CCYC packet					*/
} INICYC;

/****************************************************************************/
/*			INIALM (ROM/hisetup,hibuild) (CRE_ALM)							*/
/****************************************************************************/
typedef struct	inialm	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CALM	in_t_calm;				/* T_CALM packet					*/
} INIALM;

/****************************************************************************/
/*			INISVC (ROM/hisetup,hibuild) (DEF_SVC)							*/
/****************************************************************************/
typedef struct	inisvc	{
		UH		in_indicator;			/* Indicator						*/
		H		in_cd;					/* Function code					*/
		T_DSVC	in_t_dsvc;				/* T_DSVC packet					*/
} INISVC;

/****************************************************************************/
/*			INITEX (ROM/hisetup,hibuild) (DEF_TEX)							*/
/****************************************************************************/
typedef struct	initex	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_DTEX	in_t_dtex;				/* T_DTEX packet					*/
} INITEX;

/****************************************************************************/
/*			INIDTQ (ROM/hisetup,hibuild) (CRE_DTQ)							*/
/****************************************************************************/
typedef struct	inidtq	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CDTQ	in_t_cdtq;				/* T_CDTQ packet					*/
} INIDTQ;

/****************************************************************************/
/*			INIMTX (ROM/hisetup,hibuild) (CRE_MTX)							*/
/****************************************************************************/
typedef struct	inimtx	{
		UH		in_indicator;			/* Indicator						*/
		ID		in_id;					/* ID								*/
		T_CMTX	in_t_cmtx;				/* T_CMTX packet					*/
} INIMTX;

/****************************************************************************/
/*			INIOVR (ROM/hisetup,hibuild) (CRE_MTX)							*/
/****************************************************************************/
typedef struct	iniovr	{
		UH		in_indicator;			/* Indicator						*/
		H		in_rsv;					/* reserved							*/
		T_DOVR	in_t_dovr;				/* T_DOVR packet					*/
} INIOVR;

/****************************************************************************/
/*			INIHDR (ROM/hisetup,hibuild) (ATT_INI)							*/
/****************************************************************************/
typedef struct	inihdr	{
		VP_INT	in_exinf;				/* extended information				*/
		FP		in_inirtn;				/* initialization routine address	*/
} INIHDR;
/****************************************************************************/
/*			INIINH															*/
/****************************************************************************/
typedef struct	iniinh	{
		UH		in_indicator;			/* Indicator						*/
		INHNO	in_inhno;				/* NO								*/
		T_DINH	in_t_dinh;				/* T_DINH packet					*/
} INIINH;
/****************************************************************************/
/*			INIEXC															*/
/****************************************************************************/
typedef struct	iniexc	{
		UH		in_indicator;			/* Indicator						*/
		EXCNO	in_excno;				/* NO								*/
		T_DEXC	in_t_dexc;				/* T_DEXC packet					*/
} INIEXC;
/****************************************************************************/
/*			INITRP															*/
/****************************************************************************/
typedef struct	initrp	{
		UH		in_indicator;			/* Indicator						*/
		TRPNO	in_trpno;				/* NO								*/
		T_DTRP	in_t_dtrp;				/* T_DTRP packet					*/
} INITRP;
/*** Cache pre-fetch information ********************/
typedef	 struct t_pref{		   /* Prefetch information table				*/
	   VP	   *pf_addr;	   /* Prefetch address							*/
	   UW		pf_size;		/* Prefetch size							 */
}T_PREF;
/*** Initialize routine definition ********************/
typedef	 struct t_inirtn{	   /* Initialize routine information table		*/
	   VP_INT  exccd;		   /* exccd										*/
	   FP	   inirtn;		   /* Initialize routine address				*/
}T_INIRTN;

#pragma unpack
/****************************************************************************/
/*			Macro for initial registration									*/
/****************************************************************************/
#define _INI_CRE_TSK(id,tskatr,exinf,task,itskpri,stksz,stk) \
		static const INITSK initsk##id = { \
			  (UH)INDI_CRE_TSK, \
			  (ID)id, \
				   { (ATR)tskatr, \
					 (VP_INT)exinf, \
					 (FP)task, \
					 (PRI)itskpri, \
					 (SIZE)stksz, \
					 (VP)stk } , \
			  };

#define _INI_VSCR_TSK(id,tskatr,exinf,task,itskpri) \
		static const INITSK initsk##id = { \
			  (UH)INDI_VSCR_TSK, \
			  (ID)id, \
				   { (ATR)tskatr, \
					 (VP_INT)exinf, \
					 (FP)task, \
					 (PRI)itskpri, \
					 (SIZE)NULL, \
					 (VP)NULL } , \
			  };

#define _INI_CRE_SEM(id,sematr,isemcnt,maxsem) \
		static const INISEM inisem##id = { \
			  (UH)INDI_CRE_SEM, \
			  (ID)id, \
				   { (ATR)sematr, \
					 (UINT)isemcnt, \
					 (UINT)maxsem } , \
			  };

#define _INI_CRE_FLG(id,flgatr,iflgptn) \
		static const INIFLG iniflg##id = { \
			  (UH)INDI_CRE_FLG, \
			  (ID)id, \
				   { (ATR)flgatr, \
					 (FLGPTN)iflgptn } , \
			  };

#define _INI_CRE_DTQ(id,dtqatr,dtqcnt,dtq) \
		static const INIDTQ inidtq##id = { \
			  (UH)INDI_CRE_DTQ, \
			  (ID)id, \
				   { (ATR)dtqatr, \
					 (UINT)dtqcnt, \
					 (VP)dtq } , \
			  };

#define _INI_CRE_MBX(id,mbxatr,maxmpri,mprihd) \
		static const INIMBX inimbx##id = { \
			  (UH)INDI_CRE_MBX, \
			  (ID)id, \
				   { (ATR)mbxatr, \
					 (PRI)maxmpri, \
					 (VP)mprihd } , \
			  };

#define _INI_CRE_MTX(id,mtxatr,ceilpri) \
		static const INIMTX inimtx##id = { \
			  (UH)INDI_CRE_MTX, \
			  (ID)id, \
				   { (ATR)mtxatr, \
					 (PRI)ceilpri } , \
			  };

#define _INI_CRE_MBF(id,mbfatr,maxmsz,mbfsz,mbf) \
		static const INIMBF inimbf##id = { \
			  (UH)INDI_CRE_MBF, \
			  (ID)id, \
				   { (ATR)mbfatr, \
					 (UINT)maxmsz, \
					 (SIZE)mbfsz, \
					 (VP)mbf } , \
			  };

#if ((VTCFG_NEWMPL) == 0)
#define _INI_CRE_MPL(id,mplatr,mplsz,mpl) \
		static const INIMPL inimpl##id = { \
			  (UH)INDI_CRE_MPL, \
			  (ID)id, \
				   { (ATR)mplatr, \
					 (SIZE)mplsz, \
					 (VP)mpl } , \
			  (VP)NULL, \
			  (UINT)0U, \
			  (UINT)0U, \
			  };
#else
// Not specified VTA_UNFRAGMENT attribute
#define _INI_CRE_MPL(id,mplatr,mplsz,mpl) \
		static const INIMPL inimpl##id = { \
			  (UH)INDI_CRE_MPL, \
			  (ID)id, \
				   { (ATR)mplatr, \
					 (SIZE)mplsz, \
					 (VP)mpl, \
					 (VP)NULL, \
					 (UINT)0U, \
					 (UINT)0U } , \
			  };
// Specified VTA_UNFRAGMENT attribute
#define _INI_CRE_MPL2(id,mplatr,mplsz,mpl,minblksz,sctnum) \
		UW _kernel_inimplmb##id[VTSZ_MPLMB(sctnum)/sizeof(UW)]; \
		static const INIMPL inimpl##id = { \
			  (UH)INDI_CRE_MPL, \
			  (ID)id, \
				   { (ATR)mplatr, \
					 (SIZE)mplsz, \
					 (VP)mpl , \
					 (VP) _kernel_inimplmb##id , \
					 (UINT)minblksz, \
					 (UINT)sctnum } , \
			  };
#endif

#if ((VTCFG_MPFMANAGE) == 0)
#define _INI_CRE_MPF(id,mpfatr,blkcnt,blfsz,mpf) \
		static const INIMPF inimpf##id = { \
			  (UH)INDI_CRE_MPF, \
			  (ID)id, \
				   { (ATR)mpfatr, \
					 (UINT)blkcnt, \
					 (UINT)blfsz, \
					 (VP)mpf } , \
              (VP)NADR , \
			  };
#else
#define _INI_CRE_MPF(id,mpfatr,blkcnt,blfsz,mpf) \
		UW _kernel_inimpfmb##id[VTSZ_MPFMB(blkcnt, blfsz)/sizeof(UW)]; \
		static const INIMPF inimpf##id = { \
			  (UH)INDI_CRE_MPF, \
			  (ID)id, \
				   { (ATR)mpfatr, \
					 (UINT)blkcnt, \
					 (UINT)blfsz, \
					 (VP)mpf, \
					 (VP)_kernel_inimpfmb##id } , \
			  };
#endif

#define _INI_CRE_CYC(id,cycatr,exinf,cychdr,cyctim,cycphs) \
		static const INICYC inicyc##id = { \
			  (UH)INDI_CRE_CYC, \
			  (ID)id, \
				   { (ATR)cycatr, \
					 (VP_INT)exinf, \
					 (FP)cychdr, \
					 (RELTIM)cyctim, \
					 (RELTIM)cycphs } , \
			  };

#define _INI_CRE_ALM(id,almatr,exinf,almhdr) \
		static const INIALM inialm##id = { \
			  (UH)INDI_CRE_ALM, \
			  (ID)id, \
				   { (ATR)almatr, \
					 (VP_INT)exinf, \
					 (FP)almhdr } , \
			  };

#define _INI_DEF_SVC(fncd,svcatr,svcrtn) \
		static const INISVC inisvc##fncd = { \
			  (UH)INDI_DEF_SVC, \
			  (H)fncd, \
				   { (ATR)svcatr, \
					 (FP)svcrtn } , \
			  };

#define _INI_DEF_TEX(id,texatr,texrtn) \
		static const INITEX initex##id = { \
			  (UH)INDI_DEF_TEX, \
			  (ID)id, \
				   { (ATR)texatr, \
					 (FP)texrtn } , \
			  };

#define _INI_DEF_OVR(ovratr,ovrhdr) \
		static const INIOVR iniovr = { \
			  (UH)INDI_DEF_OVR, \
			  (H)NULL, \
				   { (ATR)ovratr, \
					 (FP)ovrhdr } , \
			  };

#define _INI_DEF_INH(inhno, inhatr, inthdr, inhsr) \
		static const INIINH iniinh##inhno = { \
			(UH)INDI_DEF_INH, \
			(INHNO)inhno, \
				{	(ATR)inhatr, \
					(FP)inthdr, \
					(UINT)inhsr } , \
			};

#define _INI_DEF_EXC(excno, excatr, exchdr, excsr) \
		static const INIEXC iniexc##excno = { \
			(UH)INDI_DEF_EXC, \
			(EXCNO)excno, \
				{	(ATR)excatr, \
					(FP)exchdr, \
					(UINT)excsr } , \
			};

#define _INI_VDEF_TRP(trpno, trpatr, trphdr, trpsr) \
		static const INITRP initrp##trpno = { \
			(UH)INDI_VDEF_TRP, \
			(TRPNO)trpno, \
				{	(ATR)trpatr, \
					(FP)trphdr, \
					(UINT)trpsr } , \
			};

#define _INI_ATT_INI(exinf, inirtn) \
		(VP_INT)exinf, \
		(FP)inirtn,

#define _INI_PRE_FETCH(adr, size) \
					 (VP)adr, \
					 (UW)size,

#endif
