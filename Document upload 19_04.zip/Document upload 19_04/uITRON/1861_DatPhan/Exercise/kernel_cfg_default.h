/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_cfg_default.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_CFG_DEFAULT_H
#define _HIOS_KERNEL_CFG_DEFAULT_H

/****************************************************************************/
/*	Define hi_???? which are not defined by kernel_cfg_main.h				*/
/****************************************************************************/
#ifndef	hi_knlmsklvl
	#define	hi_knlmsklvl	15
#endif
#ifndef	hi_trcbufsz
	#define	hi_trcbufsz	0x10000
#endif
#ifndef	hi_irqstksz
	#define	hi_irqstksz	(0x400*16)
#endif
#ifndef	hi_tmrhdrstksz
	#define	hi_tmrhdrstksz	0x1000
#endif
#ifndef	hi_sysinistksz
	#define	hi_sysinistksz	0x1000
#endif
#ifndef	hi_uppintnst
	#define	hi_uppintnst	16
#endif
#ifndef	hi_lowintnst
	#define	hi_lowintnst	15
#endif

#ifndef	hi_maxtskid
	#define	hi_maxtskid	1023
#endif
#ifndef	hi_tskstksz
	#define	hi_tskstksz	((hi_maxtskid+1)*0x400)
#endif
#ifndef	hi_ststkid
	#define	hi_ststkid	0
#endif

#ifndef	hi_maxdtqid
	#define	hi_maxdtqid	1023
#endif
#ifndef	hi_maxsemid
	#define	hi_maxsemid	1023
#endif
#ifndef	hi_maxflgid
	#define	hi_maxflgid	1023
#endif
#ifndef	hi_maxmbxid
	#define	hi_maxmbxid	1023
#endif
#ifndef	hi_maxmtxid
	#define	hi_maxmtxid	1023
#endif
#ifndef	hi_maxmbfid
	#define	hi_maxmbfid	1023
#endif
#ifndef	hi_maxmpfid
	#define	hi_maxmpfid	1023
#endif
#ifndef	hi_maxmplid
	#define	hi_maxmplid	1023
#endif
#ifndef	hi_maxcycid
	#define	hi_maxcycid	15
#endif
#ifndef	hi_maxalmid
	#define	hi_maxalmid	15
#endif
#ifndef	hi_maxsvccd
	#define	hi_maxsvccd	1023
#endif
#ifndef	hi_dtqsz
	#define	hi_dtqsz	((hi_maxdtqid+1)*64)
#endif
#ifndef	hi_mbfsz
	#define	hi_mbfsz	((hi_maxmbfid+1)*256)
#endif
#ifndef	hi_mpfsz
	#define	hi_mpfsz	((hi_maxmpfid+1)*1024)
#endif
#ifndef	hi_mplsz
	#define	hi_mplsz	((hi_maxmplid+1)*4096)
#endif

/****************************************************************************/
/*	Other definition														*/
/****************************************************************************/
#define hi_maxtskpri TMAX_TPRI
#define hi_maxexccd hi_maxvctno
#define hi_addstksz	 0			 /* Additional kernel stack size			*/

#endif
