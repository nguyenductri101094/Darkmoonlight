﻿#include "CDcuBlock.h"

CDcuBlock::CDcuBlock() {

}

CDcuBlock::CDcuBlock(std::string name) {

}

CDcuBlock::~CDcuBlock() {

}

void CDcuBlock::AppendJtag(IJtag* pJtag) {

}

bool CDcuBlock::InsertJtag(IJtag* pJtag, UI32 pos) {

}

UI32 CDcuBlock::GetJagNum() {

}

std::string CDcuBlock::GetBlockName() {

}

UI32 CDcuBlock::GetIndex(IJtag* pJtag) {

}

IJtag* CDcuBlock::at(UI32 Pos) {

}

void CDcuBlock::ReplaceJTAG(IJtag* before, IJtag* after) {

}

bool CDcuBlock::RemoveJTAG(IJtag* pJtag) {

}

bool CDcuBlock::EraseJTAG(IJtag* pJtag) {

}

void CDcuBlock::Dump() {

}

void CDcuBlock::GenerateHandshakeSequence() {

}

