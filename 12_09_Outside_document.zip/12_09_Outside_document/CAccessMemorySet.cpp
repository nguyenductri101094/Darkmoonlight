﻿#include "CAccessMemorySet.h"

CAccessMemorySet::CAccessMemorySet(): m_accessWeight(&g_rnd) {

}

CAccessMemorySet::~CAccessMemorySet() {

}

bool CAccessMemorySet::SetWeight(std::string access_type, std::string weight_value) {

}

std::unique_ptr<IJtag> CAccessMemorySet::CreateAccessCommand() {

}

std::unique_ptr<IJtag> CAccessMemorySet::CreateAccessCommand(UI32 access_id) {

}

