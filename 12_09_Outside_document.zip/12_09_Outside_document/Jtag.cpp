﻿#include        "Jtag.h"


/*===============================================
@brief: Clock(TCK) Output Control
@ID: 0
@name: set_tck
===============================================*/
const IJtag::JTAG_ID     JtagSetTck::m_id(JTAG_ID_SET_TCK);
const std::string        JtagSetTck::m_name("set_tck");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagSetTck::GetJtagCommand() {

}


/*===============================================
@brief: Clock(TCK) Period Control
@ID: 1
@name: set_tck_cycle
===============================================*/
const IJtag::JTAG_ID     JtagSetTckCycle::m_id(JTAG_ID_SET_TCK_CYCLE);
const std::string        JtagSetTckCycle::m_name("set_tck_cycle");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagSetTckCycle::GetJtagCommand() {

}


/*===============================================
@brief: Clock(TCK) Delay Control
@ID: 2
@name: set_tck_delay
===============================================*/
const IJtag::JTAG_ID     JtagSetTckDelay::m_id(JTAG_ID_SET_TCK_DELAY);
const std::string        JtagSetTckDelay::m_name("set_tck_delay");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagSetTckDelay::GetJtagCommand() {

}


/*===============================================
@brief: Reset(TRSTZ) Pulse Output
@ID: 3
@name: startup
===============================================*/
const IJtag::JTAG_ID     JtagStartup::m_id(JTAG_ID_STARTUP);
const std::string        JtagStartup::m_name("startup");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagStartup::GetJtagCommand() {

}


/*===============================================
@brief: IDLE State Recovery
@ID: 4
@name: idle
===============================================*/
const IJtag::JTAG_ID     JtagIdle::m_id(JTAG_ID_IDLE);
const std::string        JtagIdle::m_name("idle");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagIdle::GetJtagCommand() {

}


/*===============================================
@brief: 32-bit Data Write
@ID: 5
@name: wr
===============================================*/
const IJtag::JTAG_ID     JtagWr::m_id(JTAG_ID_WR);
const std::string        JtagWr::m_name("wr");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagWr::GetJtagCommand() {

}


/*===============================================
@brief: 1-bit Data Write
@ID: 6
@name: wr1
===============================================*/
const IJtag::JTAG_ID     JtagWr1::m_id(JTAG_ID_WR1);
const std::string        JtagWr1::m_name("wr1");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagWr1::GetJtagCommand() {

}


/*===============================================
@brief: 1-bit Data Write with Authentication
@ID: 7
@name: wr1_key
===============================================*/
const IJtag::JTAG_ID     JtagWr1Key::m_id(JTAG_ID_WR1_KEY);
const std::string        JtagWr1Key::m_name("wr1_key");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagWr1Key::GetJtagCommand() {

}


/*===============================================
@brief: 32-bit Data Write and Check
@ID: 8
@name: wrc
===============================================*/
const IJtag::JTAG_ID     JtagWrc::m_id(JTAG_ID_WRC);
const std::string        JtagWrc::m_name("wrc");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagWrc::GetJtagCommand() {

}


/*===============================================
@brief: 32-bit Data Check
@ID: 9
@name: cmp
===============================================*/
const IJtag::JTAG_ID     JtagCmp::m_id(JTAG_ID_CMP);
const std::string        JtagCmp::m_name("cmp");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagCmp::GetJtagCommand() {

}


/*===============================================
@brief: 1-bit Data Check
@ID: 10
@name: cmp1
===============================================*/
const IJtag::JTAG_ID     JtagCmp1::m_id(JTAG_ID_CMP1);
const std::string        JtagCmp1::m_name("cmp1");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagCmp1::GetJtagCommand() {

}


/*===============================================
@brief: 32-bit Data Check with Polling
@ID: 11
@name: poll
===============================================*/
const IJtag::JTAG_ID     JtagPoll::m_id(JTAG_ID_POLL);
const std::string        JtagPoll::m_name("poll");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagPoll::GetJtagCommand() {

}


/*===============================================
@brief: 1-bit Data Check with Polling
@ID: 12
@name: bpoll
===============================================*/
const IJtag::JTAG_ID     JtagBpoll::m_id(JTAG_ID_BPOLL);
const std::string        JtagBpoll::m_name("bpoll");

/**
* @brief Get command of JTAG
* @return string JTAG command
*/
std::string JtagBpoll::GetJtagCommand ()
{
                
}

