﻿#ifndef CDCU_MANAGER_H
#define CDCU_MANAGER_H

#include        "CMemory.h"
#include        "CAccessMemorySet.h"
#include        "CDcuConfig.h"
#include        "CMauBlock.h"    


class CDcuManager {

public:
    CDcuManager();
    ~CDcuManager();
    bool InitDCU();
    std::unique_ptr<CDcuBlock> GenerateJtagCommand();
    void OutputJtagCommand();

public:
    CMemory              m_memory;
    CAccessMemorySet     m_accessMem;
    CDcuConfig           m_config;
};

#endif // !CDCU_MANAGER_H

