﻿#ifndef IJTAG_H
#define IJTAG_H

#include    "rtg_common.h"


/*===============================================
@brief: Abstract class of JTAG commands
===============================================*/
class IJtag {

public:

    typedef enum {
        JTAG_ID_SET_TCK,
        JTAG_ID_SET_TCK_CYCLE,
        JTAG_ID_SET_TCK_DELAY,
        JTAG_ID_STARTUP,
        JTAG_ID_IDLE,
        JTAG_ID_WR,
        JTAG_ID_WR1,
        JTAG_ID_WR1_KEY,
        JTAG_ID_WRC,
        JTAG_ID_CMP,
        JTAG_ID_CMP1,
        JTAG_ID_POLL,
        JTAG_ID_BPOLL,
        JTAG_ID_MAU_RD_B_TYPE_A,
        JTAG_ID_MAU_WR_B_TYPE_A,
        JTAG_ID_MAU_RD_H_TYPE_A,
        JTAG_ID_MAU_WR_H_TYPE_A,
        JTAG_ID_MAU_RD_W_TYPE_A,
        JTAG_ID_MAU_WR_W_TYPE_A,
        JTAG_ID_MAU_RD_DW_TYPE_A,
        JTAG_ID_MAU_WR_DW_TYPE_A,
        JTAG_ID_MAU_RD_B_TYPE_B,
        JTAG_ID_MAU_WR_B_TYPE_B,
        JTAG_ID_MAU_RD_H_TYPE_B,
        JTAG_ID_MAU_WR_H_TYPE_B,
        JTAG_ID_MAU_RD_W_TYPE_B,
        JTAG_ID_MAU_WR_W_TYPE_B,
        JTAG_ID_MAU_RD_DW_TYPE_B,
        JTAG_ID_MAU_WR_DW_TYPE_B,
        JTAG_ID_NUM
    } JTAG_ID;

    IJtag(bool rdy = false, UI8 map = 0, UI8 bank = 0, UI8 ir = 0, UI8 bit = 0, UI32 dr = 0, UI8 key = 0, UI32 c_dr = 0):
        m_rdy(rdy),
        m_map(map),
        m_bank(bank),
        m_ir(ir),
        m_bit(bit),
        m_dr(dr),
        m_key(key),
        m_c_dr(c_dr) {
    }

    ~IJtag() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    virtual JTAG_ID GetJtagId() = 0;

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    virtual std::string GetJtagName() = 0;

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    virtual std::string GetJtagCommand() = 0;

    /**
    * @brief append comment into last current comment
    */
    virtual void AppendComment(const std::string& comment);

    /**
    * @brief Get comment of JTAG
    * @return string comment of JTAG
    */
    virtual std::string GetComment();

    /**
    * @brief erase comment of JTAG
    */
    virtual void DeleteComment();

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    virtual bool RegulateJtagCommand();

protected:
    std::string          m_comment;     //! describe some attention about JTAG
    bool                 m_rdy;         //! 1(true): Do after falling edges of RDYZ; 0(false): Do immediately
    UI8                  m_map;         //! Map number(0-7) of IR register defined by DUT spec
    UI8                  m_bank;        //! Bank number(0-7) of IR register defined by DUT spec
    UI8                  m_ir;          //! Number(8-bit) of IR register define by DUT spec
    UI8                  m_bit;         //! Ascending digit position(0-31)
    UI32                 m_dr;          //! Write data
    UI8                  m_key;         //! Authentication code(4-bit)
    UI32                 m_c_dr;        //! Expected data(32-bit)

};


/*===============================================
@brief: Class to manage group JTAG commands to do certain purpose
===============================================*/
class ComplexJtag: public IJtag {

public:
    ComplexJtag(JTAG_ID id, std::string name):
        m_id(id),
        m_name(name),
        m_size(0),
        m_vJtagList()
       {}

    ComplexJtag(JTAG_ID id, std::string name, UI32 size):
                m_id(id),
                m_name(name),
                m_size(size),
                m_vJtagList()
                {}

    ~ComplexJtag() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get size of JTAG
    * @return size of JTAG command
    */
    UI32 GetSize() { return m_size; }

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand() { return std::string(""); }

    /**
    * @brief Add attribute and correct JTAG command
    * @return true if correct successfully
    */
    bool RegulateJtagCommand();

private:
    JTAG_ID                             m_id;               //! ID of JTAG
    std::string                         m_name;             //! name of JTAG
    UI32                                m_size;             //! size of memory area access in MAU     
    std::vector<std::unique_ptr<IJtag>> m_vJtagList;        //! manage list of JTAG support certain purpose

};

#endif // IJTAG_H
