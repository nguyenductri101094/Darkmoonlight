﻿#ifndef CDCU_BLOCK_H
#define CDCU_BLOCK_H

#include    "IJtag.h"

class CDcuBlock {

public:
    CDcuBlock();
    CDcuBlock(std::string name);
    ~CDcuBlock();
    void AppendJtag(IJtag* pJtag);
    bool InsertJtag(IJtag* pJtag, UI32 pos);
    UI32 GetJagNum();
    std::string GetBlockName();
    UI32 GetIndex(IJtag* pJtag);
    IJtag* at(UI32 Pos);
    void ReplaceJTAG(IJtag* before, IJtag* after);
    bool RemoveJTAG(IJtag* pJtag);
    bool EraseJTAG(IJtag* pJtag);
    void Dump();
    void GenerateHandshakeSequence();

protected:
    std::string m_name;
    std::vector<std::unique_ptr<IJtag>> m_vJtag;

};

#endif // !CDCU_BLOCK_H



