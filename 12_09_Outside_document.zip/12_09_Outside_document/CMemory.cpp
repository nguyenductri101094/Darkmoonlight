﻿#include "CMemory.h"

CMemory::CMemory(): m_ReadableMem(&g_rnd), m_WritableMem(&g_rnd) {

}

CMemory::~CMemory() {

}

bool CMemory::SetMem(MEMADDR startAddr, MEMADDR endAddr, std::string attribute, std::string resource, std::string ratio) {
    bool result;

    return result;
}

std::pair<MEMRANGE, std::string> CMemory::SelectMemRange(UI32 size, const char attribute) {

}

std::string CMemory::GetResource(MEMRANGE mr) {

}

UI32 CMemory::CountReadMem() {
    return m_ReadableMem.Count();
}

UI32 CMemory::CountWriteMem() {
    return m_WritableMem.Count();
}

void CMemory::DumpMemory() {

}

