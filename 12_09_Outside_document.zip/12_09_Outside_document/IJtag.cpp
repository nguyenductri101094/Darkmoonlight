﻿#include "IJtag.h"



/**
* @brief append comment into last current comment
*/
void IJtag::AppendComment(const std::string& comment) {
    m_comment += comment;
}

/**
* @brief Get comment of JTAG
* @return string comment of JTAG
*/
std::string IJtag::GetComment() {
    return m_comment;
}

/**
* @brief erase comment of JTAG
*/
void IJtag::DeleteComment() {
    m_comment = "";
}

/**
* @brief Add attribute and correct JTAG command
* @return true if correct successfully
*/
bool IJtag::RegulateJtagCommand() {}

//====================================================//

/**
* @brief Add attribute and correct JTAG command
* @return true if correct successfully
*/
bool ComplexJtag::RegulateJtagCommand() {

}