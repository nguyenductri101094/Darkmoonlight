﻿#ifndef CMEMORY_H
#define CMEMORY_H

#include    "rnd_gen.h"


class CMemory {

public:
    CMemory();
    ~CMemory();
    bool SetMem(MEMADDR startAddr, MEMADDR endAddr, std::string attribute, std::string resource, std::string ratio);
    std::pair<MEMRANGE, std::string> SelectMemRange(UI32 size, const char attribute);
    std::string GetResource(MEMRANGE mr);
    UI32 CountReadMem();
    UI32 CountWriteMem();
    void DumpMemory();

private:
    CWeightedRandom <MEMRANGE>       m_ReadableMem;
    CWeightedRandom <MEMRANGE>       m_WritableMem;
    std::map<MEMRANGE, UI32>         m_resource;

};


#endif // CMEMORY_H

