#ifndef			RANDGEN_H_
#define			RANDGEN_H_

#include	"rtg_common.h"
#include	"rtg_types.h"

#if (__STDC__==1) && (__cplusplus >= 201103L)
#define USE_CPP11_LIBRARY_
#include	<random>
#endif

/**
 * @brief  乱数生成源となるクラスのインターフェース
 */
class IRandom {
public:
    IRandom() {}; 
    virtual ~IRandom() {}; 
    virtual UI32 Get(void) = 0;
    virtual UI32 GetRange(UI32 min, UI32 max) = 0;
    virtual SI32 GetRange(SI32 min, SI32 max) = 0;
    virtual UI64 GetRange(UI64 min, UI64 max) = 0;
    virtual SI64 GetRange(SI64 min, SI64 max) = 0;
    virtual void Seed(void*) = 0;
};

/**
 * @brief  乱数生成源となるクラス定義時のアダプタクラス
 */
class CRandomAdaptor : public IRandom {
public:
	CRandomAdaptor(){}
	virtual ~CRandomAdaptor(){}
    UI32 operator()(long int M) {
    	return GetRange(0U, (UI32)M-1);
    }
protected:
    virtual UI32 Get(void) { _ASSERT(0); return 0U;};
    virtual UI32 GetRange(UI32 min, UI32 max) { _ASSERT(0); return 0U;};
    virtual SI32 GetRange(SI32 min, SI32 max) { _ASSERT(0); return 0;};
    virtual UI64 GetRange(UI64 min, UI64 max) { _ASSERT(0); return 0UL;};
    virtual SI64 GetRange(SI64 min, SI64 max) { _ASSERT(0); return 0L;};
    virtual void Seed(void*){ _ASSERT(0); return;};
};


#ifdef USE_CPP11_LIBRARY_
/**
 * @brief  システムにより乱数を生成するクラス。動作は遅くシードに対する再現性がない。。
 *	       よってSeedを指定した一意なパタンを生成したい場合はそのまま利用できない。
 *	       ユーザーがシードを指定しない場合のシード取得に使える。
 */
class CUniformedRandom : public CRandomAdaptor {
public:
    CUniformedRandom(){}
    virtual ~CUniformedRandom() {}
    virtual UI32 Get(void) ;
    virtual UI32 GetRange(UI32 min, UI32 max) ;
}; 

/**
 * @brief  メルセンヌ・ツイスタにより一様乱数を発生させるクラス。
 *	       比較的高速に生成出来る。
 */
class CMersenneTwister : public CRandomAdaptor {
public:
	CMersenneTwister(): m_mt(){}
	CMersenneTwister(UI32 s) : m_mt() { m_mt.seed(s); }
	virtual ~CMersenneTwister(){}
	virtual void Seed(void* vp) {
		std::random_device rdev;
		uint32_t seed32n = (vp) ? *(reinterpret_cast<uint32_t*>(vp)) : rdev();
		m_mt.seed(seed32n);
	}
    UI32 operator()(long int M) {
    	return GetRange(0U, (UI32)M-1);
    } 
	virtual UI32 Get(void) override {
		return (UI32)m_mt();
	}
	virtual UI32 GetRange(UI32 min, UI32 max) override {
		return (min < max) ? std::uniform_int_distribution<UI32>(min, max)(m_mt) : min;
	}
	virtual SI32 GetRange(SI32 min, SI32 max) override {
		return (min < max) ? std::uniform_int_distribution<SI32>(min, max)(m_mt) : min;
	}
	virtual UI64 GetRange(UI64 min, UI64 max) override {
		return (min < max) ? std::uniform_int_distribution<UI64>(min, max)(m_mt) : min;
	}
	virtual SI64 GetRange(SI64 min, SI64 max) override {
		return (min < max) ? std::uniform_int_distribution<SI64>(min, max)(m_mt) : min;
	}
private:
	std::mt19937 m_mt;
	
};

#else

/**
 * @brief  システムにより乱数を生成するクラス。動作は遅くシードに対する再現性がない。。
 *	       よってSeedを指定した一意なパタンを生成したい場合はそのまま利用できない。
 *	       ユーザーがシードを指定しない場合のシード取得に使える。
 */
class CUniformedRandom : public CRandomAdaptor {
public:
    CUniformedRandom() : m_rndsrc("/dev/urandom"){}
    virtual ~CUniformedRandom() {}
    virtual UI32 Get(void); 
    virtual UI32 GetRange(UI32 min, UI32 max);
protected:
	LPCTSTR	m_rndsrc;
}; 


/**
 * @brief  メルセンヌ・ツイスタにより一様乱数を発生させるクラス。
 *	       比較的高速に生成出来る。
 */
class CMersenneTwister : public IRandom {

public:
	CMersenneTwister(): m_iN(624), m_iM(397), m_ulMATRIX_A(0x9908b0dfUL), 
		m_ulUPPER_MASK(0x80000000UL), m_ulLOWER_MASK(0x7fffffffUL)
	{
		m_veculMT.resize(m_iN);
		m_iMTI = m_iN + 1;
	}
	
	void Seed(void* seed) {
		m_veculMT[0] = (*(UI32*)seed) & 0xffffffffUL;
		for (m_iMTI = 1; m_iMTI < m_iN; m_iMTI++) {
			m_veculMT[m_iMTI] = (1812433253UL * (m_veculMT[m_iMTI - 1] ^ (m_veculMT[m_iMTI - 1] >> 30)) + m_iMTI); 
			m_veculMT[m_iMTI] &= 0xffffffffUL;
		}
	}
 
	/**
	 *	@brief	範囲を指定した中で32ビットの一様乱数を生成する。
	 *	@param	min		範囲の下限
	 *	@param	max		範囲の上限
	 *	@return	32ビットの一様乱数
	 */
	UI32 GetRange(UI32 min, UI32 max) {
		
		if ((max + 1ULL - min)==0) {
			_ASSERT(printf("ZERO DIV max=%d, min=%d\n", max,min)); 
		}
		return (min >= max) ? min : ((this->Get() % (max + 1ULL - min)) + min);
	}
	
	/**
	 *	@brief	範囲を指定した中で32ビットの一様乱数を生成する。
	 *	@param	min		範囲の下限
	 *	@param	max		範囲の上限
	 *	@return	32ビットの一様乱数
	 */
	SI32 GetRange(SI32 min, SI32 max) {
		if ((max + 1LL - min)==0) {
			printf("ZERO DIV max=%d, min=%d\n", max,min);
			_ASSERT(max + 1LL - min); 
		}
		return (min >= max) ? min : ((this->Get() % (max + 1LL - min)) + min);
	}
	
	/**
	 *	@brief	範囲を指定した中で64ビットの一様乱数を生成する。
	 *	@param	min		範囲の下限
	 *	@param	max		範囲の上限
	 *	@return	64ビットの一様乱数
	 */
	UI64 GetRange(UI64 min, UI64 max) {
		
		// full range
		if (min == 0 && max == ~0ULL) {
			return ((((UI64)Get()) << 32) | Get());
		}
		
		if ((UI64)(max + 1ULL - min)==0) {
			printf("ZERO DIV max=%lld, min=%lld\n", max,min); 
			_ASSERT(max + 1ULL - min);
		}
		UI64 r = (((UI64)Get()) << 32) | Get();
		return (min >= max) ? min : ((r % (max + 1ULL - min)) + min);
	}
	
	/**
	 *	@brief	範囲を指定した中で64ビットの一様乱数を生成する。
	 *	@param	min		範囲の下限
	 *	@param	max		範囲の上限
	 *	@return	64ビットの一様乱数
	 */
	SI64 GetRange(SI64 min, SI64 max) {
		
		if ((max + 1LL - min)==0) {
			printf("ZERO DIV max=%lld, min=%lld\n", max,min); 
			_ASSERT(max + 1LL - min);
		}
		UI64 r = ((((UI64)Get()) << 32) | Get());
		return (min >= max) ? min : ((r % (max + 1LL - min)) + min);
	}
    
	/**
	 *	@brief	32ビットの一様乱数を生成する。
	 *	@return	32ビットの一様乱数
	 */
	UI32 Get() {
		UI32 aulMag01[2] = { 0x0UL, (UI32)m_ulMATRIX_A };
		if (m_iMTI >= m_iN) {
			int iKK = 0;
			for (; iKK < m_iN - m_iM; iKK++) {
				UI32 ulY = (m_veculMT[iKK] & m_ulUPPER_MASK) | (m_veculMT[iKK + 1] & m_ulLOWER_MASK);
				m_veculMT[iKK] = m_veculMT[iKK + m_iM] ^ (ulY >> 1) ^ aulMag01[ulY & 0x1UL];
			}
			for (; iKK < m_iN - 1; iKK++) {
				UI32 ulY = (m_veculMT[iKK] & m_ulUPPER_MASK) | (m_veculMT[iKK + 1] & m_ulLOWER_MASK);
				m_veculMT[iKK] = m_veculMT[iKK + (m_iM - m_iN)] ^ (ulY >> 1) ^ aulMag01[ulY & 0x1UL];
			}
			UI32 ulY = (m_veculMT[m_iN - 1] & m_ulUPPER_MASK) | (m_veculMT[0] & m_ulLOWER_MASK);
			m_veculMT[m_iN - 1] = m_veculMT[m_iM - 1] ^ (ulY >> 1) ^ aulMag01[ulY & 0x1UL];
			m_iMTI = 0;
		}
		UI32 ulY = m_veculMT[m_iMTI++];
		// Tempering
		ulY ^= (ulY >> 11);
		ulY ^= (ulY <<  7) & 0x9d2c5680UL;
		ulY ^= (ulY << 15) & 0xefc60000UL;
		ulY ^= (ulY >> 18);
		return ulY;
	}

private:
	const SI32			m_iN;
	const SI32			m_iM;
	const SI32			m_ulMATRIX_A;
	const UI32			m_ulUPPER_MASK;
	const UI32			m_ulLOWER_MASK;
	std::vector<UI32>	m_veculMT;
	SI32				m_iMTI;
};
#endif

/**
 *  @brief  指定された一様乱数源から重みに従ってランダムに要素を選択するテンプレートクラス。
 *          現状は要素の重み変更によるパフォーマンスが良くない。また再計算を指示する必要がある。
 */
template <typename CLASS_T>
class CWeightedRandom : public CRandomAdaptor {
public:
	/**
	 *	@brief   このオブジェクトを生成します。
	 *	@param  pr 重み付き乱数の生成に使用する発生源
	 */
	CWeightedRandom(IRandom* pr) : m_MapObj(), m_WHash(), m_pRand(pr), m_bValid(true), m_MapLnk(), m_ErrorMem() {}
	
	/**
	 *	@brief  このオブジェクトを破棄します。
	 *          登録されたオブジェクトや乱数発生源の解放は利用者が責任を持ちます。
	 *          このデストラクタでは何も行いません。
	 */
	virtual ~CWeightedRandom(){}
	
	/**
	 *	@brief  重みを再計算します。要素を削除したタイミングで再計算が必要です。
	 */
	void ReCalc(void) {
		
		if (m_bValid) {
			return;
		}
		m_WHash.clear();
		
		typename std::map <CLASS_T,std::pair<UI32,UI32>>::iterator  itr;
		UI32	totalWeight = 0;
		
		for (itr = m_MapObj.begin(); itr != m_MapObj.end(); ++itr) {
			totalWeight += itr->second.first;
			m_WHash.insert(std::pair<UI32, CLASS_T>(totalWeight, itr->first));
		}
		
		m_bValid = true;
		return;
	}
	
	/**
	 *	@brief  使用する乱数発生源を設定します。
	 *	@param  rgen 使用する乱数発生源
	 */
	void SetRandom(IRandom*	rgen) {
		m_pRand = rgen;
		return;
	}
	
	/**
	 *	@brief  要素と重みを設定します。
	 *	@param  id  登録する要素。
	 *	@param  wv  要素の重み。重みに０が指定された場合は無視します。
	 * 	@return 真の場合は削除後の再挿入のため再計算が必要。
	 */
	bool Set(CLASS_T id, UI32 wv) {
		UI32 tailWeight = 0;
		if (wv == 0) {
			return false;
		}
		if (!m_WHash.empty()) {
			/* 積み重ねられた最後の重み取得 */
			typename std::map<UI32, CLASS_T>::reverse_iterator  ritr;
			ritr = m_WHash.rbegin();
			tailWeight = ritr->first;
		}

		/* 挿入した結果で重複を確認する - Register KEY(CLASS_T), Value(Weight,WeigtTotal) */
		std::pair<typename std::map <CLASS_T, std::pair<UI32,UI32> >::iterator, bool> 
		pib = m_MapObj.insert(typename std::pair<CLASS_T, std::pair<UI32,UI32> > (id, std::pair<UI32,UI32>(wv,wv + tailWeight)));
		
		/* 重複で失敗した場合、削除して再登録 - Register KEY(WeigtTotal), Value(CLASS_T) */
		if (pib.second) {
			/* 成功時のみ重みテーブルへ反映する */
			m_WHash.insert(typename std::pair<UI32, CLASS_T>((wv + tailWeight), id));
		} else{
			/* TODO:CLASS_Tがポインタの場合LEAK(delete pib.first) */
			m_MapObj.erase(pib.first);
			m_MapObj.insert(typename std::pair<CLASS_T, std::pair<UI32,UI32> > (id, std::pair<UI32,UI32>(wv,wv + tailWeight)));
			/* Skip calculation of WeightTable */
			m_bValid = false;
		}
		
		return (!m_bValid); /* 再挿入時、真を返す */
	}

	/**
	 *	@brief  要素と重みを設定します。
	 *	@param  id   登録する要素。
	 *	@param  lnk  リンクビットの有無
	 *	@param  wv   要素の重み。重みに０が指定された場合は無視します。
	 * 	@return 真の場合は削除後の再挿入のため再計算が必要。
	 */
	bool Set(CLASS_T id, UI32 lnk, UI32 wv, bool isErrorMem) {
		UI32 tailWeight = 0;
		if (wv == 0) {
			return false;
		}
		if (!m_WHash.empty()) {
			/* 積み重ねられた最後の重み取得 */
			typename std::map<UI32, CLASS_T>::reverse_iterator  ritr;
			ritr = m_WHash.rbegin();
			tailWeight = ritr->first;
		}
        /*要素に対するリンクを設定(おそらく重複は無いハズ...)*/
        m_MapLnk.insert(typename std::pair<CLASS_T, UI32>(id,lnk)) ;

		m_ErrorMem.insert(typename std::pair<CLASS_T, UI32>(id, isErrorMem)) ;
		/* 挿入した結果で重複を確認する - Register KEY(CLASS_T), Value(Weight,WeigtTotal) */
		std::pair<typename std::map <CLASS_T, std::pair<UI32,UI32> >::iterator, bool> 
		pib = m_MapObj.insert(typename std::pair<CLASS_T, std::pair<UI32,UI32> > (id, std::pair<UI32,UI32>(wv,wv + tailWeight)));
		
		/* 重複で失敗した場合、削除して再登録 - Register KEY(WeigtTotal), Value(CLASS_T) */
		if (pib.second) {
			/* 成功時のみ重みテーブルへ反映する */
			m_WHash.insert(typename std::pair<UI32, CLASS_T>((wv + tailWeight), id));
		} else{
			/* TODO:CLASS_Tがポインタの場合LEAK(delete pib.first) */
			m_MapObj.erase(pib.first);
			m_MapObj.insert(typename std::pair<CLASS_T, std::pair<UI32,UI32> > (id, std::pair<UI32,UI32>(wv,wv + tailWeight)));
			/* Skip calculation of WeightTable */
			m_bValid = false;
		}
		
		return (!m_bValid); /* 再挿入時、真を返す */
	}

	/**
	 *	@brief  要素を削除します。処理コストが大きいため自動で再計算はされません。。
	 *          必要なだけDeleteをして最後に１度だけ再計算してください。
	 *	@param  id  削除する要素。
	 *  @return 実際に削除した場合に真を返す（この場合再計算が必要）。
	 */
	bool Delete(CLASS_T id) {
		/* std::map.erase内部でfindされるため、ここでfindしなくてよい */
		if (m_MapObj.erase(id)) {
			m_bValid = false;
		}
		return !m_bValid;
	}

	/**
	 *	@brief  登録されいている要素の数を取得します。
	 *	@return 登録された要素数。
	 */
	size_t Count(void) const {
		_ASSERT (m_bValid);
		return m_MapObj.size();
	}
	
	/**
	 *	@brief  重みに従ってランダムな要素を返します。
	 *	@return 選択された要素。
	 */	
	CLASS_T GetObj(void) throw (std::runtime_error) {
		_ASSERT (m_bValid);
		UI32	last	= 0;
		UI32	urnd	= 0;
		
		if (m_WHash.empty()) {
			throw std::runtime_error ("Weight-random container has no element.");
		}
		
		typename std::map<UI32, CLASS_T>::reverse_iterator  ritr;
		ritr = m_WHash.rbegin();
		last = ritr->first;
		urnd = m_pRand->GetRange((UI32)1, (UI32)last);
		
		typename std::map <UI32, CLASS_T>::iterator ilb;
		ilb = m_WHash.lower_bound (urnd);
		
		return ilb->second;
	}

	/**
	 * @brief  内部テーブルの整合状態を取得します。
	 * @return 不整合が発生している場合、偽を返します。
	 */	
	operator bool() {
		return m_bValid;
	}

	/**
	 *	@brief  登録テーブルのステータスを取得します。
	 */	
	void Clear() {
		m_MapObj.clear();
		m_WHash.clear();
		m_MapLnk.clear();
		m_ErrorMem.clear();
		m_bValid = true;
	}

	/**
	 *	@brief  登録されているキーのセットを返します。
	 *	@return キーセット
	 */	
	std::set<CLASS_T> KeySet(void) {
		typename std::set<CLASS_T> kset;
		typename std::map<CLASS_T, std::pair<UI32,UI32> >::iterator  itr;
		for (itr = m_MapObj.begin(); itr != m_MapObj.end(); itr++) {
			kset.insert(itr->first);
		}
//		std::for_each (m_MapObj.begin(), m_MapObj.end(), 
//			[&kset] (typename std::pair<CLASS_T, std::pair<UI32,UI32>>& elm){
//				kset.insert(elm.first);
//			}
//		);
		return kset;
	}

	/**
	 * @brief	指定されたキーと対で登録されいている重み値を取得します。。
	 * @param	code キーコード
	 * @return	重み値
	 */
	virtual UI32 GetWeight(CLASS_T code) {
		if (!m_bValid) {
			ReCalc() ;
		}
		typename std::map<CLASS_T, std::pair<UI32, UI32> >::iterator itr;
		if ((itr= m_MapObj.find(code)) == m_MapObj.end()) {
			return 0;
		}
		return (itr->second.first) ;
	}

    UI32 GetLnk( CLASS_T m ) {
		UI32 lnk = 1 ;
		typename std::map<CLASS_T, UI32>::iterator itr ;
		
		// そもそもweightファイルにlnkが設定されていない場合は
		// lnk=1(既存)の動作とする
		if( m_MapLnk.empty() ){
			//MSG_WARN(0, "Un define \"lnk\" in weight file.\n");
			return lnk ;
		}
		
		if ((itr= m_MapLnk.find(m)) == m_MapLnk.end()) {
			MSG_WARN(0, "itr->2 : 0x%08x\n", itr->second);	  
			//MSG_WARN(0, "Un define \"lnk\" in weight file.\n");
			return lnk;
		}
		return (itr->second) ;
    }

	bool GetMemError( CLASS_T m ) {
		
		typename std::map<CLASS_T, UI32>::iterator itr ;
		
		if( m_ErrorMem.empty() ){
			//MSG_WARN(0, "Un define \"memError\" in weight file.\n");
			return false ;
		}
		
		if ((itr= m_ErrorMem.find(m)) == m_ErrorMem.end()) {
			MSG_WARN(0, "itr->2 : 0x%08x\n", itr->second);	  
			//MSG_WARN(0, "Un define \"memError\" in weight file.\n");
			return false;
		}
		return (itr->second) == true ;
    }


#if !defined(NDEBUG) 
	/**
	 *	@brief  重みを表示します。デバッグ用。
	 *  @param  os  出力先
	 */
	void Dump(std::ostream& os) {
		typename std::map<CLASS_T, std::pair<UI32,UI32> >::iterator  itr;	
		os << std::setw(10) << std::left << std::setfill(' ') << "Key" << std::setw(10) << "Val" << std::setw(10) << "Total" << std::endl;
		os << std::setw(10) << std::left << std::setfill(' ') << "---------" << std::setw(10) << "---------"  << std::setw(10) << "---------"  << std::endl;
		for (itr = m_MapObj.begin(); itr != m_MapObj.end(); itr++) {
			os << std::setw(10) << std::left << std::setfill(' ') << itr->first;
			os << std::setw(10) << std::left << std::setfill(' ') << itr->second.first;
			os << std::setw(10) << std::left << std::setfill(' ') << itr->second.second;
			os << std::endl; 
		}
		os << std::endl;
		
		typename std::map<UI32,CLASS_T>::iterator  itr2;
		os << std::setw(10) << std::left << std::setfill(' ') << "Total" << std::setw(10) << "Key" << std::endl;
		os << std::setw(10) << std::left << std::setfill(' ') << "---------" << std::setw(10) << "---------" << std::endl;
		for (itr2 = m_WHash.begin(); itr2 != m_WHash.end(); itr2++) {
			os << std::setw(10) << std::left << std::setfill(' ') << itr2->first;
			os << std::setw(10) << std::left << std::setfill(' ') << itr2->second;
			os << std::endl; 
		}		
		return;
	}
#endif

protected:
	typename
	std::map<CLASS_T, 
	std::pair<UI32, UI32> >		m_MapObj;	//!<　@brief 要素に対して(要素の重み,積重値)を設定
	typename
	std::map<UI32, CLASS_T>		m_WHash;	//!<　@brief 積重値に対して要素を設定
	IRandom*					m_pRand;	//!<　@brief 一様乱数の発生源
	bool						m_bValid;	//!<　@brief 内部テーブルの整合状態を示す（偽の場合再計算が必要）
    typename
	std::map<CLASS_T, UI32 >	m_MapLnk;	//!<　@brief 要素に対してリンク設定値を設定
	std::map<CLASS_T, UI32 >	m_ErrorMem;
};

// As global vars
extern CMersenneTwister	g_rnd;	//!<　@brief このアプリケーション全体で使用する乱数発生源

#endif	// RANDGEN_H_
