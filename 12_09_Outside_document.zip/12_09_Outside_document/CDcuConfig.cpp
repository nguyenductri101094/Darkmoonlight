﻿#include "CDcuConfig.h"

CDcuConfig::CDcuConfig() {

}

CDcuConfig::~CDcuConfig() {

}

/**
* @brief  Get number of Jtag in a block
*/
UI32 CDcuConfig::GetJtagNum() {
    return m_nJtagNum;
}

/**
* @brief  Get number of Jtag Block
*/
UI32 CDcuConfig::GetBlockJtagNum() {
    return m_nBlockJtagNum;
}

/**
* @brief  Parse input file DCU configuration
*/
bool CDcuConfig::ParseDcuConfig(const std::string& filepath) {
    std::ifstream	ifs(filepath);
    const std::string 	separator(",");
    SectionData			secdata;
    if (ifs.fail()) {
        if (filepath.length() == 0) {
            return true;
        }
        else {
            MSG_ERROR(0, "profile [%s] not found.\n", filepath.c_str());
        }
        return false;
    }

    // Csv splitter
    while (ifs.eof() != true) {
        std::string  line;
        getline(ifs, line);
        CsvRow&& row = Split(line, std::string("//"));
        if (row.empty()) {
            continue;
        }
        line = row[0];
        row.clear();
        if ((row = Split(line, std::string(","))).size() > 0) {
            secdata.push_back(row);
        }
    }

    // Section distribute
    SectionData::iterator itr;
    SectionData part = { {"NOTHING"} };
    SectionName name = "NOTHING";

    for (itr = secdata.begin(); itr != secdata.end(); ++itr) {
        std::cout << "itr: " << (*itr).at(0) << "\tSize: " << (*itr).size() << std::endl;
        if (IsSectionKey((*itr)[0]) == true) {
            if ((*itr).size() == 1) {
                name = (*itr)[0];
                part.clear();
                //m_mConfigData.insert(Section(name, part));
                /*if ((m_mConfigData.insert(Section(name, part)).second) != true) {
                    SectionData vpre = m_mConfigData[name];
                    vpre.insert(vpre.end(), part.begin(), part.end());
                    m_mConfigData.erase(name);
                    m_mConfigData.insert(Section(name, vpre));
                }*/
            } else {
                //Do nothing
            }
        } else {
            //m_mConfigData[name] = (*itr);
            part.push_back(*itr);
        }
    }

    //if (part.empty() == false) {
    //    if ((m_mConfigData.insert(Section(name, part)).second) != true) {
    //        std::cout << "Name4: " << name << std::endl;
    //        SectionData vpre = m_mConfigData[name];
    //        vpre.insert(vpre.end(), part.begin(), part.end());
    //        m_mConfigData.erase(name);
    //        m_mConfigData.insert(Section(name, vpre));
    //    }
    //}

    return true;
}

/**
* @brief  Seprate string by specific character
*/
CsvRow CDcuConfig::Split(std::string& src, const std::string& key) {
    CsvRow v;
    std::string::size_type index = 0;
    while (index < src.length()) {
        std::string::size_type oldindex = index;
        index = src.find(key, index);
        if (index != std::string::npos) {
            std::string item = src.substr(oldindex, index - oldindex);
            v.push_back(Trim(item));
        }
        else {
            std::string item = src.substr(oldindex);
            v.push_back(Trim(item));
            break;
        }
        index += key.length();
    }
    return v;
}

/**
* @brief  Remove redundant character ("space") out of string 
*/
std::string CDcuConfig::Trim(const std::string & str) {

    std::string::const_iterator head = str.begin();
    std::string::const_iterator tail = str.end();
    if (str.length() < 1) {
        return std::string("");
    }

    while (isspace(*head)) {
        head++;
    }
    if (head != tail) {
        do {
            tail--;
        } while (isspace(*tail));
        tail++;
    }
    return std::string(head, tail);
}

/**
* @brief  Check if string is section key (contain "::")
*/
bool CDcuConfig::IsSectionKey(const std::string& str) {
    return str.compare(0, 2, "::", 2) == 0;
}

/**
* @brief  Method to access data in each section
*/
SectionData& CDcuConfig::GetSectionData(const std::string& section) {
    return m_mConfigData[section];
}

/**
* @brief  Print out all data for debugging
*/
void CDcuConfig::DumpConfigData() {
    SectionMap::iterator s;
    for (s = m_mConfigData.begin(); s != m_mConfigData.end(); ++s) {
        if (s->first.length() == 0) {
            std::cout << "[no name]" << std::endl;
        } else {
            std::cout << s->first << std::endl;
        }
        SectionData::iterator d;
        for (d = s->second.begin(); d != s->second.end(); ++d) {
            CsvRow::iterator c = d->begin();
            if (c != d->end()) {
                std::cout << *c;
                c++;
            }
            for (; c != d->end(); c++) {
                std::cout << ", " << *c;
            }
            std::cout << std::endl;
        }
    }
}

