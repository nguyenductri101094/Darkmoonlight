﻿#include "CDcuManager.h"

CDcuManager::CDcuManager() {

}

CDcuManager::~CDcuManager() {

}

bool CDcuManager::InitDCU() {
    bool result = true;

    return result;
}

std::unique_ptr<CDcuBlock> CDcuManager::GenerateJtagCommand() {

}

void CDcuManager::OutputJtagCommand() {

}

