﻿#ifndef CMAU_BLOCK_H
#define CMAU_BLOCK_H

#include        "CDcuBlock.h"


class CMauBlock: public CDcuBlock {

public:
    CMauBlock();
    CMauBlock(std::string name);
    ~CMauBlock();
    void GenerateHandshakeSequence();
    void GenerateSelfCheckCode();

private:
    bool m_MBIN;
    bool m_MBOUT;

};

#endif // !CMAU_BLOCK_H


