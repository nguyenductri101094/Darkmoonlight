﻿#ifndef CDCU_CONFIG_H
#define CDCU_CONFIG_H

#include        "rtg_common.h"
#include        "rtg_types.h"


class CDcuConfig {

public:

    /**
    * @brief Construct this object
    */
    CDcuConfig();

    /**
    * @brief  Destroy this object
    */
    ~CDcuConfig();

    /**
    * @brief  Get number of Jtag in a block
    * @param  None
    * @return Return number of Jtag in a block
    */
    UI32 GetJtagNum();

    /**
    * @brief  Get number of Jtag Block
    * @param  None
    * @return Return number of Jtag block
    */
    UI32 GetBlockJtagNum();

    /**
    * @brief  Parse input file DCU configuration
    * @param  filepath Path of input file DCU configuration
    * @return Return TRUE if data is processed successfully, otherwise return FALSE
    */
    bool ParseDcuConfig(const std::string& filepath);

    /**
    * @brief  Seprate string by specific character
    * @param  str Target string
    * @param  key Specific character
    * @return Return vector string which is seprated
    */
    CsvRow	Split(std::string& src, const std::string& key);

    /**
    * @brief  Remove redundant character ("space") out of string
    * @param  str Target string
    * @return Return string without "space" character
    */
    static std::string Trim(const std::string& str);

    /**
    * @brief  Check if string is section key (contain "::") 
    * @param  str Target string
    * @return Return TRUE if string is section key, otherwise return FALSE
    */
    bool	IsSectionKey(const std::string& str);

    /**
    * @brief  Method to access data in each section
    * @param  section Name of section that need to get
    * @return Return vector contain data of that section
    */
    SectionData& GetSectionData(const std::string& section);

    /**
    * @brief  Print out all data for debugging
    * @param  os 
    * @return Return data of configuration
    */
    void DumpConfigData();

private:
    UI32          m_nJtagNum;    //<! @brief Number of Jtag in a block
    UI32          m_nBlockJtagNum;   //<! @brief Number of block Jtag

protected:
    SectionMap    m_mConfigData;  //<! @brief Map that contain data of all sections
};

#endif // !CDCU_CONFIG_H





