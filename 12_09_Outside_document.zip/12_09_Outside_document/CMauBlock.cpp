﻿#include "CMauBlock.h"


CMauBlock::CMauBlock() {

}

CMauBlock::CMauBlock(std::string name) {

}

CMauBlock::~CMauBlock() {

}

void CMauBlock::GenerateHandshakeSequence() {

}

void CMauBlock::GenerateSelfCheckCode() {

}

