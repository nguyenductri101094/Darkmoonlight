﻿#ifndef CACCESS_MEMORY_SET_H
#define CACCESS_MEMORY_SET_H

#include        "rnd_gen.h"
#include        "IJtag.h"
#include        "Jtag.h"

class CAccessMemorySet {

public:
    CAccessMemorySet();
    ~CAccessMemorySet();
    bool SetWeight(std::string access_type, std::string weight_value);
    std::unique_ptr<IJtag> CreateAccessCommand();
    std::unique_ptr<IJtag> CreateAccessCommand(UI32 access_id);

private:
    CWeightedRandom<UI32>    m_accessWeight;
    std::string              access_weight[IJtag::JTAG_ID_NUM];

};

#endif // CACCESS_MEMORY_SET_H


