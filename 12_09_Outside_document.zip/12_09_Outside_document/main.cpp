#include        "CDcuManager.h"

int main(int argc, char** argv) {
    std::cout << "MAIN FUNCTION" << std::endl;

    std::shared_ptr<CDcuConfig> g_cfg = std::make_shared<CDcuConfig>();

    if (g_cfg->ParseDcuConfig("./dcu_config.profile") != true) {
        std::cout << "\nParse not success\n" << std::endl;
    }
    else {
        std::cout << "\nParse success\n" << std::endl;
    }

    g_cfg->DumpConfigData();

    return 1;
}