﻿#ifndef JTAG_H
#define JTAG_H

#include        "IJtag.h"



/*===============================================
@brief: Clock(TCK) Output Control
@ID: 0
@name: set_tck
===============================================*/
class JtagSetTck: public IJtag {

public:
    JtagSetTck(): m_tck_stp(false) {}

    JtagSetTck(bool tck_stp_value): m_tck_stp(tck_stp_value) {}

    ~JtagSetTck() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
    bool                        m_tck_stp;      //! 1(true): High level of TCK; 0(false): Oscillation

};


/*===============================================
@brief: Clock(TCK) Period Control
@ID: 1
@name: set_tck_cycle
===============================================*/
class JtagSetTckCycle: public IJtag {

public:
    JtagSetTckCycle(): m_cycle(0) {}

    JtagSetTckCycle(UI32 cycle_value): m_cycle(cycle_value) {}

    ~JtagSetTckCycle() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
    UI32                        m_cycle;        //! TCK period(32 - bit)

};


/*===============================================
@brief: Clock(TCK) Delay Control
@ID: 2
@name: set_tck_delay
===============================================*/
class JtagSetTckDelay: public IJtag {

public:
    JtagSetTckDelay(): m_delay(0) {}

    JtagSetTckDelay(UI32 delay_value): m_delay(delay_value) {}

    ~JtagSetTckDelay() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
    UI32                        m_delay;        //! TCK delay(32-bit)

};


/*===============================================
@brief: Reset(TRSTZ) Pulse Output
@ID: 3
@name: startup
===============================================*/
class JtagStartup: public IJtag {

public:
    JtagStartup() {}

    ~JtagStartup() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
};


/*===============================================
@brief: IDLE State Recovery
@ID: 4
@name: idle
===============================================*/
class JtagIdle: public IJtag {

public:
    JtagIdle() {}

    ~JtagIdle() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG
};


/*===============================================
@brief: 32-bit Data Write
@ID: 5
@name: wr
===============================================*/
class JtagWr: public IJtag {

public:
    JtagWr() {}

    JtagWr(bool rdy, UI8 map, UI8 bank, UI8 ir, UI32 dr):
        IJtag(rdy, map, bank, ir, 0, dr) {}

    ~JtagWr() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Write
@ID: 6
@name: wr1
===============================================*/
class JtagWr1: public IJtag {

public:
    JtagWr1() {}

    JtagWr1(bool rdy, UI8 map, UI8 bank, UI8 ir, UI8 bit, UI32 dr):
        IJtag(rdy, map, bank, ir, bit, dr) {}

    ~JtagWr1() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Write with Authentication
@ID: 7
@name: wr1_key
===============================================*/
class JtagWr1Key: public IJtag {

public:
    JtagWr1Key() {}

    JtagWr1Key(bool rdy, UI8 map, UI8 bank, UI8 ir, UI8 bit, UI32 dr, UI8 key):
        IJtag(rdy, map, bank, ir, bit, dr, key) {}

    ~JtagWr1Key() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 32-bit Data Write and Check
@ID: 8
@name: wrc
===============================================*/
class JtagWrc: public IJtag {

public:
    JtagWrc() {}

    JtagWrc(bool rdy, UI8 map, UI8 bank, UI8 ir, UI32 dr, UI32 c_dr):
        IJtag(rdy, map, bank, ir, 0, dr, 0, c_dr) {
    }

    ~JtagWrc() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 32-bit Data Check
@ID: 9
@name: cmp
===============================================*/
class JtagCmp: public IJtag {

public:
    JtagCmp() {}

    JtagCmp(bool rdy, UI8 map, UI8 bank, UI8 ir, UI32 c_dr):
        IJtag(rdy, map, bank, ir, 0, 0, 0, c_dr) {}

    ~JtagCmp() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Check
@ID: 10
@name: cmp1
===============================================*/
class JtagCmp1: public IJtag {

public:
    JtagCmp1() {}

    JtagCmp1(bool rdy, UI8 map, UI8 bank, UI8 ir, UI8 bit, UI32 c_dr):
        IJtag(rdy, map, bank, ir, bit, 0, 0, c_dr) {}

    ~JtagCmp1() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 32-bit Data Check with Polling
@ID: 11
@name: poll
===============================================*/
class JtagPoll: public IJtag {

public:
    JtagPoll() {}

    JtagPoll(bool rdy, UI8 map, UI8 bank, UI8 ir, UI32 c_dr):
        IJtag(rdy, map, bank, ir, 0, 0, 0, c_dr) {}

    ~JtagPoll() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


/*===============================================
@brief: 1-bit Data Check with Polling
@ID: 12
@name: bpoll
===============================================*/
class JtagBpoll: public IJtag {

public:
    JtagBpoll() {}

    JtagBpoll(bool rdy, UI8 map, UI8 bank, UI8 ir, UI8 bit, UI32 c_dr):
        IJtag(rdy, map, bank, ir, bit, 0, 0, c_dr) {}

    ~JtagBpoll() {}

    /**
    * @brief  Get ID of JTAG
    * @return ID of JTAG
    */
    JTAG_ID GetJtagId() { return m_id; };

    /**
    * @brief Get name of JTAG
    * @return string name of JTAG
    */
    std::string GetJtagName() { return m_name; };

    /**
    * @brief Get command of JTAG
    * @return string JTAG command
    */
    std::string GetJtagCommand();

private:
    static const JTAG_ID        m_id;           //! ID of JTAG
    static const std::string    m_name;         //! name of JTAG

};


#endif // !JTAG_H


