# -------------------------------- HOW TO USE -------------------------------------
# 		python Coverage_Debug.py <Cforest file>
# ---------------------------------------------------------------------------------

import database;
import sys;
import csv;
import re;
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import datetime # support time stamp
import copy
from collections import OrderedDict
import random

# ----------------------------- Private definition -------------------


# ----------------------------- Assisant Function ---------------------
def Type_of_Handler_Address(data):
	psw = data.SR["PSW"] if database.GetMode != database.Mode.GM else data.SR["GMPSW"]
	PSW_EBV = database.GetValueBitRange(psw, 15, 15)
	if PSW_EBV == 0:
		return '_R'
	else:
		return '_E'

def Type_of_Syserr(data, name):
	if data.Exp[0] == "SYSERR":
		return (name + "_slave")
	elif data.Exp[0] == "SYSERR_REEXEC":
		return ("SYSERR" + Type_of_Handler_Address(data) + "_rb")
	elif data.Exp[0] == "SYSERR_RB":
		return ("SYSERR" + Type_of_Handler_Address(data) + "_save")
	else:
		print "ERROR: Type of SysErr isn't detected: ", data.Exp[0]
		return "SYSERR_ERROR"

def Type_of_EI_int(data, name):
	if data.Behavior == 0: ##Direct vector
		return name
	else:
		if data.Exp[0] == "EIINT":
			name = "EITBL" + Type_of_Handler_Address(data)
		else:
			name = "GMEITBL" + Type_of_Handler_Address(data)
		return name

def CheckingExpIntCoverage(data, prev_data):
	global str_coprocessor

	if len(data.Exp) != 0:
		##Check mode
		name = data.Exp[0]
		name += Type_of_Handler_Address(data)

		if data.Exp[0] == "UCPOP0" or data.Exp[0] == "UCPOP1":
			name += str_coprocessor
		elif "SYSERR" in data.Exp[0]:
			name = Type_of_Syserr(data, name)
		elif data.Exp[0] == "EIINT" or data.Exp[0] == "GMEIINT":
			name = Type_of_EI_int(data, name)

		if name in ExpInt_Mode_class.map.keys():
			ExpInt_Mode_class.Update_result(name, database.GetModeAndPrivilege(prev_data.SR))

		##Check vector/channel
		if data.Exp[0] in dict_Exp_Name_vct.keys():
			ExpInt_VctChannel_class.Update_result(data.Exp[0], database.GetMode(prev_data.SR), int(data.Opr[0], 16))

# Dict to store mode execution status
ModeDict = OrderedDict([("CV", OrderedDict()), ("VS", OrderedDict())])

#Object verify
class VectorValue:
	def __init__(self, dict_Exp_vct):
		self.map = OrderedDict()
		for key_exp, value_exp in dict_Exp_vct.items():
			self.map[key_exp] = OrderedDict(ModeDict)
			dict_min_mid_max = OrderedDict()
			for pos in ["_min", "_mid", "_max"]:
				key_min_mid_max = "vct/channel_" + str(value_exp[0]) + "_" + str(value_exp[1]) + pos
				dict_min_mid_max[key_min_mid_max] = 0

			for key_mode in self.map[key_exp].keys():
				self.map[key_exp][key_mode] = OrderedDict(dict_min_mid_max)

	def Update_result(self, name, mode, val):
		if name not in self.map.keys():
			return

		if mode == database.Mode.CV:
			str_mode = "CV"
		elif mode == database.Mode.HM or mode == database.Mode.GM:
			str_mode = "VS"
		else:
			return

		for key in self.map[name][str_mode].keys():
			raw_field = key.split("_")
			min_val = int(raw_field[1], 16)
			max_val = int(raw_field[2], 16)
			key_pos_val = raw_field[0] + "_" + raw_field[1] + "_" + raw_field[2]
			break

		if min_val < val < max_val:
			key_pos_val += "_mid"
		elif val == min_val:
			key_pos_val += "_min"
		elif val == max_val:
			key_pos_val += "_max"
		else:
			print "ERROR: Value out of range - min_val = ", min_val, " - max_val = ", max_val, " - val = ", val

		self.map[name][str_mode][key_pos_val] = 1

	def ExportCSV(self, file_name, action):
		output_file = open(file_name, action)
		writer = csv.writer(output_file)
		writer.writerow(["INS", "CV_min", "CV_mid", "CV_max", "VS_min", "VS_mid", "VS_max"])
		for key_exp, value_exp in self.map.items():
			list_result = [key_exp]
			for key_mode, value_mode in value_exp.items():
				for key_pos, value_pos in value_mode.items():
					list_result.append(value_pos) 			
			writer.writerow(list_result)
		output_file.close()

#-------------------------------------------------------------------
# ----------------------------- MAIN Function ----------------------
#-------------------------------------------------------------------
start_time = datetime.datetime.now()
print "Start Checking Coverage ExpInt: ", start_time
cforest_log = sys.argv[1:]
database.GR = {}
database.WR = {}
database.SR = { 'HVCFG' : 0, 'PSWH' : 0, 'PSW' : 0, 'GMPSW' : 0,
				'DIR0' : 0}
				
#-------------Control mode of script--------------
Enable_test_ExpInt_Mode = True

Enable_debug_log = True
#-------------End control mode of script--------------

if Enable_test_ExpInt_Mode == True:
	ExpInt_name = 	["UCPOP0_R_+FPU", "UCPOP0_E_+FPU", "UCPOP0_R_-FPU", "UCPOP0_E_-FPU", "UCPOP1_R_+FPU", "UCPOP1_E_+FPU", "UCPOP1_R_-FPU", "UCPOP1_E_-FPU", "UCPOP2_R", "UCPOP2_E",
					"RIE_R", "RIE_E", "PIE_R", "PIE_E", "FPE_R", "FPE_E", "FXE_R", "FXE_E", "FETRAP_R", "FETRAP_E", "SYSCALL_R", "SYSCALL_E", "TRAP0_R", "TRAP0_E", "TRAP1_R", "TRAP1_E",
					"SYSERR_R_slave", "SYSERR_E_slave", "SYSERR_R_rb", "SYSERR_E_rb", "SYSERR_R_save", "SYSERR_E_save",
					"LSAB_R", "LSAB_E", "PCB_R", "PCB_E", "AE_R", "AE_E", "DBINT_R", "DBINT_E", "DBNMI_R", "DBNMI_E", "DBTRAP_R", "DBTRAP_E", "MAE_R", "MAE_E", "FENMI_R", "FENMI_E",
					"FEINT_R", "FEINT_E", "EIINT_R", "EIINT_E", "EITBL_R", "EITBL_E", "GMFEINT_R", "GMFEINT_E", "GMEIINT_R", "GMEIINT_E", "GMEITBL_R", "GMEITBL_E", "BGFEINT_R", "BGFEINT_E", "BGEIINT_R", "BGEIINT_E"]

	ExpInt_Mode_class = database.InssExeInMode(ExpInt_name)
	##In case: config is implemented coprocessor
	str_coprocessor = "_+FPU"
	##In case: config isn't implemented coprocessor
	#str_coprocessor = "_-FPU"
	ExpInt_Mode_result_file = "ExpInt_Mode_result_file.csv"
	ExpInt_VctChannel_result_file = "ExpInt_VctChannel_result_file.csv"
	dict_Exp_Name_vct = OrderedDict([	("FETRAP", 	[0x0,  	0xF ]),
										("SYSCALL", [0x0,  	0xFF]),
										("TRAP0",	[0x0,  	0xF ]),
										("TRAP1",	[0x10, 	0x1F])])

	ExpInt_VctChannel_class = VectorValue(dict_Exp_Name_vct)


AccumulationFile = 'Data_Accumulation_ExpInt.bk'
#Load back data from backup file(if exists) before executing script
if os.path.isfile(AccumulationFile):
	with open(AccumulationFile, 'rb') as file_bk:
		if Enable_test_ExpInt_Mode == True:
			ExpInt_Mode_class = pickle.load(file_bk)
	
for log in cforest_log:
	start_time_log = datetime.datetime.now()
	print "File: ", log, " Start Time: ", start_time_log
	raw_data = database.CollectData(log)
	#Get start and end of random code
	start_line = database.GetIndexStartRandomCode(raw_data)
	end_line = database.GetIndexEndRandomCode(raw_data)
	
	database.PrintData(raw_data)		
	for line in range (start_line, end_line):
		CheckingExpIntCoverage(raw_data[line], raw_data[line - 1])
	
	del raw_data
	end_time_log = datetime.datetime.now()
	print "Time Lapse: ", (end_time_log - start_time_log)
	

"""
-------------------------------------------------------------------------
----------------------- Handle result file ------------------------------
-------------------------------------------------------------------------
"""
# Export data to CSV file
if Enable_test_ExpInt_Mode == True:
	ExpInt_Mode_class.ExportCSV(ExpInt_Mode_result_file, 'wb')
	ExpInt_VctChannel_class.ExportCSV(ExpInt_VctChannel_result_file, 'wb')

#Backup data to a new file between script-executions
with open(AccumulationFile, 'wb') as file_bk:
	if Enable_test_ExpInt_Mode == True:
		pickle.dump(ExpInt_Mode_class, file_bk)

print "End Time: ", datetime.datetime.now()
print "Total Time Consume: ", (datetime.datetime.now() - start_time)