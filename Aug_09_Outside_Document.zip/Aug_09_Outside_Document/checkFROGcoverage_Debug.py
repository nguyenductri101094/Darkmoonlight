# -------------------------------- HOW TO USE -------------------------------------
# 		python checkFROGcoverage_Debug.py <Cforest file>
# ---------------------------------------------------------------------------------

import database;
import sys;
import re;
import pickle # support backup data structures like variables/struct/class to a file
import os.path # support check file existance
import datetime # support time stamp
import copy
import collections
from collections import OrderedDict
import random

# ----------------------------- Private definition -------------------
class BreakType:
	PCB = 1
	LSAB = 2
	AE = 3
	NONE = 4

# ----------------------------- Assisant Function ---------------------
def Detect_checkpoint(list, n):
	if (list[n] == "Fail"):
		list[n] = "Pass"

def Print_result(file, list, n):
	m = str(n).zfill(4)
	if list[n] == "Fail":
		file.write("-------->Case No.%s: Re-check\n" % m)
	elif list[n] == "Pass":
		file.write("-------->Case No.%s: Done\n" % m)

def Print_debug_log(file_control, data, dict_fixed, list_toggle, checkpoint_name):
	name_list = list()
	for key in dict_fixed.keys():
		name_list.append(key)
	
	for name in list_toggle:
		name_list.append(name)
	
	file_control.write("%s \n" % checkpoint_name)
	database.PrintBitCombination(file_control, data, name_list, 15)
	file_control.write("\n\n")

def HandleResult_BreakEnableDisable_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)	
	
	for key, value in dict_result.items():
		if (value == 1):
			index = int(key[pos("DIR1.BEN")] + key[pos("BPC.BE")], 2)
			BPC_FE = key[pos("BPC.FE")]
			PCB = key[pos("PCB occurs")]			
			PCB_cond = Occur if (index == 3 and BPC_FE == '1') else NotOccur
			
			if PCB == PCB_cond:			
				Detect_checkpoint(list_case, 8*index + int(BPC_FE) + checkpointNum)

def HandleResult_BreakEnableDisable_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
		
	for key, value in dict_result.items():
		if (value == 1):
			##DIR1.BEN; BPC.BE
			index = int(key[pos("DIR1.BEN")] + key[pos("BPC.BE")], 2)
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			LSAB = key[pos("LSAB occurs")]
			LSAB_cond = Occur if (index == 3) else NotOccur
			
			if LoadIns == '1':
				if 		LSAB == NotOccur and (key_RE_WE == '00' or key_RE_WE == '01'):		Detect_checkpoint(list_case, 8*index + checkpointNum)
				elif 	LSAB == LSAB_cond and key_RE_WE == '10':							Detect_checkpoint(list_case, 8*index + checkpointNum + 1)
				elif 	LSAB == LSAB_cond and key_RE_WE == '11':							Detect_checkpoint(list_case, 8*index + checkpointNum + 4)				
			if StoreIns == '1':
				if 		LSAB == NotOccur and (key_RE_WE == '00' or key_RE_WE == '10'):		Detect_checkpoint(list_case, 8*index + checkpointNum + 2)
				elif 	LSAB == LSAB_cond and key_RE_WE == '01':							Detect_checkpoint(list_case, 8*index + checkpointNum + 3)
				elif 	LSAB == LSAB_cond and key_RE_WE == '11':							Detect_checkpoint(list_case, 8*index + checkpointNum + 5)

def HandleResult_CompareAddress_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			index = int(key[pos("PC Addr hit")] + key[pos("BPC.VA")], 2)
			PCB = key[pos("PCB occurs")]
			PCB_cond = Occur if (index == 1 or index == 2) else NotOccur
			
			if PCB == PCB_cond:			
				Detect_checkpoint(list_case, 5*index + checkpointNum)

def HandleResult_CompareAddress_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			index = int(key[pos("RW Addr hit")] + key[pos("BPC.VA")], 2)
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			LSAB = key[pos("LSAB occurs")]
			LSAB_cond = NotOccur if (index == 0 or index == 3) else Occur
			
			if LSAB == LSAB_cond:
				if LoadIns == '1':				
					if 		key_RE_WE == '10':	Detect_checkpoint(list_case, 5*index + checkpointNum)
					elif 	key_RE_WE == '11':	Detect_checkpoint(list_case, 5*index + checkpointNum + 2)				
				if StoreIns == '1':
					if 		key_RE_WE == '01':	Detect_checkpoint(list_case, 5*index + checkpointNum + 1)
					elif 	key_RE_WE == '11':	Detect_checkpoint(list_case, 5*index + checkpointNum + 3)

def HandleResult_AddrMaskCmp_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):	
			Detect_checkpoint(list_case, checkpointNum)

def HandleResult_AddrMaskCmp_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			
			if (LoadIns == '1'):
				if 		key_RE_WE == '10':		Detect_checkpoint(list_case, checkpointNum)
				elif 	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 2)
			if (StoreIns == '1'):
				if 		key_RE_WE == '01':		Detect_checkpoint(list_case, checkpointNum + 1)
				elif 	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 3)

def HandleResult_AllChannelin1_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			Detect_checkpoint(list_case, checkpointNum)

def HandleResult_AllChannelin1_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

	for key, value in dict_result.items():
		if (value == 1):
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			
			if (LoadIns == '1'):
				if 		key_RE_WE == '10':		Detect_checkpoint(list_case, checkpointNum)
				elif	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 2)
			if (StoreIns == '1'):
				if 		key_RE_WE == '01':		Detect_checkpoint(list_case, checkpointNum + 1)
				elif	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 3)

def HandleResult_BreakAfterDBRET_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			Detect_checkpoint(list_case, checkpointNum)

def HandleResult_BreakAfterDBRET_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			
			if (LoadIns == '1'):
				if 		key_RE_WE == '10':		Detect_checkpoint(list_case, checkpointNum)
				elif	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 2)
			if (StoreIns == '1'):
				if 		key_RE_WE == '01':		Detect_checkpoint(list_case, checkpointNum + 1)
				elif	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 3)

def HandleResult_Illegal_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			index = int(key[pos("BPC.RE")] + key[pos("BPC.WE")], 2)
			BPC_VA = key[pos("BPC.VA")]
			PC_hit = key[pos("PC Addr hit")]
			
			if ((BPC_VA == '0' and PC_hit == '1') or (BPC_VA == '1' and PC_hit == '0')) and index != 0:
				Detect_checkpoint(list_case, index - 1 + checkpointNum)

def HandleResult_Illegal_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if value == 1:
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			BPC_VA = key[pos("BPC.VA")]
			Addr_hit = key[pos("RW Addr hit")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			
			if (BPC_VA == '0' and Addr_hit == '1') or (BPC_VA == '1' and Addr_hit == '0'):
				if (LoadIns == '1'):
					if 		key_RE_WE == '10':		Detect_checkpoint(list_case, checkpointNum)
					elif	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 2)
				if (StoreIns == '1'):
					if 		key_RE_WE == '01':		Detect_checkpoint(list_case, checkpointNum + 1)
					elif	key_RE_WE == '11':		Detect_checkpoint(list_case, checkpointNum + 3)

def HandleResult_CmpGPIDHost_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			index = int(key[pos("DBGEN.HE")] + key[pos("BPC.HE")], 2)
			PCB = key[pos("PCB occurs")]
			PCB_cond = Occur if index == 3 else NotOccur
			int_DBGEN_GEx_BPC_GEx = int(key[pos("DBGEN.GEx")] + key[pos("BPC.GEx")], 2)
			disp = 0 if int_DBGEN_GEx_BPC_GEx <= 1 else 5
			
			if PCB == PCB_cond:
				Detect_checkpoint(list_case, 10*index + checkpointNum + disp)

def HandleResult_CmpGPIDHost_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if value == 1:
			index = int(key[pos("DBGEN.HE")] + key[pos("BPC.HE")], 2)
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			LSAB = key[pos("LSAB occurs")]
			LSAB_cond = Occur if index == 3 else NotOccur
			int_DBGEN_GEx_BPC_GEx = int(key[pos("DBGEN.GEx")] + key[pos("BPC.GEx")], 2)
			disp = 0 if int_DBGEN_GEx_BPC_GEx <= 1 else 5
			
			if LSAB == LSAB_cond:
				if (LoadIns == '1'):
					if 		key_RE_WE == '10':		Detect_checkpoint(list_case, 10*index + checkpointNum + disp)
					elif	key_RE_WE == '11':		Detect_checkpoint(list_case, 10*index + checkpointNum + 2 + disp)
				if (StoreIns == '1'):
					if 		key_RE_WE == '01':		Detect_checkpoint(list_case, 10*index + checkpointNum + 1 + disp)
					elif	key_RE_WE == '11':		Detect_checkpoint(list_case, 10*index + checkpointNum + 3 + disp)

def HandleResult_CmpGPIDGuest_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			index = int(key[pos("DBGEN.GEx")] + key[pos("BPC.GEx")], 2)
			PCB = key[pos("PCB occurs")]
			PCB_cond = Occur if index == 3 else NotOccur
			int_DBGEN_HE_BPC_HE = int(key[pos("DBGEN.HE")] + key[pos("BPC.HE")], 2)
			disp = 0 if int_DBGEN_HE_BPC_HE <= 1 else 5
			key_DBGEN_GEy_BPC_GEy = key[pos("DBGEN.GEy")] + key[pos("BPC.GEy")]
			
			if PCB == PCB_cond:
				Detect_checkpoint(list_case, 10*index + checkpointNum + disp)
				if key_DBGEN_GEy_BPC_GEy == '11' and index != 3:
					Detect_checkpoint(list_case, 40 + checkpointNum + disp)
			
def HandleResult_CmpGPIDGuest_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if value == 1:
			index = int(key[pos("DBGEN.GEx")] + key[pos("BPC.GEx")], 2)
			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			LSAB = key[pos("LSAB occurs")]
			LSAB_cond = Occur if index == 3 else NotOccur
			int_DBGEN_HE_BPC_HE = int(key[pos("DBGEN.HE")] + key[pos("BPC.HE")], 2)
			disp = 0 if int_DBGEN_HE_BPC_HE <= 1 else 5
			key_DBGEN_GEy_BPC_GEy = key[pos("DBGEN.GEy")] + key[pos("BPC.GEy")]
			NotMatchGPID = True if (key_DBGEN_GEy_BPC_GEy == '11' and index != 3) else False 
			
			if LSAB == LSAB_cond:
				if (LoadIns == '1'):
					if 	key_RE_WE == '10':		
						Detect_checkpoint(list_case, 10*index + checkpointNum + disp)
						if NotMatchGPID == True: Detect_checkpoint(list_case, 40 + checkpointNum + disp)
					elif key_RE_WE == '11':		
						Detect_checkpoint(list_case, 10*index + checkpointNum + 2 + disp)
						if NotMatchGPID == True: Detect_checkpoint(list_case, 40 + checkpointNum + 2 + disp)
					
				if (StoreIns == '1'):
					if 	key_RE_WE == '01':		
						Detect_checkpoint(list_case, 10*index + checkpointNum + 1 + disp)
						if NotMatchGPID == True: Detect_checkpoint(list_case, 40 + checkpointNum + 1 + disp)
					elif key_RE_WE == '11':		
						Detect_checkpoint(list_case, 10*index + checkpointNum + 3 + disp)
						if NotMatchGPID == True: Detect_checkpoint(list_case, 40 + checkpointNum + 3 + disp)

def HandleResult_BreakAfterHMGM_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			key_DBGEN_HE_BPC_HE = key[pos("DBGEN.HE")] + key[pos("BPC.HE")]
			key_DBGEN_GEx_BPC_GEx = key[pos("DBGEN.GEx")] + key[pos("BPC.GEx")]
			if key_DBGEN_HE_BPC_HE != '11' and key_DBGEN_GEx_BPC_GEx == '11':
				index = 0
			elif key_DBGEN_HE_BPC_HE == '11' and key_DBGEN_GEx_BPC_GEx != '11':
				index = 1
			else:
				continue
			Detect_checkpoint(list_case, 5*index + checkpointNum)

def HandleResult_BreakAfterHMGM_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if (value == 1):
			key_DBGEN_HE_BPC_HE = key[pos("DBGEN.HE")] + key[pos("BPC.HE")]
			key_DBGEN_GEx_BPC_GEx = key[pos("DBGEN.GEx")] + key[pos("BPC.GEx")]
			if key_DBGEN_HE_BPC_HE != '11' and key_DBGEN_GEx_BPC_GEx == '11':
				index = 0
			elif key_DBGEN_HE_BPC_HE == '11' and key_DBGEN_GEx_BPC_GEx != '11':
				index = 1
			else:
				continue

			key_RE_WE = key[pos("BPC.RE")] + key[pos("BPC.WE")]
			LoadIns = key[pos("Load Ins")]
			StoreIns = key[pos("Store Ins")]
			if LoadIns == '1': 
				if 		key_RE_WE == '10':	Detect_checkpoint(list_case, 5*index + checkpointNum)
				elif 	key_RE_WE == '11':	Detect_checkpoint(list_case, 5*index + checkpointNum + 2)

			if StoreIns == '1': 
				if 		key_RE_WE == '01':	Detect_checkpoint(list_case, 5*index + checkpointNum + 1)
				elif 	key_RE_WE == '11':	Detect_checkpoint(list_case, 5*index + checkpointNum + 3)

def HandleResult_C2B1Ins_PCB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label, index):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if value == 1:
			key_cond = key[pos("1st_PCB occurs")] + key[pos("2nd_PCB occurs")] + key[pos("1st_BPC.BE")] + key[pos("2nd_BPC.BE")]
			if 		key_cond == '0000':	Detect_checkpoint(list_case, 4*index + checkpointNum)
			elif 	key_cond == '1010':	Detect_checkpoint(list_case, 4*index + checkpointNum + 1)
			elif 	key_cond == '0101':	Detect_checkpoint(list_case, 4*index + checkpointNum + 2)
			elif 	key_cond == '1111':	Detect_checkpoint(list_case, 4*index + checkpointNum + 3)

def HandleResult_AccessSizeVar_Cache_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, listcheckpointNum, Label, index):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	if ins not in tuple_cache:										
		list_order_type_size = [tuple_Load_byte, tuple_Load_hword, tuple_Load_word, tuple_Load_dword, tuple_Load_qword, tuple_Store_byte, tuple_Store_hword, tuple_Store_word, tuple_Store_dword, tuple_Store_qword]
		list_index_checkpoint_RWE = [listcheckpointNum[0], listcheckpointNum[1]]
		
		for pos_size in range (0, len(list_order_type_size)):
			if ins in list_order_type_size[pos_size]:
				if pos_size < 5:	type_size = pos_size + 1
				else:				type_size = pos_size - 4
				break

		for key, value in dict_result.items():
			if value == 1:
				BPC_RE = key[pos("BPC.RE")]
				BPC_WE = key[pos("BPC.WE")]
				LSAB = key[pos("LSAB occurs")]
				pos_BPC_TY0 = pos("BPC.TY = 0")
				
				if pos_size < 5 and BPC_RE == '1': ##BPC.RE = 1					
					checkpoint_index = list_index_checkpoint_RWE[int(BPC_WE)]
				elif pos_size >= 5 and BPC_WE == '1': ##BPC.WE = 1					
					checkpoint_index = list_index_checkpoint_RWE[int(BPC_RE)]
				else:
					continue
							
				for m in range (0, 6):
					##LSAB occurs, BPC.TY
					if m == 0 or m == type_size:
						if (type_size == 4 or type_size == 5) and ("final" in ins or "word2" in ins or "word3" in ins or "word4" in ins): 
							if LSAB == '0' and key[m + pos_BPC_TY0] == '1': Detect_checkpoint(list_case, 12*index + checkpoint_index + m)
						else:	
							if LSAB == '1' and key[m + pos_BPC_TY0] == '1': Detect_checkpoint(list_case, 12*index + checkpoint_index + m)
					else:
						if LSAB == '0' and key[m + pos_BPC_TY0] == '1': 	Detect_checkpoint(list_case, 12*index + checkpoint_index + m)
			
	else:
		for i in range (0, len(tuple_cache)):
			if ins == tuple_cache[i]: 
				break
				
		for key, value in dict_result.items():
			if value == 1:
				LSAB = key[pos("LSAB occurs")]
				BPC_RE = key[pos("BPC.RE")]
				BPC_WE = key[pos("BPC.WE")]
				BPC_TY0 = key[pos("BPC.TY = 0")]
				
				if LSAB == '0' and BPC_RE == '1' and BPC_TY0 == '1':
					if BPC_WE == '0':	
						Detect_checkpoint(list_case, 2*i + listcheckpointNum[2])
					else:
						Detect_checkpoint(list_case, 2*i + listcheckpointNum[3])

def HandleResult_StoreToROM_LSAB(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, checkpointNum, Label):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)
	
	for key, value in dict_result.items():
		if value == 1:
			key_LSAB_RE_BE = key[pos("LSAB occurs")] + key[pos("BPC.RE")] + key[pos("BPC.BE")]
			
			if 		key_LSAB_RE_BE == '000':	Detect_checkpoint(list_case, checkpointNum)
			elif 	key_LSAB_RE_BE == '101':	Detect_checkpoint(list_case, checkpointNum + 1)
			elif 	key_LSAB_RE_BE == '010':	Detect_checkpoint(list_case, checkpointNum + 2)
			elif 	key_LSAB_RE_BE == '111':	Detect_checkpoint(list_case, checkpointNum + 3)
			
def HandleResult_AEinPrivilege_AE(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle, listcheckpointNum, Label, index):
	dict_result = database.FilterBitCombination(OriginData, OriginListName, dict_bit_fixed, list_bit_toggle)
	if (Enable_debug_log): Print_debug_log(DebugLogControl, dict_result, dict_bit_fixed, list_bit_toggle, Label)

	for key, value in dict_result.items():
		if value == 1:
			AE = key[pos("AE occurs")]
			key_SV = key[pos("SV mode")]
			num_UM = ~int(key_SV)
			key_align = key[pos("4n + 1")] + key[pos("4n + 2")] + key[pos("4n + 3")]
			
			if AE == '1' and index >= 4 and key_SV == '0':
				print "ERROR: AE exception occurs in UM mode: ", Label				
			elif AE == '1':
				if 		key_align == '100':	Detect_checkpoint(list_case, 3*index + listcheckpointNum[num_UM])
				elif 	key_align == '010':	Detect_checkpoint(list_case, 3*index + listcheckpointNum[num_UM] + 1)
				elif 	key_align == '001':	Detect_checkpoint(list_case, 3*index + listcheckpointNum[num_UM] + 2)
													
def Recalculate_Mem_Addr(data):
	if "." in data.InsName:
		raw_name = data.InsName.split(".")
		name = raw_name[0]
		expand = raw_name[1]
		if len(data.memAddr) != 0:
			if expand == "dw" or expand == "h4":
				mem = data.memAddr[0]
				data.memAddr.append(mem + 4)
				if len(data.memAddr) != 2: print "Error mem address - Line: ", data.Line
			if expand == "qw":
				mem = data.memAddr[0]
				for i in range (1, 4):
					mem += 4
					data.memAddr.append(mem)
				if len(data.memAddr) != 4: print "Error mem address - Line: ", data.Line
	
def Break_occur(data):
	if len(data.Exp) != 0:
		if data.Exp[0] == 'PCB':	return BreakType.PCB
		elif data.Exp[0] == 'LSAB':	return BreakType.LSAB
		elif data.Exp[0] == 'AE':	return BreakType.AE	
		else:						return BreakType.NONE
	else:							return BreakType.NONE

def Detect_mode(mode, key):
	if mode == database.Mode.DM: 
		key += '100' ##Debug mode, Virtual Mode, Host mode
	elif mode == database.Mode.HM:
		key += '011'
	elif mode == database.Mode.GM:
		key += '010'
	else:
		key += '000'
		
	return key
	
def DBGEN_info(data):
	global channel_not_match
	DBGEN_HE = database.GetValueBitRange(data.SR["DBGEN"], 8, 8)
	GPID = database.GetValueBitRange(data.SR["PSWH"], 8, 10)		
	DBGEN_GEx = database.GetValueBitRange(data.SR["DBGEN"], GPID, GPID)
	
	while (channel_not_match == GPID):
		channel_not_match = random.randint(0, 7)
	
	DBGEN_GEy = database.GetValueBitRange(data.SR["DBGEN"], channel_not_match, channel_not_match)
	return str(DBGEN_HE) + str(DBGEN_GEx) + str(DBGEN_GEy)
	
def DIR1_BEN(prev_data):
	return database.GetValueBitRange(prev_data.SR["DIR1"], 0, 0)	

def Get_Break_channel(data):
	bit_BT = database.GetValueBitRange(data.SR["DIR1"], 8, 19)
	mask = 1
	for i in range (0, 11):
		bit_val = bit_BT & mask
		if (bit_val == 0): mask = mask << 1
		else: break
		
	return i

def BPC_TY(prev_data, n):
	return database.GetValueBitRange(prev_data.BPC[n], 10, 12)

def BPC_HE(prev_data, n):
	return database.GetValueBitRange(prev_data.BPC[n], 24, 24)

def BPC_GEx(prev_data, n):
	GPID = database.GetValueBitRange(prev_data.SR["PSWH"], 8, 10)
	return database.GetValueBitRange(prev_data.BPC[n], GPID + 16, GPID + 16)

def BPC_GEy(prev_data, n):
	global channel_not_match
	return database.GetValueBitRange(prev_data.BPC[n], channel_not_match + 16, channel_not_match + 16)
	
def BPC_VA(prev_data, n):
	return database.GetValueBitRange(prev_data.BPC[n], 8, 8)
	
def BPC_BE(prev_data, n):
	return database.GetValueBitRange(prev_data.BPC[n], 3, 3)

def BPC_FE(prev_data, n):
	return database.GetValueBitRange(prev_data.BPC[n], 2, 2)

def BPC_RE(prev_data, n):
	value = database.GetValueBitRange(prev_data.BPC[n], 0, 0)
	##As confirming with CPU team, with channel 4 -> 11, BPC.RE always = 0 
	if (n >= 4):
		value = 0	
	return value	
	
def BPC_WE(prev_data, n):
	value = database.GetValueBitRange(prev_data.BPC[n], 1, 1)
	##As confirming with CPU team, with channel 4 -> 11, BPC.WE always = 0 
	if (n >= 4):
		value = 0	
	return value

def BPAV(prev_data, n):
	return database.GetValueBitRange(prev_data.BPAV[n], 0, 31)
	
def BPAM(prev_data, n):
	return database.GetValueBitRange(prev_data.BPAM[n], 0, 31)

def SameMask(data, prev_data):
	if Break_occur(data) == BreakType.PCB or Break_occur(data) == BreakType.LSAB:
		channel = Get_Break_channel(data)
		tup = (BPC_VA(prev_data, channel), BPAV(prev_data, channel), BPAM(prev_data, channel), Break_occur(data))
		if tup not in dict_occured_Break:
			dict_occured_Break[tup] = data.Line
			return '0'
		else:
			return '1'				
	else: return '0'

def Max_Break_channel(data):
	bit_BT = database.GetValueBitRange(data.SR["DIR1"], 8, 19)
	result = '0'
	if Break_occur(data) == BreakType.PCB:
		if (bit_BT == 0xFFF): 	result = '1'
	elif Break_occur(data) == BreakType.LSAB:
		if (bit_BT == 0xF): 	result = '1'
	if result == '1': print "Max Break channel: ", data.Line
	return result

def Is_PC_Address_Hit(data, prev_data, n):
	return (BPAV(prev_data, n) | BPAM(prev_data, n)) == (data.PC | BPAM(prev_data, n))

def Is_RW_Address_Hit(data, prev_data, n):
	if (len(data.memAddr) != 0):
		for mem in data.memAddr:
			if ((BPAV(prev_data, n) | BPAM(prev_data, n)) == (mem | BPAM(prev_data, n))): 
				return True
			
		return False
	else: 
		return False

def Mem_Address_Hit(data, prev_data):
	list_MemAddr_hit = list()
	if (len(data.memAddr) != 0):
		for m in range (0, len(data.memAddr)):
			for n in range (0, len(data.BPC)):	
				if ((BPAV(prev_data, n) | BPAM(prev_data, n)) == (data.memAddr[m] | BPAM(prev_data, n))) and BPC_VA(prev_data, n) == 0:
					list_MemAddr_hit.append(data.memAddr[m])
	
	return list_MemAddr_hit	

def Is_store_to_ROM(data):
	#NOTICE: In order to make script simpler, we will fix the memory address of ROM
	#Read from file init_g4mh20_pe00.py: ROM area = [0x00000000, 0x01ffffff] (attribute "RX")
	if len(data.memAddr) != 0:
		for mem in data.memAddr:
			if mem <= 0x01ffffff:
				return True
	
	return False
	
def Match_LSAB_type_name(data, prev_data, dict_cond_check_LSAB, dict_cond_check_LSAB_second):
	nameSubNum = re.split('(\d+)', data.InsName)
	if len(nameSubNum) and nameSubNum[0] in dict_LSAB_size:
		dict_cond_check_LSAB = dict_LSAB_size[nameSubNum[0]]
		return dict_cond_check_LSAB, dict_cond_check_LSAB_second
	
	list_name_both_LD_ST = ["not1", "set1", "clr1", "tst1", "caxi"]
	for name in list_name_both_LD_ST:
		if name in data.InsName:
			dict_cond_check_LSAB = 			dict_LSAB_size[name + "_Load"]
			dict_cond_check_LSAB_second =	dict_LSAB_size[name + "_Store"]
			return dict_cond_check_LSAB, dict_cond_check_LSAB_second

	list_MemAddr_hit = Mem_Address_Hit(data, prev_data)
	list_name_first_final = ["dispose", "popsp", "resbank", "ldm.mp", "ld.dw", "ldv.dw", "ldvz.h4", "prepare", "pushsp", "EIINT", "stm.mp", "st.dw", "stv.dw", "stvz.h4"]
	for name in list_name_first_final:
		if name in data.InsName:
			if name == "EIINT":
				if data.Behavior == database.InsBehavior.LD_ST: 
					name = "EIINTsave"
				else:
					continue
			if len(list_MemAddr_hit) != 0:
				if list_MemAddr_hit[0] == data.memAddr[0]:
					dict_cond_check_LSAB = dict_LSAB_size[name + "_first"]
				if list_MemAddr_hit[-1] == data.memAddr[-1]:
					dict_cond_check_LSAB_second = dict_LSAB_size[name + "_final"]
			return dict_cond_check_LSAB, dict_cond_check_LSAB_second
			
	list_name_qword = ["ldv.qw", "stv.qw"]
	if data.InsName in list_name_qword:
		if len(list_MemAddr_hit) != 0:
			for n in range (0, len(data.memAddr)):
				if data.memAddr[n] in list_MemAddr_hit:
					dict_cond_check_LSAB = dict_LSAB_size[data.InsName + "_word" + str(n + 1)]
					return dict_cond_check_LSAB, dict_cond_check_LSAB_second
	
	list_name_LLbit = ["stc.b", "stc.h", "stc.w"]
	if data.InsName in list_name_LLbit:
		if prev_data.LLBIT == 0:
			dict_cond_check_LSAB = dict_LSAB_size[data.InsName + "_LLbit0"]
		else:
			dict_cond_check_LSAB = dict_LSAB_size[data.InsName + "_LLbit1"]
		return dict_cond_check_LSAB, dict_cond_check_LSAB_second
	
	if data.InsName == "EIINT" and data.Behavior == database.InsBehavior.LD:
		dict_cond_check_LSAB = dict_LSAB_size["EIINT_table"]
	elif data.InsName == "cache" and data.Opr[0] == "CFALI":
		if len(data.memAddr) != 0:	dict_cond_check_LSAB = dict_LSAB_size["CFAL"]
	elif data.InsName == "pref" and data.Opr[0] == "PREFI":
		if len(data.memAddr) != 0:	dict_cond_check_LSAB = dict_LSAB_size["PREF"]
		
	return dict_cond_check_LSAB, dict_cond_check_LSAB_second

def Concat_key_info_BPC_AddrHit(data, prev_data, channel, key_PCB_LSAB):
	##BPC.HE + BPC.GEx + BPC.GEy + BPC.VA + BPC.BE + BPC.FE + BPC.WE + BPC.RE
	key_PCB_LSAB_sub = key_PCB_LSAB + str(BPC_HE(prev_data, channel)) + str(BPC_GEx(prev_data, channel)) + str(BPC_GEy(prev_data, channel))\
									+ str(BPC_VA(prev_data, channel)) + str(BPC_BE(prev_data, channel))  \
									+ str(BPC_FE(prev_data, channel)) + str(BPC_WE(prev_data, channel))  \
									+ str(BPC_RE(prev_data, channel)) 
	
	##BPC.TY = 0
	if BPC_TY(prev_data, channel) == 0:
		key_PCB_LSAB_sub += '1'
	else:
		key_PCB_LSAB_sub += '0'
	
	##PC Addr hit
	if Is_PC_Address_Hit(data, prev_data, channel) == True:
		key_PCB_LSAB_sub += '1'
	else:
		key_PCB_LSAB_sub += '0'				
	
	##RW Addr hit
	if Is_RW_Address_Hit(data, prev_data, channel) == True:
		key_PCB_LSAB_sub += '1'
	else:
		key_PCB_LSAB_sub += '0'
		
	##Channel < 4:
	if channel < 4:
		key_PCB_LSAB_sub += '1'
	else:
		key_PCB_LSAB_sub += '0'
		
	return key_PCB_LSAB_sub

def Concat_key_info_condition_BPC_TY(data, prev_data, channel, key_cond_check_LSAB, HVCFG_HVE):
	if HVCFG_HVE == 1:
		mode = database.GetMode(prev_data.SR)
		if data.InsName == "EIINT" and mode == database.Mode.GM:
			mode = database.Mode.HM 
			
		if mode == database.Mode.HM:
			if DBGEN_info(data)[0] == '0' or BPC_HE(prev_data, channel) == 0: return ""
		elif mode == database.Mode.GM:
			if DBGEN_info(data)[1] == '0' or BPC_GEx(prev_data, channel) == 0: return ""
		else:
			return ""
			
	if not (BPC_FE(prev_data, channel) == 0 and Is_RW_Address_Hit(data, prev_data, channel) == True and BPC_VA(prev_data, channel) == 0): 	
		return ""
		
	##BPC.BE + BPC.WE + BPC.RE
	key_cond_check_LSAB_sub = key_cond_check_LSAB + str(BPC_BE(prev_data, channel)) + str(BPC_WE(prev_data, channel)) + str(BPC_RE(prev_data, channel))
	
	##BPC.TY
	list_key_BPC_TY = ['100000', '010000', '001000', '000100', '000010', '000001']
	key_cond_check_LSAB_sub +=  list_key_BPC_TY[BPC_TY(prev_data, channel)]
	
	##Channel < 4:
	if channel < 4:
		key_cond_check_LSAB_sub += '1'
	else:
		key_cond_check_LSAB_sub += '0'
	
	return key_cond_check_LSAB_sub

def Satisfy_all_condition_PCB_C2B1(data, prev_data, channel, HVCFG_HVE):
	if HVCFG_HVE == 1:
		mode = database.GetMode(prev_data.SR)
		if data.InsName == "EIINT" and mode == database.Mode.GM:
			mode = database.Mode.HM 
		if mode == database.Mode.HM:
			if DBGEN_info(data)[0] == '0' or BPC_HE(prev_data, channel) == 0: return False
		elif mode == database.Mode.GM:
			if DBGEN_info(data)[1] == '0' or BPC_GEx(prev_data, channel) == 0: return False
		else:
			return False

	if BPC_FE(prev_data, channel) == 1 and BPC_WE(prev_data, channel) == 0 and BPC_RE(prev_data, channel) == 0:
		if ((Is_PC_Address_Hit(data, prev_data, channel) == True and BPC_VA(data, channel) == 0) 
			or (Is_PC_Address_Hit(data, prev_data, channel) == False and BPC_VA(prev_data, channel) == 1)):
				return True			
	
	return False
	
def CheckingDebugCoverage(data, prev_data, data_before_prev):
	global channel_not_match
	
	#Refresh dictionary contain Break for each log file
	if data.Line == start_line:		dict_occured_Break = dict()
	
	Cancel_update_dict_cond_check_LSAB = False
	channel_not_match = 0	
	data.InsName, data.Opr = database.ConvertInsHasSpecialOpr(data.InsName, data.Opr)
	Recalculate_Mem_Addr(data)
	HVCFG_HVE = database.GetValueBitRange(data.SR["HVCFG"], 0, 0)
	
	#Detect type of break
	if 	Break_occur(data) == BreakType.PCB:
		key_PCB_LSAB = '10' ##PCB occurs
		key_cond_check_LSAB = '0'
		key_cond_check_Others = '0'
	elif Break_occur(data) == BreakType.LSAB:
		key_PCB_LSAB = '01' ##LSAB occurs
		key_cond_check_LSAB = '1'
		key_cond_check_Others = '0'
	elif Break_occur(data) == BreakType.AE:
		key_PCB_LSAB = '00'
		key_cond_check_LSAB = '0'
		key_cond_check_Others = '1'
	else:
		key_PCB_LSAB = '00'
		key_cond_check_LSAB = '0'
		key_cond_check_Others = '0'

	#Detect Mode
	cur_mode = database.GetMode(prev_data.SR)
	if data.InsName == "EIINT" and cur_mode == database.Mode.GM:
		cur_mode = database.Mode.HM
	key_PCB_LSAB = Detect_mode(cur_mode, key_PCB_LSAB) ##Debug mode, Virtual Mode, Host mode
	key_cond_check_LSAB = Detect_mode(cur_mode, key_cond_check_LSAB)
	key_cond_check_Others = Detect_mode(cur_mode, key_cond_check_Others)
	
	#Detect Privilege
	priv = database.GetModeAndPrivilege(prev_data.SR)
	if priv == database.Mode.HM_HV or priv == database.Mode.GM_SV or priv == database.Mode.CV_SV:
		key_cond_check_Others += '1'
	else:
		key_cond_check_Others += '0'

	#Detect behavior of instruction
	if 		data.Behavior == 0:			
		key_PCB_LSAB += '00'
	elif	data.Behavior == database.InsBehavior.LD:			
		key_PCB_LSAB += '10'
	elif	data.Behavior == database.InsBehavior.ST:			
		key_PCB_LSAB += '01'
	elif	data.Behavior == database.InsBehavior.LD_ST:			
		key_PCB_LSAB += '11'

	#Only using when Enable_test_PCB_LSAB
	if (Enable_test_PCB_LSAB):
		##Same mask
		key_PCB_LSAB += SameMask(data, prev_data)

		##Is_all_channel
		key_PCB_LSAB += Max_Break_channel(data)

		##After DBRET
		if (prev_data.InsName == "dbret"): key_PCB_LSAB += '1'
		else:	key_PCB_LSAB += '0'

		##HM->GM
		prev_mode = database.GetMode(data_before_prev.SR)
		if (prev_data.InsName == "eiret" or prev_data.InsName == "feret") and prev_mode == database.Mode.HM and cur_mode == database.Mode.GM:
			key_PCB_LSAB += '1'
		else:
			key_PCB_LSAB += '0'
			
		##GM->HM
		if len(prev_data.Exp) != 0 and prev_mode == database.Mode.GM and cur_mode == database.Mode.HM:
			key_PCB_LSAB += '1'
		else:
			key_PCB_LSAB += '0'
	
		##DIR1.BEN
		key_PCB_LSAB += str(DIR1_BEN(prev_data))
		
		##DBGEN.HE + DBGEN.GEx + DBGEN.GEy
		key_PCB_LSAB += DBGEN_info(data)

	#Only using when Enable_test_LSAB
	if (Enable_test_LSAB):
		##ST->ROM
		if Is_store_to_ROM(data) == True:
			key_cond_check_LSAB += '1'
		else:
			key_cond_check_LSAB += '0'

		dict_cond_check_LSAB = dict()
		dict_cond_check_LSAB_second = dict()
		if DIR1_BEN(prev_data) == 0 or data.Behavior == 0:
			Cancel_update_dict_cond_check_LSAB = True
		else:
			dict_cond_check_LSAB, dict_cond_check_LSAB_second = Match_LSAB_type_name(data, prev_data, dict_cond_check_LSAB, dict_cond_check_LSAB_second)
	
	#Only using when Enable_test_Others
	if (Enable_test_Others):
		dict_cond_check_Others = dict()		
		for name in tuple_pos_Others:
			if name in data.InsName:
				dict_cond_check_Others = dict_Others[name]
				break
		
		if len(dict_cond_check_Others) != 0 and len(data.memAddr) != 0:
			align = data.memAddr[0] % 4
			list_key_align = ['000', '100', '010', '001']
			key_cond_check_Others += list_key_align[align]
			if len(key_cond_check_Others) != lengthOfList_Others:
				print "Error: Length of key_cond_check_Others is not suitable: key = ", key_cond_check_Others, " - Expected len: ", lengthOfList_Others, " - Line: ", data.Line
			else:
				dict_cond_check_Others[key_cond_check_Others] = 1
		
	for n in range(len(prev_data.BPC)):
		#Only using when Enable_test_PCB_LSAB
		if (Enable_test_PCB_LSAB):
			key_PCB_LSAB_sub = Concat_key_info_BPC_AddrHit(data, prev_data, n, key_PCB_LSAB)
			
			if len(key_PCB_LSAB_sub) != lengthOfList_PCB_LSAB:
				print "Error: Length of key_PCB_LSAB is not suitable: key = ", key_PCB_LSAB_sub, " - Expected len: ", lengthOfList_PCB_LSAB, " - Line: ", data.Line
				break
			dict_PCB_LSAB[key_PCB_LSAB_sub] = 1
		
		#Only using when Enable_test_LSAB
		if (Enable_test_LSAB) and Cancel_update_dict_cond_check_LSAB == False:
			key_cond_check_LSAB_sub = Concat_key_info_condition_BPC_TY(data, prev_data, n, key_cond_check_LSAB, HVCFG_HVE)
			
			if len(key_cond_check_LSAB_sub) != lengthOfList_LSAB and len(key_cond_check_LSAB_sub) != 0:
				print "Error: Length of key_cond_check_LSAB_sub is not suitable: key = ", key_cond_check_LSAB_sub, " - Expected len: ", lengthOfList_LSAB, " - Line: ", data.Line
				break
				
			if len(dict_cond_check_LSAB) != 0 and len(key_cond_check_LSAB_sub) != 0:
				dict_cond_check_LSAB[key_cond_check_LSAB_sub] = 1
			if len(dict_cond_check_LSAB_second) != 0 and len(key_cond_check_LSAB_sub) != 0: 
				dict_cond_check_LSAB_second[key_cond_check_LSAB_sub] = 1
									
def Test_PCB_C2B1(data, dict_C2B1):	
	for key, value in dict_C2B1.items():
		if key in dict_PCB_C2B1:
			dict_cond_check_PCB = dict_PCB_C2B1[key]
		else:
			continue
		for tup in value:
			data_first_C2B1 = data[tup[0]]
			prev_data_first_C2B1 = data[tup[0] - 1]
			data_second_C2B1 = data[tup[1]]
			prev_data_second_C2B1 = data[tup[1] - 1]
			list_channel_br_1st_C2B1 = list()
			list_channel_br_2nd_C2B1 = list()
			HVCFG_HVE = database.GetValueBitRange(data_first_C2B1.SR["HVCFG"], 0, 0)
			
			key_cond_check_PCB = ''
			##Debug mode, Virtual Mode, Host mode
			mode = database.GetMode(prev_data_first_C2B1.SR)
			key_cond_check_PCB = Detect_mode(mode, key_cond_check_PCB) 

			##1st_PCB occurs
			if len(data_first_C2B1.Exp) != 0 and data_first_C2B1.Exp[0] == "PCB":
				key_cond_check_PCB += '1'
			else:
				key_cond_check_PCB += '0'
			##2nd_PCB occurs
			if len(data_second_C2B1.Exp) != 0 and data_second_C2B1.Exp[0] == "PCB":
				key_cond_check_PCB += '1'
			else:
				key_cond_check_PCB += '0'	
			
			if DIR1_BEN(prev_data_first_C2B1) == 0:
				continue			
				
			for n in range(len(prev_data_first_C2B1.BPC)):
				if Satisfy_all_condition_PCB_C2B1(data_first_C2B1, prev_data_first_C2B1, n, HVCFG_HVE) == True:
					list_channel_br_1st_C2B1.append(n)
			
				if Satisfy_all_condition_PCB_C2B1(data_second_C2B1, prev_data_second_C2B1, n, HVCFG_HVE) == True:
					list_channel_br_2nd_C2B1.append(n)
			
			if len(list_channel_br_1st_C2B1) == 0 or len(list_channel_br_2nd_C2B1) == 0:
				continue
			
			##1st_BPC.BE
			_1st_BPC_BE_satisfy = False
			for channel in list_channel_br_1st_C2B1:
				if BPC_BE(prev_data_first_C2B1, channel) == 1:
					key_cond_check_PCB += '1'
					_1st_BPC_BE_satisfy = True
					break			
			if _1st_BPC_BE_satisfy == False: key_cond_check_PCB += '0'
			
			##2nd_BPC.BE
			_2nd_BPC_BE_satisfy = False
			for channel in list_channel_br_2nd_C2B1:
				if BPC_BE(prev_data_second_C2B1, channel) == 1:
					key_cond_check_PCB += '1'
					_2nd_BPC_BE_satisfy = True
					break			
			if _2nd_BPC_BE_satisfy == False: key_cond_check_PCB += '0'
			
			if len(key_cond_check_PCB) != lengthOfList_PCB:
				print "Error: Length of key_cond_check_PCB is not suitable: key = ", key_cond_check_PCB, " - Expected len: ", lengthOfList_PCB, " - Line: ", data.Line
				break
			dict_cond_check_PCB[key_cond_check_PCB] = 1
			 
#-------------------------------------------------------------------
# ----------------------------- MAIN Function ----------------------
#-------------------------------------------------------------------
start_time = datetime.datetime.now()
print "Start Checking Coverage Debug: ", start_time
cforest_log = sys.argv[1:]
OutputFileName = "Log_Coverage_Debug.csv"
OutputFileControl = open(OutputFileName, 'w')

database.GR = {}
database.WR = {}
database.SR = { 'HVCFG' : 0, 'PSWH' : 0, 'PSW' : 0, 'GMPSW' : 0,
				'MPM' : 0,
				'DBGEN' : 0, 'DBIC' : 0, 'DBPC' : 0, 'DIR0' : 0, 'DIR1' : 0, 'BPC' : 0, 'BPAV' : 0, 'BPAM' : 0}
				
#-------------Control mode of script--------------
Enable_test_PCB_LSAB = True
Enable_test_PCB = False
Enable_test_LSAB = False
Enable_test_Others = False

Enable_debug_log = True
#-------------End control mode of script--------------
key_PCB_LSAB = ""
key_cond_check_PCB = ""
key_cond_check_LSAB = ""
key_cond_check_Others = ""
channel_not_match = 0
				
if (Enable_test_PCB_LSAB):
	list_PCB_LSAB = [	"PCB occurs", "LSAB occurs", "Debug Mode", "Virtual Mode", "Host Mode", "Load Ins", "Store Ins", "Same mask", "Is_all_channel", "After DBRET", "HM->GM", "GM->HM", "DIR1.BEN", "DBGEN.HE", "DBGEN.GEx", "DBGEN.GEy", ## channel match: .GEx; channel not match: .GEy
						"BPC.HE", "BPC.GEx", "BPC.GEy", "BPC.VA", "BPC.BE", "BPC.FE", "BPC.WE", "BPC.RE", "BPC.TY = 0", "PC Addr hit", "RW Addr hit", "Channel < 4"]								
	dict_PCB_LSAB = dict()
	dict_occured_Break = dict()
	lengthOfList_PCB_LSAB = len(list_PCB_LSAB)

if (Enable_test_PCB):
	""" Only update into this dict when condition is satisfied: Two ins is C2B1, Sreg BPCn <- updated by channel break only
	"""
	list_cond_check_PCB = [	"Debug Mode", "Virtual Mode", "Host Mode",
							"1st_PCB occurs", "2nd_PCB occurs", 
							"1st_BPC.BE", "2nd_BPC.BE"]
	dict_cond_check_PCB = dict()
	lengthOfList_PCB = len(list_cond_check_PCB)
	list_1st_C2B1_ins_before_Bcond = ["cmp", "add", "sub", "subr", "tst", "and", "xor", "or", "cmp5", "add5", "shr5", "sar5", "shl5"]
	list_2nd_C2B1_ins_after_mov = ["add", "sub", "subr", "and", "xor", "or", "add5", "shr5", "sar5", "shl5"]
	list_pos_PCB_C2B1 = list()
	for n in range (0, len(list_1st_C2B1_ins_before_Bcond)):
		type_C2B1 = list_1st_C2B1_ins_before_Bcond[n] + "_Bcond9"
		list_pos_PCB_C2B1.append(type_C2B1) 
		
	for n in range (0, len(list_2nd_C2B1_ins_after_mov)):
		type_C2B1 = "MOVR_" + list_2nd_C2B1_ins_after_mov[n]
		list_pos_PCB_C2B1.append(type_C2B1)	
		
	dict_PCB_C2B1 = collections.OrderedDict()
	for type_C2B1 in list_pos_PCB_C2B1:
		dict_PCB_C2B1[type_C2B1] = dict(dict_cond_check_PCB)
				 
if (Enable_test_LSAB):
	list_cond_check_LSAB = [	"LSAB occurs",
								"Debug Mode", "Virtual Mode", "Host Mode", "ST->ROM",
								"BPC.BE", "BPC.WE", "BPC.RE", "BPC.TY = 0", "BPC.TY = 1", "BPC.TY = 2", "BPC.TY = 3", "BPC.TY = 4", "BPC.TY = 5", "Channel < 4"]
	lengthOfList_LSAB = len(list_cond_check_LSAB)
	dict_cond_check_LSAB = dict()

	tuple_Load_byte = 	("ld.b", "ld.b+", "ld.b-", "ldl.bu", "not1_Load", "set1_Load", "clr1_Load", "tst1_Load")
	tuple_Load_hword = 	("ld.h", "ld.h+", "ld.h-", "ldl.hu")
	tuple_Load_word =	("ld.w", "ld.w+", "ld.w-", "ldl.w", "caxi_Load", "switch", "callt", "syscall", "dispose_first", "dispose_final", "popsp_first", "popsp_final", "resbank_first", "resbank_final", "EIINT_table", "ldv.w", "ldm.mp_first", "ldm.mp_final")
	tuple_Load_dword =	("ld.dw_first", "ld.dw_final", "ldv.dw_first", "ldv.dw_final", "ldvz.h4_first", "ldvz.h4_final")
	tuple_Load_qword = 	("ldv.qw_word1", "ldv.qw_word2", "ldv.qw_word3", "ldv.qw_word4")
	tuple_Store_byte =	("st.b", "st.b+", "st.b-", "stc.b_LLbit0", "stc.b_LLbit1", "not1_Store", "clr1_Store", "set1_Store", "tst1_Store")
	tuple_Store_hword =	("st.h", "st.h+", "st.h-", "stc.h_LLbit0", "stc.h_LLbit1")
	tuple_Store_word =	("st.w", "st.w+", "st.w-", "stc.w_LLbit0", "stc.w_LLbit1", "caxi_Store", "prepare_first", "prepare_final", "pushsp_first", "pushsp_final", "EIINTsave_first", "EIINTsave_final", "stm.mp_first", "stm.mp_final", "stv.w")
	tuple_Store_dword =	("st.dw_first", "st.dw_final", "stv.dw_first", "stv.dw_final", "stvz.h4_first", "stvz.h4_final")
	tuple_Store_qword = ("stv.qw_word1", "stv.qw_word2", "stv.qw_word3", "stv.qw_word4")
	tuple_cache =		("CFAL", "PREF")
	
	tuple_pos_LSAB_size = tuple_Load_byte + tuple_Load_hword + tuple_Load_word + tuple_Load_dword + tuple_Load_qword + tuple_Store_byte + tuple_Store_hword + tuple_Store_word + tuple_Store_dword + tuple_Store_qword + tuple_cache
	dict_LSAB_size = collections.OrderedDict()
	for n in range (0, len(tuple_pos_LSAB_size)):
		ins_ld_st = tuple_pos_LSAB_size[n]
		dict_LSAB_size[ins_ld_st] = dict(dict_cond_check_LSAB)
	
if (Enable_test_Others):
	list_cond_check_Others = [	"AE occurs", 
								"Debug Mode", "Virtual Mode", "Host Mode",	"SV mode",
								"4n + 1", "4n + 2", "4n + 3"]
	lengthOfList_Others = len(list_cond_check_Others)
	dict_cond_check_Others = dict()
	
	tuple_pos_Others = ("prepare", "dispose", "pushsp", "popsp", "ldm.mp", "stm.mp")
	dict_Others = collections.OrderedDict()
	for n in range (0, len(tuple_pos_Others)):
		ins_Others = tuple_pos_Others[n]
		dict_Others[ins_Others] = dict(dict_cond_check_Others)

if (Enable_debug_log):
	DebugLog = "Debug_result_log.csv"
	DebugLogControl = open(DebugLog, 'w') 
	
for log in cforest_log:
	start_time_log = datetime.datetime.now()
	print "File: ", log, " Start Time: ", start_time_log
	raw_data = database.CollectData(log)
	raw_data = database.CorrectLineInfor(raw_data)
	#Get start and end of random code
	start_line = database.GetIndexStartRandomCode(raw_data)
	end_line = database.GetIndexEndRandomCode(raw_data)
	
	#database.PrintData(raw_data)		
	if (Enable_test_PCB):
		dict_C2B1 = database.CollectC2B1Pos(raw_data, start_line, end_line)
		Test_PCB_C2B1(raw_data, dict_C2B1)
	
	for line in range (start_line, end_line):
		CheckingDebugCoverage(raw_data[line], raw_data[line - 1], raw_data[line - 2])
	
	del raw_data
	end_time_log = datetime.datetime.now()
	print "Time Lapse: ", (end_time_log - start_time_log)
	

"""
-------------------------------------------------------------------------
----------------------- Handle result file ------------------------------
-------------------------------------------------------------------------
Please refer document: Traceability_table_Debug_checkpointNum.xlsx to understand the method to check position of checkpoint
"""
list_case = ["Fail"] * 3630

AccumulationFile = 'Data_Accumulation.bk'
#Load back data from backup file(if exists) before executing script
if os.path.isfile(AccumulationFile):
	with open(AccumulationFile, 'rb') as file_bk:
		list_case = pickle.load(file_bk)

if (Enable_test_PCB_LSAB):
	Occur = 	'1'
	NotOccur = 	'0'
	#-----------------------------------------------
	#-------------- Convention mode ----------------
	#-----------------------------------------------	
	def pos(bitname):
		position = len(dict_CV_PCB_LSAB_fixed) + list_CV_PCB_LSAB_toggle.index(bitname)
		return position
		
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])			
	list_CV_PCB_LSAB_toggle = ["DIR1.BEN", "BPC.BE", "BPC.FE",	"PCB occurs"]
	checkpointNum = 1
	Label = "Conventional - PCB_LSAB: Break enable/disable - PCB"
	HandleResult_BreakEnableDisable_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("BPC.VA",			'0'),
													("RW Addr hit", 	'1'),
													("BPC.TY = 0",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "DIR1.BEN", "BPC.BE", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 3
	Label = "Conventional - PCB_LSAB: Break enable/disable - LSAB"
	HandleResult_BreakEnableDisable_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)	
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN", 		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = ["PC Addr hit", "BPC.VA", "PCB occurs"]
	checkpointNum = 33
	Label = "Convention - PCB_LSAB: Compare address - PCB"
	HandleResult_CompareAddress_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)				
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.TY = 0",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = ["RW Addr hit", "BPC.VA", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 34
	Label = "Convention - PCB_LSAB: Compare address - LSAB"
	HandleResult_CompareAddress_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)
			
						
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("Same mask",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.VA",			'0'),
													("PC Addr hit", 	'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0'),
													("PCB occurs",		'1')])				
	list_CV_PCB_LSAB_toggle = list()
	checkpointNum = 53
	Label = "Convention - PCB_LSAB: Address mask comparison - PCB"
	HandleResult_AddrMaskCmp_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("Same mask",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.VA",			'0'),
													("RW Addr hit", 	'1'),
													("BPC.TY = 0",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 54
	Label = "Convention - PCB_LSAB: Address mask comparison - LSAB"
	HandleResult_AddrMaskCmp_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("Is_all_channel",	'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0'),
													("PCB occurs",		'1')])
	list_CV_PCB_LSAB_toggle = list()
	checkpointNum = 58
	Label = "Convention - PCB_LSAB: All channel setting for 1 event - PCB"
	HandleResult_AllChannelin1_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)	
		
		
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("Is_all_channel",	'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 59
	Label = "Convention - PCB_LSAB: All channel setting for 1 event - LSAB" 
	HandleResult_AllChannelin1_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)
		
		
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'1'),
													("After DBRET",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = list()
	checkpointNum = 63
	Label = "Convention - PCB_LSAB: Break after DBRET - PCB"
	HandleResult_BreakAfterDBRET_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("After DBRET",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
	list_CV_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 64
	Label = "Convention - PCB_LSAB: Break after DBRET - LSAB"
	HandleResult_BreakAfterDBRET_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'0'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])					
	list_CV_PCB_LSAB_toggle = ["BPC.VA", "PC Addr hit", "BPC.RE", "BPC.WE"]
	checkpointNum = 68
	Label = "Convention - PCB_LSAB: Illegal setting - PCB"
	HandleResult_Illegal_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_CV_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'0'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.TY = 0",		'1'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])					
	list_CV_PCB_LSAB_toggle = ["BPC.VA", "RW Addr hit", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 71
	Label = "Convention - PCB_LSAB: Illegal setting - LSAB"
	HandleResult_Illegal_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_CV_PCB_LSAB_fixed, list_CV_PCB_LSAB_toggle, checkpointNum, Label)

	
	#-----------------------------------------------
	#------------ Virtualization mode --------------
	#-----------------------------------------------				
	def pos(bitname):
		position = len(dict_VS_PCB_LSAB_fixed) + list_VS_PCB_LSAB_toggle.index(bitname)
		return position
		
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])			
	list_VS_PCB_LSAB_toggle = ["DIR1.BEN", "BPC.BE", "BPC.FE",	"PCB occurs"]
	checkpointNum = 1165
	Label = "Host - PCB_LSAB: Break enable/disable - PCB"
	HandleResult_BreakEnableDisable_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("BPC.VA",			'0'),
													("RW Addr hit", 	'1'),
													("BPC.TY = 0",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "DIR1.BEN", "BPC.BE", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 1167
	Label = "Host - PCB_LSAB: Break enable/disable - LSAB"
	HandleResult_BreakEnableDisable_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])			
	list_VS_PCB_LSAB_toggle = ["DIR1.BEN", "BPC.BE", "BPC.FE",	"PCB occurs"]
	checkpointNum = 1197
	Label = "Guest - PCB_LSAB: Break enable/disable - PCB"
	HandleResult_BreakEnableDisable_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("BPC.VA",			'0'),
													("RW Addr hit", 	'1'),
													("BPC.TY = 0",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "DIR1.BEN", "BPC.BE", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 1199
	Label = "Guest - PCB_LSAB: Break enable/disable - LSAB"
	HandleResult_BreakEnableDisable_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1')])			
	list_VS_PCB_LSAB_toggle = ["DBGEN.HE", "BPC.HE", "DBGEN.GEx", "BPC.GEx", "PCB occurs"]
	checkpointNum = 1229
	Label = "Host - PCB_LSAB: Compare GPID match/not match - PCB"
	HandleResult_CmpGPIDHost_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])			
	list_VS_PCB_LSAB_toggle = ["DBGEN.HE", "BPC.HE", "DBGEN.GEx", "BPC.GEx", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 1230
	Label = "Host - PCB_LSAB: Compare GPID match/not match - LSAB"
	HandleResult_CmpGPIDHost_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0')])			
	list_VS_PCB_LSAB_toggle = ["DBGEN.HE", "BPC.HE", "DBGEN.GEx", "BPC.GEx", "DBGEN.GEy", "BPC.GEy", "PCB occurs"]
	checkpointNum = 1269
	Label = "Guest - PCB_LSAB: Compare GPID match/not match - PCB"
	HandleResult_CmpGPIDGuest_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.VA", 			'0'),			
													("PC Addr hit",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])			
	list_VS_PCB_LSAB_toggle = ["DBGEN.HE", "BPC.HE", "DBGEN.GEx", "BPC.GEx", "DBGEN.GEy", "BPC.GEy", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 1270
	Label = "Guest - PCB_LSAB: Compare GPID match/not match - LSAB"
	HandleResult_CmpGPIDGuest_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN", 		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = ["PC Addr hit", "BPC.VA", "PCB occurs"]
	checkpointNum = 1319
	Label = "Host - PCB_LSAB: Compare address - PCB"
	HandleResult_CompareAddress_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)				
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.TY = 0",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = ["RW Addr hit", "BPC.VA", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 1320
	Label = "Host - PCB_LSAB: Compare address - LSAB"
	HandleResult_CompareAddress_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN", 		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = ["PC Addr hit", "BPC.VA", "PCB occurs"]
	checkpointNum = 1339
	Label = "Guest - PCB_LSAB: Compare address - PCB"
	HandleResult_CompareAddress_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)				
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.TY = 0",		'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = ["RW Addr hit", "BPC.VA", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE", "LSAB occurs"]
	checkpointNum = 1340
	Label = "Guest - PCB_LSAB: Compare address - LSAB"
	HandleResult_CompareAddress_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("Same mask",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.VA",			'0'),
													("PC Addr hit", 	'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1'),
													("PCB occurs",		'1')])				
	list_VS_PCB_LSAB_toggle = list()
	checkpointNum = 1359
	Label = "Host - PCB_LSAB: Address mask comparison - PCB"
	HandleResult_AddrMaskCmp_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("Same mask",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.VA",			'0'),
													("RW Addr hit", 	'1'),
													("BPC.TY = 0",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1360
	Label = "Host - PCB_LSAB: Address mask comparison - LSAB"
	HandleResult_AddrMaskCmp_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("Same mask",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.VA",			'0'),
													("PC Addr hit", 	'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1'),
													("PCB occurs",		'1')])				
	list_VS_PCB_LSAB_toggle = list()
	checkpointNum = 1364
	Label = "Guest - PCB_LSAB: Address mask comparison - PCB"
	HandleResult_AddrMaskCmp_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("Same mask",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.VA",			'0'),
													("RW Addr hit", 	'1'),
													("BPC.TY = 0",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1365
	Label = "Guest - PCB_LSAB: Address mask comparison - LSAB"
	HandleResult_AddrMaskCmp_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("Is_all_channel",	'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1'),
													("PCB occurs",		'1')])
	list_VS_PCB_LSAB_toggle = list()
	checkpointNum = 1369
	Label = "Host - PCB_LSAB: All channel setting for 1 event - PCB"
	HandleResult_AllChannelin1_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)	
		
		
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("Is_all_channel",	'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1370
	Label = "Host - PCB_LSAB: All channel setting for 1 event - LSAB" 
	HandleResult_AllChannelin1_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("Is_all_channel",	'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1'),
													("PCB occurs",		'1')])
	list_VS_PCB_LSAB_toggle = list()
	checkpointNum = 1374
	Label = "Guest - PCB_LSAB: All channel setting for 1 event - PCB"
	HandleResult_AllChannelin1_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)	
		
		
	#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("Is_all_channel",	'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1375
	Label = "Guest - PCB_LSAB: All channel setting for 1 event - LSAB" 
	HandleResult_AllChannelin1_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'1'),
													("After DBRET",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = list()
	checkpointNum = 1379
	Label = "Host - PCB_LSAB: Break after DBRET - PCB"
	HandleResult_BreakAfterDBRET_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("After DBRET",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1380
	Label = "Host - PCB_LSAB: Break after DBRET - LSAB"
	HandleResult_BreakAfterDBRET_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'1'),
													("After DBRET",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.RE",			'0'),
													("BPC.WE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = list()
	checkpointNum = 1384
	Label = "Guest - PCB_LSAB: Break after DBRET - PCB"
	HandleResult_BreakAfterDBRET_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
			
			
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'),
													("After DBRET",		'1'),
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])
	list_VS_PCB_LSAB_toggle = ["Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1385
	Label = "Guest - PCB_LSAB: Break after DBRET - LSAB"
	HandleResult_BreakAfterDBRET_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'0'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])					
	list_VS_PCB_LSAB_toggle = ["BPC.VA", "PC Addr hit", "BPC.RE", "BPC.WE"]
	checkpointNum = 1389
	Label = "Host - PCB_LSAB: Illegal setting - PCB"
	HandleResult_Illegal_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'0'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.TY = 0",		'1'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("DBGEN.HE",		'1'),
													("BPC.HE",			'1')])					
	list_VS_PCB_LSAB_toggle = ["BPC.VA", "RW Addr hit", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1392
	Label = "Host - PCB_LSAB: Illegal setting - LSAB"
	HandleResult_Illegal_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	
	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'0'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])					
	list_VS_PCB_LSAB_toggle = ["BPC.VA", "PC Addr hit", "BPC.RE", "BPC.WE"]
	checkpointNum = 1396
	Label = "Guest - PCB_LSAB: Illegal setting - PCB"
	HandleResult_Illegal_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)

	
	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'0'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.TY = 0",		'1'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("DBGEN.GEx",		'1'),
													("BPC.GEx",			'1')])					
	list_VS_PCB_LSAB_toggle = ["BPC.VA", "RW Addr hit", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1399
	Label = "Guest - PCB_LSAB: Illegal setting - LSAB"
	HandleResult_Illegal_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)
	

	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("PCB occurs",		'1'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'1'),
													("BPC.WE",			'0'),
													("BPC.RE",			'0'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("BPC.VA",			'0'),
													("PC Addr hit",		'1'),
													("HM->GM",			'1')])					
	list_VS_PCB_LSAB_toggle = ["DBGEN.HE", "BPC.HE", "DBGEN.GEx", "BPC.GEx"]
	checkpointNum = 1403
	Label = "Host<->Guest - PCB_LSAB: Break after change HM<->GM - PCB"
	HandleResult_BreakAfterHMGM_PCB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)


	#--------------------------------------------------------------------------------------------------------------------------------
	dict_VS_PCB_LSAB_fixed = OrderedDict([			("LSAB occurs",		'1'), 								
													("DIR1.BEN",		'1'),
													("BPC.BE",			'1'),
													("BPC.FE",			'0'),
													("BPC.TY = 0",		'1'),
													("Channel < 4",		'1'),
													("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("BPC.VA",			'0'),
													("RW Addr hit",		'1'),
													("GM->HM",			'1')])					
	list_VS_PCB_LSAB_toggle = ["DBGEN.HE", "BPC.HE", "DBGEN.GEx", "BPC.GEx", "Load Ins", "Store Ins", "BPC.RE", "BPC.WE"]
	checkpointNum = 1404
	Label = "Host<->Guest - PCB_LSAB: Break after change HM<->GM - LSAB"
	HandleResult_BreakAfterHMGM_LSAB(dict_PCB_LSAB, list_PCB_LSAB, dict_VS_PCB_LSAB_fixed, list_VS_PCB_LSAB_toggle, checkpointNum, Label)

if (Enable_test_PCB):	
	for type_C2B1 in dict_PCB_C2B1:
		index = dict_PCB_C2B1.keys().index(type_C2B1)
		dict_cond_check_PCB = dict_PCB_C2B1[type_C2B1]
		
		#-----------------------------------------------
		#-------------- Convention mode ----------------
		#-----------------------------------------------	
		def pos(bitname):
			position = len(dict_CV_PCB_fixed) + list_CV_PCB_toggle.index(bitname)
			return position
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		dict_CV_PCB_fixed 	= OrderedDict([			("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])
		list_CV_PCB_toggle 	= [	"1st_PCB occurs", "2nd_PCB occurs", "1st_BPC.BE", "2nd_BPC.BE"]
		checkpointNum = 75
		Label = type_C2B1 + " - Conventional - PCB"
		HandleResult_C2B1Ins_PCB(dict_cond_check_PCB, list_cond_check_PCB, dict_CV_PCB_fixed, list_CV_PCB_toggle, checkpointNum, Label, index)
		
		
		#-----------------------------------------------
		#------------ Virtualization mode --------------
		#-----------------------------------------------	
		def pos(bitname):
			position = len(dict_VS_PCB_fixed) + list_VS_PCB_toggle.index(bitname)
			return position
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		dict_VS_PCB_fixed 	= OrderedDict([			("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1')])
		list_VS_PCB_toggle 	= [	"1st_PCB occurs", "2nd_PCB occurs", "1st_BPC.BE", "2nd_BPC.BE"]
		checkpointNum = 1413
		Label = type_C2B1 + " - Host - PCB"
		HandleResult_C2B1Ins_PCB(dict_cond_check_PCB, list_cond_check_PCB, dict_VS_PCB_fixed, list_VS_PCB_toggle, checkpointNum, Label, index)
		
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		dict_VS_PCB_fixed 	= OrderedDict([			("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0')])
		list_VS_PCB_toggle 	= [	"1st_PCB occurs", "2nd_PCB occurs", "1st_BPC.BE", "2nd_BPC.BE"]
		checkpointNum = 1505
		Label = type_C2B1 + " - Guest - PCB"
		HandleResult_C2B1Ins_PCB(dict_cond_check_PCB, list_cond_check_PCB, dict_VS_PCB_fixed, list_VS_PCB_toggle, checkpointNum, Label, index)
	
if (Enable_test_LSAB):	
	for ins in dict_LSAB_size:
		index = dict_LSAB_size.keys().index(ins)
		dict_cond_check_LSAB = dict_LSAB_size[ins]
		
		#-----------------------------------------------
		#-------------- Convention mode ----------------
		#-----------------------------------------------	
		def pos(bitname):
			position = len(dict_CV_LSAB_size_fixed) + list_CV_LSAB_size_toggle.index(bitname)
			return position
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
		dict_CV_LSAB_size_fixed = OrderedDict([		("Debug Mode",		'0'),			
													("Virtual Mode",	'0'),
													("BPC.BE",			'1'),
													("Channel < 4",		'1')])		
		list_CV_LSAB_size_toggle = ["LSAB occurs", "BPC.RE", "BPC.WE", "BPC.TY = 0", "BPC.TY = 1", "BPC.TY = 2", "BPC.TY = 3", "BPC.TY = 4", "BPC.TY = 5"]
		listcheckpointNum = [167, 173, 1123, 1124]
		Label = ins + " - Conventional - LSAB: Access size variation + Cache"		
		HandleResult_AccessSizeVar_Cache_LSAB(dict_cond_check_LSAB, list_cond_check_LSAB, dict_CV_LSAB_size_fixed, list_CV_LSAB_size_toggle, listcheckpointNum, Label, index)

		
		#-----------------------------------------------
		#------------ Virtualization mode --------------
		#-----------------------------------------------	
		def pos(bitname):
			position = len(dict_VS_LSAB_size_fixed) + list_VS_LSAB_size_toggle.index(bitname)
			return position
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
		dict_VS_LSAB_size_fixed = OrderedDict([		("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1'),
													("BPC.BE",			'1'),
													("Channel < 4",		'1')])		
		list_VS_LSAB_size_toggle = ["LSAB occurs", "BPC.RE", "BPC.WE", "BPC.TY = 0", "BPC.TY = 1", "BPC.TY = 2", "BPC.TY = 3", "BPC.TY = 4", "BPC.TY = 5"]
		listcheckpointNum = [1597, 1603, 3533, 3534]
		Label = ins + " - Host - LSAB: Access size variation + Cache"	
		HandleResult_AccessSizeVar_Cache_LSAB(dict_cond_check_LSAB, list_cond_check_LSAB, dict_VS_LSAB_size_fixed, list_VS_LSAB_size_toggle, listcheckpointNum, Label, index)
		
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
		dict_VS_LSAB_size_fixed = OrderedDict([		("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0'),
													("BPC.BE",			'1'),
													("Channel < 4",		'1')])		
		list_VS_LSAB_size_toggle = ["LSAB occurs", "BPC.RE", "BPC.WE", "BPC.TY = 0", "BPC.TY = 1", "BPC.TY = 2", "BPC.TY = 3", "BPC.TY = 4", "BPC.TY = 5"]
		listcheckpointNum = [2569, 2575, 3537, 3538]
		Label = ins + " - Guest - LSAB: Access size variation + Cache"		
		HandleResult_AccessSizeVar_Cache_LSAB(dict_cond_check_LSAB, list_cond_check_LSAB, dict_VS_LSAB_size_fixed, list_VS_LSAB_size_toggle, listcheckpointNum, Label, index)
				
	
	tuple_store = tuple_Store_byte + tuple_Store_hword + tuple_Store_word + tuple_Store_dword + tuple_Store_qword
	for ins in dict_LSAB_size:
		if ins in tuple_store:
			dict_cond_check_LSAB = dict_LSAB_size[ins]
			
			#-----------------------------------------------
			#-------------- Convention mode ----------------
			#-----------------------------------------------	
			def pos(bitname):
				position = len(dict_CV_LSAB_storeROM_fixed) + list_CV_LSAB_storeROM_toggle.index(bitname)
				return position
			
			#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
			dict_CV_LSAB_storeROM_fixed = OrderedDict([		("Debug Mode",		'0'),			
															("Virtual Mode",	'0'),
															("BPC.WE",			'1'),
															("ST->ROM",			'1'),
															("BPC.TY = 0",		'1'),
															("Channel < 4",		'1')])		
			list_CV_LSAB_storeROM_toggle = ["LSAB occurs", "BPC.RE", "BPC.BE"]
			checkpointNum = 1119
			Label = ins + " - Conventional - LSAB: Store to ROM area"
			HandleResult_StoreToROM_LSAB(dict_cond_check_LSAB, list_cond_check_LSAB, dict_CV_LSAB_storeROM_fixed, list_CV_LSAB_storeROM_toggle, checkpointNum, Label)
			
			
			#-----------------------------------------------
			#------------ Virtualization mode --------------
			#-----------------------------------------------	
			def pos(bitname):
				position = len(dict_VS_LSAB_storeROM_fixed) + list_VS_LSAB_storeROM_toggle.index(bitname)
				return position
			
			#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
			dict_VS_LSAB_storeROM_fixed = OrderedDict([		("Debug Mode",		'0'),			
															("Virtual Mode",	'1'),
															("Host Mode",		'1'),
															("BPC.WE",			'1'),
															("ST->ROM",			'1'),
															("BPC.TY = 0",		'1'),
															("Channel < 4",		'1')])		
			list_VS_LSAB_storeROM_toggle = ["LSAB occurs", "BPC.RE", "BPC.BE"]
			checkpointNum = 3525
			Label = ins + " - Host - LSAB: Store to ROM area"
			HandleResult_StoreToROM_LSAB(dict_cond_check_LSAB, list_cond_check_LSAB, dict_VS_LSAB_storeROM_fixed, list_VS_LSAB_storeROM_toggle, checkpointNum, Label)
			
			
			#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
			dict_VS_LSAB_storeROM_fixed = OrderedDict([		("Debug Mode",		'0'),			
															("Virtual Mode",	'1'),
															("Host Mode",		'0'),
															("BPC.WE",			'1'),
															("ST->ROM",			'1'),
															("BPC.TY = 0",		'1'),
															("Channel < 4",		'1')])		
			list_VS_LSAB_storeROM_toggle = ["LSAB occurs", "BPC.RE", "BPC.BE"]
			checkpointNum = 3529
			Label = ins + " - Guest - LSAB: Store to ROM area"
			HandleResult_StoreToROM_LSAB(dict_cond_check_LSAB, list_cond_check_LSAB, dict_VS_LSAB_storeROM_fixed, list_VS_LSAB_storeROM_toggle, checkpointNum, Label)		
	
if (Enable_test_Others):
	for ins, result_Others in dict_Others.items():
		index = dict_Others.keys().index(ins)
		dict_cond_check_Others = dict_Others[ins]
		
		#-----------------------------------------------
		#-------------- Convention mode ----------------
		#-----------------------------------------------	
		def pos(bitname):
			position = len(dict_CV_Others_AE_fixed) + list_CV_Others_AE_toggle.index(bitname)
			return position
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		dict_CV_Others_AE_fixed = OrderedDict([		("Debug Mode",		'0'),			
													("Virtual Mode",	'0')])		
		list_CV_Others_AE_toggle = ["AE occurs", "SV mode", "4n + 1", "4n + 2", "4n + 3"]
		listcheckpointNum = [1128, 1146]
		Label = ins + " - Conventional - Others: AE"
		HandleResult_AEinPrivilege_AE(dict_cond_check_Others, list_cond_check_Others, dict_CV_Others_AE_fixed, list_CV_Others_AE_toggle, listcheckpointNum, Label, index)
		
		#-----------------------------------------------
		#------------ Virtualization mode --------------
		#-----------------------------------------------	
		def pos(bitname):
			position = len(dict_VS_Others_AE_fixed) + list_VS_Others_AE_toggle.index(bitname)
			return position
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		dict_VS_Others_AE_fixed = OrderedDict([		("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'1')])		
		list_VS_Others_AE_toggle = ["AE occurs", "SV mode", "4n + 1", "4n + 2", "4n + 3"]
		listcheckpointNum = [3542, 3566]
		Label = ins + " - Host - Others: AE"
		HandleResult_AEinPrivilege_AE(dict_cond_check_Others, list_cond_check_Others, dict_VS_Others_AE_fixed, list_VS_Others_AE_toggle, listcheckpointNum, Label, index)
		
		
		#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		dict_VS_Others_AE_fixed = OrderedDict([		("Debug Mode",		'0'),			
													("Virtual Mode",	'1'),
													("Host Mode",		'0')])		
		list_VS_Others_AE_toggle = ["AE occurs", "SV mode", "4n + 1", "4n + 2", "4n + 3"]
		listcheckpointNum = [3578, 3596]
		Label = ins + " - Guest - Others: AE"
		HandleResult_AEinPrivilege_AE(dict_cond_check_Others, list_cond_check_Others, dict_VS_Others_AE_fixed, list_VS_Others_AE_toggle, listcheckpointNum, Label, index)		
	

##Limit: IMPORTANT: Not check LSAB Host <-> Guest: 1403 - 1412 
###Limit: Not check checkpoint 1115 -> 1118	
###Limit: Not check checkpoint 1127, 1158 -> 1164	
for i in range (1, len(list_case)):
	Print_result(OutputFileControl, list_case, i)
					
OutputFileControl.close()

#Backup data to a new file between script-executions
with open(AccumulationFile, 'wb') as file_bk:
	pickle.dump(list_case, file_bk)

print "End Time: ", datetime.datetime.now()
print "Total Time Consume: ", (datetime.datetime.now() - start_time)