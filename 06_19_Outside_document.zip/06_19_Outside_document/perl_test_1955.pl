#!/usr/bin/perl -w

# Code: HW 1955
# Generation: 25
# Name: Nguyen Minh Tri


print "\nxxxxxxxxxxxxxxx\n";

my $f_out = "./output.txt";
open (FILE_OUT, ">$f_out") || die ("xxx cannot open $f_out xxx");

my $file_index = 0;
my $flag = 0;
my $cnt_err = 0;

$file = $ARGV[0];

$file_array[$file_index] = $file;
$file_index ++;


while ($line = <>) {
my @tmp_arr1 =  ""; 
my @tmp_arr2 =  ""; 
my $var_2 = 0;
my $var_3 = 0;
my $var_4 = 0;
  chomp ($line);
  if ($flag == 1) {
    $flag = 0;
    @tmp_arr2 = split(/ +/,$line);
    $var_3 = $tmp_arr2[3];
    $var_4 = $tmp_arr2[5];
    print FILE_OUT ("$var_3 $var_4\n");
    
  }
  if ($line =~ /\<Memory Protection Error \(Suppressed\)/ && $flag == 0) {
    $flag = 1;
    $cnt_err++;
    @tmp_arr1 = split(/ +/,$line);
    $var_2 = $tmp_arr1[5];
    $var_2 =~ s/\>$//; 
    print FILE_OUT ("$var_2 ");
  }
  if (eof) {
    $file = $ARGV[0];
    $file_array[$file_index] = $file;
    $err_array[$file_index-1] = $cnt_err;
    $file_index ++;
    $cnt_err = 0;
  }
}

for ($index=0; $index < ($file_index-1); $index++) {
  print FILE_OUT ("$file_array[$index]: $err_array[$index]\n");
}

close (FILE_OUT);

print "\nxxxxxxxxxxxxxxx\n";


