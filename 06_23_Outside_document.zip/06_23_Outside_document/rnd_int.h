#ifndef RANDOMINT_H_
#define RANDOMINT_H_

#include "rtg_common.h"
#include "rnd_gen.h"

/**
 *  @brief  重みに従ったランダムな符号無し整数を扱うテンプレートクラス。<BR>
 *          任意の値、範囲に対して重みを設定できる。<BR><BR>
 * 
 * 　　　　　<B>I.階層選択と非階層選択</B><BR>
 *          このクラスは登録された重みに対して非階層な選択方式で値を得る。<BR>
 *          非階層選択と階層選択について次のような重み設定を考えてみる。<BR>
 *　　          Range1 = {0 - 9}, 重み = 1<BR>
 *    　　      Range2 = {10-11}, 重み = 1<BR>
 * 
 * 	         (1) 非階層な選択<BR>
 *              {0 - 11}が等しい比率で取得される。<BR>
 *              全ての要素の重みが等しく１であり、それぞれ8.3%の出現率となる。<BR>
 *           (2) 階層選択<BR>
 *              {0 - 9}と{10-11}が1:1の等しい比率で取得され、<BR>
 *              {0 - 9}の中から(または{10-11}の中から)均等に選択される。<BR>
 *              {0 - 9}の出現率は5%, {10-11}の出現率は25%となる。<BR>
 * 
 * 　　　　　<B>II.重複範囲の登録</B><BR>
 * 			重みに対する要素が部分的に重複する登録も許可される。<BR>
 * 		　　{0 - 3}が重み１、{2 - 5}が重み２で登録された場合、<BR>
 *  		GetValueにより得られる整数比率は下記のようになる。<BR>
 *        　　  Range1 =   {0 - 1}, 重み = 1 → 約  8.3%<BR>
 *        　　  Range1 =   {2 - 3}, 重み = 3 → 約 24.9% <BR>
 *        　　  Range1 =   {4 - 5}, 重み = 2 → 約 16.7%
 * 
 */
template <typename TYPE_T>
class CRandomInt
{
public:
	typedef	CRandomInt <TYPE_T>			this_type;

	/**
	 * @brief  このオブジェクトを生成します。
	 */
	CRandomInt() : m_pMT(&g_mt), m_Wr(&g_mt){}
	
	/**
	 * @brief  このオブジェクトを生成します。
	 * @param  pRnd 一様乱数発生源
	 */
	CRandomInt(IRandom* pRnd) : m_pMT(pRnd), m_Wr(pRnd){}

	/**
	 * @brief  このオブジェクトを破棄します。
	 */	
	virtual ~CRandomInt(){}

	/**
	 * @brief  数値範囲に対して重みを設定します。
	 * @param  min 登録範囲の最小値
	 * @param  max 登録範囲の最大値
	 * @param  wv  登録範囲の重み値
	 * @return 真の場合、再計算（ReCalc）する必要があります。
	 */	
	virtual bool AddRange(TYPE_T min, TYPE_T max, UI32 wv) {
		_ASSERT (min < max);
		_ASSERT (wv != 0);
		return m_Wr.Set(typename std::pair<TYPE_T, TYPE_T>(min, max), wv * (max - min + 1));
	}

	/**
	 * @brief  数値に対して重みを設定します。
	 * @param  val 数値
	 * @param  wv  数値の重み値
	 * @return 真の場合、再計算（ReCalc）する必要があります。
	 */	
	virtual bool AddValue(TYPE_T val, UI32 wv) {
		_ASSERT (wv != 0);
		return m_Wr.Set(typename std::pair<TYPE_T, TYPE_T>(val, val), wv);
	}
	
	/**
	 * @brief  重みに従った値を取得します。
	 * @return ランダム値。
	 */	
	virtual TYPE_T GetValue(void) {
		typename std::pair<TYPE_T,TYPE_T> vr = m_Wr.GetObj();
		if (vr.first == vr.second) {
			return vr.first;
		}else{
			return m_pMT->GetRange((TYPE_T)vr.first,(TYPE_T)vr.second);
		}
	}

	/**
	 * @brief  重みテーブルの再計算を指示します。
	 */	
	virtual void ReCalc(void) {
		m_Wr.ReCalc();
	}
	
protected:
	IRandom*						m_pMT;	//!<　@brief 一様乱数の発生源
	CWeightedRandom	<
		typename
		std::pair<TYPE_T,TYPE_T>
	 >								m_Wr;	//!<　@brief 数値に対する重み
};
#endif /*RANDOMINT_H_*/
