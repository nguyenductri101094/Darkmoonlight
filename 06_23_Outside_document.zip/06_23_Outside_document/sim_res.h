#ifndef SIM_RES_H_
#define SIM_RES_H_

#include "rtg_common.h"

class CSimResource {
public:
	GRLST			m_gr;
	VRLST			m_vr;
	SRSET			m_nc; 
	SRLST			m_vc; 
	SRLST			m_tc; 
	std::vector<T_MEMWRRECORD> m_logs;
	
	friend std::ostream& operator<< (std::ostream& os, const CSimResource& r) {
		for (UI32 t = 0; t < r.m_gr.size(); t++) {
			const GRSET& gs = r.m_gr[t];
			for (UI32 r = 0; r < 32; r++) {
				os << "HT" /* << std::setw(2) << std::setfill('0') */ << std::dec << t; 
				os << "#r" << std::setw(2) << std::setfill('0') << r << " = ";
				os << "0x"  << std::setw(8) << std::setfill('0') << std::hex << gs[r] << std::endl;
			}
		}
		const SRSET& ns = r.m_nc;
		for (UI32 n = 0; n < ns.size(); n++) {
			UI32 selid = ns[n].first >> 5;
			UI32 regid = ns[n].first & 31;
			UI32 value = ns[n].second;
				os << "NC#sr(" << std::dec << selid << ", " << regid << ") = ";
				os << "0x"  << std::setw(8) << std::setfill('0') << std::hex << value << std::endl;
		}
		
		for (UI32 v = 0; v < r.m_vc.size(); v++) {
			const SRSET& vs = r.m_vc[v];
			for (UI32 n = 0; n < vs.size(); n++) {
				UI32 selid = vs[n].first >> 5;
				UI32 regid = vs[n].first & 31;
				UI32 value = vs[n].second;
					os << "VC" << std::dec << v << "#sr(" << std::dec << selid << ", " << regid << ") = ";
					os << "0x"  << std::setw(8) << std::setfill('0') << std::hex << value << std::endl;
			}
		}
		
		for (UI32 t = 0; t < r.m_tc.size(); t++) {
			const SRSET& ts = r.m_tc[t];
			for (UI32 n = 0; n < ts.size(); n++) {
				UI32 selid = ts[n].first >> 5;
				UI32 regid = ts[n].first & 31;
				UI32 value = ts[n].second;
					os << "TC" << std::dec << t << "#sr(" << std::dec << selid << ", " << regid << ") = ";
					os << "0x"  << std::setw(8) << std::setfill('0') << std::hex << value << std::endl;
			}
		}
		
		return os;
	}
};

#endif /*SIM_RES_*/
