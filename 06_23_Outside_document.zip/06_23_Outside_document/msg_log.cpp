#include "msg_log.h"

namespace RTG_TOOL {

CLogMessage gMSG;

void CLogMessage::Warn (UI32 level, const char* fmt, ...) {
	std::string s;

	if (m_bConWarn || m_bLogWarn) {
		char buff[1024];

		va_list argp;
		va_start(argp, fmt);
		vsprintf(buff, fmt, argp);
		va_end(argp);
		s = buff;
	}
	if (m_bConWarn) {
		if (m_ostream) {
			(*m_ostream) << "Warn : " << s;
		}
	}
	if (m_bLogWarn) {
		m_lvlQ.push_back(level);
		m_msgQ.push_back("Warn : " + s);
	}
}

void CLogMessage::Error(UI32 level, const char* fmt, ...) {
	std::string s;

	if (m_bConError || m_bLogError) {
		char buff[1024];
		va_list argp;
		va_start(argp, fmt);
		vsprintf(buff, fmt, argp);
		va_end(argp);
		s = buff;
	}
	if (m_bConError) {
		if (m_ostream) {
			(*m_ostream) << COUT_RED << "Error : " << s << COUT_RESET << std::flush;
		}
	}
	if (m_bLogError) {
		m_lvlQ.push_back(level);
		m_msgQ.push_back("Error : " + s);
	}
}

void CLogMessage::Info(UI32 level, const char* fmt, ...) {

	std::string s;

	if (m_bConInfo || m_bLogInfo) {
		char buff[1024];
		va_list argp;
		va_start(argp, fmt);
		vsprintf(buff, fmt, argp);
		va_end(argp);
		s = buff;
	}
	if (m_bConInfo) {
		if (m_ostream) {
			(*m_ostream) << "Info : " << s;
		}
	}
	if (m_bLogInfo) {
		m_lvlQ.push_back(level);
		m_msgQ.push_back("Info : " + s);
	}
	if (m_ostream) {
		m_ostream->flush();
	}
}

std::string CLogMessage::Get (UI32 i) {

	if (m_msgQ.size() < (i+1)) {
		return "";
	}
	return m_msgQ.at(i);
}

void CLogMessage::SetConsole (std::ostream* console) {
	m_ostream = console;
}

} // namespace RTG_TOOL
