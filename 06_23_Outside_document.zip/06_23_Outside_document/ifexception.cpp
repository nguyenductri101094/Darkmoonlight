#include	"ifexception.h"
#include	"exception.h"

IException* IException::New() {

	return (new CException())->Setup();

}
