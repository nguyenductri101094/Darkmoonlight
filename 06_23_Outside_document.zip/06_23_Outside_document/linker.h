#ifndef LINKER_H_
#define LINKER_H_

#include	"rtg_common.h"
#include	"rnd_gen.h"
#include	"codeblock.h"
/**
 *	@brief  メモリの使用領域を管理するクラス。
 */
class CLinker
{
public:
	typedef enum {
		MEM_FREE_ALLOC,
		MEM_USER_ALLOC,
		MEM_ATT_NUM
	} MEM_ATTRIBUTE;

public:
	/**
	 *	@brief   このオブジェクトを生成します。
	 */
	CLinker();
	
	/**
	 *	@brief   このオブジェクトを破棄します。
	 */
	virtual ~CLinker(){}
	
	/**
	 *	@brief   アロケート情報をクリアします。予約アドレス空間はクリアされません。
	 */
	void Reload(void);

	/**
	 *	@brief   アロケート情報を追加します。
	 *	@param   start  確保する開始アドレスを指定します。 
	 *	@param   end    確保する終端アドレスを指定します。。
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool AllocAddress(MEMADDR start, MEMADDR end, MEM_ATTRIBUTE att);

	/**
	 *	@brief   アロケート情報を追加します。
	 *	@param   adr  確保する開始アドレスを指定します。 
	 *	@param   len  確保するデータサイズ（byte）を指定します。 
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool Alloc(MEMADDR start, MEMADDR len, MEM_ATTRIBUTE att) {
		return AllocAddress (start, start + len - 1/* = end address */, att);
	}

	/**
	 *	@brief   指定サイズで自動アロケートします。
	 *	@param   adr  アロケータされた結果（アドレス）が格納されます。 
	 *	@param   len  確保するデータサイズ（byte）を指定します。 
	 *	@param   rng  検索範囲を指定します。
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool AllocSearch(CCodeBlock * pcb, MEMADDR* adr, MEMADDR len, MEMRANGE rng, MEMADDR align, MEM_ATTRIBUTE att = MEM_FREE_ALLOC);

	bool CheckAllocatedSize(MEMADDR start, UI32 len);

	/**
	 *	@brief   Update available memory areas 
	 *	@param	 MEMRANGE mr Allocated memory range。 
	 *	@return  None。
	 */
	void UpdateAvailableMemory(MEMRANGE mr);

	/**
	 *	@brief   Get available memory map. 
	 *	@param	 。 
	 *	@return  。
	 */
	MEMRANGE GetRandomLocation (MEM_ATTRIBUTE att);

	/**
	 *	@brief   指定アドレスのエントリを削除します。
	 *	@param   adr  一致した場合のみ削除します 
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool Remove(MEMADDR adr);

	/**
	 *	@brief   予約領域(検証に使えない)を追加します。
	 *           検証に使う予約（割り当て）はAllocateを使用してください。
	 *	@param   range  一致した場合のみ削除します(start, end)。 
	 *	@return  成功した場合は真、失敗した場合は偽を返します。
	 */
	bool Reserve(const MEMRANGE& range, MEM_ATTRIBUTE att) {
		Memory *pMem = new Memory(range, att);
		if(m_rsv.insert(std::make_pair(range.first, pMem)).second) {
			return true;
		}
		delete pMem;
		return false;
	}
	
	/**
	 *	@brief   指定したアドレスとサイズで競合を検証します。
	 *	@param   adr  検証するアドレスを指定します。 
	 *	@param   len  検証するデータサイズ（byte）を指定します。 
	 *	@return  利用可能である場合は真、競合している場合は偽を返します。 
	 */
	bool IsAvailable(MEMADDR start, MEMADDR end, MEM_ATTRIBUTE att);

	/**
	 *	@brief   アロケート情報を標準出力へ表示します（デバッグ用）。
	 */
	void Debug();
	
protected:
	// Declear inner class
	class Memory {
	public:
		Memory(MEMRANGE mr, MEM_ATTRIBUTE att) : m_mr(mr), m_att(att) {}
		MEMRANGE m_mr;
		MEM_ATTRIBUTE m_att;
	};
	std::map<MEMADDR, Memory*>	m_hash;	//!<	@brief アロケーションテーブル<アドレス, サイズ>
	std::map<MEMADDR, Memory*>	m_vacancy;
	std::map<MEMADDR, Memory*>	m_rsv;	//!<	@brief 予約領域(アロケートによる結果でなく最初から使用できない領域)
};
extern CAddressWeight g_FetchAddr;
#endif /*LINKER_H_*/

