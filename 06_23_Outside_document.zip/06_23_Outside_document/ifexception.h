#ifndef IFEXCEPTION_H_
#define IFEXCEPTION_H_

#include	"weight_parser.h"
#include	"rnd_gen.h"
#include	"rtg_cfg.h"

#define Code_FPI         0x0072
#define Code_Ch_BPC_BPNM 0x3000
#define Code_Ch_BPC_VSEL 0x3100
#define Code_Ch_BPC_VE   0x3200
#define Code_Ch_BPC_TY   0x3300
#define Code_Ch_BPC_VD   0x3400
#define Code_Ch_BPC_VA   0x3500
#define Code_Ch_BPC_MD   0x3600
#define Code_Ch_BPC_BR   0x3700
#define Code_Ch_BPC_TE   0x3800
#define Code_Ch_BPC_BE   0x3900
#define Code_Ch_BPC_FE   0x3A00
#define Code_Ch_BPC_WE   0x3B00
#define Code_Ch_BPC_RE   0x3C00
#define Code_Ch_BPAM     0x3D00
#define Code_Ch_BPDM     0x3E00
#define Code_Ch_DIR1_SQ  0x5000
#define Code_Ch_DIR1_SQ0 0x5100
#define Code_Ch_DIR1_SQ1 0x5200

#define Code_Ch_NumOfChannels 0x4000
#define	Code_DUMMY		 0xFFFF

/**
 * @brief 例外情報を管理するクラスです。
 *        例外のコード、例外の名前、発生確率を制御します。
 */
class IExceptionConfig
{
public:

	typedef enum {
		EXP_LEVEL_NONE,
		EXP_LEVEL_FE,
		EXP_LEVEL_EI,
		EXP_LEVEL_DB,
		EXP_LEVEL_NUM
	}  EXP_LEVEL;

	IExceptionConfig() : m_id(0), m_name(), m_type(0), m_lcode(0), m_ucode(0), m_addr(0), m_weight(0), m_count(0), m_force(false), 
		m_count_random(0), m_lchannel(0), m_uchannel(0), m_bIsInterrupt(false),m_bankNum(0) {}
	virtual ~IExceptionConfig(){}
	
	UI32		m_id;
	std::string m_name;
    UI32        m_type;
	UI32		m_lcode;
	UI32		m_ucode;
	UI32		m_addr;
	UI32		m_weight;
	UI32		m_count;
	bool		m_force;
	UI32		m_count_random;
	UI32		m_lchannel;
	UI32		m_uchannel;
	bool		m_bIsInterrupt;
	UI32		m_level;
	//!< For interrupt with regiter bank.
	UI32		m_bankNum;
	
	virtual void Dump(std::ostream& os = std::cout) {
		os << std::hex << std::setw(4) << std::setfill('0') << m_lcode << ' ';
		os << "- ";
		os << std::hex << std::setw(4) << std::setfill('0') << m_ucode << ' ';
		os << std::setw(15) << std::setfill(' ') << m_name << ' ';
		os << std::hex << std::setw(4) << std::setfill('0') << m_addr << ' ';
		os << std::dec << std::setw(4) << std::setfill(' ') << m_weight << "%" << std::endl;
	}
	
	virtual void Print(std::ostream& os = std::cout) {
		MSG_INFO(0, "     - %-8s = %4d times\n", m_name.data(), m_count);
	}
};


/**
 * @brief 例外情報を管理するクラスです。
 *        例外のコード、例外の名前、発生確率を制御します。
 */
class IException
{
public:
	/**
	 * @brief このオブジェクトを生成します。
	 */
	IException(): m_mapExcep(), m_BreakPointWeightSum(0), m_iNumOfChannels(4), m_vBpcVsel(8,50), m_iBpcVselSum(400), m_vBpcTy(5,50), m_iBpcTySum(250), m_vBpam(32,50), m_vBpdm(32,50), m_bSequentialMode(false) {}
	
	typedef enum {
		EXP_NONE = 0, EXP_RESET, EXP_SYSERR, EXP_DBNMI, EXP_DBINT, EXP_RMINT, EXP_FENMI, EXP_FEINT, EXP_FPI,
		EXP_EIINT, EXP_VMRESTART, EXP_MIP, EXP_ITLBE, EXP_RIE, EXP_UCPOP0, EXP_UCPOP1, EXP_UCPOP2,
		EXP_PIE, EXP_MAE, EXP_MDP, EXP_MDP_INT, EXP_MIP_HM, EXP_MDP_HM, EXP_MDP_INT_HM, EXP_DTLBE, EXP_FPP, EXP_FXE, EXP_DBTRAP, EXP_RMTRAP, EXP_DBHVTRAP, EXP_HVTRAP, EXP_HVCALL, EXP_SYSCALL,
		EXP_FETRAP, EXP_TRAP0, EXP_TRAP1, EXP_EITBL, EXP_RBINT,
		/* Break point */
		EXP_BREAK_NONE, EXP_RMWB, EXP_LDB, EXP_RLB, EXP_PCB, EXP_LSAB, EXP_SDB, EXP_AE, EXP_SS, EXP_SEQ,
		/* Break point register */
		EXP_BPC_BPNM, EXP_BPC_VSEL, EXP_BPC_VE, EXP_BPC_TY, EXP_BPC_VD, EXP_BPC_VA, EXP_BPC_MD, EXP_BPC_BR, EXP_BPC_TE, EXP_BPC_BE, EXP_BPC_FE, EXP_BPC_WE,
		EXP_BPC_RE, EXP_BPAM, EXP_BPDM, EXP_DIR1_SQ0, EXP_DIR1_SQ1, EXP_BREAK_CHANNEL, 
		EXP_NUM
	}  EXP_ID;
	
	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~IException() {
		/* ! Not work polymorphism here */
		Clear();
	}
	

	/**
	 * @brief セットアップが必要な場合、このインターフェースを実装します。
	 */
	virtual IException* Setup(){ return this; }
	
	
	/**
	 * @brief	Get Exception id by name
	 * @param	exception name
	 * @return	exception id
	 */
	virtual UI32 GetKey(std::string name) {
		std::map <UI32,IExceptionConfig*>::iterator itr;
		for(itr = m_mapExcep.begin(); itr != m_mapExcep.end(); itr++) {
			std::string exp = itr->second->m_name;
			std::transform(exp.begin(), exp.end(), exp.begin(), [] (int ch) {return std::tolower(ch);});
			if(exp == name) {
				return itr->second->m_id;
			}
		}
		return 0;
	}

	/**
	 * @brief	指定された例外要因コードに対応する文字列を返します。
	 * @param	code 例外要因コード値
	 * @return	例外名文字列
	 */
	virtual UI32 GetWeight(UI32 key) {
		IExceptionConfig* pCfg = GetConfig(key);
		if (pCfg == NULL) {
			std::runtime_error excep("Exception entry none!");
			throw excep;
		}
		return pCfg->m_weight;
	}
	
	/**
	 * @brief	指定された例外要因コードに対応する文字列を返します。
	 * @param	code 例外要因コード値
	 * @return	例外名文字列
	 */
	virtual IExceptionConfig* GetConfig(UI32 key) {
		std::map<UI32,IExceptionConfig*>::iterator itr;
		itr = m_mapExcep.find(key);
		if (itr == m_mapExcep.end()) {
			return NULL;
		}
		return m_mapExcep[key];
	}	
	
	/**
	 * @brief	例外情報を登録します。
	 * @param	param 例外情報
	 * @return	真の場合、上書きが発生した。
	 */
	virtual bool SetConfig(IExceptionConfig* param) {
		_ASSERT(param);
		
		IExceptionConfig* pCfg = new IExceptionConfig(); // copy-constructor相当
		*pCfg = *param;
		
		std::pair<std::map<UI32,IExceptionConfig*>::iterator, bool> result;
		std::pair<UI32,IExceptionConfig*> kvPair(pCfg->m_id, pCfg);
		
		result = m_mapExcep.insert (kvPair);
		if (result.second != true) {
			delete result.first->second;
			m_mapExcep.erase(result.first);
			result = m_mapExcep.insert(kvPair);
			_ASSERT(result.second);
			return true;
		}
		return false;
	}

	/**
	 * @brief	例外情報をクリアします
	 */
	virtual void Clear() {
		std::map <UI32,IExceptionConfig*>::iterator i;
		for (i = m_mapExcep.begin(); i != m_mapExcep.end(); i++) {
			delete i->second;
		}
		m_mapExcep.clear();
	}

	/**
	 * @brief	設定された確率から例外の発生を許可するかどうかを決定します。
	 * @param	code 例外要因コード値
	 * @return	許可する場合、真を返します。
	 */
	virtual bool RaiseException(UI32 key) {
		UI32 w = GetWeight(key);
		UI32 p = g_rnd.GetRange(1,100);
		return (w >= p);
	}
	
	/**
	 * @brief	設定された確率から例外の発生を許可するかどうかを決定します。
	 * @param	code 例外要因コード値
	 * @return	許可する場合、真を返します。
	 */
	virtual bool AccesptException(UI32 key) {
		IExceptionConfig* pCfg = GetConfig(key);
		if (pCfg == NULL) {
			std::runtime_error excep("Exception entry none!");
			throw excep;
		}
		if (pCfg->m_force) {
			return true; // 強制例外なら受け付ける
		}
		UI32 w = pCfg->m_weight;
		UI32 p = g_rnd.GetRange(1,100);
		return (w >= p);
	}

	/**
	 * @brief	設定された確率から例外の発生を許可するかどうかを決定します。
	 * @param	code 例外要因コード値
	 * @return	許可する場合、真を返します。
	 */
	virtual void CountUp(UI32 key) {
		IExceptionConfig* pCfg = GetConfig(key);
		if (pCfg != NULL) {
			pCfg->m_count++;
		}
	}

	/**
	 * @brief	例外発生をカウントします。（命令生成カバレッジ計測用）
	 * @param	code 例外要因コード値
	 */
	virtual void CountUpRandom(UI32 key) {
		IExceptionConfig* pCfg = GetConfig(key);
		if (pCfg != NULL) {
			pCfg->m_count_random++;
		}
	}

	/**
	 * @brief	デバッグ用 登録されいている例外情報を指定ストリームに出力します。
	 * @param	os ストリーム
	 * @return	許可する場合、真を返します。
	 */
	virtual void Dump(std::ostream& os = std::cout) {
		std::map <UI32,IExceptionConfig*>::iterator i;
		
		os << std::setw(11) << std::setfill(' ') << "LCode-UCode" << ' ';
		os << std::setw(15) << std::setfill(' ') << "Name" << ' ';
		os << std::setw(4) << std::setfill(' ') << "Addr" << ' ';
		os << std::setw(4) << std::setfill(' ') << "Weight" << ' ' << std::endl;
		os << "----------- --------------- ---- -----" << std::endl;
		for (i = m_mapExcep.begin(); i != m_mapExcep.end(); i++) {
			i->second->Dump(os);
		}
	}


	/**
	 * @brief	レポート用 登録されいている例外情報を指定ストリームに出力します。
	 * @param	os ストリーム
	 * @return	許可する場合、真を返します。
	 */
	virtual void Print(std::ostream& os = std::cout) {
		std::map <UI32,IExceptionConfig*>::iterator i;
		for (i = m_mapExcep.begin(); i != m_mapExcep.end(); i++) {
			if (i->second->m_lcode && i->second->m_count) {
				i->second->Print(os);
			}
		}
	}
		

	/**
	 * @brief	生成コード統計データ用に、登録されいている例外情報を渡します。
	 * @param	例外情報
	 */
	virtual std::map< UI32,IExceptionConfig*>& GetException(void) {
        return ( m_mapExcep ) ;
    }
		

	/**
	 * @brief	指定された例外名文字列に対応する例外発生確率を返します。
	 * @param	name   例外名
	 * @param	weight 例外発生確率 (0 to 100)
	 * @param	lchannel Exception lower channel.
	 * @param	uchannel Exception upper channel.
	 * @param	bankNum	 Interrupt bank number.
	 */
	virtual void Set(std::string name , UI32 weight, UI32 lchannel, UI32 uchannel, UI32 bankNum) {
		static std::vector<std::pair<std::string, UI32>> vExpKeys = {{"Exp_SYSERR", EXP_SYSERR}, {"Exp_HVTRAP", EXP_HVTRAP},
			{"Exp_FETRAP", EXP_FETRAP}, {"Exp_TRAP0", EXP_TRAP0}, {"Exp_TRAP1", EXP_TRAP1}, {"Exp_RIE", EXP_RIE}, {"Exp_FPP", EXP_FPP},
			{"Exp_FPI", EXP_FPI}, {"Exp_UCPOP(0)", EXP_UCPOP0}, {"Exp_UCPOP(1)", EXP_UCPOP1}, {"Exp_UCPOP(2)", EXP_UCPOP2},
			{"Exp_MIP", EXP_MIP}, {"Exp_MDP", EXP_MDP}, {"Exp_ITLBE", EXP_ITLBE}, {"Exp_DTLBE", EXP_DTLBE}, {"Exp_PIE", EXP_PIE},
			{"Exp_SS", EXP_SS}, {"Exp_DBTRAP", EXP_DBTRAP}, {"Exp_RMTRAP", EXP_RMTRAP}, {"Exp_DBHVTRAP", EXP_DBHVTRAP},
			{"Exp_RLB", EXP_RLB}, {"Exp_RMINT", EXP_RMINT}, {"Exp_DBINT", EXP_DBINT}, {"Exp_DBNMI", EXP_DBNMI}, {"Exp_MAE", EXP_MAE},
			{"Exp_FENMI", EXP_FENMI}, {"Exp_FEINT", EXP_FEINT}, {"Exp_EIINT", EXP_EIINT}, {"Exp_EITBL", EXP_EITBL},
			{"Exp_RBINT", EXP_RBINT}, {"Exp_SYSCALL", EXP_SYSCALL}, {"Exp_HVCALL", EXP_HVCALL}, {"Break_NONE", EXP_BREAK_NONE},
			{"Break_PCB", EXP_PCB}, {"Break_LSAB", EXP_LSAB}, {"Break_LDB", EXP_LDB}, {"Break_SDB", EXP_SDB}, {"Break_RMWB", EXP_RMWB},
			{"Break_AE", EXP_AE}, {"Break_RLB", EXP_RLB}, {"Break_SS", EXP_SS}, {"Break_SEQ", EXP_SEQ}, {"Ch_BPC.BPNM", EXP_BPC_BPNM},
			{"Ch_BPC.VSEL", EXP_BPC_VSEL}, {"Ch_BPC.VE", EXP_BPC_VE}, {"Ch_BPC.TY", EXP_BPC_TY}, {"Ch_BPC.VD", EXP_BPC_VD},
			{"Ch_BPC.VA", EXP_BPC_VA}, {"Ch_BPC.MD", EXP_BPC_MD}, {"Ch_BPC.BR", EXP_BPC_BR}, {"Ch_BPC.TE", EXP_BPC_TE},
			{"Ch_BPC.BE", EXP_BPC_BE}, {"Ch_BPC.FE", EXP_BPC_FE}, {"Ch_BPC.WE", EXP_BPC_WE}, {"Ch_BPC.RE", EXP_BPC_RE},
			{"Ch_BPAM", EXP_BPAM}, {"Ch_BPDM", EXP_BPDM},{"Ch_DIR1.SQ0", EXP_DIR1_SQ0},{"Ch_DIR1.SQ1", EXP_DIR1_SQ1},
			{"Ch_NumOfChannels", EXP_BREAK_CHANNEL}};

		std::map <UI32,IExceptionConfig*>::iterator itr;
		std::vector<std::pair<std::string, UI32>>::iterator itrExpKey;
		IExceptionConfig* pExp = NULL;
		for(itrExpKey = vExpKeys.begin(); itrExpKey < vExpKeys.end(); itrExpKey++) {
			if(itrExpKey->first == name) {
				itr = m_mapExcep.find(itrExpKey->second);
				if(itr != m_mapExcep.end())
					pExp = itr->second;
				break;
			}
		}
		if(pExp == NULL) {
#if DBGMODE
			printf("Not support setting: %s", name.c_str());
#endif
			return;
		}

		if (pExp->m_id > EXP_RESET && pExp->m_id < EXP_BREAK_NONE) {
			// Parse config of exception/ interrupt
			if (pExp->m_bIsInterrupt == false && weight > 100) {
				return ; // ERROR
			}
            pExp->m_weight = weight ;
			pExp->m_lchannel = lchannel;
			pExp->m_uchannel = uchannel;
			pExp->m_bankNum = bankNum;
		} else if (pExp->m_id < EXP_BPC_BPNM) {
			// Parse config of break point

			if((pExp->m_id == EXP_SDB) || (pExp->m_id == EXP_LDB) || (pExp->m_id == EXP_SS)
				|| (pExp->m_id == EXP_RMWB) || (pExp->m_id == EXP_RLB))
				return;

			if (weight > 100) {
				return ; // ERROR
			}
			pExp->m_weight = weight ;
			m_BreakPointWeightSum += weight;
			if((pExp->m_id == EXP_SEQ) && (weight > 0)){
				m_bSequentialMode = true;
			}
#if DBGMODE
			printf("Break Weight %s = %d\n", (pExp->m_name).c_str(), pExp->m_weight);
#endif
        } else if (pExp->m_id >= EXP_BPC_BPNM) {
			pExp->m_weight = weight ;
			m_bChannelWeightFlag = true;
            if(pExp->m_id == EXP_BREAK_CHANNEL) {
                m_iNumOfChannels = weight;
            }
#if DBGMODE
			printf("Channel Weight %s = %d\n", (pExp->m_name).c_str(), pExp->m_weight);
#endif
		}
		return ;
	}

	/**
	 * @brief	指定された例外名文字列に対応する例外発生確率を返します。
	 * @param	WeightSet 例外発生確率 (0 to 100)
	 */
	virtual bool SetWeight(std::vector<std::vector<std::string>> sd) {
		std::vector<std::vector<std::string>>::iterator is;
		std::vector<std::string>::iterator ir;
		for (is = sd.begin(); is != sd.end(); is++) {
			if (is->size() == 2) {
                std::string val1 = is->at(0);
                std::string val2 = is->at(1);
                UI32 weight = CToolFnc::AtoI(val2.c_str());
                Set( val1 , weight, 0, 0, 0);  // 命令重みを設定,重み０も設定可能とする
			} else if(is->size() == 4) {
				std::string val1 = is->at(0);
				UI32 weight = CToolFnc::AtoI((is->at(1)).c_str());
				UI32 lchannel = CToolFnc::AtoI((is->at(2)).c_str());
				UI32 uchannel = CToolFnc::AtoI((is->at(3)).c_str());
				Set(val1, weight, lchannel, uchannel, 0);
			} else if(is->size() == 5) {
				std::string val1 = is->at(0);
				UI32 weight = CToolFnc::AtoI((is->at(1)).c_str());
				UI32 lchannel = CToolFnc::AtoI((is->at(2)).c_str());
				UI32 uchannel = CToolFnc::AtoI((is->at(3)).c_str());
				UI32 bankNum = CToolFnc::AtoI((is->at(4)).c_str());
				Set(val1, weight, lchannel, uchannel, bankNum);
			} else if(( is->size() == 9 ) && ( is->at(0) == "Ch_BPC.VSEL" )) {
                m_iBpcVselSum = 0;
                for( int i=0; i<8; i++ ) {
                    m_iBpcVselSum += m_vBpcVsel[i] = CToolFnc::AtoI( is->at(i+1).c_str());
#if DBGMODE
					printf("Channel Weight BPC.VSEL[%d] = %d\n", i, m_vBpcVsel[i]);
#endif
                }
#if DBGMODE
                printf("Channel Weight m_iBpcVselSum:%d\n", m_iBpcVselSum);
#endif
            } else if(( is->size() == 6 ) && ( is->at(0) == "Ch_BPC.TY" )) {
                m_iBpcTySum = 0;
                for( int i=0; i<5; i++ ) {
                    m_iBpcTySum += m_vBpcTy[i] = CToolFnc::AtoI( is->at(i+1).c_str());
#if DBGMODE
					printf("Channel Weight BPC.TY[%d] = %d\n", i, m_vBpcTy[i]);
#endif
                }
#if DBGMODE
                printf("Channel Weight m_iBpcVselSum:%d\n", m_iBpcTySum);
#endif
            } else if(( is->size() == 33 ) && ( is->at(0) == "Ch_BPAM" )) {
                for( int i=0; i<32; i++ ) {
                    m_vBpam[i] = CToolFnc::AtoI( is->at(32-i).c_str());
#if DBGMODE
					printf("Channel Weight BPAM[%d] = %d\n", i, m_vBpam[i]);
#endif
                }
            } else if(( is->size() == 33 ) && ( is->at(0) == "Ch_BPDM" )) {
                for( int i=0; i<32; i++ ) {
                    m_vBpdm[i] = CToolFnc::AtoI( is->at(32-i).c_str());
#if DBGMODE
					printf("Channel Weight BPDM[%d] = %d\n", i, m_vBpdm[i]);
#endif
                }
            } else {
				MSG_ERROR(0, "Format error in section ""EXCEPTION/BREAK"", %s size:(%d)\n", is->at(0).c_str(), is->size());
				return false;
			}
		}
		return true;
	}

    /**
     * @brief チャネル設定処理
     */
	void SetChannel(UI32* bpc, UI32* addr_mask, UI32* data_mask) {
    UI32 weight;
    UI32 val;
	*bpc = 0x0;
	*data_mask = 0x0;

	// BPC.TY
	val = GetBPC_TY();
	*bpc |= val << 10;

	// BPC.VA
	weight = GetWeight(EXP_BPC_VA);
    if(( weight != 0 ) && ( (UI32)g_rnd.GetRange(1,100) <= weight )) {
        *bpc |= 0x00000100; 
    }

    // BPC.TE
    weight = GetWeight(EXP_BPC_TE);
    if(( weight != 0 ) && ( (UI32)g_rnd.GetRange(1,100) <= weight )) {
        *bpc |= 0x00000010;  
    }
    // BPC.BE
    weight = GetWeight(EXP_BPC_BE);
    if(( weight != 0 ) && ( (UI32)g_rnd.GetRange(1,100) <= weight )) {
        *bpc |= 0x00000008;
    }
    // BPC.FE
    weight = GetWeight(EXP_BPC_FE);
    if(( weight != 0 ) && ( (UI32)g_rnd.GetRange(1,100) <= weight )) {
        *bpc |= 0x00000004; 
    }
    // BPC.WE
    weight = GetWeight(EXP_BPC_WE);
    if(( weight != 0 ) && ( (UI32)g_rnd.GetRange(1,100) <= weight )) {
        *bpc |= 0x00000002;
    }
    // BPC.RE
    weight = GetWeight(EXP_BPC_RE);
    if(( weight != 0 ) && ( (UI32)g_rnd.GetRange(1,100) <= weight )) {
        *bpc |= 0x00000001; 
    }
    // BPAM
    val = GetBPAM();
    *addr_mask = val;

#if DBGMODE
    fprintf(stdout,"==> SetChannel BPC:%08x BPAM:%08x BPDM:%08x\n",*bpc,*addr_mask,*data_mask);
#endif
}

    /**
     * @brief チャネル設定有無フラグ読み出し
     */
    virtual bool GetChannelWeightFlag() {
        return m_bChannelWeightFlag;
    }

    /**
     * @brief 重み考慮BPC.VSELの値取得
     * @return BPC.VSELの値 UI32(0-7)
     */
    virtual UI32 GetBPC_VSEL() {
        UI32 val = 0;
        UI32 rnd = g_rnd.GetRange((UI32)0,m_iBpcVselSum);
        UI32 wk_sum = 0;
        for( auto itr = m_vBpcVsel.begin(); itr != m_vBpcVsel.end(); ++itr ) {
            wk_sum += *itr;
            if( rnd <= wk_sum ) {
                break;
            }
            val++;
        }
        return val;
    }

    /**
     * @brief 重み考慮BPC.TYの値取得
     * @return BPC.TYの値 UI32(0-4)
     */
    virtual UI32 GetBPC_TY() {
        UI32 val = 0;
        UI32 rnd = g_rnd.GetRange((UI32)0,m_iBpcTySum);
        UI32 wk_sum = 0;
        for( auto itr = m_vBpcTy.begin(); itr != m_vBpcTy.end(); ++itr ) {
            wk_sum += *itr;
            if( rnd <= wk_sum ) {
                break;
            }
            val++;
        }
        return val;
    }

    /**
     * @brief 重み考慮BPAMの値取得
     * @return BPAMの値 UI32
     */
    virtual UI32 GetBPAM() {
        UI32 val = 0;
        UI32 rnd;
        for( int i=0; i<32; i++ ) {
            rnd = g_rnd.GetRange(1,100);
            val = val >> 1;
            if( rnd <= (UI32)m_vBpam[i] ) {
                val |= 0x80000000;
            }
        }
        return val;
    }

    /**
     * @brief 重み考慮BPDMの値取得
     * @return BPDMの値 UI32
     */
    virtual UI32 GetBPDM() {
        UI32 val = 0;
        UI32 rnd;
        for( int i=0; i<32; i++ ) {
            rnd = g_rnd.GetRange(1,100);
            val = val >> 1;
            if( rnd <= (UI32)m_vBpdm[i] ) {
                val |= 0x80000000;
            }
        }
        return val;
    }

	/**
	 * @brief ブレークの発生頻度を取得する 
     * @retrun パーセンテージの値(0-100)
	 */

	virtual UI32 GetBreakPointWeight() {
		std::map <UI32,IExceptionConfig*>::iterator itr;
		UI32 break_point_sum = 0;
		for (itr = m_mapExcep.begin(); itr != m_mapExcep.end(); itr++) {
			UI32 nExpId = itr->second->m_id;
			// Break type that is other than Break_NONE
			if(nExpId > EXP_BREAK_NONE && nExpId < EXP_BPC_BPNM) {
				break_point_sum += (itr->second)->m_weight;
			}			
		}
        if( break_point_sum == 0 ) {
            m_BreakPointSum = 0;
            return(0);
        }
		else {
            m_BreakPointSum = break_point_sum;
            return ((m_BreakPointWeightSum * 100 ) / break_point_sum);
        }
	}

    /**
     * @brief ブレーク種決定
     */
    virtual UI32 GetBreakType() {
		std::map <UI32,IExceptionConfig*>::iterator itr;
        UI32 rnd = g_rnd.GetRange((UI32)1,m_BreakPointSum);
        UI32 wk_sum = 0;
        UI32 type = 0;
		for (itr = m_mapExcep.begin(); itr != m_mapExcep.end(); itr++) {
            UI32 nExpId = itr->second->m_id;
			if(nExpId > EXP_BREAK_NONE && nExpId < EXP_BPC_BPNM) {
                wk_sum += (itr->second)->m_weight;
                if( rnd <= wk_sum ) {
                    type = (itr->second)->m_type;
                    break;
                }
            }
        }        
        return type;
    }

	/**
     * @brief Get channel in sequential break
	 */
	virtual void GetChannelInSequential(UI32* SQ0, UI32* SQ1) {
		std::map <UI32,IExceptionConfig*>::iterator itr;
		if(m_bSequentialMode == false)
			return ;
		for (itr = m_mapExcep.begin(); itr != m_mapExcep.end(); itr++) {
			UI32 nExpId = itr->second->m_id;
			if(nExpId == EXP_DIR1_SQ0){
				UI32 sq0_rnd = g_rnd.GetRange(1,100);
				if(sq0_rnd <= (itr->second)->m_weight)
					*SQ0 = Code_Ch_DIR1_SQ0;
			}
			if(nExpId == EXP_DIR1_SQ1){
				UI32 sq1_rnd = g_rnd.GetRange(1,100);
				if(sq1_rnd <= (itr->second)->m_weight)
					*SQ1 = Code_Ch_DIR1_SQ1;
			}
		}
	}

	/**
	 * @brief チャネル数を返す
	 */
	virtual UI32 GetNumOfChannels() {
		return m_iNumOfChannels;
	}

	/**
	 * @brief	Get Config of exception (and interrupt)
	 * @idx		Index of exception.
	 * @return	A pointer to IExceptionConfig struct.
	 */
	virtual IExceptionConfig * GetExpConfig(UI32 idx){
		if(idx < 0 || idx >= m_mapExcep.size()){
			return NULL;
		}
		std::map <UI32,IExceptionConfig*>::iterator itr;
		/* Because m_mapExcep is updated at the beginning only. So, the order is not changed */
		UI32 count = 0;
		for(itr = m_mapExcep.begin(); itr != m_mapExcep.end(); itr++) {
			if(count == idx)
				break;
			count++;
		}
		return itr->second;
	}

	/** 
	 * @brief Retrieve list of exception that can cause exception with specified code
	 * @param exception cause code
	 * @return list of exception config
	 */
	virtual std::vector<IExceptionConfig*> GetConfigByCode (UI32 code) {
		std::map <UI32,IExceptionConfig*>::iterator itr;
		std::vector<IExceptionConfig*> vExp;
		for(itr = m_mapExcep.begin(); itr != m_mapExcep.end(); itr++) {
			if(code >= itr->second->m_lcode && code <= itr->second->m_ucode) {
				vExp.push_back(itr->second);
			}
		}
		return vExp;
	}

public:
	static IException* New();

protected:
	std::map< UI32,IExceptionConfig*> m_mapExcep;		//!< 例外情報を保持するマップ Key=要因コード Value=("例外名", 重み)
	UI32 m_BreakPointWeightSum; //!< ブレークポイント設定用重み集計値（分子、BREAK_NONE含まず）
	UI32 m_BreakPointSum; //!< ブレークポイント設定用重み集計値（分母、BREAK_NONE含む）
    bool m_bChannelWeightFlag; //!< チャネル重み設定有無フラグ
    UI32 m_iNumOfChannels; //!< チャネル数（仮置き：本来はISS用初期化ファイルe3v5.iniに有るべき）
    std::vector<int> m_vBpcVsel; //!< Ch_BPC.VSELの重み
    UI32 m_iBpcVselSum; //!< Ch_BPC.VSEL重みの合計
    std::vector<int> m_vBpcTy; //!< Ch_BPC.TYの重み
    UI32 m_iBpcTySum; //!< Ch_BPC.TY重みの合計
    std::vector<int> m_vBpam; //!< Ch_BPAMの重み
    std::vector<int> m_vBpdm; //!< Ch_BPDMの重み
	bool m_bSequentialMode;	// Specify sequential mode
};

#endif /*IFEXCEPTION_H_*/
