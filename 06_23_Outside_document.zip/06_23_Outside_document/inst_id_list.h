#ifndef INST_ID_LIST_H_
#define INST_ID_LIST_H_


#define INS_ID_ADD                    1
#define INS_ID_ADD_I5                 2
#define INS_ID_ADDI_SI16              3
#define INS_ID_ADF                    4
#define INS_ID_AND                    5
#define INS_ID_ANDI_I16               6
#define INS_ID_BC_SD9                 7
#define INS_ID_BE_SD9                 8
#define INS_ID_BF_SD9                 9
#define INS_ID_BGE_SD9                10
#define INS_ID_BGT_SD9                11
#define INS_ID_BH_SD9                 12
#define INS_ID_BLE_SD9                13
#define INS_ID_BL_SD9                 14
#define INS_ID_BLT_SD9                15
#define INS_ID_BN_SD9                 16
#define INS_ID_BNC_SD9                17
#define INS_ID_BNE_SD9                18
#define INS_ID_BNH_SD9                19
#define INS_ID_BNL_SD9                20
#define INS_ID_BNV_SD9                21
#define INS_ID_BNZ_SD9                22
#define INS_ID_BP_SD9                 23
#define INS_ID_BR_SD9                 24
#define INS_ID_BSA_SD9                25
#define INS_ID_BT_SD9                 26
#define INS_ID_BV_SD9                 27
#define INS_ID_BZ_SD9                 28
#define INS_ID_BC_SD17                29
#define INS_ID_BE_SD17                30
#define INS_ID_BF_SD17                31
#define INS_ID_BGE_SD17               32
#define INS_ID_BGT_SD17               33
#define INS_ID_BH_SD17                34
#define INS_ID_BLE_SD17               35
#define INS_ID_BL_SD17                36
#define INS_ID_BLT_SD17               37
#define INS_ID_BN_SD17                38
#define INS_ID_BNC_SD17               39
#define INS_ID_BNE_SD17               40
#define INS_ID_BNH_SD17               41
#define INS_ID_BNL_SD17               42
#define INS_ID_BNV_SD17               43
#define INS_ID_BNZ_SD17               44
#define INS_ID_BP_SD17                45
#define INS_ID_BSA_SD17               46
#define INS_ID_BT_SD17                47
#define INS_ID_BV_SD17                48
#define INS_ID_BZ_SD17                49
#define INS_ID_BINS                   50
#define INS_ID_BSH                    51
#define INS_ID_BSW                    52
#define INS_ID_CALLT                  53
#define INS_ID_CAXI                   54
#define INS_ID_CLL                    55
#define INS_ID_CLR1_SD16              56
#define INS_ID_CLR1                   57
#define INS_ID_CMOV                   58
#define INS_ID_CMOV_SI5               59
#define INS_ID_CMP                    60
#define INS_ID_CMP_SI5                61
#define INS_ID_CTRET                  62
#define INS_ID_DI                     63
#define INS_ID_DISPOSE                64
#define INS_ID_DISPOSE_R3             65
#define INS_ID_DIV                    66
#define INS_ID_DIVH_2                 67
#define INS_ID_DIVH_3                 68
#define INS_ID_DIVHU                  69
#define INS_ID_DIVQ                   70
#define INS_ID_DIVQU                  71
#define INS_ID_DIVU                   72
#define INS_ID_EI                     73
#define INS_ID_EIRET                  74
#define INS_ID_FERET                  75
#define INS_ID_FETRAP                 76
#define INS_ID_HALT                   77
#define INS_ID_HSH                    78
#define INS_ID_HSW                    79
#define INS_ID_JARLSD22               80
#define INS_ID_JARLD22                81
#define INS_ID_JARL                   82
#define INS_ID_JMP                    83
#define INS_ID_JMPD32                 84
#define INS_ID_JRSD22                 85
#define INS_ID_JRD32                  86
#define INS_ID_LD_BSD16               87
#define INS_ID_LD_BSD23               88
#define INS_ID_LD_BUD16               89
#define INS_ID_LD_BUD23               90
#define INS_ID_LD_DW                  91
#define INS_ID_LD_HSD16               92
#define INS_ID_LD_HSD23               93
#define INS_ID_LD_HUD16               94
#define INS_ID_LD_HUD23               95
#define INS_ID_LD_WSD16               96
#define INS_ID_LD_WSD23               97
#define INS_ID_LDL_W                  98
#define INS_ID_LDSR                   99
#define INS_ID_LOOP                   100
#define INS_ID_MAC                    101
#define INS_ID_MACU                   102
#define INS_ID_MOV                    103
#define INS_ID_MOVI5                  104
#define INS_ID_MOVI32                 105
#define INS_ID_MOVEA                  106
#define INS_ID_MOVHI                  107
#define INS_ID_MUL                    108
#define INS_ID_MULI9                  109
#define INS_ID_MULH                   110
#define INS_ID_MULHI5                 111
#define INS_ID_MULHI                  112
#define INS_ID_MULU                   113
#define INS_ID_MULUI9                 114
#define INS_ID_NOP                    115
#define INS_ID_NOT                    116
#define INS_ID_NOT1SD16               117
#define INS_ID_NOT1                   118
#define INS_ID_OR                     119
#define INS_ID_ORI                    120
#define INS_ID_POPSP                  121
#define INST_ID_PREPARE               122
#define INST_ID_PREPARE_SP            123
#define INST_ID_PREPARE_HI16          124
#define INST_ID_PREPARE_I32           125
#define INS_ID_PUSHSP                 126
#define INS_ID_RIE                    127
#define INS_ID_RIE_I9                 128
#define INS_ID_ROTL_I5                129
#define INS_ID_ROTL                   130
#define INS_ID_SAR                    131
#define INS_ID_SAR_I5                 132
#define INS_ID_SAR_R3                 133
#define INS_ID_SASF                   134
#define INS_ID_SATADD                 135
#define INS_ID_SATADD_I5              136
#define INS_ID_SATADD_R3              137
#define INS_ID_SATSUB                 138
#define INS_ID_SATSUB_R3              139
#define INS_ID_SATSUBI                140
#define INS_ID_SATSUBR                141
#define INS_ID_SBF                    142
#define INS_ID_SCH0L                  143
#define INS_ID_SCH0R                  144
#define INS_ID_SCH1L                  145
#define INS_ID_SCH1R                  146
#define INS_ID_SET1_SD16              147
#define INS_ID_SET1                   148
#define INS_ID_SETF                   149
#define INS_ID_SHL                    150
#define INS_ID_SHL_I5                 151
#define INS_ID_SHL_R3                 152
#define INS_ID_SHR                    153
#define INS_ID_SHR_I5                 154
#define INS_ID_SHR_R3                 155
#define INS_ID_SLD_B                  156
#define INS_ID_SLD_BU                 157
#define INS_ID_SLD_H                  158
#define INS_ID_SLD_HU                 159
#define INS_ID_SLD_W                  160
#define INS_ID_SNOOZE                 161
#define INS_ID_SST_B                  162
#define INS_ID_SST_H                  163
#define INS_ID_SST_W                  164
#define INS_ID_ST_B_SD16              165
#define INS_ID_ST_B_SD23              166
#define INS_ID_ST_DW                  167
#define INS_ID_ST_H_SD16              168
#define INS_ID_ST_H_SD23              169
#define INS_ID_ST_W_SD16              170
#define INS_ID_ST_W_SD23              171
#define INS_ID_STC_W                  172
#define INS_ID_STSR                   173
#define INS_ID_SUB                    174
#define INS_ID_SUBR                   175
#define INS_ID_SWITCH                 176
#define INS_ID_SXB                    177
#define INS_ID_SXH                    178
#define INS_ID_SYNCE                  179
#define INS_ID_SYNCI                  180
#define INS_ID_SYNCM                  181
#define INS_ID_SYNCP                  182
#define INS_ID_SYSCALL                183
#define INS_ID_TRAP                   184
#define INS_ID_TST                    185
#define INS_ID_TST1_SD16              186
#define INS_ID_TST1                   187
#define INS_ID_XOR                    188
#define INS_ID_XORI                   189
#define INS_ID_ZXB                    190
#define INS_ID_ZXH                    191
#define INS_ID_HVCALL                 192
#define INS_ID_HVTRAP                 193
#define INS_ID_LDVC_SR                194
#define INS_ID_STVC_SR                195
#define INS_ID_DST                    196
#define INS_ID_EST                    197
#define INS_ID_LDTC_GR                198
#define INS_ID_LDTC_VR                199
#define INS_ID_LDTC_PC                200
#define INS_ID_LDTC_SR                201
#define INS_ID_STTC_GR                202
#define INS_ID_STTC_VR                203
#define INS_ID_STTC_PC                204
#define INS_ID_STTC_SR                205
#define INS_ID_CACHE                  206
#define INS_ID_PREF                   207
#define INS_ID_TLBAI                  208
#define INS_ID_TLBR                   209
#define INS_ID_TLBS                   210
#define INS_ID_TLBVI                  211
#define INS_ID_TLBW                   212
#define INS_ID_DBCP                   213
#define INS_ID_DBHVTRAP               214
#define INS_ID_DBPUSH                 215
#define INS_ID_DBRET                  216
#define INS_ID_DBTAG                  217
#define INS_ID_DBT                    218
#define INS_ID_RMT                    219
#define INS_ID_ABSF_D                 220
#define INS_ID_ABSF_S                 221
#define INS_ID_ADDF_D                 222
#define INS_ID_ADDF_S                 223
#define INS_ID_CEILF_DL               224
#define INS_ID_CEILF_DUL              225
#define INS_ID_CEILF_DUW              226
#define INS_ID_CEILF_DW               227
#define INS_ID_CEILF_SL               228
#define INS_ID_CEILF_SUL              229
#define INS_ID_CEILF_SUW              230
#define INS_ID_CEILF_SW               231
#define INS_ID_CMOVF_D                232
#define INS_ID_CMOVF_S                233
#define INS_ID_CMPF_D                 234
#define INS_ID_CMPF_S                 235
#define INS_ID_CVTF_DL                236
#define INS_ID_CVTF_DS                237
#define INS_ID_CVTF_DUL               238
#define INS_ID_CVTF_DUW               239
#define INS_ID_CVTF_DW                240
#define INS_ID_CVTF_HS                241
#define INS_ID_CVTF_LD                242
#define INS_ID_CVTF_LS                243
#define INS_ID_CVTF_SD                244
#define INS_ID_CVTF_SL                245
#define INS_ID_CVTF_SH                246
#define INS_ID_CVTF_SUL               247
#define INS_ID_CVTF_SUW               248
#define INS_ID_CVTF_SW                249
#define INS_ID_CVTF_ULD               250
#define INS_ID_CVTF_ULS               251
#define INS_ID_CVTF_UWD               252
#define INS_ID_CVTF_UWS               253
#define INS_ID_CVTF_WD                254
#define INS_ID_CVTF_WS                255
#define INS_ID_DIVF_D                 256
#define INS_ID_DIVF_S                 257
#define INS_ID_FLOORF_DL              258
#define INS_ID_FLOORF_DUL             259
#define INS_ID_FLOORF_DUW             260
#define INS_ID_FLOORF_DW              261
#define INS_ID_FLOORF_SL              262
#define INS_ID_FLOORF_SUL             263
#define INS_ID_FLOORF_SUW             264
#define INS_ID_FLOORF_SW              265
#define INS_ID_FMAF_S                 266
#define INS_ID_FMSF_S                 267
#define INS_ID_FNMAF_S                268
#define INS_ID_FNMSF_S                269
#define INS_ID_MADDF_S                270
#define INS_ID_MAXF_D                 271
#define INS_ID_MAXF_S                 272
#define INS_ID_MINF_D                 273
#define INS_ID_MINF_S                 274
#define INS_ID_MSUBF_S                275
#define INS_ID_MULF_D                 276
#define INS_ID_MULF_S                 277
#define INS_ID_NEGF_D                 278
#define INS_ID_NEGF_S                 279
#define INS_ID_NMADDF_S               280
#define INS_ID_NMSUBF_S               281
#define INS_ID_RECIPF_D               282
#define INS_ID_RECIPF_S               283
#define INS_ID_ROUNDF_DL              284
#define INS_ID_ROUNDF_DUL             285
#define INS_ID_ROUNDF_DUW             286
#define INS_ID_ROUNDF_DW              287
#define INS_ID_ROUNDF_SL              288
#define INS_ID_ROUNDF_SUL             289
#define INS_ID_ROUNDF_SUW             290
#define INS_ID_ROUNDF_SW              291
#define INS_ID_RSQRTF_D               292
#define INS_ID_RSQRTF_S               293
#define INS_ID_SQRTF_D                294
#define INS_ID_SQRTF_S                295
#define INS_ID_SUBF_D                 296
#define INS_ID_SUBF_S                 297
#define INS_ID_TRFSR                  298
#define INS_ID_TRNCF_DL               299
#define INS_ID_TRNCF_DUL              300
#define INS_ID_TRNCF_DUW              301
#define INS_ID_TRNCF_DW               302
#define INS_ID_TRNCF_SL               303
#define INS_ID_TRNCF_SUL              304
#define INS_ID_TRNCF_SUW              305
#define INS_ID_TRNCF_SW               306
#define INS_ID_CNVQ15Q30              307
#define INS_ID_CNVQ30Q15              308
#define INS_ID_CNVQ31Q62              309
#define INS_ID_CNVQ62Q31              310
#define INS_ID_DUP_H                  311
#define INS_ID_DUP_W                  312
#define INS_ID_EXPQ31                 313
#define INS_ID_MODADD                 314
#define INS_ID_MOV_DW_VR2             315
#define INS_ID_MOV_DW_VR3             316
#define INS_ID_MOV_H                  317
#define INS_ID_MOV_W_VR23             318
#define INS_ID_MOV_W_VR3              319
#define INS_ID_MOV_W_VR2              320
#define INS_ID_PKI16I32               321
#define INS_ID_PKI16UI8               322
#define INS_ID_PKI32I16               323
#define INS_ID_PKI64I32               324
#define INS_ID_PKQ15Q31               325
#define INS_ID_PKQ30Q31               326
#define INS_ID_PKQ31Q15               327
#define INS_ID_PKUI8I16               328
#define INS_ID_VABS_H                 329
#define INS_ID_VABS_W                 330
#define INS_ID_VADD_DW                331
#define INS_ID_VADD_H                 332
#define INS_ID_VADD_W                 333
#define INS_ID_VADDS_H                334
#define INS_ID_VADDS_W                335
#define INS_ID_VADDSAT_H              336
#define INS_ID_VADDSAT_W              337
#define INS_ID_VAND                   338
#define INS_ID_VBIQ_H                 339
#define INS_ID_VBSWAP_DW              340
#define INS_ID_VBSWAP_H               341
#define INS_ID_VBSWAP_W               342
#define INS_ID_VCALC_H                343
#define INS_ID_VCALC_W                344
#define INS_ID_VCMOV                  345
#define INS_ID_VCMPEQ_H               346
#define INS_ID_VCMPEQ_W               347
#define INS_ID_VCMPLE_H               348
#define INS_ID_VCMPLE_W               349
#define INS_ID_VCMPLT_H               350
#define INS_ID_VCMPLT_W               351
#define INS_ID_VCMPNE_H               352
#define INS_ID_VCMPNE_W               353
#define INS_ID_VCONCAT_B              354
#define INS_ID_VITLV_H                355
#define INS_ID_VITLV_W                356
#define INS_ID_VITLVHW_H              357
#define INS_ID_VITLVWH_H              358
// #define INS_ID_VLD_B                  359
// #define INS_ID_VLD_B                  360
// #define INS_ID_VLD_B                  361
// #define INS_ID_VLD_B                  362
// #define INS_ID_VLD_DW                 363
// #define INS_ID_VLD_DW                 364
// #define INS_ID_VLD_DW                 365
// #define INS_ID_VLD_DW                 366
// #define INS_ID_VLD_DW                 367
// #define INS_ID_VLD_H                  368
// #define INS_ID_VLD_H                  369
// #define INS_ID_VLD_H                  370
// #define INS_ID_VLD_H                  371
// #define INS_ID_VLD_W                  372
// #define INS_ID_VLD_W                  373
// #define INS_ID_VLD_W                  374
// #define INS_ID_VLD_W                  375
// #define INS_ID_VMADRN_H               376
// #define INS_ID_VMADRN_W               377
// #define INS_ID_VMADSAT_H              378
// #define INS_ID_VMADSAT_W              379
// #define INS_ID_VMAXGE_H               380
// #define INS_ID_VMAXGE_W               381
// #define INS_ID_VMAXGT_H               382
// #define INS_ID_VMAXGT_W               383
// #define INS_ID_VMINLE_H               384
// #define INS_ID_VMINLE_W               385
// #define INS_ID_VMINLT_H               386
// #define INS_ID_VMINLT_W               387
// #define INS_ID_VMSUM_H                388
// #define INS_ID_VMSUM_W                389
// #define INS_ID_VMSUMAD_H              390
// #define INS_ID_VMSUMAD_W              391
// #define INS_ID_VMSUMADIM_H            392
// #define INS_ID_VMSUMADIM_W            393
// #define INS_ID_VMSUMADRE_H            394
// #define INS_ID_VMSUMADRE_W            395
// #define INS_ID_VMSUMADRN_H            396
// #define INS_ID_VMSUMAD                397
// #define INS_ID_VMUL_H                 398
// #define INS_ID_VMUL_W                 399
// #define INS_ID_VMULCX_H               400
// #define INS_ID_VMULCX_W               401
// #define INS_ID_VMULT_H                402
// #define INS_ID_VMULT_W                403
// #define INS_ID_VNEG_H                 404
// #define INS_ID_VNEG_W                 405
// #define INS_ID_VNOT                   406
// #define INS_ID_VOR                    407
// #define INS_ID_VSAR_DW                408
// #define INS_ID_VSAR_DW                409
// #define INS_ID_VSAR_H                 410
// #define INS_ID_VSAR_H                 411
// #define INS_ID_VSAR_W                 412
// #define INS_ID_VSAR_W                 413
// #define INS_ID_VSHL_DW                414
// #define INS_ID_VSHL_DW                415
// #define INS_ID_VSHL_H                 416
// #define INS_ID_VSHL_H                 417
// #define INS_ID_VSHL_W                 418
// #define INS_ID_VSHL_W                 419
// #define INS_ID_VSHR_DW                420
// #define INS_ID_VSHR_DW                421
// #define INS_ID_VSHR_H                 422
// #define INS_ID_VSHR_H                 423
// #define INS_ID_VSHR_W                 424
// #define INS_ID_VSHR_W                 425
// #define INS_ID_VSHUFL_B               426
// #define INS_ID_VST_B                  427
// #define INS_ID_VST_B                  428
// #define INS_ID_VST_B                  429
// #define INS_ID_VST_B                  430
// #define INS_ID_VST_DW                 431
// #define INS_ID_VST_DW                 432
// #define INS_ID_VST_DW                 433
// #define INS_ID_VST_DW                 434
// #define INS_ID_VST_DW                 435
// #define INS_ID_VST_DW                 436
// #define INS_ID_VST_H                  437
// #define INS_ID_VST_H                  438
// #define INS_ID_VST_H                  439
// #define INS_ID_VST_H                  440
// #define INS_ID_VST_H                  441
// #define INS_ID_VST_W                  442
// #define INS_ID_VST_W                  443
// #define INS_ID_VST_W                  444
// #define INS_ID_VST_W                  445
// #define INS_ID_VST_W                  446
// #define INS_ID_VSUB_DW                447
// #define INS_ID_VSUB_H                 448
// #define INS_ID_VSUB_W                 449
// #define INS_ID_VSUBS_H                450
// #define INS_ID_VSUBS_W                451
// #define INS_ID_VSUBSAT_H              452
// #define INS_ID_VSUBSAT_W              453
#define INS_ID_VXOR                   454
#define INS_ID_WORD					455
#define INS_ID_SHORT				456
#define INS_ID_LDV_DW				467
#define INS_ID_LDV_QW				471
#define INS_ID_LDV_W				475
#define INS_ID_LDVZ_H4				487
#define INS_ID_STV_DW				489
#define INS_ID_STV_QW				493
#define INS_ID_STV_W				497
#define INS_ID_STVZ_H4				509
#define INS_ID_RECIPF_S4			538
#define INS_ID_RSQRTF_S4			541
#define INS_ID_CMPF_S4				636
#define INS_ID_LD_B_INC        		637
#define INS_ID_LD_B_DEC        		638
#define INS_ID_LD_BU_INC       		639
#define INS_ID_LD_BU_DEC       		640
#define INS_ID_LD_H_INC        		641
#define INS_ID_LD_H_DEC        		642
#define INS_ID_LD_HU_INC       		643
#define INS_ID_LD_HU_DEC       		644
#define INS_ID_LD_W_INC        		645
#define INS_ID_LD_W_DEC        		646
#define INS_ID_ST_B_INC        		649
#define INS_ID_ST_B_DEC        		650
#define INS_ID_ST_H_INC        		651
#define INS_ID_ST_H_DEC        		652
#define INS_ID_ST_W_INC        		653
#define INS_ID_ST_W_DEC        		654
#define INS_ID_LDL_BU          		661
#define INS_ID_LDL_HU          		662
#define INS_ID_STC_B           		664
#define INS_ID_STC_H           		665
#define	INS_ID_RESBANK				667
#define INS_ID_STM_GSR				668
#define INS_ID_STM_MP				669
#define INS_ID_LDM_GSR				670
#define INS_ID_LDM_MP				671

/* Custom instruction */
#define INS_CID_CLR1_B                (NUM_OF_INS + 1)
#define INS_CID_CLR1                  (NUM_OF_INS + 2)
#define INS_CID_NOT1_B                (NUM_OF_INS + 3)
#define INS_CID_NOT1                  (NUM_OF_INS + 4)
#define INS_CID_SET1_B                (NUM_OF_INS + 5)
#define INS_CID_SET1                  (NUM_OF_INS + 6)
#define INS_CID_TST1_B                (NUM_OF_INS + 7)
#define INS_CID_TST1                  (NUM_OF_INS + 8)
#define INS_CID_PREF_I                (NUM_OF_INS + 9)
#define INS_CID_LD_ARRAY              (NUM_OF_INS + 10)
#define INS_CID_ST_ARRAY              (NUM_OF_INS + 11)
#define INS_CID_LS_ARRAY              (NUM_OF_INS + 12)
#define INS_CID_SLD_ARRAY             (NUM_OF_INS + 13)
#define INS_CID_SST_ARRAY             (NUM_OF_INS + 14)
#define INS_CID_SLS_ARRAY             (NUM_OF_INS + 15)
#define INS_CID_CAXI_ARRAY            (NUM_OF_INS + 16)
#define INS_CID_MPU_UPDATE            (NUM_OF_INS + 17)
#define INS_CID_MOV_ALU               (NUM_OF_INS + 18)
#define INS_CID_MOVR_SHIFT            (NUM_OF_INS + 19)
#define INS_CID_MOV_SST               (NUM_OF_INS + 20)
#define INS_CID_MOV5_ST               (NUM_OF_INS + 21)
#define INS_CID_MOVEA_SST             (NUM_OF_INS + 22)
#define INS_CID_MOVEA_ST              (NUM_OF_INS + 23)
#define INS_CID_CMP_BCC               (NUM_OF_INS + 24)
#define INS_CID_ALU_BCC				  (NUM_OF_INS + 25)
#define INS_CID_LDLBU_STCB_S		  (NUM_OF_INS + 26)
#define INS_CID_LDLBU_STCB_F		  (NUM_OF_INS + 27)
#define INS_CID_LDLHU_STCH_S		  (NUM_OF_INS + 28)
#define INS_CID_LDLHU_STCH_F		  (NUM_OF_INS + 29)
#define INS_CID_LDLW_STCW_S			  (NUM_OF_INS + 30)
#define INS_CID_LDLW_STCW_F			  (NUM_OF_INS + 31)
#define INS_CID_ALU_ALU               (NUM_OF_INS + 32)
#define INS_CID_ALU_JMP               (NUM_OF_INS + 33)
#define INS_CID_ALU_LDST              (NUM_OF_INS + 34)
#define INS_CID_ALU_DIV               (NUM_OF_INS + 35)
#define INS_CID_ALU_MUL               (NUM_OF_INS + 36)
#define INS_CID_ALU_SPECIAL           (NUM_OF_INS + 37)
#define INS_CID_ALU_FPU               (NUM_OF_INS + 38)
#define INS_CID_ALU_C2B1              (NUM_OF_INS + 39)
#define INS_CID_LD_ALU                (NUM_OF_INS + 40)
#define INS_CID_LD_JMP                (NUM_OF_INS + 41)
#define INS_CID_LD_LDST               (NUM_OF_INS + 42)
#define INS_CID_LD_DIV                (NUM_OF_INS + 43)
#define INS_CID_LD_MUL                (NUM_OF_INS + 44)
#define INS_CID_LD_SPECIAL            (NUM_OF_INS + 45)
#define INS_CID_LD_FPU                (NUM_OF_INS + 46)
#define INS_CID_LD_C2B1               (NUM_OF_INS + 47)
#define INS_CID_FPU_FPU               (NUM_OF_INS + 48)
#define INS_CID_C2B1_C2B1             (NUM_OF_INS + 49)
#define INS_CID_CHANGE_PRIV           (NUM_OF_INS + 50)
#define INS_CID_CMPFS_TRFSR           (NUM_OF_INS + 51)
#define INS_CID_RIE_FPU32			  (NUM_OF_INS + 52)
#define INS_CID_RIE_FXU32			  (NUM_OF_INS + 53)
#define INS_CID_RIE_FXU64			  (NUM_OF_INS + 54)
#define INS_CID_RIE_INT64			  (NUM_OF_INS + 55)
#define INS_CID_MPU_CHECK			  (NUM_OF_INS + 56)
#define INS_CID_CHANGE_MODE           (NUM_OF_INS + 57)

#endif /*INST_ID_LIST_H_*/