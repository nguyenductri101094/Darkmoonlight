#ifndef SIM_CTRL_H_
#define SIM_CTRL_H_

#include	"rtg_common.h"
#include	"ifsim_ctrl.h"

#define NumberofLLBit 2

struct CIntInfo {
public:
	enum ASYN_CLEAR_STATUS {
		ASYNC_CLEAR_NONE,
		ASYNC_CLEAR_PEND,
		ASYNC_CLEAR_REJECT,
		ASYNC_CLEAR_NUM
	};
	IInstruction			*pIns;
	std::string				sName;
	UI32					nEventId;
	UI32					nPriority;
	SI32					nPeriod;
	UI32					nIndex;
	UI32					nCauseCode;
	UI32					nChannel;
	ASYN_CLEAR_STATUS		nClear;
	
	CIntInfo(IInstruction *pIns, std::string name, UI32 period, UI32 index, UI32 priority, UI32 cause_code, UI32 channel) 
	: pIns(pIns), sName(name), nEventId(0), nPriority(priority), nPeriod(period), nIndex(index), nCauseCode(cause_code), nChannel(channel), nClear(ASYNC_CLEAR_NONE){}
};
struct LDL_STC_CusIns_Sim 
{
	struct LLBitManage {

			LLBitManage() {
				Reset ();
			}
		
			~LLBitManage(){}

			void Reset () {
				STCAddress = 0;
				LLBit = false;
				STCTargetPosition = 0;
				STCSourReg = 0;
				STCDestReg = 0;
				pInsSTC = NULL;
				pInsLDL = NULL;
				pInsForce = NULL;
				IsSTCSuccess = false;
				InSTCSequence = false;
 
				IsSTCInLoop = false;
				IsLDLInLoop = false;
				ForceSTCFail = false;
			}
		
			UI32						STCAddress;			//!< @brief Address of STC instruction.
			bool						LLBit;
			UI32						STCTargetPosition;
			UI32						STCSourReg;
			UI32						STCDestReg;
			IInstruction*				pInsSTC;			//!< @brief pointer to STC target Ins.
			IInstruction*				pInsLDL;			//!< @brief pointer to LDL Ins.
			IInstruction*				pInsForce;			//!< @brief pointer to Ins which use to force LLBit clear.
			bool						IsSTCSuccess;		//!< @brief true stc give result success, false stc give result fail.
			bool						InSTCSequence;		//!< @brief Checking current is in LDL STC sequence.
			bool						StartSTCSequence;	//!< @brief Checking is starting LDL STC sequence.
			bool						IsSTCInLoop;		//!< @brief Checking whether stc be generated in loop sequence.
			bool						IsLDLInLoop;		//!< @brief Checking whether stc be generated in loop sequence.
			bool						ForceSTCFail;
		};

	public:
		//!< Contruct LDL_STC_CusIns_Sim object.
		LDL_STC_CusIns_Sim() :m_nSTCTargetCounter(0), m_pInsLoop(NULL), m_pInsExp(NULL), m_bIsStatusInsLoop(false), m_bNeedResetLoop(false), m_loopCounter (0), m_loopTarget(0) {
			
			for (UI32 i =0; i < NumberofLLBit; i++) {
				LLBitManage* LLBitSequence = new LLBitManage() ;
				LLBitSTC.push_back (*LLBitSequence);
			}
		}
		
		//!< Decontruct LDL_STC_CusIns_Sim object.
		~LDL_STC_CusIns_Sim(){}
		
		/**
			 * @brief  Update position of current instruction。
		*/	
		void CounterLDL_STC_Target(CCodeBlock* pCB, IInstruction* pIns) {
			UI32 counter = 0;
			std::vector<IInstruction*>::iterator itr;

			//!< Update position of current instruction.
			for (itr = m_vpInsBlock.begin(); itr != m_vpInsBlock.end(); itr++) {
				counter++;
				if (pIns == (*itr)){
					break;
				}
			}
			if (itr == m_vpInsBlock.end()){
				m_vpInsBlock.push_back(pIns);
				counter++;
			}

			m_nSTCTargetCounter = counter;

		}
		/**
			 * @brief  Update information loop of loop sequence.
			 * @brief  Update loop counter, and loop status.
		*/	
		void UpdateLDL_STC_Status (CCodeBlock* pCB, IInstruction* pIns, ISimulator* m_pSim) {
			
			//!< Update m_nSTCTargetCounter base on Random Instrucion.
			if (pIns->IsRandomIns()) {
				CounterLDL_STC_Target(pCB, pIns);
			} else if ((pIns->GetRegulationTarget()!=NULL) && (pIns->GetRegulationTarget()->IsRandomIns())) {
				CounterLDL_STC_Target(pCB, pIns->GetRegulationTarget());
			}
			
			IRegulation r(m_pSim, /*IsNativeMode()?(1U<<31):*/0); // TODO: TO BE FIXED on multi-thread
			//!< Reading loop counter.
			if(m_bIsStatusInsLoop) {
				if(pIns == m_pInsLoop) {
					UI32 loopCounter = 0;
					if (m_pSim->ReadGrReg(&loopCounter, (SI32)pIns->opr(0)->Idx(),r.m_ht) != true) {
						std::runtime_error excep("Simulator error : Read GR");
						throw excep;
					}
					// Set condition to Reset loop se
					if (loopCounter == 1) {
						m_bNeedResetLoop = true;
					}
				} 
				if ((m_bNeedResetLoop) && (pIns != m_pInsLoop)) {
						m_pInsLoop = NULL;
						m_bIsStatusInsLoop = false;
						m_loopCounter = 0;
						m_loopTarget = 0;
						m_bNeedResetLoop = false;
				} else {
					//Update Loopcounter.
					UI32 loopCounter = 0;
					if (m_pSim->ReadGrReg(&loopCounter, (SI32)m_pInsLoop->opr(0)->Idx(),r.m_ht) != true) {
						std::runtime_error excep("Simulator error : Read GR");
						throw excep;
					}
					m_loopCounter = m_loopTarget - loopCounter;
				}				
			}
			// Codition to start loop sequence.
			if ((pIns->InLoop() || pIns->GetMne()== "loop") && (!m_bIsStatusInsLoop)) {
				//!< Starting sequence when finding loop condition.
				UI32 idx = pCB->GetIndex(pIns);
				while(idx < pCB->GetInstructionNum()) {
					if(pCB->at(idx)->GetMne() == "loop") {
						m_pInsLoop = pCB->at(idx);
						break;
					}
					idx++;
				}
				if (m_pSim->ReadGrReg(&m_loopTarget, (SI32)m_pInsLoop->opr(0)->Idx(),r.m_ht) != true) {
					std::runtime_error excep("Simulator error : Read GR");
					throw excep;
				}
				if (m_pInsLoop != NULL) {
					m_bIsStatusInsLoop = true;
				} 
			}
			
		}
		

	public:
		UI32						m_nSTCTargetCounter;	//!< @brief Counter number of current step.
		std::vector <LLBitManage>	LLBitSTC;		
		std::vector<IInstruction*>	m_vpInsBlock;			//!< @brief hold random for calculating current position.
		
		//!<LLBit.
		std::vector<T_LLBITRECORD>	m_vLLBitData;			//!< @brief hold all LLBit data.
		T_LLBITRECORD				m_stLLBitData;			//!< @brief current LLbit data.

		//!< Process for stc in loop sequence.
		IInstruction*				m_pInsLoop;				//!< @brief pointer to frit ins In loop sequence in LDL STC sequence.
		IInstruction*				m_pInsExp;				//!< @brief pointer to Ins cause Interrupt/Exp before LLBit be cleared.
		bool						m_bIsStatusInsLoop;		//!< @brief Checking whether ldl stc sequence is in loop instructions.
		bool						m_bNeedResetLoop;		//!< @brief Need reset Loop sequence or not. 
		UI32						m_loopCounter;			//!< @brief loop counter.
		UI32						m_loopTarget;


};
/**
 * @brief	シミュレータを制御するクラス
 */
class CSimulatorControl : public ISimulatorControl
{
public:

	/**
	 * @brief  このオブジェクトを構築します。
	 */	
	CSimulatorControl();

	/**
	 * @brief  このオブジェクトを破棄します。
	 */	
	virtual ~CSimulatorControl();

	/**
	 * @brief	このオブジェクトを初期化します。
	 * @return	初期化に成功した場合、真を返す。
	 */	
	virtual bool Init(std::string&);
	
	/**
	 * @brief  シミュレーション開始前、再開時に必要な処理を実装します。
	 * @return 成功した場合、真を返します。
	 */
	virtual bool ReadySimulation (ISimulationParam* pSp, IBlockSimParam* pBsp);

	/**
	 * @brief  シミュレーション開始前、再開時に必要な処理を実装します。
	 * @return 成功した場合、真を返します。
	 */
	virtual CSimResource* GetResource ();

protected:
	/**
	 * @brief  Frogアドレスを論理アドレス、物理アドレスを得る。
	 * 
	 */
	bool DecodeAddress(UI32 L, UI32* PL, UI32* PP);
	
	bool RecalcAbsoluteAddress(IInstruction* pIns);
	
	
	/**
	 * @brief	シミュレーターに指定命令の実行を指示します。
	 * @param   htid  実効スレッドID 
	 * @param   lpc   命令論理アドレス(PC値)
	 * @param   ppc   命令物理アドレス   
	 * @param   pIns  命令オブジェクト
	 * @param   res   結果受信用データクラス
	 * @return	成功した場合、真を返す。
	 */	
	virtual bool Step(UI32 htid, UI32 lpc, UI32 ppc, IInstruction* pIns, ISimulatorStepResp * res);
	
	/**
	 * @brief ブレークポイント情報の生成処理
	 */
	virtual void GenerateBreakPointSetup(IBlockSimParam* p, IInstruction* pIns,CCodeBlock* pBlk);

    /**
     * @brief ブレークポイントの設定と種別選択処理
     */
	virtual UI32 GenerateBreakPointBeforeSetup(IBlockSimParam* p, IInstruction* pIns, CCodeBlock* pBlk);

    /**
     * @brief  ブレークポイントコードブロック作成
     */
    virtual void GenerateBreakPointSetupBlock(IBlockSimParam* bsp);

	/**
	 * @brief	ブロック単位でシミュレーションします。
	 * @return	バージョンを示す文字列
	 */	
	virtual bool BlockSimulation(IBlockSimParam* p);	
		
	/**
	 * @brief	値制約の検証を実施し、補正命令によりコードブロックを編集します。。
	 * @param   pCB   コードブロック参照
	 * @param   pIns  命令参照
	 * @return	補正した場合、真を返す。偽の場合は補正なく実行可能。
	 */	
	bool RegulateBranchCondition(CCodeBlock* pCB, IInstruction* pIns);

	/**
	 * @brief	値制約の検証を実施し、補正命令によりコードブロックを編集します。。
	 * @param   pCB   コードブロック参照
	 * @param   pIns  命令参照
	 * @return	補正した場合、真を返す。偽の場合は補正なく実行可能。
	 */	
	bool RegulateValueConstraint(CCodeBlock* pCB, IInstruction* pIns);

	/**
	 * @brief	r0に対して補正処理が必要である場合、インデックスを書き換える。
	 * @param   pIns  補正が必要な命令
	 */	
	void GiveUpRecovery_R0(IInstruction* pIns, IRegulation *Reg);
	
	/**
	 * @brief	シミュレーターがネイティブ動作中であるかを取得する。。
	 * @return	ネイティブ動作中であれば真を返す。
	 */	
	bool IsNativeMode( void );

    /**
    * @brief Get whether the simulator is in guest operation. .
    * @Returns true if guest operation is in progress.
    */
    bool IsGuestMode(void);

	/**
	 * @brief	PSW値を読み出す（TODO: VMモード時TC0のPSWを読み出す。MT動作時には修正が必要）。。
	 * @return	PSWの値
	 */	
	UI32 GetPSW( void );

	/**
	 * @brief	Adjust random code block to control FPI exception
	 * @param	pCB	pointer to code block
	 * @param	pIns current regulated Instruction
	 * @return	bool (true: need to ReAsm, false: Do not need to ReAsm)
	 */	
	bool RegulateFPIException (CCodeBlock* pCB, IInstruction* pIns);

	/**
	 * @brief	Remove propagation of FPU mismatch during FPI mode.
	 * @param	pCB	pointer to code block
	 * @param	pIns current regulated Instruction
	 * @return	bool (true: need to ReAsm, false: Do not need to ReAsm)
	 */	
	bool OverwriteFPIMismatch(CCodeBlock* pCB, IInstruction* pIns);

	/**
	 * @brief	Update status of FPI control variable.
	 * @param	pIns current regulated Instruction
	 * @return	void
	 */	
	void UpdateFPIStatus(IInstruction* pIns);
	
	/**
	 * @brief	Regualate some specical custom Instruction in simulation phase.
	 * @param	pCB pointer to current code block.
	 * @param	pIns pointer to current regulated Instruction.
	 * @return	bool (true: need to ReAsm, False: don't need to ReAsm)
	*/	
	bool RegulateSpecialCustomIns(CCodeBlock* pCB, IInstruction* pIns);

	/**
		To be Define.
	*/
	bool RegulateSpecialCustomInsSTCInsert (CCodeBlock* pCB, IInstruction* pIns, UI32 LLBitType ,LDL_STC_CusIns_Sim* lspsim);

	/**
		To be Define.
	*/
	bool PredictLLBitInNextIns( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBitType ,LDL_STC_CusIns_Sim* lspsim);

	/**
		To be Define.
	*/
	bool ForceClearLLBit( CCodeBlock* pCB, IInstruction* pIns, UI32 LLBitType ,LDL_STC_CusIns_Sim* lspsim);
	/**
	 * @brief	値制約の検証結果から汎用レジスタの補正コードを生成する。
	 * @param   curV  現在値
	 * @param   trgV  目標値
	 * @param   reg   対象の汎用レジスタインデックス
	 * @param   vPrevIns include the previous instruction of current instruction in C2B1 or forwarding data
	 * @return	生成した補正命令
	 */		
	IInstruction* GenerateRegulatedInstructionGR32(UI32 curV, UI32 trgV, UI32 reg, std::vector<UI32>& ex, std::vector<IInstruction*> *vPrevIns, IInstruction* pIns, CCodeBlock* pcb);

	std::vector<IInstruction*> RegulateByForwardingIns(UI32 htid, UI32 targV, UI32 reg, std::vector<UI32>& ex, IInstruction* pIns, CCodeBlock* pcb);

	/**
	 * @brief	Mask the LDSR instruction to set the specified bits.
	 * @param   pCB  pointer to code block
	 * @param   pIns pointer to LDSR instruction
	 * @return	bool (true: mask succeeded, false: the instruction is removed)
	 */		
	bool MaskSysRegLoad (CCodeBlock* pCB, IInstruction *pIns);

	/**
	 * @brief	Check asynchronous label, then send interrupt request to simulator
	 * @param	pIns	Current simulated instruction
	 */
	void CheckInterruptRequest(CCodeBlock *pCB, IInstruction *pIns);

	/**
	 * @brief	Check status of requested event, then deciding clear un-accepted event
	 * @param	pCB		current simulated code block
	 * @param	pIns	Current simulated instruction
	 * @return	If there is any event cleared, return true, otherwise, return false
	 */
	bool DeassertInterrupt(CCodeBlock *pCB, IInstruction *pIns);

	/**
	 * @brief	Check and prevent consecutive interrupt request
	 * @param	pCB		current simulated code block
	 * @param	pIns	Current simulated instruction
	 * @return	If there is consecutive request, return true; otherwise, return false
	 */
	bool CheckConsecutiveRequest(CCodeBlock *pCB, IInstruction *pIns);

	/**
	 * @brief	Adjust codeblock when exception occurs
	 * @param	pCB pointer to a code block structure
	 * @param	pIns pointer to current executing instruction
	 * @return	Specify whether code block was adjusted or not
	 */
	bool RegulateException(CCodeBlock* pCB, IInstruction *pIns, IExceptionConfig* pExp);

	/**
	 *
	 *
	 */
	void SetException (IInstruction *pIns, IExceptionConfig *pExp, CCodeBlock* pCB);

	bool CheckAcceptanceCond(std::string name, UI32 priority = 0);

	bool RegulateBeforeException(CCodeBlock *pCB, IInstruction *pIns);

	std::string GetMContext();

	std::string GetTContext();
	
	UI32 GetTargetHandlerAddress(IExceptionConfig *pExp);

	/**
	 *@brief	Store information about exception (return PC or code block of breakPC)
	 *@param	Exception cause code
	 *@param	pIns pointer to current executing instruction
	 *@param	pCB pointer to a code block structure
	 */
	void StoreExceptionInfo(UI32 cause_code, IInstruction* pIns, CCodeBlock* pCB);

	bool RecoveryFPIResources(CCodeBlock *pCB);
	bool SyncCoProc(CCodeBlock *pCB, IInstruction *pIns);
	void RestoreRegulatedGR(CCodeBlock *pCB);
	virtual void GetRegulatedGrList(std::map<std::string, GRVALSET> *pGrList) {
		pGrList->insert(m_mRegulatedGrList.begin(), m_mRegulatedGrList.end());
		m_mRegulatedGrList.clear();
	}
	void PrepareDeletedIns(CCodeBlock *pCB, IInstruction *pIns);
	IExceptionConfig* IdentifyException(IException*	pExp, UI32 code);
	bool AdjustJumpForwarding(CCodeBlock *pCB, IInstruction *pIns);

    /**
    *@brief	Regulate MPU update sequence
    */
    bool RegulateMPUupdate(CCodeBlock *pCB, UI32 jump_reg);

    /**
    *@brief	Random value for MPIDn (n: 0 -> 7) and SPID
    */
    void RandomMPIDn_SPID(CCodeBlock *pCB, UI32 reg);

    /**
    *@brief Update MPU register of Host management and Guest Management
    */
    bool RandomGuest_HostEntries(CCodeBlock *pCB, UI32 reg);

    /**
    *@brief	Update MPU register of Convention mode
    */
    void RandomMPUofConventionMode(CCodeBlock *pCB, UI32 reg);

protected:
	enum FPI_STATUS{
		FPI_NONE,
		FPI_START_PSW_ID_0,
		FPI_START_PSW_ID_1,
		FPI_ACCEPT,
		FPI_NOT_ACCEPT
	};

	FPI_STATUS						m_nFPIStatus;
	UI32							m_nFPIPendingIns;
	UI32							m_nFPIMismatchReg;
	LDL_STC_CusIns_Sim				m_stLDL_STC_Sim;
	std::vector<CIntInfo*>			m_vRequestedIntStack; //<! @brief Stack to control sending interrupt request to simulator.
	bool							m_bRollback;
	IInstruction*					m_pRollbackIns;
	UI32							m_nBlockSimCount;
	UI32							m_nDeassertIdx;
	UI32							m_nWRMemOffset;
	UI32							m_nWRMemBlockCount;
	bool							m_bNewWRMemBlock;
	std::map<std::string, GRVALSET>	m_mRegulatedGrList;
	std::vector<std::string>		m_vExpLabelStack;
	std::vector<IInstruction*>		m_vRequestedIns;
	UI64							m_nPreciMismatchReg;
    CMmList*                        m_MPUlist;     //!< @brief save MPU information
};

#endif /*SIM_CTRL_H_*/
