#ifndef SIMULATOR_H_
#define SIMULATOR_H_


#include    "ifsimulator.h"
//extern "C"{
#include	"frog_if.h"
//}



 /***************************************/
 /* コールバック・GCSインタフェース関数群 */
 /***************************************/

    /**
     * Register Interface - Register Update (callback)
     *
     * @param  regname       [in] Name of register to update
     * @param  value         [in] Value to update register to
     * @param  prev_value    [in] PreviousValue to update register to
     */
	void cb_update_nc_register(const std::string regname, FrogRegData value, FrogRegData prev_value) ;

    /**
     * Register Interface - Register Update (callback)
     *
     * @param  regname       [in] Name of register to update
     * @param  value         [in] Value to update register to
     * @param  prev_value    [in] PreviousValue to update register to
     * @param  vcid          [in] Machine ID (0-7)
     */
	void cb_update_vc_register(const std::string regname, FrogRegData value, FrogRegData prev_value, UI32 vcid) ;
    /**
     * Register Interface - Register Update (callback)
     *
     * @param  regname       [in] Name of register to update
     * @param  value         [in] Value to update register to
     * @param  prev_value    [in] PreviousValue to update register to
     * @param  tcid          [in] Thread ID(0-63)
     */
	void cb_update_tc_register(const std::string regname, FrogRegData value, FrogRegData prev_value, UI32 tcid) ;

    /**
     * Memory Interface - Memory Update (callback)
     *
     * @param  address     [in] Physical memory address at which to begin update
     * @param  size        [in] Number of bytes to update ( 16-bit access => 2, 32-bit access => 4 )
     * @param  value       [in] update value
     * @param  prev_value  [in] PreviousValue
     * @param  access_type [in] "read", "write"
     * @param  access_bus  [in] 0:FetchData , 1:R/W Data , 2: API
     */
    void cb_update_generator_memory(uint64_t address, UI32 size, uint64_t value, uint64_t prev_value, UI32 access_type, UI32 access_bus, UI32 load_action) ;

    /**
     * LLbit Interface - llbit Update (callback)
     *
     * @param  address       [in] Name of register to update
     * @param  isNt          [in] true:Native thread, false:HT#0-63
     * @param  tcid          [in] Thread ID(0-63).
     * @param  status        [in] "C"=New link created, "D"=Diasappear link.
     */
    void cb_update_generator_llbit(UI32 pe_id, uint64_t address, UI32 size, bool isNt, UI32 ptid, const UI32 status) ;


    /**
     * Miscellaneous - Insert Comment (callback)
     *
     * @param  comment [in] Execution information
     */
	void cb_insert_comment(const std::string &comment) ;

    /**
     * TLB Interface - entry accessing (callback)
     *
     * @param  idx        [in] Index of entry (0-63)
     * @param  l0         [in] Value of TELO0 register.
     * @param  l1         [in] Value of TELO1 register.
     * @param  h0         [in] Value of TEHI0 register.
     * @param  h1         [in] Value of TEHI1 register.
     * @param  l0_prev    [in] PreviousValue of TELO0 register.
     * @param  l1_prev    [in] PreviousValue of TELO1 register.
     * @param  h0_prev    [in] PreviousValue of TEHI0 register.
     * @param  h1_prev    [in] PreviousValue of TEHI1 register.
     * @param  access_type [in] "R"=read entry, "W"=write entry.
     */
    void cb_update_generator_tlb(UI32 idx, UI32 l0, UI32 l1, UI32 h0, UI32 h1, UI32 l0_prev, UI32 l1_prev, UI32 h0_prev, UI32 h1_prev, UI32 access_type) ;



/****************************************************************/
/*              Undoコンテナ用インスタンスクラス群              */
/****************************************************************/

#define SIM_UNDO_DISABLE	0	//!< コールバックがあってもUndoコンテナに情報をセットしない。キャッシュしているレジスタにも反映させない。
#define SIM_UNDO_ENABLE		1	//!< コールバックがあればStep実行による更新としてUndoコンテナに情報をセットする
#define SIM_UNDO_API		2	//!< コールバックがあってもUndoコンテナに情報をセットしない。キャッシュしているレジスタには反映させる。
#define SIM_UNDO_PRESET		3	//!< コールバックがあればメモリ初期値情報としてUndoコンテナに情報をセットする

class	IUndoProfile {
public:
	IUndoProfile(){}
	virtual ~IUndoProfile(){}
	/**
	 * @brief このクラスに格納されている情報をシミュレータに書き戻す。
	**/
	virtual SI32 WriteBack(){ return (GCSIF_SUCCESS) ; }
	/**
	 * @brief このクラスに格納されている情報の種類を取得する。
	 * @retval  1 : NCレジスタ更新情報
	 * @retval  2 : TCレジスタ更新情報
	 * @retval  3 : VCレジスタ更新情報
	 * @retval  8 : 汎用レジスタ更新情報
	 * @retval 10 : ベクタレジスタ更新情報
	 * @retval 11 : プログラムカウンタ更新情報
	 * @retval 12 : TLBエントリー更新情報
	 * @retval 13 : リンクビット更新情報
	 * @retval 16 : メモリーライト情報
	 * @retval 17 : メモリー初期値情報
	**/
	virtual SI32 GetType(){ return 0 ; }
	void Init(){ m_pc_pending= false ; }
	SI32 Flash( void ){
		SI32 success= GCSIF_SUCCESS ;
		if (m_pc_pending) {
			if ((SI32)m_pc_tcid < 0) {
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
				std::cout << "NC : PC = " ;
#endif
				success= gcs_set_nc_register("PC", (FrogRegData)m_pc_value ) ;
			} else {
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
				std::cout << "TC#" << std::dec << m_pc_tcid << " : PC = " ;
#endif
				success= gcs_set_tc_register("PC", (FrogRegData)m_pc_value, m_pc_tcid) ;
			}
#if defined(_DBG_SIM_H_)||defined(_DBG_SIM00_)||defined(_DBG_SIM01_)
			std::cout << std::hex << m_pc_value << std::endl;
#endif
			m_pc_pending= false ;
		}
		return (success) ;
	}
	static bool m_pc_pending ;
	static UI32 m_pc_tcid ;
	static UI32 m_pc_value ;
} ;


/**
 * @brief NCレジスタ更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CNcRegProfile : public IUndoProfile {
public:
	CNcRegProfile(UI32 selID     , UI32 regID     , UI64 value ) :
	   m_type(1) ,m_selID(selID) , m_regID(regID) , m_value((UI32)value) {}

	~CNcRegProfile(){}
	SI32 WriteBack() ;
	virtual SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_selID ;
	UI32	m_regID ;
	UI32	m_value ;
} ;


/**
 * @brief TCレジスタ更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CTcRegProfile : public IUndoProfile {
public:
	CTcRegProfile (UI32 tcid     ,UI32 selID        ,UI32 regID       , UI64 value ) :
	   m_type(2) ,m_tcid(tcid) , m_selID (selID ) , m_regID (regID) , m_value((UI32)value) {}

	~CTcRegProfile(){}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_tcid ;
	UI32	m_selID ;
	UI32	m_regID ;
	UI32	m_value ;
} ;

	
/**
 * @brief VCレジスタ更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CVcRegProfile : public IUndoProfile {
public:
	CVcRegProfile(UI32 vcid    , UI32 selID     , UI32 regID     , UI64 value ) :
	   m_type(3) ,m_vcid(vcid) , m_selID(selID) , m_regID(regID) , m_value((UI32)value) {}

	~CVcRegProfile() {}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_vcid ;
	UI32	m_selID ;
	UI32	m_regID ;
	UI32	m_value ;
} ;


/**
 * @brief 汎用レジスタ更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CGrRegProfile : public IUndoProfile {
public:
	CGrRegProfile (UI32 tcid    , UI32 regID      , UI64 value ) :
	    m_type(8) ,m_tcid(tcid) , m_regID (regID) , m_value((UI32)value) {}

	~CGrRegProfile(){}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_tcid ;
	UI32	m_regID ;
	UI32	m_value ;
} ;

	
/**
 * @brief ベクタレジスタ更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CVeRegProfile : public IUndoProfile {
public:
	CVeRegProfile (UI32 tcid     , UI32 regID      , UI64 value ) :
	    m_type(10) ,m_tcid(tcid)  , m_regID (regID) , m_value(value) {}

	~CVeRegProfile(){}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_tcid ;
	UI32	m_regID ;
	UI64	m_value ;
} ;

	
/**
 * @brief プログラムカウンタ更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CPcRegProfile : public IUndoProfile {
public:
	CPcRegProfile (UI32 tcid    , UI64 value ) :
	   m_type(11) ,m_tcid(tcid) , m_value((UI32)value) {}

	~CPcRegProfile(){}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_tcid ;
	UI32	m_value ;
} ;

	
/**
 * @brief TLBエントリー更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CTLBProfile : public IUndoProfile {
public:
	CTLBProfile( SI32 idx    , UI32 l0 , UI32 l1  , UI32 h0  , UI32 h1  , UI8 at) :
	   m_type(12),m_idx(idx) ,m_l0(l0) , m_l1(l1) , m_h0(h0) , m_h1(h1) , m_at(at) {}

	~CTLBProfile(){}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI32	m_idx ;
	UI32	m_l0 ;
	UI32	m_l1 ;
	UI32	m_h0 ;
	UI32	m_h1 ;
	UI32 	m_at ;
} ;

	
/**
 * @brief リンクビット更新情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CLLbitProfile : public IUndoProfile {
public:
	CLLbitProfile (UI64 address       , UI32 size	,bool isNt    , SI32 tcid     , UI8 status):
	   m_type(13) ,m_address(address) , m_size(size), m_isNt(isNt) , m_tcid (tcid) , m_status(status) {}

	~CLLbitProfile(){}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI64	m_address ;
	UI32	m_size;
	bool	m_isNt ;
	UI32	m_tcid ;
	UI32 	m_status ;
} ;

	
/**
 * @brief メモリーライト情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CWrMemProfile : public IUndoProfile {
public:
	CWrMemProfile(UI64 address       ,UI32 size    , UI64 value     , UI32 access_bus) :
	  m_type(16) ,m_address(address) ,m_size(size) , m_value(value) , m_access_bus(access_bus) {}

	~CWrMemProfile() {}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI64	m_address ;
	UI32	m_size ;
	UI64	m_value ;
	UI32	m_access_bus ;
} ;


/**
 * @brief メモリー初期値設定情報をアンドゥーコンテナに載せるオブジェクトクラス
*/
class	CPresetMemProfile : public IUndoProfile {
public:
	CPresetMemProfile(UI64 address   ,UI32 size    , UI64 writen      , UI64 value     , UI32 access_bus) :
	  m_type(17) ,m_address(address) ,m_size(size) , m_writen(writen) , m_value(value) , m_access_bus(access_bus) {}

	~CPresetMemProfile() {}
	SI32 WriteBack() ;
	SI32 GetType(){ return m_type ; }
	UI32	m_type ;
	UI64	m_address ;
	UI32	m_size ;
	UI64	m_writen ;
	UI64	m_value ;
	UI32	m_access_bus ;
} ;


class	DataAccessItem {
public:
    ~DataAccessItem() {}
    DataAccessItem( UI32 read1_write0 , UI64 addr , UI32 byte ) : m_Read1_Write0(read1_write0), m_nMemAddress(addr), m_nMemByte( byte ) {}
	DataAccessItem( UI32 read1_write0 , UI64 addr , UI32 byte, UI64 data ) : m_Read1_Write0(read1_write0), m_nMemAddress(addr), m_nMemByte( byte ), m_nMemData( data ) {}

public:
    UI32        m_Read1_Write0;
    UI64		m_nMemAddress;
	UI32		m_nMemByte;
	UI64        m_nMemData;
};


/**
 * @brief ISSシミュレータを提供するクラスです。
 *        ISimulatorを実装します。
 */
class CSimulator : public ISimulator
{
public:
    /**
     * @brief このオブジェクトを構築します。
     */
    CSimulator();
    
    /**
     * @brief このオブジェクトを破棄します。
     */
    virtual ~CSimulator();

    /**
     * @brief インスタンスを初期化します。
     * @param ini パスを含む初期設定ファイル名を指定。
     */
    virtual bool Init(std::string& ini);

    /**
     * @brief シミュレータ名を表す文字列を返す
     *
     * @return シミュレータ名
	 * @retval "E3xISS" : 現在これのみ
     */
    virtual std::string GetName( void ) ; 

    /**
     * @brief シミュレータのレビジョンを表す文字列を、シミュレータから取得して呼び元に返す
     *
     * @return レビジョン文字列
     */
    virtual std::string GetSimulatorVersion( void ) ; 

    /**
     * @brief シミュレータの搭載情報を返す
     *
     * @return isError
     */
	virtual bool GetSimulatorInfo(ISimulatorHwInfo &info) ;

    /**
     * @brief １命令をステップ実行します。
     * @param   htid         [in]   ステップするスレッドＩＤ
     * @param   address      [in]   メモリにライトし、実行するアドレス
     * @param   response     [out]  実行結果情報格納先クラスの先頭アドレス（結果不要ならばNULL指定可）
     * @note
     * \n エラー情報： GetErrorInfo()で取得可
     * \n ERR_NOT_INITIALIZED     : Simulator is not initialized.
     * \n ERR_INVALID_TCID        : Thread id is 0-63
     * \n ERR_THREAD_NOT_LINKED   : Thread isn't associated with vm.
     * \n ERR_THREAD_CANT_EXEC    : Native is operating
     * \n ERR_THREAD_IS_HALT      : Thread is halt or suspend.
     * \n ERR_STEP                : Error on executing operation in ISS.
     * \n ERR_CLEAN               : エラーが無い状態。戻り値が false の場合はこの値となる。
     * \n 上記以外                 : 内部エラー
     */
    virtual bool Step(SI32 htid ,UI64 address ,ISimulatorStepResp * response) ;

    /**
     * @brief 巻戻しポイントの作成
     *
     * @param   point_id     [in]  巻戻しポイントをラベル文字列で設定
     */
    virtual bool CreateChkPoint(std::string point_id) ;

    /**
     * @brief 設定ポイントまでの巻戻し
     *
     * @param   point_id     [in]  巻戻しポイントをラベル文字列で指定
     */
    virtual bool Rollback(std::string point_id) ;

	/**
	 * @brief	Rollback execution of a instruction
	 * @return	Rollback is successfull or not
	 */
	virtual bool Rollback() ;

    /**
     * @brief シミュレータ上のメモリにデータをライトします。
     *
     * @param   address      [in]  メモリにライトし、実行するアドレス
     * @param   size         [in]  メモリにライトするサイズ
     * @param   val          [in]  メモリにライトするデータの先頭アドレス
     * @return isSUCCESS
     */
    virtual bool WriteMemory( UI64 address , SI32 size , UI64 val ) ;

    /**
     * @brief 指定したアドレス（MMU有効時は物理アドレスに変換）が未使用であれば初期値データをライトします。
     *
     * @param   isNC         [in]  取得先がネイテイブマシンならば true
     * @param   htid         [in]  取得先が仮想マシンの場合のスレッドＩＤ
     * @param   address      [in]  メモリにライトし、実行するアドレス
     * @param   size         [in]  メモリにライトするサイズ
     * @param   val          [in]  メモリにライトするデータの先頭アドレス
     * @return isSUCCESS
     */
    virtual bool PresetMemory( bool isNC ,UI32 htid , UI64 address, SI32 size , UI64 val, bool flag = false) ;

    /**
     * @brief メモリのデータをリードします。
     *
     * @param   address     : リードアドレス
     * @param   size        : リードサイズ
     * @param   val         : リードデータの格納アドレス
     * @return isError
     */
    virtual bool ReadMemory( UI64 address , SI32 size , UI64 * val  ) ;

    /**
     * @brief システム・レジスタ値の読み出し（ネイティブ・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @return isError
     */
    bool ReadNcReg(UI32 * value , SI32 regID , SI32 selID ) ;

    /**
     * @brief システム・レジスタ値の読み出し（スレッド・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool ReadTcReg(UI32 * value , SI32 regID , SI32 selID , SI32 tcid ) ;

	/**
     * @brief システム・レジスタ値の読み出し（ネイティブ・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @return isError
     */
    virtual bool WriteNcReg(UI32 value , SI32 regID , SI32 selID ) ;

	 /**
     * @brief システム・レジスタ値の読み出し（スレッド・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool WriteTcReg(UI32 value , SI32 regID , SI32 selID , SI32 htid ) ;


    /**
     * @brief システム・レジスタ値の読み出し（仮想マシン・コンテキスト）
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  selID         [in]  グループ番号
     * @param  vcid          [in]  仮想マシン・コンテキスト番号
     * @return isError
     */
    virtual bool ReadVcReg(UI32 * value , SI32 regID , SI32 selID , SI32 vcid ) ;

    /**
     * @brief ハードウェアスレッドのプログラムカウンタの読み出し
     *
     * @param  *value        [out] 結果格納アドレス
     * @param  tcid          [in]  スレッド・コンテキスト番号（省略時はNC:PC値を返す）
     * @return isSUCCESS
     */
    virtual bool ReadPC(UI32 * value ,SI32 tcid ) ;

    /**
     * @brief ネイティブスレッドのプログラムカウンタの読み出し
     *
     * @param  *value        [out] 結果格納アドレス
     * @return isSUCCESS
     */
    virtual bool ReadPC(UI32 * value ) ;

    /**
     * @brief 汎用レジスタ値の読み出し
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool ReadGrReg(UI32 * value , SI32 regID  , SI32 tcid ) ;

	 /**
     * @brief Use to read system Register
     *
     * @param  value         [out] read value from system register.
     * @param  registerName  [in]  System register name.
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
	virtual bool ReadSysRegister(UI32 * value, std::string registerName , SI32 tcid ) ;
    /**
     * @brief FP-SIMDレジスタ値の読み出し
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool ReadWrReg(__uint128_t * value , SI32 regID , SI32 tcid ) ;

    /**
     * @brief ベクトルレジスタ値の読み出し
     *
     * This function can read value from system register without privilege.
     * To access General, Vector and PC, use existing interface.
     *
     * @param  value         [out] 結果格納アドレス
     * @param  regID         [in]  レジスタ番号
     * @param  tcid          [in]  スレッド・コンテキスト番号
     * @return isError
     */
    virtual bool ReadVeReg(UI64 * value , SI32 regID  , SI32 tcid ) ;

    /**
     * @brief エラー詳細情報の取得
     *
     * @param  value         [out] 結果格納アドレス
     * @return isError
     */
    virtual bool GetErrorInfo(UI32 * value ) ;

    /**
     * @brief レジスタ（主に汎用レジスタ）の値をダンプ
     *
     * @param  tcid          [in] Thread ID(0-63).
     */
    virtual bool DumpTcReg( SI32 tcid ) ;

    /**
     * @brief アンドゥコンテナをサーチして、メモリ初期化が必要なアドレスと初期値 のリストを返す。（プリロードコード生成用）
     *
     * @return Pointer Memory Preset Data Vector
     */
	virtual void GetMemoryPresetData( std::vector<T_MEMWRRECORD > *  buff ) ;

    /**
     * @brief アンドゥコンテナをサーチして、シミュレーション中にメモリライトを行ったアドレスと書き込み値のリストを返す。（エピローグコード生成用）
     *
     * @return Pointer of Memory Writen Data Vector
     */
	virtual void GetMemoryWritenData( std::vector<T_MEMWRRECORD > * buff ) ;
	
	/**
     * @brief Get LLBit data vector form LLBit call back.
     *
     * @return Pointer of LLBit Data Vector.
     */
	virtual void GetLLBitData( std::vector<T_LLBITRECORD > * buff );

	/**
	 * @brief	Send a interrupt request to simulator
	 * @ptid	Physical thread ID of current machine
	 * @name	Interrupt name
	 * @channel	Interrupt channel
	 * @priority	Interrupt priority incase of user interrupt (EIINT and EITBL).
	 * @causecode	Cause code in case of SYSERR
	 */
	virtual void RequestInterrupt(UI32 ptid, std::string name, UI32 channel, UI32 priority, UI32 causecode);

	/**
	 * @brief	Clear a interrupt request in simulator
	 * @ptid	Physical thread ID of current machine
	 * @name	Interrupt name
	 */
	virtual void ClearInterrupt(UI32 ptid, std::string name);


	/**
	 * 仮想アドレス-物理アドレス 変換処理インタフェース
	 *
	 * @param  isNC 　    [in]  取得先がネイテイブマシンならば true
	 * @param  htid 　    [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @param  vaddr      [in]  仮想アドレス
	 * @param  length     [in]  データサイズ（1:バイトアクセス、2;ハーフワードアクセス、4:ワードアクセス、8:ダブルワードアクセス。それ以外の指定は不可）
	 * @param  ac   　    [in]  アクセスタイプ
	 * @param  *paddr1    [out] 物理アドレス１
	 * @param  *length1   [out] 物理アドレス１レングス
	 * @param  *paddr2    [out] 物理アドレス２
	 * @param  *length2   [out] 物理アドレス２レングス
	 * @return isError 
	 * \n ERR_MMU_DISABLED					: MMUを搭載していないか、機能が有効になっていない
	 * \n ERR_MMU_PV						: アクセスするとアクセス権違反で例外が発生する
	 * \n ERR_MMU_ME						: アクセスするとTLB多重違反で例外が発生する
	 * \n ERR_MMU_PB						: アクセスするとTLB境界違反で例外が発生する
	 * \n ERR_MMU_NP						: アクセスするとTLB次ページ違反で例外が発生する
	 */
	virtual bool MmuTransferAddr( bool isNC , UI32 htid , UI32 vaddr , UI64 length , eMXU_ACCESS_TYPE ac , UI64  *paddr1 , UI64 *length1 , UI64 *paddr2 , UI64 *length2) ;

	/**
	 * @fn UI32 V850_MMU_TransferAddr( bool isNC ,UI32 htid , UI32 vaddr ,UI64 length ,UI32 AccessFlg ,UI64 *paddr1 ,UI64 *length1 ,UI32 *option1 ,UI64 *paddr2 ,UI64 *length2 ,UI32 *option2 ) ;
	 * 
	 * @brief
	 *  仮想アドレス-物理アドレス 変換処理
	 * 
	 * @param  isNC       [in]  取得先がネイテイブマシンならば true
	 * @param  htid       [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @param  vaddr      [in]  仮想アドレス
	 * @param  length     [in]  データサイズ（1:バイトアクセス、2;ハーフワードアクセス、4:ワードアクセス、8:ダブルワードアクセス。それ以外の指定は不可）
	 * @param  AccessFlg  [in]  アクセス種別 (MMU_BIT_UR、MMU_BIT_UW、MMU_BIT_UX、MMU_BIT_SR、MMU_BIT_SW、MMU_BIT_SXのいずれか。それ以外の指定は不可)
	 * @param  *paddr1    [out]	（省略可）物理アドレス１
	 * @param  *length1   [out]	（省略可）物理アドレス１レングス
	 * @param  *option1   [out]	（省略可）その他の情報１（ [0000_0000_0000 || S[3:0] || 0000_0000_0000 || PCC[3:0]] ）
	 * @param  *paddr2    [out]	（省略可）物理アドレス２       （次ページがある場合のみ値を格納）
	 * @param  *length2   [out]	（省略可）その他の情報２       （次ページがある場合のみ値を格納）
	 * @param  *option2   [out]	（省略可）物理アドレス２レングス（次ページがある場合のみ値を格納）
	 * 
	 * @return
	 *\n 	( [0000_00 || ME || PB || NP || V || SX || SW || SR || UX || UW || UR || 0000_0000_0000_0000] )
	 *\n ME:TLB多重一致例外、PB:TLBページ境界例外、NP:TLB次ページ例外、V:一致TLBエントリーが１つ以上在り、
	 *\n SX,SW,SR,UX,UW,UR:エラー検出時に要求したアクセス種別と同じ値が入る。（非エラー時６ビット全てに０が返る）
	 */
	UI32 V850_MMU_TransferAddr( bool isNC ,UI32 htid , UI32 vaddr ,UI64 length ,UI32 AccessFlg ,UI64 *paddr1 ,UI64 *length1 ,UI32 *option1 ,UI64 *paddr2 ,UI64 *length2 ,UI32 *option2 ) ;

	/**
	 * TLB検索処理
	 *
	 * @param  isNC 　    [in]  取得先がネイテイブマシンならば true
	 * @param  htid 　    [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @param  addr       [in]  仮想アドレス
	 * @param  AccessFlg  [in]  アクセス種別 (MMU_BIT_UR、MMU_BIT_UW、MMU_BIT_UX、MMU_BIT_SR、MMU_BIT_SW、MMU_BIT_SXのいずれか。それ以外の指定は不可)
	 * @param  *pIndex    [out] 合致するTLBエントリー番号
	 * 
	 * return
	 *\n ( [0000_00 || ME || 00 || V || SX || SW || SR || UX || UW || UR || 0000_0000_0000_0000] )
	 *\n ME:TLB多重一致例外、PB:TLBページ境界例外、NP:TLB次ページ例外、V:一致TLBエントリーが１つ以上在り、
	 *\n SX,SW,SR,UX,UW,UR:エラー検出時に要求したアクセス種別と同じ値が入る。（非エラー時６ビット全てに０が返る）
	 */
	UI32 V850_MMU_SearchTLB( bool isNC ,UI32 htid , UI64 addr , UI32 AccessFlg ,UI32 *pIndex ) ;

	/**
	 * メモリ保護区間情報リストの取得処理
	 *
	 * シミュレータの現行設定における、始端アドレスから終端アドレスまでのメモリ保護状態のリストを取得する。
	 *
	 * @param  *result    [out] メモリ保護区間情報リストへのポインタ
	 * @param  begin_adr  [in]  始端アドレス
	 * @param  end_adr    [in]  末端アドレス
	 * @param  isNC       [in]  取得先がネイテイブマシンならば true
	 * @param  htid       [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @param  ac         [in]  アクセスタイプ
	 * @return isError 
	 */
	virtual bool GetSegmentList(CSegmentList* &result , UI32 begin_adr , UI32 end_adr , eMXU_ACCESS_TYPE ac , UI32 htid , bool isNC ) ;

	/**
	 * メモリ保護区間情報リストの取得処理
	 *
	 * シミュレータの現行設定における、始端アドレスから終端アドレスまでのメモリ保護状態のリストを取得する。
	 *
	 * @param  *result    [out] メモリ保護区間情報リストへのポインタ
	 * @param  begin_adr  [in]  始端アドレス
	 * @param  end_adr    [in]  終端アドレス
	 * @param  ac         [in]  アクセス種別(リード／ライト／実行）
	 * @param  htid       [in]  取得先が仮想マシンの場合のスレッドＩＤ
	 * @return isError 
	 */
	virtual bool GetSegmentList(CSegmentList* &result , UI32 begin_adr , UI32 end_adr , eMXU_ACCESS_TYPE ac , UI32 htid ) ;


	/**
	 * 直近に実行した命令で行なったメモリデータアクセスの記録を取得する
	 *
	 * @param  read1_write0 [out]  True:リードアクセス  false:ライトアクセス 
	 * @param  addr         [out]  アクセスアドレス
	 * @param  byte         [out]  データバイト数
	 * @return isValid
	 */
	virtual bool PopMemAccessLog(UI32 &read1_write0 , UI64 &addr , UI32 &byte ) ;

	/**
	 * @brief set m_itrDataAccessInStep equal firt element of m_DataAccessInStep
	 *	Assign value for m_itrDataAccessInStep before get m_DataAccessInStep element.
	 * @param	index of memory in memory log
	 * @return	True: if index is valid, otherwise, false
	 */
	virtual bool SetMemVariable(UI32 idx);

	/**
	 * 直近に実行した命令で行なったメモリデータアクセスの記録を取得する
	 *
	 * @param  read1_write0 [out]  True:リードアクセス  false:ライトアクセス 
	 * @param  addr         [out]  アクセスアドレス
	 * @param  byte         [out]  データバイト数
	 * @param  value        [out]  アクセスデータ
	 * @return isValid
	 */
	virtual bool EachMemAccessLog(UI32 &read1_write0 , UI64 &addr , UI32 &byte , UI64 &value ) ;

	/**
	 * 直近に実行した命令によるメモリデータアクセス回数を取得する
	 *
	 * @return メモリデータアクセス回数
	 */
	virtual UI32 SizeMemAccessLog(void) {
        return m_DataAccessInStep.size() ;
    }

    void clear_statistics_memory(void) ;

	/*======================*/
    /* コールバック処理関数群 */
	/*======================*/

    /**
     * @brief NCレジスタ更新情報蓄積・ミラーリング処理を行なう
     */
	void update_nc_register(std::string regname, FrogRegData value, FrogRegData prev_value) ;
    /**
     * @brief VCレジスタ更新情報蓄積・ミラーリング処理を行なう
     */
	void update_vc_register(std::string regname, FrogRegData value, FrogRegData prev_value, UI32 vcid) ;
    /**
     * @brief TCレジスタ更新情報蓄積・ミラーリング処理を行なう
     */
	void update_tc_register(std::string regname, FrogRegData value, FrogRegData prev_value, UI32 tcid) ;
    /**
     * @brief メモリーアクセス情報蓄積処理を行なう
     */
	void update_generator_memory(UI64 address, UI32 size, UI64 value, UI64 prev_value, UI32 access_type, UI32 access_bus, UI32 load_action) ;
    /**
     * @brief メモリーアクセス情報を一時保存する。
     */
    void update_statistics_memory(UI64 address, UI32 size, UI32 access_type, UI32 access_bus, UI32 load_action, UI64 value );
    /**
     * @brief LLbit更新情報蓄積処理を行なう
     */
    void update_generator_llbit(UI64 address, UI32 size, bool isNt, UI32 tcid, const int32_t status) ;
    /**
     * @brief コメント情報処理を行なう
     */
    void insert_comment(std::string comment) ;
    /**
     * @brief TLBエントリー更新情報蓄積・ミラーリング処理を行なう
     */
    void update_generator_tlb(UI32 idx, UI32 l0, UI32 l1, UI32 h0, UI32 h1, UI32 l0_prev, UI32 l1_prev, UI32 h0_prev, UI32 h1_prev, UI32 access_type) ;
   
	/**
     * @brief Set memory accessed by operation code block to preset.
     * @addr: Memory address
	 * @size: Initialize size
	 * @value: Initialized value.
     * @return 
     */
	void SetSysMemPreset(UI64 addr, UI32 size, UI64 value);

	/**
     * @brief Get memory accessed by operation block.
     *
     * @return Pointer of Memory Writen Data Vector
     */
	void GetSysMemPreset(std::vector<T_MEMWRRECORD > * buff);

	void GetFPIUpdatedResource(CSimResource* res);

    bool IsNativeMachine (void);

    /**
    * @brief Check memory range from addr to addr + size whether it has preset yet
    * @return true if memory range do not preset
    */
    virtual bool IsInitMemory(UI64 addr, UI32 size);

    /**
    * @brief find memory has size which do not preset memory
    * @return start address of the memory area
    */
    virtual MEMADDR FindVacantMemory(UI32 size, UI64 align);

    /**
    * @brief Get value of MPLA register correspond to entry
    */
    virtual UI32 GetMPLA(UI32 entry) { return m_mpla[m_mpbk][entry]; }

    /**
    * @brief Get value of MPUA register correspond to entry
    */
    virtual UI32 GetMPUA(UI32 entry) { return m_mpua[m_mpbk][entry]; }

    /**
    * @brief Get value of MPAT register correspond to entry
    */
    virtual UI32 GetMPAT(UI32 entry) { return m_mpat[m_mpbk][entry]; }

protected:
	/**
	 * @fn UI32 CSimulator::GetAccessPermission(UI32 addr ,UI32 asid ,UI32 mpm) ;
	 *
	 * @brief
	 *   Obtain memory protection information
	 *
	 * @param[in]     addr			:Start address of access area
	 * @param[in]     asid			:If SPID = MPIDx, asid |= 1 << x. Otherwise, asid = 0.
	 * @param[in]     mpm			:MPM register value
	 *
	 * @return
	 *  Returns the access permission information of the protected area containing the specified address
     *  If there is more than one protection area, Permission is permit if there is a protection area is permit
	 */
	UI32 GetAccessPermission(UI32 addr ,UI32 asid ,UI32 mpm) ;

	/**
	 * @fn void UpdateMxuData( void ) ;
	 *
	 * @brief
	 *   MPU/MMUレジスタ値をISSから取り込む処理
	 */
	void InitMxuData( void ) ;

	/**
	 * @fn void UpdateMpuRgnData( void ) ;
	 *
	 * @brief
	 *   取り込んだMPPRTレジスタ値から、メモリ保護領域に対応するVM番号を算出します。
	 */
	void UpdateMpuRgnData( void ) ;

	/**
	 * @fn void UpdateThreadMapping( void ) ;
	 *
	 * @brief
	 *   取り込んだVMPRTレジスタ値から、スレッドに対応するVM番号を算出します。
	 */
	void UpdateThreadMapping();

	/**
	 * @brief	指定スレッドの試験区間情報リストが現在のシミュレータの状態と違った可能性があることを通知する。
	 */
	void MxuSetDirty(UI32 htid) {
		if (htid < m_htnum) {
			m_Seg[htid].SetDirty() ;
		}
		return ;
	}
	/**
	 * @brief	試験区間情報リストが現在のシミュレータの状態と違った可能性があることを通知する。
	 */
	void MxuSetDirty( void ) {
		for (UI32 htid= 0 ;htid < m_htnum ;htid++ ) {
			m_Seg[htid].SetDirty() ;
		}
		m_Seg[64].SetDirty();
		return ;
	}

protected:
    bool        m_bNM ;				//!< シミュレータがネイティブモード中であれば true
    UI32		m_nCauseCode ;		//!< シミュレータの全EIIC,FEIC,DBICのうち、最後に更新された**ICレジスタの値
    UI32		m_nPC ;				//!< シミュレータの全PCのうち、最後に更新されたPCの値
    UI32		m_nErrorInfo ;		//!< エラー発生時の詳細情報格納場所
	UI32		m_nUndoLogOn ;		//!< アンドゥ・コンテナへの積み込み制御スイッチ
	std::vector<T_LLBITRECORD>  m_vLLBit;
	std::vector<IUndoProfile*> m_Undo ;	//!< アンドゥ・コンテナ
    std::map<UI32, CPresetMemProfile*> m_mPresetMem;
    std::map<MEMADDR, MEMADDR> m_mVacancy; //!< variable to control memory of load memory which do not preset
	std::map<std::string, UI32> m_tags;	//!< タグ情報・コンテナ
	std::vector<UI32>			m_tagsIns;
	std::vector<DataAccessItem> m_DataAccessInStep ;	//!< １ステップ中に発生したメモリアクセスを記録するベクタ
	std::vector<DataAccessItem>::iterator m_itrDataAccessInStep; //!< １ステップ中に発生したメモリアクセスを記録するベクタイタレータ
	std::vector<CPresetMemProfile*>	m_SysMemPreset;

	bool		m_initialized ;		//!< true:シミュレータ初期化完了

    UI32        m_gmnum;
	UI32		m_vmnum;			//!< シミュレータに搭載しているＶＭ数
	UI32		m_htnum;			//!< シミュレータに搭載しているＨＴ数
	UI32		m_mpnum;			//!< シミュレータに搭載しているメモリ保護領域数（０の時、MPU非搭載）
	UI32		m_tlbnum;			//!< シミュレータに搭載しているTLBエントリー数（０の時、MMU非搭載）
	UI32		m_bpnum;			//!< シミュレータに搭載しているブレークポイントチャネル数
	bool		m_smallpage ;		//!< シミュレータに搭載しているMMU最小ページサイズ（true:1k Byte / false:4k Byte）

	CSegmentList m_Seg[65];			//!< 区間リスト(HT#0〜HT#63,NT)のキャッシュ

	UI32		m_vcid_table[64] ;	//!< スレッド→VM番号 対応表

	UI32		m_vmprt[4/*0*/] ;		//!< シミュレータのVMPRT0~VMPRT3レジスタのミラー

	UI32		m_mpprt[3] ;		//!< シミュレータのMPPRT0~MPPRT3レジスタのミラー 

    // Define 2 bank of MPU, each bank has 32 register of each type MPLA, MPUA, MPAT
	UI32		m_mpla[2][32] ;		
	UI32		m_mpua[2][32] ;		
	UI32		m_mpat[2][32] ;		
	UI32		m_mpvm[32] ;		//!< メモリ保護領域に割当たっているVM。bit0~7がVM0~7に対応。値が0のときNMに割り当たっていることを表す。 
	UI32		m_spid;
	UI32		m_mpid[8];
    UI32        m_mpbk;         //!<  MPBK register


	UI32		m_telo0[64] ;		//!< シミュレータのTLBエントリー値のミラー 
	UI32		m_telo1[64] ;		//!< シミュレータのTLBエントリー値のミラー 
	UI32		m_tehi0[64] ;		//!< シミュレータのTLBエントリー値のミラー 
	UI32		m_tehi1[64] ;		//!< シミュレータのTLBエントリー値のミラー 

	UI32		m_psw[65] ;			//!< シミュレータのPSW(HT#0〜HT#63,NT)レジスタのミラー
	UI32		m_asid[65] ;		//!< シミュレータのASID(HT#0〜HT#63,NT)レジスタのミラー
	UI32		m_mpm[9] ;			//!< シミュレータのMPM(VM#0〜VM#7,NM)レジスタのミラー
	UI32		m_mcfg0[9] ;		//!< シミュレータのMCFG0(VM#0〜VM#7,NM)レジスタのミラー
	UI32		m_dir0[9] ;			//!< シミュレータのDIR0(VM#0〜VM#7,NM)レジスタのミラー
	UI32		m_pswh;			//!< シミュレータのPSW(HT#0〜HT#63,NT)レジスタのミラー
    UI32        m_gmmpm;            //!<  GMMPM register
    UI32        m_gmpsw;            //!<  GMPSW register
    UI32        m_hvcfg;            //!<  HVCFG register
};



#endif /*SIMULATOR_H_*/

/* end of file */
