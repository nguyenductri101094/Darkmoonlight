#include "insid_set.h"
#include "rtg_cfg.h"

CInstructionSet::CInstructionSet()
 :	IInstructionSet(&g_rnd), 
 	m_ldArrayNum(2,8), m_stArrayNum(2,8), m_lsArrayNum(2,8),
 	m_sldArrayNum(2,8), m_sstArrayNum(2,8), m_slsArrayNum(2,8),
    m_caxiArrayNum(2,8),
 	m_ldIns(&g_rnd), m_stIns(&g_rnd), m_lsIns(&g_rnd),
 	m_sldIns(&g_rnd), m_sstIns(&g_rnd), m_slsIns(&g_rnd),
    m_caxiIns(&g_rnd)
{
}

CInstructionSet::~CInstructionSet() {
}


void CInstructionSet::DefaultSet() {
	m_wrIns.Clear();
	//Default value for sequencial instruction
	std::pair<UI32, UI32> p = std::pair<UI32, UI32> (1, 1);

	for (INS_ID x = 1; x <= NUM_OF_INS; x++) {
		m_wrIns.Set(x, BASE_WEIGHT);
		m_seqInsNum.insert(std::pair<UI32, std::pair<UI32, UI32>>(x, p));
	}
    FilterCategory( 1 << IInstruction::ICAT_FPU_S, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_FPU_D, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_FPU_D, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_SIMD, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_MPU, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_MMU, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_DEBUG, 0 ); 
    FilterCategory( 1 << IInstruction::ICAT_SPECIAL, 0 ); 
    FilterBehavior( 1 << IInstruction::LOAD_MEMORY, 0 ); 
    FilterBehavior( 1 << IInstruction::STORE_MEMORY, 0 ); 
    FilterBehavior( 1 << IInstruction::STORE_MEMORY, 0 ); 
    FilterBehavior( 1 << IInstruction::JMP, 0 ); 
    FilterPriviledge( 1 << IInstruction::IPRIV_CU0, 0 ); 
    FilterPriviledge( 1 << IInstruction::IPRIV_CU1, 0 ); 
    FilterPriviledge( 1 << IInstruction::IPRIV_CU2, 0 ); 
    FilterPriviledge( 1 << IInstruction::IPRIV_SV, 0 ); 
    FilterPriviledge( 1 << IInstruction::IPRIV_HV, 0 ); 
    FilterPriviledge( 1 << IInstruction::IPRIV_DB, 0 ); 
}


UI32 CInstructionSet::FilterCategory(BS_ICAT mask, BS_ICAT val) {
	
	std::set<INS_ID> kset = m_wrIns.KeySet();
	
	// 種別情報についてmaskで指定されたビットがvalに等しくない場合、候補から削除する
	for (std::set<INS_ID>::iterator i = kset.begin();i != kset.end(); i++) {
		IInstruction*	pIns = CreateIns(*i);
		if (pIns != nullptr) {
			if ((mask.to_ulong() & pIns->GetCategory()) != (mask.to_ulong() & val.to_ulong())) {
				m_wrIns.Delete(*i);
			}
			delete pIns;
		}
	}
	m_wrIns.ReCalc();
	return m_wrIns.Count();	
}


UI32 CInstructionSet::FilterPriviledge(BS_IPRV mask, BS_IPRV val) {
	
	std::set<INS_ID> kset = m_wrIns.KeySet();
	
	// 権限情報についてmaskで指定されたビットがvalに等しくない場合、候補から削除する
	for (std::set<INS_ID>::iterator i = kset.begin(); i != kset.end(); i++) {
		IInstruction*	pIns = CreateIns(*i);
		if (pIns != nullptr) {
			if ((mask.to_ulong() & pIns->GetPriviledge()) != (mask.to_ulong() & val.to_ulong())) {
				m_wrIns.Delete(*i);
			}
			delete pIns;
		}
	}
	m_wrIns.ReCalc();
	return m_wrIns.Count();	
}


UI32 CInstructionSet::FilterBehavior(BS_IBHV mask, BS_IBHV val) {
	
	std::set<INS_ID>	kset = m_wrIns.KeySet();
	
	// 振舞情報についてmaskで指定されたビットがvalに等しくない場合、候補から削除する
	for (std::set<INS_ID>::iterator i = kset.begin(); i != kset.end(); i++) {
		IInstruction*	pIns = CreateIns(*i);
		if (pIns != nullptr) {
			if ((mask.to_ulong() & pIns->GetBehavior()) != (mask.to_ulong() & val.to_ulong())) {
				m_wrIns.Delete(*i);
			}
			delete pIns;
		}
	}
	m_wrIns.ReCalc();
	return m_wrIns.Count();	
}


IInstruction* CInstructionSet::CreateIns() {
	_ASSERT(m_wrIns.Count());
	INS_ID id = m_wrIns.GetObj();
	return this->CreateIns(id);
}

bool CInstructionSet::BannedLsIns(INS_ID insid) {
	if ( insid == CIns_466_ldv_dw::m_id || insid == CIns_470_ldv_qw::m_id || insid == CIns_474_ldv_w::m_id || insid == CIns_484_ldvz_h4::m_id 
	|| insid == CIns_488_stv_dw::m_id || insid == CIns_492_stv_qw::m_id || insid == CIns_496_stv_w::m_id || insid == CIns_506_stvz_h4::m_id ) {
		return true;
	}
	return false;
}

void CInstructionSet::MakeLdIns() {
	m_ldIns.Clear ();
	for (INS_ID I = CIns_87_ld_b::m_id; I <= CIns_97_ld_w::m_id; I++) {
		m_ldIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_ldIns.ReCalc ();

	if (m_ldArrayNum.first == 0) {
		m_ldArrayNum.first = 1;
	}
	if (m_ldArrayNum.first > m_ldArrayNum.second) {
		m_ldArrayNum.second = m_ldArrayNum.first;
	}

	// Short format
	m_sldIns.Clear ();
	for (INS_ID I = CIns_156_sld_b::m_id; I <= CIns_160_sld_w::m_id; I++) {
		m_sldIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_sldIns.ReCalc ();

	if (m_sldArrayNum.first == 0) {
		m_sldArrayNum.first = 1;
	}
	if (m_sldArrayNum.first > m_sldArrayNum.second) {
		m_sldArrayNum.second = m_sldArrayNum.first;
	}

	// FPSIMD
	for (INS_ID I = CIns_467_ldv_dw::m_id; I <= CIns_487_ldvz_h4::m_id; I++) {
		if (BannedLsIns(I)) continue;
		m_ldIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_ldIns.ReCalc ();

	if (m_ldArrayNum.first == 0) {
		m_ldArrayNum.first = 1;
	}
	if (m_ldArrayNum.first > m_ldArrayNum.second) {
		m_ldArrayNum.second = m_ldArrayNum.first;
	}
	
	// G4MH
	for (INS_ID I = CIns_637_ld_b_inc::m_id; I <= CIns_646_ld_w_dec::m_id; I++) {
		m_ldIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_ldIns.ReCalc ();

	if (m_ldArrayNum.first == 0) {
		m_ldArrayNum.first = 1;
	}
	if (m_ldArrayNum.first > m_ldArrayNum.second) {
		m_ldArrayNum.second = m_ldArrayNum.first;
	}

	// G4MH-LDL
	for (INS_ID I = CIns_661_ldl_bu::m_id; I <= CIns_662_ldl_hu::m_id; I++) {
		m_ldIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_ldIns.ReCalc ();

	if (m_ldArrayNum.first == 0) {
		m_ldArrayNum.first = 1;
	}
	if (m_ldArrayNum.first > m_ldArrayNum.second) {
		m_ldArrayNum.second = m_ldArrayNum.first;
	}

}


void CInstructionSet::MakeStIns() {
	m_stIns.Clear();
	for (INS_ID I = CIns_165_st_b::m_id; I <= CIns_171_st_w::m_id; I++) {
		m_stIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_stIns.ReCalc ();

	if (m_stArrayNum.first == 0) {
		m_stArrayNum.first = 1;
	}
	if (m_stArrayNum.first > m_stArrayNum.second) {
		m_stArrayNum.second = m_stArrayNum.first;
	}

	
	// Short format
	m_sstIns.Clear();
	for (INS_ID I = CIns_162_sst_b::m_id; I <= CIns_164_sst_w::m_id; I++) {
		m_sstIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_sstIns.ReCalc ();

	if (m_sstArrayNum.first == 0) {
		m_sstArrayNum.first = 1;
	}
	if (m_sstArrayNum.first > m_sstArrayNum.second) {
		m_sstArrayNum.second = m_sstArrayNum.first;
	}

	//FPSIMD
	for (INS_ID I = CIns_489_stv_dw::m_id; I <= CIns_509_stvz_h4::m_id; I++) {
		if (BannedLsIns(I)) continue;
		m_stIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_stIns.ReCalc ();

	if (m_stArrayNum.first == 0) {
		m_stArrayNum.first = 1;
	}
	if (m_stArrayNum.first > m_stArrayNum.second) {
		m_stArrayNum.second = m_stArrayNum.first;
	}

	// G4MH
	for (INS_ID I = CIns_649_st_b_inc::m_id; I <= CIns_654_st_w_dec::m_id; I++) {
		m_stIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_stIns.ReCalc ();

	if (m_stArrayNum.first == 0) {
		m_stArrayNum.first = 1;
	}
	if (m_stArrayNum.first > m_stArrayNum.second) {
		m_stArrayNum.second = m_stArrayNum.first;
	}

	// G4MH-STC
	for (INS_ID I = CIns_664_stc_b::m_id; I <= CIns_665_stc_h::m_id; I++) {
		m_stIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_stIns.ReCalc ();

	if (m_stArrayNum.first == 0) {
		m_stArrayNum.first = 1;
	}
	if (m_stArrayNum.first > m_stArrayNum.second) {
		m_stArrayNum.second = m_stArrayNum.first;
	}

}


void CInstructionSet::MakeLsIns() {
	m_lsIns.Clear();
	for (INS_ID I = CIns_87_ld_b::m_id; I <= CIns_97_ld_w::m_id; I++) {
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	for (INS_ID I = CIns_165_st_b::m_id; I <= CIns_171_st_w::m_id; I++) {
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_lsIns.ReCalc ();

	if (m_lsArrayNum.first == 0) {
		m_lsArrayNum.first = 1;
	}
	if (m_lsArrayNum.first > m_lsArrayNum.second) {
		m_lsArrayNum.second = m_lsArrayNum.first;
	}
	
	// Short format
	m_slsIns.Clear();
	for (INS_ID I = CIns_156_sld_b::m_id; I <= CIns_160_sld_w::m_id; I++) {
		m_slsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	for (INS_ID I = CIns_162_sst_b::m_id; I <= CIns_164_sst_w::m_id; I++) {
		m_slsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_slsIns.ReCalc ();

	if (m_slsArrayNum.first == 0) {
		m_slsArrayNum.first = 1;
	}
	if (m_slsArrayNum.first > m_slsArrayNum.second) {
		m_slsArrayNum.second = m_slsArrayNum.first;
	}

	//FPSIMD
	for (INS_ID I = CIns_467_ldv_dw::m_id; I <= CIns_475_ldv_w::m_id; I++) {
		if (BannedLsIns(I)) continue;
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	for (INS_ID I = CIns_489_stv_dw::m_id; I <= CIns_509_stvz_h4::m_id; I++) {
		if (BannedLsIns(I)) continue;
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_lsIns.ReCalc ();

	if (m_lsArrayNum.first == 0) {
		m_lsArrayNum.first = 1;
	}
	if (m_lsArrayNum.first > m_lsArrayNum.second) {
		m_lsArrayNum.second = m_lsArrayNum.first;
	}

	// G4MH
	for (INS_ID I = CIns_637_ld_b_inc::m_id; I <= CIns_654_st_w_dec::m_id; I++) {
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_lsIns.ReCalc ();

	if (m_lsArrayNum.first == 0) {
		m_lsArrayNum.first = 1;
	}
	if (m_lsArrayNum.first > m_lsArrayNum.second) {
		m_lsArrayNum.second = m_lsArrayNum.first;
	}

	//G4MH-LDL-STC
	for (INS_ID I = CIns_661_ldl_bu::m_id; I <= CIns_662_ldl_hu::m_id; I++) {
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	for (INS_ID I = CIns_664_stc_b::m_id; I <= CIns_665_stc_h::m_id; I++) {
		m_lsIns.Set (I, m_wrIns.GetWeight(I));
	} 
	m_lsIns.ReCalc ();

	if (m_lsArrayNum.first == 0) {
		m_lsArrayNum.first = 1;
	}
	if (m_lsArrayNum.first > m_lsArrayNum.second) {
		m_lsArrayNum.second = m_lsArrayNum.first;
	}
}


void CInstructionSet::MakeCaxiIns() {
	m_caxiIns.Clear();

	INS_ID I = CIns_54_caxi::m_id ;
	m_caxiIns.Set(I, m_wrIns.GetWeight(I)) ;
	m_caxiIns.ReCalc ();

	if (m_caxiArrayNum.first == 0) {
		m_caxiArrayNum.first = 1;
	}
	if (m_caxiArrayNum.first  > m_caxiArrayNum.second) {
		m_caxiArrayNum.second = m_caxiArrayNum.first;
	}
}


static LPCTSTR weight_keys[]=
{
     "Ins_001_add"          ,"Ins_002_add"          ,"Ins_003_addi"         ,"Ins_004_adf"          
    ,"Ins_005_and"          ,"Ins_006_andi"         ,"Ins_007_bc"           ,"Ins_008_be"           
    ,"Ins_009_bf"           ,"Ins_010_bge"          ,"Ins_011_bgt"          ,"Ins_012_bh"           
    ,"Ins_013_ble"          ,"Ins_014_bl"           ,"Ins_015_blt"          ,"Ins_016_bn"           
    ,"Ins_017_bnc"          ,"Ins_018_bne"          ,"Ins_019_bnh"          ,"Ins_020_bnl"          
    ,"Ins_021_bnv"          ,"Ins_022_bnz"          ,"Ins_023_bp"           ,"Ins_024_br"           
    ,"Ins_025_bsa"          ,"Ins_026_bt"           ,"Ins_027_bv"           ,"Ins_028_bz"           
    ,"Ins_029_bc"           ,"Ins_030_be"           ,"Ins_031_bf"           ,"Ins_032_bge"          
    ,"Ins_033_bgt"          ,"Ins_034_bh"           ,"Ins_035_ble"          ,"Ins_036_bl"           
    ,"Ins_037_blt"          ,"Ins_038_bn"           ,"Ins_039_bnc"          ,"Ins_040_bne"          
    ,"Ins_041_bnh"          ,"Ins_042_bnl"          ,"Ins_043_bnv"          ,"Ins_044_bnz"          
    ,"Ins_045_bp"           ,"Ins_046_bsa"          ,"Ins_047_bt"           ,"Ins_048_bv"           
    ,"Ins_049_bz"           ,"Ins_050_bins"         ,"Ins_051_bsh"          ,"Ins_052_bsw"          
    ,"Ins_053_callt"        ,"Ins_054_caxi"         ,"Ins_055_cll"          ,"Ins_056_clr1"         
    ,"Ins_057_clr1"         ,"Ins_058_cmov"         ,"Ins_059_cmov"         ,"Ins_060_cmp"          
    ,"Ins_061_cmp"          ,"Ins_062_ctret"        ,"Ins_063_di"           ,"Ins_064_dispose"      
    ,"Ins_065_dispose"      ,"Ins_066_div"          ,"Ins_067_divh"         ,"Ins_068_divh"         
    ,"Ins_069_divhu"        ,"Ins_070_divq"         ,"Ins_071_divqu"        ,"Ins_072_divu"         
    ,"Ins_073_ei"           ,"Ins_074_eiret"        ,"Ins_075_feret"        ,"Ins_076_fetrap"       
    ,"Ins_077_halt"         ,"Ins_078_hsh"          ,"Ins_079_hsw"          ,"Ins_080_jarl"         
    ,"Ins_081_jarl"         ,"Ins_082_jarl"         ,"Ins_083_jmp"          ,"Ins_084_jmp"          
    ,"Ins_085_jr"           ,"Ins_086_jr"           ,"Ins_087_ld_b"         ,"Ins_088_ld_b"         
    ,"Ins_089_ld_bu"        ,"Ins_090_ld_bu"        ,"Ins_091_ld_dw"        ,"Ins_092_ld_h"         
    ,"Ins_093_ld_h"         ,"Ins_094_ld_hu"        ,"Ins_095_ld_hu"        ,"Ins_096_ld_w"         
    ,"Ins_097_ld_w"         ,"Ins_098_ldl_w"        ,"Ins_099_ldsr"         ,"Ins_100_loop"         
    ,"Ins_101_mac"          ,"Ins_102_macu"         ,"Ins_103_mov"          ,"Ins_104_mov"          
    ,"Ins_105_mov"          ,"Ins_106_movea"        ,"Ins_107_movhi"        ,"Ins_108_mul"          
    ,"Ins_109_mul"          ,"Ins_110_mulh"         ,"Ins_111_mulh"         ,"Ins_112_mulhi"        
    ,"Ins_113_mulu"         ,"Ins_114_mulu"         ,"Ins_115_nop"          ,"Ins_116_not"          
    ,"Ins_117_not1"         ,"Ins_118_not1"         ,"Ins_119_or"           ,"Ins_120_ori"          
    ,"Ins_121_popsp"        ,"Ins_122_prepare"      ,"Ins_123_prepare"      ,"Ins_124_prepare"      
    ,"Ins_125_prepare"      ,"Ins_126_pushsp"       ,"Ins_127_rie"          ,"Ins_128_rie"          
    ,"Ins_129_rotl"         ,"Ins_130_rotl"         ,"Ins_131_sar"          ,"Ins_132_sar"          
    ,"Ins_133_sar"          ,"Ins_134_sasf"         ,"Ins_135_satadd"       ,"Ins_136_satadd"       
    ,"Ins_137_satadd"       ,"Ins_138_satsub"       ,"Ins_139_satsub"       ,"Ins_140_satsubi"      
    ,"Ins_141_satsubr"      ,"Ins_142_sbf"          ,"Ins_143_sch0l"        ,"Ins_144_sch0r"        
    ,"Ins_145_sch1l"        ,"Ins_146_sch1r"        ,"Ins_147_set1"         ,"Ins_148_set1"         
    ,"Ins_149_setf"         ,"Ins_150_shl"          ,"Ins_151_shl"          ,"Ins_152_shl"          
    ,"Ins_153_shr"          ,"Ins_154_shr"          ,"Ins_155_shr"          ,"Ins_156_sld_b"        
    ,"Ins_157_sld_bu"       ,"Ins_158_sld_h"        ,"Ins_159_sld_hu"       ,"Ins_160_sld_w"        
    ,"Ins_161_snooze"       ,"Ins_162_sst_b"        ,"Ins_163_sst_h"        ,"Ins_164_sst_w"        
    ,"Ins_165_st_b"         ,"Ins_166_st_b"         ,"Ins_167_st_dw"        ,"Ins_168_st_h"         
    ,"Ins_169_st_h"         ,"Ins_170_st_w"         ,"Ins_171_st_w"         ,"Ins_172_stc_w"        
    ,"Ins_173_stsr"         ,"Ins_174_sub"          ,"Ins_175_subr"         ,"Ins_176_switch"       
    ,"Ins_177_sxb"          ,"Ins_178_sxh"          ,"Ins_179_synce"        ,"Ins_180_synci"        
    ,"Ins_181_syncm"        ,"Ins_182_syncp"        ,"Ins_183_syscall"      ,"Ins_184_trap"         
    ,"Ins_185_tst"          ,"Ins_186_tst1"         ,"Ins_187_tst1"         ,"Ins_188_xor"          
    ,"Ins_189_xori"         ,"Ins_190_zxb"          ,"Ins_191_zxh"          ,"Ins_192_hvcall"       
    ,"Ins_193_hvtrap"       ,"Ins_194_ldvc_sr"      ,"Ins_195_stvc_sr"      ,"Ins_196_dst"          
    ,"Ins_197_est"          ,"Ins_198_ldtc_gr"      ,"Ins_199_ldtc_vr"      ,"Ins_200_ldtc_pc"      
    ,"Ins_201_ldtc_sr"      ,"Ins_202_sttc_gr"      ,"Ins_203_sttc_vr"      ,"Ins_204_sttc_pc"      
    ,"Ins_205_sttc_sr"      ,"Ins_206_cache"        ,"Ins_207_pref"         ,"Ins_208_tlbai"        
    ,"Ins_209_tlbr"         ,"Ins_210_tlbs"         ,"Ins_211_tlbvi"        ,"Ins_212_tlbw"         
    ,"Ins_213_dbcp"         ,"Ins_214_dbhvtrap"     ,"Ins_215_dbpush"       ,"Ins_216_dbret"        
    ,"Ins_217_dbtag"        ,"Ins_218_dbtrap"       ,"Ins_219_rmtrap"       ,"Ins_220_absf_d"       
    ,"Ins_221_absf_s"       ,"Ins_222_addf_d"       ,"Ins_223_addf_s"       ,"Ins_224_ceilf_dl"     
    ,"Ins_225_ceilf_dul"    ,"Ins_226_ceilf_duw"    ,"Ins_227_ceilf_dw"     ,"Ins_228_ceilf_sl"     
    ,"Ins_229_ceilf_sul"    ,"Ins_230_ceilf_suw"    ,"Ins_231_ceilf_sw"     ,"Ins_232_cmovf_d"      
    ,"Ins_233_cmovf_s"      ,"Ins_234_cmpf_d"       ,"Ins_235_cmpf_s"       ,"Ins_236_cvtf_dl"      
    ,"Ins_237_cvtf_ds"      ,"Ins_238_cvtf_dul"     ,"Ins_239_cvtf_duw"     ,"Ins_240_cvtf_dw"      
    ,"Ins_241_cvtf_hs"      ,"Ins_242_cvtf_ld"      ,"Ins_243_cvtf_ls"      ,"Ins_244_cvtf_sd"      
    ,"Ins_245_cvtf_sl"      ,"Ins_246_cvtf_sh"      ,"Ins_247_cvtf_sul"     ,"Ins_248_cvtf_suw"     
    ,"Ins_249_cvtf_sw"      ,"Ins_250_cvtf_uld"     ,"Ins_251_cvtf_uls"     ,"Ins_252_cvtf_uwd"     
    ,"Ins_253_cvtf_uws"     ,"Ins_254_cvtf_wd"      ,"Ins_255_cvtf_ws"      ,"Ins_256_divf_d"       
    ,"Ins_257_divf_s"       ,"Ins_258_floorf_dl"    ,"Ins_259_floorf_dul"   ,"Ins_260_floorf_duw"   
    ,"Ins_261_floorf_dw"    ,"Ins_262_floorf_sl"    ,"Ins_263_floorf_sul"   ,"Ins_264_floorf_suw"   
    ,"Ins_265_floorf_sw"    ,"Ins_266_fmaf_s"       ,"Ins_267_fmsf_s"       ,"Ins_268_fnmaf_s"      
    ,"Ins_269_fnmsf_s"      ,"Ins_270_maddf_s"      ,"Ins_271_maxf_d"       ,"Ins_272_maxf_s"       
    ,"Ins_273_minf_d"       ,"Ins_274_minf_s"       ,"Ins_275_msubf_s"      ,"Ins_276_mulf_d"       
    ,"Ins_277_mulf_s"       ,"Ins_278_negf_d"       ,"Ins_279_negf_s"       ,"Ins_280_nmaddf_s"     
    ,"Ins_281_nmsubf_s"     ,"Ins_282_recipf_d"     ,"Ins_283_recipf_s"     ,"Ins_284_roundf_dl"    
    ,"Ins_285_roundf_dul"   ,"Ins_286_roundf_duw"   ,"Ins_287_roundf_dw"    ,"Ins_288_roundf_sl"    
    ,"Ins_289_roundf_sul"   ,"Ins_290_roundf_suw"   ,"Ins_291_roundf_sw"    ,"Ins_292_rsqrtf_d"     
    ,"Ins_293_rsqrtf_s"     ,"Ins_294_sqrtf_d"      ,"Ins_295_sqrtf_s"      ,"Ins_296_subf_d"       
    ,"Ins_297_subf_s"       ,"Ins_298_trfsr"        ,"Ins_299_trncf_dl"     ,"Ins_300_trncf_dul"    
    ,"Ins_301_trncf_duw"    ,"Ins_302_trncf_dw"     ,"Ins_303_trncf_sl"     ,"Ins_304_trncf_sul"    
    ,"Ins_305_trncf_suw"    ,"Ins_306_trncf_sw"     ,"Ins_307_cnvq15q30"    ,"Ins_308_cnvq30q15"    
    ,"Ins_309_cnvq31q62"    ,"Ins_310_cnvq62q31"    ,"Ins_311_dup_h"        ,"Ins_312_dup_w"        
    ,"Ins_313_expq31"       ,"Ins_314_modadd"       ,"Ins_315_mov_dw"       ,"Ins_316_mov_dw"       
    ,"Ins_317_mov_h"        ,"Ins_318_mov_w"        ,"Ins_319_mov_w"        ,"Ins_320_mov_w"        
    ,"Ins_321_pki16i32"     ,"Ins_322_pki16ui8"     ,"Ins_323_pki32i16"     ,"Ins_324_pki64i32"     
    ,"Ins_325_pkq15q31"     ,"Ins_326_pkq30q31"     ,"Ins_327_pkq31q15"     ,"Ins_328_pkui8i16"     
    ,"Ins_329_vabs_h"       ,"Ins_330_vabs_w"       ,"Ins_331_vadd_dw"      ,"Ins_332_vadd_h"       
    ,"Ins_333_vadd_w"       ,"Ins_334_vadds_h"      ,"Ins_335_vadds_w"      ,"Ins_336_vaddsat_h"    
    ,"Ins_337_vaddsat_w"    ,"Ins_338_vand"         ,"Ins_339_vbiq_h"       ,"Ins_340_vbswap_dw"    
    ,"Ins_341_vbswap_h"     ,"Ins_342_vbswap_w"     ,"Ins_343_vcalc_h"      ,"Ins_344_vcalc_w"      
    ,"Ins_345_vcmov"        ,"Ins_346_vcmpeq_h"     ,"Ins_347_vcmpeq_w"     ,"Ins_348_vcmple_h"     
    ,"Ins_349_vcmple_w"     ,"Ins_350_vcmplt_h"     ,"Ins_351_vcmplt_w"     ,"Ins_352_vcmpne_h"     
    ,"Ins_353_vcmpne_w"     ,"Ins_354_vconcat_b"    ,"Ins_355_vitlv_h"      ,"Ins_356_vitlv_w"      
    ,"Ins_357_vitlvhw_h"    ,"Ins_358_vitlvwh_h"    ,"Ins_359_vld_b"        ,"Ins_360_vld_b"        
    ,"Ins_361_vld_b"        ,"Ins_362_vld_b"        ,"Ins_363_vld_dw"       ,"Ins_364_vld_dw"       
    ,"Ins_365_vld_dw"       ,"Ins_366_vld_dw"       ,"Ins_367_vld_dw"       ,"Ins_368_vld_h"        
    ,"Ins_369_vld_h"        ,"Ins_370_vld_h"        ,"Ins_371_vld_h"        ,"Ins_372_vld_w"        
    ,"Ins_373_vld_w"        ,"Ins_374_vld_w"        ,"Ins_375_vld_w"        ,"Ins_376_vmadrn_h"     
    ,"Ins_377_vmadrn_w"     ,"Ins_378_vmadsat_h"    ,"Ins_379_vmadsat_w"    ,"Ins_380_vmaxge_h"     
    ,"Ins_381_vmaxge_w"     ,"Ins_382_vmaxgt_h"     ,"Ins_383_vmaxgt_w"     ,"Ins_384_vminle_h"     
    ,"Ins_385_vminle_w"     ,"Ins_386_vminlt_h"     ,"Ins_387_vminlt_w"     ,"Ins_388_vmsum_h"      
    ,"Ins_389_vmsum_w"      ,"Ins_390_vmsumad_h"    ,"Ins_391_vmsumad_w"    ,"Ins_392_vmsumadim_h"  
    ,"Ins_393_vmsumadim_w"  ,"Ins_394_vmsumadre_h"  ,"Ins_395_vmsumadre_w"  ,"Ins_396_vmsumadrn_h"  
    ,"Ins_397_vmsumadrn_w"  ,"Ins_398_vmul_h"       ,"Ins_399_vmul_w"       ,"Ins_400_vmulcx_h"     
    ,"Ins_401_vmulcx_w"     ,"Ins_402_vmult_h"      ,"Ins_403_vmult_w"      ,"Ins_404_vneg_h"       
    ,"Ins_405_vneg_w"       ,"Ins_406_vnot"         ,"Ins_407_vor"          ,"Ins_408_vsar_dw"      
    ,"Ins_409_vsar_dw"      ,"Ins_410_vsar_h"       ,"Ins_411_vsar_h"       ,"Ins_412_vsar_w"       
    ,"Ins_413_vsar_w"       ,"Ins_414_vshl_dw"      ,"Ins_415_vshl_dw"      ,"Ins_416_vshl_h"       
    ,"Ins_417_vshl_h"       ,"Ins_418_vshl_w"       ,"Ins_419_vshl_w"       ,"Ins_420_vshr_dw"      
    ,"Ins_421_vshr_dw"      ,"Ins_422_vshr_h"       ,"Ins_423_vshr_h"       ,"Ins_424_vshr_w"       
    ,"Ins_425_vshr_w"       ,"Ins_426_vshufl_b"     ,"Ins_427_vst_b"        ,"Ins_428_vst_b"        
    ,"Ins_429_vst_b"        ,"Ins_430_vst_b"        ,"Ins_431_vst_dw"       ,"Ins_432_vst_dw"       
    ,"Ins_433_vst_dw"       ,"Ins_434_vst_dw"       ,"Ins_435_vst_dw"       ,"Ins_436_vst_dw"       
    ,"Ins_437_vst_h"        ,"Ins_438_vst_h"        ,"Ins_439_vst_h"        ,"Ins_440_vst_h"        
    ,"Ins_441_vst_h"        ,"Ins_442_vst_w"        ,"Ins_443_vst_w"        ,"Ins_444_vst_w"        
    ,"Ins_445_vst_w"        ,"Ins_446_vst_w"        ,"Ins_447_vsub_dw"      ,"Ins_448_vsub_h"       
    ,"Ins_449_vsub_w"       ,"Ins_450_vsubs_h"      ,"Ins_451_vsubs_w"      ,"Ins_452_vsubsat_h"    
    ,"Ins_453_vsubsat_w"    ,"Ins_454_vxor"         ,"Ins_455__word"        ,"Ins_456__short"

	// FP-SIMD Instruction ...
	,"Ins_457_cmovf_w4"      ,"Ins_458_movv_w2"      ,"Ins_459_movv_w4"      ,"Ins_460_movvg_w"     
	,"Ins_461_movvi"        ,"Ins_462_flpv_s2"      ,"Ins_463_flpv_s4"      ,"Ins_464_shflv_w2"     
	,"Ins_465_shflv_w4"     ,"Ins_466_ldv_dw"       ,"Ins_467_ldv_dw"       ,"Ins_468_ldv_dw"       
	,"Ins_469_ldv_dw"       ,"Ins_470_ldv_qw"       ,"Ins_471_ldv_qw"       ,"Ins_472_ldv_qw"       
	,"Ins_473_ldv_qw"       ,"Ins_474_ldv_w"        ,"Ins_475_ldv_w"        ,"Ins_476_ldv_w"        
	,"Ins_477_ldv_w"        ,"Ins_478_ldvgtr2_w"    ,"Ins_479_ldvgtr4_w"    ,"Ins_480_ldvpgtr2_w"   
	,"Ins_481_ldvpgtr4_w"   ,"Ins_482_ldvz_h1"      ,"Ins_483_ldvz_h2"      ,"Ins_484_ldvz_h4"      
	,"Ins_485_ldvz_h1"      ,"Ins_486_ldvz_h2"      ,"Ins_487_ldvz_h4"      ,"Ins_488_stv_dw"       
	,"Ins_489_stv_dw"       ,"Ins_490_stv_dw"       ,"Ins_491_stv_dw"       ,"Ins_492_stv_qw"       
	,"Ins_493_stv_qw"       ,"Ins_494_stv_qw"       ,"Ins_495_stv_qw"       ,"Ins_496_stv_w"        
	,"Ins_497_stv_w"        ,"Ins_498_stv_w"        ,"Ins_499_stv_w"        ,"Ins_500_stvpsct2_w"   
	,"Ins_501_stvpsct4_w"   ,"Ins_502_stvsct2_w"    ,"Ins_503_stvsct4_w"    ,"Ins_504_stvz_h1"      
	,"Ins_505_stvz_h2"      ,"Ins_506_stvz_h4"      ,"Ins_507_stvz_h1"      ,"Ins_508_stvz_h2"      
	,"Ins_509_stvz_h4"      ,"Ins_510_cmov_w1"      ,"Ins_511_cmov_w2"      ,"Ins_512_cmov_w4"      
	,"Ins_513_trfsrv_w2"    ,"Ins_514_trfsrv_w4"    

    ,"Ins_515_absf.s1"      ,"Ins_516_absf.s2"      ,"Ins_517_absf.s4"      ,"Ins_518_addf.s1"
    ,"Ins_519_addf.s2"      ,"Ins_520_addf.s4"      ,"Ins_521_divf.s1"      ,"Ins_522_divf.s2"
    ,"Ins_523_divf.s4"      ,"Ins_524_maxf.s1"      ,"Ins_525_maxf.s2"      ,"Ins_526_maxf.s4"
    ,"Ins_527_minf.s1"      ,"Ins_528_minf.s2"      ,"Ins_529_minf.s4"      ,"Ins_530_mulf.s1"
    ,"Ins_531_mulf.s2"      ,"Ins_532_mulf.s4"      ,"Ins_533_negf.s1"      ,"Ins_534_negf.s2"
    ,"Ins_535_negf.s4"      ,"Ins_536_recipf.s1"    ,"Ins_537_recipf.s2"    ,"Ins_538_recipf.s4"
    ,"Ins_539_rsqrtf.s1"    ,"Ins_540_rsqrtf.s2"    ,"Ins_541_rsqrtf.s4"    ,"Ins_542_sqrtf.s1"
    ,"Ins_543_sqrtf.s2"     ,"Ins_544_sqrtf.s4"     ,"Ins_545_subf.s1"      ,"Ins_546_subf.s2"
    ,"Ins_547_subf.s4"      ,"Ins_548_fmaf.s1"      ,"Ins_549_fmaf.s2"      ,"Ins_550_fmaf.s4"
    ,"Ins_551_fmsf.s1"      ,"Ins_552_fmsf.s2"      ,"Ins_553_fmsf.s4"      ,"Ins_554_fnmaf.s1"
    ,"Ins_555_fnmaf.s2"     ,"Ins_556_fnmaf.s4"     ,"Ins_557_fnmsf.s1"     ,"Ins_558_fnmsf.s2"
    ,"Ins_559_fnmsf.s4"     ,"Ins_560_addsubf.s2"   ,"Ins_561_addsubf.s4"   ,"Ins_562_addsubnf.s2"
    ,"Ins_563_addsubnf.s4"  ,"Ins_564_subaddf.s2"   ,"Ins_565_subaddf.s4"   ,"Ins_566_subaddnf.s2"
    ,"Ins_567_subaddnf.s4"  ,"Ins_568_addxf.s2"     ,"Ins_569_addxf.s4"     ,"Ins_570_mulxf.s2"
    ,"Ins_571_mulxf.s4"     ,"Ins_572_subxf.s2"     ,"Ins_573_subxf.s4"     ,"Ins_574_addsubnxf.s2"
    ,"Ins_575_addsubnxf.s4" ,"Ins_576_addsubxf.s2"  ,"Ins_577_addsubxf.s4"  ,"Ins_578_subaddnxf.s2"
    ,"Ins_579_subaddnxf.s4" ,"Ins_580_subaddxf.s2"  ,"Ins_581_subaddxf.s4"  ,"Ins_582_addrf.s2"
    ,"Ins_583_addrf.s4"     ,"Ins_584_maxrf.s2"     ,"Ins_585_maxrf.s4"     ,"Ins_586_minrf.s2"
    ,"Ins_587_minrf.s4"     ,"Ins_588_mulrf.s2"     ,"Ins_589_mulrf.s4"     ,"Ins_590_subrf.s2"
    ,"Ins_591_subrf.s4"     ,"Ins_592_ceilf.suw1"   ,"Ins_593_ceilf.suw2"   ,"Ins_594_ceilf.suw4"
    ,"Ins_595_ceilf.sw1"    ,"Ins_596_ceilf.sw2"    ,"Ins_597_ceilf.sw4"    ,"Ins_598_cvtf.hs1"
    ,"Ins_599_cvtf.hs2"     ,"Ins_600_cvtf.hs4"     ,"Ins_601_cvtf.sh1"     ,"Ins_602_cvtf.sh2"
    ,"Ins_603_cvtf.sh4"     ,"Ins_604_cvtf.suw1"    ,"Ins_605_cvtf.suw2"    ,"Ins_606_cvtf.suw4"
    ,"Ins_607_cvtf.sw1"     ,"Ins_608_cvtf.sw2"     ,"Ins_609_cvtf.sw4"     ,"Ins_610_cvtf.uws1"
    ,"Ins_611_cvtf.uws2"    ,"Ins_612_cvtf.uws4"    ,"Ins_613_cvtf.ws1"     ,"Ins_614_cvtf.ws2"
    ,"Ins_615_cvtf.ws4"     ,"Ins_616_floorf.suw1"  ,"Ins_617_floorf.suw2"  ,"Ins_618_floorf.suw4"
    ,"Ins_619_floorf.sw1"   ,"Ins_620_floorf.sw2"   ,"Ins_621_floorf.sw4"   ,"Ins_622_roundf.suw1"
    ,"Ins_623_roundf.suw2"  ,"Ins_624_roundf.suw4"  ,"Ins_625_roundf.sw1"   ,"Ins_626_roundf.sw2"
    ,"Ins_627_roundf.sw4"   ,"Ins_628_trncf.suw1"   ,"Ins_629_trncf.suw2"   ,"Ins_630_trncf.suw4"
    ,"Ins_631_trncf.sw1"    ,"Ins_632_trncf.sw2"    ,"Ins_633_trncf.sw4"    ,"Ins_634_cmpf.s1"
    ,"Ins_635_cmpf.s2"      ,"Ins_636_cmpf.s4"		,"Ins_637_ld_b_inc"		,"Ins_638_ld_b_dec"
	,"Ins_639_ld_bu_inc"	,"Ins_640_ld_bu_dec"	,"Ins_641_ld_h_inc"		,"Ins_642_ld_h_dec"	
	,"Ins_643_ld_hu_inc"	,"Ins_644_ld_hu_dec"	,"Ins_645_ld_w_inc"		,"Ins_646_ld_w_dec"
	,"Ins_647_ld_dw_inc"	,"Ins_648_ld_dw_dec"	,"Ins_649_st_b_inc"		,"Ins_650_st_b_dec"
	,"Ins_651_st_h_inc"		,"Ins_652_st_h_dec"		,"Ins_653_st_w_inc"		,"Ins_654_st_w_dec"
	,"Ins_655_st_dw_inc"	,"Ins_656_st_dw_dec"	,"Ins_657_clip_b"		,"Ins_658_clip_bu"
	,"Ins_659_clip_h"		,"Ins_660_clip_hu"		,"Ins_661_ldl_bu"		,"Ins_662_ldl_hu"		
	,"Ins_663_ldl_dw"		,"Ins_664_stc_b"		,"Ins_665_stc_h"		,"Ins_666_stc_dw"
	,"Ins_667_resbank"		,"Ins_668_stm_gsr"		,"Ins_669_stm_mp"		,"Ins_670_ldm_gsr"
	,"Ins_671_ldm_mp"
	// Custom Instruction ...
    ,"Ins_C001_clr1"			,"Ins_C002_clr1"			,"Ins_C003_not1"			,"Ins_C004_not1"
    ,"Ins_C005_set1"			,"Ins_C006_set1"			,"Ins_C007_tst1"			,"Ins_C008_tst1"
    ,"Ins_C009_pref_I"			,"Ins_C010_ld_array"		,"Ins_C011_st_array"		,"Ins_C012_ls_array"
    ,"Ins_C013_sld_array"		,"Ins_C014_sst_array"		,"Ins_C015_sls_array"		,"Ins_C016_caxi_array"
    ,"Ins_C017_mpu_update"		,"Ins_C018_mov_alu"			,"Ins_C019_movr_shift"		,"Ins_C020_mov_sst"
    ,"Ins_C021_mov5_st"			,"Ins_C022_movea_sst"		,"Ins_C023_movea_st"		,"Ins_C024_cmp_bcc"
    ,"Ins_C025_alu_bcc"         ,"Ins_C026_ldlbu_stcb_s"	,"Ins_C027_ldlbu_stcb_f"	,"Ins_C028_ldlhu_stch_s"
	,"Ins_C029_ldlhu_stch_f"	,"Ins_C030_ldlw_stcw_s"		,"Ins_C031_ldlw_stcw_f"		,"Ins_C032_alu_alu"			
	,"Ins_C033_alu_br"          ,"Ins_C034_alu_ldst"		,"Ins_C035_alu_div"			,"Ins_C036_alu_mul"			
	,"Ins_C037_alu_special"     ,"Ins_C038_alu_fpu"			,"Ins_C039_alu_c2b1"		,"Ins_C040_ld_alu"	
	,"Ins_C041_ld_br"           ,"Ins_C042_ld_ldst"			,"Ins_C043_ld_div"			,"Ins_C044_ld_mul"			
	,"Ins_C045_ld_special"      ,"Ins_C046_ld_fpu"			,"Ins_C047_ld_c2b1"			,"Ins_C048_fpu_fpu"			
	,"Ins_C049_c2b1_c2b1"       ,"Ins_C050_changing_privilege", "Ins_C051_cmpfs_trfsr"	,"Ins_C052_rie_fpu32"		
	,"Ins_C053_rie_fxu32"		,"Ins_C054_rie_fxu64"		,"Ins_C055_rie_int64"		,"Ins_C056_mpu_checking"
    ,"Ins_C057_changing_mode",
	NULL
} ;



/**
 * @brief　命令重みを設定する
 * @param  str　命令重み登録キー
 * @param  weight_value  重み値
 * @return 命令オブジェクト
 */
UI32 CInstructionSet::SetWeight(std::string str ,UI32 weight_value ) {
	UI32 id= 0 ;
	for (UI32 i= 0 ;i < (sizeof(weight_keys)/sizeof(LPCTSTR)) ;i++) {
		if (strcmp(str.c_str() ,weight_keys[i]) == 0) {
			id= i + 1 ;
			break ;
		}
	}
	if (id) {
		m_wrIns.Set( id, weight_value ); 
	}
	return (id) ;
}


/**
 * @brief　IDを指定して命令重み登録キーを取得する
 * @return 命令重み登録キー
 */
LPCTSTR CInstructionSet::GetKey(UI32 weight_id) {
	if (weight_id <= (sizeof(weight_keys)/sizeof(LPCTSTR))) {
		return weight_keys[weight_id - 1] ;
	} else {
        return "";
    }
}


/**
 *	@brief  重みを表示します。デバッグ用。
 */
void CInstructionSet::Dump( void ) {
	std::cout << "** status[" << (((bool)m_wrIns)? "Valid" : "dirty") << "]" << std::endl ;
	std::set<UI32> key_set= m_wrIns.KeySet() ;
	std::set<UI32>::iterator  itr;
	for (itr = key_set.begin(); itr != key_set.end(); itr++) {
		UI32 id= *itr ;
		UI32 wt= m_wrIns.GetWeight(id) ;
		if (id <= (sizeof(weight_keys)/sizeof(LPCTSTR))) {
			std::cout << "** Key: " << weight_keys[id - 1] << "  weight: " << wt << std::endl ;
		} else {
			std::cout << "** Key: " << id << "  weight: " << wt << std::endl ;
		}
	}
	return;
}

#include "ins_factory.cpp"

