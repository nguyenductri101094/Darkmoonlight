#ifndef REGULATION_H_
#define REGULATION_H_

#include	"rtg_common.h"
#include	"ifsimulator.h"

class IOperand;

/**
 * @brief シミュレーション時に命令の制約を検査し、
 *        補正に必要な情報を取得するパラメータクラスです。
 */
class IRegulation {
public:

	/**
	 * @brief 補正結果フラグ集合
	 */
	typedef enum EN_REGULATION_BEHAVIOR{
		REGULATION_FETCH,
		REGULATION_LOAD,
		REGULATION_STORE,
		/* Free use */
		REGULATION_BEHAVIOR_NUM
	} REGULATION_BEHAVIOR;

	/**
	 * @brief 補正結果フラグ集合
	 */
	typedef enum EN_REGULATION_RESULT{
		REGULATION_PASS,
		REGULATION_REASM,
		REGULATION_GIVEUP,
		/* Free use */
		REGULATION_RESULT_NUM
	} REGULATION_RESULT;

	/**
	 * @brief このオブジェクトを生成します。
	 */
	IRegulation() : m_pSim(NULL), m_depends(NULL), m_ht(0x80000000), m_bForce(false), m_nRepeat(1), m_bRr(1), m_vGr(), m_vWr(), m_vSr(), m_vEa() {}


	/**
	 * @brief このオブジェクトを生成します。
	 * @param pSim シミュレーター参照
	 * @param ht   スレッド番号
	 */
	IRegulation(ISimulator* pSim, UI32 ht) : m_pSim(pSim), m_depends(NULL), m_ht(ht), m_bForce(false), m_nRepeat(1), m_bRr(1), m_vGr(), m_vWr(), m_vSr(), m_vEa() {}


	/**
	 * @brief このオブジェクトを破棄します。
	 */
	virtual ~IRegulation(){}


	/**
	 * @brief  実行可能であるかを問い合わせます。
	 * @return 真の場合、実行可能であることを意味します。
	 */
	virtual bool Pass() { return (m_bRr[REGULATION_PASS] && (m_bRr[REGULATION_REASM]==false) && (NeedIns()==false));}


	/**
	 * @brief  補正命令が必要であるか問い合わせます。
	 *         必要な補正内容はこのクラスメンバであるVectorに格納されています。
	 * @return 真の場合は補正命令が必要であることを意味します。
	 */
	virtual bool NeedIns() { return (m_bRr[REGULATION_GIVEUP] == false && !(m_vGr.empty() && m_vSr.empty() && m_vWr.empty()/* && m_vEa.empty()*/));}

	virtual bool GiveUpRegulate() { return (m_bRr[REGULATION_GIVEUP]);}

	/**
	 * @brief 再アセンブルが必要であることを指示します。。
	 */
	virtual void ReAsm() { m_bRr.set(REGULATION_REASM, 1); }


	/**
	 * @brief 再シミュレーションが必要であることを指示します。
	 */
	virtual void ReSim() { m_bRr.set(REGULATION_PASS, 0); }

	virtual void GiveUp() {
		m_bRr.set(REGULATION_PASS, 0);
		m_bRr.set(REGULATION_GIVEUP, 1);
	}

	/**
	 * @brief 補正結果に関するフラグを取得
	 */
	virtual void SetBehavior(REGULATION_BEHAVIOR b, bool val = 1) { m_bBh.set(b,val); }

	/**
	 * @brief 補正結果に関するフラグを取得
	 */
	virtual bool GetBehavior(REGULATION_BEHAVIOR b) { return m_bBh[b]; }

	/**
	 * @brief 補正結果に関するフラグを取得
	 */
	virtual bool GetResult(REGULATION_RESULT rr) { return m_bRr[rr]; }

	/**
	 * @brief Get/Set force adjustment
	 */
	virtual void SetForce(bool bForce) { m_bForce = bForce; }
	virtual bool IsForce() { return m_bForce; }

	/** 
	 * @brief Get/set re-executing time
	 */
	virtual void SetRepeat(UI32 r) {m_nRepeat = r;}
	virtual UI32 GetRepeat() {return m_nRepeat;}


public:
	ISimulator*		m_pSim;							//!< @brief シミュレーター参照 (in-param)
	IOperand*       m_depends;						//!< @brief 依存オペランド (in-param)
	UI32			m_ht;							//!< @brief この命令を実行するスレッド番号 (in-param)
	bool			m_bForce;						//!< @brief Force regulation for valid parameter
	UI32			m_nRepeat;						//!< @brief Re-execution time
	std::bitset<REGULATION_BEHAVIOR_NUM>	m_bBh;	//!< @brief 補正結果に使用する（out param flags）
	std::bitset<REGULATION_RESULT_NUM>		m_bRr;	//!< @brief 補正結果に使用する（out param flags）
	std::vector< std::pair<UI32,UI32> >		m_vGr;	//!< @brief GR補正情報(レジスタインデックスと値)を返す（out-param:この情報を元に補正する）
	std::vector< std::pair<UI32,std::pair<std::bitset<4> ,__uint128_t> > > m_vWr;	//!< @brief WR補正情報(レジスタインデックスとelm_flagと値)を返す（out-param:この情報を元に補正する）
	std::vector< std::pair<UI32,UI32> >		m_vSr;	//!< @brief SR補正情報(selID*32+regIDと値)を返す（out-param:この情報を元に補正する）
	std::vector< std::pair<UI32,UI32> >		m_vEa;	//!< @brief 実効アドレス
};

#endif /*REGULATION_H_*/
