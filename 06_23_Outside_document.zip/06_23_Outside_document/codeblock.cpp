#include	"codeblock.h"
#include    "usr_src.h"
#include    "operand.h"
#include "instruction.h"

extern std::shared_ptr<CUserSourceFile>		g_usf;

CCodeBlock::CCodeBlock() : 
	m_bRLB(false), m_orgsize(0), m_borg(false), m_bmod(false), m_bUserAddress(false), m_bFreeAlloc(true), m_address(0), m_align(2),
	m_codesize(0), m_label(""), m_vcode(), m_lhash(), m_vndat(), m_vbtarget(), m_bStatistics(false), m_bBreakSetupInsFlag(false), m_bBreakSetDone(false)
{
	//DBG_TRACE();
}


CCodeBlock::CCodeBlock(std::string label) : 
	m_bRLB(false),  m_orgsize(0), m_borg(false), m_bmod(false), m_bUserAddress(false), m_bFreeAlloc(true), m_address(0), m_align(2),
	m_codesize(0), m_label(label), m_vcode(), m_lhash(), m_vndat(), m_vbtarget(), m_bStatistics(false), m_bBreakSetupInsFlag(false), m_bBreakSetDone(false)
{
	//DBG_TRACE();
}


CCodeBlock::CCodeBlock(std::string label, UI32 addr) : 
	m_bRLB(false),  m_orgsize(0), m_borg(false), m_bmod(false), m_bUserAddress(false), m_bFreeAlloc(true), m_address(addr), m_align(2),
	m_codesize(0), m_label(label), m_vcode(), m_lhash(), m_vndat(), m_vbtarget(), m_bStatistics(false), m_bBreakSetupInsFlag(false), m_bBreakSetDone(false)
{
	//DBG_TRACE();
}


CCodeBlock::~CCodeBlock()
{
	std::for_each (m_vcode.begin(), m_vcode.end(), [](IInstruction* i){ delete i;} );
}


UI32 CCodeBlock::Print(std::ostream& ofs) {

	if (!IsEnableOutput()) {
		return 0;
	}

	ofs << std::setfill(' ');
	ofs << std::left;

#if 0
	if (m_borg) {
		ofs << std::endl; 
		ofs << ".org " << "0x" << std::hex << m_address << std::endl;
	}
#else
	std::string l = m_label;
	if (l.length() == 0) {
		std::stringstream ss;
		ss << std::hex << std::setw(8) << std::setfill('0');
		ss >> l;
	}
	ofs << "    .section    " << '.' << CLabel::m_prefix << l << ',' << " \"ax\"" << std::endl;
#endif

	if (m_label.length()) {
		if (!m_borg) {
			ofs << std::endl;
		}
		ofs << CLabel::m_prefix << m_label << ':' << std::endl;
	}

	std::vector<IInstruction*>::iterator itr;
#if defined(NDEBUG)
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		ofs << (**itr);
	}
#else
	UI32 addr = m_address ;
	char buf[20] ;
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		sprintf(buf , " ADDR: 0x%08x " , addr );
 		(**itr).AppendComment(buf);
		ofs  << (**itr);
 		addr += (**itr).GetLen();
	}
#endif

	ofs << std::endl;
	return m_vcode.size();
}


UI32 CCodeBlock::PrintLink(std::ostream& ofs) {

	if (IsEnableOutput() && IsLocationCount() ) {
		ofs << std::setfill(' ');
		ofs << std::left;
	
		std::string l = GetLabel();
		UI32		a = GetAddress();
		if (l.length() == 0) {
			std::stringstream	ss;
			ss << std::setw(8) << std::setfill('0') << a;
			ss >> l;
		}
		ofs << "    " << '.' << CLabel:: m_prefix << l << "    0x" << std::right << std::hex << std::setw(8) << std::setfill('0') << a << ':'  << " {" << std::endl; 
		ofs << "    " << "    " << "* (." << CLabel:: m_prefix << l << ')' << std::endl;
		ofs << "    " << '}' << std::endl;
		ofs << std::endl;
        return (GetAddress() + GetCodeSize());
	} else {
		return 0;
	}
}


void CCodeBlock::AddOpeCode(IInstruction* popr) {
	_ASSERT(popr);
	m_vcode.push_back(popr);
}


void CCodeBlock::AddOpeCode(IInstruction* popr, UI32 order) {
	
	_ASSERT(popr);
	if (this->GetInstructionNum() < order) {
	_ASSERT(this->GetInstructionNum() >= order);
	}
	
	std::vector<IInstruction*>::iterator itr = m_vcode.begin();
	advance(itr, order);
	m_vcode.insert(itr, popr);
}

UI32 CCodeBlock::GetIndex(IInstruction* pIns) throw (std::runtime_error){
	
	UI32 max = GetInstructionNum();
	for (UI32 idx = 0; idx < max; idx++) {
		if (at(idx) == pIns) {
			return idx;
		}
	}
	std::runtime_error excep("Not found instruction\n");
	throw excep;
	return 0;
}

void CCodeBlock::Interlace(CCodeBlock* b) {

	_ASSERT(b);
		
	/* TODO: 要検討 */
	/* CCodeBlock bとこのブロックが命令を多重で参照しないように         */
	/* bはクリアする。デストラクタにより2重解放になる。                 */
	/* コピーコンストラクタで対応すべきであるがパフォーマンスを考慮した。 */
	
	std::vector<IInstruction*> vmix;
	
	int aNum = this->m_vcode.size();
	int bNum = b->m_vcode.size();
	int ia, ib;
	
	for (ia = ib = 0; (ia < aNum) && (ib < bNum); ) {
		if (ia < aNum) {
			vmix.push_back(this->at(ia));
			ia++;
		}
		if (ib < bNum) {
			vmix.push_back(b->at(ib));
			ib++;
		}
	}
	
	this->m_codesize += b->m_codesize;
	b->m_vcode.clear();		// bの参照を切る(b->Clearを呼ばない)
	delete b;
	
	m_vcode = vmix;			// そのまま上書きする
}


void CCodeBlock::Append(CCodeBlock* b) {
	
	_ASSERT(b);
	m_vcode.insert(m_vcode.end(), b->m_vcode.begin(), b->m_vcode.end()); 	
	this->m_codesize += b->m_codesize;
	
	b->m_vcode.clear();		// bの参照を切る(b->Clearを呼ばない)
	delete b;
}


CCodeBlock* CCodeBlock::Split(UI32 i) {
	
	if (i < GetInstructionNum()) {
		std::vector<IInstruction*>::iterator itr = m_vcode.begin();
		std::advance(itr, i);
		
		CCodeBlock* splitCb = new CCodeBlock();
		splitCb->m_vcode.insert(splitCb->m_vcode.end(), itr, this->m_vcode.end()); 	
		this->m_vcode.erase(itr, this->m_vcode.end());
		
		// 補正可否も継承する
		splitCb->EnableRegulation(this->IsRegulation());
		
		return splitCb;
	}
	return NULL;
}


IInstruction* CCodeBlock::Fetch(UI32 addr) {
	std::map<UI32,IInstruction*>::iterator itr;
	if ((itr = m_lhash.find(addr)) != m_lhash.end()) {
		return itr->second;
	}
	return NULL;
}


void CCodeBlock::Update() {
	std::vector<IInstruction*>::iterator itr;
	m_codesize	= 0;
	
	m_lhash.clear();
	m_vndat.clear();
	
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		m_lhash.insert(std::pair<UI32,IInstruction*>(m_address+m_codesize, (*itr)));
		if ((*itr)->Category(IInstruction::ICAT_NATIVEDATA)) {
			m_vndat.push_back(m_address+m_codesize);
		}
		m_codesize	+= (*itr)->GetLen();
	}
}


/**
 *	@brief 補正命令について、レジスタ干渉しない限りにおいて前倒しにリオーダーする。
 */
void CCodeBlock::FrontLoadRegulation() {

	// 上から走査、補正コードが検出されたら逆方向に遡る
	auto ri = m_vcode.begin() + 1;
	auto GetSrIndex = [](IInstruction* p) -> UI32 {
		UI32 N = p->GetOpNum();
		for (UI32 i = 0; i < N; i++) {
			if (p->opr(i)->Attr(IOperand::OPR_ATTR_SR)) {
				return *(p->opr(i));
			}
		}
		return ~0U;
	};

	auto IsPreventConsecutiveRequest = [=] (IInstruction *p) -> bool {
		UI32 idx = this->GetIndex(p);
		if(idx > 0 && idx < this->GetInstructionNum() - 1) {
			IInstruction *pPrevIns = this->at(idx - 1);
            IInstruction *pNextIns = this->at(idx + 1);
			if(pPrevIns->HasAsyncLabel() && pNextIns->HasAsyncLabel())
				return true;

            if(pPrevIns->GetId() == INS_ID_EI && pNextIns->HasDeassertAsyncLabel())
                return true;
		}

		return false;
	};

    /** lambda: checking whether current instruction need to judge PSW.CCn value
     * @param p checking instruction
     * @return true if instruction need to judge PSW, otherwise false
     */
    auto IsRequirePSWIns = [] (IInstruction *p) ->bool {
        UI32 Id = p->GetId();
        // These condition are to increase checking speed by reduce below conditions.
        if(Id == INS_ID_MOVI32 || Id == INS_ID_ADDI_SI16 || Id == INS_ID_ANDI_I16)
            return false;

        if(p->Behavior(IInstruction::STORE_MEMORY) || p->Behavior(IInstruction::LOAD_MEMORY))
            return false;

        // These condition are to ensure all cases requiring PSW register, but rarely called.
        if(Id == INS_ID_ADF || Id == INS_ID_CMOV || Id == INS_ID_CMOV_SI5 || Id == INS_ID_SASF || Id == INS_ID_SBF || Id == INS_ID_SETF)
            return true;
        if(Id == INS_ID_STSR || INS_ID_STTC_SR)
            return true;
        if(Id >= INS_ID_BC_SD9 && Id <= INS_ID_BZ_SD17)
            return true;
        return false;
    };

	//std::cout << "-------------------------------------Before------------------------------------" << std::endl;
	//Dump(std::cout);
	for (; ri != m_vcode.end() ; ++ri) {
		if ((*ri)->InSequence() && (*ri)->InSequence(IInstruction::IF_SEQ_FWD) == false) {
			continue;
		}
		//if (((*ri)->GetComment().find("Regulation")) != std::string::npos) { // On testing, comment search....
		if ((*ri)->GetRegulationTarget() != nullptr) {
			auto rt = ri;
			std::string strTargetMne = (*ri)->GetRegulationTarget()->GetMne();
			if(strTargetMne == "feret" || strTargetMne == "eiret" || strTargetMne == "trfsr" )
				continue;
            if((*ri)->HasAsyncLabel() || IsPreventConsecutiveRequest((*ri)) || (*ri)->GetException().first != 0) {
				continue;
			}

			//std::cout << "--" << std::endl;
			while (rt != m_vcode.begin()) {
				auto rh = rt - 1;
				if ((*rh)->GetRegulationTarget() != nullptr) {
					break; // 補正コードを密集させるためここでSTOP
				}
				UI32 TargetId = (*rt)->GetRegulationTarget()->GetId();
				if(TargetId == INS_ID_JMP || TargetId == INS_ID_JMPD32 || TargetId == INS_ID_LOOP){
					break;
				}

				//prevent resbank instruction update adjustment code.
				if((*rh)->GetMne() == "resbank") {
					break;
				}

				//Preceding instruction has asynchronous event label.
				if((*rh)->GetException().first != 0){
					break;
				}

				// Event may be accepted at adjustment code after moving.
				if((*rh)->HasDeassertAsyncLabel()) {
					break;
				}

				if((*rh)->GetComment().find("Mirror") !=std::string::npos)
					break;

				if ((*rh)->InSequence()){
					IInstruction *pForwardIns = ((*rh)->GetC2B1Ins() != nullptr) ? (*rh)->GetC2B1Ins() : (*rh)->GetForwardIns();

					while(pForwardIns != nullptr && (pForwardIns->GetId() != INS_ID_LOOP)  
						&& (GetIndex(*rh) < GetIndex(*rt) && (GetIndex(pForwardIns) > GetIndex(*rt))) ) {
						//Preceding instruction has asynchronous event label.
						if(((*rh)->GetException().first != 0 || (*rh)->HasDeassertAsyncLabel()) && (g_cfg->m_nRanHandler & 0x1) != 0){
							break;
						}
						auto rt_dst = (*rt)->GetGrDst();
						auto rh_r = (*rh)->GetGrDst() | (*rh)->GetGrSrc();
						//[FROG]TODO: This case was not supported.
						// mov              hilo(0x16a943b4), r6
						// sbf              4, r6, r15, r13			<-- r6 is src register
						// caxi             [r6],r13,r20			<-- r6 is src register without forwarding
						if (rt_dst & rh_r) {
							break;
						}

						(*rh)->DirMoveTo(*rt);
						std::iter_swap (rt, rh);
						if(rh == m_vcode.begin())
							break;
						rt = rh ;
						rh = rt - 1;
						ri = ri-1;

						pForwardIns = ((*rh)->GetC2B1Ins() != nullptr) ? (*rh)->GetC2B1Ins() : (*rh)->GetForwardIns();
	
					}
					IInstruction *target = (*rt)->GetRegulationTarget();
					if((target != nullptr && target->GetMne() == "dispose" && target->InLoop() == true) && (*rt)->GetLabel().size() == 0){
					} else
						break; // 順序不動コードによりSTOP
				}
				//if (((*rt)->GetMne().find("mov")) == std::string::npos) {
				//	break; // ?
				//}
				if ( ((*rh)->m_pswb != (*rh)->m_pswa ) || ((*rt)->m_pswb != (*rt)->m_pswa ) ) {
                    // The adjustment code usually doesn't check PSW register
                    if(IsRequirePSWIns(*rt) == true)
					    break;
				}
				if ((*rh)->Behavior(IInstruction::JMP)) {
					break; // Jmpコード
				}
				if ((*rh)->GetLabel().length() > 0) {
					break; // Label付き命令（Jmpの着地点になる）
				}

				// The store memory may be adjustment for Forwarding
				if((*rt)->Behavior(IInstruction::STORE_MEMORY)) {
					// rh instruction may overwrite/read (a new value) memory written by rt.
					if((*rh)->Behavior(IInstruction::STORE_MEMORY) || (*rh)->Behavior(IInstruction::LOAD_MEMORY)) {
						break;
					}
				}


				UI32 sridx = GetSrIndex(*rh);
				if (sridx != ~0U) {
					if (GetSrIndex(*rt) == sridx) {
						//fprintf(stderr, "SR 干渉 sridx=%d\n", sridx);
						break;
					}
				}

				auto grt = (*rt)->GetGrSrc() | (*rt)->GetGrDst();
				auto grh = (*rh)->GetGrSrc() | (*rh)->GetGrDst();
                auto wrt = (*rt)->GetWrSrc() | (*rt)->GetWrDst();
				auto wrh = (*rh)->GetWrSrc() | (*rh)->GetWrDst();
				if ( (grt & grh) == 0 && (wrt & wrh) == 0) {
					std::iter_swap (rt, rh);
					rt = rh;
				}else{
					break;
				}
			}
		}
	}
	//std::cout << "-------------------------------------After------------------------------------" << std::endl;
	Update();
	//Dump(std::cout);
	//std::cout << std::endl;
}


void CCodeBlock::Dump(std::ostream& os /*= std::cout*/){
	std::map<UI32,IInstruction*>::iterator i;
	os << '[' << GetLabel() << "] Size=" << GetCodeSize() << std::endl;
	os << std::setfill('0') << std::hex;
	for (i = m_lhash.begin(); i != m_lhash.end(); i++) {
		os << std::setw(8) << i->first << " : " << i->second->GetOutCode();
		
		std::string lbl = i->second->GetLabel();
		if (lbl == "") {
			os << std::endl;
		}else{
			os << "  (" << i->second->GetLabel() << ")" 
			<< std::endl;
		}
	}
}

/*Because some instructions was modified when simulate, 
we must adjust their commnent, some instructions which GNU do not support will be modified in this sequence*/
void CCodeBlock::AdjustRandomComment(){
	char memo[256];
	auto ri = m_vcode.begin();
	UI64	bits;
	for (; ri != m_vcode.end() ; ++ri) {
		if ((*ri)->GetMne().find("stm") != std::string::npos || (*ri)->GetMne().find("ldm") != std::string::npos ) {
			bits = (*ri)->Fetch();
			IInstruction* pNewIns = _WORD(bits);
			sprintf (memo, "Instruction: %s", (*ri)->GetCode().c_str());
			pNewIns->AppendComment(memo);
			(*ri)->DirMoveTo(pNewIns);

			this->Replace((*ri), pNewIns);
			this->Update();
			
		} else if (((*ri)->GetComment().find("Block")) != std::string::npos) { // Comment for random code block
			if ((*ri)->Assemble(&bits)) {
				sprintf (memo, "OpeCode(%llX)", bits);
			} else {
				sprintf (memo, "Asm Error !!");
			}
			(*ri)->AppendComment(memo);
		}
	}
}

bool CCodeBlock::RecoverCodesize(IInstruction *pIns){
	auto PrepareDeleteGap = [&] (IInstruction *pGap) {
		SI32 idx = this->GetIndex(pGap) - 1;
		IInstruction *p;
		UI32 max_try = 10;	// [FROG]TODO: Define this

		if (pGap->GetRiePartner() != nullptr) {
			this->Remove(pIns->GetRiePartner());
			pGap->SetRiePartner(nullptr);
			this->Update();
		}

		// Remove link to its adjustment code.
		while(idx >= 0 && max_try >= 0) {
			p = this->at(idx);

			if(p->GetRegulationTarget() != NULL) {
				if(p->GetRegulationTarget() == pGap)
					p->SetRegulationTarget(nullptr);
			}
			if(p->GetC2B1Ins() != NULL) { // If removed instruction is 2nd ins. of C2B1
				if(p->GetC2B1Ins() == pGap)
					p->SetC2B1Ins(nullptr);
			} /*else
				break;*/
			idx--;
			max_try--;
		}
	};

	auto IsGap = [&] (IInstruction *pGap) {
		if (pGap->InSequence(IInstruction::IF_SEQ_GAP)) 
			return true;
		bool IsNotGap = (pGap->GetRegulationTarget() != nullptr) || pGap->Behavior(IInstruction::JMP) || (pGap->GetLabel().size() != 0)
							|| (pGap->GetMne().find(".word") != std::string::npos) || (pGap->GetMne().find(".hword") != std::string::npos);
		if (IsNotGap) 
			return false;
		else
			return true;
	};

	//Find the gap code for this group of instruction
	for (UI32 i = this->GetIndex(pIns) + 1; i < this->GetInstructionNum(); i++) {
		IInstruction* pFoot = this->at(i);
		//Gap code is nop instruction 
		if (pFoot->GetLabel().find("foot") != std::string::npos) {
			//Need instruction of the first gapcode is the word which store PC for next label
			UI32 tailIdx = this->GetIndex(pFoot) + 1;
			SI32 count = this->GetCodeSize() - this->m_orgsize;
			if (count > 0) {
				//Remove all posible gap code before normal code
				while (count > 0) {
					IInstruction *pGap = this->at(tailIdx);
					if (pGap->InSequence(IInstruction::IF_SEQ_GAP) != true) 
						break;
					//Remove if the lenght of instruction which need to be removed higher than the increment of code size
					count -= pGap->GetLen();
					PrepareDeleteGap(pGap);
					this->Remove(pGap);
				}
				
				if (pIns->GetRegulationTarget() != nullptr && count > 0) {
					IInstruction *pTarget = pIns->GetRegulationTarget();
					if (pTarget->Behavior(IInstruction::JMP)) {
						//PrepareDeleteGap(pTarget);
						tailIdx = this->GetIndex(pIns) + 1;
						while (count > 0) {
							IInstruction *pGap = this->at(tailIdx);
							if (IsGap(pGap)) {
								count -= pGap->GetLen();
								PrepareDeleteGap(pGap);
								this->Remove(pGap);
							}
							else {
								tailIdx++;
								continue;
							}
						}
					}
					//Case 3 : The added instruction is adjusment code of normal instructions
					else {
						PrepareDeleteGap(pTarget);
						tailIdx = this->GetIndex(pIns) + 1;
						while (count > 0) {
							IInstruction *pGap = this->at(tailIdx);
							if (IsGap(pGap)) {
								count -= pGap->GetLen();
								PrepareDeleteGap(pGap);
								this->Remove(pGap);
							}
							else {
								tailIdx++;
								continue;
							}
						}
					}
				}
				else if (count > 0) {
					tailIdx = this->GetIndex(pIns) + 1;
					while (count > 0) {
						IInstruction *pGap = this->at(tailIdx);
						if (IsGap(pGap)) {
							count -= pGap->GetLen();
							PrepareDeleteGap(pGap);
							this->Remove(pGap);
						}
						else {
							tailIdx++;
							continue;
						}
					}
				}
				
				this->Update();
			}
			if (count < 0) {
				while (count < 0) {
				//Add more gap code for recover the orginal code size
				IInstruction* pNewGap = NOP();
				pNewGap->SetSequence(IInstruction::IF_SEQ_GAP, true);
				this->Insert(pNewGap, this->at(tailIdx));
				count +=2;
				}
				this->Update();
			}
			return true; /* Re-Compile & Re-Sim */
		} else if (i == this->GetInstructionNum() - 1) {
			this->m_orgsize = this->GetCodeSize();
			this->Update();
			return false; /* Re-Compile & Re-Sim */
		}
	}
	return false;
}

bool CCodeBlock::CheckPrecisionOverwrite(UI32 checkSize) {

	auto CheckDepend = [&](IInstruction* p, UI32 reg, bool isWR=false) -> SI32 {
		UI32 opNum = p->GetOpNum();
		std::string mne = p->GetMne();

		if (p->Behavior(IInstruction::JMP) && p->GetJumpTarget().size() != 0) {
			return 1;
		}

		// Instructions has async
		/*if (p->HasAsyncLabel()) {
			IDirective *pDir = nullptr;
			UI32 k= 0;
			while((pDir = p->GetDirective(k)) != nullptr) {
				CAsyncLabel *pAL = static_cast<CAsyncLabel*> (pDir->GetAsyncLabel());
				if(pAL != NULL  && pAL->m_bAssert == true) {
					std::cout << "case 1" << std::endl;
					return 1;
				}
				k++;
			}
		}*/

		if(isWR) {
			for (UI32 j = 0; j < opNum; j++) {
				IOperand* jopr = p->opr(j);
				if (jopr->Attr(IOperand::OPR_ATTR_WR) != true)
					continue;

				UI32 regN = jopr->Idx(); 
				if (jopr->Attr(IOperand::OPR_ATTR_SRC) != true) {
					if ((regN == reg) && (jopr->Attr(IOperand::OPR_ATTR_DST)) && (mne.find("div", 0) != 0)) {
						return -1;
					}
					continue;
				}
				if (regN == reg) {
					return 1;
				}
			}
		} else {
			if ((mne == "prepare" || mne == "pushsp"))
				return 1;
			for (UI32 j = 0; j < opNum; j++) {
				IOperand* jopr = p->opr(j);
				if (jopr->Attr(IOperand::OPR_ATTR_GR) != true)
					continue;

				UI32 regN = jopr->Idx(); 
				if (jopr->Attr(IOperand::OPR_ATTR_SRC) != true) {
					if ((regN == reg) && (jopr->Attr(IOperand::OPR_ATTR_DST)) && (mne.find("div", 0) != 0)) {
						return -1;
					}
					continue;
				}
				if (jopr->Attr(IOperand::OPR_ATTR_PAIR)) {
					if (regN == (reg & ~1U)) {
						return 1;
					}
				}else if (regN == reg) {
					return 1;
				}
			}
		}
		return 0;
	};

	for (UI32 i = 0; i < checkSize; i++) {
		IInstruction* pIns = this->at(i);
		// Skip instructions that is in valid (dead code, gap code , etc)
		// TODO: Skip the instructions that was skipped when executed (exception need skip: eg: UCPOP,RIE,PIE,MAE)
		if (pIns->GetValid() != true) continue;

		//Not consider the the instruction has exception as overwrite instruction
		UI32 ExpCause = pIns->GetException().first;
		if (ExpCause == 0xC0 /*MAE*/ || ExpCause == 0xA0 /*PIE*/ || ExpCause == 0x60 /*RIE*/ || 
			ExpCause == 0x71 /*FPE*/ || ExpCause == 0x75 /*FXE*/ ||
			( ExpCause >= 0x80 && ExpCause <= 0x82 /*UCPOP*/ ) || 
			( ExpCause >= 0x10 && ExpCause <= 0x1F /*SYSERR*/ )) 
			continue;

		//A vector holding a register to be collapsed
		UI32 depreg;
		UI32 depwreg;
		depwreg = (UI32)(pIns->GetOprIdxMistmatch() >> 32) ;
		depreg = (UI32)(pIns->GetOprIdxMistmatch() & 0xffffffff);

		//if there are no register need to be overwrite, continue to next instructions
		if ((depreg == 0 && depwreg == 0) || pIns->GetLabel().find("Change_to") != std::string::npos) {
			continue; // 依存関係でのエラーを発生させない、次の命令へ
		}

		// Detected error occurrence.
		UI32 holdPos = i + 1; //It refers to the instruction following the error generation instruction.
		UI32 h;

		// Find the general purpose registers which was mismatched 
		for (UI32 v = 0; v < 32; v++) {
			if ((depreg & (1 << v)) == 0) continue;
			for (h = holdPos; h < checkSize; h++) {

				//Invalid instructions
				if (this->at(h)->GetValid() != true) continue;

				//Not consider the the instruction has exception as overwrite instruction
				UI32 causeCode = this->at(h)->GetException().first;
				if (causeCode == 0xC0 /*MAE*/ || causeCode == 0xA0 /*PIE*/ || causeCode == 0x60 /*RIE*/ || 
					causeCode == 0x71 /*FPE*/ || causeCode == 0x75 /*FXE*/ ||
					( causeCode >= 0x80 && causeCode <= 0x82 /*UCPOP*/ ) || 
					( causeCode >= 0x10 && causeCode <= 0x1F /*SYSERR*/ )) 
					continue;

				SI32 retDepend = CheckDepend (this->at(h), v, false);
				if (retDepend > 0) {
					return false;
				} else
				if (retDepend < 0) {
					break;
				}
			}
			if (h >= checkSize) {
				return false;
			}
		}

		// Find the wire registers which was mismatched 
		for (UI32 v = 0; v < 32; v++) {
			if ((depwreg & (1 << v)) == 0) continue;
			for (h = holdPos; h < checkSize; h++) {

				//Invalid instructions
				if (this->at(h)->GetValid() != true) continue;

				//Not consider the the instruction has exception as overwrite instruction
				UI32 causeCode = this->at(h)->GetException().first;
				if (causeCode == 0xC0 /*MAE*/ || causeCode == 0xA0 /*PIE*/ || causeCode == 0x60 /*RIE*/ || 
					causeCode == 0x71 /*FPE*/ || causeCode == 0x75 /*FXE*/ ||
					( causeCode >= 0x80 && causeCode <= 0x82 /*UCPOP*/ ) || 
					( causeCode >= 0x10 && causeCode <= 0x1F /*SYSERR*/ )) 
					continue;

				SI32 retDepend = CheckDepend (this->at(h), v, true); 
				if (retDepend > 0) {
					return false;
				} else
				if (retDepend < 0) {
					break;
				}
			}
			if (h >= checkSize) {
				return false;
			}
		}
	}

	return true;
}
// Store the branch target of jump,disposeJ and bcond instruction for synchronize PC
void CCodeBlock::RecordBrTarget(std::string label){
	if (label != "") m_vbtarget.push_back(label);
}

bool CCodeBlock::IsEntry(IInstruction *pIns) {
	return false;
};

UI32 CUserBlock::Print(std::ostream& ofs) {

	if (!IsEnableOutput()) {
		return 0;
	}

	ofs << std::setfill(' ');
	ofs << std::left;

#if 0
	if (m_borg) {
		ofs << std::endl; 
		ofs << ".org " << "0x" << std::hex << m_address << std::endl;
	}
#else
	std::string l = m_label;
	if (l.length() == 0) {
		std::stringstream ss;
		ss << std::hex << std::setw(8) << std::setfill('0');
		ss >> l;
	}
	ofs << "    .section    " << '.' << CLabel::m_prefix << l << ',' << " \"ax\"" << std::endl;
#endif	
	if (m_label.length()) {
		if (!m_borg) {
			ofs << std::endl;
		}
		ofs << CLabel::m_prefix << m_label << ':' << std::endl;
	}

	// REPRASE SETTING
    g_usf->ClearPlaceHolder();
    g_usf->SetPlaceHolder("%CONTEXT%", m_context_key);
	g_usf->SetPlaceHolder("%FROG_PE%", CLabel::m_prefix);
	// OUTPUT USER CODE
    g_usf->GetBody(m_user_key , ofs);

	std::vector<IInstruction*>::iterator itr;
#if defined(NDEBUG)
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		ofs << (**itr);
	}
#else
	UI32 addr = m_address ;
	char buf[20] ;
	for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
		sprintf(buf , " ADDR: 0x%08x " , addr );
 		(**itr).AppendComment(buf);
		ofs << (**itr);
 		addr += (**itr).GetLen();
	}
#endif

	ofs << std::endl;
	return m_vcode.size();
}


/**
 * @brief  ノード出力インターフェース
 * @param  ofs  出力ストリームオブジェクト
 * @return 出力行数を返す。
 */
UI32 CVectorBlock::Print(std::ostream& ofs) {
    if (m_bIsSys) {
        ofs << ".ifndef FROG_MANYCORE_GEN"<< std::endl;
    }
	std::string l = m_label;
   	ofs << ".ifndef " << CLabel::m_prefix << l  << "_UseUserCode"<< std::endl;

	ofs << std::setfill(' ');
	ofs << std::left;

	if (l.length() == 0) {
		std::stringstream ss;
		ss << std::hex << std::setw(8) << std::setfill('0');
		ss >> l;
	}
	ofs << "    .section    " << '.' << CLabel::m_prefix << l << ',' << " \"ax\"" << std::endl;

	if (m_label.length()) {
		if (!m_borg) {
			ofs << std::endl;
		}
		ofs << CLabel::m_prefix << m_label << ':' << std::endl;
	}

	std::vector<IInstruction*>::iterator itr;
	if (IsEnableOutput() || (m_strHandler == "")) {
#if defined(NDEBUG)
		for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
			ofs << (**itr);
		}
#else
		UI32 addr = m_address ;
		char buf[20] ;
		for (itr = m_vcode.begin(); itr != m_vcode.end(); itr++) {
			sprintf(buf , " ADDR: 0x%08x " , addr );
 			(**itr).AppendComment(buf);
			ofs  << (**itr);
	 		addr += (**itr).GetLen();
		}
#endif
	} else {
        if (m_ExceptionLevel == 1) {
		    ofs  << "	ldsr             r3, 29" << std::endl;
        } else if (m_ExceptionLevel == 2) {
		    ofs  << "	ldsr             r3, 30, 3" << std::endl;
        } else {
		    ofs  << "	ldsr             r3, 28" << std::endl;
        }
		ofs  << "	mov              hilo(" << CLabel::m_prefix << m_strHandler << ") ,r3" << std::endl;
		ofs  << "	jmp              [r3]" << std::endl;
	}

	ofs << std::endl;
	ofs << ".endif" << std::endl;
    if (m_bIsSys) {
        ofs << ".endif" << std::endl;
    }
	ofs << std::endl;
	return m_vcode.size();
}


UI32 CVectorBlock::PrintLink(std::ostream& ofs) {

	if (IsLocationCount()) {
		ofs << std::setfill(' ');
		ofs << std::left;
	
		std::string l = GetLabel();
		UI32		a = GetAddress();
		if (l.length() == 0) {
			std::stringstream	ss;
			ss << std::setw(8) << std::setfill('0') << a;
			ss >> l;
		}
		ofs << "    " << '.' << CLabel:: m_prefix << l << "    0x" << std::right << std::hex << std::setw(8) << std::setfill('0') << a << ':'  << " {" << std::endl; 
		ofs << "    " << "    " << "* (." << CLabel:: m_prefix << l << ')' << std::endl;
		ofs << "    " << '}' << std::endl;
		ofs << std::endl;
        return (GetAddress() + GetCodeSize());
	} else {
		return 0;
	}
}

void CPreloadBlock::Update() {
	// Update lookup table (CALLT, SYSCALL)
	if(m_vEntry.size() > 0) {
		std::map <IInstruction*, UI32> mDst;
		IInstruction *pIns;
		UI32 offset = 0;
		UI32 startPos = 0;

		// Search start instruction of TBL
		for(UI32 idx = 0; idx < m_vcode.size(); idx++) {
			pIns = m_vcode[idx];
			if(pIns->GetMne() == ".hword" || pIns->GetMne() == ".word"){
				startPos = idx;
				break;
			}
		}

		// Re-calculate offset
		for(UI32 idx = startPos; idx < m_vcode.size(); idx++) {
			pIns = m_vcode[idx];
			mDst.insert(std::make_pair(pIns, offset));
			offset += pIns->GetLen();
		}

		std::vector<IInstruction*>::iterator itr;
		UI32 entry = 0;
		IInstruction *pWord;
		for(itr = m_vEntry.begin(); itr != m_vEntry.end(); itr++) {
			IInstruction *pIns = *itr;
			UI32 pos = this->GetIndex(pIns);
			IInstruction *pReg = NULL;

			for(SI32 i = pos - 1; i >= 0; i--) {
				IInstruction *p = this->at(i);
				if(p->GetRegulationTarget() == pIns) {
					pReg = p;
				} else
					break;
			}

			if(pReg != NULL) {
				//m_vEntry.insert(itr + 1, pReg);
				//itr = m_vEntry.erase(itr); itr--;
				(*itr) = pReg;
				offset = (mDst.find(pReg))->second;
			} else {
				offset = (mDst.find(pIns))->second;
			}
			
			pWord = m_vcode[startPos + entry];
			pWord->opr(0)->SetRange(offset, offset);
			pWord->opr(0)->Replace(offset);
			entry++;
		}
	}
	CCodeBlock::Update();
}

bool CPreloadBlock::Remove(IInstruction* p) {
	// Update lookup table (CALLT, SYSCALL)
	if(m_vEntry.size() > 0) {
		// Replace deleted instruction by next ins in lookup table.
		IInstruction *pNext;
		UI32 idx = this->GetIndex(p);
		if(idx == this->GetInstructionNum()) {
			//this->AddOpeCode(NOP()); //[FROG]TODO: Fix it.
		}
		pNext = this->at(idx + 1);

		for(UI32 n = 0; n < m_vEntry.size(); n++) {
			std::vector<IInstruction*>::reference ref = m_vEntry.at(n);
			if(p == ref) {
				ref = pNext;
			}
		}
	}

	// Remove instruction
	return CCodeBlock::Remove(p);
}

IInstruction* CPreloadBlock::Replace(IInstruction* before, IInstruction* after) {
	// Update lookup table (CALLT, SYSCALL)
	if(m_vEntry.size() > 0) {
		// Replace deleted instruction by after in lookup table.
		for(UI32 n = 0; n < m_vEntry.size(); n++) {
			std::vector<IInstruction*>::reference ref = m_vEntry.at(n);
			if(before == ref) {
				ref = after;
			}
		}
	}
	return CCodeBlock::Replace(before,after);
}

