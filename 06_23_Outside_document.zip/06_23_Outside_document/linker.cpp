#include "linker.h"

CLinker::CLinker() : m_hash(), m_vacancy(), m_rsv() {
}

/**
 * 予約領域には２つある。
 * (1) 検証空間として使用不可能な領域。設定ファイルに記載された領域以外(m_rsv)
 * (2) ジェネレーターで確保済の領域
 * つまり(1)+(2)以外が命令配置可能である。
 * 
 * この関数は(1)だけの状態に戻す。
 */
void CLinker::Reload() {
	// アロケーションテーブルを破棄 
	m_hash.clear();
    m_vacancy.clear();
	
	// 使用する領域「以外」を全て予約する
	std::map<MEMADDR, Memory*>::iterator i;

	MEMADDR a = 0; 
	for (i = m_rsv.begin(); i != m_rsv.end(); ++i) {
		Memory* pMem = i->second;

		if (a < pMem->m_mr.first) {
			Alloc (a, pMem->m_mr.first - a, MEM_FREE_ALLOC);
		}else
		if (a == (pMem->m_mr.first)) {
			// NOP
		} else {
			// a=0, かつi->first=0は先頭から確保するケースとして許容
			MSG_WARN(0, "Invalid instruction area.%x - %x\n", a, pMem->m_mr.first);
		}
		a = pMem->m_mr.second + 1;
		Memory *pVacancyMem = new Memory(MEMRANGE(pMem->m_mr.first, pMem->m_mr.second), pMem->m_att);
		m_vacancy.insert(std::make_pair(pMem->m_mr.first, pVacancyMem));
	}
	Alloc(a , 0 - a, MEM_FREE_ALLOC);
}


bool CLinker::AllocAddress(MEMADDR start, MEMADDR end, MEM_ATTRIBUTE att) {
	
	if (this->IsAvailable(start, end, att) != true) {
		/* 領域外、または予約済 */
		std::cout << "start addr = " << std::hex << start << std::endl;
		std::cout << " end  addr = " << std::hex << end  << std::endl;
		this->Debug();
		
		return false;
	}
	
	/* 新規登録 */
	m_hash.insert(std::make_pair(start, new Memory(MEMRANGE(start, end), att)));
	UpdateAvailableMemory(MEMRANGE(start, end));
	
	return true;
}


bool CLinker::AllocSearch(CCodeBlock * pcb, MEMADDR* start, MEMADDR len, MEMRANGE rng, MEMADDR align, MEM_ATTRIBUTE att/* = MEM_FREE_ALLOC*/){

	MEMADDR ups  =  0;
	MEMADDR mask = ~ups;
	if (align || ((align & (align - 1)) == 0)) {
		//alignは０でもなく、またはalignは２の冪乗である
		ups = align - 1;
		mask = ~ups;
	}

	if (IsAvailable( rng.first, rng.first, att) != true) {
		// 開始位置アドレス(start)からlower_boudをとった時、start位置が予約領域内である場合は次の予約領域のスタート位置が返される。
		//（欲しいのは一番最初に見付かる空アドレスなのでこれは期待ではない、欲しいのは「start位置を予約している領域の終端＋１の位置」）
		// 開始位置が予約領域でない場合は、そこから確保できるかチャレンジすれば良い。
		// よってstart位置が予約領域である場合、イテレータをデクリメントする（開始地点が使用済であるということは,m_hashには１つ以上登録がある）
		// デクリメントして得た予約領域の終端直後が空きアドレス。
		std::map<MEMADDR, Memory*>::iterator lower;	//<! adr「以上の」要素が最初に現れる位置
		lower = m_vacancy.lower_bound(rng.first);
		rng.first = lower->second->m_mr.first;
	}
	if (rng.first >= rng.second) {
		return false;
	}

	MEMADDR head = (rng.first + ups) & mask;					//<! このアドレス以降に確保する
	MEMADDR end  = head + len - 1;
	auto CorrectAddr = [&](MEMADDR head, MEMADDR end){
		if(g_FetchAddr.GetMirror(head) == true || g_FetchAddr.GetMirror(end) == true){
			if(pcb->GetHandlerAddress() == 0 && pcb->GetLabel().find("codeblock") != std::string::npos){
				return true;
			}else{
				return false;
			}
		}else
			return true;
	};
	if (IsAvailable (head, end, att) && CorrectAddr(head, end) == true) {
		if ( end > rng.second) {
			return false; // 確保許可される最大アドレスを越えているのでこれ以上やっても無意味。
		}else{
			m_hash.insert(std::make_pair(head, new Memory(MEMRANGE(head, end), att)));
			UpdateAvailableMemory(MEMRANGE(head, end));
			*start = head;
			return true;
		}
	}
	std::map<MEMADDR, Memory*>::iterator next;	//<! adr「以上の」要素が最初に現れる位置
	next = m_vacancy.lower_bound(head);
	if(next == m_vacancy.end()) {
		next = m_vacancy.begin();
	}

	SI32 nTryMax = m_vacancy.size();
	Memory *pMem;
	while(nTryMax > 0) {
		pMem = next->second;
		head = (pMem->m_mr.first + ups) & mask;
		if (IsAvailable(head, head + len - 1, att)) {
			if ((head + len) > rng.second) {
				return false; // 確保許可される最大アドレスを越えているのでこれ以上やっても無意味。
			}
			if (CorrectAddr(head, head + len - 1) == false){
				nTryMax--;
				next++;
				continue;
			}
			m_hash.insert(std::make_pair(head, new Memory(MEMRANGE(head, head + len - 1), att)));
			UpdateAvailableMemory(MEMRANGE(head, head + len - 1));
			*start = head;
			return true;
		}

		nTryMax--;
		next++;
		// Last memory range.
		if(next == m_vacancy.end()) {
			next = m_vacancy.begin();
		}
	}

	return false;
}

void CLinker::UpdateAvailableMemory (MEMRANGE mr) {
	
	std::map<MEMADDR, Memory*>::iterator itr;
	itr = m_vacancy.upper_bound(mr.first); // The element that has key greater than mr.first or .end()
	if(itr == m_vacancy.begin())
		return;

	itr--;
	Memory *pMem = itr->second;

    // Element did not involve mr
    if(mr.second < pMem->m_mr.first || mr.first > pMem->m_mr.second)
        return;

    m_vacancy.erase(itr);
    if(mr.first > pMem->m_mr.first) {
		m_vacancy.insert(std::make_pair(pMem->m_mr.first, new Memory(MEMRANGE(pMem->m_mr.first, mr.first - 1), pMem->m_att)));
	}
	if(pMem->m_mr.second > mr.second) {
		m_vacancy.insert(std::make_pair(mr.second + 1, new Memory(MEMRANGE(mr.second + 1, pMem->m_mr.second), pMem->m_att)));
	}
	delete pMem;
}

MEMRANGE CLinker::GetRandomLocation (MEM_ATTRIBUTE att) {
	std::map<MEMADDR, Memory*>::iterator itr;
	std::vector<MEMRANGE> vAddr;
	for(itr = m_vacancy.begin(); itr != m_vacancy.end(); itr++) {
		if(itr->second->m_att == att) {
			vAddr.push_back(MEMRANGE(itr->second->m_mr.first, itr->second->m_mr.second));
		}
	}

	if(vAddr.size()) {
		UI32 pos = g_rnd.GetRange(0, vAddr.size() - 1);
		return vAddr[pos];
	} else {
		itr = m_vacancy.begin();
		return itr->second->m_mr;
	}
}

bool CLinker::CheckAllocatedSize(MEMADDR start, UI32 len) {
	std::map<MEMADDR, Memory*>::iterator itr;
	itr = m_hash.upper_bound(start);
	if(itr == m_hash.end())
		return true;

	if((itr->first - start) >= len)
		return true;
	return false;
}

bool CLinker::Remove(MEMADDR adr) {
	std::map<MEMADDR, Memory*>::iterator itr;
	UI32 start, end;
	// Update m_hash
	if ((itr = m_hash.find(adr)) == m_hash.end()) {
		// Non-allocated adddress
		return false;
	}
	start = itr->second->m_mr.first;
	end = itr->second->m_mr.second;
	MEM_ATTRIBUTE att = itr->second->m_att;
	delete (itr->second);
	m_hash.erase(itr);

	// update m_vacancy
	itr = m_vacancy.upper_bound(adr);
	Memory *pMem = itr->second;
	if(itr != m_vacancy.end() && end == (pMem->m_mr.first - 1) && att == pMem->m_att) {
		end = pMem->m_mr.second;
		itr = m_vacancy.erase(itr);
		delete pMem;
	}
	itr--;
	pMem = itr->second;
	if(itr != m_vacancy.begin() && (pMem->m_mr.second == (start - 1))  && att == pMem->m_att) {
		start = itr->first;
		itr = m_vacancy.erase(itr);
		delete pMem;
	}
	m_vacancy.insert(std::make_pair(start, new Memory(MEMRANGE(start, end), att)));
	return true;
}


bool CLinker::IsAvailable(MEMADDR start, MEMADDR end, MEM_ATTRIBUTE att) {
	
	if (m_hash.empty()) {
		return true;
	}
	
	//Debug();
	std::map<MEMADDR, Memory*>::iterator lower;	//<! adr「以上の」要素が最初に現れる位置
	std::map<MEMADDR, Memory*>::iterator upper;	//<! adr「以上の」要素が最初に現れる位置
	lower = upper = m_hash.lower_bound(start);

	if (m_hash.begin()->first < start) {	
		lower--;
		if (lower->second->m_mr.second >= start) {
			return false;
		}
	}

	if (upper != m_hash.end()) {
		if (upper->first <= end) {
			return false;
		}
	} else {
		MEMADDR a = 0;
		if ( ~a < end ) {
			return false;
		}
	}

	std::map<MEMADDR, Memory*>::iterator itrVac;
	itrVac = m_vacancy.lower_bound(start);
	if(itrVac != m_vacancy.end()) {
		Memory *pMem = itrVac->second;
		if(pMem->m_mr.second < end || pMem->m_att != att){
			return false;
		}
	}

	return true;
}


void CLinker::Debug(void) {
	std::map<MEMADDR, Memory*>::iterator itr;
	int i = 0;
	std::cout << "--- Allocation table ---" << std::endl;
	for (itr = m_hash.begin(); itr != m_hash.end(); itr++) {
		Memory* pMem = itr->second;
		std::cout  << std::setw(2) << std::setfill('0') << std::dec << i << ':' 
			<< std::hex << std::setw(8) << std::setfill('0') << pMem->m_mr.first << '-' 
			<< std::hex << std::setw(8) << std::setfill('0') << pMem->m_mr.second << std::endl;
		i++;
	}
}

