In order to run Create_Configuration_Automatically:
	type:		 ./Port_PCL_Data_to_Config.PL <PCL configuration name>
	for example: ./Port_PCL_Data_to_Config.PL PCL_configuration.xlsm